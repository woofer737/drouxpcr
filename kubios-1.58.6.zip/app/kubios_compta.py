# -*- coding: utf-8 -*-
"""Rapport comptable mensuel (1.52.0) : le « rapport de ventes pour taxes » remis à la comptabilité,
calculé à partir des ventes Lightspeed gardées dans Kubios et exporté en Excel (avec formules).

Structure du rapport (réglable par un administrateur, meta « compta_cfg ») :
  1. Ventes totales (sous-total, réductions, TPS, TVQ) ;
  2. Montants à réduire du chiffre de ventes (non taxables, ventes à d'autres taux, livraison, locations…),
     chacun associé à un compte GL ; le reste va au compte principal (ex. 4005 Ventes TPS/TVQ) ;
  3. Écritures GL (formules : la somme des écritures égale toujours les ventes totales) ;
  4. Dépenses / coût (usage interne, entretien…) ;
  5. Paiements et remboursements par compte GL, avec contrôle par rapport aux ventes.
Chaque ligne de vente n'est comptée qu'une fois : elle va à la PREMIÈRE ligne du rapport dont une source correspond."""
import re
import json
import datetime
import traceback
from flask import request, jsonify, render_template, send_file, session
import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from kubios_base import get_company_name, get_conn, meta_get, meta_set
from kubios_app import app
from kubios_auth import admin_required_check, log_audit, permission_required_check
from kubios_atelier_outils import store_missing_days
from kubios_rh_outils import PDF_DIR
from kubios_lightspeed import LightspeedError, TAX_EPS, _store_state, _tax_pct, ls_config
from kubios_rapports import REP_MISC, REP_NO_CATEGORY, _rep_run_local, _rep_state, _shop_name

__all__ = ['COMPTA_DEFAULT', 'COMPTA_SOURCE_TYPES', 'api_compta_config', 'api_compta_export', 'api_compta_report',
           'api_compta_status', 'compta_cfg', 'compta_page', 'compta_report', 'export_compta_xlsx']

MOIS_COURTS = ['Janv', 'Févr', 'Mars', 'Avril', 'Mai', 'Juin', 'Juil', 'Août', 'Sept', 'Oct', 'Nov', 'Déc']

# Types de sources qu'on peut associer à une ligne du rapport
COMPTA_SOURCE_TYPES = {
    'categorie': "Catégorie d'articles",
    'classe_taxe': 'Classe de taxe',
    'categorie_taxe': 'Catégorie de taxes (contient)',
    'frais': 'Frais Lightspeed',
    'frais_sans_taxe': 'Frais Lightspeed sans taxe (consigne)',
    'taux': 'Taux de taxe total (%)',
    'sans_taxe': 'Toute vente sans taxe',
    'divers': 'Articles divers (sans fiche)',
    'texte': 'Description contient',
}

COMPTA_DEFAULT = {
    'principal': {'label': 'Ventes TPS/TVQ', 'gl': '4005'},
    'ventilation': [
        {'label': 'Ventes Autochtones', 'gl': '4006', 'sources': [{'type': 'categorie_taxe', 'value': 'autochtone'}]},
        {'label': 'Ventes sans taxes', 'gl': '', 'sources': [{'type': 'sans_taxe'}]},
        {'label': 'Ventes 5%', 'gl': '4007', 'sources': [{'type': 'taux', 'value': '5'}]},
        {'label': 'Ventes 11%', 'gl': '4011', 'sources': [{'type': 'taux', 'value': '11'}]},
        {'label': 'Ventes 12%', 'gl': '4012', 'sources': [{'type': 'taux', 'value': '12'}]},
        {'label': 'Ventes 13%', 'gl': '4008', 'sources': [{'type': 'taux', 'value': '13'}]},
        {'label': 'Ventes 14%', 'gl': '4013', 'sources': [{'type': 'taux', 'value': '14'}]},
        {'label': 'Ventes 15%', 'gl': '4010', 'sources': [{'type': 'taux', 'value': '15'}]},
        {'label': 'Livraison/Transport', 'gl': '4041', 'sources': [{'type': 'frais', 'value': '*'}]},
        {'label': 'Locations', 'gl': '4009', 'sources': [{'type': 'categorie', 'value': 'Location'}]},
        {'label': 'Taxes de pneus', 'gl': '4002', 'sources': [{'type': 'texte', 'value': 'taxe de pneu'}]},
    ],
    'depenses': [
        {'label': 'Consignes à rembourser', 'gl': '', 'sources': [{'type': 'frais_sans_taxe', 'value': '*'}]},
        {'label': 'Entretien équip. locations', 'gl': '6501', 'sources': []},
        {'label': 'Entretien Bâtisse/Magasin', 'gl': '6505', 'sources': []},
        {'label': 'Usage interne Magasin/Atelier', 'gl': '8156', 'sources': [{'type': 'categorie', 'value': 'Usage Interne Magasin'}]},
        {'label': "Écart d'arrondissement de caisse", 'gl': '8146', 'sources': []},
    ],
    'paiements': [
        {'label': 'Trans. à déposer - Lightspeed', 'gl': '1012', 'modes': []},
        {'label': 'Trans. au comptant à déposer (Chèques)', 'gl': '1014', 'modes': []},
        {'label': 'Trans. à déposer - Terminal externe', 'gl': '1016', 'modes': []},
        {'label': 'Trans. au comptant à déposer (Comptant)', 'gl': '1017', 'modes': []},
        {'label': 'Trans. au comptant à déposer (Dépôt direct, virement Interac)', 'gl': '1018', 'modes': []},
        {'label': 'Trans. à déposer - Financement', 'gl': '1019', 'modes': []},
        {'label': 'Trans. à déposer - Commerce en ligne', 'gl': '1027', 'modes': []},
        {'label': 'Ajustement inventaire Lightspeed (comptable inventaire)', 'gl': '1171', 'modes': []},
    ],
    'paiements_ignores': [],
    'prepare_par': '',
}


def _clean_gl(v):
    return re.sub(r'[^0-9A-Za-z.\-]', '', str(v or ''))[:20]


def _clean_sources(lst):
    out = []
    for s in (lst or [])[:40]:
        if not isinstance(s, dict) or s.get('type') not in COMPTA_SOURCE_TYPES:
            continue
        item = {'type': s['type']}
        if s['type'] not in ('sans_taxe', 'divers'):
            val = str(s.get('value') or '').strip()[:200]
            if not val:
                continue
            if s['type'] == 'taux':
                try:
                    val = ('%g' % float(val.replace(',', '.').replace('%', '').strip()))
                except ValueError:
                    continue
            item['value'] = val
        out.append(item)
    return out


def _clean_cfg(d):
    d = d if isinstance(d, dict) else {}
    p = d.get('principal') if isinstance(d.get('principal'), dict) else {}
    lines = lambda k: [x for x in (d.get(k) or []) if isinstance(x, dict)][:60]
    return {
        'principal': {'label': str(p.get('label') or 'Ventes TPS/TVQ').strip()[:120], 'gl': _clean_gl(p.get('gl'))},
        'ventilation': [{'label': str(x.get('label') or '').strip()[:120] or '(sans nom)', 'gl': _clean_gl(x.get('gl')),
                         'sources': _clean_sources(x.get('sources'))} for x in lines('ventilation')],
        'depenses': [{'label': str(x.get('label') or '').strip()[:120] or '(sans nom)', 'gl': _clean_gl(x.get('gl')),
                      'sources': _clean_sources(x.get('sources'))} for x in lines('depenses')],
        'paiements': [{'label': str(x.get('label') or '').strip()[:120] or '(sans nom)', 'gl': _clean_gl(x.get('gl')),
                       'modes': sorted({str(m).strip()[:120] for m in (x.get('modes') or []) if str(m).strip()}, key=str.lower)}
                      for x in lines('paiements')],
        'paiements_ignores': sorted({str(m).strip()[:120] for m in (d.get('paiements_ignores') or [])[:60] if str(m).strip()}, key=str.lower),
        'prepare_par': str(d.get('prepare_par') or '').strip()[:80],
    }


def compta_cfg():
    try:
        c = json.loads(meta_get('compta_cfg') or 'null')
    except ValueError:
        c = None
    if not c:
        return json.loads(json.dumps(COMPTA_DEFAULT))
    c = _clean_cfg(c)
    if meta_get('compta_autoch_v1') != '1':
        c = _migrate_autochtones(c)
    if meta_get('compta_consigne_v1') != '1':
        c = _migrate_consignes(c)
    return c


def _migrate_consignes(c):
    """1.58.6 (une fois) : « Consignes à rembourser » sans source → frais Lightspeed sans taxe (montant non taxé des frais)."""
    changed = False
    for d in c['depenses']:
        if 'consigne' in d['label'].lower() and not d['sources']:
            d['sources'] = [{'type': 'frais_sans_taxe', 'value': '*'}]
            changed = True
    if changed:
        meta_set('compta_cfg', json.dumps(c, ensure_ascii=False))
    meta_set('compta_consigne_v1', '1')
    return c


def _migrate_autochtones(c):
    """1.58.4 (une fois) : la ligne « Ventes Autochtones » cherche la catégorie de taxes « Autochtones - Exonéré » de Lightspeed
    et passe en premier (sinon ces ventes, sans taxes, iraient à « Ventes sans taxes »)."""
    vent = c['ventilation']
    i = next((k for k, v in enumerate(vent) if 'autochton' in v['label'].lower()), None)
    if i is not None:
        line = vent.pop(i)
        if not line['sources']:
            line['sources'] = [{'type': 'categorie_taxe', 'value': 'autochtone'}]
        vent.insert(0, line)
        meta_set('compta_cfg', json.dumps(c, ensure_ascii=False))
    meta_set('compta_autoch_v1', '1')
    return c


# ---------------------------------------------------------------- calcul

def _norm(s):
    return str(s or '').strip().lower()


def _line_matches(src, ln):
    t = src['type']
    v = _norm(src.get('value'))
    if t == 'sans_taxe':
        return ln['notax']
    if t == 'divers':
        return ln['divers']
    if t == 'categorie':
        if v in (_norm(REP_NO_CATEGORY), _norm(REP_MISC)):
            return _norm(ln['cat_top']) == v
        p = _norm(ln['cat_path'])
        return bool(p) and (_norm(ln['cat_top']) == v or p == v or p.startswith(v + '/'))
    if t == 'classe_taxe':
        return _norm(ln['classe']) == v
    if t == 'categorie_taxe':                  # 1.58.4 : « contient » (ex. « autochtone » → « Autochtones - Exonéré »)
        return bool(v) and (v in _norm(ln['cat_taxe']) or v in _norm(ln.get('cat_taxe_vente')))   # ligne OU vente (1.58.5)
    if t == 'frais':
        return ln['is_fee'] and (v == '*' or _norm(ln['fee_name']) == v)
    if t == 'frais_sans_taxe':                 # 1.58.6 : consigne = frais Lightspeed NON taxé (« * » = tous, sinon nom contient)
        return ln['is_fee'] and ln['notax'] and (v == '*' or (bool(v) and v in _norm(ln['fee_name'])))
    if t == 'taux':
        try:
            return (not ln['notax']) and abs(ln['taux'] - float(v)) < 0.01
        except ValueError:
            return False
    if t == 'texte':
        return bool(v) and (v in _norm(ln['descr']) or v in _norm(ln['fee_name']))
    return False


def _source_label(ln):
    """Ce qui décrit la ligne de vente dans le détail (catégorie ou frais)."""
    if ln['is_fee']:
        return 'Frais : ' + (ln['fee_name'] or 'Frais')
    return ln['cat_top']


def _load_lines(d0, d1, shop_id):
    conn = get_conn()
    try:
        cats = {r['category_id']: r['path'] or r['name'] or '' for r in conn.execute("SELECT category_id, name, path FROM ls_categories")}
        classes = {r['tax_class_id']: r['name'] for r in conn.execute("SELECT tax_class_id, name FROM ls_tax_classes")}
        # nom + noms des taxes (une catégorie exonérée garde souvent son nom dans tax1Name : « Autochtones - Exonéré »)
        tcats = {r['tax_category_id']: ' | '.join(dict.fromkeys(x for x in (r['name'], r['tax1_name'], r['tax2_name']) if x))
                 for r in conn.execute("SELECT tax_category_id, name, tax1_name, tax2_name FROM ls_tax_categories")}
        q = ("SELECT item_id, category_id, subtotal, discount, total, tax1, tax2, tax1_rate, tax2_rate, tax_cat, sale_tax_cat, tax_class, "
             "is_fee, fee_name, descr FROM sales_lines WHERE sale_date BETWEEN ? AND ?")
        args = [d0.isoformat(), d1.isoformat()]
        if shop_id:
            q += " AND shop_id=?"
            args.append(str(shop_id))
        rows = conn.execute(q, args).fetchall()
        pq = ("SELECT COALESCE(NULLIF(TRIM(name),''),'(Autre)') name, "
              "SUM(CASE WHEN amount>=0 THEN amount ELSE 0 END) pos, SUM(CASE WHEN amount<0 THEN amount ELSE 0 END) neg, COUNT(*) n "
              "FROM sales_payments WHERE COALESCE(pay_date, sale_date) BETWEEN ? AND ?" + (" AND shop_id=?" if shop_id else "") + " GROUP BY 1")
        pays = [dict(r) for r in conn.execute(pq, args).fetchall()]
        n_sales = conn.execute("SELECT COUNT(DISTINCT sale_id) n FROM sales_lines WHERE sale_date BETWEEN ? AND ?"
                               + (" AND shop_id=?" if shop_id else ""), args).fetchone()['n']
    finally:
        conn.close()
    lines = []
    for r in rows:
        x1, x2 = r['tax1'] or 0.0, r['tax2'] or 0.0
        notax = abs(x1) <= TAX_EPS and abs(x2) <= TAX_EPS
        taux = (_tax_pct(r['tax1_rate']) if abs(x1) > TAX_EPS else 0) + (_tax_pct(r['tax2_rate']) if abs(x2) > TAX_EPS else 0)
        divers = str(r['item_id'] or '0') in ('', '0') and not r['is_fee']
        path = cats.get(r['category_id'] or '')
        if divers:
            top = REP_MISC
        elif path is None or not path:
            top = REP_NO_CATEGORY
        else:
            top = path.split('/')[0].strip()
        lines.append({'sous_total': r['subtotal'] or 0.0, 'reductions': -(r['discount'] or 0.0), 'total': r['total'] or 0.0,
                      'tps': x1, 'tvq': x2, 'notax': notax, 'taux': round(taux, 4), 'divers': divers,
                      'cat_path': path or '', 'cat_top': top,
                      'classe': classes.get(r['tax_class'] or '') or ('Sans classe' if not r['tax_class'] else ''),
                      'cat_taxe': tcats.get(r['tax_cat'] or '') or '', 'cat_taxe_vente': tcats.get(r['sale_tax_cat'] or '') or '',
                      'is_fee': bool(r['is_fee']),
                      'fee_name': r['fee_name'] or '', 'descr': r['descr'] or ''})
    return lines, pays, n_sales


def _empty_amounts():
    return {'sous_total': 0.0, 'reductions': 0.0, 'tps': 0.0, 'tvq': 0.0}


def _add(acc, ln):
    for k in ('sous_total', 'reductions', 'tps', 'tvq'):
        acc[k] += ln[k]


def _finish(acc):
    for k in ('sous_total', 'reductions', 'tps', 'tvq'):
        acc[k] = round(acc[k], 2)
    acc['total'] = round(acc['sous_total'] + acc['reductions'] + acc['tps'] + acc['tvq'], 2)
    return acc


def compta_report(d0, d1, shop_id='', username=None, cfg=None):
    cfg = cfg or compta_cfg()
    lines, pays, n_sales = _load_lines(d0, d1, shop_id)
    totals = _empty_amounts()
    vent = [dict(_empty_amounts(), label=v['label'], gl=v['gl'], manuel=not v['sources'], lignes=0, detail={}) for v in cfg['ventilation']]
    dep = [{'label': v['label'], 'gl': v['gl'], 'manuel': not v['sources'], 'montant': 0.0, 'lignes': 0, 'detail': {}} for v in cfg['depenses']]
    reste_detail = {}
    for ln in lines:
        _add(totals, ln)
        for i, v in enumerate(cfg['ventilation']):              # première ligne correspondante seulement
            if any(_line_matches(s, ln) for s in v['sources']):
                _add(vent[i], ln)
                vent[i]['lignes'] += 1
                key = _source_label(ln)
                vent[i]['detail'][key] = vent[i]['detail'].get(key, 0.0) + ln['sous_total'] + ln['reductions']
                break
        else:
            key = _source_label(ln) + (f" — taxes {('%g' % ln['taux']).replace('.', ',')} %" if not ln['notax'] else ' — sans taxe')
            reste_detail[key] = reste_detail.get(key, 0.0) + ln['sous_total'] + ln['reductions']
        for i, v in enumerate(cfg['depenses']):                  # les dépenses sont indépendantes de la ventilation
            if any(_line_matches(s, ln) for s in v['sources']):
                dep[i]['montant'] += ln['total']
                dep[i]['lignes'] += 1
                key = _source_label(ln)
                dep[i]['detail'][key] = dep[i]['detail'].get(key, 0.0) + ln['total']
                break
    _finish(totals)
    for v in vent:
        _finish(v)
    reduire = _finish({k: sum(v[k] for v in vent) for k in ('sous_total', 'reductions', 'tps', 'tvq')})
    principal = _finish({k: totals[k] - reduire[k] for k in ('sous_total', 'reductions', 'tps', 'tvq')})
    principal.update(label=cfg['principal']['label'], gl=cfg['principal']['gl'])
    for d in dep:
        d['montant'] = round(d['montant'], 2)
    # paiements
    by_mode = {_norm(p['name']): p for p in pays}
    used = set()
    pay_rows = []
    for p in cfg['paiements']:
        row = {'label': p['label'], 'gl': p['gl'], 'modes': p['modes'], 'manuel': not p['modes'],
               'paiements': 0.0, 'remboursements': 0.0, 'detail': []}
        for m in p['modes']:
            src = by_mode.get(_norm(m))
            if src and _norm(m) not in used:
                used.add(_norm(m))
                row['paiements'] += src['pos'] or 0.0
                row['remboursements'] += src['neg'] or 0.0
                row['detail'].append({'mode': src['name'], 'paiements': round(src['pos'] or 0, 2),
                                      'remboursements': round(src['neg'] or 0, 2), 'nombre': src['n']})
        pay_rows.append(row)
    ignored = {_norm(m) for m in cfg.get('paiements_ignores') or []}
    rest = [{'mode': p['name'], 'paiements': round(p['pos'] or 0, 2), 'remboursements': round(p['neg'] or 0, 2),
             'total': round((p['pos'] or 0) + (p['neg'] or 0), 2), 'nombre': p['n']}
            for p in sorted(pays, key=lambda p: -abs((p['pos'] or 0) + (p['neg'] or 0))) if _norm(p['name']) not in used]
    non_associes = [x for x in rest if _norm(x['mode']) not in ignored]
    ignores = [x for x in rest if _norm(x['mode']) in ignored]          # ex. Compte à recevoir : exclus du total des paiements
    for r in pay_rows:
        r['paiements'], r['remboursements'] = round(r['paiements'], 2), round(r['remboursements'], 2)
        r['total'] = round(r['paiements'] + r['remboursements'], 2)
    pay_total = round(sum(r['total'] for r in pay_rows) + sum(x['total'] for x in non_associes), 2)
    rnd = lambda dct: [{'source': k, 'montant': round(v, 2)} for k, v in sorted(dct.items(), key=lambda kv: -abs(kv[1])) if abs(v) >= 0.005]
    for v in vent + dep:
        v['detail'] = rnd(v['detail'])
    conn = get_conn()
    fetched = conn.execute("SELECT MIN(fetched_at) a, MAX(fetched_at) b FROM sales_days WHERE day BETWEEN ? AND ?",
                           (d0.isoformat(), d1.isoformat())).fetchone()
    conn.close()
    return {'report': 'compta', 'title': 'Rapport de ventes pour taxes',
            'start': d0.isoformat(), 'end': d1.isoformat(), 'shop_id': shop_id or '', 'shop_name': _shop_name(shop_id),
            'prepare_par': cfg.get('prepare_par') or '', 'sales_count': n_sales,
            'totals': totals, 'ventilation': vent, 'a_reduire': reduire, 'principal': principal, 'reste_detail': rnd(reste_detail),
            'depenses': dep, 'paiements': pay_rows, 'non_associes': non_associes, 'ignores': ignores, 'paiements_total': pay_total,
            'ecart_paiements': round(totals['total'] - pay_total, 2),
            'fetched_oldest': fetched['a'], 'fetched_newest': fetched['b'],
            'generated_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'by': username}


# ---------------------------------------------------------------- Excel

def _dfr(iso):
    return f"{iso[8:10]}-{iso[5:7]}-{iso[:4]}"


def export_compta_xlsx(r, prepare_par=None):
    out = PDF_DIR / "Rapports_comptables"
    out.mkdir(parents=True, exist_ok=True)
    d0 = datetime.date.fromisoformat(r['start'])
    one_month = r['start'][:7] == r['end'][:7]
    sheet_title = f"{MOIS_COURTS[d0.month - 1]} {d0.year}" if one_month else f"{r['start']} au {r['end']}"
    path = out / f"Rapport_ventes_taxes_{r['start']}_au_{r['end']}.xlsx"
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = re.sub(r'[\\/*?:\[\]]', '-', sheet_title)[:31]
    money = '#,##0.00 $;[Red]-#,##0.00 $'
    blue = '1E3A8A'
    head_fill = PatternFill('solid', fgColor=blue)
    sec_fill = PatternFill('solid', fgColor='DBE3F3')
    tot_fill = PatternFill('solid', fgColor='F1F5F9')
    man_fill = PatternFill('solid', fgColor='FFF7CC')
    thin = Side(style='thin', color='CBD5E1')
    top_border = Border(top=Side(style='medium', color='64748B'))
    for col, w in zip('ABCDEFGH', (4, 9, 58, 15, 17, 14, 14, 16)):
        ws.column_dimensions[col].width = w

    ws['C1'] = (prepare_par if prepare_par is not None else r.get('prepare_par')) or ''
    ws['C1'].font = Font(bold=True, size=12)
    ws['C2'] = get_company_name() + (f" — {r['shop_name']}" if r.get('shop_name') else '')
    ws['C2'].font = Font(bold=True, size=13, color=blue)
    ws['C3'] = f"Rapport de vente du {_dfr(r['start'])} au {_dfr(r['end'])}"
    ws['C3'].font = Font(bold=True, size=12)
    g = r['generated_at']
    ws['C4'] = (f"Généré par Kubios le {_dfr(g[:10])} à {g[11:16]}" + (f" par {r['by']}" if r.get('by') else '')
                + f" — {r['sales_count']} vente(s) Lightspeed. Cellules jaunes : montants à saisir à la main.")
    ws['C4'].font = Font(italic=True, size=9, color='6B7280')

    def head(row, labels, first_col=2):
        for j, lbl in enumerate(labels):
            c = ws.cell(row=row, column=first_col + j, value=lbl)
            if lbl:
                c.font = Font(bold=True, color='FFFFFF')
                c.fill = head_fill
                c.alignment = Alignment(horizontal='left' if first_col + j <= 3 else 'right')

    def amounts(row, vals, manual=False, bold=False, fill=None):
        """vals : D..G (valeur ou formule) ; H = somme."""
        for j, v in enumerate(vals):
            c = ws.cell(row=row, column=4 + j, value=v)
            c.number_format = money
            if manual:
                c.fill = man_fill
            elif fill:
                c.fill = fill
            if bold:
                c.font = Font(bold=True)
        c = ws.cell(row=row, column=8, value=f"=SUM(D{row}:G{row})")
        c.number_format = money
        c.font = Font(bold=True)
        if fill:
            c.fill = fill

    def label(row, text, gl=None, bold=False, fill=None):
        if gl is not None:
            c = ws.cell(row=row, column=2, value=int(gl) if str(gl).isdigit() else (gl or None))
            c.alignment = Alignment(horizontal='left')
            if fill:
                c.fill = fill
        c = ws.cell(row=row, column=3, value=text)
        c.font = Font(bold=bold)
        if fill:
            c.fill = fill

    # 1. Ventes totales
    row = 6
    head(row, ['', '', 'Sous-total', 'Réductions', 'TPS', 'TVQ', 'Total'])
    row += 1
    T = r['totals']
    label(row, 'Ventes totales :', bold=True, fill=sec_fill)
    amounts(row, [T['sous_total'], T['reductions'], T['tps'], T['tvq']], bold=True, fill=sec_fill)
    r_tot = row
    # 2. À réduire
    row += 2
    ws.cell(row=row, column=3, value='À réduire du chiffre de ventes').font = Font(bold=True, size=12, color=blue)
    row += 1
    vrows = []
    for v in r['ventilation']:
        label(row, v['label'])
        amounts(row, [v['sous_total'], v['reductions'], v['tps'], v['tvq']], manual=v['manuel'])
        vrows.append(row)
        row += 1
    r_red = row
    label(row, 'Total à réduire', bold=True, fill=tot_fill)
    if vrows:
        amounts(row, [f"=SUM({c}{vrows[0]}:{c}{vrows[-1]})" for c in 'DEFG'], bold=True, fill=tot_fill)
    else:
        amounts(row, [0, 0, 0, 0], bold=True, fill=tot_fill)
    for col in range(3, 9):
        ws.cell(row=row, column=col).border = top_border
    # 3. Écritures GL
    row += 2
    head(row, ['GL', 'Écritures à faire', 'Sous-total', 'Réductions', 'TPS', 'TVQ', 'Total'])
    row += 1
    gl_first = row
    P = r['principal']
    label(row, P['label'], P['gl'])
    amounts(row, [f"={c}{r_tot}-{c}{r_red}" for c in 'DEFG'])
    row += 1
    for v, src in zip(r['ventilation'], vrows):
        label(row, v['label'], v['gl'])
        amounts(row, [f"={c}{src}" for c in 'DEFG'])
        row += 1
    gl_last = row - 1
    label(row, 'Sous-total des écritures', bold=True, fill=tot_fill)
    amounts(row, [f"=SUM({c}{gl_first}:{c}{gl_last})" for c in 'DEFG'], bold=True, fill=tot_fill)
    for col in range(3, 9):
        ws.cell(row=row, column=col).border = top_border
    r_glsum = row
    row += 1
    ws.cell(row=row, column=3, value='Vérification (doit être 0,00 $)').font = Font(italic=True, color='6B7280')
    c = ws.cell(row=row, column=8, value=f"=ROUND(H{r_glsum}-H{r_tot},2)")
    c.number_format = money
    c.font = Font(italic=True, color='6B7280')
    # 4. Dépenses / coût
    row += 2
    head(row, ['GL', 'Dépenses / coût', 'Montant'])
    row += 1
    for d in r['depenses']:
        label(row, d['label'], d['gl'])
        c = ws.cell(row=row, column=4, value=d['montant'] if not d['manuel'] else None)
        c.number_format = money
        if d['manuel']:
            c.fill = man_fill
        row += 1
    # 5. Paiements
    row += 1
    head(row, ['GL', 'Paiements', 'Paiements', 'Remboursements', 'Total'])
    row += 1
    p_first = row
    for p in r['paiements']:
        label(row, p['label'], p['gl'])
        for j, v in enumerate((p['paiements'] if not p['manuel'] else None, p['remboursements'] if not p['manuel'] else None)):
            c = ws.cell(row=row, column=4 + j, value=v)
            c.number_format = money
            if p['manuel']:
                c.fill = man_fill
        c = ws.cell(row=row, column=6, value=f"=SUM(D{row}:E{row})")
        c.number_format = money
        c.font = Font(bold=True)
        row += 1
    for x in r['non_associes']:
        label(row, f"Mode non associé : {x['mode']}")
        ws.cell(row=row, column=3).font = Font(color='B91C1C', bold=True)
        for j, v in enumerate((x['paiements'], x['remboursements'])):
            ws.cell(row=row, column=4 + j, value=v).number_format = money
        c = ws.cell(row=row, column=6, value=f"=SUM(D{row}:E{row})")
        c.number_format = money
        c.font = Font(bold=True)
        row += 1
    p_last = row - 1
    label(row, 'Total des paiements', bold=True, fill=tot_fill)
    for j, col in enumerate('DEF'):
        c = ws.cell(row=row, column=4 + j, value=f"=SUM({col}{p_first}:{col}{p_last})" if p_last >= p_first else 0)
        c.number_format = money
        c.font = Font(bold=True)
        c.fill = tot_fill
        c.border = top_border
    r_ptot = row
    row += 1
    ws.cell(row=row, column=3, value="Écart : ventes avec taxes − paiements (ventes portées au compte, dépôts, etc.)").font = Font(italic=True, color='6B7280')
    c = ws.cell(row=row, column=6, value=f"=ROUND(H{r_tot}-F{r_ptot},2)")
    c.number_format = money
    c.font = Font(italic=True, color='6B7280')
    for x in r.get('ignores') or []:
        row += 1
        fr = lambda v: f"{v:,.2f}".replace(',', ' ').replace('.', ',')
        ws.cell(row=row, column=3, value=f"Mode exclu du rapport : {x['mode']} (paiements {fr(x['paiements'])} $ ; "
                                         f"remboursements {fr(x['remboursements'])} $)").font = Font(italic=True, color='6B7280')
    ws.freeze_panes = 'A6'
    ws.sheet_view.zoomScale = 90
    ws.page_setup.orientation = 'portrait'
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_title_rows = None

    # Feuille 2 : d'où vient chaque montant
    wd = wb.create_sheet('Détail des sources')
    for col, w in zip('ABC', (48, 52, 16)):
        wd.column_dimensions[col].width = w
    wd['A1'] = f"Détail des sources — {_dfr(r['start'])} au {_dfr(r['end'])}"
    wd['A1'].font = Font(bold=True, size=13, color=blue)
    wd['A2'] = "Montants avant taxes (sous-total moins réductions) ; dépenses : montants après réductions, avant taxes."
    wd['A2'].font = Font(italic=True, size=9, color='6B7280')
    row = 4
    for j, lbl in enumerate(('Ligne du rapport', 'Source Lightspeed', 'Montant')):
        c = wd.cell(row=row, column=1 + j, value=lbl)
        c.font = Font(bold=True, color='FFFFFF')
        c.fill = head_fill
    row += 1
    blocks = [(P['label'] + ' (reste des ventes)', r['reste_detail'])] + [(v['label'], v['detail']) for v in r['ventilation']] \
        + [('Dépense : ' + d['label'], d['detail']) for d in r['depenses']]
    for name, det in blocks:
        if not det:
            continue
        for k, x in enumerate(det):
            wd.cell(row=row, column=1, value=name if k == 0 else None).font = Font(bold=k == 0)
            wd.cell(row=row, column=2, value=x['source'])
            wd.cell(row=row, column=3, value=x['montant']).number_format = money
            row += 1
        row += 1
    if any(p['detail'] for p in r['paiements']):
        for j, lbl in enumerate(('Paiements', 'Mode de paiement Lightspeed', 'Total')):
            c = wd.cell(row=row, column=1 + j, value=lbl)
            c.font = Font(bold=True, color='FFFFFF')
            c.fill = head_fill
        row += 1
        for p in r['paiements']:
            for k, x in enumerate(p['detail']):
                wd.cell(row=row, column=1, value=p['label'] if k == 0 else None).font = Font(bold=k == 0)
                wd.cell(row=row, column=2, value=f"{x['mode']} ({x['nombre']})")
                wd.cell(row=row, column=3, value=round(x['paiements'] + x['remboursements'], 2)).number_format = money
                row += 1
    wb.save(path)
    return path


# ---------------------------------------------------------------- pages et API

@app.route('/rapport-comptable')
def compta_page():
    resp = permission_required_check('tax_reports')
    if resp is not None:
        return resp
    return render_template('compta_report.html', company=get_company_name(), username=session.get('username'),
                           is_admin=bool(session.get('is_admin')))


@app.route('/api/compta/status')
def api_compta_status():
    resp = permission_required_check('tax_reports')
    if resp is not None:
        return resp
    ss = _store_state
    conn = get_conn()
    shops = [dict(r) for r in conn.execute("SELECT shop_id id, name FROM ls_shops WHERE archived=0 ORDER BY name").fetchall()]
    conn.close()
    return jsonify({'connected': ls_config()['connected'], 'is_admin': bool(session.get('is_admin')),
                    'running': ss['running'], 'progress': ss['progress'],
                    'error': _rep_state['error'] or (ss['error'] if not ss['running'] else None),
                    'result': _rep_state.get('compta') if not ss['running'] else None, 'shops': shops,
                    'prepare_par': compta_cfg().get('prepare_par') or ''})


@app.route('/api/compta/report', methods=['POST'])
def api_compta_report():
    resp = permission_required_check('tax_reports')
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}
    try:
        start = datetime.date.fromisoformat(data.get('start') or '')
        end = datetime.date.fromisoformat(data.get('end') or '')
    except ValueError:
        return jsonify({'ok': False, 'error': "Dates invalides."}), 400
    if end < start:
        return jsonify({'ok': False, 'error': "La date de fin est avant la date de début."}), 400
    end = min(end, datetime.date.today())
    if start > end:
        return jsonify({'ok': False, 'error': "La période choisie est dans le futur."}), 400
    if (end - start).days > 400:
        return jsonify({'ok': False, 'error': "Période trop longue (maximum un an)."}), 400
    shop_id = str(data.get('shop_id') or '').strip()
    if data.get('refresh'):
        if not ls_config()['connected']:
            return jsonify({'ok': False, 'error': "Kubios n'est pas connecté à Lightspeed (Administration → Lightspeed)."}), 400
        missing = [start + datetime.timedelta(days=i) for i in range((end - start).days + 1)]
    else:
        missing = store_missing_days(start, end, need_tax=True, need_pay=True)
    if missing and not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Des jours de cette période ne sont pas encore dans Kubios et Kubios n'est "
                                              "pas connecté à Lightspeed (Administration → Lightspeed)."}), 400
    user = session.get('username')
    _rep_state['error'] = None
    try:
        ready = _rep_run_local('compta', missing, lambda: compta_report(start, end, shop_id, user), user)
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    log_audit('Rapport comptable mensuel ' + ('régénéré à partir de Lightspeed' if data.get('refresh') else 'demandé'),
              f"{start} au {end}" + (f", magasin #{shop_id}" if shop_id else ""))
    return jsonify({'ok': True, 'ready': ready, 'missing': len(missing)})


@app.route('/api/compta/export')
def api_compta_export():
    resp = permission_required_check('tax_reports')
    if resp is not None:
        return resp
    r = _rep_state.get('compta')
    if not r:
        return jsonify({'error': "Aucun rapport à exporter : génère-le d'abord."}), 400
    prep = request.args.get('prepare_par')
    path = export_compta_xlsx(r, prep.strip()[:80] if prep is not None else None)
    log_audit('Rapport comptable mensuel exporté (Excel)', f"{r['start']} au {r['end']}")
    return send_file(str(path), as_attachment=True, download_name=path.name)


@app.route('/api/compta/config', methods=['GET', 'POST'])
def api_compta_config():
    if request.method == 'POST':
        resp = admin_required_check()
        if resp is not None:
            return resp
        cfg = _clean_cfg(request.get_json(silent=True) or {})
        meta_set('compta_cfg', json.dumps(cfg, ensure_ascii=False))
        log_audit('Rapport comptable : configuration modifiée',
                  f"{len(cfg['ventilation'])} ligne(s) de ventes, {len(cfg['depenses'])} dépense(s), {len(cfg['paiements'])} paiement(s)")
        if _rep_state.get('compta'):                               # recalculer l'aperçu affiché avec les nouveaux réglages
            r = _rep_state['compta']
            try:
                _rep_state['compta'] = compta_report(datetime.date.fromisoformat(r['start']), datetime.date.fromisoformat(r['end']),
                                                     r.get('shop_id') or '', session.get('username'), cfg)
            except Exception:
                traceback.print_exc()
        return jsonify({'ok': True, 'config': cfg})
    resp = permission_required_check('tax_reports')
    if resp is not None:
        return resp
    if request.args.get('defaut'):
        return jsonify({'config': json.loads(json.dumps(COMPTA_DEFAULT))})
    conn = get_conn()
    try:
        q = lambda sql: [r[0] for r in conn.execute(sql).fetchall() if r[0] and str(r[0]).strip()]
        cats = q("SELECT DISTINCT TRIM(CASE WHEN INSTR(path,'/')>0 THEN SUBSTR(path,1,INSTR(path,'/')-1) ELSE COALESCE(path,name) END) "
                 "FROM ls_categories ORDER BY 1 COLLATE NOCASE")
        opts = {
            'categorie': cats + [REP_NO_CATEGORY, REP_MISC],
            'classe_taxe': q("SELECT name FROM ls_tax_classes ORDER BY name COLLATE NOCASE") + ['Sans classe'],
            'categorie_taxe': q("SELECT name FROM ls_tax_categories UNION SELECT tax1_name FROM ls_tax_categories "
                                "UNION SELECT tax2_name FROM ls_tax_categories ORDER BY 1 COLLATE NOCASE"),
            'frais': ['*'] + q("SELECT DISTINCT fee_name FROM sales_lines WHERE is_fee=1 ORDER BY fee_name COLLATE NOCASE"),
            'frais_sans_taxe': ['*'] + q("SELECT DISTINCT fee_name FROM sales_lines WHERE is_fee=1 AND ABS(COALESCE(tax1,0))<=0.0001 "
                                         "AND ABS(COALESCE(tax2,0))<=0.0001 ORDER BY fee_name COLLATE NOCASE"),
            'paiements': q("SELECT DISTINCT COALESCE(NULLIF(TRIM(name),''),'(Autre)') FROM sales_payments ORDER BY 1 COLLATE NOCASE"),
        }
        since = (datetime.date.today() - datetime.timedelta(days=400)).isoformat()
        rates = set()
        for r in conn.execute("SELECT DISTINCT ROUND(tax1_rate,6) a, ROUND(tax2_rate,6) b, ABS(tax1)>? x1, ABS(tax2)>? x2 "
                              "FROM sales_lines WHERE sale_date>=?", (TAX_EPS, TAX_EPS, since)).fetchall():
            t = (_tax_pct(r['a']) if r['x1'] else 0) + (_tax_pct(r['b']) if r['x2'] else 0)
            if t > 0:
                rates.add('%g' % round(t, 4))
        opts['taux'] = sorted(rates, key=float)
    finally:
        conn.close()
    return jsonify({'config': compta_cfg(), 'options': opts, 'types': COMPTA_SOURCE_TYPES, 'is_admin': bool(session.get('is_admin'))})
