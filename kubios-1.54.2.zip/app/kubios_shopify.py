# -*- coding: utf-8 -*-
"""Boutique en ligne Shopify (1.54.0) : Kubios lit régulièrement les commandes de la boutique Shopify,
avise par courriel la personne responsable à chaque nouvelle commande et lui envoie un résumé quotidien
(commandes reçues, complétées, à suivre).

Connexion : application de la boutique créée dans le Dev Dashboard de Shopify (Client ID + secret →
jeton de 24 h obtenu par « client credentials », renouvelé automatiquement), ou jeton Admin API d'une
ancienne application personnalisée (shpat_…), qui reste valide.
Lecture seule : Kubios ne modifie jamais les commandes (portée read_orders)."""
import datetime
import json
import re
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
from html import escape
from flask import jsonify, render_template, request, session
from kubios_base import get_company_name, get_conn, meta_get, meta_set
from kubios_app import app
from kubios_auth import admin_required_check, log_audit, permission_required_check
from kubios_mail import send_email

__all__ = ['SHOPIFY_API_VERSION', 'SHOPIFY_DEFAULTS', 'api_shopify_config', 'api_shopify_orders', 'api_shopify_status',
           'api_shopify_summary', 'api_shopify_sync', 'api_shopify_test', 'shopify_cfg', 'shopify_page', 'shopify_summary_html',
           'shopify_sync', 'shopify_tick', 'start_shopify_monitor']

SHOPIFY_API_VERSION = '2026-07'
SHOPIFY_DEFAULTS = {'shop': '', 'auth': 'client', 'client_id': '', 'client_secret': '', 'token': '', 'enabled': False,
                    'notify_new': True, 'summary': True, 'summary_time': '17:30', 'emails': '', 'interval_min': 5,
                    'prefix': ''}                       # ex. « Web- » : seules ces commandes sont suivies (vide = toutes)
FULFILL_LABELS = {'FULFILLED': 'Traitée', 'UNFULFILLED': 'Non traitée', 'PARTIALLY_FULFILLED': 'Partiellement traitée',
                  'IN_PROGRESS': 'En préparation', 'ON_HOLD': 'En attente', 'OPEN': 'Ouverte', 'PENDING_FULFILLMENT': 'À préparer',
                  'RESTOCKED': 'Remise en stock', 'SCHEDULED': 'Planifiée', 'REQUEST_DECLINED': 'Demande refusée'}
FINANCE_LABELS = {'PAID': 'Payée', 'PENDING': 'Paiement en attente', 'AUTHORIZED': 'Paiement autorisé (à saisir)',
                  'PARTIALLY_PAID': 'Partiellement payée', 'REFUNDED': 'Remboursée', 'PARTIALLY_REFUNDED': 'Partiellement remboursée',
                  'VOIDED': 'Annulée (paiement)', 'EXPIRED': 'Paiement expiré'}
DONE_FULFILL = ('FULFILLED', 'RESTOCKED')
PAY_TODO = ('PENDING', 'AUTHORIZED', 'PARTIALLY_PAID', 'EXPIRED')
_lock = threading.Lock()


# ---------------------------------------------------------------- réglages et état

def _emails(txt):
    return [e for e in re.split(r'[\s,;]+', str(txt or '')) if re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+', e)][:20]


def _clean_shop(v):
    v = str(v or '').strip().lower()
    v = re.sub(r'^https?://', '', v).split('/')[0]
    if v and '.' not in v:
        v += '.myshopify.com'
    return v if re.fullmatch(r'[a-z0-9][a-z0-9\-]*\.myshopify\.com', v) else ''


def shopify_cfg():
    try:
        c = json.loads(meta_get('shopify_cfg') or '{}')
    except ValueError:
        c = {}
    out = dict(SHOPIFY_DEFAULTS)
    out.update({k: c[k] for k in SHOPIFY_DEFAULTS if k in c})
    return out


def _state():
    try:
        return json.loads(meta_get('shopify_state') or '{}')
    except ValueError:
        return {}


def _set_state(**kw):
    st = _state()
    st.update(kw)
    meta_set('shopify_state', json.dumps(st, ensure_ascii=False))
    return st


def _prefixes(cfg):
    return [p.strip().lower() for p in re.split(r'[,;]+', str(cfg.get('prefix') or '')) if p.strip()]


def _wanted(cfg, name):
    """La commande fait-elle partie de celles à suivre (préfixe du numéro, ex. « Web- ») ?"""
    pre = _prefixes(cfg)
    n = str(name or '').lstrip('#').lower()
    return not pre or any(n.startswith(p.lstrip('#')) for p in pre)


def _configured(cfg):
    return bool(cfg['shop'] and ((cfg['auth'] == 'token' and cfg['token']) or (cfg['auth'] == 'client' and cfg['client_id'] and cfg['client_secret'])))


# ---------------------------------------------------------------- API Shopify

class ShopifyError(Exception):
    pass


def _http(url, data=None, headers=None, timeout=30):
    """Requête HTTP (séparée pour les tests). Retourne (code, texte)."""
    req = urllib.request.Request(url, data=data, headers=headers or {}, method='POST' if data is not None else 'GET')
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read().decode('utf-8', 'replace')
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode('utf-8', 'replace')
    except (urllib.error.URLError, OSError) as e:
        raise ShopifyError(f"Shopify est injoignable ({getattr(e, 'reason', e)}). Vérifie la connexion Internet du serveur.")


_token_cache = {}


def _token(cfg, force=False):
    if cfg['auth'] == 'token':
        return cfg['token']
    key = (cfg['shop'], cfg['client_id'])
    t = _token_cache.get(key)
    if t and not force and t['exp'] > time.time() + 300:
        return t['token']
    body = urllib.parse.urlencode({'grant_type': 'client_credentials', 'client_id': cfg['client_id'],
                                   'client_secret': cfg['client_secret']}).encode()
    code, txt = _http(f"https://{cfg['shop']}/admin/oauth/access_token", body, {'Content-Type': 'application/x-www-form-urlencoded',
                                                                                'Accept': 'application/json'})
    try:
        d = json.loads(txt)
    except ValueError:
        d = {}
    if code != 200 or not d.get('access_token'):
        msg = d.get('error_description') or d.get('error') or txt[:200]
        if code in (400, 401, 403):
            raise ShopifyError("Shopify refuse la connexion : Client ID ou secret invalide, ou application non installée sur la boutique "
                               f"({msg}).")
        raise ShopifyError(f"Shopify a répondu {code} à la demande de jeton : {msg}")
    _token_cache[key] = {'token': d['access_token'], 'exp': time.time() + int(d.get('expires_in') or 86399), 'scope': d.get('scope') or ''}
    return d['access_token']


def _gql(cfg, query, variables=None):
    for attempt in (0, 1):
        tok = _token(cfg, force=attempt == 1)
        code, txt = _http(f"https://{cfg['shop']}/admin/api/{SHOPIFY_API_VERSION}/graphql.json",
                          json.dumps({'query': query, 'variables': variables or {}}).encode(),
                          {'Content-Type': 'application/json', 'Accept': 'application/json', 'X-Shopify-Access-Token': tok})
        if code == 401 and attempt == 0 and cfg['auth'] == 'client':
            continue                                    # jeton expiré : on en redemande un
        if code in (401, 403):
            raise ShopifyError("Shopify refuse l'accès : vérifie que l'application a la permission « read_orders » et qu'elle est installée "
                               "sur la boutique." + (" Le jeton (shpat_…) est peut-être révoqué." if cfg['auth'] == 'token' else ''))
        if code == 429 or code >= 500:
            raise ShopifyError(f"Shopify est momentanément indisponible ({code}). Kubios réessaiera.")
        try:
            d = json.loads(txt)
        except ValueError:
            raise ShopifyError(f"Réponse inattendue de Shopify ({code}).")
        return d
    raise ShopifyError("Connexion à Shopify impossible.")


ORDER_FIELDS = """id name createdAt updatedAt processedAt cancelledAt closed displayFinancialStatus displayFulfillmentStatus
  note tags totalPriceSet { shopMoney { amount currencyCode } }
  shippingLines(first: 3) { nodes { title } }
  lineItems(first: 40) { nodes { title variantTitle sku quantity } }"""
PROTECTED_FIELDS = " email phone customer { displayName } shippingAddress { city province }"


def _orders_query(protected):
    return ("query($q: String!, $after: String) { orders(first: 100, after: $after, query: $q, sortKey: UPDATED_AT) "
            "{ pageInfo { hasNextPage endCursor } nodes { " + ORDER_FIELDS + (PROTECTED_FIELDS if protected else '') + " } } }")


def _is_access_error(errors):
    txt = json.dumps(errors).lower()
    return any(w in txt for w in ('not approved', 'access denied', 'access_denied', 'protected customer', 'customer object'))


def _fetch_orders(cfg, since_iso, max_pages=30):
    """Commandes modifiées depuis since_iso. Si Shopify refuse les données protégées (nom, courriel du client),
    on relit sans elles et on le note dans l'état."""
    protected = _state().get('protected_ok', True)
    out, after = [], None
    for _ in range(max_pages):
        d = _gql(cfg, _orders_query(protected), {'q': f"updated_at:>='{since_iso}'", 'after': after})
        if d.get('errors') and protected and _is_access_error(d['errors']):
            protected = False
            _set_state(protected_ok=False)
            out, after = [], None
            continue
        if d.get('errors') and not (d.get('data') or {}).get('orders'):
            raise ShopifyError('Shopify : ' + '; '.join(str(e.get('message')) for e in d['errors'])[:300])
        o = d['data']['orders']
        out.extend(o['nodes'])
        if not o['pageInfo']['hasNextPage']:
            break
        after = o['pageInfo']['endCursor']
    return out


def _admin_url(cfg, gid):
    num = str(gid).rsplit('/', 1)[-1]
    return f"https://admin.shopify.com/store/{cfg['shop'].split('.')[0]}/orders/{num}"


def _row_from_node(cfg, n):
    money = (n.get('totalPriceSet') or {}).get('shopMoney') or {}
    cust = (n.get('customer') or {}).get('displayName') or ''
    addr = n.get('shippingAddress') or {}
    items = [{'t': (li.get('title') or '') + (f" — {li['variantTitle']}" if li.get('variantTitle') else ''), 'q': li.get('quantity') or 0,
              'sku': li.get('sku') or ''} for li in ((n.get('lineItems') or {}).get('nodes') or [])]
    ship = ', '.join(s.get('title') or '' for s in ((n.get('shippingLines') or {}).get('nodes') or []) if s.get('title'))
    return {'id': n['id'], 'name': n.get('name') or '', 'created_at': n.get('createdAt') or '', 'updated_at': n.get('updatedAt') or '',
            'cancelled_at': n.get('cancelledAt') or None, 'closed': 1 if n.get('closed') else 0,
            'financial': n.get('displayFinancialStatus') or '', 'fulfillment': n.get('displayFulfillmentStatus') or '',
            'total': float(money.get('amount') or 0), 'currency': money.get('currencyCode') or 'CAD', 'customer': cust,
            'email': n.get('email') or '', 'phone': n.get('phone') or '',
            'ship_city': ', '.join(x for x in (addr.get('city'), addr.get('province')) if x), 'shipping': ship,
            'items': json.dumps(items, ensure_ascii=False), 'note': (n.get('note') or '')[:1000],
            'tags': ', '.join(n.get('tags') or []) if isinstance(n.get('tags'), list) else (n.get('tags') or ''),
            'admin_url': _admin_url(cfg, n['id'])}


def _local(iso):
    """Horodatage Shopify (UTC « Z ») → heure locale du serveur, sans fuseau."""
    if not iso:
        return None
    try:
        return datetime.datetime.fromisoformat(iso.replace('Z', '+00:00')).astimezone().replace(tzinfo=None)
    except ValueError:
        return None


# ---------------------------------------------------------------- synchronisation

def shopify_sync(initial=None, notify=True):
    """Lit les commandes modifiées depuis la dernière lecture, met à jour la table locale et avise des nouvelles."""
    cfg = shopify_cfg()
    if not _configured(cfg):
        raise ShopifyError("La boutique Shopify n'est pas configurée.")
    with _lock:
        st = _state()
        first = initial if initial is not None else not st.get('initial_done')
        now_utc = datetime.datetime.now(datetime.timezone.utc)
        if first or not st.get('last_sync_utc'):
            since = now_utc - datetime.timedelta(days=60)
        else:
            since = datetime.datetime.fromisoformat(st['last_sync_utc']) - datetime.timedelta(minutes=15)
        try:
            nodes = _fetch_orders(cfg, since.strftime('%Y-%m-%dT%H:%M:%SZ'))
        except ShopifyError as e:
            _set_state(last_error=str(e), last_error_at=datetime.datetime.now().strftime('%Y-%m-%d %H:%M'))
            raise
        stamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        connected_at = st.get('connected_at') or now_utc.isoformat()
        new_orders = []
        conn = get_conn()
        try:
            for n in nodes:
                r = _row_from_node(cfg, n)
                old = conn.execute("SELECT fulfillment, notified_at, fulfilled_seen_at FROM shopify_orders WHERE id=?", (r['id'],)).fetchone()
                is_new = old is None and not first and r['created_at'] >= connected_at.replace('+00:00', 'Z')[:19]
                fseen = (old['fulfilled_seen_at'] if old else None)
                if r['fulfillment'] in DONE_FULFILL and not fseen:
                    # première lecture : la date de traitement est inconnue, on prend la dernière modification de la commande
                    upd = _local(r['updated_at'])
                    fseen = stamp if not first else (upd.strftime('%Y-%m-%d %H:%M:%S') if upd else stamp)
                cols = list(r.keys())
                if old is None:
                    conn.execute(f"INSERT INTO shopify_orders({', '.join(cols)}, first_seen_at, notified_at, fulfilled_seen_at) "
                                 f"VALUES ({', '.join('?' * len(cols))}, ?, ?, ?)",
                                 [r[c] for c in cols] + [stamp, None if is_new else stamp, fseen])
                else:
                    conn.execute(f"UPDATE shopify_orders SET {', '.join(c + '=?' for c in cols if c != 'id')}, fulfilled_seen_at=? WHERE id=?",
                                 [r[c] for c in cols if c != 'id'] + [fseen, r['id']])
                if is_new and not r['cancelled_at'] and _wanted(cfg, r['name']):
                    new_orders.append(r)
            conn.commit()
        finally:
            conn.close()
        _set_state(last_sync_utc=now_utc.isoformat(), last_sync=stamp, last_error=None, initial_done=True, connected_at=connected_at,
                   last_count=len(nodes))
    sent = 0
    if new_orders and notify and cfg['notify_new']:
        sent = _notify_new(cfg, new_orders)
    return {'ok': True, 'read': len(nodes), 'new': len(new_orders), 'emails': sent, 'initial': first}


def _send_all(cfg, subject, text, html):
    to = _emails(cfg['emails'])
    for addr in to:
        try:
            send_email(addr, subject, text, None, mode='send', bcc_company=False, category='Boutique en ligne', html=html)
        except Exception:
            traceback.print_exc()
    return len(to)


def _money(v, cur='CAD'):
    return f"{v:,.2f}".replace(',', ' ').replace('.', ',') + (' $' if cur in ('CAD', 'USD') else f' {cur}')


def _items_text(r, limit=6):
    try:
        items = json.loads(r['items'] or '[]')
    except ValueError:
        items = []
    txt = [f"{i['q']} × {i['t']}" for i in items[:limit]]
    if len(items) > limit:
        txt.append(f"+ {len(items) - limit} autre(s) article(s)")
    return txt


def _todo_reason(r):
    why = []
    if r['fulfillment'] not in DONE_FULFILL:
        why.append(FULFILL_LABELS.get(r['fulfillment'], r['fulfillment'] or 'Non traitée'))
    if r['financial'] in PAY_TODO:
        why.append(FINANCE_LABELS.get(r['financial'], r['financial']))
    return ' · '.join(why)


def _email_shell(title, color, intro, body):
    return (f"<!doctype html><html><body style=\"margin:0;background:#f1f5f9;font-family:Segoe UI,Arial,sans-serif;color:#1f2937\">"
            f"<div style=\"max-width:720px;margin:0 auto;padding:20px\"><div style=\"background:#fff;border-radius:12px;overflow:hidden;border:1px solid #e2e8f0\">"
            f"<div style=\"background:{color};color:#fff;padding:16px 22px\"><div style=\"font-size:12px;opacity:.85\">{escape(get_company_name())} — Boutique en ligne</div>"
            f"<div style=\"font-size:20px;font-weight:700;margin-top:2px\">{escape(title)}</div></div>"
            f"<div style=\"padding:18px 22px\"><p style=\"margin:0 0 14px;font-size:14px\">{intro}</p>{body}</div></div>"
            f"<p style=\"font-size:11px;color:#94a3b8;text-align:center;margin:12px 0 0\">Courriel envoyé automatiquement par Kubios à partir des commandes Shopify.</p>"
            f"</div></body></html>")


def _order_card(r):
    d = _local(r['created_at'])
    items = ''.join(f"<li>{escape(t)}</li>" for t in _items_text(r, 10))
    who = escape(r['customer'] or r['email'] or 'Client')
    extra = ' · '.join(escape(x) for x in (r['email'] if r['customer'] else '', r['phone'], r['ship_city'], r['shipping']) if x)
    return (f"<div style=\"border:1px solid #e2e8f0;border-radius:10px;padding:12px 14px;margin:0 0 10px\">"
            f"<div style=\"display:flex;justify-content:space-between\"><b style=\"font-size:16px\">{escape(r['name'])}</b>"
            f"<b style=\"font-size:16px\">{_money(r['total'], r['currency'])}</b></div>"
            f"<div style=\"font-size:13px;color:#475569;margin-top:2px\">{who}{' — ' + extra if extra else ''}</div>"
            f"<div style=\"font-size:12px;color:#64748b;margin-top:2px\">{d.strftime('%d-%m-%Y à %H:%M') if d else ''} · "
            f"{escape(FINANCE_LABELS.get(r['financial'], r['financial']))} · {escape(FULFILL_LABELS.get(r['fulfillment'], r['fulfillment']))}</div>"
            f"<ul style=\"margin:8px 0 6px;padding-left:18px;font-size:13px\">{items}</ul>"
            + (f"<div style=\"font-size:12px;background:#fffbeb;border-radius:6px;padding:6px 8px;margin-bottom:6px\">Note du client : {escape(r['note'])}</div>" if r['note'] else '')
            + f"<a href=\"{escape(r['admin_url'])}\" style=\"display:inline-block;background:#2563eb;color:#fff;text-decoration:none;padding:7px 14px;"
              f"border-radius:6px;font-size:13px;font-weight:600\">Ouvrir dans Shopify</a></div>")


def _notify_new(cfg, orders):
    orders = sorted(orders, key=lambda r: r['created_at'])
    total = sum(r['total'] for r in orders)
    one = len(orders) == 1
    subject = (f"Nouvelle commande {orders[0]['name']} — {_money(orders[0]['total'], orders[0]['currency'])}" if one
               else f"{len(orders)} nouvelles commandes en ligne — {_money(total)}")
    text = '\n\n'.join(f"{r['name']} — {_money(r['total'], r['currency'])} — {r['customer'] or r['email']}\n" + '\n'.join(_items_text(r))
                       + f"\n{r['admin_url']}" for r in orders)
    html = _email_shell('Nouvelle commande' if one else f'{len(orders)} nouvelles commandes', '#16a34a',
                        'Une nouvelle commande vient d\'être reçue sur la boutique en ligne.' if one else
                        f'{len(orders)} nouvelles commandes viennent d\'être reçues sur la boutique en ligne.',
                        ''.join(_order_card(r) for r in orders))
    n = _send_all(cfg, f"[Boutique] {subject}", text, html)
    conn = get_conn()
    try:
        stamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        conn.executemany("UPDATE shopify_orders SET notified_at=? WHERE id=?", [(stamp, r['id']) for r in orders])
        conn.commit()
    finally:
        conn.close()
    return n


# ---------------------------------------------------------------- résumé quotidien et listes

def _orders(view='suivre', q='', day=None):
    day = day or datetime.date.today()
    cfg = shopify_cfg()
    conn = get_conn()
    try:
        rows = [dict(r) for r in conn.execute("SELECT * FROM shopify_orders ORDER BY created_at DESC LIMIT 3000").fetchall()]
    finally:
        conn.close()
    rows = [r for r in rows if _wanted(cfg, r['name'])]
    for r in rows:
        d = _local(r['created_at'])
        r['local'] = d.strftime('%Y-%m-%d %H:%M') if d else ''
        r['day'] = d.date().isoformat() if d else ''
        r['age_days'] = (day - d.date()).days if d else 0
        r['fulfillment_label'] = FULFILL_LABELS.get(r['fulfillment'], r['fulfillment'])
        r['financial_label'] = FINANCE_LABELS.get(r['financial'], r['financial'])
        r['todo'] = (not r['cancelled_at']) and (r['fulfillment'] not in DONE_FULFILL or r['financial'] in PAY_TODO)
        r['reason'] = _todo_reason(r) if r['todo'] else ''
        r['done_today'] = bool(r['fulfilled_seen_at'] and r['fulfilled_seen_at'][:10] == day.isoformat()) and not r['cancelled_at']
        r['items_list'] = _items_text(r, 40)
    iso = day.isoformat()
    if view == 'suivre':
        rows = sorted([r for r in rows if r['todo']], key=lambda r: r['created_at'])
    elif view == 'jour':
        rows = [r for r in rows if r['day'] == iso or r['done_today']]
    elif view == 'semaine':
        rows = [r for r in rows if r['day'] >= (day - datetime.timedelta(days=6)).isoformat()]
    if q:
        words = q.lower().split()
        rows = [r for r in rows if all(w in ' '.join(str(r.get(k) or '') for k in ('name', 'customer', 'email', 'items', 'tags', 'note')).lower()
                                       for w in words)]
    return rows


def _dm(local):
    return f"{local[8:10]}-{local[5:7]}" if local else ''


def shopify_summary_html(day=None):
    day = day or datetime.date.today()
    rows = _orders('toutes', day=day)
    recues = [r for r in rows if r['day'] == day.isoformat() and not r['cancelled_at']]
    annulees = [r for r in rows if r['day'] == day.isoformat() and r['cancelled_at']]
    completees = [r for r in rows if r['done_today']]
    suivre = sorted([r for r in rows if r['todo']], key=lambda r: r['created_at'])
    tot = sum(r['total'] for r in recues)

    def tile(n, label, color):
        return (f"<td style=\"width:33%;padding:4px\"><div style=\"background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:10px 12px\">"
                f"<div style=\"font-size:22px;font-weight:700;color:{color}\">{n}</div><div style=\"font-size:12px;color:#64748b\">{label}</div></div></td>")

    def table(title, lst, cols, empty):
        h = f"<h3 style=\"font-size:15px;margin:18px 0 6px;color:#1e3a8a\">{escape(title)} ({len(lst)})</h3>"
        if not lst:
            return h + f"<p style=\"font-size:13px;color:#64748b;margin:0\">{escape(empty)}</p>"
        h += "<table style=\"width:100%;border-collapse:collapse;font-size:13px\"><tr>" + ''.join(
            f"<th style=\"text-align:{'right' if c[0] == 'total' else 'left'};background:#f1f5f9;padding:6px 8px;font-size:11px;color:#475569\">{c[1]}</th>" for c in cols) + "</tr>"
        for r in lst:
            h += "<tr>" + ''.join(f"<td style=\"padding:6px 8px;border-bottom:1px solid #eef2f7;vertical-align:top;text-align:{'right' if c[0] == 'total' else 'left'};"
                                  f"{'white-space:nowrap;' if c[0] in ('total', 'name', 'd', 'h') else ''}\">{c[2](r)}</td>"
                                  for c in cols) + "</tr>"
        return h + "</table>"
    link = lambda r: f"<a href=\"{escape(r['admin_url'])}\" style=\"color:#2563eb;font-weight:700;text-decoration:none\">{escape(r['name'])}</a>"
    who = lambda r: escape(r['customer'] or r['email'] or '—') + (f"<div style=\"color:#64748b;font-size:12px\">{escape('; '.join(r['items_list'][:3]))}</div>" if r['items_list'] else '')
    money = lambda r: _money(r['total'], r['currency'])
    body = f"<table style=\"width:100%;border-collapse:collapse\"><tr>{tile(len(recues), 'reçues aujourd’hui — ' + _money(tot), '#16a34a')}" \
           f"{tile(len(completees), 'complétées aujourd’hui', '#2563eb')}{tile(len(suivre), 'à suivre', '#d97706' if suivre else '#16a34a')}</tr></table>"
    body += table('Commandes reçues aujourd’hui', recues, [('name', 'Commande', link), ('h', 'Heure', lambda r: r['local'][11:16]), ('c', 'Client et articles', who),
                                                           ('s', 'Statut', lambda r: escape(r['financial_label'] + ' · ' + r['fulfillment_label'])), ('total', 'Total', money)],
                  "Aucune commande reçue aujourd'hui.")
    body += table('À suivre', suivre, [('name', 'Commande', link), ('d', 'Reçue', lambda r: _dm(r['local']) + (f"<div style=\"color:#b45309;font-size:12px\">depuis {r['age_days']} j</div>" if r['age_days'] >= 2 else '')),
                                        ('c', 'Client et articles', who), ('s', 'À faire', lambda r: f"<b style=\"color:#b45309\">{escape(r['reason'])}</b>"), ('total', 'Total', money)],
                  'Aucune commande en attente : tout est traité.')
    body += table('Complétées aujourd’hui', completees, [('name', 'Commande', link), ('d', 'Reçue le', lambda r: _dm(r['local'])), ('c', 'Client et articles', who), ('total', 'Total', money)],
                  "Aucune commande complétée aujourd'hui.")
    if annulees:
        body += table('Annulées aujourd’hui', annulees, [('name', 'Commande', link), ('c', 'Client', who), ('total', 'Total', money)], '')
    text = (f"Résumé de la boutique en ligne — {day.strftime('%d-%m-%Y')}\nReçues : {len(recues)} ({_money(tot)}) · Complétées : {len(completees)} · "
            f"À suivre : {len(suivre)}\n\nÀ suivre :\n" + '\n'.join(f"- {r['name']} ({r['local'][:10]}) {r['customer'] or r['email']} — {r['reason']}" for r in suivre))
    html = _email_shell(f"Résumé du {day.strftime('%d-%m-%Y')}", '#1e3a8a',
                        'Voici le résumé de la journée de la boutique en ligne : commandes reçues, complétées et à suivre.', body)
    subject = f"[Boutique] Résumé du {day.strftime('%d-%m-%Y')} — {len(recues)} reçue(s), {len(suivre)} à suivre"
    return subject, text, html, {'recues': len(recues), 'completees': len(completees), 'suivre': len(suivre), 'total': round(tot, 2)}


def _send_summary(cfg, day=None):
    subject, text, html, counts = shopify_summary_html(day)
    n = _send_all(cfg, subject, text, html)
    _set_state(last_summary_day=(day or datetime.date.today()).isoformat(), last_summary_at=datetime.datetime.now().strftime('%Y-%m-%d %H:%M'))
    return n, counts


def shopify_tick(now=None):
    """Appelé chaque minute par la tâche de fond : lecture régulière et résumé à l'heure choisie."""
    cfg = shopify_cfg()
    if not cfg['enabled'] or not _configured(cfg):
        return None
    now = now or datetime.datetime.now()
    st = _state()
    last = st.get('last_sync_try')
    interval = max(2, min(60, int(cfg['interval_min'] or 5)))
    did = None
    if not last or (now - datetime.datetime.fromisoformat(last)).total_seconds() >= interval * 60 - 5:
        _set_state(last_sync_try=now.isoformat(timespec='seconds'))
        try:
            did = shopify_sync()
        except ShopifyError:
            pass
        except Exception:
            traceback.print_exc()
    if cfg['summary'] and _emails(cfg['emails']) and st.get('last_summary_day') != now.date().isoformat():
        try:
            hh, mm = (int(x) for x in (cfg['summary_time'] or '17:30').split(':'))
        except ValueError:
            hh, mm = 17, 30
        if (now.hour, now.minute) >= (hh, mm):
            try:
                if not did:
                    shopify_sync()                       # résumé à jour
            except Exception:
                pass
            _send_summary(cfg, now.date())
    return did


def _shopify_loop():
    time.sleep(45)
    while True:
        try:
            shopify_tick()
        except Exception:
            traceback.print_exc()
        time.sleep(60)


def start_shopify_monitor():
    threading.Thread(target=_shopify_loop, name='surveillance_shopify', daemon=True).start()


# ---------------------------------------------------------------- pages et API

@app.route('/boutique-en-ligne')
def shopify_page():
    resp = permission_required_check('shopify')
    if resp is not None:
        return resp
    return render_template('shopify.html', company=get_company_name(), is_admin=bool(session.get('is_admin')))


def _public_cfg(cfg):
    c = dict(cfg)
    c['client_secret_set'] = bool(c.pop('client_secret'))
    tok = c.pop('token')
    c['token_set'] = bool(tok)
    c['token_hint'] = (tok[:6] + '…' + tok[-4:]) if tok and len(tok) > 12 else ''
    return c


@app.route('/api/shopify/status')
def api_shopify_status():
    resp = permission_required_check('shopify')
    if resp is not None:
        return resp
    cfg = shopify_cfg()
    st = _state()
    rows = _orders('toutes')
    today = datetime.date.today().isoformat()
    out = {'configured': _configured(cfg), 'enabled': cfg['enabled'], 'shop': cfg['shop'], 'is_admin': bool(session.get('is_admin')),
           'last_sync': st.get('last_sync'), 'last_error': st.get('last_error'), 'last_error_at': st.get('last_error_at'),
           'last_summary_at': st.get('last_summary_at'), 'protected_ok': st.get('protected_ok', True),
           'counts': {'suivre': sum(1 for r in rows if r['todo']), 'jour': sum(1 for r in rows if r['day'] == today and not r['cancelled_at']),
                      'total_jour': round(sum(r['total'] for r in rows if r['day'] == today and not r['cancelled_at']), 2),
                      'completees': sum(1 for r in rows if r['done_today']), 'total': len(rows)},
           'recipients': len(_emails(cfg['emails'])), 'summary_time': cfg['summary_time'], 'notify_new': cfg['notify_new'], 'summary': cfg['summary'], 'prefix': cfg['prefix']}
    if session.get('is_admin'):
        out['config'] = _public_cfg(cfg)
    return jsonify(out)


@app.route('/api/shopify/orders')
def api_shopify_orders():
    resp = permission_required_check('shopify')
    if resp is not None:
        return resp
    view = request.args.get('vue') if request.args.get('vue') in ('suivre', 'jour', 'semaine', 'toutes') else 'suivre'
    rows = _orders(view, (request.args.get('q') or '').strip()[:100])
    keep = ('id', 'name', 'local', 'age_days', 'customer', 'email', 'phone', 'ship_city', 'shipping', 'total', 'currency', 'financial_label',
            'fulfillment_label', 'todo', 'reason', 'done_today', 'items_list', 'note', 'tags', 'admin_url', 'cancelled_at')
    return jsonify({'orders': [{k: r.get(k) for k in keep} for r in rows[:500]], 'count': len(rows)})


@app.route('/api/shopify/config', methods=['POST'])
def api_shopify_config():
    resp = admin_required_check()
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    cfg = shopify_cfg()
    old_key = (cfg['shop'], cfg['auth'], cfg['client_id'])
    if 'shop' in d:
        shop = _clean_shop(d.get('shop'))
        if d.get('shop') and not shop:
            return jsonify({'ok': False, 'error': "Adresse de boutique invalide : utilise l'adresse « ta-boutique.myshopify.com »."}), 400
        cfg['shop'] = shop
    if d.get('auth') in ('client', 'token'):
        cfg['auth'] = d['auth']
    for k in ('client_id',):
        if k in d:
            cfg[k] = str(d[k] or '').strip()[:200]
    if d.get('client_secret'):                          # vide = garder le secret enregistré
        cfg['client_secret'] = str(d['client_secret']).strip()[:300]
    if d.get('token'):
        cfg['token'] = str(d['token']).strip()[:300]
    if d.get('clear_secret'):
        cfg['client_secret'] = cfg['token'] = ''
    for k in ('enabled', 'notify_new', 'summary'):
        if k in d:
            cfg[k] = bool(d[k])
    if 'summary_time' in d:
        if not re.fullmatch(r'([01]?\d|2[0-3]):[0-5]\d', str(d['summary_time'] or '')):
            return jsonify({'ok': False, 'error': "Heure du résumé invalide."}), 400
        cfg['summary_time'] = '%02d:%s' % (int(d['summary_time'].split(':')[0]), d['summary_time'].split(':')[1])
    if 'emails' in d:
        bad = [e for e in re.split(r'[\s,;]+', str(d['emails'] or '')) if e and not _emails(e)]
        if bad:
            return jsonify({'ok': False, 'error': 'Courriel invalide : ' + ', '.join(bad[:3])}), 400
        cfg['emails'] = ', '.join(_emails(d['emails']))
    if 'prefix' in d:
        cfg['prefix'] = ', '.join(p.strip()[:20] for p in re.split(r'[,;]+', str(d['prefix'] or '')) if p.strip())[:100]
    if 'interval_min' in d:
        try:
            cfg['interval_min'] = max(2, min(60, int(d['interval_min'])))
        except (TypeError, ValueError):
            pass
    meta_set('shopify_cfg', json.dumps(cfg))
    if (cfg['shop'], cfg['auth'], cfg['client_id']) != old_key:
        _token_cache.clear()
        if old_key[0] and cfg['shop'] != old_key[0]:      # autre boutique : on repart à neuf
            conn = get_conn()
            conn.execute("DELETE FROM shopify_orders")
            conn.commit()
            conn.close()
            meta_set('shopify_state', '{}')
    log_audit('Boutique en ligne : réglages modifiés', f"{cfg['shop'] or '(aucune boutique)'} — "
              f"{'activée' if cfg['enabled'] else 'désactivée'}, {len(_emails(cfg['emails']))} destinataire(s)")
    return jsonify({'ok': True, 'config': _public_cfg(cfg)})


@app.route('/api/shopify/test', methods=['POST'])
def api_shopify_test():
    resp = admin_required_check()
    if resp is not None:
        return resp
    cfg = shopify_cfg()
    if not _configured(cfg):
        return jsonify({'ok': False, 'error': "Remplis l'adresse de la boutique et les identifiants, puis enregistre."}), 400
    try:
        _token_cache.clear()
        _set_state(protected_ok=True)                   # revérifier l'accès au nom et au courriel des clients
        d = _gql(cfg, "{ shop { name currencyCode } orders(first: 1) { nodes { name } } }")
        if d.get('errors'):
            msg = '; '.join(str(e.get('message')) for e in d['errors'])[:300]
            scope = (_token_cache.get((cfg['shop'], cfg['client_id'])) or {}).get('scope', '')
            if 'access denied' in msg.lower() and 'order' in msg.lower():
                msg = ("L'application n'a pas la permission de lire les commandes (read_orders). Dans le Dev Dashboard : coche read_orders et "
                       "read_customers, publie une nouvelle version, puis mets à jour l'installation sur la boutique (accepter les nouvelles "
                       "permissions)." + (f" Permissions actuelles du jeton : {scope}." if scope else " Le jeton n'a actuellement aucune permission."))
            else:
                msg = 'Shopify : ' + msg
            return jsonify({'ok': False, 'error': msg})
        shop = d['data']['shop']
        last = (d['data']['orders']['nodes'] or [{}])[0].get('name')
        scope = (_token_cache.get((cfg['shop'], cfg['client_id'])) or {}).get('scope', '')
    except ShopifyError as e:
        return jsonify({'ok': False, 'error': str(e)})
    log_audit('Boutique en ligne : connexion testée', f"{cfg['shop']} — OK")
    return jsonify({'ok': True, 'shop': shop.get('name'), 'currency': shop.get('currencyCode'), 'last_order': last, 'scope': scope})


@app.route('/api/shopify/sync', methods=['POST'])
def api_shopify_sync():
    resp = permission_required_check('shopify')
    if resp is not None:
        return resp
    try:
        r = shopify_sync()
    except ShopifyError as e:
        return jsonify({'ok': False, 'error': str(e)})
    return jsonify(r)


@app.route('/api/shopify/summary', methods=['POST'])
def api_shopify_summary():
    resp = permission_required_check('shopify')
    if resp is not None:
        return resp
    cfg = shopify_cfg()
    d = request.get_json(silent=True) or {}
    if d.get('preview'):
        subject, _t, html, counts = shopify_summary_html()
        return jsonify({'ok': True, 'subject': subject, 'html': html, 'counts': counts})
    if not _emails(cfg['emails']):
        return jsonify({'ok': False, 'error': "Aucun destinataire n'est enregistré (réglages, plus bas)."})
    try:
        if _configured(cfg):
            shopify_sync()
    except ShopifyError:
        pass
    n, counts = _send_summary(cfg)
    log_audit('Boutique en ligne : résumé envoyé', f"{n} destinataire(s)")
    return jsonify({'ok': True, 'sent': n, 'counts': counts})
