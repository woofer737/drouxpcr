# -*- coding: utf-8 -*-
"""
Vérification des codes de licence.

Ce module ne contient QUE la clé PUBLIQUE — il peut être livré sans risque avec
l'application chez n'importe quel client : elle permet de vérifier qu'un code de
licence a bien été signé par le générateur officiel, mais elle ne permet PAS de
créer de nouveaux codes. Seul le générateur de licences (gardé séparément, jamais
livré avec l'app) contient la clé privée qui signe les codes.

Format d'un code de licence :
    OE-LIC1-<payload_b64>.<signature_b64>

où <payload_b64> encode en base64 (urlsafe, sans padding) un JSON compact :
    {"id": "...", "licensee": "Nom du client", "type": "30d"|"1y"|"lifetime"|"date",
     "issued": "AAAA-MM-JJ", "expires": "AAAA-MM-JJ" ou null,
     "max_users": 5 ou null}

"max_users" (nombre maximum d'utilisateurs actifs) est absent des anciens codes :
absent ou null = utilisateurs illimités.

Version 2 (Kubios 1.38.0) — licence par modules :
    OE-LIC2-<payload_b64>.<signature_b64>
Même signature. Le payload garde les champs du noyau (type, expires, max_users…) et
ajoute "v": 2 et "modules" : {"atelier": {"type": "1y", "expires": "AAAA-MM-JJ"},
"rh": {"type": "lifetime", "expires": null}}. Un module absent n'est pas inclus.
Les anciens codes OE-LIC1- (émis avant les modules) donnent accès à tous les modules,
avec la même échéance que le noyau.
"""
import base64
import json

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature

CODE_PREFIX = "OE-LIC1-"
CODE_PREFIX_V2 = "OE-LIC2-"
PREFIXES = (CODE_PREFIX_V2, CODE_PREFIX)

# Modules vendus séparément du noyau.
MODULES = {
    'atelier': "Gestion Atelier",
    'rh': "Gestion RH",
}
CORE_LABEL = "Noyau — comptes à recevoir, comptes de crédit, rapports, utilisateurs"

# Clé publique Ed25519 (base64 urlsafe, sans padding) — correspond à la clé
# privée gardée uniquement dans le générateur de licences.
PUBLIC_KEY_B64 = "F0hAz8y9nPKkMsaLCKg_iM_-80-73fgjDR6GY4t18jw"

TYPE_LABELS = {
    '30d': "30 jours",
    '1y': "1 an",
    'lifetime': "À vie",
    'date': "Date précise",
}


def max_users_of(payload):
    """Nombre maximum d'utilisateurs actifs permis par la licence, ou None
    (illimité — aussi le cas des codes émis avant l'ajout de cette limite)."""
    value = (payload or {}).get('max_users')
    if isinstance(value, int) and not isinstance(value, bool) and value > 0:
        return value
    return None


def users_label(payload):
    n = max_users_of(payload)
    return "Illimité" if n is None else f"{n} utilisateur{'s' if n > 1 else ''}"


def _b64url_decode(s):
    padding = '=' * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + padding)


def _b64url_encode(b):
    return base64.urlsafe_b64encode(b).decode('ascii').rstrip('=')


def _get_public_key():
    raw = _b64url_decode(PUBLIC_KEY_B64)
    return Ed25519PublicKey.from_public_bytes(raw)


def verify_license_code(code):
    """Vérifie un code de licence. Retourne toujours un dict :
        {'ok': True, 'payload': {...}}
    ou
        {'ok': False, 'error': "message clair en français"}
    Ne fait AUCUNE vérification de date d'expiration ici — seulement la
    signature et le format. La date est vérifiée séparément par l'appelant."""
    if not code or not isinstance(code, str):
        return {'ok': False, 'error': "Aucun code de licence fourni."}
    code = ''.join(code.split())          # tolère les retours à la ligne d'un copier-coller
    prefix = next((p for p in PREFIXES if code.startswith(p)), None)
    if not prefix:
        return {'ok': False, 'error': "Format de code de licence invalide."}
    body = code[len(prefix):]
    if '.' not in body:
        return {'ok': False, 'error': "Format de code de licence invalide."}
    payload_b64, _, sig_b64 = body.partition('.')
    try:
        payload_bytes = _b64url_decode(payload_b64)
        signature = _b64url_decode(sig_b64)
    except Exception:
        return {'ok': False, 'error': "Code de licence illisible ou corrompu."}

    try:
        _get_public_key().verify(signature, payload_b64.encode('ascii'))
    except InvalidSignature:
        return {'ok': False, 'error': "Ce code de licence n'est pas valide (signature incorrecte)."}
    except Exception:
        return {'ok': False, 'error': "Code de licence illisible ou corrompu."}

    try:
        payload = json.loads(payload_bytes)
    except Exception:
        return {'ok': False, 'error': "Code de licence illisible ou corrompu."}

    if not isinstance(payload, dict) or 'licensee' not in payload or 'type' not in payload:
        return {'ok': False, 'error': "Code de licence illisible ou corrompu."}
    if prefix == CODE_PREFIX_V2 and not isinstance(payload.get('modules', {}), dict):
        return {'ok': False, 'error': "Code de licence illisible ou corrompu."}

    return {'ok': True, 'payload': payload}


def modules_status(payload, today):
    """État de chaque module pour une licence (payload déjà vérifié) à la date « today ».
    Retourne {cle: {'label', 'included', 'active', 'type', 'type_label', 'expires', 'days_left'}}."""
    import datetime
    payload = payload or {}
    out = {}
    v1 = 'modules' not in payload            # ancien code : tous les modules, échéance du noyau
    mods = payload.get('modules') or {}
    for key, label in MODULES.items():
        m = {'type': payload.get('type'), 'expires': payload.get('expires')} if v1 else mods.get(key)
        if not isinstance(m, dict):
            out[key] = {'label': label, 'included': False, 'active': False, 'type': None, 'type_label': '—', 'expires': None, 'days_left': None}
            continue
        exp, days, active = m.get('expires'), None, True
        if exp:
            try:
                days = (datetime.date.fromisoformat(exp) - today).days
                active = days >= 0
            except (ValueError, TypeError):
                active = False
        out[key] = {'label': label, 'included': True, 'active': active, 'type': m.get('type'),
                    'type_label': TYPE_LABELS.get(m.get('type'), m.get('type') or '—'), 'expires': exp, 'days_left': days,
                    'legacy': v1}
    return out
