# -*- coding: utf-8 -*-
"""Pages du module Système : utilisateurs, sessions, mises à jour, paramètres d'envoi, journaux, messages, entreprise, licence.
Module de Kubios (découpé de app.py en 1.46.0, code inchangé)."""
import os
import re
import io
import csv
import sys
import json
import base64
import hashlib
import unicodedata
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import openpyxl
from openpyxl.utils import get_column_letter
import licensing
from kubios_base import (
    AT_FMT, COMPANY_EMAIL_DEFAULT, COMPANY_NAME_DEFAULT, SETTINGS_DEFAULTS, _at_now, db_add_audit,
    get_company_email, get_company_name, get_conn, get_settings, meta_get, meta_set, set_settings,
)
from kubios_license import _clock_problem_message, get_license_status, get_trusted_today
from kubios_mail import _M365_TOKEN, m365_mailbox, send_via_m365, test_smtp_connection
from kubios_pdf import LOGO_PATH
from kubios_sessions import _SESS_REVOKED
from kubios_version import APP_NAME, APP_VERSION, CHANGELOG
from kubios_app import APP_DIR, BASE_DIR, app
from kubios_auth import (
    PERMISSION_KEYS, _dump_permissions, _parse_permissions, admin_required_check, current_display_name,
    log_audit, permission_required_check,
)

__all__ = ['ADMIN_SETTINGS_LOGO_EXTS', 'ADMIN_SETTINGS_LOGO_MAX_BYTES', 'ANN_COLORS', 'COMPANY_PHONE_DEFAULT', 'EMAIL_CLOSING_MESSAGE_DEFAULT', 'LOGIN_BG_CUSTOM_PREFIX', 'LOGIN_BG_DEFAULT_NAME', 'LOGIN_BG_EXTS', 'LOGIN_BG_MAX_BYTES', 'LOGIN_BG_MODES', 'LOGIN_VIDEO_EXTS', 'LOGIN_VIDEO_MAX_BYTES', 'LOGIN_VIDEO_PREFIX', 'LOGO_DEFAULT_BACKUP_PATH', 'PDF_FOOTER_MESSAGE_DEFAULT', 'SESS_ONLINE_SEC', 'THREE_FILES', 'THREE_VENDOR_DIR', 'THREE_VERSION', 'UPDATE_CHECK_URL', 'UPDATE_RUNNER_PATH', 'UPDATE_STAGING_DIR', 'UPDATE_UPLOAD_MAX', 'UPDATE_ZIP_PATH', 'VERSIONS_DIR', 'VERSIONS_KEEP', '_EMAIL_OK', '_UPDATE_RUNNER_SCRIPT', '_ann_payload', '_launch_update', '_login_bg_custom_file', '_login_video_file', '_read_package_info', '_real_python_exe', '_three_lock', '_three_state', '_version_tuple', 'activation_page', 'admin_settings_page', 'admin_users_page', 'ann_status', 'announcements_page', 'api_admin_security_user', 'api_admin_security_users', 'api_admin_three', 'api_audit', 'api_create_announcement', 'api_create_user', 'api_delete_user', 'api_email_log', 'api_get_admin_settings', 'api_get_email_settings', 'api_license_activate', 'api_license_status', 'api_license_warning_ack', 'api_list_announcements', 'api_list_users', 'api_login_bg_mode', 'api_login_video', 'api_reset_admin_logo', 'api_reset_login_bg', 'api_send_mode', 'api_sessions', 'api_sessions_revoke', 'api_set_admin_settings', 'api_set_email_settings', 'api_test_email_settings', 'api_update_announcement', 'api_update_user', 'api_updates', 'api_updates_check', 'api_updates_install', 'api_updates_rollback', 'api_updates_upload', 'api_updates_upload_install', 'api_updates_versions', 'api_upload_admin_logo', 'api_upload_login_bg', 'db_count_active_users', 'db_create_user', 'db_delete_user', 'db_get_user', 'db_get_user_by_username', 'db_list_announcements', 'db_list_audit', 'db_list_users', 'db_set_user_mfa', 'db_update_user', 'db_user_security', 'download_three_vendor', 'email_log_page', 'email_settings_page', 'get_company_phone', 'get_email_closing_message', 'get_pdf_footer_message', 'get_public_settings', 'license_user_limit_error', 'login_bg_mode', 'login_bg_url', 'login_video_url', 'sess_list', 'sessions_page', 'three_local_ready', 'updates_page', 'versions_list']


COMPANY_PHONE_DEFAULT = ""  # optionnel, à remplir


PDF_FOOTER_MESSAGE_DEFAULT = "Merci de votre confiance."


EMAIL_CLOSING_MESSAGE_DEFAULT = "Merci de votre attention."


LOGO_DEFAULT_BACKUP_PATH = Path(__file__).resolve().parent / "static" / "logo_default.png"


LOGIN_BG_DEFAULT_NAME = "login_bg_default.svg"


LOGIN_BG_CUSTOM_PREFIX = "login_bg_custom"


LOGIN_BG_EXTS = ('.jpg', '.jpeg', '.png', '.webp')


LOGIN_BG_MAX_BYTES = 8 * 1024 * 1024  # 8 Mo


LOGIN_VIDEO_PREFIX = "login_video_custom"          # 1.32.0 : vidéo de fond de la page de connexion


LOGIN_VIDEO_EXTS = ('.mp4', '.webm')


LOGIN_VIDEO_MAX_BYTES = 80 * 1024 * 1024           # 80 Mo


LOGIN_BG_MODES = ('mosaique', 'image', 'video')


def get_company_phone():
    return (meta_get('company_phone') or COMPANY_PHONE_DEFAULT).strip()


def get_pdf_footer_message():
    return (meta_get('pdf_footer_message') or PDF_FOOTER_MESSAGE_DEFAULT).strip() or PDF_FOOTER_MESSAGE_DEFAULT


def get_email_closing_message():
    msg = meta_get('email_closing_message')
    return msg if msg is not None and msg.strip() else EMAIL_CLOSING_MESSAGE_DEFAULT


UPDATE_CHECK_URL = "https://raw.githubusercontent.com/woofer737/drouxpcr/main/version.json"


UPDATE_STAGING_DIR = BASE_DIR / "_update_staging"


UPDATE_ZIP_PATH = BASE_DIR / "_update_download.zip"


UPDATE_RUNNER_PATH = BASE_DIR / "_run_update.py"


def _real_python_exe():
    """Chemin fiable vers python.exe.

    Quand ce code tourne DANS le service Windows, sys.executable pointe vers
    pythonservice.exe (l'hôte du service, pas un vrai interpréteur Python) —
    lancer un sous-processus avec ce chemin échoue silencieusement. sys.exec_prefix
    reste correct dans les deux cas (service ou lancement normal), donc on
    reconstruit le chemin de python.exe à partir de là, avec repli sur
    sys.executable si jamais il n'existe pas à cet endroit.
    """
    candidate = os.path.join(sys.exec_prefix, "python.exe" if os.name == "nt" else "python3")
    if os.path.exists(candidate):
        return candidate
    return sys.executable


_UPDATE_RUNNER_SCRIPT = r'''
import os, sys, shutil, subprocess, time

STAGED = r"{staged}"
TARGET = r"{target}"
BASE = r"{base}"
LOG_PATH = os.path.join(BASE, "_update_log.txt")

def log(msg):
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(time.strftime("%Y-%m-%d %H:%M:%S") + " - " + msg + "\n")

def real_python_exe():
    # Ce runner peut avoir ete lance via pythonservice.exe (sys.executable
    # errone dans ce cas) : on reconstruit le vrai python.exe a partir de
    # sys.exec_prefix, qui lui reste correct.
    candidate = os.path.join(sys.exec_prefix, "python.exe" if os.name == "nt" else "python3")
    if os.path.exists(candidate):
        return candidate
    return sys.executable

PYTHON_EXE = real_python_exe()
log("Python utilise pour la mise a jour : " + PYTHON_EXE)

EXCLUDE_NAMES = {{"__pycache__", ".venv"}}
EXCLUDE_FILES = {{"data.db", "service.log"}}
EXCLUDE_EXT = (".xlsx", ".db")

def copy_tree(src, dst):
    for name in os.listdir(src):
        if name in EXCLUDE_NAMES:
            continue
        s = os.path.join(src, name)
        d = os.path.join(dst, name)
        if os.path.isdir(s):
            os.makedirs(d, exist_ok=True)
            copy_tree(s, d)
        else:
            if name in EXCLUDE_FILES or name.lower().endswith(EXCLUDE_EXT):
                continue
            shutil.copy2(s, d)

log("=== Debut de la mise a jour ===")
# Laisse le temps au processus precedent de bien se terminer et de liberer
# le port / les fichiers.
time.sleep(4)

try:
    copy_tree(STAGED, TARGET)
    log("Fichiers copies avec succes depuis " + STAGED)
except Exception as e:
    log("ERREUR copie fichiers: " + repr(e))

try:
    req = os.path.join(TARGET, "requirements.txt")
    if os.path.exists(req):
        r = subprocess.run([PYTHON_EXE, "-m", "pip", "install", "-r", req],
                            capture_output=True, text=True, timeout=180)
        log("pip install rc=" + str(r.returncode))
        if r.returncode != 0:
            log("pip stderr: " + r.stdout[-1000:] + r.stderr[-1000:])
except Exception as e:
    log("ERREUR pip install: " + repr(e))

# Redemarre selon le mode choisi explicitement par la personne au moment de
# cliquer "Installer maintenant" (service Windows ou start.bat) — plus fiable
# qu'une detection automatique, puisque le meme code tourne dans les deux
# types d'environnement chez ce client.
RESTART_MODE = "{restart_mode}"
restarted = False
service_py = os.path.join(TARGET, "service.py")

def restart_via_service():
    global restarted
    try:
        check = subprocess.run(["sc", "query", "ComptesARecevoirOE"],
                                capture_output=True, text=True, timeout=15)
        if check.returncode == 0 and "ComptesARecevoirOE" in check.stdout:
            subprocess.run([PYTHON_EXE, service_py, "restart"], timeout=30)
            log("Service Windows redemarre.")
            restarted = True
        else:
            log("Mode service demande, mais aucun service ComptesARecevoirOE trouve sur cette machine.")
    except Exception as e:
        log("ERREUR redemarrage service: " + repr(e))

def restart_via_startbat():
    global restarted
    try:
        start_bat = os.path.join(TARGET, "start.bat")
        if os.path.exists(start_bat):
            subprocess.Popen(["cmd", "/c", "start", "", "start.bat"],
                              cwd=TARGET, creationflags=subprocess.CREATE_NEW_CONSOLE)
            log("start.bat relance dans une nouvelle fenetre.")
            restarted = True
        else:
            log("Mode start.bat demande, mais start.bat introuvable dans " + TARGET)
    except Exception as e:
        log("ERREUR relance start.bat: " + repr(e))

log("Mode de redemarrage demande : " + RESTART_MODE)
if RESTART_MODE == "service":
    restart_via_service()
else:
    restart_via_startbat()

# Filet de securite : si le mode choisi echoue, on essaie quand meme l'autre
# methode plutot que de laisser l'application eteinte.
if not restarted:
    log("Le mode demande a echoue, tentative de l'autre methode en secours.")
    if RESTART_MODE == "service":
        restart_via_startbat()
    else:
        restart_via_service()

log("=== Mise a jour terminee ===")
'''


SESS_ONLINE_SEC = 300           # « en ligne » = activité dans les 5 dernières minutes


def db_list_users():
    conn = get_conn()
    rows = conn.execute(
        "SELECT id, username, full_name, is_admin, active, created_at, permissions, email, mfa_required, mfa_method "
        "FROM users ORDER BY username COLLATE NOCASE"
    ).fetchall()
    conn.close()
    out = []
    for r in rows:
        d = dict(r)
        d['permissions'] = _parse_permissions(d.get('permissions'))
        out.append(d)
    return out


def db_get_user_by_username(username):
    conn = get_conn()
    row = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    d['permissions'] = _parse_permissions(d.get('permissions'))
    return d


def db_get_user(user_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    d['permissions'] = _parse_permissions(d.get('permissions'))
    return d


def db_create_user(username, password, is_admin=False, permissions=None):
    username = (username or '').strip()
    if not username:
        raise ValueError("Nom d'utilisateur requis.")
    if not password or len(password) < 4:
        raise ValueError("Mot de passe trop court (minimum 4 caractères).")
    conn = get_conn()
    try:
        conn.execute(
            "INSERT INTO users(username, password_hash, is_admin, active, created_at, permissions) "
            "VALUES (?,?,?,1,?,?)",
            (username, generate_password_hash(password), 1 if is_admin else 0,
             datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
             _dump_permissions(permissions)),
        )
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        raise ValueError("Ce nom d'utilisateur existe déjà.")
    conn.close()


def db_update_user(user_id, is_admin=None, active=None, new_password=None, permissions=None):
    conn = get_conn()
    if is_admin is not None:
        conn.execute("UPDATE users SET is_admin=? WHERE id=?", (1 if is_admin else 0, user_id))
    if active is not None:
        conn.execute("UPDATE users SET active=? WHERE id=?", (1 if active else 0, user_id))
    if new_password:
        if len(new_password) < 4:
            conn.close()
            raise ValueError("Mot de passe trop court (minimum 4 caractères).")
        conn.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new_password), user_id))
    if permissions is not None:
        conn.execute("UPDATE users SET permissions=? WHERE id=?", (_dump_permissions(permissions), user_id))
    conn.commit()
    conn.close()


def db_delete_user(user_id):
    conn = get_conn()
    conn.execute("DELETE FROM users WHERE id=?", (user_id,))
    conn.commit()
    conn.close()


def db_count_active_users():
    conn = get_conn()
    n = conn.execute("SELECT COUNT(*) FROM users WHERE active=1").fetchone()[0]
    conn.close()
    return n


def license_user_limit_error(adding=1):
    """Retourne un message d'erreur si ajouter `adding` utilisateur(s) actif(s)
    dépasserait la limite d'utilisateurs de la licence, sinon None."""
    status = get_license_status()
    limit = licensing.max_users_of(status.get('payload'))
    if limit is None:
        return None
    active = db_count_active_users()
    if active + adding > limit:
        return (f"Limite de la licence atteinte : {limit} utilisateur(s) actif(s) permis "
                f"({active} actuellement). Désactive un compte ou demande une licence "
                f"avec plus d'utilisateurs.")
    return None


def db_list_audit(limit=1000):
    conn = get_conn()
    rows = conn.execute(
        "SELECT ts, username, action, details FROM audit_log ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_public_settings():
    """Ce qu'un utilisateur non-admin a besoin de savoir (jamais les identifiants SMTP)."""
    return {'send_mode': meta_get('send_mode', SETTINGS_DEFAULTS['send_mode'])}


def db_user_security(user_id):
    conn = get_conn()
    r = conn.execute("SELECT id, username, full_name, email, active, is_admin, permissions, mfa_required, mfa_method, "
                     "mfa_secret, mfa_last_step, mfa_pending_secret FROM users WHERE id=?", (user_id,)).fetchone()
    conn.close()
    return dict(r) if r else None


def db_set_user_mfa(user_id, **fields):
    allowed = {'mfa_required', 'mfa_method', 'mfa_secret', 'mfa_last_step', 'mfa_pending_secret', 'email', 'full_name'}
    sets = [(k, v) for k, v in fields.items() if k in allowed]
    if not sets:
        return
    conn = get_conn()
    conn.execute("UPDATE users SET " + ", ".join(f"{k}=?" for k, _ in sets) + " WHERE id=?",
                 [v for _, v in sets] + [user_id])
    conn.commit()
    conn.close()


ANN_COLORS = {
    'red': ('#fef2f2', '#991b1b', '#fca5a5', '⚠'),
    'yellow': ('#fffbeb', '#854d0e', '#fcd34d', '⚠'),
    'blue': ('#eff6ff', '#1e40af', '#93c5fd', 'ℹ'),
}


def ann_status(a, today=None):
    today = today or datetime.date.today().isoformat()
    if not a['active']:
        return 'desactive'
    if a['start_date'] and today < a['start_date']:
        return 'programme'
    if a['end_date'] and today > a['end_date']:
        return 'expire'
    return 'actif'


def db_list_announcements():
    conn = get_conn()
    rows = [dict(r) for r in conn.execute("SELECT * FROM announcements ORDER BY id DESC").fetchall()]
    conn.close()
    for r in rows:
        r['status'] = ann_status(r)
    return rows


THREE_VERSION = '0.147.0'


THREE_VENDOR_DIR = APP_DIR / 'static' / 'vendor'


THREE_FILES = (
    (f'three-{THREE_VERSION}.min.js', f'https://cdn.jsdelivr.net/npm/three@{THREE_VERSION}/build/three.min.js',
     ('WebGLRenderer', 'REVISION')),
    (f'OrbitControls-{THREE_VERSION}.js', f'https://cdn.jsdelivr.net/npm/three@{THREE_VERSION}/examples/js/controls/OrbitControls.js',
     ('THREE.OrbitControls',)),
)


_three_lock = threading.Lock()


_three_state = {'running': False, 'error': None, 'at': None}


def three_local_ready():
    for name, _url, marks in THREE_FILES:
        p = THREE_VENDOR_DIR / name
        if not p.exists() or p.stat().st_size < 1000:
            return False
    return True


def download_three_vendor():
    """Télécharge et vérifie les deux fichiers ; retourne (ok, message)."""
    if not _three_lock.acquire(blocking=False):
        return False, "Un téléchargement est déjà en cours."
    _three_state.update(running=True, error=None)
    try:
        THREE_VENDOR_DIR.mkdir(parents=True, exist_ok=True)
        for name, url, marks in THREE_FILES:
            req = urllib.request.Request(url, headers={'User-Agent': f'Kubios/{APP_VERSION}'})
            with urllib.request.urlopen(req, timeout=60) as r:
                data = r.read()
            text = data[:200000].decode('utf-8', errors='ignore') + data[-200000:].decode('utf-8', errors='ignore')
            if len(data) < 1000 or not all(m in text for m in marks):
                raise RuntimeError(f"Le fichier reçu pour {name} ne semble pas être three.js {THREE_VERSION}.")
            tmp = THREE_VENDOR_DIR / (name + '.tmp')
            tmp.write_bytes(data)
            os.replace(tmp, THREE_VENDOR_DIR / name)
        _three_state['at'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
        db_add_audit('Kubios', 'three.js installé localement', f"version {THREE_VERSION}")
        return True, f"three.js {THREE_VERSION} est installé dans Kubios."
    except urllib.error.URLError as e:
        msg = ("Kubios n'a pas accès à Internet pour le moment ; il réessaiera au prochain démarrage ou à la prochaine "
               f"ouverture du tableau de bord 3D. ({getattr(e, 'reason', e)})")
        _three_state['error'] = msg
        return False, msg
    except Exception as e:
        msg = f"Téléchargement impossible : {e}"
        _three_state['error'] = msg
        return False, msg
    finally:
        _three_state['running'] = False
        _three_lock.release()


@app.route('/activation')
def activation_page():
    status = get_license_status()
    if status['active']:
        # Licence valide : cette page devient une vue/renouvellement volontaire,
        # réservée à un administrateur ou à un utilisateur ayant la permission
        # "license", déjà connecté.
        if not (session.get('is_admin') or 'license' in (session.get('permissions') or [])):
            return redirect(url_for('index'))
    return render_template('activation.html', company=get_company_name(), status=status,
                            type_labels=licensing.TYPE_LABELS,
                            users_label=licensing.users_label(status.get('payload')),
                            max_users=licensing.max_users_of(status.get('payload')),
                            active_users=db_count_active_users(), core_label=licensing.CORE_LABEL,
                            modules=status.get('modules') or {}, module_names=licensing.MODULES,
                            locked=licensing.MODULES.get(request.args.get('module') or ''),
                            logged_in=bool(session.get('user_id')), app_name=APP_NAME, year=datetime.date.today().year,
                            bg_url=login_bg_url(), bg_mode=login_bg_mode(), video_url=login_video_url())


@app.route('/api/license/status')
def api_license_status():
    return jsonify(get_license_status())


@app.route('/api/license/activate', methods=['POST'])
def api_license_activate():
    data = request.json or {}
    code = (data.get('code') or '').strip()
    result = licensing.verify_license_code(code)
    if not result['ok']:
        return jsonify({'ok': False, 'error': result['error']}), 400

    payload = result['payload']
    expires = payload.get('expires')
    if expires:
        try:
            exp_date = datetime.date.fromisoformat(expires)
        except Exception:
            return jsonify({'ok': False, 'error': "Date d'expiration illisible dans ce code."}), 400
        today, clock_ok, local = get_trusted_today()
        if not clock_ok:
            return jsonify({'ok': False, 'error': _clock_problem_message(today, local)}), 400
        if exp_date < today:
            return jsonify({'ok': False, 'error':
                             f"Ce code de licence a expiré le {expires}. Demande un nouveau code."}), 400

    code = ''.join(code.split())
    meta_set('license_code', code)
    label = licensing.TYPE_LABELS.get(payload['type'], payload['type'])
    mods = licensing.modules_status(payload, get_trusted_today()[0])
    mods_txt = ', '.join(f"{m['label']} : " + (('à vie' if not m['expires'] else f"jusqu'au {m['expires']}") if m['included'] else 'non inclus')
                         for m in mods.values())
    username = session.get('username') or 'N/A (avant connexion)'
    db_add_audit(username, 'Licence activée',
                 f"{payload['licensee']} — {label}" +
                 (f" — expire le {expires}" if expires else " — à vie") +
                 f" — utilisateurs : {licensing.users_label(payload)} — {mods_txt}")
    return jsonify({'ok': True, 'payload': payload, 'type_label': label, 'modules': mods,
                    'users_label': licensing.users_label(payload)})


@app.route('/api/admin/security/users')
def api_admin_security_users():
    resp = admin_required_check()
    if resp is not None:
        return resp
    conn = get_conn()
    rows = [dict(r) for r in conn.execute("SELECT id, username, email, is_admin, active, mfa_required, mfa_method "
                                          "FROM users ORDER BY username COLLATE NOCASE").fetchall()]
    conn.close()
    return jsonify(rows)


_EMAIL_OK = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')


@app.route('/api/admin/security/users/<int:user_id>', methods=['POST'])
def api_admin_security_user(user_id):
    resp = admin_required_check()
    if resp is not None:
        return resp
    u = db_user_security(user_id)
    if u is None:
        return jsonify({'ok': False, 'error': 'Utilisateur introuvable.'}), 404
    data = request.get_json(silent=True) or {}
    if data.get('reset_mfa'):
        db_set_user_mfa(user_id, mfa_method=None, mfa_secret=None, mfa_pending_secret=None, mfa_last_step=0)
        conn = get_conn()
        conn.execute("DELETE FROM mfa_challenges WHERE user_id=?", (user_id,))
        conn.commit()
        conn.close()
        log_audit('2FA réinitialisée par un administrateur', u['username'])
        return jsonify({'ok': True})
    email = (data.get('email') or '').strip() or None
    if email and not _EMAIL_OK.match(email):
        return jsonify({'ok': False, 'error': f"Adresse invalide : {email}"}), 400
    req = 1 if data.get('mfa_required') else 0
    full_name = (data.get('full_name') or '').strip()[:80] or None
    db_set_user_mfa(user_id, email=email, mfa_required=req, full_name=full_name)
    if (u.get('full_name') or None) != full_name:
        log_audit('Nom complet modifié', f"{u['username']} — {full_name or 'aucun'}")
        if user_id == session.get('user_id'):
            session['full_name'] = full_name
    changes = []
    if (u.get('email') or None) != email:
        changes.append(f"courriel : {email or 'aucun'}")
    if bool(u.get('mfa_required')) != bool(req):
        changes.append("2FA " + ("obligatoire" if req else "non exigée"))
    if changes:
        log_audit('Sécurité du compte modifiée', f"{u['username']} — " + "; ".join(changes))
    return jsonify({'ok': True})


def _ann_payload(data):
    msg = (data.get('message') or '').strip()
    if not msg:
        raise ValueError("Écris le message à afficher.")
    if len(msg) > 600:
        raise ValueError("Le message est trop long (600 caractères au maximum).")
    color = data.get('color') if data.get('color') in ANN_COLORS else 'yellow'
    start = (data.get('start_date') or '').strip() or datetime.date.today().isoformat()
    end = (data.get('end_date') or '').strip() or None
    try:
        datetime.date.fromisoformat(start)
        if end:
            datetime.date.fromisoformat(end)
    except ValueError:
        raise ValueError("Date invalide.")
    if end and end < start:
        raise ValueError("La date de fin est avant la date de début.")
    return msg, color, start, end


@app.route('/api/license-warning/ack', methods=['POST'])
def api_license_warning_ack():
    if session.pop('license_warn', None):
        st = get_license_status()
        db_add_audit(session.get('username') or '?', "Avis d'expiration de la licence confirmé",
                     f"{st.get('days_left')} jour(s) restant(s)")
    return jsonify({'ok': True})


@app.route('/admin/messages')
def announcements_page():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return render_template('announcements.html', company=get_company_name(), username=session.get('username'))


@app.route('/api/admin/announcements')
def api_list_announcements():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return jsonify(db_list_announcements())


@app.route('/api/admin/announcements', methods=['POST'])
def api_create_announcement():
    resp = admin_required_check()
    if resp is not None:
        return resp
    try:
        msg, color, start, end = _ann_payload(request.get_json(silent=True) or {})
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    conn = get_conn()
    conn.execute("INSERT INTO announcements(message, color, start_date, end_date, active, created_at, created_by, "
                 "updated_at) VALUES (?,?,?,?,1,?,?,?)", (msg, color, start, end, now, session.get('username'), now))
    conn.commit()
    conn.close()
    log_audit('Message aux utilisateurs publié', f"{color}, du {start} au {end or '(sans fin)'} : {msg[:120]}")
    return jsonify({'ok': True})


@app.route('/api/admin/announcements/<int:ann_id>', methods=['PUT', 'DELETE'])
def api_update_announcement(ann_id):
    resp = admin_required_check()
    if resp is not None:
        return resp
    conn = get_conn()
    a = conn.execute("SELECT * FROM announcements WHERE id=?", (ann_id,)).fetchone()
    if a is None:
        conn.close()
        return jsonify({'ok': False, 'error': 'Message introuvable.'}), 404
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    try:
        if request.method == 'DELETE':
            conn.execute("DELETE FROM announcements WHERE id=?", (ann_id,))
            conn.commit()
            log_audit('Message aux utilisateurs supprimé', a['message'][:120])
            return jsonify({'ok': True})
        data = request.get_json(silent=True) or {}
        if set(data) == {'active'}:
            conn.execute("UPDATE announcements SET active=?, updated_at=? WHERE id=?",
                         (1 if data['active'] else 0, now, ann_id))
            conn.commit()
            log_audit('Message aux utilisateurs ' + ('réactivé' if data['active'] else 'désactivé'), a['message'][:120])
            return jsonify({'ok': True})
        try:
            msg, color, start, end = _ann_payload(data)
        except ValueError as e:
            return jsonify({'ok': False, 'error': str(e)}), 400
        conn.execute("UPDATE announcements SET message=?, color=?, start_date=?, end_date=?, updated_at=? WHERE id=?",
                     (msg, color, start, end, now, ann_id))
        conn.commit()
        log_audit('Message aux utilisateurs modifié', f"{color}, du {start} au {end or '(sans fin)'} : {msg[:120]}")
        return jsonify({'ok': True})
    finally:
        conn.close()


@app.route('/api/admin/three', methods=['GET', 'POST'])
def api_admin_three():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if request.method == 'POST':
        ok, msg = download_three_vendor()
        return jsonify({'ok': ok, 'message': msg, 'installed': three_local_ready(), 'version': THREE_VERSION}), (200 if ok else 502)
    return jsonify({'installed': three_local_ready(), 'version': THREE_VERSION, 'running': _three_state['running'],
                    'error': _three_state['error'], 'folder': str(THREE_VENDOR_DIR),
                    'files': [f[0] for f in THREE_FILES]})


@app.route('/admin/journal-envois')
def email_log_page():
    resp = permission_required_check('email_settings')
    if resp is not None:
        return resp
    return render_template('email_log.html', company=get_company_name())


@app.route('/api/email-log')
def api_email_log():
    resp = permission_required_check('email_settings')
    if resp is not None:
        return resp
    a = request.args
    where, params = [], []
    try:
        d0 = datetime.date.fromisoformat(a.get('from') or '')
        where.append("ts >= ?"); params.append(d0.isoformat())
    except ValueError:
        pass
    try:
        d1 = datetime.date.fromisoformat(a.get('to') or '')
        where.append("ts < ?"); params.append((d1 + datetime.timedelta(days=1)).isoformat())
    except ValueError:
        pass
    for k in ('method', 'status', 'category'):
        if a.get(k):
            where.append(f"{k}=?"); params.append(a[k])
    if a.get('q'):
        where.append("(recipient LIKE ? OR subject LIKE ? OR sender LIKE ? OR summary LIKE ?)"); params += [f"%{a['q']}%"] * 4
    sw = (" WHERE " + " AND ".join(where)) if where else ""
    conn = get_conn()
    try:
        rows = [dict(r) for r in conn.execute(f"SELECT * FROM email_log{sw} ORDER BY id DESC LIMIT 500", params).fetchall()]
        stats = {r[0]: r[1] for r in conn.execute(f"SELECT status, COUNT(*) FROM email_log{sw} GROUP BY status", params).fetchall()}
        bymeth = {r[0]: r[1] for r in conn.execute(f"SELECT method, COUNT(*) FROM email_log{sw} GROUP BY method", params).fetchall()}
        cats = [r[0] for r in conn.execute("SELECT DISTINCT category FROM email_log ORDER BY category").fetchall()]
    finally:
        conn.close()
    return jsonify({'rows': rows, 'stats': stats, 'methods': bymeth, 'categories': cats})


@app.route('/admin/users')
def admin_users_page():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return render_template('admin_users.html', company=get_company_name(), username=session.get('username'),
                            permission_keys=PERMISSION_KEYS)


@app.route('/api/audit')
def api_audit():
    resp = permission_required_check('audit')
    if resp is not None:
        return resp
    return jsonify(db_list_audit())


@app.route('/admin/email-settings')
def email_settings_page():
    resp = permission_required_check('email_settings')
    if resp is not None:
        return resp
    return render_template('email_settings.html', company=get_company_name(), username=session.get('username'),
                            is_admin=session.get('is_admin', False), permissions=session.get('permissions') or [])


@app.route('/api/settings/send-mode')
def api_send_mode():
    return jsonify(get_public_settings())


ADMIN_SETTINGS_LOGO_EXTS = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp'}


ADMIN_SETTINGS_LOGO_MAX_BYTES = 5 * 1024 * 1024  # 5 Mo


@app.route('/admin/settings')
def admin_settings_page():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return render_template('admin_settings.html', company=get_company_name(), app_name=APP_NAME,
                            username=session.get('username'))


@app.route('/api/admin-settings')
def api_get_admin_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return jsonify({
        'company_name': get_company_name(),
        'company_email': get_company_email(),
        'company_phone': get_company_phone(),
        'pdf_footer_message': get_pdf_footer_message(),
        'email_closing_message': get_email_closing_message(),
        'logo_customized': bool(meta_get('logo_customized')),
        'login_bg_customized': _login_bg_custom_file() is not None,
        'login_bg_url': login_bg_url(),
        'login_bg_mode': meta_get('login_bg_mode') or 'mosaique',
        'login_video_url': login_video_url(),
        'defaults': {
            'company_name': COMPANY_NAME_DEFAULT,
            'company_email': COMPANY_EMAIL_DEFAULT,
            'company_phone': COMPANY_PHONE_DEFAULT,
            'pdf_footer_message': PDF_FOOTER_MESSAGE_DEFAULT,
            'email_closing_message': EMAIL_CLOSING_MESSAGE_DEFAULT,
        },
    })


@app.route('/api/admin-settings', methods=['POST'])
def api_set_admin_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}

    name = (data.get('company_name') or '').strip()
    if not name:
        return jsonify({'error': 'Le nom de l\'entreprise est requis.'}), 400

    email = (data.get('company_email') or '').strip()
    if email and '@' not in email:
        return jsonify({'error': 'Adresse courriel invalide.'}), 400

    meta_set('company_name', name)
    meta_set('company_email', email)
    meta_set('company_phone', (data.get('company_phone') or '').strip())
    meta_set('pdf_footer_message', (data.get('pdf_footer_message') or '').strip() or PDF_FOOTER_MESSAGE_DEFAULT)
    meta_set('email_closing_message', (data.get('email_closing_message') or '').strip() or EMAIL_CLOSING_MESSAGE_DEFAULT)

    log_audit("Modification des paramètres de personnalisation (Administration)")
    return jsonify({'ok': True})


@app.route('/api/admin-settings/logo', methods=['POST'])
def api_upload_admin_logo():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if 'file' not in request.files or not request.files['file'].filename:
        return jsonify({'error': 'Aucun fichier reçu.'}), 400
    f = request.files['file']
    ext = Path(f.filename).suffix.lower()
    if ext not in ADMIN_SETTINGS_LOGO_EXTS:
        return jsonify({'error': 'Format d\'image non supporté (PNG, JPG, GIF, BMP ou WEBP).'}), 400
    raw = f.read()
    if not raw:
        return jsonify({'error': 'Fichier vide.'}), 400
    if len(raw) > ADMIN_SETTINGS_LOGO_MAX_BYTES:
        return jsonify({'error': 'Image trop volumineuse (max 5 Mo).'}), 400

    # On conserve une copie du logo d'origine avant la toute première
    # personnalisation, pour permettre un retour en arrière plus tard.
    if not meta_get('logo_customized') and LOGO_PATH.exists() and not LOGO_DEFAULT_BACKUP_PATH.exists():
        try:
            shutil.copyfile(str(LOGO_PATH), str(LOGO_DEFAULT_BACKUP_PATH))
        except Exception:
            pass

    LOGO_PATH.write_bytes(raw)
    meta_set('logo_customized', '1')
    log_audit("Changement du logo utilisé dans les PDF (Administration)", f.filename)
    return jsonify({'ok': True})


def _login_bg_custom_file():
    name = meta_get('login_bg_custom') or ''
    path = LOGO_PATH.parent / name if name.startswith(LOGIN_BG_CUSTOM_PREFIX) else None
    return path if path is not None and path.exists() else None


def _login_video_file():
    name = meta_get('login_video_custom') or ''
    path = LOGO_PATH.parent / name if name.startswith(LOGIN_VIDEO_PREFIX) else None
    return path if path is not None and path.exists() else None


def login_video_url():
    p = _login_video_file()
    if not p:
        return None
    return url_for('static', filename=p.name, v=int(p.stat().st_mtime))


def login_bg_mode():
    """Fond choisi pour la page de connexion, avec repli sur l'animation si le fichier manque."""
    m = meta_get('login_bg_mode') or 'mosaique'
    if m == 'video' and not _login_video_file():
        return 'mosaique'
    if m == 'image' and not _login_bg_custom_file():
        return 'mosaique'
    return m if m in LOGIN_BG_MODES else 'mosaique'


def login_bg_url():
    """Adresse de l'image de fond de la page de connexion (photo personnalisée
    si elle existe, sinon l'image par défaut). Le paramètre v force le
    navigateur à recharger l'image quand elle change."""
    path = _login_bg_custom_file() or (LOGO_PATH.parent / LOGIN_BG_DEFAULT_NAME)
    try:
        v = int(path.stat().st_mtime)
    except OSError:
        v = 0
    return url_for('static', filename=path.name, v=v)


@app.route('/api/admin-settings/login-bg', methods=['POST'])
def api_upload_login_bg():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if 'file' not in request.files or not request.files['file'].filename:
        return jsonify({'error': 'Aucun fichier reçu.'}), 400
    f = request.files['file']
    ext = Path(f.filename).suffix.lower()
    if ext not in LOGIN_BG_EXTS:
        return jsonify({'error': "Format d'image non supporté (JPG, PNG ou WEBP)."}), 400
    raw = f.read()
    if not raw:
        return jsonify({'error': 'Fichier vide.'}), 400
    if len(raw) > LOGIN_BG_MAX_BYTES:
        return jsonify({'error': 'Image trop volumineuse (max 8 Mo).'}), 400
    for old in LOGO_PATH.parent.glob(LOGIN_BG_CUSTOM_PREFIX + '.*'):
        try:
            old.unlink()
        except OSError:
            pass
    name = LOGIN_BG_CUSTOM_PREFIX + ('.jpg' if ext == '.jpeg' else ext)
    (LOGO_PATH.parent / name).write_bytes(raw)
    meta_set('login_bg_custom', name); meta_set('login_bg_mode', 'image')
    log_audit("Changement de l'image de fond de la page de connexion (Administration)", f.filename)
    return jsonify({'ok': True, 'url': login_bg_url()})


@app.route('/api/admin-settings/login-video', methods=['POST', 'DELETE'])
def api_login_video():
    resp = admin_required_check()
    if resp is not None:
        return resp
    def clear():
        for old in LOGO_PATH.parent.glob(LOGIN_VIDEO_PREFIX + '.*'):
            try:
                old.unlink()
            except OSError:
                pass
    if request.method == 'DELETE':
        clear(); meta_set('login_video_custom', '')
        if meta_get('login_bg_mode') == 'video':
            meta_set('login_bg_mode', 'mosaique')
        log_audit("Vidéo de fond de la page de connexion retirée (Administration)")
        return jsonify({'ok': True})
    f = request.files.get('file')
    if not f or not f.filename:
        return jsonify({'error': 'Aucun fichier reçu.'}), 400
    ext = Path(f.filename).suffix.lower()
    if ext not in LOGIN_VIDEO_EXTS:
        return jsonify({'error': 'Format vidéo non supporté (MP4 ou WebM).'}), 400
    raw = f.read()
    if not raw:
        return jsonify({'error': 'Fichier vide.'}), 400
    if len(raw) > LOGIN_VIDEO_MAX_BYTES:
        return jsonify({'error': 'Vidéo trop volumineuse (80 Mo au maximum). Une vidéo de 15 à 30 secondes suffit.'}), 400
    clear()
    name = LOGIN_VIDEO_PREFIX + ext
    (LOGO_PATH.parent / name).write_bytes(raw)
    meta_set('login_video_custom', name); meta_set('login_bg_mode', 'video')
    log_audit("Vidéo de fond de la page de connexion (Administration)", f.filename)
    return jsonify({'ok': True, 'url': login_video_url(), 'mode': 'video'})


@app.route('/api/admin-settings/login-bg-mode', methods=['POST'])
def api_login_bg_mode():
    resp = admin_required_check()
    if resp is not None:
        return resp
    m = (request.get_json(silent=True) or {}).get('mode')
    if m not in LOGIN_BG_MODES:
        return jsonify({'error': 'Choix invalide.'}), 400
    if m == 'video' and not _login_video_file():
        return jsonify({'error': "Téléverse d'abord une vidéo."}), 400
    if m == 'image' and not _login_bg_custom_file():
        return jsonify({'error': "Téléverse d'abord une image."}), 400
    meta_set('login_bg_mode', m)
    log_audit('Fond de la page de connexion', {'mosaique': 'Animation Kubios', 'image': 'Image personnalisée', 'video': 'Vidéo personnalisée'}[m])
    return jsonify({'ok': True, 'mode': m})


@app.route('/api/admin-settings/login-bg/reset', methods=['POST'])
def api_reset_login_bg():
    resp = admin_required_check()
    if resp is not None:
        return resp
    for old in LOGO_PATH.parent.glob(LOGIN_BG_CUSTOM_PREFIX + '.*'):
        try:
            old.unlink()
        except OSError:
            pass
    meta_set('login_bg_custom', '')
    log_audit("Retour à l'image de fond par défaut de la page de connexion (Administration)")
    return jsonify({'ok': True, 'url': login_bg_url()})


@app.route('/api/admin-settings/logo/reset', methods=['POST'])
def api_reset_admin_logo():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if LOGO_DEFAULT_BACKUP_PATH.exists():
        shutil.copyfile(str(LOGO_DEFAULT_BACKUP_PATH), str(LOGO_PATH))
    meta_set('logo_customized', '')
    log_audit("Réinitialisation du logo par défaut (Administration)")
    return jsonify({'ok': True})


@app.route('/admin/updates')
def updates_page():
    resp = permission_required_check('updates')
    if resp is not None:
        return resp
    return render_template('updates.html', company=get_company_name(), username=session.get('username'),
                            version=APP_VERSION, changelog=CHANGELOG,
                            is_admin=session.get('is_admin', False), permissions=session.get('permissions') or [])


@app.route('/api/updates')
def api_updates():
    resp = permission_required_check('updates')
    if resp is not None:
        return resp
    return jsonify({'version': APP_VERSION, 'changelog': CHANGELOG})


@app.route('/api/updates/check')
def api_updates_check():
    resp = permission_required_check('updates')
    if resp is not None:
        return resp
    try:
        req = urllib.request.Request(UPDATE_CHECK_URL, headers={'Cache-Control': 'no-cache'})
        with urllib.request.urlopen(req, timeout=6) as r:
            raw_body = r.read().decode('utf-8-sig').strip()
            remote = json.loads(raw_body)
    except urllib.error.URLError:
        return jsonify({'ok': False, 'error':
                         "Impossible de joindre le serveur de mises à jour. "
                         "Vérifie ta connexion Internet et réessaie."})
    except Exception as e:
        return jsonify({'ok': False, 'error':
                         "Réponse invalide du serveur de mises à jour (%s)." % e})

    remote_version = remote.get('version', '')
    remote_changelog = remote.get('changelog', [])
    try:
        up_to_date = _version_tuple(APP_VERSION) >= _version_tuple(remote_version)
    except Exception:
        return jsonify({'ok': False, 'error': "Numéro de version distant illisible."})

    # Les changements plus récents que la version installée (pour affichage).
    new_entries = [e for e in remote_changelog
                   if _version_tuple(e.get('version', '0.0.0')) > _version_tuple(APP_VERSION)]

    return jsonify({
        'ok': True,
        'installed_version': APP_VERSION,
        'latest_version': remote_version,
        'up_to_date': up_to_date,
        'new_entries': new_entries,
        'can_auto_install': bool(remote.get('download_url')),
    })


@app.route('/api/updates/install', methods=['POST'])
def api_updates_install():
    resp = permission_required_check('updates')
    if resp is not None:
        return resp

    body = request.get_json(silent=True) or {}
    restart_mode = body.get('restart_mode')
    if restart_mode not in ('service', 'startbat'):
        return jsonify({'ok': False, 'error':
                         "Précise comment cet ordinateur redémarre l'application "
                         "(service Windows ou start.bat) avant de continuer."}), 400

    try:
        req = urllib.request.Request(UPDATE_CHECK_URL, headers={'Cache-Control': 'no-cache'})
        with urllib.request.urlopen(req, timeout=6) as r:
            remote = json.loads(r.read().decode('utf-8-sig').strip())
    except Exception as e:
        return jsonify({'ok': False, 'error': "Impossible de joindre le serveur de mises à jour (%s)." % e}), 400

    download_url = remote.get('download_url')
    if not download_url:
        return jsonify({'ok': False, 'error':
                         "Aucun paquet de mise à jour téléchargeable pour l'instant. "
                         "Utilise « Vérifier les mises à jour » pour voir ce qui a changé."}), 400

    try:
        # Télécharge et extrait le paquet de code dans un dossier temporaire,
        # HORS du dossier de l'app (C:\DBouxpCR\app) — jamais dans le dossier
        # en cours d'utilisation par ce processus.
        if UPDATE_STAGING_DIR.exists():
            shutil.rmtree(UPDATE_STAGING_DIR, ignore_errors=True)
        UPDATE_STAGING_DIR.mkdir(parents=True, exist_ok=True)

        dl_req = urllib.request.Request(download_url, headers={'Cache-Control': 'no-cache'})
        with urllib.request.urlopen(dl_req, timeout=30) as r:
            zip_bytes = r.read()
        UPDATE_ZIP_PATH.write_bytes(zip_bytes)

        with zipfile.ZipFile(UPDATE_ZIP_PATH) as zf:
            zf.extractall(UPDATE_STAGING_DIR)

        staged_app_dir = UPDATE_STAGING_DIR / "app"
        if not (staged_app_dir / "app.py").exists():
            return jsonify({'ok': False, 'error':
                             "Le paquet téléchargé est invalide (app.py introuvable dedans)."}), 400
    except Exception as e:
        return jsonify({'ok': False, 'error': f"Échec du téléchargement du paquet : {e}"}), 400

    err = _launch_update(staged_app_dir, restart_mode)
    if err:
        return jsonify({'ok': False, 'error': err}), 400
    db_add_audit(session.get('username'), 'Mise à jour installée', f"vers v{remote.get('version')}")
    return jsonify({'ok': True, 'message':
                     "Téléchargement terminé. L'application redémarre maintenant — "
                     "recharge cette page dans environ 30 secondes."})


VERSIONS_DIR = BASE_DIR / "_versions_kubios"


VERSIONS_KEEP = 5


def versions_list():
    out = []
    for f in sorted(VERSIONS_DIR.glob('kubios-*__*.zip'), key=lambda x: x.stat().st_mtime, reverse=True) if VERSIONS_DIR.exists() else []:
        ver, _, stamp = f.stem[len('kubios-'):].partition('__')
        try:
            when = datetime.datetime.strptime(stamp, '%Y%m%d-%H%M%S').strftime('%Y-%m-%d %H:%M')
        except ValueError:
            when = ''
        out.append({'file': f.name, 'version': ver, 'saved': when, 'size': f.stat().st_size, 'current': ver == APP_VERSION})
    return out


def _launch_update(staged_app_dir, restart_mode):
    """Lance le script qui copie le paquet préparé par-dessus app\\ puis redémarre Kubios.
    Retourne un message d'erreur, ou None si l'installation est lancée."""
    try:
        runner_src = _UPDATE_RUNNER_SCRIPT.format(
            staged=str(staged_app_dir), target=str(APP_DIR), base=str(BASE_DIR),
            restart_mode=restart_mode)
        UPDATE_RUNNER_PATH.write_text(runner_src, encoding='utf-8')
        popen_kwargs = {'cwd': str(BASE_DIR), 'close_fds': True}
        if sys.platform == 'win32':
            popen_kwargs['creationflags'] = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
        subprocess.Popen([_real_python_exe(), str(UPDATE_RUNNER_PATH)], **popen_kwargs)
    except Exception as e:
        return f"Impossible de démarrer l'installation : {e}"

    # Laisse le temps à la réponse HTTP de partir avant de fermer ce processus — le script
    # lancé ci-dessus attend, de son côté, que ce processus soit bien terminé avant de copier.
    def _delayed_exit():
        time.sleep(1.5)
        os._exit(0)
    threading.Thread(target=_delayed_exit, daemon=True).start()
    return None


UPDATE_UPLOAD_MAX = 150 * 1024 * 1024


def _version_tuple(v):
    """Convertit "1.4.0" (ou "v1.4") en (1, 4, 0) pour comparer deux versions ; (0,) si illisible."""
    try:
        return tuple(int(x) for x in str(v).strip().lstrip('vV').split('.'))
    except ValueError:
        return (0,)


def _read_package_info(app_py):
    """Lit APP_VERSION et CHANGELOG dans le app.py d'un paquet, sans l'exécuter."""
    import ast
    tree = ast.parse(app_py.read_text(encoding='utf-8-sig'))
    info = {'version': None, 'changelog': []}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            if name == 'APP_VERSION':
                info['version'] = ast.literal_eval(node.value)
            elif name == 'CHANGELOG' and isinstance(node.value, ast.List):
                class _Plain(ast.NodeTransformer):     # texte avec valeur insérée : on garde la partie fixe
                    def visit_JoinedStr(self, n):
                        return ast.copy_location(ast.Constant(''.join(v.value for v in n.values if isinstance(v, ast.Constant) and isinstance(v.value, str))), n)
                for el in node.value.elts:            # entrée par entrée : une entrée illisible ne bloque pas les autres
                    try:
                        info['changelog'].append(ast.literal_eval(ast.fix_missing_locations(_Plain().visit(el))))
                    except (ValueError, TypeError, SyntaxError):
                        pass
    return info


@app.route('/api/updates/upload', methods=['POST'])
def api_updates_upload():
    """Étape 1 : reçoit le zip, le vérifie et le prépare ; retourne sa version et ses changements."""
    resp = permission_required_check('updates')
    if resp is not None:
        return resp
    f = request.files.get('file')
    if not f or not f.filename:
        return jsonify({'ok': False, 'error': 'Choisis le fichier du paquet (kubios-x.y.z.zip).'}), 400
    if not f.filename.lower().endswith('.zip'):
        return jsonify({'ok': False, 'error': 'Le paquet doit être un fichier .zip.'}), 400
    data = f.read()
    if not data or len(data) > UPDATE_UPLOAD_MAX:
        return jsonify({'ok': False, 'error': 'Fichier vide ou trop volumineux (150 Mo au maximum).'}), 400
    try:
        if UPDATE_STAGING_DIR.exists():
            shutil.rmtree(UPDATE_STAGING_DIR, ignore_errors=True)
        UPDATE_STAGING_DIR.mkdir(parents=True, exist_ok=True)
        UPDATE_ZIP_PATH.write_bytes(data)
        with zipfile.ZipFile(UPDATE_ZIP_PATH) as zf:
            bad = zf.testzip()
            if bad:
                return jsonify({'ok': False, 'error': f"Le fichier zip est endommagé ({bad})."}), 400
            names = zf.namelist()
            zf.extractall(UPDATE_STAGING_DIR)          # extractall neutralise les chemins « .. » et absolus
    except zipfile.BadZipFile:
        return jsonify({'ok': False, 'error': "Ce fichier n'est pas un zip valide."}), 400
    except Exception as e:
        return jsonify({'ok': False, 'error': f"Impossible d'ouvrir le paquet : {e}"}), 400
    staged = UPDATE_STAGING_DIR / 'app'
    if not (staged / 'app.py').exists():
        shutil.rmtree(UPDATE_STAGING_DIR, ignore_errors=True)
        return jsonify({'ok': False, 'error': "Ce n'est pas un paquet Kubios : le dossier « app » avec app.py est introuvable dans le zip."}), 400
    try:
        # depuis 1.46.0, le numéro de version et l'historique sont dans kubios_version.py
        info = _read_package_info(staged / 'kubios_version.py') if (staged / 'kubios_version.py').exists() else _read_package_info(staged / 'app.py')
    except Exception as e:
        shutil.rmtree(UPDATE_STAGING_DIR, ignore_errors=True)
        return jsonify({'ok': False, 'error': f"Le app.py du paquet est illisible ({e})."}), 400
    if not info['version']:
        shutil.rmtree(UPDATE_STAGING_DIR, ignore_errors=True)
        return jsonify({'ok': False, 'error': "Version introuvable dans le paquet (APP_VERSION)."}), 400
    cur, new = _version_tuple(APP_VERSION), _version_tuple(info['version'])
    cmp_ = 'newer' if new > cur else ('same' if new == cur else 'older')
    entries = [e for e in info['changelog'] if isinstance(e, dict) and _version_tuple(e.get('version')) > cur] if cmp_ == 'newer' else info['changelog'][:1]
    token = hashlib.sha256(data).hexdigest()
    session['update_upload_token'] = token
    db_add_audit(session.get('username'), 'Mise à jour : paquet téléversé', f"{f.filename} — v{info['version']}")
    return jsonify({'ok': True, 'version': info['version'], 'current': APP_VERSION, 'compare': cmp_, 'token': token,
                    'filename': f.filename, 'size': len(data), 'files': len([n for n in names if not n.endswith('/')]),
                    'entries': [{'version': e.get('version'), 'date': e.get('date'), 'changes': e.get('changes', [])} for e in entries][:20]})


@app.route('/api/updates/versions')
def api_updates_versions():
    resp = permission_required_check('updates')
    if resp is not None:
        return resp
    return jsonify({'ok': True, 'current': APP_VERSION, 'versions': versions_list(), 'keep': VERSIONS_KEEP})


@app.route('/api/updates/rollback', methods=['POST'])
def api_updates_rollback():
    """Réinstalle une version conservée (seul le programme change ; la base et les fichiers restent)."""
    resp = permission_required_check('updates')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    restart_mode = d.get('restart_mode')
    if restart_mode not in ('service', 'startbat'):
        return jsonify({'ok': False, 'error': "Précise comment cet ordinateur redémarre l'application (service Windows ou start.bat)."}), 400
    name = str(d.get('file') or '')
    if not re.fullmatch(r'kubios-[0-9.]+__\d{8}-\d{6}\.zip', name) or not (VERSIONS_DIR / name).exists():
        return jsonify({'ok': False, 'error': 'Version introuvable.'}), 404
    ver = name[len('kubios-'):].partition('__')[0]
    if ver == APP_VERSION:
        return jsonify({'ok': False, 'error': "C'est déjà la version en place."}), 400
    try:
        if UPDATE_STAGING_DIR.exists():
            shutil.rmtree(UPDATE_STAGING_DIR, ignore_errors=True)
        UPDATE_STAGING_DIR.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(VERSIONS_DIR / name) as z:
            z.extractall(UPDATE_STAGING_DIR)
    except Exception as e:
        return jsonify({'ok': False, 'error': f"Copie de la version illisible : {e}"}), 400
    staged = UPDATE_STAGING_DIR / 'app'
    if not (staged / 'app.py').exists():
        return jsonify({'ok': False, 'error': 'Copie de la version incomplète.'}), 400
    err = _launch_update(staged, restart_mode)
    if err:
        return jsonify({'ok': False, 'error': err}), 400
    db_add_audit(session.get('username'), 'Retour à une version précédente', f"v{APP_VERSION} → v{ver}")
    return jsonify({'ok': True, 'message': f"Retour à la v{ver} lancé. L'application redémarre — recharge cette page dans environ 30 secondes."})


@app.route('/api/updates/upload/install', methods=['POST'])
def api_updates_upload_install():
    """Étape 2 : installe le paquet préparé à l'étape 1."""
    resp = permission_required_check('updates')
    if resp is not None:
        return resp
    body = request.get_json(silent=True) or {}
    restart_mode = body.get('restart_mode')
    if restart_mode not in ('service', 'startbat'):
        return jsonify({'ok': False, 'error': "Précise comment cet ordinateur redémarre l'application (service Windows ou start.bat)."}), 400
    token = body.get('token') or ''
    if not token or token != session.get('update_upload_token') or not UPDATE_ZIP_PATH.exists() \
            or hashlib.sha256(UPDATE_ZIP_PATH.read_bytes()).hexdigest() != token:
        return jsonify({'ok': False, 'error': 'Le paquet vérifié n\u2019est plus disponible : téléverse-le de nouveau.'}), 400
    staged = UPDATE_STAGING_DIR / 'app'
    if not (staged / 'app.py').exists():
        return jsonify({'ok': False, 'error': 'Le paquet vérifié n\u2019est plus disponible : téléverse-le de nouveau.'}), 400
    info = _read_package_info(staged / 'kubios_version.py') if (staged / 'kubios_version.py').exists() else _read_package_info(staged / 'app.py')
    if _version_tuple(info['version']) < _version_tuple(APP_VERSION) and not body.get('allow_older'):
        return jsonify({'ok': False, 'error': f"Ce paquet (v{info['version']}) est plus ancien que la version installée (v{APP_VERSION}). Coche la confirmation pour revenir en arrière."}), 400
    err = _launch_update(staged, restart_mode)
    if err:
        return jsonify({'ok': False, 'error': err}), 400
    session.pop('update_upload_token', None)
    db_add_audit(session.get('username'), 'Mise à jour installée (paquet téléversé)', f"v{APP_VERSION} → v{info['version']}")
    return jsonify({'ok': True, 'message': f"Installation de la v{info['version']} lancée. L'application redémarre maintenant — recharge cette page dans environ 30 secondes."})


@app.route('/api/settings/email', methods=['GET'])
def api_get_email_settings():
    resp = permission_required_check('email_settings')
    if resp is not None:
        return resp
    settings = get_settings()
    settings['smtp_password_set'] = bool(settings.get('smtp_password'))
    settings.pop('smtp_password', None)
    settings['m365_secret_set'] = bool(settings.get('m365_secret'))
    settings.pop('m365_secret', None)
    return jsonify(settings)


@app.route('/api/settings/email', methods=['PUT'])
def api_set_email_settings():
    resp = permission_required_check('email_settings')
    if resp is not None:
        return resp
    data = request.json or {}
    send_mode = data.get('send_mode', 'outlook')
    if send_mode == 'smtp':
        host = (data.get('smtp_host') or '').strip()
        from_email = (data.get('smtp_from_email') or '').strip()
        if not host or not from_email:
            return jsonify({'ok': False, 'error':
                             "Pour activer le mode SMTP, il faut au minimum l'adresse du "
                             "serveur et l'adresse courriel d'expédition."}), 400
    if send_mode == 'm365':
        need = [k for k, lbl in (('m365_tenant', 'ID du locataire'), ('m365_client_id', "ID de l'application"), ('m365_mailbox_general', 'boîte de Kubios'))
                if not (data.get(k) or '').strip()]
        if not (data.get('m365_secret') or meta_get('m365_secret')):
            need.append('m365_secret')
        if need:
            return jsonify({'ok': False, 'error': "Pour Microsoft 365, il faut l'ID du locataire, l'ID de l'application, le secret client "
                                                  "et au moins la boîte de Kubios."}), 400
        for k in ('m365_mailbox_ar', 'm365_mailbox_general', 'm365_ar_reply_to'):
            v = (data.get(k) or '').strip()
            if v and not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+', v):
                return jsonify({'ok': False, 'error': f"Adresse de boîte invalide : {v}"}), 400
        _M365_TOKEN.update(key=None, tok=None, exp=0)
    set_settings(data)
    log_audit('Modification paramètres d\'envoi', f"mode={send_mode}")
    return jsonify({'ok': True})


@app.route('/api/settings/email/test', methods=['POST'])
def api_test_email_settings():
    resp = permission_required_check('email_settings')
    if resp is not None:
        return resp
    data = request.json or {}
    # Si le mot de passe n'est pas fourni (champ laissé vide dans le formulaire),
    # on utilise celui déjà enregistré pour permettre de tester sans le retaper.
    settings = dict(data)
    if not settings.get('smtp_password'):
        settings['smtp_password'] = meta_get('smtp_password', '')
    if data.get('send_mode') == 'm365':
        if not settings.get('m365_secret'):
            settings['m365_secret'] = meta_get('m365_secret', '')
        to = (data.get('test_to') or '').strip() or get_company_email() or ''
        if not to:
            return jsonify({'ok': False, 'error': "Indique l'adresse qui recevra le courriel de test."}), 400
        purpose = 'ar' if data.get('test_box') == 'ar' else 'general'
        try:
            mb = m365_mailbox(settings, purpose)
            send_via_m365(to, f"{get_company_name()} — test d'envoi Microsoft 365",
                          f"Bonjour,\n\nCe courriel de test a été envoyé par Kubios depuis la boîte {mb} avec Microsoft 365.\n\n{get_company_name()}",
                          None, settings, mode='send', bcc_company=False, purpose=purpose)
            log_audit('Paramètres d\'envoi : test Microsoft 365 réussi', f"{mb} → {to}")
            return jsonify({'ok': True, 'message': f"Courriel de test envoyé depuis {mb} à {to}."})
        except Exception as e:
            return jsonify({'ok': False, 'error': str(e)}), 400
    try:
        test_smtp_connection(settings)
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/admin/sessions')
def sessions_page():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return render_template('sessions.html', company=get_company_name(), my_sid=session.get('sid'))


def sess_list(conn):
    lim = (datetime.datetime.now() - datetime.timedelta(days=30)).strftime(AT_FMT)
    rows = [dict(r) for r in conn.execute("SELECT * FROM user_sessions WHERE revoked_at IS NULL AND last_seen > ? ORDER BY last_seen DESC", (lim,)).fetchall()]
    now = datetime.datetime.now()
    for r in rows:
        r['idle'] = int((now - datetime.datetime.strptime(r['last_seen'], AT_FMT)).total_seconds())
        r['online'] = r['idle'] <= SESS_ONLINE_SEC
    return rows


@app.route('/api/sessions')
def api_sessions():
    resp = admin_required_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        rows = sess_list(conn)
    finally:
        conn.close()
    return jsonify({'sessions': rows, 'me': session.get('sid')})


@app.route('/api/sessions/revoke', methods=['POST'])
def api_sessions_revoke():
    resp = admin_required_check()
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    conn = get_conn()
    try:
        if d.get('sid'):
            sids = [d['sid']]
        elif d.get('user_id') and d.get('kind') in ('user', 'portail'):
            sids = [r[0] for r in conn.execute("SELECT sid FROM user_sessions WHERE kind=? AND user_id=? AND revoked_at IS NULL", (d['kind'], int(d['user_id']))).fetchall()]
        else:
            return jsonify({'ok': False, 'error': 'Session introuvable.'}), 400
        sids = [x for x in sids if x != session.get('sid')]
        if not sids:
            return jsonify({'ok': False, 'error': "Tu ne peux pas fermer ta propre session d'ici : utilise « Se déconnecter »."}), 400
        who = [r for r in conn.execute(f"SELECT display, kind FROM user_sessions WHERE sid IN ({','.join('?' * len(sids))})", sids).fetchall()]
        conn.execute(f"UPDATE user_sessions SET revoked_at=?, revoked_by=? WHERE sid IN ({','.join('?' * len(sids))}) AND revoked_at IS NULL",
                     [_at_now(), current_display_name()] + sids)
        conn.commit()
    finally:
        conn.close()
    _SESS_REVOKED.update(sids)
    log_audit('Session fermée à distance', ', '.join(f"{w['display']} ({'portail' if w['kind'] == 'portail' else 'Kubios'})" for w in who))
    return jsonify({'ok': True, 'closed': len(sids)})


@app.route('/api/users', methods=['GET'])
def api_list_users():
    resp = admin_required_check()
    if resp is not None:
        return resp
    users = db_list_users()
    conn = get_conn()
    try:                                     # 1.37.0 : dernière connexion (journal d'audit)
        last = {r['username']: r['ts'] for r in conn.execute(
            "SELECT username, MAX(ts) ts FROM audit_log WHERE action='Connexion' GROUP BY username").fetchall()}
    finally:
        conn.close()
    conn = get_conn()
    try:
        online = {r['user_id'] for r in sess_list(conn) if r['kind'] == 'user' and r['online']}
    finally:
        conn.close()
    for u in users:
        u['last_login'] = last.get(u['username'])
        u['online'] = u['id'] in online
    if request.args.get('meta') == '1':
        lic = get_license_status()
        return jsonify({'users': users, 'max_users': licensing.max_users_of(lic.get('payload')), 'active_users': db_count_active_users()})
    return jsonify(users)


@app.route('/api/users', methods=['POST'])
def api_create_user():
    resp = admin_required_check()
    if resp is not None:
        return resp
    data = request.json or {}
    email = (data.get('email') or '').strip() or None
    if email and not _EMAIL_OK.match(email):
        return jsonify({'ok': False, 'error': f"Adresse courriel invalide : {email}"}), 400
    limit_error = license_user_limit_error()
    if limit_error:
        return jsonify({'ok': False, 'error': limit_error}), 400
    try:
        db_create_user(data.get('username', ''), data.get('password', ''), bool(data.get('is_admin')),
                        permissions=data.get('permissions'))
        created = db_get_user_by_username(data.get('username', ''))
        full_name = (data.get('full_name') or '').strip()[:80] or None
        if created and (email or data.get('mfa_required') or full_name):
            db_set_user_mfa(created['id'], email=email, mfa_required=1 if data.get('mfa_required') else 0,
                            full_name=full_name)
        log_audit('Création utilisateur', data.get('username', '')
                  + (f" — courriel {email}" if email else "") + (" — 2FA obligatoire" if data.get('mfa_required') else ""))
        return jsonify({'ok': True})
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/users/<int:user_id>', methods=['PUT'])
def api_update_user(user_id):
    resp = admin_required_check()
    if resp is not None:
        return resp
    data = request.json or {}
    if user_id == session.get('user_id') and data.get('active') is False:
        return jsonify({'ok': False, 'error': "Tu ne peux pas désactiver ton propre compte."}), 400
    if data.get('active') is True:
        current = db_get_user(user_id)
        if current and not current['active']:
            limit_error = license_user_limit_error()
            if limit_error:
                return jsonify({'ok': False, 'error': limit_error}), 400
    try:
        db_update_user(
            user_id,
            is_admin=data.get('is_admin'),
            active=data.get('active'),
            new_password=data.get('password') or None,
            permissions=data.get('permissions'),
        )
        target = db_get_user(user_id)
        target_name = target['username'] if target else str(user_id)
        changes = []
        if data.get('is_admin') is not None:
            changes.append('admin' if data.get('is_admin') else 'retrait admin')
        if data.get('active') is not None:
            changes.append('réactivé' if data.get('active') else 'désactivé')
        if data.get('password'):
            changes.append('mot de passe réinitialisé')
        if data.get('permissions') is not None:
            changes.append(f"accès : {', '.join(data.get('permissions')) or 'aucun'}")
        log_audit('Modification utilisateur', f"{target_name} ({', '.join(changes) or 'aucun changement'})")
        return jsonify({'ok': True})
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/users/<int:user_id>', methods=['DELETE'])
def api_delete_user(user_id):
    resp = admin_required_check()
    if resp is not None:
        return resp
    if user_id == session.get('user_id'):
        return jsonify({'ok': False, 'error': "Tu ne peux pas supprimer ton propre compte."}), 400
    target = db_get_user(user_id)
    db_delete_user(user_id)
    log_audit('Suppression utilisateur', target['username'] if target else str(user_id))
    return jsonify({'ok': True})
