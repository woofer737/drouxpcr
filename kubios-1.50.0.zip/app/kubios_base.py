# -*- coding: utf-8 -*-
"""Tronc commun : base de données, réglages, entreprise, audit, adresse du client.
Module du tronc commun de Kubios (découpé de app.py en 1.45.0, code inchangé)."""
import os, re, io, csv, sys, json, base64, hashlib, unicodedata, time, shutil, secrets, sqlite3, zipfile, threading, subprocess, datetime, traceback
import urllib.request, urllib.error, urllib.parse, email.utils
from pathlib import Path
from flask import request, session, has_request_context
import licensing

__all__ = ['AT_FMT', 'AUDIT_MAX_ROWS', 'COMPANY_EMAIL_DEFAULT', 'COMPANY_NAME_DEFAULT', 'DB_PATH', 'SETTINGS_DEFAULTS', '_LOOPBACK', '_at_now', 'client_ip', 'db_add_audit', 'get_company_email', 'get_company_name', 'get_conn', 'get_settings', 'meta_get', 'meta_set', 'set_settings']


DB_PATH = Path(__file__).resolve().parent / "data.db"


COMPANY_NAME_DEFAULT = "Outillages Express"


COMPANY_EMAIL_DEFAULT = "recevables@outillagesexpress.ca"


def get_company_name():
    return (meta_get('company_name') or COMPANY_NAME_DEFAULT).strip() or COMPANY_NAME_DEFAULT


def get_company_email():
    return (meta_get('company_email') or COMPANY_EMAIL_DEFAULT).strip()


_LOOPBACK = ('127.0.0.1', '::1', '::ffff:127.0.0.1')


def client_ip():
    """Adresse réelle de l'utilisateur (1.26.1).
    Derrière Cloudflare Tunnel, toutes les connexions arrivent du tunnel (127.0.0.1) : on lit alors
    l'en-tête CF-Connecting-IP (ou X-Forwarded-For). Ces en-têtes ne sont crus que si la connexion
    vient du PC lui-même, là où roule cloudflared — sinon n'importe qui sur le réseau pourrait les inventer."""
    ra = request.remote_addr or ''
    if ra in _LOOPBACK:
        cf = (request.headers.get('CF-Connecting-IP') or '').strip()
        if cf:
            return cf[:64]
        xff = (request.headers.get('X-Forwarded-For') or '').split(',')[0].strip()
        if xff:
            return xff[:64]
    return ra or '?'


def get_conn():
    conn = sqlite3.connect(str(DB_PATH), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def meta_get(key, default=None):
    conn = get_conn()
    row = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
    conn.close()
    return row['value'] if row else default


def meta_set(key, value):
    conn = get_conn()
    conn.execute("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                 (key, str(value)))
    conn.commit()
    conn.close()


AUDIT_MAX_ROWS = 5000


def db_add_audit(username, action, details=''):
    """Enregistre une action dans le journal d'audit. N'interrompt jamais l'action
    elle-même si l'écriture échoue (l'audit est secondaire, jamais bloquant)."""
    try:
        conn = get_conn()
        cur = conn.execute(
            "INSERT INTO audit_log(ts, username, action, details) VALUES (?,?,?,?)",
            (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), username or '?', action, details or '')
        )
        new_id = cur.lastrowid
        conn.commit()
        # purge périodique pour éviter une croissance illimitée (garde les AUDIT_MAX_ROWS plus récents)
        if new_id % 100 == 0:
            conn.execute(
                "DELETE FROM audit_log WHERE id NOT IN (SELECT id FROM audit_log ORDER BY id DESC LIMIT ?)",
                (AUDIT_MAX_ROWS,)
            )
            conn.commit()
        conn.close()
    except Exception:
        traceback.print_exc()


SETTINGS_DEFAULTS = {
    'send_mode': 'outlook',        # 'outlook' ou 'smtp'
    'smtp_host': '',
    'smtp_port': '587',
    'smtp_username': '',
    'smtp_password': '',
    'smtp_encryption': 'starttls',  # 'starttls' | 'ssl' | 'none'
    'smtp_from_email': '',
    'smtp_from_name': '',
    # 1.43.0 : Microsoft 365 (Graph) — application inscrite dans Entra ID avec la permission Mail.Send
    'm365_tenant': '',
    'm365_client_id': '',
    'm365_secret': '',
    'm365_mailbox_ar': '',        # boîte partagée des comptes à recevoir (états de compte)
    'm365_mailbox_general': '',   # boîte de Kubios pour tous les autres envois
    'm365_from_name': '',
    'm365_ar_reply_to': '',      # 1.43.2 : adresse de réponse des états de compte (ex. groupe Teams recevables@)
    'm365_ar_copy': '',          # '1' = copie cachée de chaque état de compte à cette adresse
}


def get_settings():
    return {k: meta_get(k, default) for k, default in SETTINGS_DEFAULTS.items()}


def set_settings(data):
    for key in SETTINGS_DEFAULTS:
        if key in data and data[key] is not None:
            value = data[key]
            if key in ('smtp_password', 'm365_secret') and value == '':
                continue  # champ laissé vide = on garde l'ancien mot de passe
            meta_set(key, value)


AT_FMT = '%Y-%m-%d %H:%M:%S'


def _at_now():
    return datetime.datetime.now().strftime(AT_FMT)
