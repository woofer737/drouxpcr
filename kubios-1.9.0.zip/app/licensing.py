# -*- coding: utf-8 -*-
"""
Vérification des codes de licence.

Ce module ne contient QUE la clé PUBLIQUE — il peut être livré sans risque avec
l'application chez n'importe quel client : elle permet de vérifier qu'un code de
licence a bien été signé par le générateur officiel, mais elle ne permet PAS de
créer de nouveaux codes. Seul le générateur de licences (gardé séparément, jamais
livré avec l'app) contient la clé privée qui signe les codes.

Format d'un code de licence :
    OE-LIC1-<payload_b64>.<signature_b64>

où <payload_b64> encode en base64 (urlsafe, sans padding) un JSON compact :
    {"id": "...", "licensee": "Nom du client", "type": "30d"|"1y"|"lifetime",
     "issued": "AAAA-MM-JJ", "expires": "AAAA-MM-JJ" ou null}
"""
import base64
import json

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature

CODE_PREFIX = "OE-LIC1-"

# Clé publique Ed25519 (base64 urlsafe, sans padding) — correspond à la clé
# privée gardée uniquement dans le générateur de licences.
PUBLIC_KEY_B64 = "F0hAz8y9nPKkMsaLCKg_iM_-80-73fgjDR6GY4t18jw"

TYPE_LABELS = {
    '30d': "30 jours",
    '1y': "1 an",
    'lifetime': "À vie",
}


def _b64url_decode(s):
    padding = '=' * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + padding)


def _b64url_encode(b):
    return base64.urlsafe_b64encode(b).decode('ascii').rstrip('=')


def _get_public_key():
    raw = _b64url_decode(PUBLIC_KEY_B64)
    return Ed25519PublicKey.from_public_bytes(raw)


def verify_license_code(code):
    """Vérifie un code de licence. Retourne toujours un dict :
        {'ok': True, 'payload': {...}}
    ou
        {'ok': False, 'error': "message clair en français"}
    Ne fait AUCUNE vérification de date d'expiration ici — seulement la
    signature et le format. La date est vérifiée séparément par l'appelant."""
    if not code or not isinstance(code, str):
        return {'ok': False, 'error': "Aucun code de licence fourni."}
    code = code.strip()
    if not code.startswith(CODE_PREFIX):
        return {'ok': False, 'error': "Format de code de licence invalide."}
    body = code[len(CODE_PREFIX):]
    if '.' not in body:
        return {'ok': False, 'error': "Format de code de licence invalide."}
    payload_b64, _, sig_b64 = body.partition('.')
    try:
        payload_bytes = _b64url_decode(payload_b64)
        signature = _b64url_decode(sig_b64)
    except Exception:
        return {'ok': False, 'error': "Code de licence illisible ou corrompu."}

    try:
        _get_public_key().verify(signature, payload_b64.encode('ascii'))
    except InvalidSignature:
        return {'ok': False, 'error': "Ce code de licence n'est pas valide (signature incorrecte)."}
    except Exception:
        return {'ok': False, 'error': "Code de licence illisible ou corrompu."}

    try:
        payload = json.loads(payload_bytes)
    except Exception:
        return {'ok': False, 'error': "Code de licence illisible ou corrompu."}

    if not isinstance(payload, dict) or 'licensee' not in payload or 'type' not in payload:
        return {'ok': False, 'error': "Code de licence illisible ou corrompu."}

    return {'ok': True, 'payload': payload}
