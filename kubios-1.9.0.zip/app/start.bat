@echo off
cd /d "%~dp0"
echo ============================================
echo   Comptes a recevoir - demarrage de l'app
echo ============================================

where python >nul 2>nul
if errorlevel 1 (
    echo.
    echo ERREUR : Python n'est pas installe ou pas dans le PATH.
    echo Installe Python depuis https://www.python.org/downloads/
    echo puis coche "Add Python to PATH" durant l'installation.
    echo.
    pause
    exit /b 1
)

echo Python utilise :
where python
echo.

echo Verification des dependances (peut prendre 1-2 minutes la premiere fois)...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo ERREUR : l'installation des dependances a echoue. Voir le message ci-dessus.
    echo.
    pause
    exit /b 1
)

echo.
echo Verification que Flask est bien installe...
python -c "import flask; print('Flask OK :', flask.__version__)"
if errorlevel 1 (
    echo.
    echo ERREUR : Flask ne s'est pas installe correctement.
    echo Essaie de lancer manuellement : python -m pip install flask
    echo.
    pause
    exit /b 1
)

echo.
echo Demarrage du serveur local sur http://127.0.0.1:5080
echo (Laisse cette fenetre ouverte pendant que tu utilises l'application)
echo.

start "" http://127.0.0.1:5080
python app.py

pause
