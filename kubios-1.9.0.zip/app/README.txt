COMPTES À RECEVOIR — APP LOCALE
=================================

CE QUE FAIT L'APP
- Une page web pour entrer de nouvelles factures et créer de nouveaux
  clients — utilisable depuis cet ordinateur ET, en même temps, depuis
  d'autres ordinateurs du même réseau (voir section ACCÈS RÉSEAU).
- Pour un client donné, elle génère un état de compte en PDF et peut créer
  un brouillon (ou envoyer directement) un courriel Outlook avec le PDF
  en pièce jointe. Les courriels sortent toujours via Outlook sur CET
  ordinateur, peu importe qui utilise l'app.

DÉMARRAGE AUTOMATIQUE AVEC WINDOWS (SERVICE)
- L'app peut être installée comme un vrai service Windows : elle démarre
  alors automatiquement à chaque démarrage de l'ordinateur, même avant
  qu'une session soit ouverte, sans fenêtre visible — plus besoin de
  double-cliquer start.bat.
- Installation (une seule fois) : clic droit sur "Installer_service.bat"
  → "Exécuter en tant qu'administrateur". Le script installe les
  dépendances, autorise le port 5080 dans le pare-feu, installe le service
  en démarrage automatique et le démarre tout de suite.
- ⚠️ IMPORTANT : dans ce mode, Outlook NE PEUT PAS être piloté
  automatiquement (le service tourne sous le compte "Système", qui n'a pas
  de session de bureau — c'est une limitation de Windows, pas de l'app).
  Va dans "Paramètres d'envoi" (connecté comme administrateur) et choisis
  le mode SMTP pour que l'envoi de courriels continue de fonctionner. Sans
  ce changement, les boutons d'envoi afficheront une erreur.
- Le journal du service (ce qu'affichait la fenêtre noire avant) est écrit
  dans "service.log" dans le dossier app\ — utile pour dépanner.
- Pour redémarrer le service après une modification : "Redemarrer_service.bat"
  (aussi en administrateur).
- Pour revenir à un démarrage manuel : "Desinstaller_service.bat" (en
  administrateur) retire le service ; utilise ensuite start.bat comme avant.
- Ne lance pas start.bat pendant que le service tourne (les deux ne peuvent
  pas utiliser le port 5080 en même temps).

LICENCE
- L'app nécessite maintenant une licence active pour fonctionner. Au tout
  premier démarrage (ou si la licence n'a jamais été activée), une page
  d'activation apparaît automatiquement : colle le code de licence reçu
  et clique sur "Activer la licence".
- Il existe trois types de licence : 30 jours, 1 an, ou à vie (n'expire
  jamais). C'est toi (le fournisseur) qui génères ces codes avec l'outil
  séparé "Générateur de licences" (voir son propre README) — l'app elle-
  même ne peut pas créer de licence, seulement en vérifier une.
- Quand une licence à durée limitée expire, l'app se bloque de nouveau
  automatiquement (même la page de connexion) et redemande un code — il
  suffit de coller un nouveau code sur la page d'activation qui réapparaît
  pour continuer.
- Un administrateur connecté peut en tout temps consulter la licence
  actuelle ou en activer une nouvelle (par exemple pour un renouvellement
  avant l'expiration) via le lien "Licence" en haut de la page. Un
  avertissement apparaît automatiquement quand il reste 14 jours ou moins
  avant l'expiration.
- Chaque activation de licence est inscrite dans le journal d'audit.

ACCÈS RÉSEAU (PLUSIEURS PERSONNES EN MÊME TEMPS)
- Cet ordinateur agit comme le serveur : il doit rester allumé et l'app
  (la fenêtre noire) doit rester ouverte pour que les autres puissent
  s'en servir.
- Au démarrage, la fenêtre noire affiche deux adresses :
    • http://127.0.0.1:5080            (pour cet ordinateur)
    • http://<ton IP locale>:5080      (pour les autres, ex: 192.168.1.42)
  Donne cette deuxième adresse aux collègues sur le même réseau — ils
  l'ouvrent simplement dans leur navigateur, comme un site web.
- La première fois, Windows va probablement demander d'autoriser l'app
  à travers le pare-feu : accepte pour le réseau "Privé".
- Plusieurs personnes peuvent ajouter des factures ou créer des clients
  en même temps sans problème.
- Un identifiant et un mot de passe sont maintenant demandés à chacun
  (voir section CONNEXION / UTILISATEURS ci-dessous).

CONNEXION / UTILISATEURS
- Au tout premier démarrage après cette mise à jour, un compte
  "admin" est créé automatiquement et son mot de passe temporaire
  s'affiche UNE SEULE FOIS dans la fenêtre noire — note-le tout de
  suite. Connecte-toi avec ce compte pour commencer.
- Une fois connecté en tant qu'administrateur, un lien "Utilisateurs"
  apparaît en haut de la page. Il permet de :
    • créer un compte pour chaque personne (nom d'utilisateur + mot
      de passe), avec ou sans droits d'administrateur;
    • réinitialiser le mot de passe de quelqu'un;
    • désactiver ou supprimer un compte;
    • rendre quelqu'un d'autre administrateur.
- Un utilisateur normal peut faire tout ce que l'app permet (clients,
  factures, courriels, synchronisation) mais n'a pas accès à la page
  "Utilisateurs". Seul un administrateur peut gérer les comptes.
- Change le mot de passe temporaire du compte "admin" dès que possible
  (page "Utilisateurs" → "Réinitialiser mot de passe" sur ta propre
  ligne) et donne un compte distinct à chaque personne plutôt que de
  partager le compte admin.
- Si tout le monde a oublié les mots de passe : arrête l'app, supprime
  le fichier app\data.db (⚠️ tu perdras aussi les clients/factures —
  fais d'abord une copie), relance start.bat : la base est reconstruite
  depuis Excel et un nouveau compte admin temporaire est généré.
- Un lien "Audit" apparaît aussi, réservé aux administrateurs : il liste
  les 1000 dernières actions faites dans l'app (créations, modifications,
  suppressions, factures marquées payées, rapports générés, envois de
  courriels, connexions/déconnexions, gestion des comptes) avec la date,
  l'heure et le nom de la personne qui l'a faite. Utile pour savoir qui
  a fait quoi. Une recherche et un filtre par type d'action sont
  disponibles sur cette page.

COMMENT ÇA MARCHE (IMPORTANT)
- La saisie (ajout de facture, nouveau client) se fait dans une petite
  base de données locale (data.db, dans le dossier app/) — c'est instantané
  (millisecondes), pas 20-30 secondes comme avant.
- Ton fichier Excel "Compte à recevoir.xlsx" reste le document "officiel"
  que tu peux ouvrir et consulter. Il est régénéré automatiquement à
  partir de cette base :
    • toutes les 3 minutes s'il y a eu des changements, en arrière-plan
      (sans bloquer ton travail), et
    • à tout moment avec le bouton "Synchroniser vers Excel" en haut
      de la page.
  Un point de couleur en haut à droite indique l'état :
    • vert = Excel à jour
    • orange = des changements ne sont pas encore dans Excel
    • bleu (clignotant) = synchronisation en cours
- Le PDF et l'envoi de courriel ne dépendent PAS d'Excel — ils utilisent
  directement la base rapide, donc ils sont toujours instantanés.

⚠️ NE MODIFIE PLUS LE FICHIER EXCEL À LA MAIN pendant que tu utilises
l'app. À la prochaine synchronisation, le contenu du fichier est
régénéré à partir de la base — tes changements manuels seraient écrasés.
Si tu dois faire une correction manuelle, fais-la dans l'app (ou
demande-moi d'ajouter la fonctionnalité qui manque).

AVANT DE COMMENCER
1) Ferme le fichier "Compte à recevoir.xlsx" dans Excel s'il est ouvert.
2) Assure-toi qu'Outlook (l'application de bureau) est installé et que
   tu es connecté — c'est ce qui envoie les courriels.
3) La base de données est créée automatiquement au tout premier démarrage
   à partir de ton Excel actuel (import unique, ~30 secondes). Après ça,
   tout est instantané.

DÉMARRAGE
- Double-clique sur "start.bat" dans ce dossier.
- Ton navigateur s'ouvre automatiquement sur la page.
- Laisse la fenêtre noire (l'invite de commandes) ouverte tant que tu
  utilises l'app. Pour arrêter, ferme simplement cette fenêtre — mais
  fais-le seulement quand le point de statut est VERT (Excel à jour),
  ou clique d'abord sur "Synchroniser vers Excel" pour ne rien perdre
  côté fichier Excel (la base de données, elle, garde toujours tout).

UTILISATION
- Onglet "Clients" : recherche un client, clique dessus pour voir ses
  factures, le solde par tranche d'âge, télécharger le PDF, créer un
  brouillon ou envoyer directement le courriel (voir aussi la section
  ENVOI DES COURRIELS : OUTLOOK OU SERVEUR SMTP ci-dessous).
- Dans la fiche d'un client, le bouton "Modifier le message" ouvre un
  encadré où tu peux changer l'objet et le texte du courriel (le message
  standard est déjà rempli — ajoute simplement tes commentaires où tu
  veux) avant de créer le brouillon ou d'envoyer. "Réinitialiser le
  message" remet le texte standard. Si tu ne touches à rien, le message
  habituel est utilisé comme avant.
- Onglet "Ajouter une facture" : choisis un client existant (ou tape un
  nouveau nom) et remplis les détails de la facture. Instantané.
- Onglet "Nouveau client" : crée un nouveau client, prêt à recevoir des
  factures. Instantané — l'onglet Excel correspondant est créé à la
  prochaine synchronisation.

PAIEMENTS PARTIELS ET FACTURES PAYÉES
- Sur chaque facture (dans la fiche d'un client), tu peux indiquer un
  paiement partiel déjà reçu (champ "Payé" en mode modification) ou
  cliquer sur "Facture payée" pour la marquer payée au complet d'un
  coup. Un badge "Partiel" ou "Payée" apparaît sur la ligne.
- Le solde restant (montant moins ce qui a été payé) est ce qui compte
  partout : la colonne "Solde" du client, les tranches d'âge (0-30,
  31-60, etc.), le rapport d'âge, et l'état de compte PDF — une facture
  payée au complet disparaît automatiquement de l'état de compte envoyé
  au client.
- "Facture payée" peut être annulé (le bouton devient "Annuler
  paiement") si c'était une erreur.
- Dans le fichier Excel, chaque onglet client a maintenant deux
  colonnes de plus : "Payé" (L) et "Solde" (M) — le solde est calculé
  automatiquement (Montant moins Payé) et c'est lui qui alimente les
  tranches d'âge et le total du Sommaire.

ENVOI DES COURRIELS : OUTLOOK OU SERVEUR SMTP
- Par défaut, les courriels sortent via Outlook installé sur cet
  ordinateur (comme avant).
- Un administrateur peut activer un serveur SMTP à la place, depuis le
  lien "Paramètres d'envoi" (visible seulement pour les admins). Avantage :
  tout le monde sur le réseau peut alors envoyer directement, sans dépendre
  d'Outlook ni de cet ordinateur en particulier.
- Pour configurer le SMTP : adresse du serveur, port, chiffrement
  (STARTTLS/SSL/aucun), nom d'utilisateur et mot de passe SMTP (si requis),
  et l'adresse courriel d'expédition. Un bouton "Tester la connexion"
  permet de vérifier avant d'enregistrer.
- ⚠️ En mode SMTP, il n'y a pas de "brouillon à réviser" (contrairement à
  Outlook) : le bouton "Créer le courriel (brouillon)" disparaît de
  l'app, et seul "Envoyer directement" reste disponible (avec confirmation
  avant l'envoi).
- Revenir à Outlook en tout temps depuis la même page "Paramètres d'envoi".
- Chaque changement de paramètres d'envoi est inscrit dans le journal
  d'audit (page "Audit").
- Chaque courriel (brouillon ou envoi direct, peu importe la méthode) est
  maintenant automatiquement mis en copie conforme invisible (CCI) à
  recevables@outillagesexpress.ca — une copie d'archive arrive donc dans
  cette boîte à chaque fois.
- Onglet "Rapports" → "Rapport d'envoi" : génère un PDF listant tous les
  courriels enregistrés (brouillons et envois) pour le mois choisi —
  client, courriel, montant, statut et note, avec un total général.

À SAVOIR
- Une copie de sécurité automatique du fichier Excel est faite avant
  chaque synchronisation, dans C:\DBouxpCR\Backups_auto\ (les 20
  dernières sont gardées).
- N'ouvre qu'une seule fenêtre de l'app à la fois (un seul start.bat en
  cours d'exécution).
- "Créer le courriel (brouillon)" ouvre le courriel dans Outlook pour que
  tu puisses le relire avant d'appuyer sur Envoyer toi-même — c'est le
  choix le plus sécuritaire.
- "Envoyer directement" envoie sans relecture — une confirmation
  t'est demandée avant.
- Chaque envoi (brouillon ou direct) est inscrit dans l'onglet LOG_ENVOIS
  du fichier Excel à la prochaine synchronisation.
- Les PDF générés sont sauvegardés dans C:\DBouxpCR\Etats_de_compte\
- La base de données (app\data.db) est maintenant la vraie référence :
  si un jour tu changes d'ordinateur ou veux repartir à zéro à partir
  d'Excel, supprime app\data.db et relance start.bat (elle sera
  recréée depuis le fichier Excel actuel).

À PERSONNALISER (optionnel)
Dans app.py, tout en haut, tu peux ajuster :
  COMPANY_NAME, COMPANY_EMAIL, COMPANY_PHONE, AUTO_SYNC_SECONDS
(le nom "Outillages Express" a été déduit de ton adresse
recevables@outillagesexpress.ca trouvée dans LOG_ENVOIS — confirme/ajuste
au besoin).

DÉPANNAGE
- "Impossible d'enregistrer" (lors d'une synchronisation) → ferme Excel
  s'il a le fichier ouvert, puis resynchronise.
- Erreur Outlook / COM → assure-toi qu'Outlook desktop est ouvert et
  que tu y es connecté.
- Le point de statut reste orange longtemps → clique sur "Synchroniser
  vers Excel" pour forcer une synchronisation immédiate.
