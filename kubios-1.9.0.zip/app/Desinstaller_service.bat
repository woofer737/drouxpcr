@echo off
cd /d "%~dp0"
echo ============================================
echo   Desinstallation du service Windows
echo   Comptes a recevoir - Outillages Express
echo ============================================
echo.
echo ATTENTION : cette fenetre doit etre lancee en tant qu'ADMINISTRATEUR
echo (clic droit sur ce fichier -^> "Executer en tant qu'administrateur").
echo.

net session >nul 2>nul
if errorlevel 1 (
    echo ERREUR : ce script doit etre execute en tant qu'administrateur.
    pause
    exit /b 1
)

python service.py stop
python service.py remove

echo.
echo Le service a ete arrete et retire. L'app ne redemarrera plus
echo automatiquement avec Windows. Utilise start.bat pour la relancer
echo manuellement au besoin.
echo.
pause
