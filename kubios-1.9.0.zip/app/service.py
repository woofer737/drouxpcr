# -*- coding: utf-8 -*-
"""
Service Windows — Comptes à recevoir (Outillages Express)

Permet à l'application de démarrer automatiquement avec Windows, avant même
qu'une session utilisateur soit ouverte, et de continuer à fonctionner en
arrière-plan sans fenêtre visible.

⚠️ IMPORTANT : dans ce mode, Outlook ne peut PAS être piloté automatiquement
(le compte "Système" qui exécute le service n'a pas de session de bureau
interactive — c'est une limitation de Windows/Outlook, pas de cette app).
Utilise le mode d'envoi SMTP (page "Paramètres d'envoi", réservée aux
administrateurs) pour que l'envoi de courriels continue de fonctionner.

Ne pas exécuter ce fichier directement pour un usage normal — passe plutôt
par "Installer_service.bat" / "Desinstaller_service.bat" dans ce dossier.
"""
import os
import sys
import traceback

import servicemanager
import win32event
import win32service
import win32serviceutil

HERE = os.path.dirname(os.path.abspath(__file__))
LOG_PATH = os.path.join(HERE, "service.log")


class ComptesARecevoirService(win32serviceutil.ServiceFramework):
    _svc_name_ = "ComptesARecevoirOE"
    _svc_display_name_ = "Comptes à recevoir - Outillages Express"
    _svc_description_ = ("Serveur web local pour la gestion des comptes à recevoir "
                          "(Outillages Express). Démarre automatiquement avec Windows.")

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.stop_event = win32event.CreateEvent(None, 0, 0, None)

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        win32event.SetEvent(self.stop_event)
        servicemanager.LogInfoMsg("Comptes à recevoir : arrêt du service demandé.")
        # Le serveur web intégré (Flask/werkzeug) ne fournit pas de mécanisme
        # d'arrêt propre depuis un autre thread ; on met fin au processus
        # directement. Sans danger pour les données : chaque écriture SQLite
        # est déjà validée (commit) immédiatement, il n'y a rien "en vol".
        os._exit(0)

    def SvcDoRun(self):
        # Redirige stdout/stderr vers un fichier de log, car il n'y a pas de
        # console dans un service Windows (un simple print() planterait sinon).
        try:
            log_file = open(LOG_PATH, 'a', encoding='utf-8', buffering=1)
            sys.stdout = log_file
            sys.stderr = log_file
        except Exception:
            pass

        servicemanager.LogMsg(servicemanager.EVENTLOG_INFORMATION_TYPE,
                               servicemanager.PYS_SERVICE_STARTED,
                               (self._svc_name_, ''))
        print("=" * 60)
        print("Démarrage du service Comptes à recevoir")
        print("=" * 60)
        try:
            sys.path.insert(0, HERE)
            import app as appmodule
            appmodule.start_app()
        except SystemExit:
            pass
        except Exception:
            print("ERREUR FATALE dans le service :")
            print(traceback.format_exc())
            servicemanager.LogErrorMsg("Comptes à recevoir : erreur fatale, voir service.log")
            raise


if __name__ == '__main__':
    win32serviceutil.HandleCommandLine(ComptesARecevoirService)
