@echo off
cd /d "%~dp0"
echo ============================================
echo   Installation du service Windows
echo   Comptes a recevoir - Outillages Express
echo ============================================
echo.
echo ATTENTION : cette fenetre doit etre lancee en tant qu'ADMINISTRATEUR
echo (clic droit sur ce fichier -^> "Executer en tant qu'administrateur").
echo.

net session >nul 2>nul
if errorlevel 1 (
    echo ERREUR : ce script doit etre execute en tant qu'administrateur.
    echo Ferme cette fenetre, puis clic droit sur "Installer_service.bat"
    echo et choisis "Executer en tant qu'administrateur".
    echo.
    pause
    exit /b 1
)

where python >nul 2>nul
if errorlevel 1 (
    echo ERREUR : Python n'est pas installe ou pas dans le PATH.
    pause
    exit /b 1
)

echo Verification des dependances...
python -m pip install --quiet --upgrade pip
python -m pip install --quiet -r requirements.txt
if errorlevel 1 (
    echo ERREUR : l'installation des dependances a echoue.
    pause
    exit /b 1
)

echo.
echo Autorisation du port 5080 dans le pare-feu Windows...
netsh advfirewall firewall show rule name="Comptes a recevoir (5080)" >nul 2>nul
if errorlevel 1 (
    netsh advfirewall firewall add rule name="Comptes a recevoir (5080)" dir=in action=allow protocol=TCP localport=5080 >nul
)

echo.
echo Installation du service (demarrage automatique au demarrage de Windows)...
python service.py --startup auto install
if errorlevel 1 (
    echo.
    echo ERREUR : l'installation du service a echoue. Voir le message ci-dessus.
    echo Astuce : si l'erreur mentionne "pywin32", essaie d'abord :
    echo     python -m pywin32_postinstall -install
    echo puis relance ce fichier.
    pause
    exit /b 1
)

echo.
echo Demarrage du service...
python service.py start

echo.
echo ============================================
echo   Termine !
echo ============================================
echo L'app va maintenant demarrer automatiquement a chaque demarrage de
echo Windows, meme avant qu'une session soit ouverte, sans fenetre visible.
echo.
echo Acces : http://127.0.0.1:5080  (ou l'adresse reseau habituelle)
echo Journal du service : service.log dans ce dossier.
echo.
echo IMPORTANT : dans ce mode, Outlook ne peut pas envoyer les courriels
echo automatiquement (limitation de Windows). Va dans "Parametres d'envoi"
echo (une fois connecte en tant qu'administrateur) et choisis le mode SMTP
echo pour que l'envoi de courriels continue de fonctionner.
echo.
pause
