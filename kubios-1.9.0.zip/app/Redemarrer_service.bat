@echo off
cd /d "%~dp0"
echo Redemarrage du service Comptes a recevoir...

net session >nul 2>nul
if errorlevel 1 (
    echo ERREUR : ce script doit etre execute en tant qu'administrateur.
    pause
    exit /b 1
)

python service.py restart
echo.
echo Termine. Journal : service.log dans ce dossier.
pause
