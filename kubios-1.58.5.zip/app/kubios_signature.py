# -*- coding: utf-8 -*-
"""Signature des paquets de mise à jour (1.56.0).

Le fournisseur signe chaque paquet kubios-x.y.z.zip avec la MÊME clé privée Ed25519 que les licences
(gardée sur son poste, jamais livrée). La signature est rangée dans le commentaire du fichier zip :
    KUBIOS-SIG1|<version>|<signature base64url>
Message signé : b"KUBIOS-PAQUET-1|<version>|<sha256 du zip sans son commentaire>".
Le préfixe distingue ce message de celui d'une licence : une signature de licence ne peut jamais
servir de signature de paquet, ni l'inverse.

Kubios vérifie avec la clé PUBLIQUE de licensing.py : un paquet modifié, même d'un octet, est refusé."""
import base64
import hashlib
import re

SIG_PREFIX = b'KUBIOS-SIG1|'
MSG_PREFIX = b'KUBIOS-PAQUET-1|'
_EOCD = b'PK\x05\x06'

__all__ = ['package_message', 'split_zip_comment', 'verify_package_signature']


def split_zip_comment(data):
    """Retourne (zip_sans_commentaire, commentaire). Le zip sans commentaire est celui qui est signé."""
    i = data.rfind(_EOCD)
    while i >= 0:
        if i + 22 <= len(data):
            n = int.from_bytes(data[i + 20:i + 22], 'little')
            if i + 22 + n == len(data):
                return data[:i + 20] + b'\x00\x00', data[i + 22:]
        i = data.rfind(_EOCD, 0, i)
    raise ValueError("fin du zip introuvable")


def package_message(version, stripped):
    return MSG_PREFIX + version.encode('ascii') + b'|' + hashlib.sha256(stripped).hexdigest().encode('ascii')


def _b64d(s):
    return base64.urlsafe_b64decode(s + '=' * (-len(s) % 4))


def verify_package_signature(data, expected_version=None):
    """Vérifie la signature d'un paquet (contenu du fichier zip).
    Retourne {'status': 'signed'|'unsigned'|'invalid', 'version': ..., 'reason': ...}."""
    try:
        stripped, comment = split_zip_comment(data)
    except ValueError:
        return {'status': 'invalid', 'version': None, 'reason': "Le fichier n'est pas un zip valide."}
    if not comment.startswith(SIG_PREFIX):
        return {'status': 'unsigned', 'version': None, 'reason': "Ce paquet n'est pas signé par le fournisseur."}
    parts = comment.split(b'|')
    if len(parts) != 3 or not re.fullmatch(rb'\d+(\.\d+){1,3}', parts[1]):
        return {'status': 'invalid', 'version': None, 'reason': "Signature du paquet illisible."}
    version = parts[1].decode('ascii')
    try:
        from licensing import _get_public_key
        _get_public_key().verify(_b64d(parts[2].decode('ascii')), package_message(version, stripped))
    except Exception:
        return {'status': 'invalid', 'version': version,
                'reason': "La signature ne correspond pas : le paquet a été modifié ou ne vient pas du fournisseur."}
    if expected_version and version != expected_version:
        return {'status': 'invalid', 'version': version,
                'reason': f"La signature est celle de la v{version}, mais le paquet contient la v{expected_version}."}
    return {'status': 'signed', 'version': version, 'reason': ''}
