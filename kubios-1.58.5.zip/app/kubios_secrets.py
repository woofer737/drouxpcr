# -*- coding: utf-8 -*-
"""Chiffrement des secrets enregistrés par Kubios (1.56.0).

Les mots de passe et jetons des services branchés (SMTP, Microsoft 365, Lightspeed, Shopify) et la clé
des sessions ne sont plus gardés en clair dans data.db ni dans les sauvegardes :
  - sous Windows : DPAPI, portée « ordinateur ». Seul CE PC peut les déchiffrer, que Kubios roule en
    service ou avec start.bat. Une copie de data.db ou d'une sauvegarde sur un autre ordinateur ne les révèle pas ;
  - si DPAPI n'est pas disponible : AES-GCM avec une clé gardée dans un fichier HORS du dossier de
    l'application et hors des sauvegardes (_kubios_cle_secrets.key, à côté du dossier app).
Valeur enregistrée : « enc1:dpapi:<base64> » ou « enc1:aes:<base64> ». Une ancienne valeur en clair est
encore lue, puis rechiffrée au démarrage (migrate_secrets).

Conséquence voulue : après une restauration sur un AUTRE ordinateur, ces secrets sont à saisir de nouveau
(Courriels, Lightspeed, Boutique en ligne). Kubios le signale dans Santé du système."""
import base64
import os
import sys
import threading
from pathlib import Path

PREFIX = 'enc1:'
_ENTROPY = b'Kubios-secrets-v1'
KEY_FILE = Path(__file__).resolve().parent.parent / '_kubios_cle_secrets.key'
_sec_state = {'scheme': None, 'failures': 0, 'last_failure': None}
_sec_lock = threading.Lock()

__all__ = ['SECRET_KEYS', 'is_encrypted', 'protect', 'secrets_status', 'unprotect']

# Clés de la table meta qui contiennent un secret
SECRET_KEYS = frozenset({'smtp_password', 'm365_secret', 'ls_client_secret', 'ls_refresh_token', 'shopify_cfg', 'secret_key', 'heartbeat_url'})


# ---------------------------------------------------------------- DPAPI (Windows)

def _dpapi(data, protect):
    import ctypes
    from ctypes import wintypes

    class BLOB(ctypes.Structure):
        _fields_ = [('cbData', wintypes.DWORD), ('pbData', ctypes.POINTER(ctypes.c_char))]

    def blob(b):
        buf = ctypes.create_string_buffer(b, len(b))
        return BLOB(len(b), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), buf

    crypt32, kernel32 = ctypes.windll.crypt32, ctypes.windll.kernel32
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    inp, _b1 = blob(data)
    ent, _b2 = blob(_ENTROPY)
    out = BLOB()
    flags = 0x1 | (0x4 if protect else 0)          # UI_FORBIDDEN | LOCAL_MACHINE (portée ordinateur)
    if protect:
        ok = crypt32.CryptProtectData(ctypes.byref(inp), ctypes.c_wchar_p('Kubios'), ctypes.byref(ent), None, None, flags, ctypes.byref(out))
    else:
        ok = crypt32.CryptUnprotectData(ctypes.byref(inp), None, ctypes.byref(ent), None, None, flags, ctypes.byref(out))
    if not ok:
        raise OSError(f"DPAPI : erreur {ctypes.GetLastError()}")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        kernel32.LocalFree(ctypes.cast(out.pbData, ctypes.c_void_p))


# ---------------------------------------------------------------- AES-GCM (clé dans un fichier hors de l'application)

def _aes_key(create=True):
    if KEY_FILE.exists():
        k = base64.b64decode(KEY_FILE.read_bytes().strip())
        if len(k) == 32:
            return k
    if not create:
        raise OSError("clé de chiffrement introuvable")
    k = os.urandom(32)
    KEY_FILE.write_bytes(base64.b64encode(k))
    try:
        os.chmod(KEY_FILE, 0o600)
    except OSError:
        pass
    return k


def _aes(data, protect):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    if protect:
        nonce = os.urandom(12)
        return nonce + AESGCM(_aes_key(True)).encrypt(nonce, data, _ENTROPY)
    return AESGCM(_aes_key(False)).decrypt(data[:12], data[12:], _ENTROPY)


def _scheme():
    """DPAPI si Windows l'offre et qu'un aller-retour réussit ; sinon AES."""
    with _sec_lock:
        if _sec_state['scheme'] is None:
            scheme = 'aes'
            if sys.platform == 'win32':
                try:
                    if _dpapi(_dpapi(b'test', True), False) == b'test':
                        scheme = 'dpapi'
                except Exception:
                    pass
            _sec_state['scheme'] = scheme
        return _sec_state['scheme']


# ---------------------------------------------------------------- interface

def is_encrypted(value):
    return isinstance(value, str) and value.startswith(PREFIX)


def protect(text):
    """Chiffre un texte. Vide → vide (rien à protéger)."""
    if text is None or text == '' or is_encrypted(text):
        return text
    raw = str(text).encode('utf-8')
    scheme = _scheme()
    blob = _dpapi(raw, True) if scheme == 'dpapi' else _aes(raw, True)
    return f"{PREFIX}{scheme}:" + base64.b64encode(blob).decode('ascii')


def unprotect(value, default=None):
    """Déchiffre une valeur enregistrée. Ancienne valeur en clair → telle quelle.
    Impossible à déchiffrer (ex. base restaurée sur un autre PC) → default, et c'est noté."""
    if not is_encrypted(value):
        return value
    try:
        scheme, _, b64 = value[len(PREFIX):].partition(':')
        blob = base64.b64decode(b64)
        raw = _dpapi(blob, False) if scheme == 'dpapi' else _aes(blob, False)
        return raw.decode('utf-8')
    except Exception as e:
        with _sec_lock:
            _sec_state['failures'] += 1
            _sec_state['last_failure'] = str(e)[:200]
        return default


def secrets_status():
    return {'scheme': _scheme(), 'failures': _sec_state['failures'], 'last_failure': _sec_state['last_failure']}
