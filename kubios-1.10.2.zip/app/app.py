# -*- coding: utf-8 -*-
"""
App locale de gestion des Comptes à recevoir.

Architecture (v2 — rapide) :
- Une base SQLite locale (data.db) est la source de données pour l'app :
  toutes les lectures/écritures (ajout de facture, nouveau client) sont
  quasi instantanées.
- Le fichier "Compte à recevoir.xlsx" reste le document "officiel" que tu
  peux ouvrir dans Excel — il est régénéré à partir de la base SQLite,
  soit automatiquement en arrière-plan (toutes les quelques minutes),
  soit à la demande (bouton "Synchroniser vers Excel").
- Au tout premier démarrage, toutes les données de l'Excel existant sont
  importées une seule fois dans la base (ça prend ~30s la première fois
  seulement). Ensuite, tout est instantané.

IMPORTANT : une fois l'app utilisée, la base SQLite devient la référence.
Si tu modifies le fichier Excel à la main entre deux synchronisations, ces
changements seront écrasés à la prochaine synchronisation. Fais tes
changements dans l'app plutôt que dans Excel.

Démarrage : double-cliquer sur start.bat (voir README.txt)
"""
import os
import re
import io
import csv
import sys
import json
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path

from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash

import openpyxl
from openpyxl.utils import get_column_letter

import licensing

# ============================================================
# CONFIGURATION
# ============================================================
BASE_DIR = Path(__file__).resolve().parent.parent  # C:\DBouxpCR
EXCEL_PATH = BASE_DIR / "Compte à recevoir.xlsx"
PDF_DIR = BASE_DIR / "Etats_de_compte"
PDF_DIR.mkdir(exist_ok=True)
DB_PATH = Path(__file__).resolve().parent / "data.db"

APP_PORT = int(os.environ.get("APP_PORT", "5080"))

AUTO_SYNC_SECONDS = 180  # synchronise automatiquement vers Excel toutes les 3 minutes s'il y a des changements

# Valeurs par défaut (utilisées tant que rien n'a été personnalisé depuis le
# module Administration). Les valeurs effectives sont lues dynamiquement via
# les fonctions get_company_name()/get_company_email()/... ci-dessous, qui
# consultent d'abord la table `meta` (personnalisation admin) avant de
# retomber sur ces constantes.
COMPANY_NAME_DEFAULT = "Outillages Express"
COMPANY_EMAIL_DEFAULT = "recevables@outillagesexpress.ca"
COMPANY_PHONE_DEFAULT = ""  # optionnel, à remplir
PDF_FOOTER_MESSAGE_DEFAULT = "Merci de votre confiance."
EMAIL_CLOSING_MESSAGE_DEFAULT = "Merci de votre attention."

LOGO_PATH = Path(__file__).resolve().parent / "static" / "logo.png"
LOGO_DEFAULT_BACKUP_PATH = Path(__file__).resolve().parent / "static" / "logo_default.png"


def get_company_name():
    return (meta_get('company_name') or COMPANY_NAME_DEFAULT).strip() or COMPANY_NAME_DEFAULT


def get_company_email():
    return (meta_get('company_email') or COMPANY_EMAIL_DEFAULT).strip()


def get_company_phone():
    return (meta_get('company_phone') or COMPANY_PHONE_DEFAULT).strip()


def get_pdf_footer_message():
    return (meta_get('pdf_footer_message') or PDF_FOOTER_MESSAGE_DEFAULT).strip() or PDF_FOOTER_MESSAGE_DEFAULT


def get_email_closing_message():
    msg = meta_get('email_closing_message')
    return msg if msg is not None and msg.strip() else EMAIL_CLOSING_MESSAGE_DEFAULT


def get_sender_signature():
    email = get_company_email()
    name = get_company_name()
    return f"{name}\n{email}" if email else name


# Nom du LOGICIEL lui-même (affiché sur l'écran de connexion) — distinct du
# nom de l'entreprise (personnalisable via le module Administration) qui
# reste utilisé pour les états de compte, courriels et documents envoyés
# aux clients.
APP_NAME = "Kubios"

# ============================================================
# Version du logiciel et historique des changements
# ------------------------------------------------------------
# À chaque modification livrée, on ajoute une nouvelle entrée en haut de
# CHANGELOG et on augmente APP_VERSION. La page "Mises à jour" (admin)
# affiche cette liste — c'est la source de vérité pour savoir ce qui a
# changé et à quelle version l'application installée correspond.
# ============================================================
APP_VERSION = "1.10.2"

CHANGELOG = [
    {
        "version": "1.10.2",
        "date": "2026-10-11",
        "changes": [
            "Connexion Lightspeed : Lightspeed exige une adresse de retour en https://. "
            "L'adresse proposée est maintenant https://localhost/kubios-lightspeed (la "
            "même pour le test et la prod). Après l'autorisation, le navigateur affiche "
            "une page d'erreur : il suffit de copier l'adresse de la barre d'adresse et "
            "de la coller dans Administration → Lightspeed pour terminer la connexion, "
            "à partir de n'importe quel poste.",
        ],
    },
    {
        "version": "1.10.1",
        "date": "2026-10-11",
        "changes": [
            "Comptes de crédit : une sauvegarde est prise automatiquement avant chaque "
            "importation (réinitialisation de la liste, import des mouvements, "
            "synchronisation Lightspeed manuelle ou automatique). Si la sauvegarde "
            "échoue, l'importation est annulée.",
            "Nouvelle section « Sauvegardes avant importation » : un administrateur "
            "peut remettre les comptes de crédit et leur historique exactement comme "
            "avant une mauvaise importation. L'état actuel est sauvegardé juste avant, "
            "donc une restauration peut elle aussi être annulée. Les comptes à recevoir "
            "ne sont pas touchés.",
            "Une synchronisation sans aucun changement ne garde pas de sauvegarde ; "
            "les 60 plus récentes sont conservées (dossier Backups_comptes_credit).",
        ],
    },
    {
        "version": "1.10.0",
        "date": "2026-10-11",
        "changes": [
            "Comptes de crédit : synchronisation directe avec Lightspeed R-Series "
            "(API). Plus besoin d'exporter le fichier « credit_account_listings » : "
            "le bouton « Synchroniser maintenant » lit les comptes de crédit dans "
            "Lightspeed et met à jour la limite, le montant dû et le dépôt de chaque "
            "client (un changement de solde est inscrit dans l'historique).",
            "Chaque compte Kubios est maintenant relié à son compte Lightspeed par son "
            "numéro : les clients portant le même nom ne se mélangent plus. À la "
            "première synchronisation, l'association se fait par nom ; les homonymes "
            "sont listés dans « Comptes Lightspeed à associer » pour être reliés à la main.",
            "Administration → Lightspeed : Client ID / secret de l'application "
            "Lightspeed, bouton « Connecter à Lightspeed », test de connexion, sens du "
            "solde (détecté automatiquement à la première synchronisation) et "
            "synchronisation automatique quotidienne à l'heure choisie.",
            "Les cartes-cadeaux et les comptes archivés de Lightspeed sont ignorés ; "
            "les comptes « Ne pas synchroniser » sont reliés mais jamais modifiés.",
        ],
    },
    {
        "version": "1.9.3",
        "date": "2026-10-08",
        "changes": [
            "Comptes à recevoir : une facture à montant négatif (note de crédit) "
            "n'est plus affichée « Payée ». Elle porte maintenant un badge bleu "
            "« Crédit », avec son montant et son solde en bleu. Le bouton devient "
            "« Crédit appliqué » (le crédit a été utilisé ou remboursé — son solde "
            "passe à 0, badge « Crédit appliqué ») et peut être annulé.",
            "Dans la liste des clients, un client dont le solde total est négatif "
            "affiche un badge bleu « Crédit » au lieu de « À jour ».",
        ],
    },
    {
        "version": "1.9.2",
        "date": "2026-10-08",
        "changes": [
            "Comptes de crédit : la fiche d'un client permet maintenant de "
            "modifier le compte (nom, limite de crédit, montant dû, dépôt, "
            "notes) et de le supprimer (administrateurs seulement, avec son "
            "historique).",
            "Chaque mouvement de l'historique peut être modifié (date, type, "
            "vente, montant) ou supprimé s'il est en erreur. Le solde du client "
            "est ajusté automatiquement de la différence (une confirmation "
            "indique le montant).",
            "Nouvelle case « Ne pas synchroniser avec l'importation » sur chaque "
            "compte : l'import des mouvements (instantané mensuel ou journal de "
            "transactions) ne touche plus à ce compte et garde tes valeurs. La "
            "réinitialisation complète de la liste, elle, remplace quand même "
            "tout. Un badge « Non synchronisé » s'affiche dans la liste.",
            "Toutes ces actions sont inscrites au journal d'audit.",
        ],
    },
    {
        "version": "1.9.1",
        "date": "2026-10-08",
        "changes": [
            "Comptes de crédit : « Importer / réinitialiser la liste des "
            "clients » accepte maintenant aussi l'export Lightspeed "
            "« credit_account_listings » (.csv en anglais, colonnes First Name, "
            "Last Name, Credit Limit, Debt), en plus du format en français "
            "(Prénom / Entreprise, Nom, Limite de crédit, Montant dû, Dépôt). "
            "Le montant dû vient de la colonne « Debt » ; un « Debt » négatif "
            "(crédit en faveur du client) est importé comme dépôt, avec un "
            "montant dû à 0. L'import mensuel des mouvements applique la même "
            "règle : les clients en crédit ne sont plus comptés deux fois "
            "(solde négatif + dépôt).",
            "Correction : un montant écrit à la française dans un fichier "
            "importé (ex. « 1 234,56 $ ») était lu comme 123 456 $ ; la "
            "virgule décimale est maintenant reconnue.",
        ],
    },
    {
        "version": "1.9.0",
        "date": "2026-10-08",
        "changes": [
            "Comptes à recevoir : nouveau bouton « Modifier le client » dans la "
            "fiche d'un client. Il permet de changer le nom, le courriel, le "
            "téléphone et l'adresse d'un client existant. Lors d'un changement "
            "de nom, toutes ses factures suivent automatiquement et son onglet "
            "dans le fichier Excel est renommé à la prochaine synchronisation "
            "(aucun onglet en double). Chaque modification est inscrite au "
            "journal d'audit avec l'ancienne et la nouvelle valeur.",
            "La fiche d'un client affiche maintenant son courriel et son "
            "téléphone sous son nom.",
        ],
    },
    {
        "version": "1.8.9",
        "date": "2026-10-06",
        "changes": [
            "Licence : l'expiration des licences de 30 jours et d'un an ne "
            "dépend plus seulement de la date de l'ordinateur. L'app vérifie "
            "la date réelle sur Internet (au démarrage puis toutes les 6 "
            "heures) et mémorise la date la plus récente qu'elle a vue. Si la "
            "date de l'ordinateur est reculée de plus d'un jour, l'app se "
            "bloque avec un message demandant de corriger la date, et "
            "l'événement est inscrit au journal d'audit. Sans Internet, la "
            "date mémorisée sert de référence. Les licences à vie ne sont "
            "pas touchées.",
        ],
    },
    {
        "version": "1.8.8",
        "date": "2026-09-30",
        "changes": [
            "Nouveau module « Administration » (réservé aux administrateurs, "
            "accessible depuis la page d'accueil) permettant de personnaliser "
            "le logiciel : nom et courriel de l'entreprise, logo affiché sur "
            "les états de compte et rapports PDF (avec retour possible au "
            "logo par défaut), ainsi que les messages de conclusion affichés "
            "au bas des PDF et dans les courriels.",
        ],
    },
    {
        "version": "1.8.7",
        "date": "2026-09-30",
        "changes": [
            "Ajout d'une page d'accueil (menu) après la connexion : elle "
            "propose des tuiles vers chaque volet accessible (Comptes à "
            "recevoir, Comptes de crédit, Utilisateurs, Audit, Paramètres "
            "d'envoi, Mises à jour, Licence) au lieu d'atterrir directement "
            "sur les comptes à recevoir. Les liens « Accueil » sur les "
            "autres pages ramènent maintenant à ce menu.",
        ],
    },
    {
        "version": "1.8.6",
        "date": "2026-09-30",
        "changes": [
            "Ajout d'un avertissement légal (« Accès autorisé seulement ») "
            "sur la page de connexion, rappelant que le système est réservé "
            "aux personnes autorisées et que les activités peuvent être "
            "surveillées et auditées.",
        ],
    },
    {
        "version": "1.8.5",
        "date": "2026-09-30",
        "changes": [
            "Le style et les couleurs de la nouvelle page de connexion "
            "(Kubios) s'appliquent maintenant à tout le logiciel : en-tête "
            "en dégradé bleu avec le logo sur chaque page, boutons "
            "principaux assortis — sur l'écran principal, Utilisateurs, "
            "Audit, Paramètres d'envoi, Mises à jour, Licence et Comptes de "
            "crédit.",
        ],
    },
    {
        "version": "1.8.4",
        "date": "2026-09-30",
        "changes": [
            "Comptes de crédit : « Importer / réinitialiser la liste des "
            "clients » (qui remplace toute la liste et efface l'historique "
            "des mouvements) est maintenant réservé aux administrateurs — "
            "les utilisateurs avec seulement l'accès « Comptes de crédit » "
            "peuvent encore importer les mouvements/instantanés mensuels et "
            "consulter les rapports, mais plus réinitialiser la liste.",
        ],
    },
    {
        "version": "1.8.3",
        "date": "2026-09-30",
        "changes": [
            "Nouvelle page de connexion : le logiciel s'appelle maintenant "
            "« Kubios » (nouveau logo et design revus) — ce nom n'apparaît "
            "qu'à l'écran de connexion et n'affecte pas les états de compte, "
            "courriels ou documents envoyés aux clients, qui continuent "
            "d'afficher le nom de l'entreprise comme avant.",
        ],
    },
    {
        "version": "1.8.2",
        "date": "2026-09-30",
        "changes": [
            "Ajout d'un filtre « Cacher les clients à 0$ » sur la liste des "
            "comptes de crédit (limite, solde et dépôt tous à zéro).",
            "Ajout de l'export PDF des comptes de crédit (logo en haut à "
            "droite, comme les autres rapports) — soit la liste actuelle, "
            "soit le rapport exact d'une importation passée.",
            "Chaque importation (liste initiale, instantané mensuel ou "
            "journal de transactions) garde maintenant sa propre photo des "
            "soldes, téléchargeable en PDF n'importe quand — même s'il y a "
            "plusieurs importations dans le même mois, chacune garde son "
            "propre rapport.",
            "Ajout d'une option pour exclure les clients à 0$ (limite, solde "
            "et dépôt) des PDF générés, autant pour la liste actuelle que "
            "pour le rapport d'une importation passée.",
        ],
    },
    {
        "version": "1.8.1",
        "date": "2026-09-29",
        "changes": [
            "Correction de l'import mensuel des comptes de crédit : le fichier "
            "Lightspeed réellement reçu chaque mois (« credit_account_listings... "
            ".csv ») est un instantané des soldes actuels (First Name, Last Name, "
            "Credit Limit, Debt), pas un journal de transactions — il causait "
            "l'erreur « Colonnes Customer et Amount introuvables ». Le format est "
            "maintenant détecté automatiquement : instantané mensuel (met à jour "
            "les soldes) ou journal de transactions (ajoute des mouvements), les "
            "deux dans le même bouton « Importer les mouvements du mois ».",
            "Les montants avec le symbole $ (ex. « $150000.00 », « $-219.30 ») "
            "sont maintenant lus correctement dans tous les imports de comptes de "
            "crédit.",
        ],
    },
    {
        "version": "1.8.0",
        "date": "2026-09-29",
        "changes": [
            "Ajout d'un nouveau volet « Comptes de crédit » (Lightspeed), "
            "distinct des comptes à recevoir : liste des clients avec limite "
            "de crédit, solde dû et dépôt, avec alerte si un client dépasse "
            "sa limite.",
            "Import initial de la liste des comptes de crédit depuis un "
            "fichier Excel ou CSV.",
            "Import mensuel des mouvements (transactions) exportés de "
            "Lightspeed en CSV — met à jour les soldes automatiquement, sans "
            "risque de doublons si le même fichier est réimporté par erreur.",
        ],
    },
    {
        "version": "1.7.0",
        "date": "2026-09-29",
        "changes": [
            "Ajout de la date de chaque paiement (en plus du montant) — le "
            "rapport d'âge des comptes à recevoir pour un mois passé (ex. au "
            "31-07-2026) ignore maintenant correctement les paiements reçus "
            "après cette date, au lieu de les soustraire par erreur.",
            "Les factures et le tableau des clients affichent maintenant la "
            "date du paiement partiel ou complet déjà reçu.",
        ],
    },
    {
        "version": "1.6.4",
        "date": "2026-09-27",
        "changes": [
            "Installation d'une mise à jour : demande maintenant explicitement "
            "si cet ordinateur redémarre l'application comme service Windows "
            "ou manuellement via start.bat, au lieu de le deviner tout seul — "
            "utile quand plusieurs ordinateurs n'utilisent pas le même mode.",
        ],
    },
    {
        "version": "1.6.3",
        "date": "2026-09-27",
        "changes": [
            "Correctif important : l'installation automatique des mises à jour "
            "ne fonctionnait pas quand l'application tournait comme service "
            "Windows — le service s'arrêtait bien, mais ne redémarrait jamais "
            "tout seul et le code n'était pas remplacé, à cause d'un chemin "
            "Python incorrect utilisé en arrière-plan dans ce mode précis.",
        ],
    },
    {
        "version": "1.6.2",
        "date": "2026-09-27",
        "changes": [
            "Correctif : la vérification des mises à jour pouvait afficher "
            "« Réponse invalide du serveur de mises à jour » si le fichier de "
            "version en ligne contenait un caractère invisible en début de "
            "fichier ; le message d'erreur précise maintenant la cause exacte.",
        ],
    },
    {
        "version": "1.6.1",
        "date": "2026-09-27",
        "changes": [
            "Correctif : le résultat de « Vérifier les mises à jour » (nouvelle "
            "version disponible ou déjà à jour) ne s'affichait pas à l'écran "
            "même si la vérification fonctionnait correctement en arrière-plan.",
        ],
    },
    {
        "version": "1.6.0",
        "date": "2026-09-27",
        "changes": [
            "Installation automatique des mises à jour : le bouton « Installer "
            "maintenant » télécharge et applique lui-même une mise à jour "
            "détectée, puis redémarre l'application (les données du client — "
            "base de données, fichier Excel, PDF — ne sont jamais touchées).",
        ],
    },
    {
        "version": "1.5.0",
        "date": "2026-09-27",
        "changes": [
            "Ajout d'accès particuliers par utilisateur (Rapports, Audit, Licence, "
            "Paramètres d'envoi, Mises à jour) — gérable depuis la page Utilisateurs, "
            "en plus du statut administrateur.",
            "Ajout de la vérification en ligne des mises à jour (bouton « Vérifier "
            "les mises à jour »).",
        ],
    },
    {
        "version": "1.4.0",
        "date": "2026-09-27",
        "changes": [
            "Ajout d'une page « Mises à jour » (menu admin) qui affiche la version "
            "installée et l'historique complet des changements.",
        ],
    },
    {
        "version": "1.3.0",
        "date": "2026-09-26",
        "changes": [
            "Port de l'application changé de 5050 à 5080 (configurable via APP_PORT).",
            "Remplacement du serveur de développement Flask par un serveur de "
            "production (Waitress) — plus stable pour un usage continu.",
        ],
    },
    {
        "version": "1.2.0",
        "date": "2026-09-26",
        "changes": [
            "Ajout du démarrage automatique avec Windows (service Windows en "
            "arrière-plan, sans fenêtre visible).",
            "Préparation des outils pour produire un installateur Windows "
            "autonome (Setup.exe).",
        ],
    },
    {
        "version": "1.1.0",
        "date": "2026-09-26",
        "changes": [
            "Ajout du système de licence (activation par code — 30 jours, 1 an "
            "ou à vie — avec redemande automatique à l'expiration).",
            "Ajout du rapport mensuel d'envoi de courriels.",
            "Copie automatique (CCI) de chaque courriel envoyé vers "
            f"{COMPANY_EMAIL_DEFAULT}.",
            "Possibilité de modifier le sujet et le message avant l'envoi d'un "
            "état de compte.",
        ],
    },
    {
        "version": "1.0.0",
        "date": None,
        "changes": [
            "Version de référence : gestion des comptes à recevoir, paiements "
            "partiels, envoi des états de compte par Outlook ou par serveur "
            "SMTP, journal d'audit, gestion des utilisateurs et permissions.",
        ],
    },
]

# URL publique (dépôt GitHub géré par Claude) où est déposé, à chaque mise à
# jour livrée, un petit fichier version.json contenant le numéro de version
# le plus récent et son changelog. Ne contient aucune donnée d'entreprise.
UPDATE_CHECK_URL = "https://raw.githubusercontent.com/woofer737/drouxpcr/main/version.json"


def _version_tuple(v):
    """Convertit "1.4.0" en (1, 4, 0) pour pouvoir comparer deux versions."""
    return tuple(int(part) for part in v.strip().split('.'))


# ------------------------------------------------------------
# Installation automatique des mises à jour
# ------------------------------------------------------------
# APP_DIR = C:\DBouxpCR\app (contient app.py, templates, static — remplacé
# par une mise à jour). BASE_DIR = C:\DBouxpCR (contient aussi les données
# du client : data.db, le fichier Excel, les PDF — jamais touchées).
APP_DIR = Path(__file__).resolve().parent
UPDATE_STAGING_DIR = BASE_DIR / "_update_staging"
UPDATE_ZIP_PATH = BASE_DIR / "_update_download.zip"
UPDATE_LOG_PATH = BASE_DIR / "_update_log.txt"
UPDATE_RUNNER_PATH = BASE_DIR / "_run_update.py"


def _real_python_exe():
    """Chemin fiable vers python.exe.

    Quand ce code tourne DANS le service Windows, sys.executable pointe vers
    pythonservice.exe (l'hôte du service, pas un vrai interpréteur Python) —
    lancer un sous-processus avec ce chemin échoue silencieusement. sys.exec_prefix
    reste correct dans les deux cas (service ou lancement normal), donc on
    reconstruit le chemin de python.exe à partir de là, avec repli sur
    sys.executable si jamais il n'existe pas à cet endroit.
    """
    candidate = os.path.join(sys.exec_prefix, "python.exe" if os.name == "nt" else "python3")
    if os.path.exists(candidate):
        return candidate
    return sys.executable

# Script exécuté dans un processus séparé, après que ce processus-ci se soit
# terminé (pour ne jamais copier par-dessus des fichiers encore ouverts). Il
# copie uniquement le CODE (jamais data.db, les .xlsx, service.log,
# __pycache__, .venv), réinstalle les dépendances, puis relance l'app —
# comme service Windows si celui-ci est installé, sinon en rouvrant
# start.bat dans une nouvelle fenêtre.
_UPDATE_RUNNER_SCRIPT = r'''
import os, sys, shutil, subprocess, time

STAGED = r"{staged}"
TARGET = r"{target}"
BASE = r"{base}"
LOG_PATH = os.path.join(BASE, "_update_log.txt")

def log(msg):
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(time.strftime("%Y-%m-%d %H:%M:%S") + " - " + msg + "\n")

def real_python_exe():
    # Ce runner peut avoir ete lance via pythonservice.exe (sys.executable
    # errone dans ce cas) : on reconstruit le vrai python.exe a partir de
    # sys.exec_prefix, qui lui reste correct.
    candidate = os.path.join(sys.exec_prefix, "python.exe" if os.name == "nt" else "python3")
    if os.path.exists(candidate):
        return candidate
    return sys.executable

PYTHON_EXE = real_python_exe()
log("Python utilise pour la mise a jour : " + PYTHON_EXE)

EXCLUDE_NAMES = {{"__pycache__", ".venv"}}
EXCLUDE_FILES = {{"data.db", "service.log"}}
EXCLUDE_EXT = (".xlsx", ".db")

def copy_tree(src, dst):
    for name in os.listdir(src):
        if name in EXCLUDE_NAMES:
            continue
        s = os.path.join(src, name)
        d = os.path.join(dst, name)
        if os.path.isdir(s):
            os.makedirs(d, exist_ok=True)
            copy_tree(s, d)
        else:
            if name in EXCLUDE_FILES or name.lower().endswith(EXCLUDE_EXT):
                continue
            shutil.copy2(s, d)

log("=== Debut de la mise a jour ===")
# Laisse le temps au processus precedent de bien se terminer et de liberer
# le port / les fichiers.
time.sleep(4)

try:
    copy_tree(STAGED, TARGET)
    log("Fichiers copies avec succes depuis " + STAGED)
except Exception as e:
    log("ERREUR copie fichiers: " + repr(e))

try:
    req = os.path.join(TARGET, "requirements.txt")
    if os.path.exists(req):
        r = subprocess.run([PYTHON_EXE, "-m", "pip", "install", "-r", req],
                            capture_output=True, text=True, timeout=180)
        log("pip install rc=" + str(r.returncode))
        if r.returncode != 0:
            log("pip stderr: " + r.stdout[-1000:] + r.stderr[-1000:])
except Exception as e:
    log("ERREUR pip install: " + repr(e))

# Redemarre selon le mode choisi explicitement par la personne au moment de
# cliquer "Installer maintenant" (service Windows ou start.bat) — plus fiable
# qu'une detection automatique, puisque le meme code tourne dans les deux
# types d'environnement chez ce client.
RESTART_MODE = "{restart_mode}"
restarted = False
service_py = os.path.join(TARGET, "service.py")

def restart_via_service():
    global restarted
    try:
        check = subprocess.run(["sc", "query", "ComptesARecevoirOE"],
                                capture_output=True, text=True, timeout=15)
        if check.returncode == 0 and "ComptesARecevoirOE" in check.stdout:
            subprocess.run([PYTHON_EXE, service_py, "restart"], timeout=30)
            log("Service Windows redemarre.")
            restarted = True
        else:
            log("Mode service demande, mais aucun service ComptesARecevoirOE trouve sur cette machine.")
    except Exception as e:
        log("ERREUR redemarrage service: " + repr(e))

def restart_via_startbat():
    global restarted
    try:
        start_bat = os.path.join(TARGET, "start.bat")
        if os.path.exists(start_bat):
            subprocess.Popen(["cmd", "/c", "start", "", "start.bat"],
                              cwd=TARGET, creationflags=subprocess.CREATE_NEW_CONSOLE)
            log("start.bat relance dans une nouvelle fenetre.")
            restarted = True
        else:
            log("Mode start.bat demande, mais start.bat introuvable dans " + TARGET)
    except Exception as e:
        log("ERREUR relance start.bat: " + repr(e))

log("Mode de redemarrage demande : " + RESTART_MODE)
if RESTART_MODE == "service":
    restart_via_service()
else:
    restart_via_startbat()

# Filet de securite : si le mode choisi echoue, on essaie quand meme l'autre
# methode plutot que de laisser l'application eteinte.
if not restarted:
    log("Le mode demande a echoue, tentative de l'autre methode en secours.")
    if RESTART_MODE == "service":
        restart_via_startbat()
    else:
        restart_via_service()

log("=== Mise a jour terminee ===")
'''


STATEMENT_PREFIX = "OE-"

INFO_ROWS = {
    'adresse': 3,
    'ville': 4,
    'province': 5,
    'code_postal': 6,
    'courriel': 7,
}
FIRST_INVOICE_ROW = 8
FORMULA_MIN_LAST_ROW = 1000
MODELE_SHEET = "Modèle"
SOMMAIRE_SHEET = "Sommaire"
LOG_SHEET = "LOG_ENVOIS"

INVALID_SHEET_CHARS = r'[:\\/?*\[\]]'

app = Flask(__name__)


@app.before_request
def _require_login():
    resp = license_required_check()
    if resp is not None:
        return resp
    resp = login_required_check()
    if resp is not None:
        return resp


# ============================================================
# Base SQLite (source rapide de vérité)
# ============================================================
_db_lock = threading.Lock()


def get_conn():
    conn = sqlite3.connect(str(DB_PATH), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db_schema():
    conn = get_conn()
    conn.execute("PRAGMA journal_mode=WAL")  # meilleure gestion des accès concurrents (plusieurs postes)
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS clients (
        name TEXT PRIMARY KEY,
        sheet_name TEXT UNIQUE,
        phone TEXT, adresse TEXT, ville TEXT, province TEXT,
        code_postal TEXT, courriel TEXT
    );
    CREATE TABLE IF NOT EXISTS invoices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        client_name TEXT NOT NULL REFERENCES clients(name),
        numero TEXT, date_facture TEXT, echeance TEXT,
        montant REAL, notes TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_invoices_client ON invoices(client_name);
    CREATE TABLE IF NOT EXISTS log_envois (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT, client TEXT, courriel TEXT, total REAL, statut TEXT, note TEXT,
        synced INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS meta (
        key TEXT PRIMARY KEY, value TEXT
    );
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        is_admin INTEGER NOT NULL DEFAULT 0,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT,
        permissions TEXT NOT NULL DEFAULT '[]'
    );
    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT, username TEXT, action TEXT, details TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(id DESC);
    CREATE TABLE IF NOT EXISTS credit_clients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        prenom_entreprise TEXT NOT NULL,
        nom TEXT,
        credit_limit REAL NOT NULL DEFAULT 0,
        solde REAL NOT NULL DEFAULT 0,
        deposit REAL NOT NULL DEFAULT 0,
        ligne_source TEXT,
        notes TEXT,
        created_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_credit_clients_nom ON credit_clients(prenom_entreprise, nom);
    CREATE TABLE IF NOT EXISTS credit_movements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        credit_client_id INTEGER NOT NULL REFERENCES credit_clients(id),
        lightspeed_id TEXT,
        date_mouvement TEXT,
        montant REAL NOT NULL DEFAULT 0,
        type TEXT,
        sale TEXT,
        customer_brut TEXT,
        notes TEXT,
        imported_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_credit_movements_client ON credit_movements(credit_client_id);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_credit_movements_lsid
        ON credit_movements(lightspeed_id) WHERE lightspeed_id IS NOT NULL;

    CREATE TABLE IF NOT EXISTS credit_snapshots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        label TEXT,
        source TEXT,
        client_count INTEGER NOT NULL DEFAULT 0,
        total_credit_limit REAL NOT NULL DEFAULT 0,
        total_solde REAL NOT NULL DEFAULT 0,
        total_deposit REAL NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS credit_snapshot_lines (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        snapshot_id INTEGER NOT NULL REFERENCES credit_snapshots(id),
        prenom_entreprise TEXT NOT NULL,
        nom TEXT,
        credit_limit REAL NOT NULL DEFAULT 0,
        solde REAL NOT NULL DEFAULT 0,
        deposit REAL NOT NULL DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_credit_snapshot_lines_snap ON credit_snapshot_lines(snapshot_id);
    """)
    conn.commit()
    # migration : ajoute la colonne montant_paye si elle n'existe pas encore
    # (sur une base créée avant l'ajout du suivi des paiements partiels)
    cols = [r['name'] for r in conn.execute("PRAGMA table_info(invoices)").fetchall()]
    if 'montant_paye' not in cols:
        conn.execute("ALTER TABLE invoices ADD COLUMN montant_paye REAL NOT NULL DEFAULT 0")
        conn.commit()
        cols.append('montant_paye')
    # migration : ajoute la colonne date_paiement si elle n'existe pas encore (sur
    # une base créée avant le suivi des dates de paiement). Sans cette date, un
    # rapport d'âge pour un mois passé ne peut pas savoir si un paiement avait
    # déjà été reçu à cette date-là ou non.
    if 'date_paiement' not in cols:
        conn.execute("ALTER TABLE invoices ADD COLUMN date_paiement TEXT")
        conn.commit()
        # Les paiements déjà saisis avant cette mise à jour n'ont pas de date
        # exacte connue. Par choix explicite du client (Steve, Outillages
        # Express) : on les considère reçus AUJOURD'HUI plutôt que "depuis
        # toujours" — un rapport d'âge pour un mois antérieur à aujourd'hui les
        # affichera donc comme non réglés à cette date passée (plus prudent
        # pour le suivi des comptes à recevoir que de les supposer déjà payés).
        today_str = datetime.date.today().strftime('%Y-%m-%d')
        conn.execute(
            "UPDATE invoices SET date_paiement=? "
            "WHERE montant_paye > 0 AND (date_paiement IS NULL OR date_paiement='')",
            (today_str,)
        )
        conn.commit()
    # migration : ajoute la colonne permissions si elle n'existe pas encore (sur
    # une base créée avant l'ajout des accès granulaires). Les comptes non-admin
    # déjà existants gardent l'accès aux rapports (comportement identique à
    # avant cette fonctionnalité) — les autres permissions doivent être
    # accordées explicitement depuis "Utilisateurs".
    user_cols = [r['name'] for r in conn.execute("PRAGMA table_info(users)").fetchall()]
    if 'permissions' not in user_cols:
        conn.execute("ALTER TABLE users ADD COLUMN permissions TEXT NOT NULL DEFAULT '[]'")
        conn.execute("UPDATE users SET permissions='[\"reports\"]' WHERE is_admin=0")
        conn.commit()
    # migration : case « ne pas synchroniser avec l'importation » sur les comptes de crédit
    cc_cols = [r['name'] for r in conn.execute("PRAGMA table_info(credit_clients)").fetchall()]
    if cc_cols and 'no_sync' not in cc_cols:
        conn.execute("ALTER TABLE credit_clients ADD COLUMN no_sync INTEGER NOT NULL DEFAULT 0")
        conn.commit()
    # migration 1.10.0 : lien avec l'API Lightspeed (identifiant du compte de
    # crédit et du client Lightspeed) + comptes Lightspeed en attente
    # d'association manuelle (homonymes).
    if cc_cols and 'ls_credit_account_id' not in cc_cols:
        conn.execute("ALTER TABLE credit_clients ADD COLUMN ls_credit_account_id TEXT")
        conn.execute("ALTER TABLE credit_clients ADD COLUMN ls_customer_id TEXT")
        conn.commit()
    conn.executescript("""
    CREATE UNIQUE INDEX IF NOT EXISTS idx_credit_clients_lsid
        ON credit_clients(ls_credit_account_id) WHERE ls_credit_account_id IS NOT NULL;
    CREATE TABLE IF NOT EXISTS credit_backups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        label TEXT,
        username TEXT,
        filename TEXT NOT NULL,
        client_count INTEGER NOT NULL DEFAULT 0,
        movement_count INTEGER NOT NULL DEFAULT 0,
        total_solde REAL NOT NULL DEFAULT 0,
        total_deposit REAL NOT NULL DEFAULT 0,
        restored_at TEXT,
        restored_by TEXT
    );
    CREATE TABLE IF NOT EXISTS ls_pending_accounts (
        ls_credit_account_id TEXT PRIMARY KEY,
        ls_customer_id TEXT,
        prenom_entreprise TEXT,
        nom TEXT,
        credit_limit REAL NOT NULL DEFAULT 0,
        debt REAL NOT NULL DEFAULT 0,
        seen_at TEXT
    );
    """)
    conn.commit()
    conn.close()


def meta_get(key, default=None):
    conn = get_conn()
    row = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
    conn.close()
    return row['value'] if row else default


def meta_set(key, value):
    conn = get_conn()
    conn.execute("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                 (key, str(value)))
    conn.commit()
    conn.close()


def mark_dirty():
    meta_set('dirty', '1')


# ============================================================
# Utilisateurs / connexion
# ============================================================
# Accès granulaires pouvant être accordés à un utilisateur non-administrateur.
# La gestion des utilisateurs elle-même (page "Utilisateurs") reste toujours
# réservée aux administrateurs, pour qu'un compte non-admin ne puisse jamais
# se donner (ou donner à quelqu'un d'autre) davantage de droits.
PERMISSION_KEYS = {
    'reports': "Rapports (état de compte, envoi, vieillissement)",
    'audit': "Journal d'audit",
    'license': "Licence",
    'email_settings': "Paramètres d'envoi (Outlook/SMTP)",
    'updates': "Mises à jour",
    'credit_accounts': "Comptes de crédit (Lightspeed)",
}


def _parse_permissions(raw):
    try:
        val = json.loads(raw) if raw else []
        return [p for p in val if p in PERMISSION_KEYS] if isinstance(val, list) else []
    except Exception:
        return []


def _dump_permissions(perms):
    clean = sorted(set(p for p in (perms or []) if p in PERMISSION_KEYS))
    return json.dumps(clean)


def db_list_users():
    conn = get_conn()
    rows = conn.execute(
        "SELECT id, username, is_admin, active, created_at, permissions FROM users ORDER BY username COLLATE NOCASE"
    ).fetchall()
    conn.close()
    out = []
    for r in rows:
        d = dict(r)
        d['permissions'] = _parse_permissions(d.get('permissions'))
        out.append(d)
    return out


def db_get_user_by_username(username):
    conn = get_conn()
    row = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    d['permissions'] = _parse_permissions(d.get('permissions'))
    return d


def db_get_user(user_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    d['permissions'] = _parse_permissions(d.get('permissions'))
    return d


def db_create_user(username, password, is_admin=False, permissions=None):
    username = (username or '').strip()
    if not username:
        raise ValueError("Nom d'utilisateur requis.")
    if not password or len(password) < 4:
        raise ValueError("Mot de passe trop court (minimum 4 caractères).")
    conn = get_conn()
    try:
        conn.execute(
            "INSERT INTO users(username, password_hash, is_admin, active, created_at, permissions) "
            "VALUES (?,?,?,1,?,?)",
            (username, generate_password_hash(password), 1 if is_admin else 0,
             datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
             _dump_permissions(permissions)),
        )
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        raise ValueError("Ce nom d'utilisateur existe déjà.")
    conn.close()


def db_update_user(user_id, is_admin=None, active=None, new_password=None, permissions=None):
    conn = get_conn()
    if is_admin is not None:
        conn.execute("UPDATE users SET is_admin=? WHERE id=?", (1 if is_admin else 0, user_id))
    if active is not None:
        conn.execute("UPDATE users SET active=? WHERE id=?", (1 if active else 0, user_id))
    if new_password:
        if len(new_password) < 4:
            conn.close()
            raise ValueError("Mot de passe trop court (minimum 4 caractères).")
        conn.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new_password), user_id))
    if permissions is not None:
        conn.execute("UPDATE users SET permissions=? WHERE id=?", (_dump_permissions(permissions), user_id))
    conn.commit()
    conn.close()


def db_delete_user(user_id):
    conn = get_conn()
    conn.execute("DELETE FROM users WHERE id=?", (user_id,))
    conn.commit()
    conn.close()


def db_verify_login(username, password):
    user = db_get_user_by_username((username or '').strip())
    if not user or not user['active']:
        return None
    if not check_password_hash(user['password_hash'], password or ''):
        return None
    return user


def ensure_admin_bootstrap():
    """Crée un compte admin par défaut au tout premier démarrage si aucun utilisateur n'existe."""
    if db_list_users():
        return
    temp_password = secrets.token_urlsafe(9)
    db_create_user('admin', temp_password, is_admin=True)
    print()
    print("=" * 60)
    print("PREMIER DÉMARRAGE — COMPTE ADMINISTRATEUR CRÉÉ")
    print(f"  Nom d'utilisateur : admin")
    print(f"  Mot de passe      : {temp_password}")
    print("Note ce mot de passe maintenant — il ne sera plus réaffiché.")
    print("Connecte-toi puis crée les autres comptes depuis 'Utilisateurs'.")
    print("=" * 60)
    print()


def get_or_create_secret_key():
    key = meta_get('secret_key')
    if not key:
        key = secrets.token_hex(32)
        meta_set('secret_key', key)
    return key


def current_user():
    uid = session.get('user_id')
    if not uid:
        return None
    return db_get_user(uid)


def login_required_check():
    """Retourne une réponse (redirect/JSON 401) si non connecté, sinon None."""
    if request.endpoint in ('login', 'static', 'lightspeed_oauth_callback') \
            or request.endpoint in LICENSE_EXEMPT_ENDPOINTS \
            or request.path.startswith('/static/'):
        return None
    if not session.get('user_id'):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'auth_required'}), 401
        return redirect(url_for('login', next=request.path))
    return None


def admin_required_check():
    if not session.get('is_admin'):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'forbidden', 'message': 'Réservé aux administrateurs.'}), 403
        return "Accès refusé — réservé aux administrateurs.", 403
    return None


def permission_required_check(perm_key):
    """Comme admin_required_check, mais laisse passer un utilisateur non-admin
    qui a reçu la permission granulaire `perm_key` (voir PERMISSION_KEYS).
    Un administrateur a toujours accès à tout."""
    if session.get('is_admin'):
        return None
    if perm_key in (session.get('permissions') or []):
        return None
    if request.path.startswith('/api/'):
        return jsonify({'error': 'forbidden', 'message': "Ton compte n'a pas accès à cette section."}), 403
    return "Accès refusé — ton compte n'a pas accès à cette section.", 403


# ============================================================
# Licence logicielle (30 jours / 1 an / à vie)
# ============================================================
# Seul "license_code" (le code brut collé par le client) est gardé en mémoire.
# Tout le reste (licencié, type, date d'expiration) est re-dérivé à chaque
# vérification à partir de ce code — jamais lu directement d'un champ séparé
# qui pourrait être modifié sans repasser par la signature.
LICENSE_EXEMPT_ENDPOINTS = ('activation_page', 'api_license_activate', 'api_license_status', 'static')


# ------------------------------------------------------------
# Horloge de confiance pour l'expiration des licences
# ------------------------------------------------------------
# Se fier uniquement à datetime.date.today() permettrait de prolonger une
# licence expirée en reculant la date de Windows. On combine donc :
#   1) la date réelle obtenue sur Internet (en-tête HTTP "Date" d'un grand
#      site), rafraîchie au démarrage puis toutes les 6 heures, et prolongée
#      entre deux vérifications avec une horloge monotone (insensible aux
#      changements de date de Windows);
#   2) la date la plus récente déjà vue par l'app ("high-water mark"),
#      gardée dans la table meta — sert de référence quand Internet n'est
#      pas disponible.
# Si la date de l'ordinateur est en retard de plus de CLOCK_TOLERANCE_DAYS
# sur la référence, l'horloge est considérée comme reculée et une licence à
# durée limitée est bloquée. Les licences à vie ne sont jamais concernées.
CLOCK_TOLERANCE_DAYS = 1
NET_TIME_URLS = (
    "https://raw.githubusercontent.com/",
    "https://www.google.com/",
    "https://www.microsoft.com/",
)
NET_TIME_REFRESH_SECONDS = 6 * 3600      # rafraîchissement normal
NET_TIME_RETRY_SECONDS = 15 * 60         # nouvel essai si Internet indisponible
CLOCK_HIGH_WATER_KEY = 'clock_high_water'

_net_time_lock = threading.Lock()
_net_time = {'utc': None, 'mono': None}
_clock_hw_cache = {'value': None}
_clock_alert_state = {'logged': False}


def _fetch_internet_utc():
    """Retourne la date/heure UTC lue dans l'en-tête HTTP "Date" du premier
    site qui répond, ou None si aucun n'est joignable."""
    for url in NET_TIME_URLS:
        header = None
        try:
            req = urllib.request.Request(url, method='HEAD', headers={'Cache-Control': 'no-cache'})
            with urllib.request.urlopen(req, timeout=5) as r:
                header = r.headers.get('Date')
        except urllib.error.HTTPError as e:
            # Même une réponse d'erreur (403, 405...) porte un en-tête Date fiable.
            header = e.headers.get('Date') if e.headers else None
        except Exception:
            continue
        if not header:
            continue
        try:
            dt = email.utils.parsedate_to_datetime(header)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=datetime.timezone.utc)
            return dt.astimezone(datetime.timezone.utc)
        except Exception:
            continue
    return None


def refresh_internet_time():
    dt = _fetch_internet_utc()
    if dt is not None:
        with _net_time_lock:
            _net_time['utc'] = dt
            _net_time['mono'] = time.monotonic()
    return dt


def internet_today():
    """Date du jour selon Internet (convertie à l'heure locale), prolongée
    avec l'horloge monotone depuis la dernière vérification. None si l'heure
    Internet n'a jamais pu être obtenue depuis le démarrage."""
    with _net_time_lock:
        utc, mono = _net_time['utc'], _net_time['mono']
    if utc is None:
        return None
    now_utc = utc + datetime.timedelta(seconds=max(0.0, time.monotonic() - mono))
    return now_utc.astimezone().date()


def _clock_high_water_get():
    if _clock_hw_cache['value'] is not None:
        return _clock_hw_cache['value']
    hw = None
    raw = meta_get(CLOCK_HIGH_WATER_KEY)
    if raw:
        try:
            hw = datetime.date.fromisoformat(raw)
        except Exception:
            hw = None
    if hw is None:
        # Première utilisation : on part de l'action la plus récente du
        # journal d'audit (horodatée par l'app elle-même).
        try:
            conn = get_conn()
            row = conn.execute("SELECT MAX(substr(ts,1,10)) AS m FROM audit_log").fetchone()
            conn.close()
            if row and row['m']:
                hw = datetime.date.fromisoformat(row['m'])
        except Exception:
            hw = None
        if hw is not None:
            _clock_high_water_set(hw)
    _clock_hw_cache['value'] = hw
    return hw


def _clock_high_water_set(d):
    try:
        meta_set(CLOCK_HIGH_WATER_KEY, d.isoformat())
    except Exception:
        traceback.print_exc()
    _clock_hw_cache['value'] = d


def get_trusted_today():
    """Retourne (date_de_reference, horloge_ok, date_locale).
    - Avec Internet : la date Internet fait foi (et corrige au besoin la date
      mémorisée, par exemple si l'horloge avait été avancée par erreur).
    - Sans Internet : la plus récente entre la date locale et la date mémorisée.
    horloge_ok est False si la date de l'ordinateur est en retard de plus de
    CLOCK_TOLERANCE_DAYS sur la référence."""
    local = datetime.date.today()
    tol = datetime.timedelta(days=CLOCK_TOLERANCE_DAYS)
    hw = _clock_high_water_get()
    net = internet_today()
    if net is not None:
        if hw is None or hw < net or hw > net + tol:
            _clock_high_water_set(net)
        reference = net
        effective = net
    else:
        reference = hw
        if hw is None or local > hw:
            _clock_high_water_set(local)
        effective = max(local, hw) if hw else local
    clock_ok = reference is None or local >= reference - tol
    return effective, clock_ok, local


def _clock_problem_message(reference, local):
    return (f"La date de cet ordinateur ({local.isoformat()}) semble antérieure "
            f"à la date réelle ({reference.isoformat()}). Corrige la date et "
            f"l'heure de Windows, puis recharge la page.")


def _report_clock_problem(reference, local):
    if not _clock_alert_state['logged']:
        _clock_alert_state['logged'] = True
        db_add_audit('système', 'Horloge reculée détectée',
                     f"Date de l'ordinateur : {local.isoformat()} — date de référence : "
                     f"{reference.isoformat()}. Licence à durée limitée bloquée.")
        print(f"ATTENTION : horloge reculée détectée (ordinateur {local}, référence {reference}).")


def _net_time_loop():
    while True:
        try:
            ok = refresh_internet_time() is not None
        except Exception:
            ok = False
        time.sleep(NET_TIME_REFRESH_SECONDS if ok else NET_TIME_RETRY_SECONDS)


def get_license_status():
    """Revérifie la signature du code de licence stocké à chaque appel.
    Retourne un dict :
      {'active': True, 'payload': {...}, 'days_left': int|None}
      {'active': False, 'reason': 'none'|'invalid'|'expired'|'clock', 'error': str|None, 'payload': {...}|None}
    """
    code = meta_get('license_code', '')
    if not code:
        return {'active': False, 'reason': 'none', 'error': None, 'payload': None}
    result = licensing.verify_license_code(code)
    if not result['ok']:
        return {'active': False, 'reason': 'invalid', 'error': result['error'], 'payload': None}
    payload = result['payload']
    expires = payload.get('expires')
    if expires:
        try:
            exp_date = datetime.date.fromisoformat(expires)
        except Exception:
            return {'active': False, 'reason': 'invalid', 'error': "Date d'expiration illisible.", 'payload': None}
        today, clock_ok, local = get_trusted_today()
        if not clock_ok:
            _report_clock_problem(today, local)
            return {'active': False, 'reason': 'clock', 'payload': payload,
                    'error': _clock_problem_message(today, local)}
        _clock_alert_state['logged'] = False
        days_left = (exp_date - today).days
        if days_left < 0:
            return {'active': False, 'reason': 'expired', 'error': None, 'payload': payload}
        return {'active': True, 'payload': payload, 'days_left': days_left}
    return {'active': True, 'payload': payload, 'days_left': None}


def license_required_check():
    """Retourne une réponse (redirect/JSON 402) si aucune licence active,
    sinon None. Bloque TOUT (même la page de connexion) tant qu'aucune
    licence valide et non expirée n'est active — seule la page d'activation
    elle-même et son API restent accessibles."""
    if request.endpoint in LICENSE_EXEMPT_ENDPOINTS or request.path.startswith('/static/'):
        return None
    status = get_license_status()
    if not status['active']:
        if request.path.startswith('/api/'):
            return jsonify({'error': 'license_required', 'reason': status['reason']}), 402
        return redirect(url_for('activation_page'))
    return None


# ============================================================
# Journal d'audit (visible uniquement par les administrateurs)
# ============================================================
AUDIT_MAX_ROWS = 5000


def db_add_audit(username, action, details=''):
    """Enregistre une action dans le journal d'audit. N'interrompt jamais l'action
    elle-même si l'écriture échoue (l'audit est secondaire, jamais bloquant)."""
    try:
        conn = get_conn()
        cur = conn.execute(
            "INSERT INTO audit_log(ts, username, action, details) VALUES (?,?,?,?)",
            (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), username or '?', action, details or '')
        )
        new_id = cur.lastrowid
        conn.commit()
        # purge périodique pour éviter une croissance illimitée (garde les AUDIT_MAX_ROWS plus récents)
        if new_id % 100 == 0:
            conn.execute(
                "DELETE FROM audit_log WHERE id NOT IN (SELECT id FROM audit_log ORDER BY id DESC LIMIT ?)",
                (AUDIT_MAX_ROWS,)
            )
            conn.commit()
        conn.close()
    except Exception:
        traceback.print_exc()


def log_audit(action, details=''):
    """À appeler depuis une route Flask (a accès à la session courante)."""
    db_add_audit(session.get('username'), action, details)


def db_list_audit(limit=1000):
    conn = get_conn()
    rows = conn.execute(
        "SELECT ts, username, action, details FROM audit_log ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ============================================================
# Paramètres d'envoi (Outlook ou serveur SMTP) — configurables par un admin
# ============================================================
SETTINGS_DEFAULTS = {
    'send_mode': 'outlook',        # 'outlook' ou 'smtp'
    'smtp_host': '',
    'smtp_port': '587',
    'smtp_username': '',
    'smtp_password': '',
    'smtp_encryption': 'starttls',  # 'starttls' | 'ssl' | 'none'
    'smtp_from_email': '',
    'smtp_from_name': '',
}


def get_settings():
    return {k: meta_get(k, default) for k, default in SETTINGS_DEFAULTS.items()}


def get_public_settings():
    """Ce qu'un utilisateur non-admin a besoin de savoir (jamais les identifiants SMTP)."""
    return {'send_mode': meta_get('send_mode', SETTINGS_DEFAULTS['send_mode'])}


def set_settings(data):
    for key in SETTINGS_DEFAULTS:
        if key in data and data[key] is not None:
            value = data[key]
            if key == 'smtp_password' and value == '':
                continue  # champ laissé vide = on garde l'ancien mot de passe
            meta_set(key, value)


def send_via_smtp(to_email, subject, body, pdf_path, settings):
    import smtplib
    from email.message import EmailMessage

    host = (settings.get('smtp_host') or '').strip()
    from_email = (settings.get('smtp_from_email') or '').strip()
    if not host or not from_email:
        raise RuntimeError(
            "Le serveur SMTP n'est pas configuré. Un administrateur doit le configurer "
            "dans 'Paramètres d'envoi'."
        )
    port = int(settings.get('smtp_port') or 587)
    username = (settings.get('smtp_username') or '').strip()
    password = settings.get('smtp_password') or ''
    encryption = settings.get('smtp_encryption') or 'starttls'
    from_name = (settings.get('smtp_from_name') or '').strip() or get_company_name()

    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = f"{from_name} <{from_email}>"
    msg['To'] = to_email
    msg['Bcc'] = get_company_email()
    msg.set_content(body)
    with open(pdf_path, 'rb') as f:
        pdf_data = f.read()
    msg.add_attachment(pdf_data, maintype='application', subtype='pdf', filename=Path(pdf_path).name)

    if encryption == 'ssl':
        with smtplib.SMTP_SSL(host, port, timeout=30) as smtp:
            if username:
                smtp.login(username, password)
            smtp.send_message(msg)
    else:
        with smtplib.SMTP(host, port, timeout=30) as smtp:
            if encryption == 'starttls':
                smtp.starttls()
            if username:
                smtp.login(username, password)
            smtp.send_message(msg)
    return 'ENVOYÉ'


def test_smtp_connection(settings):
    """Vérifie la connexion/authentification SMTP sans envoyer de courriel."""
    import smtplib

    host = (settings.get('smtp_host') or '').strip()
    if not host:
        raise RuntimeError("Adresse du serveur SMTP manquante.")
    port = int(settings.get('smtp_port') or 587)
    username = (settings.get('smtp_username') or '').strip()
    password = settings.get('smtp_password') or ''
    encryption = settings.get('smtp_encryption') or 'starttls'

    if encryption == 'ssl':
        with smtplib.SMTP_SSL(host, port, timeout=15) as smtp:
            if username:
                smtp.login(username, password)
    else:
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            if encryption == 'starttls':
                smtp.starttls()
            if username:
                smtp.login(username, password)


def send_email(to_email, subject, body, pdf_path, mode='draft'):
    """Point d'entrée unique pour l'envoi : bascule vers Outlook ou SMTP selon les
    paramètres configurés par un administrateur. Le SMTP n'a pas de concept de
    brouillon/relecture — un appel avec mode='draft*' en mode SMTP est refusé plus haut,
    avant d'arriver ici (voir les routes)."""
    settings = get_settings()
    if settings['send_mode'] == 'smtp':
        return send_via_smtp(to_email, subject, body, pdf_path, settings)
    return send_via_outlook(to_email, subject, body, pdf_path, mode=mode)


# ============================================================
# Import unique depuis Excel -> SQLite (au tout premier démarrage)
# ============================================================
def safe_sheet_name(name: str) -> str:
    cleaned = re.sub(INVALID_SHEET_CHARS, '', name).strip()
    return cleaned[:31] if len(cleaned) > 31 else cleaned


def read_client_info_ws(ws):
    def cell(r, c):
        return ws.cell(row=r, column=c).value
    return {
        'phone': cell(2, 2) or '',
        'adresse': cell(INFO_ROWS['adresse'], 2) or '',
        'ville': cell(INFO_ROWS['ville'], 2) or '',
        'province': cell(INFO_ROWS['province'], 2) or '',
        'code_postal': cell(INFO_ROWS['code_postal'], 2) or '',
        'courriel': cell(INFO_ROWS['courriel'], 2) or '',
    }


def read_invoices_ws(ws):
    invoices = []
    r = 2
    max_row = ws.max_row
    while r <= max_row:
        num = ws.cell(row=r, column=3).value
        date_f = ws.cell(row=r, column=4).value
        echeance = ws.cell(row=r, column=5).value
        montant = ws.cell(row=r, column=6).value
        notes = ws.cell(row=r, column=11).value
        if num is not None and montant is not None:
            due = echeance.date() if isinstance(echeance, datetime.datetime) else echeance
            df = date_f.date() if isinstance(date_f, datetime.datetime) else date_f
            invoices.append({
                'numero': str(num),
                'date_facture': df.strftime('%Y-%m-%d') if isinstance(df, datetime.date) else (str(df) if df else ''),
                'echeance': due.strftime('%Y-%m-%d') if isinstance(due, datetime.date) else (str(due) if due else ''),
                'montant': float(montant),
                'notes': notes or '',
            })
        r += 1
    return invoices


def import_excel_into_db():
    """Importe une seule fois toutes les données de l'Excel existant dans la base SQLite."""
    print("Premier démarrage : import des données depuis Excel (peut prendre ~30s)...")
    wb = openpyxl.load_workbook(EXCEL_PATH, data_only=False)
    sommaire = wb[SOMMAIRE_SHEET]

    conn = get_conn()
    r = 3
    n_clients = 0
    n_invoices = 0
    used_sheet_names = set()
    while sommaire.cell(row=r, column=1).value is not None:
        name = sommaire.cell(row=r, column=1).value
        # Le nom d'onglet réel peut différer d'une simple troncature du nom du
        # client (deux clients peuvent tronquer sur le même nom) — on lit donc
        # le vrai nom d'onglet directement dans la formule existante du Sommaire.
        formula = sommaire.cell(row=r, column=2).value  # ex: ="'SheetName'!G2"
        sheet_name = None
        if isinstance(formula, str):
            m = re.match(r"^='([^']+)'!", formula)
            if m:
                sheet_name = m.group(1)
        if not sheet_name:
            sheet_name = safe_sheet_name(name)
        ws = wb[sheet_name] if sheet_name in wb.sheetnames else None
        if ws is not None and sheet_name in used_sheet_names:
            # collision improbable — on ne devrait jamais arriver ici puisqu'on lit
            # le vrai nom d'onglet, mais on se protège quand même
            ws = None
        if ws is not None:
            used_sheet_names.add(sheet_name)
            info = read_client_info_ws(ws)
            conn.execute(
                "INSERT OR REPLACE INTO clients(name, sheet_name, phone, adresse, ville, province, code_postal, courriel) "
                "VALUES (?,?,?,?,?,?,?,?)",
                (name, sheet_name, info['phone'], info['adresse'], info['ville'], info['province'],
                 info['code_postal'], info['courriel'])
            )
            n_clients += 1
            for inv in read_invoices_ws(ws):
                if inv['montant'] == 0 and not inv['numero']:
                    continue
                conn.execute(
                    "INSERT INTO invoices(client_name, numero, date_facture, echeance, montant, notes) VALUES (?,?,?,?,?,?)",
                    (name, inv['numero'], inv['date_facture'], inv['echeance'], inv['montant'], inv['notes'])
                )
                n_invoices += 1
        r += 1

    counter_cell = sommaire.cell(row=2, column=13).value  # M2 : dernier numéro d'état de compte
    try:
        counter_val = int(counter_cell or 0)
    except (TypeError, ValueError):
        counter_val = 0
    conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('statement_counter', ?)", (str(counter_val),))
    conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('dirty', '0')")
    conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('last_sync', ?)",
                 (datetime.datetime.now().isoformat(),))
    conn.commit()
    conn.close()
    print(f"Import terminé : {n_clients} clients, {n_invoices} factures.")


def create_blank_excel_template(path):
    """Crée un classeur Excel neuf (aucun client) avec la structure minimale
    attendue par l'app : onglets Modèle / Sommaire / LOG_ENVOIS. Utilisé au
    tout premier démarrage sur un ordinateur qui n'a jamais eu de fichier
    Excel (nouvelle installation) — toutes les formules et le contenu réel
    de chaque onglet client sont de toute façon régénérés à partir de la
    base SQLite à chaque synchronisation (write_client_sheet/export_to_excel),
    donc ce modèle n'a besoin que d'exister, pas d'être élaboré."""
    wb = openpyxl.Workbook()
    modele = wb.active
    modele.title = MODELE_SHEET
    modele.cell(row=1, column=1, value='Client')
    modele.cell(row=1, column=2, value='Numéro de téléphone')
    modele.cell(row=1, column=3, value='Numéro de facture')
    modele.cell(row=1, column=4, value='Date de facture ')
    modele.cell(row=1, column=5, value='Échéance ')
    modele.cell(row=1, column=6, value='Montant')
    modele.cell(row=1, column=7, value='0-30 jours')
    modele.cell(row=1, column=8, value='31-60 jours')
    modele.cell(row=1, column=9, value='61-90 jours')
    modele.cell(row=1, column=10, value='90+ jours')
    modele.cell(row=1, column=11, value='Notes / Suivi')
    modele.cell(row=1, column=12, value='Payé')
    modele.cell(row=1, column=13, value='Solde')

    sommaire = wb.create_sheet(SOMMAIRE_SHEET)
    sommaire.cell(row=1, column=1, value='Client')
    sommaire.cell(row=1, column=2, value='0-30 jours')
    sommaire.cell(row=1, column=3, value='31-60 jours')
    sommaire.cell(row=1, column=4, value='61-90 jours')
    sommaire.cell(row=1, column=5, value='90+ jours')
    sommaire.cell(row=1, column=6, value='Total')
    sommaire.cell(row=1, column=7, value='Vérfication')
    sommaire.cell(row=2, column=1, value='Sommaire')
    # Ligne 2 (sommes) et lignes clients (3+) sont vides ici : elles sont
    # entièrement régénérées par export_to_excel() dès la première synchronisation.

    log_ws = wb.create_sheet(LOG_SHEET)
    log_ws.cell(row=1, column=1, value='Date')
    log_ws.cell(row=1, column=2, value='Client')
    log_ws.cell(row=1, column=3, value='Courriel')
    log_ws.cell(row=1, column=4, value='Total')
    log_ws.cell(row=1, column=5, value='Statut')
    log_ws.cell(row=1, column=6, value='Note')

    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
    print(f"Nouveau classeur Excel créé (installation neuve) : {path}")


def ensure_db_ready():
    is_new = not DB_PATH.exists()
    init_db_schema()
    if is_new:
        import_excel_into_db()


# ============================================================
# Aging (tranches d'âge) — logique identique aux formules du classeur
# ============================================================
def compute_bucket(today, echeance_str, montant):
    if not echeance_str:
        return {'g': 0.0, 'h': 0.0, 'i': 0.0, 'j': 0.0}
    try:
        echeance = datetime.datetime.strptime(echeance_str, '%Y-%m-%d').date()
    except ValueError:
        return {'g': 0.0, 'h': 0.0, 'i': 0.0, 'j': 0.0}
    diff = (today - echeance).days
    g = montant if today <= echeance else 0.0
    h = montant if 0 < diff <= 30 else 0.0
    i = montant if 30 < diff <= 60 else 0.0
    j = montant if diff > 60 else 0.0
    return {'g': g, 'h': h, 'i': i, 'j': j}


def invoices_with_buckets(rows, ref_date=None):
    """Ajoute à chaque facture son solde restant (montant - montant payé, s'il y a eu un
    paiement partiel ou total) et sa tranche d'âge calculée sur ce solde restant — pas
    sur le montant facturé au complet.

    Pour un rapport d'âge d'un mois PASSÉ (ref_date fourni) : si le paiement enregistré
    (date_paiement) est survenu APRÈS ref_date, on ne le soustrait pas du solde — la
    facture apparaît alors comme elle l'était réellement à cette date-là, sans tenir
    compte d'un paiement reçu depuis. Pour la vue courante (ref_date=None), le paiement
    est toujours pris en compte normalement."""
    today = ref_date or datetime.date.today()
    today_str = today.strftime('%Y-%m-%d')
    out = []
    for r in rows:
        d = dict(r)
        montant_paye_total = d.get('montant_paye') or 0.0
        date_paiement = d.get('date_paiement') or ''
        if montant_paye_total and date_paiement and date_paiement > today_str:
            montant_paye_effectif = 0.0
        else:
            montant_paye_effectif = montant_paye_total
        solde = d['montant'] - montant_paye_effectif
        d['montant_paye'] = montant_paye_total
        d['date_paiement'] = date_paiement
        d['solde'] = solde
        d['bucket'] = compute_bucket(today, d['echeance'], solde)
        out.append(d)
    return out


def sum_totals(invoices):
    """totals['montant'] représente le solde total dû (après paiements partiels) — le nom
    est conservé pour ne pas casser le reste du code qui l'utilise comme 'montant dû'."""
    totals = {'montant': 0.0, 'g': 0.0, 'h': 0.0, 'i': 0.0, 'j': 0.0}
    for inv in invoices:
        totals['montant'] += inv.get('solde', inv['montant'])
        for k in ('g', 'h', 'i', 'j'):
            totals[k] += inv['bucket'][k]
    return totals


# ============================================================
# Accès aux données (rapide, SQLite)
# ============================================================
def db_list_clients():
    conn = get_conn()
    clients = conn.execute("SELECT name, courriel FROM clients ORDER BY name COLLATE NOCASE").fetchall()
    result = []
    for c in clients:
        rows = conn.execute("SELECT * FROM invoices WHERE client_name=?", (c['name'],)).fetchall()
        totals = sum_totals(invoices_with_buckets(rows))
        result.append({'name': c['name'], 'courriel': c['courriel'] or '', 'solde': round(totals['montant'], 2)})
    conn.close()
    return result


def db_client_detail(name):
    conn = get_conn()
    c = conn.execute("SELECT * FROM clients WHERE name=?", (name,)).fetchone()
    if c is None:
        conn.close()
        return None
    rows = conn.execute("SELECT * FROM invoices WHERE client_name=? ORDER BY id", (name,)).fetchall()
    conn.close()
    invoices = invoices_with_buckets(rows)
    totals = sum_totals(invoices)
    info = {'phone': c['phone'] or '', 'adresse': c['adresse'] or '', 'ville': c['ville'] or '',
            'province': c['province'] or '', 'code_postal': c['code_postal'] or '', 'courriel': c['courriel'] or ''}
    return {'name': c['name'], 'info': info, 'invoices': invoices, 'totals': totals}


def db_create_client(name, phone, adresse, ville, province, code_postal, courriel):
    conn = get_conn()
    existing = conn.execute("SELECT 1 FROM clients WHERE name=?", (name,)).fetchone()
    if existing:
        conn.close()
        raise RuntimeError("Ce client existe déjà.")
    base_sheet_name = safe_sheet_name(name)
    sheet_name = base_sheet_name
    suffix = 2
    while conn.execute("SELECT name FROM clients WHERE sheet_name=?", (sheet_name,)).fetchone():
        # collision (deux noms différents tronquent pareil) : on distingue avec un suffixe
        tail = f"_{suffix}"
        sheet_name = base_sheet_name[:31 - len(tail)] + tail
        suffix += 1
    conn.execute(
        "INSERT INTO clients(name, sheet_name, phone, adresse, ville, province, code_postal, courriel) VALUES (?,?,?,?,?,?,?,?)",
        (name, sheet_name, phone or '', adresse or '', ville or '', province or 'Qc', code_postal or '', courriel or '')
    )
    conn.commit()
    conn.close()
    mark_dirty()
    return sheet_name


CLIENT_FIELD_LABELS = {
    'name': "Nom", 'courriel': "Courriel", 'phone': "Téléphone", 'adresse': "Adresse",
    'ville': "Ville", 'province': "Province", 'code_postal': "Code postal",
}


def _unique_sheet_name(conn, name, exclude_client=None):
    """Nom d'onglet Excel valide et unique (insensible à la casse, comme
    Excel) parmi les clients — en excluant éventuellement le client lui-même
    (cas d'un renommage) — et jamais égal à un onglet système."""
    reserved = {MODELE_SHEET.lower(), SOMMAIRE_SHEET.lower(), LOG_SHEET.lower()}
    base = safe_sheet_name(name) or "Client"
    candidate = base
    suffix = 2
    while True:
        if candidate.lower() not in reserved:
            row = conn.execute(
                "SELECT name FROM clients WHERE sheet_name = ? COLLATE NOCASE AND name <> ?",
                (candidate, exclude_client if exclude_client is not None else '\x00')
            ).fetchone()
            if row is None:
                return candidate
        tail = f"_{suffix}"
        candidate = base[:31 - len(tail)] + tail
        suffix += 1


def _queue_sheet_rename(conn, old_sheet, new_sheet):
    """Mémorise un renommage d'onglet Excel à appliquer à la prochaine
    synchronisation (le fichier Excel n'est jamais modifié directement ici)."""
    row = conn.execute("SELECT value FROM meta WHERE key='pending_sheet_renames'").fetchone()
    try:
        pending = json.loads(row['value']) if row and row['value'] else []
    except Exception:
        pending = []
    pending.append([old_sheet, new_sheet])
    conn.execute(
        "INSERT INTO meta(key,value) VALUES('pending_sheet_renames', ?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (json.dumps(pending, ensure_ascii=False),)
    )


def db_update_client(old_name, new_name, phone, adresse, ville, province, code_postal, courriel):
    """Modifie un client existant. Un changement de nom est appliqué en une
    seule transaction au client ET à toutes ses factures. Retourne
    (nouveau_nom, liste des changements [(champ, avant, après)])."""
    new_name = (new_name or '').strip()
    if not new_name:
        raise RuntimeError("Le nom du client est obligatoire.")
    new_values = {
        'name': new_name,
        'courriel': (courriel or '').strip(),
        'phone': (phone or '').strip(),
        'adresse': (adresse or '').strip(),
        'ville': (ville or '').strip(),
        'province': (province or '').strip() or 'Qc',
        'code_postal': (code_postal or '').strip(),
    }
    conn = get_conn()
    try:
        cur = conn.execute("SELECT * FROM clients WHERE name=?", (old_name,)).fetchone()
        if cur is None:
            raise RuntimeError("Client introuvable (il a peut-être déjà été renommé — recharge la page).")
        changes = [(k, cur[k] or '', v) for k, v in new_values.items() if (cur[k] or '') != v]
        if not changes:
            return old_name, []

        renamed = new_name != old_name
        sheet_name = cur['sheet_name']
        if renamed:
            dup = conn.execute(
                "SELECT name FROM clients WHERE name = ? COLLATE NOCASE AND name <> ?",
                (new_name, old_name)
            ).fetchone()
            if dup:
                raise RuntimeError(f"Un autre client porte déjà ce nom : « {dup['name']} ».")
            sheet_name = _unique_sheet_name(conn, new_name, exclude_client=old_name)

        # Les factures référencent clients(name) : on diffère la vérification
        # des clés étrangères à la fin de la transaction pour pouvoir changer
        # le nom des deux côtés.
        conn.execute("PRAGMA defer_foreign_keys = ON")
        conn.execute(
            "UPDATE clients SET name=?, sheet_name=?, phone=?, adresse=?, ville=?, province=?, "
            "code_postal=?, courriel=? WHERE name=?",
            (new_values['name'], sheet_name, new_values['phone'], new_values['adresse'],
             new_values['ville'], new_values['province'], new_values['code_postal'],
             new_values['courriel'], old_name)
        )
        if renamed:
            conn.execute("UPDATE invoices SET client_name=? WHERE client_name=?", (new_name, old_name))
            if sheet_name != cur['sheet_name']:
                _queue_sheet_rename(conn, cur['sheet_name'], sheet_name)
        conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('dirty', '1')")
        conn.commit()
        return new_name, changes
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _resolve_date_paiement(montant_paye, date_paiement, previous_date_paiement=None):
    """Détermine la date de paiement à enregistrer : si un montant payé est présent
    mais qu'aucune date n'a été fournie explicitement, on garde la date précédente
    si elle existe, sinon on utilise aujourd'hui (comportement par défaut, cohérent
    avec la migration initiale) — jamais None tant qu'il y a un montant payé, pour
    que les rapports d'âge de mois passés puissent trancher correctement."""
    if not montant_paye:
        return None
    if date_paiement:
        return date_paiement
    if previous_date_paiement:
        return previous_date_paiement
    return datetime.date.today().strftime('%Y-%m-%d')


def db_add_invoice(client_name, numero, date_facture, echeance, montant, notes,
                    montant_paye=0.0, date_paiement=None):
    conn = get_conn()
    c = conn.execute("SELECT 1 FROM clients WHERE name=?", (client_name,)).fetchone()
    if not c:
        conn.close()
        raise RuntimeError(f"Client introuvable : {client_name}")
    montant_paye = float(montant_paye or 0)
    date_paiement = _resolve_date_paiement(montant_paye, date_paiement)
    conn.execute(
        "INSERT INTO invoices(client_name, numero, date_facture, echeance, montant, notes, montant_paye, date_paiement) "
        "VALUES (?,?,?,?,?,?,?,?)",
        (client_name, str(numero), date_facture, echeance, float(montant), notes or '',
         montant_paye, date_paiement)
    )
    conn.commit()
    conn.close()
    mark_dirty()


def db_update_invoice(invoice_id, numero, date_facture, echeance, montant, notes,
                       montant_paye=0.0, date_paiement=None):
    conn = get_conn()
    existing = conn.execute("SELECT montant_paye, date_paiement FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    if not existing:
        conn.close()
        raise RuntimeError("Facture introuvable.")
    montant_paye = float(montant_paye or 0)
    montant_paye_a_change = abs((existing['montant_paye'] or 0.0) - montant_paye) > 0.005
    # Si le montant payé n'a pas changé, on garde la date déjà enregistrée (même si
    # aucune nouvelle date n'est fournie) ; s'il a changé sans date fournie, on
    # considère que ce changement vient d'être fait aujourd'hui.
    previous = existing['date_paiement'] if not montant_paye_a_change else None
    date_paiement = _resolve_date_paiement(montant_paye, date_paiement, previous)
    conn.execute(
        "UPDATE invoices SET numero=?, date_facture=?, echeance=?, montant=?, notes=?, "
        "montant_paye=?, date_paiement=? WHERE id=?",
        (str(numero), date_facture, echeance, float(montant), notes or '',
         montant_paye, date_paiement, invoice_id)
    )
    conn.commit()
    conn.close()
    mark_dirty()


def db_get_invoice(invoice_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def db_delete_invoice(invoice_id):
    conn = get_conn()
    existing = conn.execute("SELECT 1 FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    if not existing:
        conn.close()
        raise RuntimeError("Facture introuvable.")
    conn.execute("DELETE FROM invoices WHERE id=?", (invoice_id,))
    conn.commit()
    conn.close()
    mark_dirty()


def db_set_invoice_paid(invoice_id, paid, date_paiement=None):
    """Marque une facture comme entièrement payée (montant_paye = montant, avec la
    date de paiement fournie ou aujourd'hui par défaut) ou annule ce marquage (remet
    montant_paye et date_paiement à zéro/vide). Un paiement partiel déjà saisi
    manuellement est écrasé par cette action, dans les deux sens."""
    conn = get_conn()
    row = conn.execute("SELECT montant FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    if not row:
        conn.close()
        raise RuntimeError("Facture introuvable.")
    if paid:
        new_montant_paye = row['montant']
        new_date_paiement = date_paiement or datetime.date.today().strftime('%Y-%m-%d')
    else:
        new_montant_paye = 0.0
        new_date_paiement = None
    conn.execute("UPDATE invoices SET montant_paye=?, date_paiement=? WHERE id=?",
                 (new_montant_paye, new_date_paiement, invoice_id))
    conn.commit()
    conn.close()
    mark_dirty()


def db_next_statement_number():
    conn = get_conn()
    with _db_lock:
        row = conn.execute("SELECT value FROM meta WHERE key='statement_counter'").fetchone()
        current = int(row['value']) if row else 0
        new_val = current + 1
        conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('statement_counter', ?)", (str(new_val),))
        conn.commit()
    conn.close()
    mark_dirty()
    return f"{STATEMENT_PREFIX}{new_val:06d}"


def db_log_envoi(client, courriel, total, statut, note):
    conn = get_conn()
    conn.execute(
        "INSERT INTO log_envois(ts, client, courriel, total, statut, note, synced) VALUES (?,?,?,?,?,?,0)",
        (datetime.datetime.now().isoformat(), client, courriel, total, statut, note)
    )
    conn.commit()
    conn.close()
    mark_dirty()


# ============================================================
# Comptes de crédit (Lightspeed) — volet distinct des comptes à recevoir.
# Liste de clients avec limite de crédit / solde dû / dépôt, alimentée par un
# import initial (Excel/CSV) puis, chaque mois, par un import des mouvements
# (transactions) exportés de Lightspeed, qui met à jour les soldes.
# ============================================================
def _credit_client_display_name(row):
    prenom = (row.get('prenom_entreprise') or '').strip()
    nom = (row.get('nom') or '').strip()
    if nom and nom.lower() not in prenom.lower():
        return f"{prenom} {nom}".strip()
    return prenom or nom


def _norm_credit_name(s):
    return (s or '').strip().lower()


def db_list_credit_clients():
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM credit_clients ORDER BY prenom_entreprise COLLATE NOCASE, nom COLLATE NOCASE"
    ).fetchall()
    conn.close()
    out = []
    for r in rows:
        d = dict(r)
        d['display_name'] = _credit_client_display_name(d)
        out.append(d)
    return out


def db_get_credit_client(client_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM credit_clients WHERE id=?", (client_id,)).fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    d['display_name'] = _credit_client_display_name(d)
    return d


def db_credit_client_movements(client_id):
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM credit_movements WHERE credit_client_id=? ORDER BY date_mouvement, id",
        (client_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _credit_net_debt(row):
    """« Debt » net d'un compte (positif = doit, négatif = crédit/dépôt).
    Les fiches d'avant la 1.9.1 pouvaient avoir un solde négatif brut."""
    solde = float(row.get('solde') or 0.0)
    deposit = float(row.get('deposit') or 0.0)
    return solde if solde < 0 else solde - deposit


def _split_debt(debt):
    """Répartit un Debt net en (montant dû, dépôt)."""
    debt = round(float(debt), 2)
    return max(debt, 0.0), max(-debt, 0.0)


CREDIT_FIELD_LABELS = {
    'prenom_entreprise': "Prénom / entreprise", 'nom': "Nom", 'credit_limit': "Limite de crédit",
    'solde': "Montant dû", 'deposit': "Dépôt", 'notes': "Notes", 'no_sync': "Ne pas synchroniser",
}


def db_update_credit_client(client_id, data):
    """Modifie un compte de crédit. Retourne (avant, changements)."""
    conn = get_conn()
    try:
        cur = conn.execute("SELECT * FROM credit_clients WHERE id=?", (client_id,)).fetchone()
        if cur is None:
            raise RuntimeError("Compte introuvable.")
        cur = dict(cur)
        new = {}
        if 'prenom_entreprise' in data:
            v = (data.get('prenom_entreprise') or '').strip()
            if not v:
                raise RuntimeError("Le prénom / nom d'entreprise est obligatoire.")
            new['prenom_entreprise'] = v
        if 'nom' in data:
            new['nom'] = (data.get('nom') or '').strip() or None
        for k in ('credit_limit', 'solde', 'deposit'):
            if k in data:
                try:
                    val = round(_parse_money(data.get(k)), 2)
                except Exception:
                    raise RuntimeError(f"Montant invalide : {CREDIT_FIELD_LABELS[k]}.")
                if val < 0:
                    raise RuntimeError(f"{CREDIT_FIELD_LABELS[k]} ne peut pas être négatif.")
                new[k] = val
        if 'notes' in data:
            new['notes'] = (data.get('notes') or '').strip() or None
        if 'no_sync' in data:
            new['no_sync'] = 1 if data.get('no_sync') in (True, 1, '1', 'true', 'on') else 0
        changes = []
        for k, v in new.items():
            old = cur.get(k)
            if isinstance(v, float):
                if abs(float(old or 0) - v) >= 0.005:
                    changes.append((k, old, v))
            elif (old if old not in ('',) else None) != v:
                changes.append((k, old, v))
        if changes:
            sets = ", ".join(f"{k}=?" for k, _, _ in changes)
            conn.execute(f"UPDATE credit_clients SET {sets} WHERE id=?",
                         [v for _, _, v in changes] + [client_id])
            conn.commit()
        return cur, changes
    finally:
        conn.close()


def db_delete_credit_client(client_id):
    conn = get_conn()
    try:
        cur = conn.execute("SELECT * FROM credit_clients WHERE id=?", (client_id,)).fetchone()
        if cur is None:
            raise RuntimeError("Compte introuvable.")
        n = conn.execute("SELECT COUNT(*) c FROM credit_movements WHERE credit_client_id=?",
                         (client_id,)).fetchone()['c']
        conn.execute("DELETE FROM credit_movements WHERE credit_client_id=?", (client_id,))
        conn.execute("DELETE FROM credit_clients WHERE id=?", (client_id,))
        conn.commit()
        return dict(cur), n
    finally:
        conn.close()


def _apply_movement_delta(conn, client_id, delta):
    """Ajuste le solde d'un compte de « delta » (positif = le client doit plus)."""
    c = conn.execute("SELECT * FROM credit_clients WHERE id=?", (client_id,)).fetchone()
    if c is None or abs(delta) < 0.005:
        return
    solde, deposit = _split_debt(_credit_net_debt(dict(c)) + delta)
    conn.execute("UPDATE credit_clients SET solde=?, deposit=? WHERE id=?", (solde, deposit, client_id))


def db_update_credit_movement(movement_id, data):
    """Modifie un mouvement ; le solde du client est ajusté de la différence
    de montant. Retourne (avant, après)."""
    conn = get_conn()
    try:
        m = conn.execute("SELECT * FROM credit_movements WHERE id=?", (movement_id,)).fetchone()
        if m is None:
            raise RuntimeError("Mouvement introuvable.")
        m = dict(m)
        date_mv = (data.get('date_mouvement') or '').strip() or None
        if date_mv:
            try:
                datetime.date.fromisoformat(date_mv)
            except Exception:
                raise RuntimeError("Date invalide (format attendu : AAAA-MM-JJ).")
        montant = round(_parse_money(data.get('montant')), 2)
        after = {
            'date_mouvement': date_mv,
            'type': (data.get('type') or '').strip() or None,
            'sale': (data.get('sale') or '').strip() or None,
            'montant': montant,
        }
        conn.execute("UPDATE credit_movements SET date_mouvement=?, type=?, sale=?, montant=? WHERE id=?",
                     (after['date_mouvement'], after['type'], after['sale'], after['montant'], movement_id))
        _apply_movement_delta(conn, m['credit_client_id'], montant - float(m['montant'] or 0))
        conn.commit()
        return m, after
    finally:
        conn.close()


def db_delete_credit_movement(movement_id):
    """Supprime un mouvement et annule son effet sur le solde du client."""
    conn = get_conn()
    try:
        m = conn.execute("SELECT * FROM credit_movements WHERE id=?", (movement_id,)).fetchone()
        if m is None:
            raise RuntimeError("Mouvement introuvable.")
        m = dict(m)
        conn.execute("DELETE FROM credit_movements WHERE id=?", (movement_id,))
        _apply_movement_delta(conn, m['credit_client_id'], -float(m['montant'] or 0))
        conn.commit()
        return m
    finally:
        conn.close()


def db_import_credit_clients(rows):
    """Remplace ENTIÈREMENT la liste des comptes de crédit à partir de lignes
    {prenom_entreprise, nom, credit_limit, solde, deposit, ligne_source}. Utilisé
    pour l'import initial (ou une réinitialisation complète demandée
    explicitement par un administrateur) — jamais appelé automatiquement, et
    n'affecte jamais l'historique des mouvements déjà importés (qui reste lié
    par credit_client_id — une réinitialisation supprime donc aussi, en
    cascade, tout l'historique des mouvements, car les anciens clients
    n'existent plus)."""
    conn = get_conn()
    conn.execute("DELETE FROM credit_movements")
    conn.execute("DELETE FROM credit_clients")
    conn.execute("DELETE FROM ls_pending_accounts")
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    for r in rows:
        conn.execute(
            "INSERT INTO credit_clients(prenom_entreprise, nom, credit_limit, solde, deposit, ligne_source, created_at) "
            "VALUES (?,?,?,?,?,?,?)",
            (r['prenom_entreprise'], r.get('nom') or None, float(r.get('credit_limit') or 0),
             float(r.get('solde') or 0), float(r.get('deposit') or 0),
             str(r['ligne_source']) if r.get('ligne_source') not in (None, '') else None, now)
        )
    conn.commit()
    count = conn.execute("SELECT COUNT(*) c FROM credit_clients").fetchone()['c']
    conn.close()
    mark_dirty()
    return count


def db_import_credit_movements(rows):
    """Importe des mouvements (transactions Lightspeed). Un mouvement déjà
    importé (même lightspeed_id) est ignoré — permet de réimporter le même
    fichier par erreur sans dupliquer. Les autres sont ajoutés et le solde du
    client correspondant (trouvé par nom, créé automatiquement si absent) est
    mis à jour. Retourne un résumé {imported, skipped, created_clients}."""
    conn = get_conn()
    existing_ids = set(
        r['lightspeed_id'] for r in conn.execute(
            "SELECT lightspeed_id FROM credit_movements WHERE lightspeed_id IS NOT NULL"
        ).fetchall()
    )
    clients = conn.execute("SELECT * FROM credit_clients").fetchall()
    by_name = {}
    for c in clients:
        cd = dict(c)
        by_name[_norm_credit_name(_credit_client_display_name(cd))] = cd

    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    imported = 0
    skipped = 0
    created_clients = 0
    locked = 0

    for r in rows:
        lsid = str(r.get('lightspeed_id') or '').strip() or None
        if lsid and lsid in existing_ids:
            skipped += 1
            continue
        customer = (r.get('customer') or '').strip()
        key = _norm_credit_name(customer)
        client = by_name.get(key)
        if client and client.get('no_sync'):
            locked += 1
            continue
        if not client:
            cur = conn.execute(
                "INSERT INTO credit_clients(prenom_entreprise, nom, credit_limit, solde, deposit, notes, created_at) "
                "VALUES (?,?,?,?,?,?,?)",
                (customer or '(client inconnu)', None, 0, 0, 0,
                 "Créé automatiquement lors d'un import de mouvements Lightspeed — "
                 "aucun client existant ne correspond à ce nom, à vérifier.", now)
            )
            client = {'id': cur.lastrowid, 'solde': 0.0, 'deposit': 0.0}
            by_name[key] = client
            created_clients += 1

        montant = float(r.get('montant') or 0)
        conn.execute(
            "INSERT INTO credit_movements(credit_client_id, lightspeed_id, date_mouvement, montant, type, sale, "
            "customer_brut, notes, imported_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (client['id'], lsid, r.get('date'), montant, r.get('type'), r.get('sale'),
             customer, r.get('notes') or '', now)
        )
        client['solde'], client['deposit'] = _split_debt(_credit_net_debt(client) + montant)
        conn.execute("UPDATE credit_clients SET solde=?, deposit=? WHERE id=?",
                     (client['solde'], client['deposit'], client['id']))
        if lsid:
            existing_ids.add(lsid)
        imported += 1

    conn.commit()
    conn.close()
    mark_dirty()
    return {'imported': imported, 'skipped': skipped, 'created_clients': created_clients, 'locked': locked}


def db_update_credit_balances(rows):
    """Met à jour les soldes des comptes de crédit à partir d'un « instantané »
    mensuel Lightspeed (une ligne par client avec sa limite de crédit et son
    solde dû ACTUELS — pas une liste de transactions). Pour chaque ligne : le
    client est trouvé par nom (prénom/entreprise + nom, comparaison insensible
    à la casse/accents), créé automatiquement s'il n'existe pas encore, puis
    sa limite de crédit et son solde sont remplacés par les valeurs du fichier.
    Si le solde change, un mouvement synthétique (type « Ajustement mensuel »)
    est enregistré pour garder un historique consultable dans la fiche client.
    Retourne {updated, unchanged, created_clients}."""
    conn = get_conn()
    clients = conn.execute("SELECT * FROM credit_clients").fetchall()
    by_name = {}
    for c in clients:
        cd = dict(c)
        by_name[_norm_credit_name(_credit_client_display_name(cd))] = cd

    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    today_str = datetime.date.today().strftime('%Y-%m-%d')
    updated = 0
    unchanged = 0
    created_clients = 0
    locked = 0

    for r in rows:
        prenom = (r.get('prenom_entreprise') or '').strip()
        nom = (r.get('nom') or '').strip() or None
        display = _credit_client_display_name({'prenom_entreprise': prenom, 'nom': nom})
        key = _norm_credit_name(display)
        if not key:
            continue
        new_limit = float(r.get('credit_limit') or 0)
        # « Debt » Lightspeed : positif = montant dû ; négatif = crédit en
        # faveur du client, conservé comme dépôt (montant dû à 0).
        debt = float(r.get('solde') or 0)
        new_solde = max(debt, 0.0)
        new_deposit = max(-debt, 0.0)
        client = by_name.get(key)
        if client and client.get('no_sync'):
            locked += 1
            continue
        if not client:
            cur = conn.execute(
                "INSERT INTO credit_clients(prenom_entreprise, nom, credit_limit, solde, deposit, notes, created_at) "
                "VALUES (?,?,?,?,?,?,?)",
                (prenom or '(client inconnu)', nom, new_limit, new_solde, 0,
                 "Créé automatiquement lors d'un import d'instantané mensuel Lightspeed — "
                 "aucun client existant ne correspond à ce nom, à vérifier.", now)
            )
            client = {'id': cur.lastrowid, 'solde': 0.0, 'deposit': 0.0, 'credit_limit': 0.0}
            by_name[key] = client
            created_clients += 1

        old_solde = float(client.get('solde') or 0.0)
        old_deposit = float(client.get('deposit') or 0.0)
        # Ancien « Debt » équivalent : les fiches importées avant la 1.9.1
        # pouvaient avoir un solde négatif (Debt brut) — on le reprend tel quel
        # pour ne pas créer de faux mouvement lors de la conversion en dépôt.
        old_debt = old_solde if old_solde < 0 else old_solde - old_deposit
        delta = round(debt - old_debt, 2)
        conn.execute("UPDATE credit_clients SET credit_limit=?, solde=?, deposit=? WHERE id=?",
                     (new_limit, new_solde, new_deposit, client['id']))
        client['solde'] = new_solde
        client['deposit'] = new_deposit
        client['credit_limit'] = new_limit

        if abs(delta) >= 0.01:
            conn.execute(
                "INSERT INTO credit_movements(credit_client_id, lightspeed_id, date_mouvement, montant, type, sale, "
                "customer_brut, notes, imported_at) VALUES (?,?,?,?,?,?,?,?,?)",
                (client['id'], None, today_str, delta, 'Ajustement mensuel', None, display,
                 f"Instantané Lightspeed importé le {today_str} : Debt {old_debt:.2f}$ -> {debt:.2f}$", now)
            )
            updated += 1
        else:
            unchanged += 1

    conn.commit()
    conn.close()
    mark_dirty()
    return {'updated': updated, 'unchanged': unchanged, 'created_clients': created_clients, 'locked': locked}


def db_capture_credit_snapshot(label, source=None):
    """Prend une photo de l'état COMPLET de la liste des comptes de crédit
    (tous les clients, avec leur limite/solde/dépôt du moment) et la range
    dans credit_snapshots/credit_snapshot_lines. Appelé après chaque import
    (initial, instantané mensuel ou journal de transactions) pour garder un
    rapport téléchargeable par import, même si plusieurs imports ont lieu
    dans le même mois."""
    conn = get_conn()
    clients = conn.execute(
        "SELECT * FROM credit_clients ORDER BY prenom_entreprise COLLATE NOCASE, nom COLLATE NOCASE"
    ).fetchall()
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    total_limit = sum((c['credit_limit'] or 0) for c in clients)
    total_solde = sum((c['solde'] or 0) for c in clients)
    total_deposit = sum((c['deposit'] or 0) for c in clients)
    cur = conn.execute(
        "INSERT INTO credit_snapshots(created_at, label, source, client_count, total_credit_limit, "
        "total_solde, total_deposit) VALUES (?,?,?,?,?,?,?)",
        (now, label, source, len(clients), total_limit, total_solde, total_deposit)
    )
    snap_id = cur.lastrowid
    for c in clients:
        conn.execute(
            "INSERT INTO credit_snapshot_lines(snapshot_id, prenom_entreprise, nom, credit_limit, solde, deposit) "
            "VALUES (?,?,?,?,?,?)",
            (snap_id, c['prenom_entreprise'], c['nom'], c['credit_limit'] or 0, c['solde'] or 0, c['deposit'] or 0)
        )
    conn.commit()
    conn.close()
    mark_dirty()
    return snap_id


def db_list_credit_snapshots():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM credit_snapshots ORDER BY created_at DESC, id DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def db_get_credit_snapshot(snapshot_id):
    conn = get_conn()
    header = conn.execute("SELECT * FROM credit_snapshots WHERE id=?", (snapshot_id,)).fetchone()
    if not header:
        conn.close()
        return None, None
    lines = conn.execute(
        "SELECT * FROM credit_snapshot_lines WHERE snapshot_id=? "
        "ORDER BY prenom_entreprise COLLATE NOCASE, nom COLLATE NOCASE",
        (snapshot_id,)
    ).fetchall()
    conn.close()
    out_lines = []
    for l in lines:
        d = dict(l)
        d['display_name'] = _credit_client_display_name(d)
        out_lines.append(d)
    return dict(header), out_lines


# ============================================================
# Sauvegardes des comptes de crédit avant chaque importation (1.10.1)
# ------------------------------------------------------------
# Avant une réinitialisation, un import de mouvements ou une synchronisation
# Lightspeed, les tables des comptes de crédit sont copiées dans un petit
# fichier SQLite (C:\DBouxpCR\Backups_comptes_credit). Un administrateur peut
# ensuite remettre les comptes exactement comme avant. Les comptes à recevoir
# (factures) ne sont jamais touchés par une restauration.
# ============================================================
CREDIT_BACKUP_DIR = BASE_DIR / "Backups_comptes_credit"
CREDIT_BACKUP_KEEP = 60
CREDIT_BACKUP_TABLES = ('credit_clients', 'credit_movements', 'ls_pending_accounts')


def db_backup_credit(label, username):
    """Copie les comptes de crédit dans un fichier de sauvegarde. Retourne
    l'id de la sauvegarde. Lève RuntimeError si la copie échoue (l'importation
    qui suit doit alors être annulée)."""
    CREDIT_BACKUP_DIR.mkdir(exist_ok=True)
    now = datetime.datetime.now()
    path = CREDIT_BACKUP_DIR / f"comptes_credit_{now.strftime('%Y-%m-%d_%Hh%M%S')}_{secrets.token_hex(3)}.db"
    conn = get_conn()
    try:
        conn.execute("ATTACH DATABASE ? AS bk", (str(path),))
        conn.execute("BEGIN")
        for t in CREDIT_BACKUP_TABLES:
            conn.execute(f"CREATE TABLE bk.{t} AS SELECT * FROM main.{t}")
        conn.execute("COMMIT")
        conn.execute("DETACH DATABASE bk")
        t = conn.execute("SELECT COUNT(*) n, COALESCE(SUM(solde),0) s, COALESCE(SUM(deposit),0) d "
                         "FROM credit_clients").fetchone()
        mv = conn.execute("SELECT COUNT(*) n FROM credit_movements").fetchone()['n']
        cur = conn.execute(
            "INSERT INTO credit_backups(created_at, label, username, filename, client_count, movement_count, "
            "total_solde, total_deposit) VALUES (?,?,?,?,?,?,?,?)",
            (now.strftime('%Y-%m-%d %H:%M:%S'), label, username or '?', path.name,
             t['n'], mv, round(t['s'], 2), round(t['d'], 2)))
        conn.commit()
        backup_id = cur.lastrowid
    except Exception as e:
        traceback.print_exc()
        try:
            conn.rollback()
        except Exception:
            pass
        conn.close()
        try:
            path.unlink()
        except OSError:
            pass
        raise RuntimeError(f"La sauvegarde des comptes de crédit a échoué ({e}) : importation annulée, "
                           "aucune donnée n'a été modifiée.")
    conn.close()
    _prune_credit_backups()
    return backup_id


def _prune_credit_backups():
    conn = get_conn()
    try:
        old = conn.execute("SELECT id, filename FROM credit_backups ORDER BY id DESC LIMIT -1 OFFSET ?",
                           (CREDIT_BACKUP_KEEP,)).fetchall()
        for r in old:
            try:
                (CREDIT_BACKUP_DIR / r['filename']).unlink()
            except OSError:
                pass
            conn.execute("DELETE FROM credit_backups WHERE id=?", (r['id'],))
        conn.commit()
    finally:
        conn.close()


def db_discard_credit_backup(backup_id):
    """Supprime une sauvegarde devenue inutile (importation sans aucun changement)."""
    if not backup_id:
        return
    conn = get_conn()
    try:
        r = conn.execute("SELECT filename FROM credit_backups WHERE id=?", (backup_id,)).fetchone()
        if r:
            try:
                (CREDIT_BACKUP_DIR / r['filename']).unlink()
            except OSError:
                pass
            conn.execute("DELETE FROM credit_backups WHERE id=?", (backup_id,))
            conn.commit()
    finally:
        conn.close()


def db_list_credit_backups():
    conn = get_conn()
    rows = [dict(r) for r in conn.execute("SELECT * FROM credit_backups ORDER BY id DESC").fetchall()]
    conn.close()
    for r in rows:
        r['file_ok'] = (CREDIT_BACKUP_DIR / r['filename']).exists()
    return rows


def db_restore_credit_backup(backup_id, username):
    """Remet les comptes de crédit (comptes, historique, comptes Lightspeed en
    attente) tels qu'ils étaient dans la sauvegarde. L'état actuel est
    sauvegardé juste avant, pour pouvoir annuler la restauration."""
    conn = get_conn()
    b = conn.execute("SELECT * FROM credit_backups WHERE id=?", (backup_id,)).fetchone()
    conn.close()
    if b is None:
        raise RuntimeError("Sauvegarde introuvable.")
    b = dict(b)
    path = CREDIT_BACKUP_DIR / b['filename']
    if not path.exists():
        raise RuntimeError(f"Le fichier de sauvegarde est introuvable ({path}).")
    d, h = b['created_at'][:10], b['created_at'][11:16]
    pre_id = db_backup_credit(f"Avant restauration de la sauvegarde du {d[8:10]}-{d[5:7]}-{d[:4]} {h}", username)
    conn = get_conn()
    try:
        conn.execute("ATTACH DATABASE ? AS bk", (str(path),))
        bk_tables = {r['name'] for r in conn.execute("SELECT name FROM bk.sqlite_master WHERE type='table'")}
        if 'credit_clients' not in bk_tables:
            raise RuntimeError("Fichier de sauvegarde invalide.")
        conn.execute("BEGIN")
        try:
            for t in ('credit_movements', 'ls_pending_accounts', 'credit_clients'):
                conn.execute(f"DELETE FROM main.{t}")
            for t in ('credit_clients', 'credit_movements', 'ls_pending_accounts'):
                if t not in bk_tables:
                    continue
                main_cols = [r['name'] for r in conn.execute(f"PRAGMA main.table_info({t})")]
                bk_cols = {r['name'] for r in conn.execute(f"PRAGMA bk.table_info({t})")}
                cols = ", ".join(c for c in main_cols if c in bk_cols)
                conn.execute(f"INSERT INTO main.{t} ({cols}) SELECT {cols} FROM bk.{t}")
            conn.execute("UPDATE credit_backups SET restored_at=?, restored_by=? WHERE id=?",
                         (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), username or '?', backup_id))
            conn.execute("COMMIT")
        except Exception:
            conn.execute("ROLLBACK")
            raise
    finally:
        try:
            conn.execute("DETACH DATABASE bk")
        except Exception:
            pass
        conn.close()
    mark_dirty()
    return b, pre_id


# ============================================================
# Lightspeed R-Series — connexion à l'API et synchronisation des comptes de
# crédit (1.10.0). Remplace l'export manuel « credit_account_listings » : Kubios
# lit directement les comptes de crédit (CreditAccount) et leurs clients
# (Customer) dans Lightspeed, puis met à jour limite / montant dû / dépôt.
# Chaque compte Kubios est relié à son compte Lightspeed par son identifiant
# (credit_clients.ls_credit_account_id) — les homonymes ne se mélangent plus.
# Les jetons et le secret sont gardés dans la table meta (comme le mot de
# passe SMTP).
# ============================================================
LS_AUTH_BASE = os.environ.get('LS_AUTH_BASE', 'https://cloud.lightspeedapp.com/auth/oauth')
LS_API_BASE = os.environ.get('LS_API_BASE', 'https://api.lightspeedapp.com/API/V3')
LS_SCOPE = 'employee:all'
LS_PAGE_LIMIT = 100
LS_AUTO_CHECK_SECONDS = 300
LS_SYNC_MOVEMENT_TYPE = 'Synchronisation Lightspeed'
LS_BALANCE_SIGNS = ('auto', 'positive_du', 'negative_du')

_ls_sync_lock = threading.Lock()
_ls_token_lock = threading.Lock()
_ls_token_cache = {'access_token': None, 'expires': 0.0}
_ls_sync_state = {'running': False, 'started_at': None, 'finished_at': None,
                  'progress': '', 'result': None, 'error': None, 'by': None}


class LightspeedError(RuntimeError):
    pass


def meta_delete(*keys):
    conn = get_conn()
    for k in keys:
        conn.execute("DELETE FROM meta WHERE key=?", (k,))
    conn.commit()
    conn.close()


def ls_default_redirect_uri():
    # Lightspeed exige une adresse https:// : aucune page n'y répond, le
    # navigateur affiche une erreur et l'utilisateur colle l'adresse obtenue
    # (qui contient le code d'autorisation) dans Administration → Lightspeed.
    # La même adresse sert pour le test et la prod.
    return "https://localhost/kubios-lightspeed"


def ls_config():
    try:
        hour = int(meta_get('ls_auto_sync_hour') or 22)
    except ValueError:
        hour = 22
    sign = meta_get('ls_balance_sign') or 'auto'
    redirect_uri = (meta_get('ls_redirect_uri') or '').strip()
    if not redirect_uri or redirect_uri == f"http://localhost:{APP_PORT}/lightspeed/callback":
        # ancienne valeur proposée en 1.10.0/1.10.1, refusée par Lightspeed (http)
        redirect_uri = ls_default_redirect_uri()
    return {
        'client_id': (meta_get('ls_client_id') or '').strip(),
        'client_secret': (meta_get('ls_client_secret') or '').strip(),
        'redirect_uri': redirect_uri,
        'account_id': (meta_get('ls_account_id') or '').strip(),
        'account_name': meta_get('ls_account_name') or '',
        'connected': bool(meta_get('ls_refresh_token')),
        'balance_sign': sign if sign in LS_BALANCE_SIGNS else 'auto',
        'auto_sync': meta_get('ls_auto_sync') == '1',
        'auto_sync_hour': min(max(hour, 0), 23),
    }


def _truthy(v):
    return str(v).strip().lower() in ('1', 'true', 'yes', 'oui')


def _ls_header(headers, name):
    for k, v in (headers or {}).items():
        if k.lower() == name.lower():
            return v
    return None


def _ls_http(method, url, data=None, headers=None, timeout=60):
    """Requête HTTP vers Lightspeed. Retourne (statut, en-têtes, JSON)."""
    hdrs = {'Accept': 'application/json', 'User-Agent': f'Kubios/{APP_VERSION}'}
    hdrs.update(headers or {})
    body = None
    if data is not None:
        body = urllib.parse.urlencode(data).encode('utf-8')
        hdrs['Content-Type'] = 'application/x-www-form-urlencoded'
    req = urllib.request.Request(url, data=body, headers=hdrs, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode('utf-8', 'replace')
            return r.status, dict(r.headers), (json.loads(raw) if raw.strip() else {})
    except urllib.error.HTTPError as e:
        raw = e.read().decode('utf-8', 'replace')
        try:
            payload = json.loads(raw)
        except Exception:
            payload = {'raw': raw[:300]}
        return e.code, dict(e.headers or {}), payload if isinstance(payload, dict) else {'raw': str(payload)[:300]}
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        reason = getattr(e, 'reason', e)
        raise LightspeedError(f"Impossible de joindre Lightspeed ({reason}). Vérifie la connexion Internet.")
    except ValueError:
        raise LightspeedError("Réponse illisible reçue de Lightspeed.")


def _ls_error_text(payload, status):
    for k in ('error_description', 'message', 'error', 'raw'):
        v = (payload or {}).get(k)
        if v:
            return str(v)
    return f"HTTP {status}"


def _ls_token_request(data):
    cfg = ls_config()
    if not cfg['client_id'] or not cfg['client_secret']:
        raise LightspeedError("Le Client ID et le Client secret Lightspeed ne sont pas configurés "
                              "(Administration → Lightspeed).")
    data = dict(data, client_id=cfg['client_id'], client_secret=cfg['client_secret'])
    status, _, payload = _ls_http('POST', f"{LS_AUTH_BASE}/token", data=data, timeout=30)
    if status != 200 or not payload.get('access_token'):
        raise LightspeedError(f"Lightspeed a refusé l'authentification : {_ls_error_text(payload, status)}. "
                              "Si le problème persiste, reconnecte Kubios à Lightspeed (Administration).")
    _ls_token_cache['access_token'] = payload['access_token']
    try:
        expires_in = int(payload.get('expires_in') or 1800)
    except (TypeError, ValueError):
        expires_in = 1800
    _ls_token_cache['expires'] = time.time() + max(expires_in - 60, 60)
    # Lightspeed peut remettre un nouveau refresh token (l'ancien devient
    # alors invalide) : on le garde immédiatement.
    if payload.get('refresh_token'):
        meta_set('ls_refresh_token', payload['refresh_token'])
    return payload['access_token']


def ls_access_token(force_refresh=False):
    with _ls_token_lock:
        if not force_refresh and _ls_token_cache['access_token'] and time.time() < _ls_token_cache['expires']:
            return _ls_token_cache['access_token']
        rt = meta_get('ls_refresh_token')
        if not rt:
            raise LightspeedError("Kubios n'est pas connecté à Lightspeed "
                                  "(Administration → Lightspeed → Connecter à Lightspeed).")
        return _ls_token_request({'grant_type': 'refresh_token', 'refresh_token': rt})


def _ls_throttle(headers):
    """Respecte la limite de requêtes de Lightspeed (« seau » X-LS-API-Bucket-Level)."""
    level = _ls_header(headers, 'X-LS-API-Bucket-Level') or ''
    try:
        used, cap = (float(x) for x in level.split('/'))
        time.sleep(2.0 if cap and used / cap > 0.7 else 0.3)
    except Exception:
        time.sleep(0.5)


def _ls_api_get(path_or_url, params=None):
    url = path_or_url if path_or_url.startswith('http') else f"{LS_API_BASE}{path_or_url}"
    if params:
        url += ('&' if '?' in url else '?') + urllib.parse.urlencode(params)
    for attempt in range(6):
        token = ls_access_token(force_refresh=(attempt > 0 and _ls_token_cache['access_token'] is None))
        status, headers, payload = _ls_http('GET', url, headers={'Authorization': f'Bearer {token}'})
        if status == 200:
            _ls_throttle(headers)
            return payload
        if status == 401 and attempt == 0:
            _ls_token_cache['access_token'] = None
            continue
        if status in (429, 502, 503, 504):
            try:
                wait = float(_ls_header(headers, 'Retry-After') or 0)
            except ValueError:
                wait = 0
            time.sleep(min(max(wait, 2 ** attempt), 30))
            continue
        raise LightspeedError(f"Erreur de l'API Lightspeed (HTTP {status}) : {_ls_error_text(payload, status)}")
    raise LightspeedError("Lightspeed ne répond pas ou reçoit trop de requêtes. Réessaie dans quelques minutes.")


def _ls_as_list(v):
    if v is None or v == '':
        return []
    return v if isinstance(v, list) else [v]


def _ls_get_all(account_id, resource, params, label):
    """Lit toutes les pages d'une ressource (pagination « next » de l'API V3,
    ou par offset pour les réponses plus anciennes)."""
    base = f"/Account/{account_id}/{resource}.json"
    url, query = base, dict(params, limit=LS_PAGE_LIMIT)
    out = []
    for _ in range(2000):
        data = _ls_api_get(url, query)
        out.extend(_ls_as_list(data.get(resource)))
        _ls_sync_state['progress'] = f"{label} : {len(out)} lu(s)…"
        attrs = data.get('@attributes') or {}
        nxt = attrs.get('next')
        if nxt:
            url, query = nxt, None
            continue
        try:
            count = int(attrs.get('count') or 0)
            offset = int(attrs.get('offset') or 0)
            lim = int(attrs.get('limit') or LS_PAGE_LIMIT)
        except (TypeError, ValueError):
            break
        if 'offset' in attrs and offset + lim < count:
            url, query = base, dict(params, limit=LS_PAGE_LIMIT, offset=offset + lim)
            continue
        break
    return out


def ls_fetch_account():
    data = _ls_api_get('/Account.json')
    acc = _ls_as_list(data.get('Account'))
    if not acc:
        raise LightspeedError("Aucun compte Lightspeed accessible avec cette connexion.")
    return str(acc[0].get('accountID') or '').strip(), (acc[0].get('name') or '').strip()


def ls_fetch_credit_accounts(account_id):
    """Retourne (comptes, ignorés). Chaque compte : ls_id, ls_customer_id,
    prenom_entreprise, nom, credit_limit, balance (solde brut Lightspeed)."""
    accounts = _ls_get_all(account_id, 'CreditAccount', {}, 'Comptes de crédit')
    customers = _ls_get_all(account_id, 'Customer', {'creditAccountID': '>,0'}, 'Clients')
    by_ca = {}
    for c in customers:
        ca = str(c.get('creditAccountID') or '').strip()
        if ca and ca != '0':
            by_ca[ca] = c
    out = []
    skipped = {'gift_cards': 0, 'archived': 0}
    for a in accounts:
        if _truthy(a.get('giftCard')):
            skipped['gift_cards'] += 1
            continue
        if _truthy(a.get('archived')):
            skipped['archived'] += 1
            continue
        caid = str(a.get('creditAccountID') or '').strip()
        if not caid:
            continue
        cust = by_ca.get(caid) or {}
        first = (cust.get('firstName') or '').strip()
        last = (cust.get('lastName') or '').strip()
        company = (cust.get('company') or '').strip()
        prenom, nom = (first or company), last
        if not prenom:
            prenom, nom = last, ''
        if not prenom:
            prenom = (a.get('name') or '').strip() or f"Compte Lightspeed {caid}"
        out.append({
            'ls_id': caid,
            'ls_customer_id': str(cust.get('customerID') or '').strip() or None,
            'prenom_entreprise': prenom,
            'nom': nom or None,
            'credit_limit': round(_parse_money(a.get('creditLimit')), 2),
            'balance': round(_parse_money(a.get('balance')), 2),
        })
    return out, skipped


def _ls_debt(balance, sign):
    """« Debt » (positif = le client doit) à partir du solde brut Lightspeed."""
    return round(balance if sign == 'positive_du' else -balance, 2)


def _ls_detect_sign(rows):
    """Compare les soldes Lightspeed aux soldes actuels de Kubios (issus de
    l'export CSV) pour déterminer le sens du champ « balance »."""
    clients = db_list_credit_clients()
    by_lsid = {c['ls_credit_account_id']: c for c in clients if c.get('ls_credit_account_id')}
    names = {}
    for c in clients:
        names.setdefault(_norm_credit_name(c['display_name']), []).append(c)
    pos = neg = n = 0
    for r in rows:
        if abs(r['balance']) < 0.01:
            continue
        c = by_lsid.get(r['ls_id'])
        if c is None:
            same = names.get(_norm_credit_name(_credit_client_display_name(r))) or []
            c = same[0] if len(same) == 1 else None
        if c is None:
            continue
        d = _credit_net_debt(c)
        if abs(d) < 0.01:
            continue
        n += 1
        if abs(d - r['balance']) < 0.01:
            pos += 1
        elif abs(d + r['balance']) < 0.01:
            neg += 1
    if n >= 5 and pos >= 0.6 * n and pos > 2 * neg:
        return 'positive_du', (n, pos, neg)
    if n >= 5 and neg >= 0.6 * n and neg > 2 * pos:
        return 'negative_du', (n, pos, neg)
    raise LightspeedError(
        f"Impossible de déterminer automatiquement le sens du solde Lightspeed ({n} compte(s) comparé(s) : "
        f"{pos} concordent avec « positif = montant dû », {neg} avec « négatif = montant dû »). "
        "Choisis-le dans Administration → Lightspeed, puis relance la synchronisation.")


def _ls_apply_values(conn, client, row, debt, now, today, note):
    """Applique limite / dû / dépôt d'un compte Lightspeed à un compte Kubios.
    Retourne 'updated' ou 'unchanged'."""
    old_debt = _credit_net_debt(client)
    delta = round(debt - old_debt, 2)
    solde, deposit = _split_debt(debt)
    limit_changed = abs(float(client.get('credit_limit') or 0) - row['credit_limit']) >= 0.005
    raw_changed = (abs(float(client.get('solde') or 0) - solde) >= 0.005
                   or abs(float(client.get('deposit') or 0) - deposit) >= 0.005)
    if not (limit_changed or raw_changed or abs(delta) >= 0.01):
        return 'unchanged'
    conn.execute("UPDATE credit_clients SET credit_limit=?, solde=?, deposit=? WHERE id=?",
                 (row['credit_limit'], solde, deposit, client['id']))
    client.update(credit_limit=row['credit_limit'], solde=solde, deposit=deposit)
    # Seuil de 1,5 ¢ : d'anciens montants divisés par 2 (import du 29-09) ont
    # 3 décimales — l'arrondi à 2 décimales ne doit pas créer de faux mouvement.
    if abs(delta) >= 0.015:
        conn.execute(
            "INSERT INTO credit_movements(credit_client_id, lightspeed_id, date_mouvement, montant, type, sale, "
            "customer_brut, notes, imported_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (client['id'], None, today, delta, LS_SYNC_MOVEMENT_TYPE, None,
             _credit_client_display_name(row),
             f"{note} le {today} : Debt {old_debt:.2f}$ -> {debt:.2f}$", now))
    return 'updated'


def _ls_insert_client(conn, row, now, note):
    cur = conn.execute(
        "INSERT INTO credit_clients(prenom_entreprise, nom, credit_limit, solde, deposit, notes, created_at, "
        "ls_credit_account_id, ls_customer_id) VALUES (?,?,?,?,?,?,?,?,?)",
        (row['prenom_entreprise'], row['nom'], 0, 0, 0, note, now, row['ls_id'], row.get('ls_customer_id')))
    return {'id': cur.lastrowid, 'prenom_entreprise': row['prenom_entreprise'], 'nom': row['nom'],
            'credit_limit': 0.0, 'solde': 0.0, 'deposit': 0.0, 'no_sync': 0,
            'ls_credit_account_id': row['ls_id']}


def db_ls_apply(rows, sign):
    """Applique les comptes lus dans Lightspeed à la base Kubios.
    1) compte déjà relié (ls_credit_account_id) -> mis à jour ;
    2) sinon, un seul compte Kubios non relié porte le même nom ET un seul
       compte Lightspeed porte ce nom -> relié puis mis à jour ;
    3) homonymes -> mis de côté dans ls_pending_accounts (association
       manuelle dans la page Comptes de crédit), rien n'est modifié ;
    4) aucun compte de ce nom -> nouveau compte Kubios relié.
    Les comptes « Ne pas synchroniser » sont reliés mais jamais modifiés."""
    conn = get_conn()
    try:
        clients = [dict(r) for r in conn.execute("SELECT * FROM credit_clients").fetchall()]
        by_lsid = {c['ls_credit_account_id']: c for c in clients if c.get('ls_credit_account_id')}
        unlinked = {}
        for c in clients:
            if not c.get('ls_credit_account_id'):
                unlinked.setdefault(_norm_credit_name(_credit_client_display_name(c)), []).append(c)
        ls_name_count = {}
        for r in rows:
            if r['ls_id'] not in by_lsid:
                k = _norm_credit_name(_credit_client_display_name(r))
                ls_name_count[k] = ls_name_count.get(k, 0) + 1

        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        today = datetime.date.today().strftime('%Y-%m-%d')
        res = {'updated': 0, 'unchanged': 0, 'linked': 0, 'created': 0, 'renamed': 0,
               'locked': 0, 'pending': 0, 'missing': 0}
        pending = []
        seen_ids = set()
        for r in rows:
            seen_ids.add(r['ls_id'])
            debt = _ls_debt(r['balance'], sign)
            key = _norm_credit_name(_credit_client_display_name(r))
            client = by_lsid.get(r['ls_id'])
            if client is None:
                cands = unlinked.get(key) or []
                if len(cands) == 1 and ls_name_count.get(key, 0) == 1:
                    client = cands[0]
                    unlinked[key] = []
                    conn.execute("UPDATE credit_clients SET ls_credit_account_id=?, ls_customer_id=? WHERE id=?",
                                 (r['ls_id'], r.get('ls_customer_id'), client['id']))
                    client['ls_credit_account_id'] = r['ls_id']
                    res['linked'] += 1
                elif cands:
                    pending.append((r, debt))
                    continue
                else:
                    client = _ls_insert_client(conn, r, now,
                                               "Créé automatiquement par la synchronisation Lightspeed.")
                    res['created'] += 1
                by_lsid[r['ls_id']] = client
            if client.get('no_sync'):
                res['locked'] += 1
                continue
            if _norm_credit_name(_credit_client_display_name(client)) != key:
                conn.execute("UPDATE credit_clients SET prenom_entreprise=?, nom=? WHERE id=?",
                             (r['prenom_entreprise'], r['nom'], client['id']))
                client.update(prenom_entreprise=r['prenom_entreprise'], nom=r['nom'])
                res['renamed'] += 1
            res[_ls_apply_values(conn, client, r, debt, now, today, 'Synchronisation Lightspeed')] += 1

        res['missing'] = sum(1 for k in by_lsid if k not in seen_ids)
        conn.execute("DELETE FROM ls_pending_accounts")
        for r, debt in pending:
            conn.execute(
                "INSERT INTO ls_pending_accounts(ls_credit_account_id, ls_customer_id, prenom_entreprise, nom, "
                "credit_limit, debt, seen_at) VALUES (?,?,?,?,?,?,?)",
                (r['ls_id'], r.get('ls_customer_id'), r['prenom_entreprise'], r['nom'],
                 r['credit_limit'], debt, now))
        res['pending'] = len(pending)
        conn.commit()
        return res
    finally:
        conn.close()


def db_ls_list_pending():
    conn = get_conn()
    try:
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM ls_pending_accounts ORDER BY prenom_entreprise COLLATE NOCASE, nom COLLATE NOCASE"
        ).fetchall()]
        unlinked = {}
        for c in conn.execute("SELECT * FROM credit_clients WHERE ls_credit_account_id IS NULL").fetchall():
            c = dict(c)
            c['display_name'] = _credit_client_display_name(c)
            c['solde'], c['deposit'] = _split_debt(_credit_net_debt(c))
            unlinked.setdefault(_norm_credit_name(c['display_name']), []).append(
                {k: c[k] for k in ('id', 'display_name', 'credit_limit', 'solde', 'deposit', 'no_sync')})
        for r in rows:
            r['display_name'] = _credit_client_display_name(r)
            r['solde'], r['deposit'] = _split_debt(r['debt'])
            r['candidates'] = unlinked.get(_norm_credit_name(r['display_name']), [])
        return rows
    finally:
        conn.close()


def db_ls_link_pending(ls_id, client_id):
    """Associe un compte Lightspeed en attente à un compte Kubios existant
    (client_id) ou à un nouveau compte (client_id None). Retourne (client, action)."""
    conn = get_conn()
    try:
        p = conn.execute("SELECT * FROM ls_pending_accounts WHERE ls_credit_account_id=?", (ls_id,)).fetchone()
        if p is None:
            raise RuntimeError("Ce compte Lightspeed n'est plus en attente (relance la synchronisation).")
        p = dict(p)
        row = {'ls_id': p['ls_credit_account_id'], 'ls_customer_id': p['ls_customer_id'],
               'prenom_entreprise': p['prenom_entreprise'], 'nom': p['nom'],
               'credit_limit': float(p['credit_limit'] or 0)}
        if conn.execute("SELECT 1 FROM credit_clients WHERE ls_credit_account_id=?", (ls_id,)).fetchone():
            raise RuntimeError("Ce compte Lightspeed est déjà associé à un compte Kubios.")
        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        today = datetime.date.today().strftime('%Y-%m-%d')
        if client_id:
            c = conn.execute("SELECT * FROM credit_clients WHERE id=?", (client_id,)).fetchone()
            if c is None:
                raise RuntimeError("Compte Kubios introuvable.")
            client = dict(c)
            if client.get('ls_credit_account_id'):
                raise RuntimeError("Ce compte Kubios est déjà associé à un autre compte Lightspeed.")
            conn.execute("UPDATE credit_clients SET ls_credit_account_id=?, ls_customer_id=? WHERE id=?",
                         (ls_id, row['ls_customer_id'], client['id']))
            action = 'linked'
        else:
            client = _ls_insert_client(conn, row, now,
                                       "Créé lors d'une association manuelle (synchronisation Lightspeed).")
            action = 'created'
        if not client.get('no_sync'):
            _ls_apply_values(conn, client, row, float(p['debt'] or 0), now, today,
                             'Association manuelle Lightspeed')
        conn.execute("DELETE FROM ls_pending_accounts WHERE ls_credit_account_id=?", (ls_id,))
        conn.commit()
        client['display_name'] = _credit_client_display_name(client)
        return client, action, p
    finally:
        conn.close()


def _ls_result_text(res):
    parts = [f"{res.get('total', 0)} compte(s) lu(s)", f"{res['updated']} mis à jour",
             f"{res['unchanged']} inchangé(s)"]
    for k, lbl in (('created', "nouveau(x) compte(s) créé(s)"), ('linked', "associé(s) par nom"),
                   ('renamed', "nom(s) mis à jour"), ('pending', "homonyme(s) à associer manuellement"),
                   ('locked', "non synchronisé(s) ignoré(s)"), ('gift_cards', "carte(s)-cadeaux ignorée(s)"),
                   ('archived', "archivé(s) ignoré(s)"),
                   ('missing', "compte(s) Kubios relié(s) absent(s) de Lightspeed")):
        if res.get(k):
            parts.append(f"{res[k]} {lbl}")
    return ", ".join(parts)


def run_ls_sync(username, auto=False):
    """Synchronisation complète (appelée depuis un fil d'exécution). Lève
    LightspeedError en cas d'échec (le message est aussi gardé pour la page)."""
    if not _ls_sync_lock.acquire(blocking=False):
        raise LightspeedError("Une synchronisation Lightspeed est déjà en cours.")
    st = _ls_sync_state
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    st.update(running=True, started_at=now, finished_at=None, progress="Connexion à Lightspeed…",
              result=None, error=None, by=username)
    label = 'Synchronisation Lightspeed (comptes de crédit)' + (' — automatique' if auto else '')
    try:
        cfg = ls_config()
        account_id = cfg['account_id']
        if not account_id:
            account_id, name = ls_fetch_account()
            meta_set('ls_account_id', account_id)
            meta_set('ls_account_name', name)
        rows, skipped = ls_fetch_credit_accounts(account_id)
        sign = cfg['balance_sign']
        if sign not in ('positive_du', 'negative_du'):
            sign, (n, pos, neg) = _ls_detect_sign(rows)
            meta_set('ls_balance_sign', sign)
            db_add_audit(username, 'Lightspeed : sens du solde détecté',
                         ("positif = montant dû" if sign == 'positive_du' else "négatif = montant dû")
                         + f" ({n} compte(s) comparé(s), {pos}/{neg})")
        st['progress'] = "Sauvegarde des comptes avant la mise à jour…"
        try:
            backup_id = db_backup_credit(
                "Avant synchronisation Lightspeed" + (" automatique" if auto else ""), username)
        except RuntimeError as e:
            raise LightspeedError(str(e))
        st['progress'] = "Mise à jour des comptes…"
        res = db_ls_apply(rows, sign)
        if not any(res[k] for k in ('updated', 'created', 'linked', 'renamed')):
            db_discard_credit_backup(backup_id)
            backup_id = None
        res['backup_id'] = backup_id
        res.update(skipped)
        res['total'] = len(rows)
        res['snapshot_id'] = None
        if res['updated'] or res['created']:
            res['snapshot_id'] = db_capture_credit_snapshot(
                'Synchronisation Lightspeed (API)', 'API Lightspeed' + (' — automatique' if auto else ''))
        mark_dirty()
        done = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        meta_set('ls_last_sync', done)
        meta_set('ls_last_sync_result', json.dumps(res))
        meta_delete('ls_last_sync_error')
        db_add_audit(username, label, _ls_result_text(res))
        st['result'] = res
        return res
    except Exception as e:
        if not isinstance(e, LightspeedError):
            traceback.print_exc()
        msg = str(e) if isinstance(e, LightspeedError) else f"Erreur inattendue : {e}"
        st['error'] = msg
        meta_set('ls_last_sync_error', f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} — {msg}")
        db_add_audit(username, label + ' — échec', msg)
        raise LightspeedError(msg)
    finally:
        st['running'] = False
        st['finished_at'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        st['progress'] = ''
        _ls_sync_lock.release()


def start_ls_sync_thread(username, auto=False):
    if _ls_sync_state['running']:
        raise LightspeedError("Une synchronisation Lightspeed est déjà en cours.")

    def _run():
        try:
            run_ls_sync(username, auto=auto)
        except LightspeedError as e:
            print("Synchronisation Lightspeed :", e)

    threading.Thread(target=_run, daemon=True).start()


def _ls_auto_sync_loop():
    """Synchronisation automatique une fois par jour, à partir de l'heure
    choisie (Administration → Lightspeed). Un échec n'est pas retenté avant
    le lendemain ; il est affiché dans la page Comptes de crédit."""
    while True:
        time.sleep(LS_AUTO_CHECK_SECONDS)
        try:
            cfg = ls_config()
            if not cfg['auto_sync'] or not cfg['connected'] or _ls_sync_state['running']:
                continue
            now = datetime.datetime.now()
            today = now.strftime('%Y-%m-%d')
            if now.hour < cfg['auto_sync_hour'] or meta_get('ls_last_auto_sync_date') == today:
                continue
            meta_set('ls_last_auto_sync_date', today)
            run_ls_sync('Synchronisation automatique', auto=True)
        except Exception as e:
            print("Synchronisation Lightspeed automatique :", e)


# ============================================================
# Synchronisation SQLite -> Excel (opération lente, en arrière-plan ou à la demande)
# ============================================================
BACKUP_DIR = BASE_DIR / "Backups_auto"
BACKUP_DIR.mkdir(exist_ok=True)
MAX_BACKUPS = 20
_sync_lock = threading.Lock()
_sync_state = {"running": False, "last_error": None}


def _prune_backups():
    backups = sorted(BACKUP_DIR.glob("Compte à recevoir_*.xlsx"), key=lambda p: p.stat().st_mtime)
    for old in backups[:-MAX_BACKUPS]:
        try:
            old.unlink()
        except OSError:
            pass


def save_wb_atomic(wb):
    """Écriture atomique : fichier temporaire vérifié, puis remplacement. Une
    interruption pendant l'écriture ne peut jamais corrompre le fichier original."""
    if EXCEL_PATH.exists():
        try:
            stamp = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
            shutil.copy2(EXCEL_PATH, BACKUP_DIR / f"Compte à recevoir_{stamp}.xlsx")
            _prune_backups()
        except OSError:
            pass

    tmp_path = EXCEL_PATH.with_name(EXCEL_PATH.stem + ".tmp_write.xlsx")
    try:
        wb.save(tmp_path)
    except PermissionError:
        raise RuntimeError(
            "Impossible d'enregistrer : le fichier Excel est probablement ouvert. "
            "Ferme 'Compte à recevoir.xlsx' dans Excel puis réessaie."
        )
    try:
        check = openpyxl.load_workbook(tmp_path, read_only=True)
        check.close()
    except Exception as e:
        tmp_path.unlink(missing_ok=True)
        raise RuntimeError(f"Écriture invalide, annulée sans toucher l'original. Détail : {e}")
    os.replace(tmp_path, EXCEL_PATH)


def set_row_formulas(ws, row):
    # les tranches d'âge (G-J) se basent sur M (le solde restant après paiement),
    # pas sur F (le montant facturé au complet)
    ws.cell(row=row, column=7, value=f"=IF(TODAY()<=E{row},M{row},0)")
    ws.cell(row=row, column=8, value=f"=IF(AND(TODAY()>E{row},TODAY()-E{row}<=30),M{row},0)")
    ws.cell(row=row, column=9, value=f"=IF(AND(TODAY()-E{row}>30,TODAY()-E{row}<=60),M{row},0)")
    ws.cell(row=row, column=10, value=f"=IF(TODAY()-E{row}>60,M{row},0)")
    ws.cell(row=row, column=13, value=f"=F{row}-L{row}")  # solde = montant - payé
    for c in (7, 8, 9, 10, 12, 13):
        ws.cell(row=row, column=c).number_format = '#,##0.00;\\(#,##0.00\\)'


def refresh_header_sums(ws, last_row):
    last_row = max(last_row, FORMULA_MIN_LAST_ROW)
    for col in (6, 7, 8, 9, 10, 12, 13):
        letter = get_column_letter(col)
        ws.cell(row=2, column=col, value=f"=SUM({letter}3:{letter}{last_row})")


def write_client_sheet(ws, client_row, invoices):
    """Réécrit entièrement le bloc de factures d'un onglet client à partir des
    données SQLite (source unique de vérité)."""
    # efface l'ancien bloc de factures (colonnes C..M, à partir de la ligne 2)
    for r in range(2, max(ws.max_row, FORMULA_MIN_LAST_ROW) + 1):
        for c in range(3, 14):
            ws.cell(row=r, column=c).value = None

    ws.cell(row=1, column=12, value='Payé')
    ws.cell(row=1, column=13, value='Solde')

    ws.cell(row=2, column=1, value=client_row['name'])
    ws.cell(row=2, column=2, value=client_row['phone'] or '')
    ws.cell(row=INFO_ROWS['adresse'], column=1, value='Adresse')
    ws.cell(row=INFO_ROWS['adresse'], column=2, value=client_row['adresse'] or '')
    ws.cell(row=INFO_ROWS['ville'], column=1, value='Ville')
    ws.cell(row=INFO_ROWS['ville'], column=2, value=client_row['ville'] or '')
    ws.cell(row=INFO_ROWS['province'], column=1, value='Province')
    ws.cell(row=INFO_ROWS['province'], column=2, value=client_row['province'] or 'Qc')
    ws.cell(row=INFO_ROWS['code_postal'], column=1, value='Code Postal')
    ws.cell(row=INFO_ROWS['code_postal'], column=2, value=client_row['code_postal'] or '')
    ws.cell(row=INFO_ROWS['courriel'], column=1, value='Adresse couriel')
    ws.cell(row=INFO_ROWS['courriel'], column=2, value=client_row['courriel'] or '')

    row = FIRST_INVOICE_ROW
    for inv in invoices:
        ws.cell(row=row, column=3, value=inv['numero'])
        try:
            d = datetime.datetime.strptime(inv['date_facture'], '%Y-%m-%d') if inv['date_facture'] else None
        except ValueError:
            d = None
        try:
            e = datetime.datetime.strptime(inv['echeance'], '%Y-%m-%d') if inv['echeance'] else None
        except ValueError:
            e = None
        if d:
            ws.cell(row=row, column=4, value=d).number_format = 'dd-mm-yyyy'
        if e:
            ws.cell(row=row, column=5, value=e).number_format = 'dd/mm/yyyy'
        ws.cell(row=row, column=6, value=float(inv['montant'])).number_format = '#,##0.00;\\(#,##0.00\\)'
        if inv['notes']:
            ws.cell(row=row, column=11, value=inv['notes'])
        ws.cell(row=row, column=12, value=float(inv.get('montant_paye') or 0))
        set_row_formulas(ws, row)
        row += 1

    last_row = max(row - 1, FORMULA_MIN_LAST_ROW)
    refresh_header_sums(ws, last_row)


def export_to_excel():
    """Régénère le fichier Excel complet à partir de la base SQLite. Opération
    lente (~20-30s) — appelée en arrière-plan ou à la demande, jamais bloquante
    pour la saisie."""
    with _sync_lock:
        _sync_state["running"] = True
        _sync_state["last_error"] = None
        try:
            wb = openpyxl.load_workbook(EXCEL_PATH, data_only=False)
            conn = get_conn()
            # Renommages d'onglets en attente (clients renommés dans l'app).
            pending_row = conn.execute("SELECT value FROM meta WHERE key='pending_sheet_renames'").fetchone()
            try:
                pending_renames = json.loads(pending_row['value']) if pending_row and pending_row['value'] else []
            except Exception:
                pending_renames = []
            for old_sheet, new_sheet in pending_renames:
                if old_sheet not in wb.sheetnames or old_sheet == new_sheet:
                    continue
                if any(n.lower() == new_sheet.lower() for n in wb.sheetnames if n != old_sheet):
                    continue  # un onglet porte déjà ce nom : on ne touche à rien
                ws_r = wb[old_sheet]
                if old_sheet.lower() == new_sheet.lower():
                    # changement de majuscules seulement : openpyxl exige un nom intermédiaire
                    ws_r.title = "_renommage_tmp_"
                ws_r.title = new_sheet

            clients = conn.execute("SELECT * FROM clients ORDER BY name COLLATE NOCASE").fetchall()

            sommaire = wb[SOMMAIRE_SHEET]
            # efface les anciennes lignes du Sommaire (à partir de la ligne 3)
            for r in range(3, max(sommaire.max_row, len(clients) + 5) + 1):
                for c in range(1, 8):
                    sommaire.cell(row=r, column=c).value = None

            srow = 3
            for c in clients:
                sheet_name = c['sheet_name']
                if sheet_name not in wb.sheetnames:
                    ws = wb.copy_worksheet(wb[MODELE_SHEET])
                    ws.title = sheet_name
                    if ws.title != sheet_name:
                        # openpyxl a ajouté un suffixe (nom déjà pris) : on garde
                        # la base alignée sur le vrai nom de l'onglet.
                        conn.execute("UPDATE clients SET sheet_name=? WHERE name=?", (ws.title, c['name']))
                        sheet_name = ws.title
                else:
                    ws = wb[sheet_name]
                invoices = conn.execute(
                    "SELECT * FROM invoices WHERE client_name=? ORDER BY id", (c['name'],)
                ).fetchall()
                write_client_sheet(ws, c, [dict(i) for i in invoices])

                sommaire.cell(row=srow, column=1, value=c['name'])
                sommaire.cell(row=srow, column=2, value=f"='{sheet_name}'!G2")
                sommaire.cell(row=srow, column=3, value=f"='{sheet_name}'!H2")
                sommaire.cell(row=srow, column=4, value=f"='{sheet_name}'!I2")
                sommaire.cell(row=srow, column=5, value=f"='{sheet_name}'!J2")
                sommaire.cell(row=srow, column=6, value=f"='{sheet_name}'!M2")  # solde restant, pas le montant facturé
                sommaire.cell(row=srow, column=7, value=f"=SUM(B{srow}:E{srow})")
                srow += 1

            last_sommaire_row = max(srow - 1, 3)
            for col in (2, 3, 4, 5, 6):
                letter = get_column_letter(col)
                sommaire.cell(row=2, column=col, value=f"=SUM({letter}3:{letter}{last_sommaire_row})")
            sommaire.cell(row=2, column=7, value="=SUM(B2:E2)")

            counter_row = conn.execute("SELECT value FROM meta WHERE key='statement_counter'").fetchone()
            if counter_row:
                sommaire.cell(row=2, column=13, value=int(counter_row['value']))

            log_ws = wb[LOG_SHEET]
            pending_logs = conn.execute("SELECT * FROM log_envois WHERE synced=0 ORDER BY id").fetchall()
            r = log_ws.max_row + 1
            for lg in pending_logs:
                log_ws.cell(row=r, column=1, value=lg['ts'])
                log_ws.cell(row=r, column=2, value=lg['client'])
                log_ws.cell(row=r, column=3, value=lg['courriel'])
                log_ws.cell(row=r, column=4, value=lg['total'])
                log_ws.cell(row=r, column=5, value=lg['statut'])
                log_ws.cell(row=r, column=6, value=lg['note'])
                r += 1

            save_wb_atomic(wb)

            conn.execute("UPDATE log_envois SET synced=1 WHERE synced=0")
            conn.execute("DELETE FROM meta WHERE key='pending_sheet_renames'")
            conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('dirty', '0')")
            conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('last_sync', ?)",
                         (datetime.datetime.now().isoformat(),))
            conn.commit()
            conn.close()
        except Exception as e:
            _sync_state["last_error"] = str(e)
            traceback.print_exc()
            raise
        finally:
            _sync_state["running"] = False


def _auto_sync_loop():
    import time
    while True:
        time.sleep(AUTO_SYNC_SECONDS)
        try:
            if meta_get('dirty', '0') == '1' and not _sync_state["running"]:
                print("Synchronisation automatique vers Excel...")
                export_to_excel()
                print("Synchronisation automatique terminée.")
        except Exception as e:
            print("Erreur de synchronisation automatique :", e)


# ============================================================
# Génération du PDF (État de compte) — reproduit le modèle existant
# ============================================================
HEADER_RESERVED_HEIGHT = 62  # mm réservés en haut de la page 1 pour titre + logo


def generate_statement_pdf(client_name, info, invoices, totals, statement_number):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Table, TableStyle,
                                     Paragraph, Spacer, NextPageTemplate, PageBreak, ListFlowable,
                                     ListItem)
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

    safe_name = re.sub(r'[\\/:*?"<>|]', '_', client_name)
    pdf_path = PDF_DIR / f"Etat_de_compte_{safe_name}_{statement_number}.pdf"

    page_w, page_h = letter
    left_margin = right_margin = 18 * mm
    bottom_margin = 18 * mm

    styles = getSampleStyleSheet()
    h1 = ParagraphStyle('h1', parent=styles['Heading1'], fontSize=13, spaceAfter=6, spaceBefore=2)
    normal = ParagraphStyle('normal', parent=styles['Normal'], fontSize=10, leading=15)
    label_normal = ParagraphStyle('labelnormal', parent=normal)
    small = ParagraphStyle('small', parent=styles['Normal'], fontSize=9, leading=13)
    footer_style = ParagraphStyle('footer', parent=styles['Normal'], fontSize=10)

    emission_date = datetime.date.today().strftime('%Y-%m-%d')

    def draw_header(canvas, doc_):
        canvas.saveState()
        x = left_margin
        top = page_h - 20 * mm

        canvas.setFont('Helvetica-Bold', 22)
        canvas.drawString(x, top, "ÉTAT DE COMPTE")

        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 10 * mm, "Date d'émission :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 32 * mm, top - 10 * mm, emission_date)
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 15 * mm, "Numéro d'état de compte :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 45 * mm, top - 15 * mm, statement_number)

        if LOGO_PATH.exists():
            from reportlab.lib.utils import ImageReader
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            logo_w = 65 * mm
            logo_h = logo_w * ih / iw
            canvas.drawImage(img, page_w - right_margin - logo_w, top - logo_h + 4 * mm,
                              width=logo_w, height=logo_h, mask='auto')

        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.setLineWidth(0.5)
        rule_y = top - 22 * mm
        canvas.line(left_margin, rule_y, page_w - right_margin, rule_y)
        canvas.restoreState()

    def draw_plain(canvas, doc_):
        pass

    frame_first = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                         page_h - bottom_margin - HEADER_RESERVED_HEIGHT * mm, id='first')
    frame_rest = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                        page_h - bottom_margin - 15 * mm, id='rest')

    doc = BaseDocTemplate(str(pdf_path), pagesize=letter)
    doc.addPageTemplates([
        PageTemplate(id='First', frames=[frame_first], onPage=draw_header),
        PageTemplate(id='Rest', frames=[frame_rest], onPage=draw_plain),
    ])

    def field(label, value):
        return Paragraph(f"<b>{label} :</b> {value}", label_normal)

    story = []
    story.append(Paragraph("Information du client", h1))
    story.append(field("Client", client_name))
    story.append(field("Adresse", info.get('adresse', '') or '—'))
    ville_prov = f"{info.get('ville','')}, {info.get('province','')}".strip(', ')
    story.append(field("Ville / Province", ville_prov or '—'))
    story.append(field("Courriel", info.get('courriel', '') or '—'))
    story.append(field("Téléphone", info.get('phone', '') or '—'))
    story.append(Spacer(1, 6 * mm))

    from reportlab.platypus.flowables import HRFlowable
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))
    story.append(Spacer(1, 4 * mm))

    story.append(Paragraph("Sommaire des soldes", h1))
    tranche_rows = [
        ["Tranche", "Montant"],
        ["0 – 30 jours", f"{totals['g']:,.2f} $"],
        ["31 – 60 jours", f"{totals['h']:,.2f} $"],
        ["61 – 90 jours", f"{totals['i']:,.2f} $"],
        ["90+ jours", f"{totals['j']:,.2f} $"],
        ["TOTAL DÛ", f"{totals['montant']:,.2f} $"],
    ]
    tranche_table = Table(tranche_rows, colWidths=[70 * mm, 60 * mm])
    tranche_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('TOPPADDING', (0, 0), (-1, -1), 7),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
        ('LINEBELOW', (0, 0), (-1, 0), 0.5, colors.HexColor('#cccccc')),
        ('ALIGN', (1, 0), (1, -1), 'LEFT'),
    ]))
    story.append(tranche_table)
    story.append(Spacer(1, 4 * mm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))

    story.append(NextPageTemplate('Rest'))
    story.append(PageBreak())

    # Le montant affiché est le solde restant (montant facturé moins paiement partiel
    # déjà reçu) — une facture entièrement payée n'apparaît plus dans le détail.
    billable = [inv for inv in invoices if inv.get('solde', inv['montant']) != 0]
    has_partial = any(inv.get('montant_paye') for inv in billable)
    if billable:
        story.append(Paragraph("Détail des factures dues", h1))
        story.append(Spacer(1, 3 * mm))
        data = [["Facture", "Date", "Échéance", "Montant"]]
        for inv in billable:
            montant_affiche = inv.get('solde', inv['montant'])
            suffix = " *" if inv.get('montant_paye') else ""
            data.append([str(inv['numero']) + suffix, inv['date_facture'], inv['echeance'],
                         f"{montant_affiche:,.2f} $"])
        det_table = Table(data, colWidths=[38 * mm, 33 * mm, 33 * mm, 38 * mm], repeatRows=0)
        det_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
            ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ]))
        story.append(det_table)
        if has_partial:
            story.append(Spacer(1, 2 * mm))
            story.append(Paragraph("* Solde après un paiement partiel déjà reçu.", small))
        story.append(Spacer(1, 6 * mm))

    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph("Modalités et paiement", h1))
    bullets = [
        "Merci d'indiquer le <b>numéro de facture</b> lors du paiement.",
        "Pour toute question concernant votre état de compte, communiquez avec nous.",
        "Les montants indiqués sont dus immédiatement, sauf entente contraire.",
    ]
    story.append(ListFlowable(
        [ListItem(Paragraph(b, small), spaceAfter=4) for b in bullets],
        bulletType='bullet', start='circle', leftIndent=12,
    ))
    story.append(Spacer(1, 6 * mm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph(f"<b>{get_pdf_footer_message()}</b><br/>&nbsp;{get_company_name()}", footer_style))

    doc.build(story)
    return pdf_path


def db_invoices_by_month(year, month):
    """Toutes les factures dont la date de facture tombe dans le mois donné, groupées par client."""
    ym = f"{year:04d}-{month:02d}"
    conn = get_conn()
    rows = conn.execute(
        "SELECT client_name, numero, date_facture, echeance, montant, notes "
        "FROM invoices WHERE date_facture LIKE ? ORDER BY client_name COLLATE NOCASE, date_facture",
        (f"{ym}-%",)
    ).fetchall()
    conn.close()
    by_client = {}
    for r in rows:
        by_client.setdefault(r['client_name'], []).append(dict(r))
    return by_client


MOIS_FR = ["", "Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet",
           "Août", "Septembre", "Octobre", "Novembre", "Décembre"]


def generate_monthly_report_pdf(year, month, by_client):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Table, TableStyle,
                                     Paragraph, Spacer, NextPageTemplate, PageBreak)
    from reportlab.platypus.flowables import HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader

    mois_nom = MOIS_FR[month]
    report_dir = PDF_DIR / "Rapports_mensuels"
    report_dir.mkdir(exist_ok=True)
    pdf_path = report_dir / f"Rapport_{year:04d}-{month:02d}.pdf"

    page_w, page_h = letter
    left_margin = right_margin = 18 * mm
    bottom_margin = 18 * mm
    header_reserved = 55  # mm

    styles = getSampleStyleSheet()
    h1 = ParagraphStyle('h1', parent=styles['Heading1'], fontSize=12, spaceAfter=4, spaceBefore=8)
    footer_style = ParagraphStyle('footer', parent=styles['Normal'], fontSize=10)

    emission_date = datetime.date.today().strftime('%Y-%m-%d')

    def draw_header(canvas, doc_):
        canvas.saveState()
        x = left_margin
        top = page_h - 20 * mm
        canvas.setFont('Helvetica-Bold', 18)
        canvas.drawString(x, top, "RAPPORT MENSUEL — COMPTES À RECEVOIR")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 9 * mm, "Période :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 20 * mm, top - 9 * mm, f"{mois_nom} {year}")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 14 * mm, "Généré le :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 24 * mm, top - 14 * mm, emission_date)

        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            logo_w = 55 * mm
            logo_h = logo_w * ih / iw
            canvas.drawImage(img, page_w - right_margin - logo_w, top - logo_h + 2 * mm,
                              width=logo_w, height=logo_h, mask='auto')

        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.setLineWidth(0.5)
        rule_y = top - 19 * mm
        canvas.line(left_margin, rule_y, page_w - right_margin, rule_y)
        canvas.restoreState()

    def draw_plain(canvas, doc_):
        pass

    frame_first = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                         page_h - bottom_margin - header_reserved * mm, id='first')
    frame_rest = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                        page_h - bottom_margin - 15 * mm, id='rest')

    doc = BaseDocTemplate(str(pdf_path), pagesize=letter)
    doc.addPageTemplates([
        PageTemplate(id='First', frames=[frame_first], onPage=draw_header),
        PageTemplate(id='Rest', frames=[frame_rest], onPage=draw_plain),
    ])

    story = []
    client_names = sorted(by_client.keys(), key=lambda s: s.lower())
    grand_total = 0.0
    n_invoices = 0

    if not client_names:
        story.append(Paragraph(f"Aucune facture datée de {mois_nom} {year} n'a été trouvée.", styles['Normal']))
    else:
        for client_name in client_names:
            invs = by_client[client_name]
            subtotal = sum(i['montant'] for i in invs)
            grand_total += subtotal
            n_invoices += len(invs)

            story.append(Paragraph(client_name, h1))
            data = [["Facture", "Date", "Échéance", "Montant"]]
            for i in invs:
                data.append([str(i['numero']), i['date_facture'], i['echeance'] or '—',
                             f"{i['montant']:,.2f} $"])
            data.append(["", "", "Sous-total :", f"{subtotal:,.2f} $"])
            t = Table(data, colWidths=[38 * mm, 33 * mm, 33 * mm, 38 * mm], repeatRows=1)
            t.setStyle(TableStyle([
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 9),
                ('GRID', (0, 0), (-1, -2), 0.5, colors.black),
                ('LINEABOVE', (0, -1), (-1, -1), 0.75, colors.black),
                ('TOPPADDING', (0, 0), (-1, -1), 5),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ]))
            story.append(t)
            story.append(Spacer(1, 5 * mm))

        story.append(HRFlowable(width="100%", thickness=0.75, color=colors.HexColor('#333333')))
        story.append(Spacer(1, 3 * mm))
        story.append(Paragraph(
            f"<b>TOTAL — {n_invoices} facture(s), {len(client_names)} client(s) : {grand_total:,.2f} $</b>",
            footer_style))

    doc.build(story)
    return pdf_path


def db_envois_by_month(year, month):
    """Tous les courriels (brouillons et envois) enregistrés dans le mois donné."""
    ym = f"{year:04d}-{month:02d}"
    conn = get_conn()
    rows = conn.execute(
        "SELECT ts, client, courriel, total, statut, note FROM log_envois "
        "WHERE ts LIKE ? ORDER BY ts",
        (f"{ym}-%",)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def generate_envoi_report_pdf(year, month, rows):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Table, TableStyle,
                                     Paragraph, Spacer, NextPageTemplate, PageBreak)
    from reportlab.platypus.flowables import HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader

    mois_nom = MOIS_FR[month]
    report_dir = PDF_DIR / "Rapports_envois"
    report_dir.mkdir(exist_ok=True)
    pdf_path = report_dir / f"Rapport_envois_{year:04d}-{month:02d}.pdf"

    page_w, page_h = letter
    left_margin = right_margin = 18 * mm
    bottom_margin = 18 * mm
    header_reserved = 55  # mm

    styles = getSampleStyleSheet()
    footer_style = ParagraphStyle('footer', parent=styles['Normal'], fontSize=10)

    emission_date = datetime.date.today().strftime('%Y-%m-%d')

    def draw_header(canvas, doc_):
        canvas.saveState()
        x = left_margin
        top = page_h - 20 * mm
        canvas.setFont('Helvetica-Bold', 18)
        canvas.drawString(x, top, "RAPPORT D'ENVOI — COURRIELS")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 9 * mm, "Période :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 20 * mm, top - 9 * mm, f"{mois_nom} {year}")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 14 * mm, "Généré le :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 24 * mm, top - 14 * mm, emission_date)

        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            logo_w = 55 * mm
            logo_h = logo_w * ih / iw
            canvas.drawImage(img, page_w - right_margin - logo_w, top - logo_h + 2 * mm,
                              width=logo_w, height=logo_h, mask='auto')

        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.setLineWidth(0.5)
        rule_y = top - 19 * mm
        canvas.line(left_margin, rule_y, page_w - right_margin, rule_y)
        canvas.restoreState()

    def draw_plain(canvas, doc_):
        pass

    frame_first = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                         page_h - bottom_margin - header_reserved * mm, id='first')
    frame_rest = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                        page_h - bottom_margin - 15 * mm, id='rest')

    doc = BaseDocTemplate(str(pdf_path), pagesize=letter)
    doc.addPageTemplates([
        PageTemplate(id='First', frames=[frame_first], onPage=draw_header),
        PageTemplate(id='Rest', frames=[frame_rest], onPage=draw_plain),
    ])

    story = []
    if not rows:
        story.append(Paragraph(f"Aucun courriel enregistré pour {mois_nom} {year}.", styles['Normal']))
    else:
        data = [["Date / heure", "Client", "Courriel", "Montant", "Statut", "Note"]]
        grand_total = 0.0
        n_envoyes = 0
        for r in rows:
            ts_disp = (r['ts'] or '')[:16].replace('T', ' ')
            data.append([ts_disp, r['client'] or '', r['courriel'] or '—',
                         f"{(r['total'] or 0):,.2f} $", r['statut'] or '', r['note'] or ''])
            grand_total += (r['total'] or 0)
            if (r['statut'] or '').upper() == 'ENVOYÉ':
                n_envoyes += 1
        t = Table(data, colWidths=[28 * mm, 32 * mm, 38 * mm, 20 * mm, 18 * mm, 40 * mm], repeatRows=1)
        t.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ]))
        story.append(t)
        story.append(Spacer(1, 5 * mm))
        story.append(HRFlowable(width="100%", thickness=0.75, color=colors.HexColor('#333333')))
        story.append(Spacer(1, 3 * mm))
        story.append(Paragraph(
            f"<b>TOTAL — {len(rows)} courriel(s) enregistré(s), dont {n_envoyes} envoyé(s) "
            f"directement : {grand_total:,.2f} $</b>",
            footer_style))

    doc.build(story)
    return pdf_path


def month_end_or_today(year, month):
    """Dernier jour du mois choisi, sauf si c'est le mois en cours : dans ce cas on
    utilise la date d'aujourd'hui, pour que le rapport du mois courant corresponde
    exactement à l'état réel actuel."""
    import calendar
    today = datetime.date.today()
    if year == today.year and month == today.month:
        return today
    last_day = calendar.monthrange(year, month)[1]
    return datetime.date(year, month, last_day)


def db_aging_all_clients(ref_date=None):
    """Solde par tranche d'âge (0-30 / 31-60 / 61-90 / 90+), par client, pour tous les
    clients ayant un solde non nul, calculé par rapport à ref_date (aujourd'hui si non
    fourni). Si ref_date est fourni, seules les factures datées au plus tard à ref_date
    sont incluses (pour reproduire l'état tel qu'il était à la fin du mois choisi)."""
    conn = get_conn()
    clients = conn.execute("SELECT name FROM clients ORDER BY name COLLATE NOCASE").fetchall()
    rows = []
    ref_str = ref_date.strftime('%Y-%m-%d') if ref_date else None
    for c in clients:
        invs = conn.execute("SELECT * FROM invoices WHERE client_name=?", (c['name'],)).fetchall()
        if not invs:
            continue
        if ref_str:
            invs = [i for i in invs if (i['date_facture'] or '') <= ref_str]
        if not invs:
            continue
        totals = sum_totals(invoices_with_buckets(invs, ref_date))
        if abs(totals['montant']) < 0.005:
            continue
        rows.append({'name': c['name'], **totals})
    conn.close()
    rows.sort(key=lambda r: r['name'].lower())
    return rows


def generate_aging_report_pdf(rows, ref_date=None, period_label=None):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Table, TableStyle, Paragraph, Spacer
    from reportlab.platypus.flowables import HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader

    ref_date = ref_date or datetime.date.today()
    ref_str = ref_date.strftime('%Y-%m-%d')

    report_dir = PDF_DIR / "Rapports_mensuels"
    report_dir.mkdir(exist_ok=True)
    pdf_path = report_dir / f"Rapport_age_{ref_str}.pdf"

    page_w, page_h = letter
    left_margin = right_margin = 18 * mm
    bottom_margin = 18 * mm
    header_reserved = 50  # mm

    styles = getSampleStyleSheet()
    footer_style = ParagraphStyle('footer', parent=styles['Normal'], fontSize=10)

    emission_date = datetime.date.today().strftime('%Y-%m-%d')
    sous_titre = f"Tous les clients — soldes en date du {ref_str}" + (f" ({period_label})" if period_label else "")

    def draw_header(canvas, doc_):
        canvas.saveState()
        x = left_margin
        top = page_h - 20 * mm
        canvas.setFont('Helvetica-Bold', 16)
        canvas.drawString(x, top, "RAPPORT D'ÂGE DES COMPTES À RECEVOIR")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 9 * mm, "Généré le :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 22 * mm, top - 9 * mm, emission_date)
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x, top - 14 * mm, sous_titre)

        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            logo_w = 50 * mm
            logo_h = logo_w * ih / iw
            canvas.drawImage(img, page_w - right_margin - logo_w, top - logo_h + 2 * mm,
                              width=logo_w, height=logo_h, mask='auto')

        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.setLineWidth(0.5)
        rule_y = top - 18 * mm
        canvas.line(left_margin, rule_y, page_w - right_margin, rule_y)
        canvas.restoreState()

    def draw_plain(canvas, doc_):
        pass

    frame_first = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                         page_h - bottom_margin - header_reserved * mm, id='first')
    frame_rest = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                        page_h - bottom_margin - 15 * mm, id='rest')

    doc = BaseDocTemplate(str(pdf_path), pagesize=letter)
    doc.addPageTemplates([
        PageTemplate(id='First', frames=[frame_first], onPage=draw_header),
        PageTemplate(id='Rest', frames=[frame_rest], onPage=draw_plain),
    ])

    story = []
    if not rows:
        story.append(Paragraph("Aucun client avec un solde dû.", styles['Normal']))
    else:
        data = [["Client", "0 – 30 j", "31 – 60 j", "61 – 90 j", "90+ j", "Total"]]
        grand = {'g': 0.0, 'h': 0.0, 'i': 0.0, 'j': 0.0, 'montant': 0.0}
        for r in rows:
            data.append([
                r['name'],
                f"{r['g']:,.2f} $", f"{r['h']:,.2f} $", f"{r['i']:,.2f} $", f"{r['j']:,.2f} $",
                f"{r['montant']:,.2f} $",
            ])
            for k in ('g', 'h', 'i', 'j', 'montant'):
                grand[k] += r[k]
        data.append([
            "TOTAL — tous les clients",
            f"{grand['g']:,.2f} $", f"{grand['h']:,.2f} $", f"{grand['i']:,.2f} $", f"{grand['j']:,.2f} $",
            f"{grand['montant']:,.2f} $",
        ])

        t = Table(data, colWidths=[55 * mm, 26 * mm, 26 * mm, 26 * mm, 26 * mm, 26 * mm], repeatRows=1)
        t.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8.5),
            ('GRID', (0, 0), (-1, -2), 0.5, colors.black),
            ('LINEABOVE', (0, -1), (-1, -1), 0.75, colors.black),
            ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
            ('ALIGN', (0, 0), (0, -1), 'LEFT'),
            ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#f3f4f6')),
        ]))
        story.append(t)
        story.append(Spacer(1, 4 * mm))
        story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))
        story.append(Spacer(1, 3 * mm))
        story.append(Paragraph(
            f"<b>{len(rows)} client(s) avec solde dû — total général : {grand['montant']:,.2f} $</b>",
            footer_style))

    doc.build(story)
    return pdf_path


def generate_credit_accounts_pdf(rows, title, subtitle, filename_stub):
    """Génère un PDF listant les comptes de crédit (client / limite / solde /
    dépôt) avec le logo en haut à droite, sur le même modèle que les autres
    rapports (état de compte, rapport d'âge, etc.). `rows` doit contenir des
    dicts avec au moins display_name (ou prenom_entreprise/nom), credit_limit,
    solde, deposit."""
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Table, TableStyle, Paragraph, Spacer
    from reportlab.platypus.flowables import HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader

    report_dir = PDF_DIR / "Rapports_comptes_credit"
    report_dir.mkdir(exist_ok=True)
    safe_stub = re.sub(r'[^A-Za-z0-9_\-]+', '_', filename_stub)
    pdf_path = report_dir / f"{safe_stub}.pdf"

    page_w, page_h = letter
    left_margin = right_margin = 18 * mm
    bottom_margin = 18 * mm
    header_reserved = 50  # mm

    styles = getSampleStyleSheet()
    footer_style = ParagraphStyle('footer', parent=styles['Normal'], fontSize=10)
    emission_date = datetime.date.today().strftime('%Y-%m-%d')

    def draw_header(canvas, doc_):
        canvas.saveState()
        x = left_margin
        top = page_h - 20 * mm
        canvas.setFont('Helvetica-Bold', 16)
        canvas.drawString(x, top, title)
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 9 * mm, "Généré le :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 22 * mm, top - 9 * mm, emission_date)
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x, top - 14 * mm, subtitle)

        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            logo_w = 50 * mm
            logo_h = logo_w * ih / iw
            canvas.drawImage(img, page_w - right_margin - logo_w, top - logo_h + 2 * mm,
                              width=logo_w, height=logo_h, mask='auto')

        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.setLineWidth(0.5)
        rule_y = top - 18 * mm
        canvas.line(left_margin, rule_y, page_w - right_margin, rule_y)
        canvas.restoreState()

    def draw_plain(canvas, doc_):
        pass

    frame_first = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                         page_h - bottom_margin - header_reserved * mm, id='first')
    frame_rest = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                        page_h - bottom_margin - 15 * mm, id='rest')

    doc = BaseDocTemplate(str(pdf_path), pagesize=letter)
    doc.addPageTemplates([
        PageTemplate(id='First', frames=[frame_first], onPage=draw_header),
        PageTemplate(id='Rest', frames=[frame_rest], onPage=draw_plain),
    ])

    story = []
    if not rows:
        story.append(Paragraph("Aucun client.", styles['Normal']))
    else:
        data = [["Client", "Limite de crédit", "Solde dû", "Dépôt"]]
        grand = {'credit_limit': 0.0, 'solde': 0.0, 'deposit': 0.0}
        for r in rows:
            name = r.get('display_name') or _credit_client_display_name(r)
            climit = r.get('credit_limit') or 0
            solde = r.get('solde') or 0
            deposit = r.get('deposit') or 0
            data.append([
                name,
                f"{climit:,.2f} $", f"{solde:,.2f} $", f"{deposit:,.2f} $",
            ])
            grand['credit_limit'] += climit
            grand['solde'] += solde
            grand['deposit'] += deposit
        data.append([
            "TOTAL",
            f"{grand['credit_limit']:,.2f} $", f"{grand['solde']:,.2f} $", f"{grand['deposit']:,.2f} $",
        ])

        t = Table(data, colWidths=[80 * mm, 35 * mm, 35 * mm, 35 * mm], repeatRows=1)
        t.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8.5),
            ('GRID', (0, 0), (-1, -2), 0.5, colors.black),
            ('LINEABOVE', (0, -1), (-1, -1), 0.75, colors.black),
            ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
            ('ALIGN', (0, 0), (0, -1), 'LEFT'),
            ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#f3f4f6')),
        ]))
        story.append(t)
        story.append(Spacer(1, 4 * mm))
        story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))
        story.append(Spacer(1, 3 * mm))
        story.append(Paragraph(
            f"<b>{len(rows)} client(s) — total dû : {grand['solde']:,.2f} $ — "
            f"total dépôts : {grand['deposit']:,.2f} $</b>",
            footer_style))

    doc.build(story)
    return pdf_path


# ============================================================
# Envoi Outlook
# ============================================================
def send_via_outlook(to_email, subject, body, pdf_path, mode='draft'):
    """mode: 'send' envoie directement, 'draft' ouvre le courriel dans Outlook pour
    relecture, 'draft_silent' l'enregistre dans le dossier Brouillons sans ouvrir de
    fenêtre (utilisé pour la création en lot de plusieurs brouillons à la fois)."""
    import win32com.client as win32
    outlook = win32.Dispatch('outlook.application')
    mail = outlook.CreateItem(0)
    mail.To = to_email
    mail.BCC = get_company_email()
    mail.Subject = subject
    mail.Body = body
    mail.Attachments.Add(str(pdf_path))
    if mode == 'send':
        mail.Send()
        return 'ENVOYÉ'
    elif mode == 'draft_silent':
        mail.Save()
        return 'BROUILLON'
    else:
        mail.Display()
        return 'BROUILLON'


# ============================================================
# Création/envoi en lot pour tous les clients avec solde dû
# ============================================================
_bulk_state = {
    "running": False, "mode": None, "total": 0, "done": 0, "ok": 0, "skipped": 0, "errors": [],
    "finished_at": None,
}
_bulk_lock = threading.Lock()


def _run_bulk(mode, username=None):
    """mode: 'draft_silent' (brouillons dans Outlook, à réviser) ou 'send'
    (envoi direct immédiat, sans révision — irréversible)."""
    import pythoncom
    pythoncom.CoInitialize()
    try:
        clients = [c for c in db_list_clients() if c['solde'] and c['solde'] > 0]
        _bulk_state.update({"running": True, "mode": mode, "total": len(clients), "done": 0,
                             "ok": 0, "skipped": 0, "errors": [], "finished_at": None})
        for c in clients:
            name = c['name']
            try:
                detail = db_client_detail(name)
                to_email = detail['info'].get('courriel') or ''
                if not to_email:
                    _bulk_state["skipped"] += 1
                    _bulk_state["errors"].append(f"{name} : pas de courriel, ignoré")
                    _bulk_state["done"] += 1
                    continue
                statement_number = db_next_statement_number()
                pdf_path = generate_statement_pdf(name, detail['info'], detail['invoices'],
                                                    detail['totals'], statement_number)
                subject = f"État de compte — {name} ({statement_number})"
                body = (
                    f"Bonjour,\n\nVeuillez trouver ci-joint votre état de compte au "
                    f"{datetime.date.today().strftime('%d/%m/%Y')}.\n\n"
                    f"Solde total : {detail['totals']['montant']:,.2f} $\n\n"
                    f"{get_email_closing_message()}\n\n{get_sender_signature()}"
                )
                statut = send_email(to_email, subject, body, pdf_path, mode=mode)
                label = "Envoi en lot" if mode == 'send' else "Brouillon en lot"
                db_log_envoi(name, to_email, detail['totals']['montant'], statut,
                             f"{label} — {statement_number}")
                _bulk_state["ok"] += 1
            except Exception as e:
                _bulk_state["errors"].append(f"{name} : {e}")
            _bulk_state["done"] += 1
    finally:
        _bulk_state["running"] = False
        _bulk_state["finished_at"] = datetime.datetime.now().isoformat()
        label = "Envoi en lot" if mode == 'send' else "Brouillons en lot"
        db_add_audit(username, label,
                     f"{_bulk_state['ok']} envoyé(s), {_bulk_state['skipped']} ignoré(s), "
                     f"{len(_bulk_state['errors'])} erreur(s)")
        pythoncom.CoUninitialize()


# ============================================================
# Routes — licence
# ============================================================
@app.route('/activation')
def activation_page():
    status = get_license_status()
    if status['active']:
        # Licence valide : cette page devient une vue/renouvellement volontaire,
        # réservée à un administrateur ou à un utilisateur ayant la permission
        # "license", déjà connecté.
        if not (session.get('is_admin') or 'license' in (session.get('permissions') or [])):
            return redirect(url_for('index'))
    return render_template('activation.html', company=get_company_name(), status=status,
                            type_labels=licensing.TYPE_LABELS)


@app.route('/api/license/status')
def api_license_status():
    return jsonify(get_license_status())


@app.route('/api/license/activate', methods=['POST'])
def api_license_activate():
    data = request.json or {}
    code = (data.get('code') or '').strip()
    result = licensing.verify_license_code(code)
    if not result['ok']:
        return jsonify({'ok': False, 'error': result['error']}), 400

    payload = result['payload']
    expires = payload.get('expires')
    if expires:
        try:
            exp_date = datetime.date.fromisoformat(expires)
        except Exception:
            return jsonify({'ok': False, 'error': "Date d'expiration illisible dans ce code."}), 400
        today, clock_ok, local = get_trusted_today()
        if not clock_ok:
            return jsonify({'ok': False, 'error': _clock_problem_message(today, local)}), 400
        if exp_date < today:
            return jsonify({'ok': False, 'error':
                             f"Ce code de licence a expiré le {expires}. Demande un nouveau code."}), 400

    meta_set('license_code', code)
    label = licensing.TYPE_LABELS.get(payload['type'], payload['type'])
    username = session.get('username') or 'N/A (avant connexion)'
    db_add_audit(username, 'Licence activée',
                 f"{payload['licensee']} — {label}" +
                 (f" — expire le {expires}" if expires else " — à vie"))
    return jsonify({'ok': True, 'payload': payload, 'type_label': label})


# ============================================================
# Routes — connexion / utilisateurs
# ============================================================
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        user = db_verify_login(username, password)
        if user:
            session.clear()
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['is_admin'] = bool(user['is_admin'])
            session['permissions'] = user.get('permissions', [])
            session.permanent = True
            db_add_audit(user['username'], 'Connexion')
            nxt = request.form.get('next') or url_for('index')
            return redirect(nxt)
        error = "Nom d'utilisateur ou mot de passe incorrect."
    nxt = request.args.get('next', '')
    return render_template('login.html', app_name=APP_NAME, error=error, next=nxt,
                            year=datetime.date.today().year)


@app.route('/logout')
def logout():
    if session.get('username'):
        db_add_audit(session.get('username'), 'Déconnexion')
    session.clear()
    return redirect(url_for('login'))


@app.route('/admin/users')
def admin_users_page():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return render_template('admin_users.html', company=get_company_name(), username=session.get('username'),
                            permission_keys=PERMISSION_KEYS)


@app.route('/audit')
def audit_page():
    resp = permission_required_check('audit')
    if resp is not None:
        return resp
    return render_template('audit.html', company=get_company_name(), username=session.get('username'),
                            is_admin=session.get('is_admin', False), permissions=session.get('permissions') or [])


@app.route('/api/audit')
def api_audit():
    resp = permission_required_check('audit')
    if resp is not None:
        return resp
    return jsonify(db_list_audit())


@app.route('/admin/email-settings')
def email_settings_page():
    resp = permission_required_check('email_settings')
    if resp is not None:
        return resp
    return render_template('email_settings.html', company=get_company_name(), username=session.get('username'),
                            is_admin=session.get('is_admin', False), permissions=session.get('permissions') or [])


@app.route('/api/settings/send-mode')
def api_send_mode():
    return jsonify(get_public_settings())


# ============================================================
# Routes — Administration (personnalisation : nom d'entreprise, logo des
# PDF, textes des PDF/courriels). Réservé aux administrateurs.
# ============================================================
ADMIN_SETTINGS_LOGO_EXTS = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp'}
ADMIN_SETTINGS_LOGO_MAX_BYTES = 5 * 1024 * 1024  # 5 Mo


@app.route('/admin/settings')
def admin_settings_page():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return render_template('admin_settings.html', company=get_company_name(), app_name=APP_NAME,
                            username=session.get('username'))


@app.route('/api/admin-settings')
def api_get_admin_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return jsonify({
        'company_name': get_company_name(),
        'company_email': get_company_email(),
        'company_phone': get_company_phone(),
        'pdf_footer_message': get_pdf_footer_message(),
        'email_closing_message': get_email_closing_message(),
        'logo_customized': bool(meta_get('logo_customized')),
        'defaults': {
            'company_name': COMPANY_NAME_DEFAULT,
            'company_email': COMPANY_EMAIL_DEFAULT,
            'company_phone': COMPANY_PHONE_DEFAULT,
            'pdf_footer_message': PDF_FOOTER_MESSAGE_DEFAULT,
            'email_closing_message': EMAIL_CLOSING_MESSAGE_DEFAULT,
        },
    })


@app.route('/api/admin-settings', methods=['POST'])
def api_set_admin_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}

    name = (data.get('company_name') or '').strip()
    if not name:
        return jsonify({'error': 'Le nom de l\'entreprise est requis.'}), 400

    email = (data.get('company_email') or '').strip()
    if email and '@' not in email:
        return jsonify({'error': 'Adresse courriel invalide.'}), 400

    meta_set('company_name', name)
    meta_set('company_email', email)
    meta_set('company_phone', (data.get('company_phone') or '').strip())
    meta_set('pdf_footer_message', (data.get('pdf_footer_message') or '').strip() or PDF_FOOTER_MESSAGE_DEFAULT)
    meta_set('email_closing_message', (data.get('email_closing_message') or '').strip() or EMAIL_CLOSING_MESSAGE_DEFAULT)

    log_audit("Modification des paramètres de personnalisation (Administration)")
    return jsonify({'ok': True})


@app.route('/api/admin-settings/logo', methods=['POST'])
def api_upload_admin_logo():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if 'file' not in request.files or not request.files['file'].filename:
        return jsonify({'error': 'Aucun fichier reçu.'}), 400
    f = request.files['file']
    ext = Path(f.filename).suffix.lower()
    if ext not in ADMIN_SETTINGS_LOGO_EXTS:
        return jsonify({'error': 'Format d\'image non supporté (PNG, JPG, GIF, BMP ou WEBP).'}), 400
    raw = f.read()
    if not raw:
        return jsonify({'error': 'Fichier vide.'}), 400
    if len(raw) > ADMIN_SETTINGS_LOGO_MAX_BYTES:
        return jsonify({'error': 'Image trop volumineuse (max 5 Mo).'}), 400

    # On conserve une copie du logo d'origine avant la toute première
    # personnalisation, pour permettre un retour en arrière plus tard.
    if not meta_get('logo_customized') and LOGO_PATH.exists() and not LOGO_DEFAULT_BACKUP_PATH.exists():
        try:
            shutil.copyfile(str(LOGO_PATH), str(LOGO_DEFAULT_BACKUP_PATH))
        except Exception:
            pass

    LOGO_PATH.write_bytes(raw)
    meta_set('logo_customized', '1')
    log_audit("Changement du logo utilisé dans les PDF (Administration)", f.filename)
    return jsonify({'ok': True})


@app.route('/api/admin-settings/logo/reset', methods=['POST'])
def api_reset_admin_logo():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if LOGO_DEFAULT_BACKUP_PATH.exists():
        shutil.copyfile(str(LOGO_DEFAULT_BACKUP_PATH), str(LOGO_PATH))
    meta_set('logo_customized', '')
    log_audit("Réinitialisation du logo par défaut (Administration)")
    return jsonify({'ok': True})


# ============================================================
# Routes — mises à jour (version et changelog)
# ============================================================
@app.route('/admin/updates')
def updates_page():
    resp = permission_required_check('updates')
    if resp is not None:
        return resp
    return render_template('updates.html', company=get_company_name(), username=session.get('username'),
                            version=APP_VERSION, changelog=CHANGELOG,
                            is_admin=session.get('is_admin', False), permissions=session.get('permissions') or [])


@app.route('/api/updates')
def api_updates():
    resp = permission_required_check('updates')
    if resp is not None:
        return resp
    return jsonify({'version': APP_VERSION, 'changelog': CHANGELOG})


@app.route('/api/updates/check')
def api_updates_check():
    resp = permission_required_check('updates')
    if resp is not None:
        return resp
    try:
        req = urllib.request.Request(UPDATE_CHECK_URL, headers={'Cache-Control': 'no-cache'})
        with urllib.request.urlopen(req, timeout=6) as r:
            raw_body = r.read().decode('utf-8-sig').strip()
            remote = json.loads(raw_body)
    except urllib.error.URLError:
        return jsonify({'ok': False, 'error':
                         "Impossible de joindre le serveur de mises à jour. "
                         "Vérifie ta connexion Internet et réessaie."})
    except Exception as e:
        return jsonify({'ok': False, 'error':
                         "Réponse invalide du serveur de mises à jour (%s)." % e})

    remote_version = remote.get('version', '')
    remote_changelog = remote.get('changelog', [])
    try:
        up_to_date = _version_tuple(APP_VERSION) >= _version_tuple(remote_version)
    except Exception:
        return jsonify({'ok': False, 'error': "Numéro de version distant illisible."})

    # Les changements plus récents que la version installée (pour affichage).
    new_entries = [e for e in remote_changelog
                   if _version_tuple(e.get('version', '0.0.0')) > _version_tuple(APP_VERSION)]

    return jsonify({
        'ok': True,
        'installed_version': APP_VERSION,
        'latest_version': remote_version,
        'up_to_date': up_to_date,
        'new_entries': new_entries,
        'can_auto_install': bool(remote.get('download_url')),
    })


@app.route('/api/updates/install', methods=['POST'])
def api_updates_install():
    resp = permission_required_check('updates')
    if resp is not None:
        return resp

    body = request.get_json(silent=True) or {}
    restart_mode = body.get('restart_mode')
    if restart_mode not in ('service', 'startbat'):
        return jsonify({'ok': False, 'error':
                         "Précise comment cet ordinateur redémarre l'application "
                         "(service Windows ou start.bat) avant de continuer."}), 400

    try:
        req = urllib.request.Request(UPDATE_CHECK_URL, headers={'Cache-Control': 'no-cache'})
        with urllib.request.urlopen(req, timeout=6) as r:
            remote = json.loads(r.read().decode('utf-8-sig').strip())
    except Exception as e:
        return jsonify({'ok': False, 'error': "Impossible de joindre le serveur de mises à jour (%s)." % e}), 400

    download_url = remote.get('download_url')
    if not download_url:
        return jsonify({'ok': False, 'error':
                         "Aucun paquet de mise à jour téléchargeable pour l'instant. "
                         "Utilise « Vérifier les mises à jour » pour voir ce qui a changé."}), 400

    try:
        # Télécharge et extrait le paquet de code dans un dossier temporaire,
        # HORS du dossier de l'app (C:\DBouxpCR\app) — jamais dans le dossier
        # en cours d'utilisation par ce processus.
        if UPDATE_STAGING_DIR.exists():
            shutil.rmtree(UPDATE_STAGING_DIR, ignore_errors=True)
        UPDATE_STAGING_DIR.mkdir(parents=True, exist_ok=True)

        dl_req = urllib.request.Request(download_url, headers={'Cache-Control': 'no-cache'})
        with urllib.request.urlopen(dl_req, timeout=30) as r:
            zip_bytes = r.read()
        UPDATE_ZIP_PATH.write_bytes(zip_bytes)

        with zipfile.ZipFile(UPDATE_ZIP_PATH) as zf:
            zf.extractall(UPDATE_STAGING_DIR)

        staged_app_dir = UPDATE_STAGING_DIR / "app"
        if not (staged_app_dir / "app.py").exists():
            return jsonify({'ok': False, 'error':
                             "Le paquet téléchargé est invalide (app.py introuvable dedans)."}), 400
    except Exception as e:
        return jsonify({'ok': False, 'error': f"Échec du téléchargement du paquet : {e}"}), 400

    try:
        runner_src = _UPDATE_RUNNER_SCRIPT.format(
            staged=str(staged_app_dir), target=str(APP_DIR), base=str(BASE_DIR),
            restart_mode=restart_mode)
        UPDATE_RUNNER_PATH.write_text(runner_src, encoding='utf-8')

        creationflags = 0
        popen_kwargs = {'cwd': str(BASE_DIR), 'close_fds': True}
        if sys.platform == 'win32':
            creationflags = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
            popen_kwargs['creationflags'] = creationflags
        subprocess.Popen([_real_python_exe(), str(UPDATE_RUNNER_PATH)], **popen_kwargs)
    except Exception as e:
        return jsonify({'ok': False, 'error': f"Impossible de démarrer l'installation : {e}"}), 400

    db_add_audit(session.get('username'), 'Mise à jour installée', f"vers v{remote.get('version')}")

    # Laisse le temps à cette réponse HTTP de partir avant de fermer ce
    # processus — le script lancé ci-dessus attend, de son côté, que ce
    # processus soit bien terminé avant de copier les fichiers.
    def _delayed_exit():
        time.sleep(1.5)
        os._exit(0)
    threading.Thread(target=_delayed_exit, daemon=True).start()

    return jsonify({'ok': True, 'message':
                     "Téléchargement terminé. L'application redémarre maintenant — "
                     "recharge cette page dans environ 30 secondes."})


@app.route('/api/settings/email', methods=['GET'])
def api_get_email_settings():
    resp = permission_required_check('email_settings')
    if resp is not None:
        return resp
    settings = get_settings()
    settings['smtp_password_set'] = bool(settings.get('smtp_password'))
    settings.pop('smtp_password', None)
    return jsonify(settings)


@app.route('/api/settings/email', methods=['PUT'])
def api_set_email_settings():
    resp = permission_required_check('email_settings')
    if resp is not None:
        return resp
    data = request.json or {}
    send_mode = data.get('send_mode', 'outlook')
    if send_mode == 'smtp':
        host = (data.get('smtp_host') or '').strip()
        from_email = (data.get('smtp_from_email') or '').strip()
        if not host or not from_email:
            return jsonify({'ok': False, 'error':
                             "Pour activer le mode SMTP, il faut au minimum l'adresse du "
                             "serveur et l'adresse courriel d'expédition."}), 400
    set_settings(data)
    log_audit('Modification paramètres d\'envoi', f"mode={send_mode}")
    return jsonify({'ok': True})


@app.route('/api/settings/email/test', methods=['POST'])
def api_test_email_settings():
    resp = permission_required_check('email_settings')
    if resp is not None:
        return resp
    data = request.json or {}
    # Si le mot de passe n'est pas fourni (champ laissé vide dans le formulaire),
    # on utilise celui déjà enregistré pour permettre de tester sans le retaper.
    settings = dict(data)
    if not settings.get('smtp_password'):
        settings['smtp_password'] = meta_get('smtp_password', '')
    try:
        test_smtp_connection(settings)
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/users', methods=['GET'])
def api_list_users():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return jsonify(db_list_users())


@app.route('/api/users', methods=['POST'])
def api_create_user():
    resp = admin_required_check()
    if resp is not None:
        return resp
    data = request.json or {}
    try:
        db_create_user(data.get('username', ''), data.get('password', ''), bool(data.get('is_admin')),
                        permissions=data.get('permissions'))
        log_audit('Création utilisateur', data.get('username', ''))
        return jsonify({'ok': True})
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/users/<int:user_id>', methods=['PUT'])
def api_update_user(user_id):
    resp = admin_required_check()
    if resp is not None:
        return resp
    data = request.json or {}
    if user_id == session.get('user_id') and data.get('active') is False:
        return jsonify({'ok': False, 'error': "Tu ne peux pas désactiver ton propre compte."}), 400
    try:
        db_update_user(
            user_id,
            is_admin=data.get('is_admin'),
            active=data.get('active'),
            new_password=data.get('password') or None,
            permissions=data.get('permissions'),
        )
        target = db_get_user(user_id)
        target_name = target['username'] if target else str(user_id)
        changes = []
        if data.get('is_admin') is not None:
            changes.append('admin' if data.get('is_admin') else 'retrait admin')
        if data.get('active') is not None:
            changes.append('réactivé' if data.get('active') else 'désactivé')
        if data.get('password'):
            changes.append('mot de passe réinitialisé')
        if data.get('permissions') is not None:
            changes.append(f"accès : {', '.join(data.get('permissions')) or 'aucun'}")
        log_audit('Modification utilisateur', f"{target_name} ({', '.join(changes) or 'aucun changement'})")
        return jsonify({'ok': True})
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/users/<int:user_id>', methods=['DELETE'])
def api_delete_user(user_id):
    resp = admin_required_check()
    if resp is not None:
        return resp
    if user_id == session.get('user_id'):
        return jsonify({'ok': False, 'error': "Tu ne peux pas supprimer ton propre compte."}), 400
    target = db_get_user(user_id)
    db_delete_user(user_id)
    log_audit('Suppression utilisateur', target['username'] if target else str(user_id))
    return jsonify({'ok': True})


@app.route('/api/me')
def api_me():
    u = current_user()
    if not u:
        return jsonify({'error': 'auth_required'}), 401
    return jsonify({'username': u['username'], 'is_admin': bool(u['is_admin'])})


# ============================================================
# Routes
# ============================================================
@app.route('/')
def index():
    """Page d'accueil (menu) affichée juste après la connexion — donne accès
    aux différents volets du logiciel selon les permissions de la personne
    connectée, plutôt que d'atterrir directement sur les comptes à recevoir."""
    return render_template('home.html', company=get_company_name(), app_name=APP_NAME,
                            username=session.get('username'), is_admin=session.get('is_admin', False),
                            permissions=session.get('permissions') or [])


@app.route('/comptes-a-recevoir')
def car_page():
    return render_template('index.html', company=get_company_name(), company_email=get_company_email(),
                            username=session.get('username'), is_admin=session.get('is_admin', False),
                            permissions=session.get('permissions') or [])


@app.route('/api/clients')
def api_clients():
    clients = db_list_clients()
    return jsonify(clients)


@app.route('/api/client/<path:name>')
def api_client_detail(name):
    data = db_client_detail(name)
    if data is None:
        return jsonify({'error': 'Client introuvable'}), 404
    data['invoices'] = [i for i in data['invoices'] if i['montant'] != 0 or i['numero']]
    return jsonify(data)


@app.route('/api/client', methods=['POST'])
def api_create_client():
    data = request.json
    try:
        sheet_name = db_create_client(
            data['name'], data.get('phone', ''), data.get('adresse', ''),
            data.get('ville', ''), data.get('province', 'Qc'),
            data.get('code_postal', ''), data.get('courriel', ''),
        )
        log_audit('Création client', data['name'])
        return jsonify({'ok': True, 'sheet': sheet_name})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/client/<path:name>', methods=['PUT'])
def api_update_client(name):
    data = request.json or {}
    try:
        new_name, changes = db_update_client(
            name, data.get('name', ''), data.get('phone', ''), data.get('adresse', ''),
            data.get('ville', ''), data.get('province', 'Qc'),
            data.get('code_postal', ''), data.get('courriel', ''),
        )
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    if changes:
        details = "; ".join(f"{CLIENT_FIELD_LABELS.get(k, k)} : « {a} » → « {b} »" for k, a, b in changes)
        log_audit('Modification client', f"{name} — {details}")
    return jsonify({'ok': True, 'name': new_name, 'changed': len(changes)})


@app.route('/api/client/<path:name>/invoice', methods=['POST'])
def api_add_invoice(name):
    data = request.json
    try:
        db_add_invoice(
            name, data['numero'], data['date_facture'], data['echeance'],
            data['montant'], data.get('notes', ''), data.get('montant_paye', 0) or 0,
            data.get('date_paiement') or None,
        )
        log_audit('Ajout facture', f"{name} — n° {data['numero']} — {float(data['montant']):,.2f} $")
        return jsonify({'ok': True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/invoice/<int:invoice_id>', methods=['PUT'])
def api_update_invoice(invoice_id):
    data = request.json
    try:
        existing = db_get_invoice(invoice_id)
        db_update_invoice(
            invoice_id, data['numero'], data['date_facture'], data['echeance'],
            data['montant'], data.get('notes', ''), data.get('montant_paye', 0) or 0,
            data.get('date_paiement') or None,
        )
        client_name = existing['client_name'] if existing else ''
        log_audit('Modification facture', f"{client_name} — n° {data['numero']}")
        return jsonify({'ok': True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/invoice/<int:invoice_id>', methods=['DELETE'])
def api_delete_invoice(invoice_id):
    try:
        inv = db_get_invoice(invoice_id)
        db_delete_invoice(invoice_id)
        detail = f"{inv['client_name']} — n° {inv['numero']} — {inv['montant']:,.2f} $" if inv else f"id={invoice_id}"
        log_audit('Suppression facture', detail)
        return jsonify({'ok': True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/invoice/<int:invoice_id>/paid', methods=['PUT'])
def api_set_invoice_paid(invoice_id):
    data = request.json or {}
    try:
        paid = bool(data.get('paid', True))
        inv = db_get_invoice(invoice_id)
        db_set_invoice_paid(invoice_id, paid, data.get('date_paiement') or None)
        detail = f"{inv['client_name']} — n° {inv['numero']}" if inv else f"id={invoice_id}"
        is_credit = bool(inv) and float(inv['montant'] or 0) < 0
        if is_credit:
            log_audit('Crédit appliqué' if paid else 'Crédit appliqué annulé', detail)
        else:
            log_audit('Facture marquée payée' if paid else 'Paiement annulé', detail)
        return jsonify({'ok': True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/client/<path:name>/statement', methods=['POST'])
def api_statement(name):
    """Génère le PDF et (selon le mode) crée un brouillon ou envoie le courriel via Outlook.
    Ne touche pas à l'Excel — tout vient de la base rapide (le PDF/courriel n'a pas besoin
    d'attendre une synchronisation Excel)."""
    data = request.json or {}
    mode = data.get('mode', 'draft')
    if mode in ('draft', 'draft_silent') and get_settings()['send_mode'] == 'smtp':
        return jsonify({'ok': False, 'error':
                         "Le mode brouillon n'est pas disponible en mode d'envoi SMTP "
                         "(pas de fenêtre de relecture) — utilise \"Envoyer directement\"."}), 400
    try:
        client = db_client_detail(name)
        if client is None:
            return jsonify({'ok': False, 'error': 'Client introuvable'}), 404
        info, invoices, totals = client['info'], client['invoices'], client['totals']

        statement_number = db_next_statement_number()
        pdf_path = generate_statement_pdf(name, info, invoices, totals, statement_number)

        to_email = data.get('email') or info.get('courriel') or ''
        subject = data.get('subject') or f"État de compte — {name} ({statement_number})"
        body = data.get('body') or (
            f"Bonjour,\n\nVeuillez trouver ci-joint votre état de compte au "
            f"{datetime.date.today().strftime('%d/%m/%Y')}.\n\n"
            f"Solde total : {totals['montant']:,.2f} $\n\n"
            f"{get_email_closing_message()}\n\n{get_sender_signature()}"
        )

        if not to_email:
            statut = 'PDF_SEULEMENT'
            db_log_envoi(name, to_email, totals['montant'], statut, 'Aucun courriel client — PDF généré seulement')
            log_audit('État de compte généré', f"{name} — {statement_number} — PDF seulement (aucun courriel)")
            return jsonify({'ok': True, 'pdf': str(pdf_path), 'statut': statut,
                             'warning': "Aucune adresse courriel pour ce client — PDF généré mais courriel non préparé."})

        statut = send_email(to_email, subject, body, pdf_path, mode=mode)
        db_log_envoi(name, to_email, totals['montant'], statut, f"Via app locale ({mode}) — {statement_number}")
        log_audit('État de compte généré', f"{name} — {statement_number} — {mode} — {totals['montant']:,.2f} $")
        return jsonify({'ok': True, 'pdf': str(pdf_path), 'statut': statut, 'statement_number': statement_number})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/client/<path:name>/pdf')
def api_get_pdf(name):
    client = db_client_detail(name)
    if client is None:
        return jsonify({'error': 'Client introuvable'}), 404
    statement_number = db_next_statement_number()
    pdf_path = generate_statement_pdf(name, client['info'], client['invoices'], client['totals'], statement_number)
    log_audit('PDF état de compte téléchargé', f"{name} — {statement_number}")
    return send_file(str(pdf_path), as_attachment=True)


@app.route('/api/reports/monthly')
def api_monthly_report():
    resp = permission_required_check('reports')
    if resp is not None:
        return resp
    try:
        year = int(request.args.get('year'))
        month = int(request.args.get('month'))
        if not (1 <= month <= 12):
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({'error': "Paramètres 'year' et 'month' invalides."}), 400
    by_client = db_invoices_by_month(year, month)
    pdf_path = generate_monthly_report_pdf(year, month, by_client)
    log_audit('Rapport mensuel généré', f"{MOIS_FR[month]} {year}")
    return send_file(str(pdf_path), as_attachment=True,
                      download_name=f"Rapport_{MOIS_FR[month]}_{year}.pdf")


@app.route('/api/reports/envois')
def api_envois_report():
    resp = permission_required_check('reports')
    if resp is not None:
        return resp
    try:
        year = int(request.args.get('year'))
        month = int(request.args.get('month'))
        if not (1 <= month <= 12):
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({'error': "Paramètres 'year' et 'month' invalides."}), 400
    rows = db_envois_by_month(year, month)
    pdf_path = generate_envoi_report_pdf(year, month, rows)
    log_audit('Rapport d\'envoi généré', f"{MOIS_FR[month]} {year}")
    return send_file(str(pdf_path), as_attachment=True,
                      download_name=f"Rapport_envois_{MOIS_FR[month]}_{year}.pdf")


@app.route('/api/reports/aging')
def api_aging_report():
    resp = permission_required_check('reports')
    if resp is not None:
        return resp
    year_raw = request.args.get('year')
    month_raw = request.args.get('month')
    ref_date = None
    period_label = None
    if year_raw or month_raw:
        try:
            year = int(year_raw)
            month = int(month_raw)
            if not (1 <= month <= 12):
                raise ValueError
        except (TypeError, ValueError):
            return jsonify({'error': "Paramètres 'year' et 'month' invalides."}), 400
        ref_date = month_end_or_today(year, month)
        period_label = f"{MOIS_FR[month]} {year}"

    rows = db_aging_all_clients(ref_date)
    pdf_path = generate_aging_report_pdf(rows, ref_date, period_label)
    ref_str = (ref_date or datetime.date.today()).strftime('%Y-%m-%d')
    log_audit('Rapport d\'âge généré', period_label or "aujourd'hui")
    return send_file(str(pdf_path), as_attachment=True,
                      download_name=f"Rapport_age_{ref_str}.pdf")


@app.route('/comptes-de-credit')
def credit_accounts_page():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    return render_template('credit_accounts.html', company=get_company_name(),
                            username=session.get('username'), is_admin=session.get('is_admin'),
                            permissions=session.get('permissions') or [])


@app.route('/api/credit-clients')
def api_list_credit_clients():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    return jsonify(db_list_credit_clients())


@app.route('/api/credit-clients/<int:client_id>')
def api_get_credit_client(client_id):
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    client = db_get_credit_client(client_id)
    if not client:
        return jsonify({'error': 'Client introuvable.'}), 404
    client['movements'] = db_credit_client_movements(client_id)
    client['can_delete'] = bool(session.get('is_admin'))
    return jsonify(client)


def _fmt_credit_val(k, v):
    if k == 'no_sync':
        return "oui" if v else "non"
    if isinstance(v, (int, float)) and k != 'no_sync':
        return f"{float(v):,.2f} $".replace(',', ' ')
    return v if v not in (None, '') else '—'


@app.route('/api/credit-clients/<int:client_id>', methods=['PUT'])
def api_update_credit_client(client_id):
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    try:
        before, changes = db_update_credit_client(client_id, request.json or {})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    if changes:
        details = "; ".join(f"{CREDIT_FIELD_LABELS.get(k, k)} : {_fmt_credit_val(k, a)} → {_fmt_credit_val(k, b)}"
                            for k, a, b in changes)
        log_audit('Modification compte de crédit', f"{_credit_client_display_name(before)} — {details}")
    return jsonify({'ok': True, 'changed': len(changes)})


@app.route('/api/credit-clients/<int:client_id>', methods=['DELETE'])
def api_delete_credit_client(client_id):
    resp = admin_required_check()
    if resp is not None:
        return resp
    try:
        before, n = db_delete_credit_client(client_id)
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    log_audit('Suppression compte de crédit',
              f"{_credit_client_display_name(before)} — limite {_fmt_credit_val('x', before.get('credit_limit') or 0)}, "
              f"dû {_fmt_credit_val('x', before.get('solde') or 0)}, dépôt {_fmt_credit_val('x', before.get('deposit') or 0)}, "
              f"{n} mouvement(s) supprimé(s)")
    return jsonify({'ok': True})


@app.route('/api/credit-movements/<int:movement_id>', methods=['PUT'])
def api_update_credit_movement(movement_id):
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    try:
        before, after = db_update_credit_movement(movement_id, request.json or {})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    client = db_get_credit_client(before['credit_client_id']) or {}
    log_audit('Modification mouvement de crédit',
              f"{client.get('display_name', '?')} — {before.get('date_mouvement') or '—'} "
              f"{before.get('type') or ''} {float(before.get('montant') or 0):.2f} $ → "
              f"{after['date_mouvement'] or '—'} {after['type'] or ''} {after['montant']:.2f} $")
    return jsonify({'ok': True})


@app.route('/api/credit-movements/<int:movement_id>', methods=['DELETE'])
def api_delete_credit_movement(movement_id):
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    try:
        m = db_delete_credit_movement(movement_id)
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    client = db_get_credit_client(m['credit_client_id']) or {}
    log_audit('Suppression mouvement de crédit',
              f"{client.get('display_name', '?')} — {m.get('date_mouvement') or '—'} {m.get('type') or ''} "
              f"{float(m.get('montant') or 0):.2f} $ (solde ajusté)")
    return jsonify({'ok': True})


def _read_upload_rows(file_storage):
    """Lit un fichier .xlsx ou .csv téléversé et retourne (headers, rows) —
    rows est une liste de listes, headers la première ligne. Détecte le
    format par l'extension du nom de fichier."""
    filename = (file_storage.filename or '').lower()
    raw = file_storage.read()
    if filename.endswith('.csv'):
        try:
            text = raw.decode('utf-8-sig')
        except UnicodeDecodeError:
            text = raw.decode('latin-1')
        reader = csv.reader(io.StringIO(text))
        all_rows = [row for row in reader if any((c or '').strip() for c in row)]
        if not all_rows:
            return [], []
        return all_rows[0], all_rows[1:]
    else:
        wb = openpyxl.load_workbook(io.BytesIO(raw), data_only=True)
        ws = wb.worksheets[0]
        all_rows = [list(r) for r in ws.iter_rows(values_only=True)
                    if any(c not in (None, '') for c in r)]
        if not all_rows:
            return [], []
        return [str(h or '') for h in all_rows[0]], all_rows[1:]


def _find_col(headers, *candidates):
    """Trouve l'index d'une colonne par nom (insensible à la casse/accents
    approximative), en essayant chaque candidat dans l'ordre."""
    norm_headers = [(h or '').strip().lower() for h in headers]
    for cand in candidates:
        cand_l = cand.strip().lower()
        for i, h in enumerate(norm_headers):
            if h == cand_l:
                return i
    return None


def _parse_money(v):
    """Convertit une valeur monétaire venant d'un fichier importé (nombre,
    ou texte du genre "$150000.00", "$-219.30", "1 234,56$", "") en float.
    Tolère le symbole $ avant ou après le signe négatif, les espaces et les
    séparateurs de milliers (virgule ou espace)."""
    if v is None:
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    if not s:
        return 0.0
    neg = '-' in s
    s = s.replace('$', '').replace('-', '').replace(' ', '').replace('\xa0', '').replace('\u202f', '')
    if ',' in s and '.' not in s and re.search(r',\d{1,2}$', s):
        # Format français : la virgule est le séparateur décimal (« 1 234,56 $ »).
        s = s.replace(',', '.')
    else:
        s = s.replace(',', '')
    if not s:
        return 0.0
    try:
        val = float(s)
    except ValueError:
        return 0.0
    return -val if neg else val


@app.route('/api/credit-clients/import', methods=['POST'])
def api_import_credit_clients():
    # Remplace/réinitialise TOUTE la liste des clients (et supprime l'historique
    # des mouvements en cascade) — opération destructrice réservée aux
    # administrateurs, contrairement aux autres actions de ce module qui ne
    # demandent que la permission 'credit_accounts'.
    resp = admin_required_check()
    if resp is not None:
        return resp
    if 'file' not in request.files or not request.files['file'].filename:
        return jsonify({'ok': False, 'error': "Aucun fichier reçu."}), 400
    divide_by_2 = str(request.form.get('divide_by_2', '')).lower() in ('1', 'true', 'on')
    try:
        headers, data_rows = _read_upload_rows(request.files['file'])
        # Deux formats acceptés : le fichier en français (Prénom / Entreprise,
        # Nom, Limite de crédit, Montant dû, Dépôt) ou l'export Lightspeed
        # « credit_account_listings » en anglais (First Name, Last Name,
        # Credit Limit, Debt).
        i_prenom = _find_col(headers, 'Prénom / Entreprise', 'Prenom / Entreprise', 'First Name',
                             'Nom', 'Client')
        i_nom = _find_col(headers, 'Last Name') if _find_col(headers, 'First Name') == i_prenom \
            else _find_col(headers, 'Nom', 'Last Name')
        i_limit = _find_col(headers, 'Limite de crédit', 'Limite de credit', 'Credit Limit')
        i_du = _find_col(headers, 'Montant dû', 'Montant du', 'Debt', 'Solde')
        i_dep = _find_col(headers, 'Dépôt', 'Depot', 'Deposit')
        i_src = _find_col(headers, 'Ligne source')
        if i_prenom is None:
            return jsonify({'ok': False, 'error':
                             "Colonne du nom du client introuvable (attendu : "
                             "« Prénom / Entreprise » ou, pour l'export Lightspeed, "
                             "« First Name »)."}), 400
        rows = []
        for r in data_rows:
            def cell(i):
                return r[i] if i is not None and i < len(r) else None
            montant_du = _parse_money(cell(i_du))
            deposit = _parse_money(cell(i_dep))
            if i_dep is None and montant_du < 0:
                # Export Lightspeed (pas de colonne Dépôt) : un « Debt » négatif
                # est un crédit en faveur du client — c'est son dépôt, et il ne
                # doit rien.
                deposit = -montant_du
                montant_du = 0.0
            if divide_by_2:
                montant_du = montant_du / 2
                deposit = deposit / 2
            rows.append({
                'prenom_entreprise': (str(cell(i_prenom)).strip() if cell(i_prenom) is not None else ''),
                'nom': (str(cell(i_nom)).strip() or None) if cell(i_nom) is not None else None,
                'credit_limit': _parse_money(cell(i_limit)),
                'solde': montant_du,
                'deposit': deposit,
                'ligne_source': cell(i_src),
            })
        rows = [r for r in rows if r['prenom_entreprise']]
        db_backup_credit(f"Avant réinitialisation de la liste ({request.files['file'].filename})",
                         session.get('username'))
        count = db_import_credit_clients(rows)
        log_audit('Import liste comptes de crédit', f"{count} client(s)" + (" (montants divisés par 2)" if divide_by_2 else ""))
        snap_id = db_capture_credit_snapshot(
            'Import initial / réinitialisation de la liste', request.files['file'].filename)
        return jsonify({'ok': True, 'count': count, 'snapshot_id': snap_id})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/credit-movements/import', methods=['POST'])
def api_import_credit_movements():
    """Accepte deux formats de fichier Lightspeed, détectés automatiquement
    à partir des en-têtes de colonnes :
      1) Journal de transactions (colonnes Customer + Amount, ex. la feuille
         « Mouvements ») -> chaque ligne est ajoutée comme mouvement distinct.
      2) Instantané mensuel des soldes (colonnes First Name/Last Name +
         Debt/Credit Limit, ex. l'export récurrent
         « credit_account_listings... .csv ») -> chaque ligne remplace la
         limite de crédit et le solde actuel du client correspondant."""
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    if 'file' not in request.files or not request.files['file'].filename:
        return jsonify({'ok': False, 'error': "Aucun fichier reçu."}), 400
    try:
        headers, data_rows = _read_upload_rows(request.files['file'])
        i_amount = _find_col(headers, 'Amount', 'Montant')
        i_customer = _find_col(headers, 'Customer', 'Client')
        i_first = _find_col(headers, 'First Name', 'Prénom / Entreprise', 'Prenom / Entreprise', 'Prénom', 'Prenom')
        i_last = _find_col(headers, 'Last Name', 'Nom')
        i_debt = _find_col(headers, 'Debt', 'Montant dû', 'Montant du', 'Solde')
        i_limit = _find_col(headers, 'Credit Limit', 'Limite de crédit', 'Limite de credit')

        if i_customer is not None and i_amount is not None:
            # --- Format 1 : journal de transactions ---
            i_id = _find_col(headers, 'ID')
            i_date = _find_col(headers, 'Date')
            i_type = _find_col(headers, 'Type')
            i_sale = _find_col(headers, 'Sale')
            rows = []
            for r in data_rows:
                def cell(i):
                    return r[i] if i is not None and i < len(r) else None
                date_raw = cell(i_date)
                date_str = str(date_raw)[:10] if date_raw else None
                rows.append({
                    'lightspeed_id': cell(i_id),
                    'date': date_str,
                    'montant': _parse_money(cell(i_amount)),
                    'type': cell(i_type),
                    'sale': cell(i_sale),
                    'customer': cell(i_customer),
                })
            rows = [r for r in rows if r['customer']]
            backup_id = db_backup_credit(
                f"Avant import du journal de transactions ({request.files['file'].filename})",
                session.get('username'))
            summary = db_import_credit_movements(rows)
            if not summary['imported'] and not summary['created_clients']:
                db_discard_credit_backup(backup_id)
            log_audit('Import mouvements comptes de crédit (journal de transactions)',
                      f"{summary['imported']} importé(s), {summary['skipped']} ignoré(s) (déjà présents), "
                      f"{summary['created_clients']} nouveau(x) client(s), "
                      f"{summary['locked']} ligne(s) ignorée(s) (compte non synchronisé)")
            snap_id = db_capture_credit_snapshot(
                'Import journal de transactions', request.files['file'].filename)
            return jsonify({'ok': True, 'mode': 'transactions', 'snapshot_id': snap_id, **summary})

        elif i_first is not None and (i_debt is not None or i_limit is not None):
            # --- Format 2 : instantané mensuel des soldes ---
            rows = []
            for r in data_rows:
                def cell(i):
                    return r[i] if i is not None and i < len(r) else None
                prenom = cell(i_first)
                if not prenom:
                    continue
                rows.append({
                    'prenom_entreprise': prenom,
                    'nom': cell(i_last),
                    'credit_limit': _parse_money(cell(i_limit)),
                    'solde': _parse_money(cell(i_debt)),
                })
            backup_id = db_backup_credit(
                f"Avant import de l'instantané mensuel ({request.files['file'].filename})",
                session.get('username'))
            summary = db_update_credit_balances(rows)
            if not summary['updated'] and not summary['created_clients']:
                db_discard_credit_backup(backup_id)
            log_audit('Import mouvements comptes de crédit (instantané mensuel)',
                      f"{summary['updated']} solde(s) mis à jour, {summary['unchanged']} inchangé(s), "
                      f"{summary['created_clients']} nouveau(x) client(s), "
                      f"{summary['locked']} compte(s) non synchronisé(s) ignoré(s)")
            snap_id = db_capture_credit_snapshot(
                'Import instantané mensuel Lightspeed', request.files['file'].filename)
            return jsonify({'ok': True, 'mode': 'snapshot', 'snapshot_id': snap_id, **summary})

        else:
            return jsonify({'ok': False, 'error':
                             "Format de fichier non reconnu. Colonnes attendues : soit « Customer » "
                             "et « Amount » (journal de transactions), soit « First Name » et "
                             "« Debt » / « Credit Limit » (instantané mensuel Lightspeed)."}), 400
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/credit-snapshots')
def api_list_credit_snapshots():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    return jsonify(db_list_credit_snapshots())


@app.route('/api/credit-snapshots/<int:snapshot_id>/pdf')
def api_credit_snapshot_pdf(snapshot_id):
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    exclude_zero = str(request.args.get('exclude_zero', '')).lower() in ('1', 'true', 'on')
    header, lines = db_get_credit_snapshot(snapshot_id)
    if not header:
        return jsonify({'error': "Instantané introuvable."}), 404
    if exclude_zero:
        lines = [l for l in lines if (l.get('credit_limit') or 0) != 0
                 or (l.get('solde') or 0) != 0 or (l.get('deposit') or 0) != 0]
    dt = header['created_at']
    dt_label = dt[:16].replace('T', ' ')
    subtitle = f"Photo prise le {dt_label}" + (f" — {header['label']}" if header.get('label') else "")
    if exclude_zero:
        subtitle += " (clients à 0$ exclus)"
    pdf_path = generate_credit_accounts_pdf(
        lines, "COMPTES DE CRÉDIT", subtitle,
        f"Comptes_credit_{dt[:10]}_{dt[11:13]}h{dt[14:16]}_{snapshot_id}" + ('_sans0' if exclude_zero else '')
    )
    log_audit('PDF comptes de crédit généré', f"Import #{snapshot_id} du {dt_label}" +
              (" (clients à 0$ exclus)" if exclude_zero else ""))
    return send_file(str(pdf_path), as_attachment=True,
                      download_name=f"Comptes_de_credit_{dt[:10]}_{dt[11:13]}h{dt[14:16]}.pdf")


@app.route('/api/credit-clients/pdf')
def api_credit_clients_pdf():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    exclude_zero = str(request.args.get('exclude_zero', '')).lower() in ('1', 'true', 'on')
    clients = db_list_credit_clients()
    if exclude_zero:
        clients = [c for c in clients if (c.get('credit_limit') or 0) != 0
                   or (c.get('solde') or 0) != 0 or (c.get('deposit') or 0) != 0]
    today_str = datetime.date.today().strftime('%Y-%m-%d')
    subtitle = f"Liste actuelle au {today_str}" + (" (clients à 0$ exclus)" if exclude_zero else "")
    pdf_path = generate_credit_accounts_pdf(
        clients, "COMPTES DE CRÉDIT", subtitle,
        f"Comptes_credit_actuel_{today_str}" + ('_sans0' if exclude_zero else '')
    )
    log_audit('PDF comptes de crédit généré', "Liste actuelle" + (" (clients à 0$ exclus)" if exclude_zero else ""))
    return send_file(str(pdf_path), as_attachment=True,
                      download_name=f"Comptes_de_credit_actuel_{today_str}.pdf")


# ------------------------------------------------------------
# Routes — sauvegardes des comptes de crédit (1.10.1)
# ------------------------------------------------------------
@app.route('/api/credit-backups')
def api_list_credit_backups():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    return jsonify({'backups': db_list_credit_backups(), 'can_restore': bool(session.get('is_admin')),
                    'folder': str(CREDIT_BACKUP_DIR), 'keep': CREDIT_BACKUP_KEEP})


@app.route('/api/credit-backups/<int:backup_id>/restore', methods=['POST'])
def api_restore_credit_backup(backup_id):
    # Remplace toute la liste des comptes de crédit : réservé aux administrateurs.
    resp = admin_required_check()
    if resp is not None:
        return resp
    if not _ls_sync_lock.acquire(blocking=False):
        return jsonify({'ok': False, 'error': "Une synchronisation Lightspeed est en cours. "
                                              "Réessaie quand elle sera terminée."}), 409
    try:
        b, pre_id = db_restore_credit_backup(backup_id, session.get('username'))
    except RuntimeError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': f"Restauration impossible : {e}. Aucune donnée n'a été modifiée."}), 500
    finally:
        _ls_sync_lock.release()
    log_audit('Restauration des comptes de crédit',
              f"Sauvegarde du {b['created_at'][:16]} ({b['label']}) — {b['client_count']} compte(s), "
              f"{b['movement_count']} mouvement(s). L'état précédent a été sauvegardé (#{pre_id}).")
    return jsonify({'ok': True, 'client_count': b['client_count'], 'pre_backup_id': pre_id})


# ------------------------------------------------------------
# Routes — Lightspeed (1.10.0)
# ------------------------------------------------------------
def _ls_status_payload():
    cfg = ls_config()
    try:
        last_result = json.loads(meta_get('ls_last_sync_result') or 'null')
    except ValueError:
        last_result = None
    conn = get_conn()
    pending = conn.execute("SELECT COUNT(*) c FROM ls_pending_accounts").fetchone()['c']
    conn.close()
    return {
        'connected': cfg['connected'],
        'account_id': cfg['account_id'],
        'account_name': cfg['account_name'],
        'auto_sync': cfg['auto_sync'],
        'auto_sync_hour': cfg['auto_sync_hour'],
        'balance_sign': cfg['balance_sign'],
        'last_sync': meta_get('ls_last_sync'),
        'last_result': last_result,
        'last_result_text': _ls_result_text(last_result) if last_result else '',
        'last_error': meta_get('ls_last_sync_error'),
        'pending': pending,
        'running': _ls_sync_state['running'],
        'progress': _ls_sync_state['progress'],
        'current_error': _ls_sync_state['error'],
        'current_result': _ls_sync_state['result'],
        'current_result_text': _ls_result_text(_ls_sync_state['result']) if _ls_sync_state['result'] else '',
    }


@app.route('/api/lightspeed/settings')
def api_ls_get_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    cfg = ls_config()
    return jsonify({
        'client_id': cfg['client_id'],
        'secret_set': bool(cfg['client_secret']),
        'redirect_uri': cfg['redirect_uri'],
        'default_redirect_uri': ls_default_redirect_uri(),
        'connected': cfg['connected'],
        'account_id': cfg['account_id'],
        'account_name': cfg['account_name'],
        'balance_sign': cfg['balance_sign'],
        'auto_sync': cfg['auto_sync'],
        'auto_sync_hour': cfg['auto_sync_hour'],
        'last_sync': meta_get('ls_last_sync'),
    })


@app.route('/api/lightspeed/settings', methods=['POST'])
def api_ls_set_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}
    old = ls_config()
    client_id = (data.get('client_id') or '').strip()
    secret = (data.get('client_secret') or '').strip()
    redirect_uri = (data.get('redirect_uri') or '').strip() or ls_default_redirect_uri()
    if not redirect_uri.lower().startswith(('http://', 'https://')):
        return jsonify({'ok': False, 'error': "L'adresse de retour doit commencer par http:// ou https://."}), 400
    sign = data.get('balance_sign') or 'auto'
    if sign not in LS_BALANCE_SIGNS:
        return jsonify({'ok': False, 'error': "Sens du solde invalide."}), 400
    try:
        hour = int(data.get('auto_sync_hour', 22))
        if not 0 <= hour <= 23:
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': "Heure de synchronisation invalide."}), 400
    meta_set('ls_client_id', client_id)
    if secret:
        meta_set('ls_client_secret', secret)
    meta_set('ls_redirect_uri', redirect_uri)
    meta_set('ls_balance_sign', sign)
    meta_set('ls_auto_sync', '1' if data.get('auto_sync') else '0')
    meta_set('ls_auto_sync_hour', hour)
    disconnected = False
    if old['connected'] and (client_id != old['client_id'] or (secret and secret != old['client_secret'])):
        # Nouvelle application Lightspeed : l'ancienne connexion n'est plus valide.
        meta_delete('ls_refresh_token', 'ls_account_id', 'ls_account_name')
        _ls_token_cache['access_token'] = None
        disconnected = True
    changes = []
    if client_id != old['client_id']:
        changes.append("Client ID modifié")
    if secret:
        changes.append("Client secret modifié")
    if sign != old['balance_sign']:
        changes.append(f"sens du solde : {sign}")
    if bool(data.get('auto_sync')) != old['auto_sync'] or hour != old['auto_sync_hour']:
        changes.append("synchro automatique : " + (f"chaque jour à {hour} h" if data.get('auto_sync') else "désactivée"))
    log_audit('Paramètres Lightspeed modifiés', "; ".join(changes) or "aucun changement important")
    return jsonify({'ok': True, 'disconnected': disconnected})


@app.route('/lightspeed/connect')
def lightspeed_connect():
    resp = admin_required_check()
    if resp is not None:
        return resp
    cfg = ls_config()
    if not cfg['client_id'] or not cfg['client_secret']:
        return redirect(url_for('admin_settings_page'))
    state = secrets.token_urlsafe(24)
    meta_set('ls_oauth_state', json.dumps({'state': state, 'ts': time.time(),
                                           'username': session.get('username')}))
    params = {'response_type': 'code', 'client_id': cfg['client_id'], 'scope': LS_SCOPE,
              'state': state, 'redirect_uri': cfg['redirect_uri']}
    return redirect(f"{LS_AUTH_BASE}/authorize?" + urllib.parse.urlencode(params))


_LS_CALLBACK_PAGE = """<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Lightspeed — Kubios</title>
<style>body{margin:0;font-family:Segoe UI,Arial,sans-serif;background:#f4f6f8;color:#1f2937}
.box{max-width:520px;margin:60px auto;background:#fff;border:1px solid #e1e5ea;border-radius:10px;padding:24px}
h1{font-size:18px;margin-top:0}.ok{color:#166534}.err{color:#991b1b}a{color:#2563eb}</style></head>
<body><div class="box"><h1 class="{{ cls }}">{{ title }}</h1><p>{{ text }}</p>
<p><a href="{{ url_for('admin_settings_page') }}">Retour à l'administration</a> ·
<a href="{{ url_for('credit_accounts_page') }}">Comptes de crédit</a></p></div></body></html>"""


def _ls_complete_oauth(args):
    """Termine la connexion à partir des paramètres renvoyés par Lightspeed
    (code + state). Retourne (ok, titre, texte, statut HTTP)."""
    try:
        saved = json.loads(meta_get('ls_oauth_state') or '{}')
    except ValueError:
        saved = {}
    state = args.get('state') or ''
    if not saved.get('state') or not secrets.compare_digest(state, saved['state']) \
            or time.time() - float(saved.get('ts') or 0) > 900:
        return (False, "Connexion refusée",
                "La demande de connexion est expirée ou invalide (elle est valide 15 minutes et une seule "
                "fois). Recommence à partir de Administration → Lightspeed → Connecter à Lightspeed.", 400)
    meta_delete('ls_oauth_state')
    username = saved.get('username') or '?'
    if args.get('error'):
        db_add_audit(username, 'Connexion Lightspeed refusée', args.get('error'))
        return (False, "Connexion annulée",
                f"Lightspeed n'a pas autorisé la connexion ({args.get('error')}).", 400)
    code = args.get('code') or ''
    if not code:
        return (False, "Connexion refusée", "Lightspeed n'a pas renvoyé de code d'autorisation.", 400)
    try:
        _ls_token_request({'grant_type': 'authorization_code', 'code': code,
                           'redirect_uri': ls_config()['redirect_uri']})
        account_id, name = ls_fetch_account()
        meta_set('ls_account_id', account_id)
        meta_set('ls_account_name', name)
    except LightspeedError as e:
        db_add_audit(username, 'Connexion Lightspeed échouée', str(e))
        return (False, "Connexion échouée", str(e), 502)
    db_add_audit(username, 'Connexion à Lightspeed', f"Compte « {name} » (#{account_id})")
    return (True, "Kubios est connecté à Lightspeed",
            f"Compte « {name} » (#{account_id}). Tu peux maintenant synchroniser les comptes de "
            "crédit à partir de la page Comptes de crédit.", 200)


@app.route('/api/lightspeed/oauth-paste', methods=['POST'])
def api_ls_oauth_paste():
    """Fin de connexion par copier-coller : l'adresse https:// de retour n'est
    servie par personne, l'utilisateur colle l'adresse complète affichée par
    le navigateur (elle contient code=… et state=…)."""
    resp = admin_required_check()
    if resp is not None:
        return resp
    raw = ((request.get_json(silent=True) or {}).get('url') or '').strip()
    query = urllib.parse.urlparse(raw).query if '://' in raw else raw.lstrip('?')
    args = {k: v[0] for k, v in urllib.parse.parse_qs(query).items()}
    if not args.get('code') and not args.get('error'):
        return jsonify({'ok': False, 'error': "Cette adresse ne contient pas de code d'autorisation. Copie "
                                              "l'adresse complète de la barre d'adresse (elle contient « code= »)."}), 400
    ok, title, text, status = _ls_complete_oauth(args)
    return jsonify({'ok': ok, 'title': title, 'message': text}), (200 if ok else status)


@app.route('/lightspeed/callback')
def lightspeed_oauth_callback():
    """Retour de Lightspeed après autorisation. Exemptée de la connexion à
    Kubios (le navigateur peut revenir sur « localhost » sans le témoin de
    session) : protégée par le jeton « state » à usage unique, valide 15 min."""
    from flask import render_template_string

    def page(ok, title, text, code=200):
        return render_template_string(_LS_CALLBACK_PAGE, cls='ok' if ok else 'err',
                                      title=title, text=text), code

    return page(*_ls_complete_oauth(request.args))


@app.route('/api/lightspeed/disconnect', methods=['POST'])
def api_ls_disconnect():
    resp = admin_required_check()
    if resp is not None:
        return resp
    meta_delete('ls_refresh_token', 'ls_account_id', 'ls_account_name')
    _ls_token_cache['access_token'] = None
    log_audit('Déconnexion de Lightspeed')
    return jsonify({'ok': True})


@app.route('/api/lightspeed/test', methods=['POST'])
def api_ls_test():
    resp = admin_required_check()
    if resp is not None:
        return resp
    try:
        account_id, name = ls_fetch_account()
        meta_set('ls_account_id', account_id)
        meta_set('ls_account_name', name)
        return jsonify({'ok': True, 'account_id': account_id, 'account_name': name})
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 502


@app.route('/api/lightspeed/status')
def api_ls_status():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    return jsonify(_ls_status_payload())


@app.route('/api/lightspeed/sync', methods=['POST'])
def api_ls_sync():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    if not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Kubios n'est pas connecté à Lightspeed "
                                              "(Administration → Lightspeed)."}), 400
    try:
        start_ls_sync_thread(session.get('username'))
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    return jsonify({'ok': True})


@app.route('/api/lightspeed/pending')
def api_ls_pending():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    return jsonify(db_ls_list_pending())


@app.route('/api/lightspeed/pending/<ls_id>/link', methods=['POST'])
def api_ls_link_pending(ls_id):
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}
    client_id = data.get('client_id')
    try:
        client_id = int(client_id) if client_id not in (None, '', 'new') else None
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': "Compte Kubios invalide."}), 400
    if _ls_sync_state['running']:
        return jsonify({'ok': False, 'error': "Une synchronisation est en cours, réessaie dans un instant."}), 409
    try:
        client, action, p = db_ls_link_pending(ls_id, client_id)
    except RuntimeError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    mark_dirty()
    log_audit('Association manuelle Lightspeed',
              f"Compte Lightspeed #{ls_id} ({_credit_client_display_name(p)}) → "
              + ("nouveau compte Kubios" if action == 'created' else f"compte Kubios « {client['display_name']} »"))
    return jsonify({'ok': True, 'action': action, 'client_id': client['id']})


@app.route('/api/sync', methods=['POST'])
def api_sync():
    try:
        export_to_excel()
        log_audit('Synchronisation manuelle vers Excel')
        return jsonify({'ok': True, 'last_sync': meta_get('last_sync')})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/sync/status')
def api_sync_status():
    return jsonify({
        'dirty': meta_get('dirty', '0') == '1',
        'running': _sync_state["running"],
        'last_error': _sync_state["last_error"],
        'last_sync': meta_get('last_sync'),
    })


@app.route('/api/statements/bulk-draft', methods=['POST'])
def api_bulk_draft():
    if get_settings()['send_mode'] == 'smtp':
        return jsonify({'ok': False, 'error':
                         "Le mode brouillon n'est pas disponible en mode d'envoi SMTP "
                         "(pas de fenêtre de relecture) — utilise \"Envoyer directement\"."}), 400
    with _bulk_lock:
        if _bulk_state["running"]:
            return jsonify({'ok': False, 'error': 'Une opération en lot est déjà en cours.'}), 409
        t = threading.Thread(target=_run_bulk, args=('draft_silent', session.get('username')), daemon=True)
        t.start()
    return jsonify({'ok': True})


@app.route('/api/statements/bulk-send', methods=['POST'])
def api_bulk_send():
    with _bulk_lock:
        if _bulk_state["running"]:
            return jsonify({'ok': False, 'error': 'Une opération en lot est déjà en cours.'}), 409
        t = threading.Thread(target=_run_bulk, args=('send', session.get('username')), daemon=True)
        t.start()
    return jsonify({'ok': True})


@app.route('/api/statements/bulk-draft/status')
def api_bulk_draft_status():
    return jsonify(_bulk_state)


def _detect_lan_ip():
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))  # aucune donnée envoyée, juste pour détecter l'interface réseau
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return None


def start_app():
    """Point d'entrée commun : démarrage interactif (start.bat) ET démarrage
    comme service Windows (service.py) appellent cette même fonction, pour
    garantir exactement la même initialisation dans les deux cas."""
    print(f"Fichier Excel utilisé : {EXCEL_PATH}")
    if not EXCEL_PATH.exists():
        # Nouvelle installation (aucune donnée existante) : on part d'un
        # classeur vierge plutôt que de bloquer le démarrage.
        create_blank_excel_template(EXCEL_PATH)
    ensure_db_ready()
    app.secret_key = get_or_create_secret_key()
    app.config['PERMANENT_SESSION_LIFETIME'] = datetime.timedelta(days=30)
    ensure_admin_bootstrap()
    t = threading.Thread(target=_auto_sync_loop, daemon=True)
    t.start()
    threading.Thread(target=_net_time_loop, daemon=True).start()
    threading.Thread(target=_ls_auto_sync_loop, daemon=True).start()

    print()
    print("=" * 60)
    print(f"Accès depuis CET ordinateur :  http://127.0.0.1:{APP_PORT}")
    lan_ip = _detect_lan_ip()
    if lan_ip:
        print(f"Accès depuis un AUTRE ordinateur du même réseau :")
        print(f"    http://{lan_ip}:{APP_PORT}")
        print("(Windows peut demander une autorisation de pare-feu la")
        print(" première fois — accepte pour le réseau 'Privé'.)")
    print("=" * 60)
    print()

    # Serveur de production (Waitress) au lieu du serveur de développement
    # Flask — celui-ci n'est pas conçu pour tourner sans surveillance en
    # tant que service et affiche un avertissement à cet effet.
    from waitress import serve
    serve(app, host='0.0.0.0', port=APP_PORT, threads=8)


if __name__ == '__main__':
    start_app()
