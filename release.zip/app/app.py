# -*- coding: utf-8 -*-
"""
App locale de gestion des Comptes à recevoir.

Architecture (v2 — rapide) :
- Une base SQLite locale (data.db) est la source de données pour l'app :
  toutes les lectures/écritures (ajout de facture, nouveau client) sont
  quasi instantanées.
- Le fichier "Compte à recevoir.xlsx" reste le document "officiel" que tu
  peux ouvrir dans Excel — il est régénéré à partir de la base SQLite,
  soit automatiquement en arrière-plan (toutes les quelques minutes),
  soit à la demande (bouton "Synchroniser vers Excel").
- Au tout premier démarrage, toutes les données de l'Excel existant sont
  importées une seule fois dans la base (ça prend ~30s la première fois
  seulement). Ensuite, tout est instantané.

IMPORTANT : une fois l'app utilisée, la base SQLite devient la référence.
Si tu modifies le fichier Excel à la main entre deux synchronisations, ces
changements seront écrasés à la prochaine synchronisation. Fais tes
changements dans l'app plutôt que dans Excel.

Démarrage : double-cliquer sur start.bat (voir README.txt)
"""
import os
import re
import sys
import json
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
from pathlib import Path

from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash

import openpyxl
from openpyxl.utils import get_column_letter

import licensing

# ============================================================
# CONFIGURATION
# ============================================================
BASE_DIR = Path(__file__).resolve().parent.parent  # C:\DBouxpCR
EXCEL_PATH = BASE_DIR / "Compte à recevoir.xlsx"
PDF_DIR = BASE_DIR / "Etats_de_compte"
PDF_DIR.mkdir(exist_ok=True)
DB_PATH = Path(__file__).resolve().parent / "data.db"

APP_PORT = int(os.environ.get("APP_PORT", "5080"))

AUTO_SYNC_SECONDS = 180  # synchronise automatiquement vers Excel toutes les 3 minutes s'il y a des changements

COMPANY_NAME = "Outillages Express"
COMPANY_EMAIL = "recevables@outillagesexpress.ca"
COMPANY_PHONE = ""  # optionnel, à remplir
DEFAULT_SENDER_SIGNATURE = f"{COMPANY_NAME}\n{COMPANY_EMAIL}"
LOGO_PATH = Path(__file__).resolve().parent / "static" / "logo.png"

# ============================================================
# Version du logiciel et historique des changements
# ------------------------------------------------------------
# À chaque modification livrée, on ajoute une nouvelle entrée en haut de
# CHANGELOG et on augmente APP_VERSION. La page "Mises à jour" (admin)
# affiche cette liste — c'est la source de vérité pour savoir ce qui a
# changé et à quelle version l'application installée correspond.
# ============================================================
APP_VERSION = "1.6.2"

CHANGELOG = [
    {
        "version": "1.6.2",
        "date": "2026-09-27",
        "changes": [
            "Correctif : la vérification des mises à jour pouvait afficher "
            "« Réponse invalide du serveur de mises à jour » si le fichier de "
            "version en ligne contenait un caractère invisible en début de "
            "fichier ; le message d'erreur précise maintenant la cause exacte.",
        ],
    },
    {
        "version": "1.6.1",
        "date": "2026-09-27",
        "changes": [
            "Correctif : le résultat de « Vérifier les mises à jour » (nouvelle "
            "version disponible ou déjà à jour) ne s'affichait pas à l'écran "
            "même si la vérification fonctionnait correctement en arrière-plan.",
        ],
    },
    {
        "version": "1.6.0",
        "date": "2026-09-27",
        "changes": [
            "Installation automatique des mises à jour : le bouton « Installer "
            "maintenant » télécharge et applique lui-même une mise à jour "
            "détectée, puis redémarre l'application (les données du client — "
            "base de données, fichier Excel, PDF — ne sont jamais touchées).",
        ],
    },
    {
        "version": "1.5.0",
        "date": "2026-09-27",
        "changes": [
            "Ajout d'accès particuliers par utilisateur (Rapports, Audit, Licence, "
            "Paramètres d'envoi, Mises à jour) — gérable depuis la page Utilisateurs, "
            "en plus du statut administrateur.",
            "Ajout de la vérification en ligne des mises à jour (bouton « Vérifier "
            "les mises à jour »).",
        ],
    },
    {
        "version": "1.4.0",
        "date": "2026-09-27",
        "changes": [
            "Ajout d'une page « Mises à jour » (menu admin) qui affiche la version "
            "installée et l'historique complet des changements.",
        ],
    },
    {
        "version": "1.3.0",
        "date": "2026-09-26",
        "changes": [
            "Port de l'application changé de 5050 à 5080 (configurable via APP_PORT).",
            "Remplacement du serveur de développement Flask par un serveur de "
            "production (Waitress) — plus stable pour un usage continu.",
        ],
    },
    {
        "version": "1.2.0",
        "date": "2026-09-26",
        "changes": [
            "Ajout du démarrage automatique avec Windows (service Windows en "
            "arrière-plan, sans fenêtre visible).",
            "Préparation des outils pour produire un installateur Windows "
            "autonome (Setup.exe).",
        ],
    },
    {
        "version": "1.1.0",
        "date": "2026-09-26",
        "changes": [
            "Ajout du système de licence (activation par code — 30 jours, 1 an "
            "ou à vie — avec redemande automatique à l'expiration).",
            "Ajout du rapport mensuel d'envoi de courriels.",
            "Copie automatique (CCI) de chaque courriel envoyé vers "
            f"{COMPANY_EMAIL}.",
            "Possibilité de modifier le sujet et le message avant l'envoi d'un "
            "état de compte.",
        ],
    },
    {
        "version": "1.0.0",
        "date": None,
        "changes": [
            "Version de référence : gestion des comptes à recevoir, paiements "
            "partiels, envoi des états de compte par Outlook ou par serveur "
            "SMTP, journal d'audit, gestion des utilisateurs et permissions.",
        ],
    },
]

# URL publique (dépôt GitHub géré par Claude) où est déposé, à chaque mise à
# jour livrée, un petit fichier version.json contenant le numéro de version
# le plus récent et son changelog. Ne contient aucune donnée d'entreprise.
UPDATE_CHECK_URL = "https://raw.githubusercontent.com/woofer737/drouxpcr/main/version.json"


def _version_tuple(v):
    """Convertit "1.4.0" en (1, 4, 0) pour pouvoir comparer deux versions."""
    return tuple(int(part) for part in v.strip().split('.'))


# ------------------------------------------------------------
# Installation automatique des mises à jour
# ------------------------------------------------------------
# APP_DIR = C:\DBouxpCR\app (contient app.py, templates, static — remplacé
# par une mise à jour). BASE_DIR = C:\DBouxpCR (contient aussi les données
# du client : data.db, le fichier Excel, les PDF — jamais touchées).
APP_DIR = Path(__file__).resolve().parent
UPDATE_STAGING_DIR = BASE_DIR / "_update_staging"
UPDATE_ZIP_PATH = BASE_DIR / "_update_download.zip"
UPDATE_LOG_PATH = BASE_DIR / "_update_log.txt"
UPDATE_RUNNER_PATH = BASE_DIR / "_run_update.py"

# Script exécuté dans un processus séparé, après que ce processus-ci se soit
# terminé (pour ne jamais copier par-dessus des fichiers encore ouverts). Il
# copie uniquement le CODE (jamais data.db, les .xlsx, service.log,
# __pycache__, .venv), réinstalle les dépendances, puis relance l'app —
# comme service Windows si celui-ci est installé, sinon en rouvrant
# start.bat dans une nouvelle fenêtre.
_UPDATE_RUNNER_SCRIPT = r'''
import os, sys, shutil, subprocess, time

STAGED = r"{staged}"
TARGET = r"{target}"
BASE = r"{base}"
LOG_PATH = os.path.join(BASE, "_update_log.txt")

def log(msg):
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(time.strftime("%Y-%m-%d %H:%M:%S") + " - " + msg + "\n")

EXCLUDE_NAMES = {{"__pycache__", ".venv"}}
EXCLUDE_FILES = {{"data.db", "service.log"}}
EXCLUDE_EXT = (".xlsx", ".db")

def copy_tree(src, dst):
    for name in os.listdir(src):
        if name in EXCLUDE_NAMES:
            continue
        s = os.path.join(src, name)
        d = os.path.join(dst, name)
        if os.path.isdir(s):
            os.makedirs(d, exist_ok=True)
            copy_tree(s, d)
        else:
            if name in EXCLUDE_FILES or name.lower().endswith(EXCLUDE_EXT):
                continue
            shutil.copy2(s, d)

log("=== Debut de la mise a jour ===")
# Laisse le temps au processus precedent de bien se terminer et de liberer
# le port / les fichiers.
time.sleep(4)

try:
    copy_tree(STAGED, TARGET)
    log("Fichiers copies avec succes depuis " + STAGED)
except Exception as e:
    log("ERREUR copie fichiers: " + repr(e))

try:
    req = os.path.join(TARGET, "requirements.txt")
    if os.path.exists(req):
        r = subprocess.run([sys.executable, "-m", "pip", "install", "-r", req],
                            capture_output=True, text=True, timeout=180)
        log("pip install rc=" + str(r.returncode))
        if r.returncode != 0:
            log("pip stderr: " + r.stdout[-1000:] + r.stderr[-1000:])
except Exception as e:
    log("ERREUR pip install: " + repr(e))

# Tente de redemarrer : d'abord comme service Windows (mode production),
# sinon en relancant start.bat dans une nouvelle fenetre (mode manuel).
restarted = False
service_py = os.path.join(TARGET, "service.py")
try:
    check = subprocess.run(["sc", "query", "ComptesARecevoirOE"],
                            capture_output=True, text=True, timeout=15)
    if check.returncode == 0 and "ComptesARecevoirOE" in check.stdout:
        subprocess.run([sys.executable, service_py, "restart"], timeout=30)
        log("Service Windows redemarre.")
        restarted = True
except Exception as e:
    log("ERREUR redemarrage service: " + repr(e))

if not restarted:
    try:
        start_bat = os.path.join(TARGET, "start.bat")
        if os.path.exists(start_bat):
            subprocess.Popen(["cmd", "/c", "start", "", "start.bat"],
                              cwd=TARGET, creationflags=subprocess.CREATE_NEW_CONSOLE)
            log("start.bat relance dans une nouvelle fenetre.")
    except Exception as e:
        log("ERREUR relance start.bat: " + repr(e))

log("=== Mise a jour terminee ===")
'''


STATEMENT_PREFIX = "OE-"

INFO_ROWS = {
    'adresse': 3,
    'ville': 4,
    'province': 5,
    'code_postal': 6,
    'courriel': 7,
}
FIRST_INVOICE_ROW = 8
FORMULA_MIN_LAST_ROW = 1000
MODELE_SHEET = "Modèle"
SOMMAIRE_SHEET = "Sommaire"
LOG_SHEET = "LOG_ENVOIS"

INVALID_SHEET_CHARS = r'[:\\/?*\[\]]'

app = Flask(__name__)


@app.before_request
def _require_login():
    resp = license_required_check()
    if resp is not None:
        return resp
    resp = login_required_check()
    if resp is not None:
        return resp


# ============================================================
# Base SQLite (source rapide de vérité)
# ============================================================
_db_lock = threading.Lock()


def get_conn():
    conn = sqlite3.connect(str(DB_PATH), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db_schema():
    conn = get_conn()
    conn.execute("PRAGMA journal_mode=WAL")  # meilleure gestion des accès concurrents (plusieurs postes)
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS clients (
        name TEXT PRIMARY KEY,
        sheet_name TEXT UNIQUE,
        phone TEXT, adresse TEXT, ville TEXT, province TEXT,
        code_postal TEXT, courriel TEXT
    );
    CREATE TABLE IF NOT EXISTS invoices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        client_name TEXT NOT NULL REFERENCES clients(name),
        numero TEXT, date_facture TEXT, echeance TEXT,
        montant REAL, notes TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_invoices_client ON invoices(client_name);
    CREATE TABLE IF NOT EXISTS log_envois (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT, client TEXT, courriel TEXT, total REAL, statut TEXT, note TEXT,
        synced INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS meta (
        key TEXT PRIMARY KEY, value TEXT
    );
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        is_admin INTEGER NOT NULL DEFAULT 0,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT,
        permissions TEXT NOT NULL DEFAULT '[]'
    );
    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT, username TEXT, action TEXT, details TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(id DESC);
    """)
    conn.commit()
    # migration : ajoute la colonne montant_paye si elle n'existe pas encore
    # (sur une base créée avant l'ajout du suivi des paiements partiels)
    cols = [r['name'] for r in conn.execute("PRAGMA table_info(invoices)").fetchall()]
    if 'montant_paye' not in cols:
        conn.execute("ALTER TABLE invoices ADD COLUMN montant_paye REAL NOT NULL DEFAULT 0")
        conn.commit()
    # migration : ajoute la colonne permissions si elle n'existe pas encore (sur
    # une base créée avant l'ajout des accès granulaires). Les comptes non-admin
    # déjà existants gardent l'accès aux rapports (comportement identique à
    # avant cette fonctionnalité) — les autres permissions doivent être
    # accordées explicitement depuis "Utilisateurs".
    user_cols = [r['name'] for r in conn.execute("PRAGMA table_info(users)").fetchall()]
    if 'permissions' not in user_cols:
        conn.execute("ALTER TABLE users ADD COLUMN permissions TEXT NOT NULL DEFAULT '[]'")
        conn.execute("UPDATE users SET permissions='[\"reports\"]' WHERE is_admin=0")
        conn.commit()
    conn.close()


def meta_get(key, default=None):
    conn = get_conn()
    row = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
    conn.close()
    return row['value'] if row else default


def meta_set(key, value):
    conn = get_conn()
    conn.execute("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                 (key, str(value)))
    conn.commit()
    conn.close()


def mark_dirty():
    meta_set('dirty', '1')


# ============================================================
# Utilisateurs / connexion
# ============================================================
# Accès granulaires pouvant être accordés à un utilisateur non-administrateur.
# La gestion des utilisateurs elle-même (page "Utilisateurs") reste toujours
# réservée aux administrateurs, pour qu'un compte non-admin ne puisse jamais
# se donner (ou donner à quelqu'un d'autre) davantage de droits.
PERMISSION_KEYS = {
    'reports': "Rapports (état de compte, envoi, vieillissement)",
    'audit': "Journal d'audit",
    'license': "Licence",
    'email_settings': "Paramètres d'envoi (Outlook/SMTP)",
    'updates': "Mises à jour",
}


def _parse_permissions(raw):
    try:
        val = json.loads(raw) if raw else []
        return [p for p in val if p in PERMISSION_KEYS] if isinstance(val, list) else []
    except Exception:
        return []


def _dump_permissions(perms):
    clean = sorted(set(p for p in (perms or []) if p in PERMISSION_KEYS))
    return json.dumps(clean)


def db_list_users():
    conn = get_conn()
    rows = conn.execute(
        "SELECT id, username, is_admin, active, created_at, permissions FROM users ORDER BY username COLLATE NOCASE"
    ).fetchall()
    conn.close()
    out = []
    for r in rows:
        d = dict(r)
        d['permissions'] = _parse_permissions(d.get('permissions'))
        out.append(d)
    return out


def db_get_user_by_username(username):
    conn = get_conn()
    row = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    d['permissions'] = _parse_permissions(d.get('permissions'))
    return d


def db_get_user(user_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    d['permissions'] = _parse_permissions(d.get('permissions'))
    return d


def db_create_user(username, password, is_admin=False, permissions=None):
    username = (username or '').strip()
    if not username:
        raise ValueError("Nom d'utilisateur requis.")
    if not password or len(password) < 4:
        raise ValueError("Mot de passe trop court (minimum 4 caractères).")
    conn = get_conn()
    try:
        conn.execute(
            "INSERT INTO users(username, password_hash, is_admin, active, created_at, permissions) "
            "VALUES (?,?,?,1,?,?)",
            (username, generate_password_hash(password), 1 if is_admin else 0,
             datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
             _dump_permissions(permissions)),
        )
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        raise ValueError("Ce nom d'utilisateur existe déjà.")
    conn.close()


def db_update_user(user_id, is_admin=None, active=None, new_password=None, permissions=None):
    conn = get_conn()
    if is_admin is not None:
        conn.execute("UPDATE users SET is_admin=? WHERE id=?", (1 if is_admin else 0, user_id))
    if active is not None:
        conn.execute("UPDATE users SET active=? WHERE id=?", (1 if active else 0, user_id))
    if new_password:
        if len(new_password) < 4:
            conn.close()
            raise ValueError("Mot de passe trop court (minimum 4 caractères).")
        conn.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new_password), user_id))
    if permissions is not None:
        conn.execute("UPDATE users SET permissions=? WHERE id=?", (_dump_permissions(permissions), user_id))
    conn.commit()
    conn.close()


def db_delete_user(user_id):
    conn = get_conn()
    conn.execute("DELETE FROM users WHERE id=?", (user_id,))
    conn.commit()
    conn.close()


def db_verify_login(username, password):
    user = db_get_user_by_username((username or '').strip())
    if not user or not user['active']:
        return None
    if not check_password_hash(user['password_hash'], password or ''):
        return None
    return user


def ensure_admin_bootstrap():
    """Crée un compte admin par défaut au tout premier démarrage si aucun utilisateur n'existe."""
    if db_list_users():
        return
    temp_password = secrets.token_urlsafe(9)
    db_create_user('admin', temp_password, is_admin=True)
    print()
    print("=" * 60)
    print("PREMIER DÉMARRAGE — COMPTE ADMINISTRATEUR CRÉÉ")
    print(f"  Nom d'utilisateur : admin")
    print(f"  Mot de passe      : {temp_password}")
    print("Note ce mot de passe maintenant — il ne sera plus réaffiché.")
    print("Connecte-toi puis crée les autres comptes depuis 'Utilisateurs'.")
    print("=" * 60)
    print()


def get_or_create_secret_key():
    key = meta_get('secret_key')
    if not key:
        key = secrets.token_hex(32)
        meta_set('secret_key', key)
    return key


def current_user():
    uid = session.get('user_id')
    if not uid:
        return None
    return db_get_user(uid)


def login_required_check():
    """Retourne une réponse (redirect/JSON 401) si non connecté, sinon None."""
    if request.endpoint in ('login', 'static') or request.endpoint in LICENSE_EXEMPT_ENDPOINTS \
            or request.path.startswith('/static/'):
        return None
    if not session.get('user_id'):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'auth_required'}), 401
        return redirect(url_for('login', next=request.path))
    return None


def admin_required_check():
    if not session.get('is_admin'):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'forbidden', 'message': 'Réservé aux administrateurs.'}), 403
        return "Accès refusé — réservé aux administrateurs.", 403
    return None


def permission_required_check(perm_key):
    """Comme admin_required_check, mais laisse passer un utilisateur non-admin
    qui a reçu la permission granulaire `perm_key` (voir PERMISSION_KEYS).
    Un administrateur a toujours accès à tout."""
    if session.get('is_admin'):
        return None
    if perm_key in (session.get('permissions') or []):
        return None
    if request.path.startswith('/api/'):
        return jsonify({'error': 'forbidden', 'message': "Ton compte n'a pas accès à cette section."}), 403
    return "Accès refusé — ton compte n'a pas accès à cette section.", 403


# ============================================================
# Licence logicielle (30 jours / 1 an / à vie)
# ============================================================
# Seul "license_code" (le code brut collé par le client) est gardé en mémoire.
# Tout le reste (licencié, type, date d'expiration) est re-dérivé à chaque
# vérification à partir de ce code — jamais lu directement d'un champ séparé
# qui pourrait être modifié sans repasser par la signature.
LICENSE_EXEMPT_ENDPOINTS = ('activation_page', 'api_license_activate', 'api_license_status', 'static')


def get_license_status():
    """Revérifie la signature du code de licence stocké à chaque appel.
    Retourne un dict :
      {'active': True, 'payload': {...}, 'days_left': int|None}
      {'active': False, 'reason': 'none'|'invalid'|'expired', 'error': str|None, 'payload': {...}|None}
    """
    code = meta_get('license_code', '')
    if not code:
        return {'active': False, 'reason': 'none', 'error': None, 'payload': None}
    result = licensing.verify_license_code(code)
    if not result['ok']:
        return {'active': False, 'reason': 'invalid', 'error': result['error'], 'payload': None}
    payload = result['payload']
    expires = payload.get('expires')
    if expires:
        try:
            exp_date = datetime.date.fromisoformat(expires)
        except Exception:
            return {'active': False, 'reason': 'invalid', 'error': "Date d'expiration illisible.", 'payload': None}
        days_left = (exp_date - datetime.date.today()).days
        if days_left < 0:
            return {'active': False, 'reason': 'expired', 'error': None, 'payload': payload}
        return {'active': True, 'payload': payload, 'days_left': days_left}
    return {'active': True, 'payload': payload, 'days_left': None}


def license_required_check():
    """Retourne une réponse (redirect/JSON 402) si aucune licence active,
    sinon None. Bloque TOUT (même la page de connexion) tant qu'aucune
    licence valide et non expirée n'est active — seule la page d'activation
    elle-même et son API restent accessibles."""
    if request.endpoint in LICENSE_EXEMPT_ENDPOINTS or request.path.startswith('/static/'):
        return None
    status = get_license_status()
    if not status['active']:
        if request.path.startswith('/api/'):
            return jsonify({'error': 'license_required', 'reason': status['reason']}), 402
        return redirect(url_for('activation_page'))
    return None


# ============================================================
# Journal d'audit (visible uniquement par les administrateurs)
# ============================================================
AUDIT_MAX_ROWS = 5000


def db_add_audit(username, action, details=''):
    """Enregistre une action dans le journal d'audit. N'interrompt jamais l'action
    elle-même si l'écriture échoue (l'audit est secondaire, jamais bloquant)."""
    try:
        conn = get_conn()
        cur = conn.execute(
            "INSERT INTO audit_log(ts, username, action, details) VALUES (?,?,?,?)",
            (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), username or '?', action, details or '')
        )
        new_id = cur.lastrowid
        conn.commit()
        # purge périodique pour éviter une croissance illimitée (garde les AUDIT_MAX_ROWS plus récents)
        if new_id % 100 == 0:
            conn.execute(
                "DELETE FROM audit_log WHERE id NOT IN (SELECT id FROM audit_log ORDER BY id DESC LIMIT ?)",
                (AUDIT_MAX_ROWS,)
            )
            conn.commit()
        conn.close()
    except Exception:
        traceback.print_exc()


def log_audit(action, details=''):
    """À appeler depuis une route Flask (a accès à la session courante)."""
    db_add_audit(session.get('username'), action, details)


def db_list_audit(limit=1000):
    conn = get_conn()
    rows = conn.execute(
        "SELECT ts, username, action, details FROM audit_log ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ============================================================
# Paramètres d'envoi (Outlook ou serveur SMTP) — configurables par un admin
# ============================================================
SETTINGS_DEFAULTS = {
    'send_mode': 'outlook',        # 'outlook' ou 'smtp'
    'smtp_host': '',
    'smtp_port': '587',
    'smtp_username': '',
    'smtp_password': '',
    'smtp_encryption': 'starttls',  # 'starttls' | 'ssl' | 'none'
    'smtp_from_email': '',
    'smtp_from_name': '',
}


def get_settings():
    return {k: meta_get(k, default) for k, default in SETTINGS_DEFAULTS.items()}


def get_public_settings():
    """Ce qu'un utilisateur non-admin a besoin de savoir (jamais les identifiants SMTP)."""
    return {'send_mode': meta_get('send_mode', SETTINGS_DEFAULTS['send_mode'])}


def set_settings(data):
    for key in SETTINGS_DEFAULTS:
        if key in data and data[key] is not None:
            value = data[key]
            if key == 'smtp_password' and value == '':
                continue  # champ laissé vide = on garde l'ancien mot de passe
            meta_set(key, value)


def send_via_smtp(to_email, subject, body, pdf_path, settings):
    import smtplib
    from email.message import EmailMessage

    host = (settings.get('smtp_host') or '').strip()
    from_email = (settings.get('smtp_from_email') or '').strip()
    if not host or not from_email:
        raise RuntimeError(
            "Le serveur SMTP n'est pas configuré. Un administrateur doit le configurer "
            "dans 'Paramètres d'envoi'."
        )
    port = int(settings.get('smtp_port') or 587)
    username = (settings.get('smtp_username') or '').strip()
    password = settings.get('smtp_password') or ''
    encryption = settings.get('smtp_encryption') or 'starttls'
    from_name = (settings.get('smtp_from_name') or '').strip() or COMPANY_NAME

    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = f"{from_name} <{from_email}>"
    msg['To'] = to_email
    msg['Bcc'] = COMPANY_EMAIL
    msg.set_content(body)
    with open(pdf_path, 'rb') as f:
        pdf_data = f.read()
    msg.add_attachment(pdf_data, maintype='application', subtype='pdf', filename=Path(pdf_path).name)

    if encryption == 'ssl':
        with smtplib.SMTP_SSL(host, port, timeout=30) as smtp:
            if username:
                smtp.login(username, password)
            smtp.send_message(msg)
    else:
        with smtplib.SMTP(host, port, timeout=30) as smtp:
            if encryption == 'starttls':
                smtp.starttls()
            if username:
                smtp.login(username, password)
            smtp.send_message(msg)
    return 'ENVOYÉ'


def test_smtp_connection(settings):
    """Vérifie la connexion/authentification SMTP sans envoyer de courriel."""
    import smtplib

    host = (settings.get('smtp_host') or '').strip()
    if not host:
        raise RuntimeError("Adresse du serveur SMTP manquante.")
    port = int(settings.get('smtp_port') or 587)
    username = (settings.get('smtp_username') or '').strip()
    password = settings.get('smtp_password') or ''
    encryption = settings.get('smtp_encryption') or 'starttls'

    if encryption == 'ssl':
        with smtplib.SMTP_SSL(host, port, timeout=15) as smtp:
            if username:
                smtp.login(username, password)
    else:
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            if encryption == 'starttls':
                smtp.starttls()
            if username:
                smtp.login(username, password)


def send_email(to_email, subject, body, pdf_path, mode='draft'):
    """Point d'entrée unique pour l'envoi : bascule vers Outlook ou SMTP selon les
    paramètres configurés par un administrateur. Le SMTP n'a pas de concept de
    brouillon/relecture — un appel avec mode='draft*' en mode SMTP est refusé plus haut,
    avant d'arriver ici (voir les routes)."""
    settings = get_settings()
    if settings['send_mode'] == 'smtp':
        return send_via_smtp(to_email, subject, body, pdf_path, settings)
    return send_via_outlook(to_email, subject, body, pdf_path, mode=mode)


# ============================================================
# Import unique depuis Excel -> SQLite (au tout premier démarrage)
# ============================================================
def safe_sheet_name(name: str) -> str:
    cleaned = re.sub(INVALID_SHEET_CHARS, '', name).strip()
    return cleaned[:31] if len(cleaned) > 31 else cleaned


def read_client_info_ws(ws):
    def cell(r, c):
        return ws.cell(row=r, column=c).value
    return {
        'phone': cell(2, 2) or '',
        'adresse': cell(INFO_ROWS['adresse'], 2) or '',
        'ville': cell(INFO_ROWS['ville'], 2) or '',
        'province': cell(INFO_ROWS['province'], 2) or '',
        'code_postal': cell(INFO_ROWS['code_postal'], 2) or '',
        'courriel': cell(INFO_ROWS['courriel'], 2) or '',
    }


def read_invoices_ws(ws):
    invoices = []
    r = 2
    max_row = ws.max_row
    while r <= max_row:
        num = ws.cell(row=r, column=3).value
        date_f = ws.cell(row=r, column=4).value
        echeance = ws.cell(row=r, column=5).value
        montant = ws.cell(row=r, column=6).value
        notes = ws.cell(row=r, column=11).value
        if num is not None and montant is not None:
            due = echeance.date() if isinstance(echeance, datetime.datetime) else echeance
            df = date_f.date() if isinstance(date_f, datetime.datetime) else date_f
            invoices.append({
                'numero': str(num),
                'date_facture': df.strftime('%Y-%m-%d') if isinstance(df, datetime.date) else (str(df) if df else ''),
                'echeance': due.strftime('%Y-%m-%d') if isinstance(due, datetime.date) else (str(due) if due else ''),
                'montant': float(montant),
                'notes': notes or '',
            })
        r += 1
    return invoices


def import_excel_into_db():
    """Importe une seule fois toutes les données de l'Excel existant dans la base SQLite."""
    print("Premier démarrage : import des données depuis Excel (peut prendre ~30s)...")
    wb = openpyxl.load_workbook(EXCEL_PATH, data_only=False)
    sommaire = wb[SOMMAIRE_SHEET]

    conn = get_conn()
    r = 3
    n_clients = 0
    n_invoices = 0
    used_sheet_names = set()
    while sommaire.cell(row=r, column=1).value is not None:
        name = sommaire.cell(row=r, column=1).value
        # Le nom d'onglet réel peut différer d'une simple troncature du nom du
        # client (deux clients peuvent tronquer sur le même nom) — on lit donc
        # le vrai nom d'onglet directement dans la formule existante du Sommaire.
        formula = sommaire.cell(row=r, column=2).value  # ex: ="'SheetName'!G2"
        sheet_name = None
        if isinstance(formula, str):
            m = re.match(r"^='([^']+)'!", formula)
            if m:
                sheet_name = m.group(1)
        if not sheet_name:
            sheet_name = safe_sheet_name(name)
        ws = wb[sheet_name] if sheet_name in wb.sheetnames else None
        if ws is not None and sheet_name in used_sheet_names:
            # collision improbable — on ne devrait jamais arriver ici puisqu'on lit
            # le vrai nom d'onglet, mais on se protège quand même
            ws = None
        if ws is not None:
            used_sheet_names.add(sheet_name)
            info = read_client_info_ws(ws)
            conn.execute(
                "INSERT OR REPLACE INTO clients(name, sheet_name, phone, adresse, ville, province, code_postal, courriel) "
                "VALUES (?,?,?,?,?,?,?,?)",
                (name, sheet_name, info['phone'], info['adresse'], info['ville'], info['province'],
                 info['code_postal'], info['courriel'])
            )
            n_clients += 1
            for inv in read_invoices_ws(ws):
                if inv['montant'] == 0 and not inv['numero']:
                    continue
                conn.execute(
                    "INSERT INTO invoices(client_name, numero, date_facture, echeance, montant, notes) VALUES (?,?,?,?,?,?)",
                    (name, inv['numero'], inv['date_facture'], inv['echeance'], inv['montant'], inv['notes'])
                )
                n_invoices += 1
        r += 1

    counter_cell = sommaire.cell(row=2, column=13).value  # M2 : dernier numéro d'état de compte
    try:
        counter_val = int(counter_cell or 0)
    except (TypeError, ValueError):
        counter_val = 0
    conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('statement_counter', ?)", (str(counter_val),))
    conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('dirty', '0')")
    conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('last_sync', ?)",
                 (datetime.datetime.now().isoformat(),))
    conn.commit()
    conn.close()
    print(f"Import terminé : {n_clients} clients, {n_invoices} factures.")


def create_blank_excel_template(path):
    """Crée un classeur Excel neuf (aucun client) avec la structure minimale
    attendue par l'app : onglets Modèle / Sommaire / LOG_ENVOIS. Utilisé au
    tout premier démarrage sur un ordinateur qui n'a jamais eu de fichier
    Excel (nouvelle installation) — toutes les formules et le contenu réel
    de chaque onglet client sont de toute façon régénérés à partir de la
    base SQLite à chaque synchronisation (write_client_sheet/export_to_excel),
    donc ce modèle n'a besoin que d'exister, pas d'être élaboré."""
    wb = openpyxl.Workbook()
    modele = wb.active
    modele.title = MODELE_SHEET
    modele.cell(row=1, column=1, value='Client')
    modele.cell(row=1, column=2, value='Numéro de téléphone')
    modele.cell(row=1, column=3, value='Numéro de facture')
    modele.cell(row=1, column=4, value='Date de facture ')
    modele.cell(row=1, column=5, value='Échéance ')
    modele.cell(row=1, column=6, value='Montant')
    modele.cell(row=1, column=7, value='0-30 jours')
    modele.cell(row=1, column=8, value='31-60 jours')
    modele.cell(row=1, column=9, value='61-90 jours')
    modele.cell(row=1, column=10, value='90+ jours')
    modele.cell(row=1, column=11, value='Notes / Suivi')
    modele.cell(row=1, column=12, value='Payé')
    modele.cell(row=1, column=13, value='Solde')

    sommaire = wb.create_sheet(SOMMAIRE_SHEET)
    sommaire.cell(row=1, column=1, value='Client')
    sommaire.cell(row=1, column=2, value='0-30 jours')
    sommaire.cell(row=1, column=3, value='31-60 jours')
    sommaire.cell(row=1, column=4, value='61-90 jours')
    sommaire.cell(row=1, column=5, value='90+ jours')
    sommaire.cell(row=1, column=6, value='Total')
    sommaire.cell(row=1, column=7, value='Vérfication')
    sommaire.cell(row=2, column=1, value='Sommaire')
    # Ligne 2 (sommes) et lignes clients (3+) sont vides ici : elles sont
    # entièrement régénérées par export_to_excel() dès la première synchronisation.

    log_ws = wb.create_sheet(LOG_SHEET)
    log_ws.cell(row=1, column=1, value='Date')
    log_ws.cell(row=1, column=2, value='Client')
    log_ws.cell(row=1, column=3, value='Courriel')
    log_ws.cell(row=1, column=4, value='Total')
    log_ws.cell(row=1, column=5, value='Statut')
    log_ws.cell(row=1, column=6, value='Note')

    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
    print(f"Nouveau classeur Excel créé (installation neuve) : {path}")


def ensure_db_ready():
    is_new = not DB_PATH.exists()
    init_db_schema()
    if is_new:
        import_excel_into_db()


# ============================================================
# Aging (tranches d'âge) — logique identique aux formules du classeur
# ============================================================
def compute_bucket(today, echeance_str, montant):
    if not echeance_str:
        return {'g': 0.0, 'h': 0.0, 'i': 0.0, 'j': 0.0}
    try:
        echeance = datetime.datetime.strptime(echeance_str, '%Y-%m-%d').date()
    except ValueError:
        return {'g': 0.0, 'h': 0.0, 'i': 0.0, 'j': 0.0}
    diff = (today - echeance).days
    g = montant if today <= echeance else 0.0
    h = montant if 0 < diff <= 30 else 0.0
    i = montant if 30 < diff <= 60 else 0.0
    j = montant if diff > 60 else 0.0
    return {'g': g, 'h': h, 'i': i, 'j': j}


def invoices_with_buckets(rows, ref_date=None):
    """Ajoute à chaque facture son solde restant (montant - montant payé, s'il y a eu un
    paiement partiel ou total) et sa tranche d'âge calculée sur ce solde restant — pas
    sur le montant facturé au complet."""
    today = ref_date or datetime.date.today()
    out = []
    for r in rows:
        d = dict(r)
        montant_paye = d.get('montant_paye') or 0.0
        solde = d['montant'] - montant_paye
        d['montant_paye'] = montant_paye
        d['solde'] = solde
        d['bucket'] = compute_bucket(today, d['echeance'], solde)
        out.append(d)
    return out


def sum_totals(invoices):
    """totals['montant'] représente le solde total dû (après paiements partiels) — le nom
    est conservé pour ne pas casser le reste du code qui l'utilise comme 'montant dû'."""
    totals = {'montant': 0.0, 'g': 0.0, 'h': 0.0, 'i': 0.0, 'j': 0.0}
    for inv in invoices:
        totals['montant'] += inv.get('solde', inv['montant'])
        for k in ('g', 'h', 'i', 'j'):
            totals[k] += inv['bucket'][k]
    return totals


# ============================================================
# Accès aux données (rapide, SQLite)
# ============================================================
def db_list_clients():
    conn = get_conn()
    clients = conn.execute("SELECT name, courriel FROM clients ORDER BY name COLLATE NOCASE").fetchall()
    result = []
    for c in clients:
        rows = conn.execute("SELECT * FROM invoices WHERE client_name=?", (c['name'],)).fetchall()
        totals = sum_totals(invoices_with_buckets(rows))
        result.append({'name': c['name'], 'courriel': c['courriel'] or '', 'solde': round(totals['montant'], 2)})
    conn.close()
    return result


def db_client_detail(name):
    conn = get_conn()
    c = conn.execute("SELECT * FROM clients WHERE name=?", (name,)).fetchone()
    if c is None:
        conn.close()
        return None
    rows = conn.execute("SELECT * FROM invoices WHERE client_name=? ORDER BY id", (name,)).fetchall()
    conn.close()
    invoices = invoices_with_buckets(rows)
    totals = sum_totals(invoices)
    info = {'phone': c['phone'] or '', 'adresse': c['adresse'] or '', 'ville': c['ville'] or '',
            'province': c['province'] or '', 'code_postal': c['code_postal'] or '', 'courriel': c['courriel'] or ''}
    return {'name': c['name'], 'info': info, 'invoices': invoices, 'totals': totals}


def db_create_client(name, phone, adresse, ville, province, code_postal, courriel):
    conn = get_conn()
    existing = conn.execute("SELECT 1 FROM clients WHERE name=?", (name,)).fetchone()
    if existing:
        conn.close()
        raise RuntimeError("Ce client existe déjà.")
    base_sheet_name = safe_sheet_name(name)
    sheet_name = base_sheet_name
    suffix = 2
    while conn.execute("SELECT name FROM clients WHERE sheet_name=?", (sheet_name,)).fetchone():
        # collision (deux noms différents tronquent pareil) : on distingue avec un suffixe
        tail = f"_{suffix}"
        sheet_name = base_sheet_name[:31 - len(tail)] + tail
        suffix += 1
    conn.execute(
        "INSERT INTO clients(name, sheet_name, phone, adresse, ville, province, code_postal, courriel) VALUES (?,?,?,?,?,?,?,?)",
        (name, sheet_name, phone or '', adresse or '', ville or '', province or 'Qc', code_postal or '', courriel or '')
    )
    conn.commit()
    conn.close()
    mark_dirty()
    return sheet_name


def db_add_invoice(client_name, numero, date_facture, echeance, montant, notes, montant_paye=0.0):
    conn = get_conn()
    c = conn.execute("SELECT 1 FROM clients WHERE name=?", (client_name,)).fetchone()
    if not c:
        conn.close()
        raise RuntimeError(f"Client introuvable : {client_name}")
    conn.execute(
        "INSERT INTO invoices(client_name, numero, date_facture, echeance, montant, notes, montant_paye) "
        "VALUES (?,?,?,?,?,?,?)",
        (client_name, str(numero), date_facture, echeance, float(montant), notes or '', float(montant_paye or 0))
    )
    conn.commit()
    conn.close()
    mark_dirty()


def db_update_invoice(invoice_id, numero, date_facture, echeance, montant, notes, montant_paye=0.0):
    conn = get_conn()
    existing = conn.execute("SELECT 1 FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    if not existing:
        conn.close()
        raise RuntimeError("Facture introuvable.")
    conn.execute(
        "UPDATE invoices SET numero=?, date_facture=?, echeance=?, montant=?, notes=?, montant_paye=? WHERE id=?",
        (str(numero), date_facture, echeance, float(montant), notes or '', float(montant_paye or 0), invoice_id)
    )
    conn.commit()
    conn.close()
    mark_dirty()


def db_get_invoice(invoice_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def db_delete_invoice(invoice_id):
    conn = get_conn()
    existing = conn.execute("SELECT 1 FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    if not existing:
        conn.close()
        raise RuntimeError("Facture introuvable.")
    conn.execute("DELETE FROM invoices WHERE id=?", (invoice_id,))
    conn.commit()
    conn.close()
    mark_dirty()


def db_set_invoice_paid(invoice_id, paid):
    """Marque une facture comme entièrement payée (montant_paye = montant) ou annule
    ce marquage (remet montant_paye à 0). Un paiement partiel déjà saisi manuellement
    est écrasé par cette action, dans les deux sens."""
    conn = get_conn()
    row = conn.execute("SELECT montant FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    if not row:
        conn.close()
        raise RuntimeError("Facture introuvable.")
    new_montant_paye = row['montant'] if paid else 0.0
    conn.execute("UPDATE invoices SET montant_paye=? WHERE id=?", (new_montant_paye, invoice_id))
    conn.commit()
    conn.close()
    mark_dirty()


def db_next_statement_number():
    conn = get_conn()
    with _db_lock:
        row = conn.execute("SELECT value FROM meta WHERE key='statement_counter'").fetchone()
        current = int(row['value']) if row else 0
        new_val = current + 1
        conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('statement_counter', ?)", (str(new_val),))
        conn.commit()
    conn.close()
    mark_dirty()
    return f"{STATEMENT_PREFIX}{new_val:06d}"


def db_log_envoi(client, courriel, total, statut, note):
    conn = get_conn()
    conn.execute(
        "INSERT INTO log_envois(ts, client, courriel, total, statut, note, synced) VALUES (?,?,?,?,?,?,0)",
        (datetime.datetime.now().isoformat(), client, courriel, total, statut, note)
    )
    conn.commit()
    conn.close()
    mark_dirty()


# ============================================================
# Synchronisation SQLite -> Excel (opération lente, en arrière-plan ou à la demande)
# ============================================================
BACKUP_DIR = BASE_DIR / "Backups_auto"
BACKUP_DIR.mkdir(exist_ok=True)
MAX_BACKUPS = 20
_sync_lock = threading.Lock()
_sync_state = {"running": False, "last_error": None}


def _prune_backups():
    backups = sorted(BACKUP_DIR.glob("Compte à recevoir_*.xlsx"), key=lambda p: p.stat().st_mtime)
    for old in backups[:-MAX_BACKUPS]:
        try:
            old.unlink()
        except OSError:
            pass


def save_wb_atomic(wb):
    """Écriture atomique : fichier temporaire vérifié, puis remplacement. Une
    interruption pendant l'écriture ne peut jamais corrompre le fichier original."""
    if EXCEL_PATH.exists():
        try:
            stamp = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
            shutil.copy2(EXCEL_PATH, BACKUP_DIR / f"Compte à recevoir_{stamp}.xlsx")
            _prune_backups()
        except OSError:
            pass

    tmp_path = EXCEL_PATH.with_name(EXCEL_PATH.stem + ".tmp_write.xlsx")
    try:
        wb.save(tmp_path)
    except PermissionError:
        raise RuntimeError(
            "Impossible d'enregistrer : le fichier Excel est probablement ouvert. "
            "Ferme 'Compte à recevoir.xlsx' dans Excel puis réessaie."
        )
    try:
        check = openpyxl.load_workbook(tmp_path, read_only=True)
        check.close()
    except Exception as e:
        tmp_path.unlink(missing_ok=True)
        raise RuntimeError(f"Écriture invalide, annulée sans toucher l'original. Détail : {e}")
    os.replace(tmp_path, EXCEL_PATH)


def set_row_formulas(ws, row):
    # les tranches d'âge (G-J) se basent sur M (le solde restant après paiement),
    # pas sur F (le montant facturé au complet)
    ws.cell(row=row, column=7, value=f"=IF(TODAY()<=E{row},M{row},0)")
    ws.cell(row=row, column=8, value=f"=IF(AND(TODAY()>E{row},TODAY()-E{row}<=30),M{row},0)")
    ws.cell(row=row, column=9, value=f"=IF(AND(TODAY()-E{row}>30,TODAY()-E{row}<=60),M{row},0)")
    ws.cell(row=row, column=10, value=f"=IF(TODAY()-E{row}>60,M{row},0)")
    ws.cell(row=row, column=13, value=f"=F{row}-L{row}")  # solde = montant - payé
    for c in (7, 8, 9, 10, 12, 13):
        ws.cell(row=row, column=c).number_format = '#,##0.00;\\(#,##0.00\\)'


def refresh_header_sums(ws, last_row):
    last_row = max(last_row, FORMULA_MIN_LAST_ROW)
    for col in (6, 7, 8, 9, 10, 12, 13):
        letter = get_column_letter(col)
        ws.cell(row=2, column=col, value=f"=SUM({letter}3:{letter}{last_row})")


def write_client_sheet(ws, client_row, invoices):
    """Réécrit entièrement le bloc de factures d'un onglet client à partir des
    données SQLite (source unique de vérité)."""
    # efface l'ancien bloc de factures (colonnes C..M, à partir de la ligne 2)
    for r in range(2, max(ws.max_row, FORMULA_MIN_LAST_ROW) + 1):
        for c in range(3, 14):
            ws.cell(row=r, column=c).value = None

    ws.cell(row=1, column=12, value='Payé')
    ws.cell(row=1, column=13, value='Solde')

    ws.cell(row=2, column=1, value=client_row['name'])
    ws.cell(row=2, column=2, value=client_row['phone'] or '')
    ws.cell(row=INFO_ROWS['adresse'], column=1, value='Adresse')
    ws.cell(row=INFO_ROWS['adresse'], column=2, value=client_row['adresse'] or '')
    ws.cell(row=INFO_ROWS['ville'], column=1, value='Ville')
    ws.cell(row=INFO_ROWS['ville'], column=2, value=client_row['ville'] or '')
    ws.cell(row=INFO_ROWS['province'], column=1, value='Province')
    ws.cell(row=INFO_ROWS['province'], column=2, value=client_row['province'] or 'Qc')
    ws.cell(row=INFO_ROWS['code_postal'], column=1, value='Code Postal')
    ws.cell(row=INFO_ROWS['code_postal'], column=2, value=client_row['code_postal'] or '')
    ws.cell(row=INFO_ROWS['courriel'], column=1, value='Adresse couriel')
    ws.cell(row=INFO_ROWS['courriel'], column=2, value=client_row['courriel'] or '')

    row = FIRST_INVOICE_ROW
    for inv in invoices:
        ws.cell(row=row, column=3, value=inv['numero'])
        try:
            d = datetime.datetime.strptime(inv['date_facture'], '%Y-%m-%d') if inv['date_facture'] else None
        except ValueError:
            d = None
        try:
            e = datetime.datetime.strptime(inv['echeance'], '%Y-%m-%d') if inv['echeance'] else None
        except ValueError:
            e = None
        if d:
            ws.cell(row=row, column=4, value=d).number_format = 'dd-mm-yyyy'
        if e:
            ws.cell(row=row, column=5, value=e).number_format = 'dd/mm/yyyy'
        ws.cell(row=row, column=6, value=float(inv['montant'])).number_format = '#,##0.00;\\(#,##0.00\\)'
        if inv['notes']:
            ws.cell(row=row, column=11, value=inv['notes'])
        ws.cell(row=row, column=12, value=float(inv.get('montant_paye') or 0))
        set_row_formulas(ws, row)
        row += 1

    last_row = max(row - 1, FORMULA_MIN_LAST_ROW)
    refresh_header_sums(ws, last_row)


def export_to_excel():
    """Régénère le fichier Excel complet à partir de la base SQLite. Opération
    lente (~20-30s) — appelée en arrière-plan ou à la demande, jamais bloquante
    pour la saisie."""
    with _sync_lock:
        _sync_state["running"] = True
        _sync_state["last_error"] = None
        try:
            wb = openpyxl.load_workbook(EXCEL_PATH, data_only=False)
            conn = get_conn()
            clients = conn.execute("SELECT * FROM clients ORDER BY name COLLATE NOCASE").fetchall()

            sommaire = wb[SOMMAIRE_SHEET]
            # efface les anciennes lignes du Sommaire (à partir de la ligne 3)
            for r in range(3, max(sommaire.max_row, len(clients) + 5) + 1):
                for c in range(1, 8):
                    sommaire.cell(row=r, column=c).value = None

            srow = 3
            for c in clients:
                sheet_name = c['sheet_name']
                if sheet_name not in wb.sheetnames:
                    ws = wb.copy_worksheet(wb[MODELE_SHEET])
                    ws.title = sheet_name
                else:
                    ws = wb[sheet_name]
                invoices = conn.execute(
                    "SELECT * FROM invoices WHERE client_name=? ORDER BY id", (c['name'],)
                ).fetchall()
                write_client_sheet(ws, c, [dict(i) for i in invoices])

                sommaire.cell(row=srow, column=1, value=c['name'])
                sommaire.cell(row=srow, column=2, value=f"='{sheet_name}'!G2")
                sommaire.cell(row=srow, column=3, value=f"='{sheet_name}'!H2")
                sommaire.cell(row=srow, column=4, value=f"='{sheet_name}'!I2")
                sommaire.cell(row=srow, column=5, value=f"='{sheet_name}'!J2")
                sommaire.cell(row=srow, column=6, value=f"='{sheet_name}'!M2")  # solde restant, pas le montant facturé
                sommaire.cell(row=srow, column=7, value=f"=SUM(B{srow}:E{srow})")
                srow += 1

            last_sommaire_row = max(srow - 1, 3)
            for col in (2, 3, 4, 5, 6):
                letter = get_column_letter(col)
                sommaire.cell(row=2, column=col, value=f"=SUM({letter}3:{letter}{last_sommaire_row})")
            sommaire.cell(row=2, column=7, value="=SUM(B2:E2)")

            counter_row = conn.execute("SELECT value FROM meta WHERE key='statement_counter'").fetchone()
            if counter_row:
                sommaire.cell(row=2, column=13, value=int(counter_row['value']))

            log_ws = wb[LOG_SHEET]
            pending_logs = conn.execute("SELECT * FROM log_envois WHERE synced=0 ORDER BY id").fetchall()
            r = log_ws.max_row + 1
            for lg in pending_logs:
                log_ws.cell(row=r, column=1, value=lg['ts'])
                log_ws.cell(row=r, column=2, value=lg['client'])
                log_ws.cell(row=r, column=3, value=lg['courriel'])
                log_ws.cell(row=r, column=4, value=lg['total'])
                log_ws.cell(row=r, column=5, value=lg['statut'])
                log_ws.cell(row=r, column=6, value=lg['note'])
                r += 1

            save_wb_atomic(wb)

            conn.execute("UPDATE log_envois SET synced=1 WHERE synced=0")
            conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('dirty', '0')")
            conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('last_sync', ?)",
                         (datetime.datetime.now().isoformat(),))
            conn.commit()
            conn.close()
        except Exception as e:
            _sync_state["last_error"] = str(e)
            traceback.print_exc()
            raise
        finally:
            _sync_state["running"] = False


def _auto_sync_loop():
    import time
    while True:
        time.sleep(AUTO_SYNC_SECONDS)
        try:
            if meta_get('dirty', '0') == '1' and not _sync_state["running"]:
                print("Synchronisation automatique vers Excel...")
                export_to_excel()
                print("Synchronisation automatique terminée.")
        except Exception as e:
            print("Erreur de synchronisation automatique :", e)


# ============================================================
# Génération du PDF (État de compte) — reproduit le modèle existant
# ============================================================
HEADER_RESERVED_HEIGHT = 62  # mm réservés en haut de la page 1 pour titre + logo


def generate_statement_pdf(client_name, info, invoices, totals, statement_number):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Table, TableStyle,
                                     Paragraph, Spacer, NextPageTemplate, PageBreak, ListFlowable,
                                     ListItem)
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

    safe_name = re.sub(r'[\\/:*?"<>|]', '_', client_name)
    pdf_path = PDF_DIR / f"Etat_de_compte_{safe_name}_{statement_number}.pdf"

    page_w, page_h = letter
    left_margin = right_margin = 18 * mm
    bottom_margin = 18 * mm

    styles = getSampleStyleSheet()
    h1 = ParagraphStyle('h1', parent=styles['Heading1'], fontSize=13, spaceAfter=6, spaceBefore=2)
    normal = ParagraphStyle('normal', parent=styles['Normal'], fontSize=10, leading=15)
    label_normal = ParagraphStyle('labelnormal', parent=normal)
    small = ParagraphStyle('small', parent=styles['Normal'], fontSize=9, leading=13)
    footer_style = ParagraphStyle('footer', parent=styles['Normal'], fontSize=10)

    emission_date = datetime.date.today().strftime('%Y-%m-%d')

    def draw_header(canvas, doc_):
        canvas.saveState()
        x = left_margin
        top = page_h - 20 * mm

        canvas.setFont('Helvetica-Bold', 22)
        canvas.drawString(x, top, "ÉTAT DE COMPTE")

        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 10 * mm, "Date d'émission :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 32 * mm, top - 10 * mm, emission_date)
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 15 * mm, "Numéro d'état de compte :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 45 * mm, top - 15 * mm, statement_number)

        if LOGO_PATH.exists():
            from reportlab.lib.utils import ImageReader
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            logo_w = 65 * mm
            logo_h = logo_w * ih / iw
            canvas.drawImage(img, page_w - right_margin - logo_w, top - logo_h + 4 * mm,
                              width=logo_w, height=logo_h, mask='auto')

        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.setLineWidth(0.5)
        rule_y = top - 22 * mm
        canvas.line(left_margin, rule_y, page_w - right_margin, rule_y)
        canvas.restoreState()

    def draw_plain(canvas, doc_):
        pass

    frame_first = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                         page_h - bottom_margin - HEADER_RESERVED_HEIGHT * mm, id='first')
    frame_rest = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                        page_h - bottom_margin - 15 * mm, id='rest')

    doc = BaseDocTemplate(str(pdf_path), pagesize=letter)
    doc.addPageTemplates([
        PageTemplate(id='First', frames=[frame_first], onPage=draw_header),
        PageTemplate(id='Rest', frames=[frame_rest], onPage=draw_plain),
    ])

    def field(label, value):
        return Paragraph(f"<b>{label} :</b> {value}", label_normal)

    story = []
    story.append(Paragraph("Information du client", h1))
    story.append(field("Client", client_name))
    story.append(field("Adresse", info.get('adresse', '') or '—'))
    ville_prov = f"{info.get('ville','')}, {info.get('province','')}".strip(', ')
    story.append(field("Ville / Province", ville_prov or '—'))
    story.append(field("Courriel", info.get('courriel', '') or '—'))
    story.append(field("Téléphone", info.get('phone', '') or '—'))
    story.append(Spacer(1, 6 * mm))

    from reportlab.platypus.flowables import HRFlowable
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))
    story.append(Spacer(1, 4 * mm))

    story.append(Paragraph("Sommaire des soldes", h1))
    tranche_rows = [
        ["Tranche", "Montant"],
        ["0 – 30 jours", f"{totals['g']:,.2f} $"],
        ["31 – 60 jours", f"{totals['h']:,.2f} $"],
        ["61 – 90 jours", f"{totals['i']:,.2f} $"],
        ["90+ jours", f"{totals['j']:,.2f} $"],
        ["TOTAL DÛ", f"{totals['montant']:,.2f} $"],
    ]
    tranche_table = Table(tranche_rows, colWidths=[70 * mm, 60 * mm])
    tranche_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('TOPPADDING', (0, 0), (-1, -1), 7),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
        ('LINEBELOW', (0, 0), (-1, 0), 0.5, colors.HexColor('#cccccc')),
        ('ALIGN', (1, 0), (1, -1), 'LEFT'),
    ]))
    story.append(tranche_table)
    story.append(Spacer(1, 4 * mm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))

    story.append(NextPageTemplate('Rest'))
    story.append(PageBreak())

    # Le montant affiché est le solde restant (montant facturé moins paiement partiel
    # déjà reçu) — une facture entièrement payée n'apparaît plus dans le détail.
    billable = [inv for inv in invoices if inv.get('solde', inv['montant']) != 0]
    has_partial = any(inv.get('montant_paye') for inv in billable)
    if billable:
        story.append(Paragraph("Détail des factures dues", h1))
        story.append(Spacer(1, 3 * mm))
        data = [["Facture", "Date", "Échéance", "Montant"]]
        for inv in billable:
            montant_affiche = inv.get('solde', inv['montant'])
            suffix = " *" if inv.get('montant_paye') else ""
            data.append([str(inv['numero']) + suffix, inv['date_facture'], inv['echeance'],
                         f"{montant_affiche:,.2f} $"])
        det_table = Table(data, colWidths=[38 * mm, 33 * mm, 33 * mm, 38 * mm], repeatRows=0)
        det_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
            ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ]))
        story.append(det_table)
        if has_partial:
            story.append(Spacer(1, 2 * mm))
            story.append(Paragraph("* Solde après un paiement partiel déjà reçu.", small))
        story.append(Spacer(1, 6 * mm))

    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph("Modalités et paiement", h1))
    bullets = [
        "Merci d'indiquer le <b>numéro de facture</b> lors du paiement.",
        "Pour toute question concernant votre état de compte, communiquez avec nous.",
        "Les montants indiqués sont dus immédiatement, sauf entente contraire.",
    ]
    story.append(ListFlowable(
        [ListItem(Paragraph(b, small), spaceAfter=4) for b in bullets],
        bulletType='bullet', start='circle', leftIndent=12,
    ))
    story.append(Spacer(1, 6 * mm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph(f"<b>Merci de votre confiance.</b><br/>&nbsp;{COMPANY_NAME}", footer_style))

    doc.build(story)
    return pdf_path


def db_invoices_by_month(year, month):
    """Toutes les factures dont la date de facture tombe dans le mois donné, groupées par client."""
    ym = f"{year:04d}-{month:02d}"
    conn = get_conn()
    rows = conn.execute(
        "SELECT client_name, numero, date_facture, echeance, montant, notes "
        "FROM invoices WHERE date_facture LIKE ? ORDER BY client_name COLLATE NOCASE, date_facture",
        (f"{ym}-%",)
    ).fetchall()
    conn.close()
    by_client = {}
    for r in rows:
        by_client.setdefault(r['client_name'], []).append(dict(r))
    return by_client


MOIS_FR = ["", "Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet",
           "Août", "Septembre", "Octobre", "Novembre", "Décembre"]


def generate_monthly_report_pdf(year, month, by_client):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Table, TableStyle,
                                     Paragraph, Spacer, NextPageTemplate, PageBreak)
    from reportlab.platypus.flowables import HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader

    mois_nom = MOIS_FR[month]
    report_dir = PDF_DIR / "Rapports_mensuels"
    report_dir.mkdir(exist_ok=True)
    pdf_path = report_dir / f"Rapport_{year:04d}-{month:02d}.pdf"

    page_w, page_h = letter
    left_margin = right_margin = 18 * mm
    bottom_margin = 18 * mm
    header_reserved = 55  # mm

    styles = getSampleStyleSheet()
    h1 = ParagraphStyle('h1', parent=styles['Heading1'], fontSize=12, spaceAfter=4, spaceBefore=8)
    footer_style = ParagraphStyle('footer', parent=styles['Normal'], fontSize=10)

    emission_date = datetime.date.today().strftime('%Y-%m-%d')

    def draw_header(canvas, doc_):
        canvas.saveState()
        x = left_margin
        top = page_h - 20 * mm
        canvas.setFont('Helvetica-Bold', 18)
        canvas.drawString(x, top, "RAPPORT MENSUEL — COMPTES À RECEVOIR")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 9 * mm, "Période :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 20 * mm, top - 9 * mm, f"{mois_nom} {year}")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 14 * mm, "Généré le :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 24 * mm, top - 14 * mm, emission_date)

        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            logo_w = 55 * mm
            logo_h = logo_w * ih / iw
            canvas.drawImage(img, page_w - right_margin - logo_w, top - logo_h + 2 * mm,
                              width=logo_w, height=logo_h, mask='auto')

        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.setLineWidth(0.5)
        rule_y = top - 19 * mm
        canvas.line(left_margin, rule_y, page_w - right_margin, rule_y)
        canvas.restoreState()

    def draw_plain(canvas, doc_):
        pass

    frame_first = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                         page_h - bottom_margin - header_reserved * mm, id='first')
    frame_rest = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                        page_h - bottom_margin - 15 * mm, id='rest')

    doc = BaseDocTemplate(str(pdf_path), pagesize=letter)
    doc.addPageTemplates([
        PageTemplate(id='First', frames=[frame_first], onPage=draw_header),
        PageTemplate(id='Rest', frames=[frame_rest], onPage=draw_plain),
    ])

    story = []
    client_names = sorted(by_client.keys(), key=lambda s: s.lower())
    grand_total = 0.0
    n_invoices = 0

    if not client_names:
        story.append(Paragraph(f"Aucune facture datée de {mois_nom} {year} n'a été trouvée.", styles['Normal']))
    else:
        for client_name in client_names:
            invs = by_client[client_name]
            subtotal = sum(i['montant'] for i in invs)
            grand_total += subtotal
            n_invoices += len(invs)

            story.append(Paragraph(client_name, h1))
            data = [["Facture", "Date", "Échéance", "Montant"]]
            for i in invs:
                data.append([str(i['numero']), i['date_facture'], i['echeance'] or '—',
                             f"{i['montant']:,.2f} $"])
            data.append(["", "", "Sous-total :", f"{subtotal:,.2f} $"])
            t = Table(data, colWidths=[38 * mm, 33 * mm, 33 * mm, 38 * mm], repeatRows=1)
            t.setStyle(TableStyle([
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 9),
                ('GRID', (0, 0), (-1, -2), 0.5, colors.black),
                ('LINEABOVE', (0, -1), (-1, -1), 0.75, colors.black),
                ('TOPPADDING', (0, 0), (-1, -1), 5),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ]))
            story.append(t)
            story.append(Spacer(1, 5 * mm))

        story.append(HRFlowable(width="100%", thickness=0.75, color=colors.HexColor('#333333')))
        story.append(Spacer(1, 3 * mm))
        story.append(Paragraph(
            f"<b>TOTAL — {n_invoices} facture(s), {len(client_names)} client(s) : {grand_total:,.2f} $</b>",
            footer_style))

    doc.build(story)
    return pdf_path


def db_envois_by_month(year, month):
    """Tous les courriels (brouillons et envois) enregistrés dans le mois donné."""
    ym = f"{year:04d}-{month:02d}"
    conn = get_conn()
    rows = conn.execute(
        "SELECT ts, client, courriel, total, statut, note FROM log_envois "
        "WHERE ts LIKE ? ORDER BY ts",
        (f"{ym}-%",)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def generate_envoi_report_pdf(year, month, rows):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Table, TableStyle,
                                     Paragraph, Spacer, NextPageTemplate, PageBreak)
    from reportlab.platypus.flowables import HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader

    mois_nom = MOIS_FR[month]
    report_dir = PDF_DIR / "Rapports_envois"
    report_dir.mkdir(exist_ok=True)
    pdf_path = report_dir / f"Rapport_envois_{year:04d}-{month:02d}.pdf"

    page_w, page_h = letter
    left_margin = right_margin = 18 * mm
    bottom_margin = 18 * mm
    header_reserved = 55  # mm

    styles = getSampleStyleSheet()
    footer_style = ParagraphStyle('footer', parent=styles['Normal'], fontSize=10)

    emission_date = datetime.date.today().strftime('%Y-%m-%d')

    def draw_header(canvas, doc_):
        canvas.saveState()
        x = left_margin
        top = page_h - 20 * mm
        canvas.setFont('Helvetica-Bold', 18)
        canvas.drawString(x, top, "RAPPORT D'ENVOI — COURRIELS")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 9 * mm, "Période :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 20 * mm, top - 9 * mm, f"{mois_nom} {year}")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 14 * mm, "Généré le :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 24 * mm, top - 14 * mm, emission_date)

        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            logo_w = 55 * mm
            logo_h = logo_w * ih / iw
            canvas.drawImage(img, page_w - right_margin - logo_w, top - logo_h + 2 * mm,
                              width=logo_w, height=logo_h, mask='auto')

        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.setLineWidth(0.5)
        rule_y = top - 19 * mm
        canvas.line(left_margin, rule_y, page_w - right_margin, rule_y)
        canvas.restoreState()

    def draw_plain(canvas, doc_):
        pass

    frame_first = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                         page_h - bottom_margin - header_reserved * mm, id='first')
    frame_rest = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                        page_h - bottom_margin - 15 * mm, id='rest')

    doc = BaseDocTemplate(str(pdf_path), pagesize=letter)
    doc.addPageTemplates([
        PageTemplate(id='First', frames=[frame_first], onPage=draw_header),
        PageTemplate(id='Rest', frames=[frame_rest], onPage=draw_plain),
    ])

    story = []
    if not rows:
        story.append(Paragraph(f"Aucun courriel enregistré pour {mois_nom} {year}.", styles['Normal']))
    else:
        data = [["Date / heure", "Client", "Courriel", "Montant", "Statut", "Note"]]
        grand_total = 0.0
        n_envoyes = 0
        for r in rows:
            ts_disp = (r['ts'] or '')[:16].replace('T', ' ')
            data.append([ts_disp, r['client'] or '', r['courriel'] or '—',
                         f"{(r['total'] or 0):,.2f} $", r['statut'] or '', r['note'] or ''])
            grand_total += (r['total'] or 0)
            if (r['statut'] or '').upper() == 'ENVOYÉ':
                n_envoyes += 1
        t = Table(data, colWidths=[28 * mm, 32 * mm, 38 * mm, 20 * mm, 18 * mm, 40 * mm], repeatRows=1)
        t.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ]))
        story.append(t)
        story.append(Spacer(1, 5 * mm))
        story.append(HRFlowable(width="100%", thickness=0.75, color=colors.HexColor('#333333')))
        story.append(Spacer(1, 3 * mm))
        story.append(Paragraph(
            f"<b>TOTAL — {len(rows)} courriel(s) enregistré(s), dont {n_envoyes} envoyé(s) "
            f"directement : {grand_total:,.2f} $</b>",
            footer_style))

    doc.build(story)
    return pdf_path


def month_end_or_today(year, month):
    """Dernier jour du mois choisi, sauf si c'est le mois en cours : dans ce cas on
    utilise la date d'aujourd'hui, pour que le rapport du mois courant corresponde
    exactement à l'état réel actuel."""
    import calendar
    today = datetime.date.today()
    if year == today.year and month == today.month:
        return today
    last_day = calendar.monthrange(year, month)[1]
    return datetime.date(year, month, last_day)


def db_aging_all_clients(ref_date=None):
    """Solde par tranche d'âge (0-30 / 31-60 / 61-90 / 90+), par client, pour tous les
    clients ayant un solde non nul, calculé par rapport à ref_date (aujourd'hui si non
    fourni). Si ref_date est fourni, seules les factures datées au plus tard à ref_date
    sont incluses (pour reproduire l'état tel qu'il était à la fin du mois choisi)."""
    conn = get_conn()
    clients = conn.execute("SELECT name FROM clients ORDER BY name COLLATE NOCASE").fetchall()
    rows = []
    ref_str = ref_date.strftime('%Y-%m-%d') if ref_date else None
    for c in clients:
        invs = conn.execute("SELECT * FROM invoices WHERE client_name=?", (c['name'],)).fetchall()
        if not invs:
            continue
        if ref_str:
            invs = [i for i in invs if (i['date_facture'] or '') <= ref_str]
        if not invs:
            continue
        totals = sum_totals(invoices_with_buckets(invs, ref_date))
        if abs(totals['montant']) < 0.005:
            continue
        rows.append({'name': c['name'], **totals})
    conn.close()
    rows.sort(key=lambda r: r['name'].lower())
    return rows


def generate_aging_report_pdf(rows, ref_date=None, period_label=None):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Table, TableStyle, Paragraph, Spacer
    from reportlab.platypus.flowables import HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader

    ref_date = ref_date or datetime.date.today()
    ref_str = ref_date.strftime('%Y-%m-%d')

    report_dir = PDF_DIR / "Rapports_mensuels"
    report_dir.mkdir(exist_ok=True)
    pdf_path = report_dir / f"Rapport_age_{ref_str}.pdf"

    page_w, page_h = letter
    left_margin = right_margin = 18 * mm
    bottom_margin = 18 * mm
    header_reserved = 50  # mm

    styles = getSampleStyleSheet()
    footer_style = ParagraphStyle('footer', parent=styles['Normal'], fontSize=10)

    emission_date = datetime.date.today().strftime('%Y-%m-%d')
    sous_titre = f"Tous les clients — soldes en date du {ref_str}" + (f" ({period_label})" if period_label else "")

    def draw_header(canvas, doc_):
        canvas.saveState()
        x = left_margin
        top = page_h - 20 * mm
        canvas.setFont('Helvetica-Bold', 16)
        canvas.drawString(x, top, "RAPPORT D'ÂGE DES COMPTES À RECEVOIR")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 9 * mm, "Généré le :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 22 * mm, top - 9 * mm, emission_date)
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x, top - 14 * mm, sous_titre)

        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            logo_w = 50 * mm
            logo_h = logo_w * ih / iw
            canvas.drawImage(img, page_w - right_margin - logo_w, top - logo_h + 2 * mm,
                              width=logo_w, height=logo_h, mask='auto')

        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.setLineWidth(0.5)
        rule_y = top - 18 * mm
        canvas.line(left_margin, rule_y, page_w - right_margin, rule_y)
        canvas.restoreState()

    def draw_plain(canvas, doc_):
        pass

    frame_first = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                         page_h - bottom_margin - header_reserved * mm, id='first')
    frame_rest = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                        page_h - bottom_margin - 15 * mm, id='rest')

    doc = BaseDocTemplate(str(pdf_path), pagesize=letter)
    doc.addPageTemplates([
        PageTemplate(id='First', frames=[frame_first], onPage=draw_header),
        PageTemplate(id='Rest', frames=[frame_rest], onPage=draw_plain),
    ])

    story = []
    if not rows:
        story.append(Paragraph("Aucun client avec un solde dû.", styles['Normal']))
    else:
        data = [["Client", "0 – 30 j", "31 – 60 j", "61 – 90 j", "90+ j", "Total"]]
        grand = {'g': 0.0, 'h': 0.0, 'i': 0.0, 'j': 0.0, 'montant': 0.0}
        for r in rows:
            data.append([
                r['name'],
                f"{r['g']:,.2f} $", f"{r['h']:,.2f} $", f"{r['i']:,.2f} $", f"{r['j']:,.2f} $",
                f"{r['montant']:,.2f} $",
            ])
            for k in ('g', 'h', 'i', 'j', 'montant'):
                grand[k] += r[k]
        data.append([
            "TOTAL — tous les clients",
            f"{grand['g']:,.2f} $", f"{grand['h']:,.2f} $", f"{grand['i']:,.2f} $", f"{grand['j']:,.2f} $",
            f"{grand['montant']:,.2f} $",
        ])

        t = Table(data, colWidths=[55 * mm, 26 * mm, 26 * mm, 26 * mm, 26 * mm, 26 * mm], repeatRows=1)
        t.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8.5),
            ('GRID', (0, 0), (-1, -2), 0.5, colors.black),
            ('LINEABOVE', (0, -1), (-1, -1), 0.75, colors.black),
            ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
            ('ALIGN', (0, 0), (0, -1), 'LEFT'),
            ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#f3f4f6')),
        ]))
        story.append(t)
        story.append(Spacer(1, 4 * mm))
        story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))
        story.append(Spacer(1, 3 * mm))
        story.append(Paragraph(
            f"<b>{len(rows)} client(s) avec solde dû — total général : {grand['montant']:,.2f} $</b>",
            footer_style))

    doc.build(story)
    return pdf_path


# ============================================================
# Envoi Outlook
# ============================================================
def send_via_outlook(to_email, subject, body, pdf_path, mode='draft'):
    """mode: 'send' envoie directement, 'draft' ouvre le courriel dans Outlook pour
    relecture, 'draft_silent' l'enregistre dans le dossier Brouillons sans ouvrir de
    fenêtre (utilisé pour la création en lot de plusieurs brouillons à la fois)."""
    import win32com.client as win32
    outlook = win32.Dispatch('outlook.application')
    mail = outlook.CreateItem(0)
    mail.To = to_email
    mail.BCC = COMPANY_EMAIL
    mail.Subject = subject
    mail.Body = body
    mail.Attachments.Add(str(pdf_path))
    if mode == 'send':
        mail.Send()
        return 'ENVOYÉ'
    elif mode == 'draft_silent':
        mail.Save()
        return 'BROUILLON'
    else:
        mail.Display()
        return 'BROUILLON'


# ============================================================
# Création/envoi en lot pour tous les clients avec solde dû
# ============================================================
_bulk_state = {
    "running": False, "mode": None, "total": 0, "done": 0, "ok": 0, "skipped": 0, "errors": [],
    "finished_at": None,
}
_bulk_lock = threading.Lock()


def _run_bulk(mode, username=None):
    """mode: 'draft_silent' (brouillons dans Outlook, à réviser) ou 'send'
    (envoi direct immédiat, sans révision — irréversible)."""
    import pythoncom
    pythoncom.CoInitialize()
    try:
        clients = [c for c in db_list_clients() if c['solde'] and c['solde'] > 0]
        _bulk_state.update({"running": True, "mode": mode, "total": len(clients), "done": 0,
                             "ok": 0, "skipped": 0, "errors": [], "finished_at": None})
        for c in clients:
            name = c['name']
            try:
                detail = db_client_detail(name)
                to_email = detail['info'].get('courriel') or ''
                if not to_email:
                    _bulk_state["skipped"] += 1
                    _bulk_state["errors"].append(f"{name} : pas de courriel, ignoré")
                    _bulk_state["done"] += 1
                    continue
                statement_number = db_next_statement_number()
                pdf_path = generate_statement_pdf(name, detail['info'], detail['invoices'],
                                                    detail['totals'], statement_number)
                subject = f"État de compte — {name} ({statement_number})"
                body = (
                    f"Bonjour,\n\nVeuillez trouver ci-joint votre état de compte au "
                    f"{datetime.date.today().strftime('%d/%m/%Y')}.\n\n"
                    f"Solde total : {detail['totals']['montant']:,.2f} $\n\n"
                    f"Merci de votre attention.\n\n{DEFAULT_SENDER_SIGNATURE}"
                )
                statut = send_email(to_email, subject, body, pdf_path, mode=mode)
                label = "Envoi en lot" if mode == 'send' else "Brouillon en lot"
                db_log_envoi(name, to_email, detail['totals']['montant'], statut,
                             f"{label} — {statement_number}")
                _bulk_state["ok"] += 1
            except Exception as e:
                _bulk_state["errors"].append(f"{name} : {e}")
            _bulk_state["done"] += 1
    finally:
        _bulk_state["running"] = False
        _bulk_state["finished_at"] = datetime.datetime.now().isoformat()
        label = "Envoi en lot" if mode == 'send' else "Brouillons en lot"
        db_add_audit(username, label,
                     f"{_bulk_state['ok']} envoyé(s), {_bulk_state['skipped']} ignoré(s), "
                     f"{len(_bulk_state['errors'])} erreur(s)")
        pythoncom.CoUninitialize()


# ============================================================
# Routes — licence
# ============================================================
@app.route('/activation')
def activation_page():
    status = get_license_status()
    if status['active']:
        # Licence valide : cette page devient une vue/renouvellement volontaire,
        # réservée à un administrateur ou à un utilisateur ayant la permission
        # "license", déjà connecté.
        if not (session.get('is_admin') or 'license' in (session.get('permissions') or [])):
            return redirect(url_for('index'))
    return render_template('activation.html', company=COMPANY_NAME, status=status,
                            type_labels=licensing.TYPE_LABELS)


@app.route('/api/license/status')
def api_license_status():
    return jsonify(get_license_status())


@app.route('/api/license/activate', methods=['POST'])
def api_license_activate():
    data = request.json or {}
    code = (data.get('code') or '').strip()
    result = licensing.verify_license_code(code)
    if not result['ok']:
        return jsonify({'ok': False, 'error': result['error']}), 400

    payload = result['payload']
    expires = payload.get('expires')
    if expires:
        try:
            exp_date = datetime.date.fromisoformat(expires)
        except Exception:
            return jsonify({'ok': False, 'error': "Date d'expiration illisible dans ce code."}), 400
        if exp_date < datetime.date.today():
            return jsonify({'ok': False, 'error':
                             f"Ce code de licence a expiré le {expires}. Demande un nouveau code."}), 400

    meta_set('license_code', code)
    label = licensing.TYPE_LABELS.get(payload['type'], payload['type'])
    username = session.get('username') or 'N/A (avant connexion)'
    db_add_audit(username, 'Licence activée',
                 f"{payload['licensee']} — {label}" +
                 (f" — expire le {expires}" if expires else " — à vie"))
    return jsonify({'ok': True, 'payload': payload, 'type_label': label})


# ============================================================
# Routes — connexion / utilisateurs
# ============================================================
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        user = db_verify_login(username, password)
        if user:
            session.clear()
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['is_admin'] = bool(user['is_admin'])
            session['permissions'] = user.get('permissions', [])
            session.permanent = True
            db_add_audit(user['username'], 'Connexion')
            nxt = request.form.get('next') or url_for('index')
            return redirect(nxt)
        error = "Nom d'utilisateur ou mot de passe incorrect."
    nxt = request.args.get('next', '')
    return render_template('login.html', company=COMPANY_NAME, error=error, next=nxt)


@app.route('/logout')
def logout():
    if session.get('username'):
        db_add_audit(session.get('username'), 'Déconnexion')
    session.clear()
    return redirect(url_for('login'))


@app.route('/admin/users')
def admin_users_page():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return render_template('admin_users.html', company=COMPANY_NAME, username=session.get('username'),
                            permission_keys=PERMISSION_KEYS)


@app.route('/audit')
def audit_page():
    resp = permission_required_check('audit')
    if resp is not None:
        return resp
    return render_template('audit.html', company=COMPANY_NAME, username=session.get('username'),
                            is_admin=session.get('is_admin', False), permissions=session.get('permissions') or [])


@app.route('/api/audit')
def api_audit():
    resp = permission_required_check('audit')
    if resp is not None:
        return resp
    return jsonify(db_list_audit())


@app.route('/admin/email-settings')
def email_settings_page():
    resp = permission_required_check('email_settings')
    if resp is not None:
        return resp
    return render_template('email_settings.html', company=COMPANY_NAME, username=session.get('username'),
                            is_admin=session.get('is_admin', False), permissions=session.get('permissions') or [])


@app.route('/api/settings/send-mode')
def api_send_mode():
    return jsonify(get_public_settings())


# ============================================================
# Routes — mises à jour (version et changelog)
# ============================================================
@app.route('/admin/updates')
def updates_page():
    resp = permission_required_check('updates')
    if resp is not None:
        return resp
    return render_template('updates.html', company=COMPANY_NAME, username=session.get('username'),
                            version=APP_VERSION, changelog=CHANGELOG,
                            is_admin=session.get('is_admin', False), permissions=session.get('permissions') or [])


@app.route('/api/updates')
def api_updates():
    resp = permission_required_check('updates')
    if resp is not None:
        return resp
    return jsonify({'version': APP_VERSION, 'changelog': CHANGELOG})


@app.route('/api/updates/check')
def api_updates_check():
    resp = permission_required_check('updates')
    if resp is not None:
        return resp
    try:
        req = urllib.request.Request(UPDATE_CHECK_URL, headers={'Cache-Control': 'no-cache'})
        with urllib.request.urlopen(req, timeout=6) as r:
            raw_body = r.read().decode('utf-8-sig').strip()
            remote = json.loads(raw_body)
    except urllib.error.URLError:
        return jsonify({'ok': False, 'error':
                         "Impossible de joindre le serveur de mises à jour. "
                         "Vérifie ta connexion Internet et réessaie."})
    except Exception as e:
        return jsonify({'ok': False, 'error':
                         "Réponse invalide du serveur de mises à jour (%s)." % e})

    remote_version = remote.get('version', '')
    remote_changelog = remote.get('changelog', [])
    try:
        up_to_date = _version_tuple(APP_VERSION) >= _version_tuple(remote_version)
    except Exception:
        return jsonify({'ok': False, 'error': "Numéro de version distant illisible."})

    # Les changements plus récents que la version installée (pour affichage).
    new_entries = [e for e in remote_changelog
                   if _version_tuple(e.get('version', '0.0.0')) > _version_tuple(APP_VERSION)]

    return jsonify({
        'ok': True,
        'installed_version': APP_VERSION,
        'latest_version': remote_version,
        'up_to_date': up_to_date,
        'new_entries': new_entries,
        'can_auto_install': bool(remote.get('download_url')),
    })


@app.route('/api/updates/install', methods=['POST'])
def api_updates_install():
    resp = permission_required_check('updates')
    if resp is not None:
        return resp

    try:
        req = urllib.request.Request(UPDATE_CHECK_URL, headers={'Cache-Control': 'no-cache'})
        with urllib.request.urlopen(req, timeout=6) as r:
            remote = json.loads(r.read().decode('utf-8-sig').strip())
    except Exception as e:
        return jsonify({'ok': False, 'error': "Impossible de joindre le serveur de mises à jour (%s)." % e}), 400

    download_url = remote.get('download_url')
    if not download_url:
        return jsonify({'ok': False, 'error':
                         "Aucun paquet de mise à jour téléchargeable pour l'instant. "
                         "Utilise « Vérifier les mises à jour » pour voir ce qui a changé."}), 400

    try:
        # Télécharge et extrait le paquet de code dans un dossier temporaire,
        # HORS du dossier de l'app (C:\DBouxpCR\app) — jamais dans le dossier
        # en cours d'utilisation par ce processus.
        if UPDATE_STAGING_DIR.exists():
            shutil.rmtree(UPDATE_STAGING_DIR, ignore_errors=True)
        UPDATE_STAGING_DIR.mkdir(parents=True, exist_ok=True)

        dl_req = urllib.request.Request(download_url, headers={'Cache-Control': 'no-cache'})
        with urllib.request.urlopen(dl_req, timeout=30) as r:
            zip_bytes = r.read()
        UPDATE_ZIP_PATH.write_bytes(zip_bytes)

        with zipfile.ZipFile(UPDATE_ZIP_PATH) as zf:
            zf.extractall(UPDATE_STAGING_DIR)

        staged_app_dir = UPDATE_STAGING_DIR / "app"
        if not (staged_app_dir / "app.py").exists():
            return jsonify({'ok': False, 'error':
                             "Le paquet téléchargé est invalide (app.py introuvable dedans)."}), 400
    except Exception as e:
        return jsonify({'ok': False, 'error': f"Échec du téléchargement du paquet : {e}"}), 400

    try:
        runner_src = _UPDATE_RUNNER_SCRIPT.format(
            staged=str(staged_app_dir), target=str(APP_DIR), base=str(BASE_DIR))
        UPDATE_RUNNER_PATH.write_text(runner_src, encoding='utf-8')

        creationflags = 0
        popen_kwargs = {'cwd': str(BASE_DIR), 'close_fds': True}
        if sys.platform == 'win32':
            creationflags = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
            popen_kwargs['creationflags'] = creationflags
        subprocess.Popen([sys.executable, str(UPDATE_RUNNER_PATH)], **popen_kwargs)
    except Exception as e:
        return jsonify({'ok': False, 'error': f"Impossible de démarrer l'installation : {e}"}), 400

    db_add_audit(session.get('username'), 'Mise à jour installée', f"vers v{remote.get('version')}")

    # Laisse le temps à cette réponse HTTP de partir avant de fermer ce
    # processus — le script lancé ci-dessus attend, de son côté, que ce
    # processus soit bien terminé avant de copier les fichiers.
    def _delayed_exit():
        time.sleep(1.5)
        os._exit(0)
    threading.Thread(target=_delayed_exit, daemon=True).start()

    return jsonify({'ok': True, 'message':
                     "Téléchargement terminé. L'application redémarre maintenant — "
                     "recharge cette page dans environ 30 secondes."})


@app.route('/api/settings/email', methods=['GET'])
def api_get_email_settings():
    resp = permission_required_check('email_settings')
    if resp is not None:
        return resp
    settings = get_settings()
    settings['smtp_password_set'] = bool(settings.get('smtp_password'))
    settings.pop('smtp_password', None)
    return jsonify(settings)


@app.route('/api/settings/email', methods=['PUT'])
def api_set_email_settings():
    resp = permission_required_check('email_settings')
    if resp is not None:
        return resp
    data = request.json or {}
    send_mode = data.get('send_mode', 'outlook')
    if send_mode == 'smtp':
        host = (data.get('smtp_host') or '').strip()
        from_email = (data.get('smtp_from_email') or '').strip()
        if not host or not from_email:
            return jsonify({'ok': False, 'error':
                             "Pour activer le mode SMTP, il faut au minimum l'adresse du "
                             "serveur et l'adresse courriel d'expédition."}), 400
    set_settings(data)
    log_audit('Modification paramètres d\'envoi', f"mode={send_mode}")
    return jsonify({'ok': True})


@app.route('/api/settings/email/test', methods=['POST'])
def api_test_email_settings():
    resp = permission_required_check('email_settings')
    if resp is not None:
        return resp
    data = request.json or {}
    # Si le mot de passe n'est pas fourni (champ laissé vide dans le formulaire),
    # on utilise celui déjà enregistré pour permettre de tester sans le retaper.
    settings = dict(data)
    if not settings.get('smtp_password'):
        settings['smtp_password'] = meta_get('smtp_password', '')
    try:
        test_smtp_connection(settings)
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/users', methods=['GET'])
def api_list_users():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return jsonify(db_list_users())


@app.route('/api/users', methods=['POST'])
def api_create_user():
    resp = admin_required_check()
    if resp is not None:
        return resp
    data = request.json or {}
    try:
        db_create_user(data.get('username', ''), data.get('password', ''), bool(data.get('is_admin')),
                        permissions=data.get('permissions'))
        log_audit('Création utilisateur', data.get('username', ''))
        return jsonify({'ok': True})
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/users/<int:user_id>', methods=['PUT'])
def api_update_user(user_id):
    resp = admin_required_check()
    if resp is not None:
        return resp
    data = request.json or {}
    if user_id == session.get('user_id') and data.get('active') is False:
        return jsonify({'ok': False, 'error': "Tu ne peux pas désactiver ton propre compte."}), 400
    try:
        db_update_user(
            user_id,
            is_admin=data.get('is_admin'),
            active=data.get('active'),
            new_password=data.get('password') or None,
            permissions=data.get('permissions'),
        )
        target = db_get_user(user_id)
        target_name = target['username'] if target else str(user_id)
        changes = []
        if data.get('is_admin') is not None:
            changes.append('admin' if data.get('is_admin') else 'retrait admin')
        if data.get('active') is not None:
            changes.append('réactivé' if data.get('active') else 'désactivé')
        if data.get('password'):
            changes.append('mot de passe réinitialisé')
        if data.get('permissions') is not None:
            changes.append(f"accès : {', '.join(data.get('permissions')) or 'aucun'}")
        log_audit('Modification utilisateur', f"{target_name} ({', '.join(changes) or 'aucun changement'})")
        return jsonify({'ok': True})
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/users/<int:user_id>', methods=['DELETE'])
def api_delete_user(user_id):
    resp = admin_required_check()
    if resp is not None:
        return resp
    if user_id == session.get('user_id'):
        return jsonify({'ok': False, 'error': "Tu ne peux pas supprimer ton propre compte."}), 400
    target = db_get_user(user_id)
    db_delete_user(user_id)
    log_audit('Suppression utilisateur', target['username'] if target else str(user_id))
    return jsonify({'ok': True})


@app.route('/api/me')
def api_me():
    u = current_user()
    if not u:
        return jsonify({'error': 'auth_required'}), 401
    return jsonify({'username': u['username'], 'is_admin': bool(u['is_admin'])})


# ============================================================
# Routes
# ============================================================
@app.route('/')
def index():
    return render_template('index.html', company=COMPANY_NAME, company_email=COMPANY_EMAIL,
                            username=session.get('username'), is_admin=session.get('is_admin', False),
                            permissions=session.get('permissions') or [])


@app.route('/api/clients')
def api_clients():
    clients = db_list_clients()
    return jsonify(clients)


@app.route('/api/client/<path:name>')
def api_client_detail(name):
    data = db_client_detail(name)
    if data is None:
        return jsonify({'error': 'Client introuvable'}), 404
    data['invoices'] = [i for i in data['invoices'] if i['montant'] != 0 or i['numero']]
    return jsonify(data)


@app.route('/api/client', methods=['POST'])
def api_create_client():
    data = request.json
    try:
        sheet_name = db_create_client(
            data['name'], data.get('phone', ''), data.get('adresse', ''),
            data.get('ville', ''), data.get('province', 'Qc'),
            data.get('code_postal', ''), data.get('courriel', ''),
        )
        log_audit('Création client', data['name'])
        return jsonify({'ok': True, 'sheet': sheet_name})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/client/<path:name>/invoice', methods=['POST'])
def api_add_invoice(name):
    data = request.json
    try:
        db_add_invoice(
            name, data['numero'], data['date_facture'], data['echeance'],
            data['montant'], data.get('notes', ''), data.get('montant_paye', 0) or 0,
        )
        log_audit('Ajout facture', f"{name} — n° {data['numero']} — {float(data['montant']):,.2f} $")
        return jsonify({'ok': True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/invoice/<int:invoice_id>', methods=['PUT'])
def api_update_invoice(invoice_id):
    data = request.json
    try:
        existing = db_get_invoice(invoice_id)
        db_update_invoice(
            invoice_id, data['numero'], data['date_facture'], data['echeance'],
            data['montant'], data.get('notes', ''), data.get('montant_paye', 0) or 0,
        )
        client_name = existing['client_name'] if existing else ''
        log_audit('Modification facture', f"{client_name} — n° {data['numero']}")
        return jsonify({'ok': True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/invoice/<int:invoice_id>', methods=['DELETE'])
def api_delete_invoice(invoice_id):
    try:
        inv = db_get_invoice(invoice_id)
        db_delete_invoice(invoice_id)
        detail = f"{inv['client_name']} — n° {inv['numero']} — {inv['montant']:,.2f} $" if inv else f"id={invoice_id}"
        log_audit('Suppression facture', detail)
        return jsonify({'ok': True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/invoice/<int:invoice_id>/paid', methods=['PUT'])
def api_set_invoice_paid(invoice_id):
    data = request.json or {}
    try:
        paid = bool(data.get('paid', True))
        inv = db_get_invoice(invoice_id)
        db_set_invoice_paid(invoice_id, paid)
        detail = f"{inv['client_name']} — n° {inv['numero']}" if inv else f"id={invoice_id}"
        log_audit('Facture marquée payée' if paid else 'Paiement annulé', detail)
        return jsonify({'ok': True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/client/<path:name>/statement', methods=['POST'])
def api_statement(name):
    """Génère le PDF et (selon le mode) crée un brouillon ou envoie le courriel via Outlook.
    Ne touche pas à l'Excel — tout vient de la base rapide (le PDF/courriel n'a pas besoin
    d'attendre une synchronisation Excel)."""
    data = request.json or {}
    mode = data.get('mode', 'draft')
    if mode in ('draft', 'draft_silent') and get_settings()['send_mode'] == 'smtp':
        return jsonify({'ok': False, 'error':
                         "Le mode brouillon n'est pas disponible en mode d'envoi SMTP "
                         "(pas de fenêtre de relecture) — utilise \"Envoyer directement\"."}), 400
    try:
        client = db_client_detail(name)
        if client is None:
            return jsonify({'ok': False, 'error': 'Client introuvable'}), 404
        info, invoices, totals = client['info'], client['invoices'], client['totals']

        statement_number = db_next_statement_number()
        pdf_path = generate_statement_pdf(name, info, invoices, totals, statement_number)

        to_email = data.get('email') or info.get('courriel') or ''
        subject = data.get('subject') or f"État de compte — {name} ({statement_number})"
        body = data.get('body') or (
            f"Bonjour,\n\nVeuillez trouver ci-joint votre état de compte au "
            f"{datetime.date.today().strftime('%d/%m/%Y')}.\n\n"
            f"Solde total : {totals['montant']:,.2f} $\n\n"
            f"Merci de votre attention.\n\n{DEFAULT_SENDER_SIGNATURE}"
        )

        if not to_email:
            statut = 'PDF_SEULEMENT'
            db_log_envoi(name, to_email, totals['montant'], statut, 'Aucun courriel client — PDF généré seulement')
            log_audit('État de compte généré', f"{name} — {statement_number} — PDF seulement (aucun courriel)")
            return jsonify({'ok': True, 'pdf': str(pdf_path), 'statut': statut,
                             'warning': "Aucune adresse courriel pour ce client — PDF généré mais courriel non préparé."})

        statut = send_email(to_email, subject, body, pdf_path, mode=mode)
        db_log_envoi(name, to_email, totals['montant'], statut, f"Via app locale ({mode}) — {statement_number}")
        log_audit('État de compte généré', f"{name} — {statement_number} — {mode} — {totals['montant']:,.2f} $")
        return jsonify({'ok': True, 'pdf': str(pdf_path), 'statut': statut, 'statement_number': statement_number})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/client/<path:name>/pdf')
def api_get_pdf(name):
    client = db_client_detail(name)
    if client is None:
        return jsonify({'error': 'Client introuvable'}), 404
    statement_number = db_next_statement_number()
    pdf_path = generate_statement_pdf(name, client['info'], client['invoices'], client['totals'], statement_number)
    log_audit('PDF état de compte téléchargé', f"{name} — {statement_number}")
    return send_file(str(pdf_path), as_attachment=True)


@app.route('/api/reports/monthly')
def api_monthly_report():
    resp = permission_required_check('reports')
    if resp is not None:
        return resp
    try:
        year = int(request.args.get('year'))
        month = int(request.args.get('month'))
        if not (1 <= month <= 12):
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({'error': "Paramètres 'year' et 'month' invalides."}), 400
    by_client = db_invoices_by_month(year, month)
    pdf_path = generate_monthly_report_pdf(year, month, by_client)
    log_audit('Rapport mensuel généré', f"{MOIS_FR[month]} {year}")
    return send_file(str(pdf_path), as_attachment=True,
                      download_name=f"Rapport_{MOIS_FR[month]}_{year}.pdf")


@app.route('/api/reports/envois')
def api_envois_report():
    resp = permission_required_check('reports')
    if resp is not None:
        return resp
    try:
        year = int(request.args.get('year'))
        month = int(request.args.get('month'))
        if not (1 <= month <= 12):
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({'error': "Paramètres 'year' et 'month' invalides."}), 400
    rows = db_envois_by_month(year, month)
    pdf_path = generate_envoi_report_pdf(year, month, rows)
    log_audit('Rapport d\'envoi généré', f"{MOIS_FR[month]} {year}")
    return send_file(str(pdf_path), as_attachment=True,
                      download_name=f"Rapport_envois_{MOIS_FR[month]}_{year}.pdf")


@app.route('/api/reports/aging')
def api_aging_report():
    resp = permission_required_check('reports')
    if resp is not None:
        return resp
    year_raw = request.args.get('year')
    month_raw = request.args.get('month')
    ref_date = None
    period_label = None
    if year_raw or month_raw:
        try:
            year = int(year_raw)
            month = int(month_raw)
            if not (1 <= month <= 12):
                raise ValueError
        except (TypeError, ValueError):
            return jsonify({'error': "Paramètres 'year' et 'month' invalides."}), 400
        ref_date = month_end_or_today(year, month)
        period_label = f"{MOIS_FR[month]} {year}"

    rows = db_aging_all_clients(ref_date)
    pdf_path = generate_aging_report_pdf(rows, ref_date, period_label)
    ref_str = (ref_date or datetime.date.today()).strftime('%Y-%m-%d')
    log_audit('Rapport d\'âge généré', period_label or "aujourd'hui")
    return send_file(str(pdf_path), as_attachment=True,
                      download_name=f"Rapport_age_{ref_str}.pdf")


@app.route('/api/sync', methods=['POST'])
def api_sync():
    try:
        export_to_excel()
        log_audit('Synchronisation manuelle vers Excel')
        return jsonify({'ok': True, 'last_sync': meta_get('last_sync')})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/sync/status')
def api_sync_status():
    return jsonify({
        'dirty': meta_get('dirty', '0') == '1',
        'running': _sync_state["running"],
        'last_error': _sync_state["last_error"],
        'last_sync': meta_get('last_sync'),
    })


@app.route('/api/statements/bulk-draft', methods=['POST'])
def api_bulk_draft():
    if get_settings()['send_mode'] == 'smtp':
        return jsonify({'ok': False, 'error':
                         "Le mode brouillon n'est pas disponible en mode d'envoi SMTP "
                         "(pas de fenêtre de relecture) — utilise \"Envoyer directement\"."}), 400
    with _bulk_lock:
        if _bulk_state["running"]:
            return jsonify({'ok': False, 'error': 'Une opération en lot est déjà en cours.'}), 409
        t = threading.Thread(target=_run_bulk, args=('draft_silent', session.get('username')), daemon=True)
        t.start()
    return jsonify({'ok': True})


@app.route('/api/statements/bulk-send', methods=['POST'])
def api_bulk_send():
    with _bulk_lock:
        if _bulk_state["running"]:
            return jsonify({'ok': False, 'error': 'Une opération en lot est déjà en cours.'}), 409
        t = threading.Thread(target=_run_bulk, args=('send', session.get('username')), daemon=True)
        t.start()
    return jsonify({'ok': True})


@app.route('/api/statements/bulk-draft/status')
def api_bulk_draft_status():
    return jsonify(_bulk_state)


def _detect_lan_ip():
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))  # aucune donnée envoyée, juste pour détecter l'interface réseau
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return None


def start_app():
    """Point d'entrée commun : démarrage interactif (start.bat) ET démarrage
    comme service Windows (service.py) appellent cette même fonction, pour
    garantir exactement la même initialisation dans les deux cas."""
    print(f"Fichier Excel utilisé : {EXCEL_PATH}")
    if not EXCEL_PATH.exists():
        # Nouvelle installation (aucune donnée existante) : on part d'un
        # classeur vierge plutôt que de bloquer le démarrage.
        create_blank_excel_template(EXCEL_PATH)
    ensure_db_ready()
    app.secret_key = get_or_create_secret_key()
    app.config['PERMANENT_SESSION_LIFETIME'] = datetime.timedelta(days=30)
    ensure_admin_bootstrap()
    t = threading.Thread(target=_auto_sync_loop, daemon=True)
    t.start()

    print()
    print("=" * 60)
    print(f"Accès depuis CET ordinateur :  http://127.0.0.1:{APP_PORT}")
    lan_ip = _detect_lan_ip()
    if lan_ip:
        print(f"Accès depuis un AUTRE ordinateur du même réseau :")
        print(f"    http://{lan_ip}:{APP_PORT}")
        print("(Windows peut demander une autorisation de pare-feu la")
        print(" première fois — accepte pour le réseau 'Privé'.)")
    print("=" * 60)
    print()

    # Serveur de production (Waitress) au lieu du serveur de développement
    # Flask — celui-ci n'est pas conçu pour tourner sans surveillance en
    # tant que service et affiche un avertissement à cet effet.
    from waitress import serve
    serve(app, host='0.0.0.0', port=APP_PORT, threads=8)


if __name__ == '__main__':
    start_app()
