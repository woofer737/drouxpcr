# -*- coding: utf-8 -*-
"""
App locale de gestion des Comptes à recevoir.

Architecture (v2 — rapide) :
- Une base SQLite locale (data.db) est la source de données pour l'app :
  toutes les lectures/écritures (ajout de facture, nouveau client) sont
  quasi instantanées.
- Le fichier "Compte à recevoir.xlsx" reste le document "officiel" que tu
  peux ouvrir dans Excel — il est régénéré à partir de la base SQLite,
  soit automatiquement en arrière-plan (toutes les quelques minutes),
  soit à la demande (bouton "Synchroniser vers Excel").
- Au tout premier démarrage, toutes les données de l'Excel existant sont
  importées une seule fois dans la base (ça prend ~30s la première fois
  seulement). Ensuite, tout est instantané.

IMPORTANT : une fois l'app utilisée, la base SQLite devient la référence.
Si tu modifies le fichier Excel à la main entre deux synchronisations, ces
changements seront écrasés à la prochaine synchronisation. Fais tes
changements dans l'app plutôt que dans Excel.

Démarrage : double-cliquer sur start.bat (voir README.txt)
"""
import os
import re
import io
import csv
import sys
import json
import base64
import hashlib
import unicodedata
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path

from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash

import openpyxl
from openpyxl.utils import get_column_letter

import licensing

# ============================================================
# CONFIGURATION
# ============================================================
BASE_DIR = Path(__file__).resolve().parent.parent  # C:\DBouxpCR
EXCEL_PATH = BASE_DIR / "Compte à recevoir.xlsx"
PDF_DIR = BASE_DIR / "Etats_de_compte"
PDF_DIR.mkdir(exist_ok=True)
DB_PATH = Path(__file__).resolve().parent / "data.db"

APP_PORT = int(os.environ.get("APP_PORT", "5080"))

AUTO_SYNC_SECONDS = 180  # synchronise automatiquement vers Excel toutes les 3 minutes s'il y a des changements

# Valeurs par défaut (utilisées tant que rien n'a été personnalisé depuis le
# module Administration). Les valeurs effectives sont lues dynamiquement via
# les fonctions get_company_name()/get_company_email()/... ci-dessous, qui
# consultent d'abord la table `meta` (personnalisation admin) avant de
# retomber sur ces constantes.
COMPANY_NAME_DEFAULT = "Outillages Express"
COMPANY_EMAIL_DEFAULT = "recevables@outillagesexpress.ca"
COMPANY_PHONE_DEFAULT = ""  # optionnel, à remplir
PDF_FOOTER_MESSAGE_DEFAULT = "Merci de votre confiance."
EMAIL_CLOSING_MESSAGE_DEFAULT = "Merci de votre attention."

LOGO_PATH = Path(__file__).resolve().parent / "static" / "logo.png"
LOGO_DEFAULT_BACKUP_PATH = Path(__file__).resolve().parent / "static" / "logo_default.png"
# Image de fond de la page de connexion (1.11.1). L'image par défaut est livrée
# avec les mises à jour ; une photo personnalisée est gardée sous un autre nom
# (login_bg_custom.*) pour qu'une mise à jour ne l'écrase jamais.
LOGIN_BG_DEFAULT_NAME = "login_bg_default.svg"
LOGIN_BG_CUSTOM_PREFIX = "login_bg_custom"
LOGIN_BG_EXTS = ('.jpg', '.jpeg', '.png', '.webp')
LOGIN_BG_MAX_BYTES = 8 * 1024 * 1024  # 8 Mo
LOGIN_VIDEO_PREFIX = "login_video_custom"          # 1.32.0 : vidéo de fond de la page de connexion
LOGIN_VIDEO_EXTS = ('.mp4', '.webm')
LOGIN_VIDEO_MAX_BYTES = 80 * 1024 * 1024           # 80 Mo
LOGIN_BG_MODES = ('mosaique', 'image', 'video')


def get_company_name():
    return (meta_get('company_name') or COMPANY_NAME_DEFAULT).strip() or COMPANY_NAME_DEFAULT


def get_company_email():
    return (meta_get('company_email') or COMPANY_EMAIL_DEFAULT).strip()


def get_company_phone():
    return (meta_get('company_phone') or COMPANY_PHONE_DEFAULT).strip()


_LOOPBACK = ('127.0.0.1', '::1', '::ffff:127.0.0.1')


def client_ip():
    """Adresse réelle de l'utilisateur (1.26.1).
    Derrière Cloudflare Tunnel, toutes les connexions arrivent du tunnel (127.0.0.1) : on lit alors
    l'en-tête CF-Connecting-IP (ou X-Forwarded-For). Ces en-têtes ne sont crus que si la connexion
    vient du PC lui-même, là où roule cloudflared — sinon n'importe qui sur le réseau pourrait les inventer."""
    ra = request.remote_addr or ''
    if ra in _LOOPBACK:
        cf = (request.headers.get('CF-Connecting-IP') or '').strip()
        if cf:
            return cf[:64]
        xff = (request.headers.get('X-Forwarded-For') or '').split(',')[0].strip()
        if xff:
            return xff[:64]
    return ra or '?'


REPORT_DISCLAIMER_TITLE = "Avis de non-responsabilité"
REPORT_DISCLAIMER = ("Les montants de ce rapport sont calculés automatiquement à partir des données de Lightspeed et de Kubios, "
                     "et sont fournis à titre indicatif. Kubios et Groupe SRB ne peuvent être tenus responsables d'erreurs, "
                     "d'omissions ou d'inexactitudes. Validez périodiquement, par échantillonnage, les montants dans Lightspeed "
                     "avant de les utiliser à des fins comptables ou fiscales.")


def _pdf_disclaimer(space=14, size=7.5):
    """Encadré de l'avis de non-responsabilité, ajouté à la fin des rapports PDF internes."""
    from reportlab.platypus import Table, TableStyle, Paragraph, Spacer, KeepTogether
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib import colors
    st = ParagraphStyle('avis', fontName='Helvetica', fontSize=size, leading=size + 2, textColor=colors.HexColor('#4b5563'))
    t = Table([[Paragraph(f"<b>{REPORT_DISCLAIMER_TITLE}</b> — {REPORT_DISCLAIMER}", st)]])
    t.setStyle(TableStyle([('BOX', (0, 0), (-1, -1), 0.5, colors.HexColor('#cbd5e1')), ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#f8fafc')),
                           ('LEFTPADDING', (0, 0), (-1, -1), 6), ('RIGHTPADDING', (0, 0), (-1, -1), 6),
                           ('TOPPADDING', (0, 0), (-1, -1), 5), ('BOTTOMPADDING', (0, 0), (-1, -1), 5)]))
    return KeepTogether([Spacer(1, space), t])


def _xlsx_disclaimer(ws):
    """Avis à la fin d'une feuille Excel de rapport."""
    from openpyxl.styles import Font, Alignment
    r = ws.max_row + 2
    c = ws.cell(row=r, column=1, value=f"{REPORT_DISCLAIMER_TITLE} — {REPORT_DISCLAIMER}")
    c.font = Font(italic=True, size=9, color='4B5563')
    c.alignment = Alignment(wrap_text=True, vertical='top')
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=max(4, min(ws.max_column, 10)))
    ws.row_dimensions[r].height = 48


def get_pdf_footer_message():
    return (meta_get('pdf_footer_message') or PDF_FOOTER_MESSAGE_DEFAULT).strip() or PDF_FOOTER_MESSAGE_DEFAULT


def get_email_closing_message():
    msg = meta_get('email_closing_message')
    return msg if msg is not None and msg.strip() else EMAIL_CLOSING_MESSAGE_DEFAULT


def get_sender_signature():
    email = get_company_email()
    name = get_company_name()
    return f"{name}\n{email}" if email else name


# Nom du LOGICIEL lui-même (affiché sur l'écran de connexion) — distinct du
# nom de l'entreprise (personnalisable via le module Administration) qui
# reste utilisé pour les états de compte, courriels et documents envoyés
# aux clients.
APP_NAME = "Kubios"

# ============================================================
# Version du logiciel et historique des changements
# ------------------------------------------------------------
# À chaque modification livrée, on ajoute une nouvelle entrée en haut de
# CHANGELOG et on augmente APP_VERSION. La page "Mises à jour" (admin)
# affiche cette liste — c'est la source de vérité pour savoir ce qui a
# changé et à quelle version l'application installée correspond.
# ============================================================
APP_VERSION = "1.43.2"

CHANGELOG = [
    {
        "version": "1.43.2",
        "date": "2026-11-11",
        "changes": [
            "Microsoft 365 : adresse de réponse pour les états de compte (ex. le groupe Teams recevables@) et option de copie "
            "cachée à cette adresse. Utile quand la boîte des comptes à recevoir est un groupe Microsoft 365, qui ne peut pas "
            "servir de boîte d'envoi.",
        ],
    },
    {
        "version": "1.43.1",
        "date": "2026-11-10",
        "changes": [
            "Paramètres d'envoi : guide Microsoft 365 mis à jour avec la méthode recommandée par Microsoft (RBAC pour les "
            "applications d'Exchange Online, limitée aux deux boîtes, sans permission Mail.Send dans Entra) ; message "
            "d'erreur d'accès refusé plus précis.",
        ],
    },
    {
        "version": "1.43.0",
        "date": "2026-11-09",
        "changes": [
            "Nouveau : Gestion → En ligne. Liste des sessions ouvertes (Kubios et portail employé) avec l'adresse, "
            "l'appareil et la dernière activité ; un administrateur peut fermer une session ou toutes celles d'une personne.",
            "Paramètres d'envoi : nouvelle méthode Microsoft 365 (Graph). Les états de compte partent de la boîte partagée "
            "des comptes à recevoir, tous les autres envois de la boîte de Kubios ; brouillons déposés dans la boîte ; "
            "test d'envoi par boîte. Outlook et SMTP restent disponibles.",
            "Utilisateurs : « Nouvel utilisateur » et « Réactiver » grisés quand la limite de la licence est atteinte ; "
            "pastille verte pour les personnes en ligne ; le panneau se ferme correctement avec ×.",
        ],
    },
    {
        "version": "1.42.1",
        "date": "2026-11-09",
        "changes": [
            "Horaires : toujours sur 2 semaines (Période 1 et Période 2) ; menu « Copier » : Période 1 → Période 2, "
            "Période 2 → Période 1, ou les 2 semaines précédentes. PDF : heures centrées sous chaque jour, une page par période.",
            "Feuilles de temps : « En direct » montre aussi qui est en retard ou pas encore arrivé selon l'horaire. Le PDF "
            "et l'Excel ont un détail par jour : prévu, entrée, sortie, pauses payées, dîner déduit, heures, et remarques "
            "(retard, absence, sortie manquante, corrections avec la raison).",
        ],
    },
    {
        "version": "1.42.0",
        "date": "2026-11-09",
        "changes": [
            "Nouveau : Gestion RH → Horaires. Grille par département et par jour, quarts types et repas en un clic, "
            "congés, total de la semaine (repas déduit), copie de la période précédente, PDF à afficher. Brouillon "
            "jusqu'à la publication ; à la publication, chaque employé touché reçoit un courriel avec ses journées.",
            "Portail employé : « Mon horaire » (cette semaine et la suivante, aujourd'hui en évidence, avis des "
            "changements) et l'horaire de tout le magasin ; la journée d'aujourd'hui sur l'accueil.",
            "Feuilles de temps : retards (au-delà de la tolérance, 5 min par défaut) et absences signalés en comparant "
            "l'horaire publié aux punchs.",
        ],
    },
    {
        "version": "1.41.1",
        "date": "2026-11-09",
        "changes": [
            "Feuilles de temps : la fenêtre de correction des punchs est plus large ; chaque punch tient sur deux lignes "
            "(type, date et heure, boutons, puis la raison sur toute la largeur). Les raisons s'affichent en entier.",
        ],
    },
    {
        "version": "1.41.0",
        "date": "2026-11-09",
        "changes": [
            "Bons de travail : bouton ⏱ « Ajouter du temps / Terminer » sur chaque bon. Le responsable ajoute le temps "
            "qu'un mécanicien a oublié de puncher (durée en un clic, proposée d'après « Service N mins »), avec la raison "
            "notée au journal, et peut marquer le bon terminé ; un punch resté ouvert est fermé. Kubios refuse un temps "
            "qui chevauche un autre punch du mécanicien ou qui finirait dans le futur.",
        ],
    },
    {
        "version": "1.40.2",
        "date": "2026-11-09",
        "changes": [
            "Liste et Terminés des bons de travail : tableau compact qui tient à l'écran sans défiler de gauche à droite "
            "(client et appareil sur deux lignes, priorité sous le numéro, actions en petits boutons) ; un clic sur la "
            "ligne ouvre le bon.",
        ],
    },
    {
        "version": "1.40.1",
        "date": "2026-11-09",
        "changes": [
            "Bons de travail : vue « ✓ Terminés » et liste avec recherche (numéro, client, appareil, travaux), filtres "
            "(statut, mécanicien, période de fin), colonne « Terminé le » et pages de 50 bons. La liste et le calendrier "
            "ne sont plus limités à 500 bons.",
            "Services non reliés : client et appareil du bon quand il n'a aucun punch, et bons probables proposés (même "
            "durée de service, date proche) à associer en un clic quand la vente n'a pas de « HT: # ».",
        ],
    },
    {
        "version": "1.40.0",
        "date": "2026-11-09",
        "changes": [
            "Atelier → Bons de travail : « Importer de HubTiger » — dépose l'export « Jobs booked in detail » (.xlsx), "
            "vois l'aperçu (nouveaux bons, bons complétés, bons terminés), puis confirme. Les champs saisis dans Kubios "
            "ne sont jamais écrasés ; le mécanicien, l'ordre et la date de travail ne sont jamais touchés.",
            "Option : dossier de dépôt C:\\DBouxpCR\\Import_HubTiger — un export qui y est enregistré est importé tout seul "
            "(vérification toutes les 5 minutes), puis rangé dans « Importés ».",
        ],
    },
    {
        "version": "1.39.2",
        "date": "2026-11-09",
        "changes": [
            "Page de connexion : bouton « Punch des employés » à côté de « Espace employé » (module RH actif) ; un "
            "appareil non autorisé doit entrer le code d'accès des postes.",
        ],
    },
    {
        "version": "1.39.1",
        "date": "2026-11-09",
        "changes": [
            "Page de connexion : bouton « Espace employé » vers le portail des employés (affiché quand le module RH est "
            "actif) ; lien de retour vers la connexion Kubios sur la page du portail.",
        ],
    },
    {
        "version": "1.39.0",
        "date": "2026-11-09",
        "changes": [
            "Portail employé (module RH) : chaque employé peut avoir son espace (invitation par courriel, compte séparé "
            "qui ne compte pas dans les utilisateurs de la licence) pour voir ses heures et les documents publiés, et "
            "signer ceux qui le demandent.",
            "Documents RH : publier ou retirer du portail, demander la signature de l'employé, signer comme gestionnaire "
            "(nom tapé ou signature dessinée), PDF signé avec page de signatures et empreinte, envoi d'une copie par courriel.",
            "Punch des employés : poste sur ordinateur ou tablette autorisé (NIP), entrée, pause, retour, sortie ; feuilles "
            "de temps avec pauses de 15 min ou moins payées, dîner déduit, heures sup. au-delà de 40 h/semaine, corrections "
            "notées, approbation, période à la semaine ou aux deux semaines, exports Excel et PDF.",
        ],
    },
    {
        "version": "1.38.0",
        "date": "2026-11-08",
        "changes": [
            "Licence par modules : le noyau, Gestion Atelier et Gestion RH ont chacun leur durée (ex. noyau à vie, "
            "Atelier et RH 1 an). Un module non inclus ou expiré disparaît du menu et ses pages sont bloquées, sans "
            "perte de données. Les anciens codes (OE-LIC1-) restent valides et donnent accès à tous les modules.",
            "Nouvelle page Licence, dans le style des autres pages, avec le tableau des modules ; l'avis « expire "
            "bientôt » couvre aussi les modules. Nouveau générateur de licences avec fenêtres (outil séparé).",
        ],
    },
    {
        "version": "1.37.0",
        "date": "2026-11-08",
        "changes": [
            "Page Utilisateurs repensée : recherche et filtres, liste épurée (rôle, statut, 2FA, nombre d'accès, "
            "dernière connexion), et panneau de détail par personne (profil, rôle et accès regroupés par module avec "
            "modèles en un clic, sécurité et mot de passe avec générateur, statut). Un seul bouton « Enregistrer ».",
        ],
    },
    {
        "version": "1.36.0",
        "date": "2026-11-08",
        "changes": [
            "Mises à jour : installer un paquet téléversé (kubios-x.y.z.zip), sans passer par GitHub. Kubios vérifie "
            "le paquet, affiche sa version et ses changements, avertit s'il est plus ancien ou identique, puis "
            "l'installe et redémarre comme une mise à jour normale.",
        ],
    },
    {
        "version": "1.35.0",
        "date": "2026-11-08",
        "changes": [
            "Vérification en deux étapes : à chaque connexion, on peut choisir entre le code de l'application "
            "d'authentification et un code reçu par courriel (si un courriel est inscrit au compte).",
        ],
    },
    {
        "version": "1.34.1",
        "date": "2026-11-08",
        "changes": [
            "Vérification en deux étapes : quand un code d'application est refusé, Kubios indique si l'horloge du PC "
            "est décalée (et de combien) ou si le code vient d'être utilisé ; tolérance portée à ±60 s ; les codes ne "
            "sont plus tous refusés après une correction de l'horloge vers l'arrière.",
        ],
    },
    {
        "version": "1.34.0",
        "date": "2026-11-08",
        "changes": [
            "Poste de punch : retour automatique à l'accueil après 4 h d'inactivité (au lieu de 1 min), réglable par "
            "un administrateur dans Atelier → Mécaniciens (1 min à 8 h).",
            "Pages de double authentification, de mot de passe oublié et de réinitialisation : même nouveau design que la "
            "page de connexion (même fond : animation, image ou vidéo).",
        ],
    },
    {
        "version": "1.33.0",
        "date": "2026-11-08",
        "changes": [
            "Poste de punch : le NIP se tape au pavé tactile ou au clavier (chiffres, Retour arrière, Entrée, Échap).",
            "Poste de punch : onglet « À venir » — le mécanicien voit ses bons planifiés des prochains jours "
            "(7 jours, 14 jours ou tous), regroupés par journée, et peut en débuter un pour prendre de l'avance.",
        ],
    },
    {
        "version": "1.32.0",
        "date": "2026-11-08",
        "changes": [
            "Nouvelle identité : Kubios, logiciel de gestion d'entreprise. Nouvelle page de connexion « Gérez tout. "
            "Simplement. » avec une mosaïque animée de mini tableaux de bord en fond ; l'avertissement « Accès "
            "autorisé seulement » est conservé.",
            "Administration → Page de connexion : choix du fond (animation Kubios, image ou vidéo personnalisée) et "
            "téléversement d'une vidéo (MP4 ou WebM, jouée en boucle sans son). La vidéo est incluse dans les "
            "sauvegardes complètes.",
        ],
    },
    {
        "version": "1.31.0",
        "date": "2026-11-08",
        "changes": [
            "Nouvelle page « Administration RH » (administrateurs) : modifier, ordonner, ajouter ou désactiver les "
            "critères d'évaluation, et les textes par défaut des modèles de documents. Les évaluations passées gardent "
            "leurs critères d'origine.",
            "Évaluations : option « S.O. » (ne s'applique pas) sur chaque critère, exclu de la moyenne.",
            "Dossier de l'employé : « Créer un document » — avertissement écrit, lettre de reconnaissance, compte rendu "
            "de rencontre, attestation d'emploi — en PDF avec signatures, classé au dossier et noté à l'historique.",
        ],
    },
    {
        "version": "1.30.0",
        "date": "2026-11-08",
        "changes": [
            "Nouveau module « Gestion RH » (permission dédiée) : dossier de chaque employé (profil, documents, "
            "évaluations, historique, journal des consultations), rappels (certifications à renouveler, fin de "
            "probation, évaluations à faire).",
            "Évaluation du rendement adaptée à un magasin de vente et de location d'outils (9 critères notés de 1 à 5, "
            "points forts, à améliorer, objectifs, commentaires de l'employé), statistiques d'atelier automatiques pour "
            "les mécaniciens, PDF signable classé au dossier à la finalisation.",
            "Atelier → export des fiches d'évaluation : option « Enregistrer aussi au dossier RH ». Les documents RH "
            "sont inclus dans les sauvegardes complètes.",
        ],
    },
    {
        "version": "1.29.2",
        "date": "2026-11-08",
        "changes": [
            "Atelier → Rentabilité : fenêtre « Exporter en PDF… » pour choisir le rapport (financier ou fiche "
            "d'évaluation), la période (prédéfinie, une journée ou du … au …), la personne (tous ou un seul "
            "mécanicien) et les options.",
        ],
    },
    {
        "version": "1.29.1",
        "date": "2026-11-08",
        "changes": [
            "Nouvelle permission « Gestion Atelier — rentabilité et évaluations (données sensibles) » : sans elle, "
            "l'onglet Rentabilité, les fiches d'évaluation et le rapport financier sont cachés et refusés par le serveur.",
            "« Services non reliés » dans son propre onglet pour le responsable d'atelier, avec Ce mois / Mois dernier / "
            "Ce trimestre et « Relire Lightspeed ».",
            "Option : relire chaque nuit (vers 2 h) les ventes des N derniers jours, pour reprendre les « HT: #bon » "
            "ajoutés ou corrigés après coup.",
        ],
    },
    {
        "version": "1.29.0",
        "date": "2026-11-08",
        "changes": [
            "Atelier → Rentabilité : statistiques de performance par mécanicien (bons travaillés et terminés, heures "
            "punchées et facturées, rendement, taux réel, marge, bons dépassant le temps facturé, problèmes signalés, "
            "punchs corrigés), comparées à la moyenne de l'atelier et à la période précédente ; coût du temps non "
            "facturé ; périodes « Cette année » et dates au choix.",
            "Exports PDF : rapport financier de l'atelier, et fiches d'évaluation (une ou toutes, une page par "
            "mécanicien) avec observations automatiques, commentaires et signatures ; options pour inclure ou non le "
            "coût et la marge, et le détail par bon.",
        ],
    },
    {
        "version": "1.28.0",
        "date": "2026-11-08",
        "changes": [
            "Bons de travail : glisser-déposer pour réattribuer un bon à un autre mécanicien ou changer l'ordre.",
            "Nouveau calendrier de planification (une ligne par mécanicien, une colonne par jour) : on glisse les "
            "bons « À planifier » au bon mécanicien et à la bonne journée. Champ « Date de travail » dans le bon. "
            "Sur le poste de punch, « Ma journée » ne montre que les bons d'aujourd'hui (ou en retard) et ceux sans date.",
            "L'atelier en direct : panneau escamotable « Bons du jour » (à faire / en cours, et terminés aujourd'hui) "
            "et compteur dans l'en-tête, sans cacher la vue 3D.",
        ],
    },
    {
        "version": "1.27.0",
        "date": "2026-11-08",
        "changes": [
            "Nouvelle page « L'atelier en direct » (Atelier → bouton « Ouvrir l'atelier en direct », ou /atelier/direct) : "
            "garage 3D avec une baie par mécanicien (élévateur, machine de saison, établi), écran par baie avec le bon, "
            "le client et le chronomètre, gyrophare aux couleurs de l'état ; mise à jour toutes les 5 secondes. "
            "Conçue pour une fenêtre séparée ou une télé (sans le menu, plein écran).",
            "Alertes en direct avec son : problème signalé, message d'un mécanicien, punch oublié ; « OK, vu » marque les "
            "messages comme lus. Jusqu'à 12 mécaniciens (2ᵉ rangée de baies). three.js en local.",
        ],
    },
    {
        "version": "1.26.1",
        "date": "2026-11-07",
        "changes": [
            "Derrière Cloudflare Tunnel, Kubios lit la vraie adresse de l'utilisateur (en-tête CF-Connecting-IP, "
            "cru seulement quand la connexion vient du tunnel sur le même PC) : blocage du code d'accès des "
            "tablettes par appareil, et bonne adresse dans le journal d'audit.",
            "Journal d'audit : adresse de chaque connexion, et tentatives de connexion échouées.",
        ],
    },
    {
        "version": "1.26.0",
        "date": "2026-11-07",
        "changes": [
            "Poste de punch : « Message au responsable » et « Signaler un problème » sur un bon (pièce manquante, "
            "plus long que prévu, client à contacter, outil, autre) ; le mécanicien voit les réponses du responsable.",
            "Responsable : pastille rouge sur « Atelier » et alerte en bas de l'écran, partout dans Kubios ; nouvel "
            "onglet Atelier → Messages pour répondre et marquer les problèmes résolus ; courriel facultatif quand un "
            "problème est signalé.",
        ],
    },
    {
        "version": "1.25.0",
        "date": "2026-11-07",
        "changes": [
            "Bons de travail : priorité en couleur (Normal, Dans la journée, Urgent), notes du responsable pour "
            "le mécanicien, ordre de travail par mécanicien (flèches) et vue en colonnes par mécanicien.",
            "Poste de punch : « Ma journée » en cartes colorées dans l'ordre du responsable, avec date souhaitée "
            "(aujourd'hui, demain, en retard) ; le détail du bon et les notes s'affichent avant de débuter et "
            "pendant le chronomètre.",
            "Supprimer un bon de travail ou changer son numéro : réservé aux administrateurs (le temps punché, le "
            "facturé et les associations suivent le nouveau numéro).",
        ],
    },
    {
        "version": "1.24.2",
        "date": "2026-11-07",
        "changes": [
            "Atelier → Rentabilité : « Relire Lightspeed » montre l'avancement et rafraîchit la page à la fin ; "
            "la journée en cours n'est plus signalée comme manquante.",
            "Nouvelle liste « Services facturés non reliés » : services de la période sans numéro de bon HubTiger, "
            "ou dont le bon n'a aucun temps punché ; chacun peut être associé à un bon ou ignoré (journal d'audit).",
            "Atelier → Mécaniciens : suppression d'un mécanicien (avec confirmation s'il a des punchs ; "
            "désactiver garde l'historique).",
        ],
    },
    {
        "version": "1.24.1",
        "date": "2026-11-07",
        "changes": [
            "Rapport des ventes → Envois automatiques : boutons « Envoyer maintenant » pour le rapport de la "
            "veille et le comparatif de la semaine passée, aux gestionnaires cochés (mêmes destinataires et même "
            "copie cachée que l'envoi automatique). Les ventes manquantes sont d'abord lues dans Lightspeed ; le "
            "résultat apparaît dans le journal des envois.",
        ],
    },
    {
        "version": "1.24.0",
        "date": "2026-11-07",
        "changes": [
            "Avis de non-responsabilité au bas de tous les rapports internes (écran, PDF, Excel et courriels) : "
            "les montants sont calculés automatiquement et fournis à titre indicatif ; Kubios et Groupe SRB ne "
            "peuvent être tenus responsables d'erreurs ; les montants doivent être validés périodiquement, par "
            "échantillonnage, dans Lightspeed. Les états de compte envoyés aux clients ne sont pas touchés.",
        ],
    },
    {
        "version": "1.23.2",
        "date": "2026-11-07",
        "changes": [
            "Rapport des ventes : comptes GL du modèle préréglés (Ventes 4100, Sans catégorie 4190, Articles "
            "divers 4150, Location 4200, Pièces de rechange 4300, Service 4400, Fond de livraison 4500, Usage "
            "Interne Magasin 4900 ; Visa 1020, Mastercard 1025, Interac 1010, Compte à recevoir 1100, Comptant "
            "1000 ; TPS 2310, TVQ 2315). Le sous-total « Ventes élargies » regroupe Ventes, (Sans catégorie) et "
            "(Articles divers, sans fiche). Tout reste modifiable dans « Comptes GL du rapport ».",
        ],
    },
    {
        "version": "1.23.1",
        "date": "2026-11-07",
        "changes": [
            "Rapport des ventes, répartition par mode de paiement : le vrai mode est retrouvé (Visa, "
            "Mastercard, American Express… à partir du détail de la transaction de carte ; Compte à "
            "recevoir pour les paiements portés au compte d'un client ; Interac, Comptant, Carte-cadeau…). "
            "Chaque mode apparaît dans « Comptes GL du rapport ». Les jours déjà lus sont relus une fois.",
        ],
    },
    {
        "version": "1.23.0",
        "date": "2026-11-07",
        "changes": [
            "Nouvelle permission « Comptes à recevoir (clients, factures) », vérifiée par le serveur sur la page "
            "et toutes ses données. Les utilisateurs existants la reçoivent automatiquement ; un nouvel utilisateur "
            "ne voit plus les comptes à recevoir sans cette permission (menu, accueil, tableau de bord 3D).",
            "Rapport des ventes au format comptable (écran, PDF, Excel, courriel) : 1. ventes par catégorie avec "
            "compte GL et sous-total des « ventes élargies », 2. répartition par mode de paiement, 3. ventilation "
            "des taxes, puis grand total facturé aux clients. Comptes GL réglables par un administrateur.",
            "Les paiements de chaque vente sont maintenant gardés dans Kubios (les jours déjà lus sont relus une "
            "fois au prochain rapport).",
            "Atelier → En direct : rafraîchi toutes les 5 secondes (pause, reprise et fin visibles presque aussitôt).",
        ],
    },
    {
        "version": "1.22.0",
        "date": "2026-11-07",
        "changes": [
            "Atelier : onglet « Bons de travail » pour créer les bons à la main (numéro HubTiger, client, "
            "appareil, travaux, date promise) et les attribuer à un mécanicien ; statut suivi par les punchs "
            "(ouvert, en cours, terminé), réouverture ou annulation par le gestionnaire.",
            "Poste de punch : « Mes bons attribués » en premier, avec le client et l'appareil.",
            "Poste de punch sans le login de Kubios : code d'accès propre au poste ou lien direct qui "
            "autorise la tablette (environ un an) ; « Révoquer les tablettes » coupe l'accès de toutes les "
            "tablettes. Le NIP du mécanicien reste demandé à chaque punch.",
        ],
    },
    {
        "version": "1.21.0",
        "date": "2026-11-07",
        "changes": [
            "Nouvelle section « Gestion Atelier ». Poste de punch (tablette) : le mécanicien choisit "
            "son nom, entre son NIP, tape ou scanne le numéro du bon HubTiger, puis Débuter / Pause / "
            "Reprendre / Terminer. S'il a déjà un bon en cours, Kubios demande quoi faire : terminer "
            "l'ancien, le mettre en pause ou travailler sur les deux.",
            "Page « Atelier » : qui travaille sur quoi en direct, temps par bon, alertes de punchs "
            "restés ouverts, correction et ajout de punchs (journal d'audit), gestion des mécaniciens "
            "(NIP, taux coûtant visible des administrateurs seulement).",
            "Rentabilité (administrateurs) : minutes et montants de service facturés dans Lightspeed "
            "(lignes « Service N mins » marquées « HT: #bon ») comparés au temps punché et au coût "
            "du mécanicien ; rendement, taux horaire réel, marge par bon et par mécanicien ; saisie "
            "manuelle du facturé au besoin.",
            "Les ventes gardées dans Kubios notent maintenant le numéro de bon HubTiger et les minutes "
            "de service de chaque ligne (les jours déjà lus peuvent être relus depuis la page Atelier).",
        ],
    },
    {
        "version": "1.20.1",
        "date": "2026-11-06",
        "changes": [
            "Tableau de bord 3D sans Internet : three.js est téléchargé une seule fois par Kubios "
            "(version fixée et vérifiée), gardé dans app\\static\\vendor et servi en local. "
            "État et bouton de téléchargement dans Administration.",
            "Maquette embellie et moins blanche : socle de gazon sur terre et roche, routes en "
            "asphalte, maisons pastel avec fleurs et buissons, étang avec reflets et ondulations, "
            "stationnement, lampadaires allumés la nuit, nuages qui passent, fond bleu ciel.",
        ],
    },
    {
        "version": "1.20.0",
        "date": "2026-11-06",
        "changes": [
            "Nouveau module « Tableau de bord 3D » (menu principal, permission dédiée) : "
            "maquette isométrique de l'entreprise en three.js, alimentée par les données de "
            "Kubios. Magasin = ventes de la période (mois en cours ou mois dernier), bâtiment "
            "mauve = taxes (TPS, TVQ, TVH), palettes = dernier instantané de l'inventaire, tour "
            "verte = comptes de crédit, maisons = 10 plus gros soldes à recevoir (toit selon le "
            "retard, taille selon le solde).",
            "Survol, clic avec zoom et panneau de détails, vues, étiquettes, jour/nuit et "
            "rotation. Chaque partie respecte les accès de l'utilisateur. Nécessite Internet "
            "(three.js est chargé en ligne).",
        ],
    },
    {
        "version": "1.19.1",
        "date": "2026-11-02",
        "changes": [
            "Valeur de l'inventaire : bouton « Prendre et envoyer maintenant », qui lit l'inventaire "
            "dans Lightspeed et envoie aussitôt le PDF par courriel aux personnes choisies "
            "(destinataires de la planification proposés, modifiables).",
        ],
    },
    {
        "version": "1.19.0",
        "date": "2026-11-01",
        "changes": [
            "Nouveau rapport « Valeur de l'inventaire » (menu Rapports, permission dédiée) : "
            "instantané lu dans Lightspeed (quantités en main × coût moyen ou coût par défaut), "
            "valeur au prix de détail, articles et unités en stock, détail par catégorie ; "
            "quantités négatives signalées à part.",
            "Historique des instantanés gardé dans Kubios, avec graphique de l'évolution et "
            "variation d'un instantané à l'autre ; PDF et envoi par courriel de n'importe quel mois.",
            "Planification mensuelle (jour du mois ou dernier jour, à l'heure choisie) avec envoi "
            "automatique du PDF aux personnes choisies.",
        ],
    },
    {
        "version": "1.18.0",
        "date": "2026-11-01",
        "changes": [
            "Nouvelle interface : menu latéral permanent sur toutes les pages (Clients et "
            "comptes, Rapports, Gestion, Système), selon les accès de chaque utilisateur, avec "
            "son nom complet et le bouton de déconnexion.",
            "Nouvel accueil : bandeau illustré « Bord de mer » qui suit le moment de la journée "
            "(matin, après-midi, soir), salutation selon l'heure (Bon matin, Bon après-midi, "
            "Bonsoir), recherche rapide d'un client, raccourcis (ajouter une facture, vérifier les "
            "factures Lightspeed, envoyer les états de compte, taxes du mois dernier), section "
            "« À surveiller » (factures en retard, sauvegarde de la nuit, licence) et ventes des "
            "7 derniers jours.",
            "Utilisateurs : nouveau champ « Nom complet », à la création et dans « Profil et "
            "sécurité ».",
        ],
    },
    {
        "version": "1.17.6",
        "date": "2026-10-31",
        "changes": [
            "Rapport des taxes : nouvelle section « Rapport des frais » à la fin (à l'écran et "
            "dans le PDF), pour les mêmes dates : Total des frais d'articles (consigne, écofrais, "
            "taxes environnementales…), comme le « Total des frais » du rapport « Lignes de "
            "vente → Frais » de Lightspeed, avec le détail par frais.",
            "Diagnostic : à chaque lecture des ventes, Kubios enregistre quelques lignes brutes de "
            "frais dans « diagnostic_frais_lightspeed.json » (C:\\DBouxpCR), pour valider la "
            "détection des frais au besoin.",
            "Les jours lus avant cette version sont relus une fois dans Lightspeed lors du "
            "prochain rapport des taxes.",
        ],
    },
    {
        "version": "1.17.5",
        "date": "2026-10-31",
        "changes": [
            "Rapport des taxes, mêmes montants que Lightspeed au cent près : les taxes sont "
            "arrondies par vente (comme Lightspeed) plutôt que ligne par ligne.",
            "Les taux propres à chaque classe d'article sont pris en compte (ex. un article "
            "« Shopify 13 » taxé à 13 % dans une vente au Québec), pour une ventilation juste.",
            "Nouveau tableau « Par classe de taxe », présenté comme le rapport « Taxe de vente » "
            "de Lightspeed (Item, Shopify 13, No Class…) : sous-total, réductions, taxé, non "
            "taxé, TPS, TVQ, total des taxes et total. Sommaire avec TPS et TVQ séparées.",
            "Ventilation par taux avec les noms officiels (TPS, TVH, TVQ, TVP) ; « TVQ » au lieu "
            "de « Taxe 2 » quand le nom est vide ; lignes à 0 $ masquées.",
            "Les jours lus avant cette version sont relus une fois dans Lightspeed lors du "
            "prochain rapport des taxes.",
        ],
    },
    {
        "version": "1.17.4",
        "date": "2026-10-31",
        "changes": [
            "Licence : quand il reste 15 jours ou moins avant l'expiration, une fenêtre s'affiche "
            "à chaque connexion pour aviser de communiquer avec le fournisseur afin de renouveler "
            "la licence ; elle se ferme avec « J'ai compris » (en rouge à 3 jours ou moins). "
            "Les licences à vie ne sont pas concernées.",
        ],
    },
    {
        "version": "1.17.3",
        "date": "2026-10-31",
        "changes": [
            "Rapport des taxes : le nom des catégories de taxes de Lightspeed est lu aussi avec "
            "chaque vente et dans tous les champs possibles ; à défaut, la catégorie est décrite "
            "par ses taxes (ex. « TPS 5 % + TVQ 9,975 % » ou « Aucune taxe ») au lieu d'un numéro. "
            "Utiliser « Relire Lightspeed et régénérer » pour mettre à jour les noms d'une période.",
        ],
    },
    {
        "version": "1.17.2",
        "date": "2026-10-31",
        "changes": [
            "Rapport des taxes : bouton « Relire Lightspeed et régénérer », qui relit toutes "
            "les ventes de la période dans Lightspeed (ventes modifiées, annulées ou retournées "
            "après coup) avant de refaire le rapport. Le rapport indique aussi quand les ventes "
            "ont été lues dans Lightspeed pour la dernière fois.",
        ],
    },
    {
        "version": "1.17.1",
        "date": "2026-10-31",
        "changes": [
            "Republication de la 1.17.0 combinée avec la 1.16.2 : inclut la limite "
            "d'utilisateurs actifs et la date d'expiration des licences, en plus du Rapport "
            "des ventes et du Rapport des taxes. Remplace le premier paquet 1.17.0, qui ne "
            "contenait pas les changements de la 1.16.2.",
        ],
    },
    {
        "version": "1.17.0",
        "date": "2026-10-30",
        "changes": [
            "La tuile « Rapports personnalisés » s'appelle maintenant « Rapport des ventes ».",
            "Nouvelle tuile « Rapport des taxes » (permission dédiée) : pour les dates choisies, "
            "ventilation de chaque taxe par taux (ex. TPS 5 %, TVQ 9,975 %) avec ventes taxables "
            "et taxe perçue, ventes non taxables, totaux avant et après taxes, et détail par "
            "catégorie de taxes Lightspeed. Affichage à l'écran et téléchargement en PDF.",
            "Les montants de taxes de chaque vente sont maintenant gardés dans Kubios ; les "
            "jours récupérés avant cette version sont relus dans Lightspeed la première fois "
            "qu'un rapport des taxes les couvre.",
        ],
    },
    {
        "version": "1.16.2",
        "date": "2026-10-30",
        "changes": [
            "Licence : prise en charge des licences avec une date d'expiration précise et "
            "d'une limite d'utilisateurs actifs (ex. 5 utilisateurs, ou illimité). Une fois "
            "la limite atteinte, la création ou la réactivation d'un compte est refusée. "
            "La page Licence affiche la limite et le nombre d'utilisateurs actifs. Les "
            "licences déjà émises restent valides, avec utilisateurs illimités.",
        ],
    },
    {
        "version": "1.16.1",
        "date": "2026-10-30",
        "changes": [
            "Sauvegardes : avis par courriel après chaque sauvegarde automatique (réussie ou "
            "en échec) ou seulement en cas d'échec, à une ou plusieurs adresses, avec bouton "
            "« Envoyer un courriel de test ». Le courriel d'échec indique la raison et quoi vérifier.",
        ],
    },
    {
        "version": "1.16.0",
        "date": "2026-10-30",
        "changes": [
            "Nouvelle option « Sauvegardes » (accueil, administrateurs) : sauvegarde complète "
            "de toutes les données et de la configuration (base de données, classeur Excel, "
            "logo et image de fond), automatiquement une fois par jour à l'heure choisie, "
            "conservée 30 jours (7 ou 14 au choix), dans le dossier choisi (disque externe ou "
            "réseau recommandé).",
            "Boutons « Faire une sauvegarde maintenant », « Télécharger » et « Restaurer » ; "
            "restauration possible aussi à partir d'un fichier. Avant toute restauration, "
            "l'état actuel est sauvegardé ; la connexion Lightspeed actuelle est conservée.",
        ],
    },
    {
        "version": "1.15.1",
        "date": "2026-10-30",
        "changes": [
            "« Messages aux utilisateurs » devient une option à part (tuile sur l'accueil, "
            "section Administration) au lieu d'une section de la page Administration.",
        ],
    },
    {
        "version": "1.15.0",
        "date": "2026-10-30",
        "changes": [
            "Nouvelle option « Messages aux utilisateurs » (accueil) : publier un message en bandeau "
            "(rouge, jaune ou bleu) affiché en haut de toutes les pages pour les utilisateurs "
            "connectés, pendant une période choisie (7 à 90 jours, date précise ou sans fin), "
            "avec aperçu. Désactiver, réactiver, modifier ou supprimer en tout temps ; le "
            "bandeau disparaît seul à la date de fin.",
        ],
    },
    {
        "version": "1.14.1",
        "date": "2026-10-30",
        "changes": [
            "La gestion du courriel et de la double authentification passe dans la page "
            "Utilisateurs (bouton « Courriel et 2FA » sur chaque compte, colonnes Courriel "
            "et 2FA) ; elle est retirée de la page Administration.",
            "Création d'un utilisateur : champ Courriel et case « 2FA obligatoire ».",
        ],
    },
    {
        "version": "1.14.0",
        "date": "2026-10-28",
        "changes": [
            "Mot de passe oublié : lien « Mot de passe oublié ? » sur la page de connexion. "
            "Un lien de réinitialisation est envoyé au courriel de l'utilisateur (valide "
            "1 heure, une seule fois, 3 demandes par heure au maximum).",
            "Double authentification (2FA), exigée utilisateur par utilisateur par un "
            "administrateur. À sa première connexion, l'utilisateur choisit sa méthode : "
            "application (Google ou Microsoft Authenticator, code QR) ou code de 6 chiffres "
            "envoyé par courriel. Blocage de 15 minutes après 5 codes erronés.",
            "Administration → nouvelle section « Utilisateurs : courriel et double "
            "authentification » : courriel de chaque utilisateur, 2FA obligatoire ou non, "
            "état de la configuration et bouton pour la réinitialiser (téléphone perdu).",
        ],
    },
    {
        "version": "1.13.2",
        "date": "2026-10-24",
        "changes": [
            "Rapports personnalisés : la copie cachée envoyée à l'adresse courriel de "
            "l'entreprise devient optionnelle (case dans Envois automatiques et dans la "
            "fenêtre « Envoyer par courriel ») ; par défaut, les rapports n'envoient plus "
            "de copie. Les états de compte des clients ne changent pas.",
        ],
    },
    {
        "version": "1.13.1",
        "date": "2026-10-24",
        "changes": [
            "Envois automatiques : choix du regroupement (catégories complètes ou catégories "
            "principales) pour le rapport de la veille et pour le comparatif hebdomadaire.",
        ],
    },
    {
        "version": "1.13.0",
        "date": "2026-10-24",
        "changes": [
            "Rapports personnalisés : les ventes de Lightspeed sont maintenant gardées dans "
            "Kubios. Chaque nuit (1 h par défaut), Kubios récupère les ventes de la veille "
            "(et relit les 7 derniers jours pour les retours et annulations). L'historique "
            "peut être récupéré depuis la date choisie (1er janvier 2024 par défaut). Les "
            "rapports se génèrent ensuite instantanément.",
            "Rapport de la veille envoyé automatiquement chaque matin aux gestionnaires choisis, "
            "et bouton « Envoyer par courriel » pour tout rapport généré.",
            "Nouveau rapport « Comparatif hebdomadaire » : une semaine (lundi au dimanche) "
            "comparée à la même semaine l'an dernier (52 semaines plus tôt, mêmes jours), avec "
            "graphique par jour, écarts et variations par catégorie ; envoyé automatiquement "
            "chaque lundi et consultable dans Kubios. Export Excel et PDF.",
            "Onglet « Envois automatiques » (administrateurs) : gestionnaires et types de "
            "rapports reçus, heure de la tâche de nuit, état de l'historique, journal des envois.",
        ],
    },
    {
        "version": "1.12.0",
        "date": "2026-10-13",
        "changes": [
            "Nouveau module « Rapports personnalisés » (accueil), avec une permission "
            "dédiée pour les utilisateurs non administrateurs.",
            "Premier rapport : « Ventes par catégorie d'articles », lu directement dans "
            "Lightspeed (API) pour la période choisie (aujourd'hui, hier, semaine, mois, "
            "mois dernier, année ou dates précises), par magasin au besoin, en catégories "
            "complètes ou principales : quantité, sous-total, rabais, total, coût, profit, "
            "marge et part des ventes, avec total général.",
            "Exportation du rapport en Excel et en PDF (logo de l'entreprise).",
        ],
    },
    {
        "version": "1.11.3",
        "date": "2026-10-12",
        "changes": [
            "Comptes à recevoir : bouton « Fusionner… » dans la fiche client. On choisit "
            "l'autre client et le nom à garder : les factures, les liens Lightspeed et les "
            "paiements traités passent au client gardé, ses coordonnées vides sont "
            "complétées, l'autre client est retiré (son onglet Excel est supprimé à la "
            "prochaine synchronisation). Une sauvegarde est prise avant.",
            "Noms reconnus : le nom d'un client fusionné (ou l'ancien nom d'un client "
            "renommé) reste associé au bon client ; les prochaines vérifications Lightspeed "
            "le retrouvent automatiquement.",
            "Factures Lightspeed : action « Relier seulement » pour relier un client "
            "Lightspeed à un client Kubios existant sans inscrire de facture ; un paiement "
            "d'un client pas encore reconnu peut être relié et appliqué au client choisi.",
            "Fiche client : liste des liens Lightspeed et des noms reconnus, avec bouton "
            "pour en retirer un.",
        ],
    },
    {
        "version": "1.11.2",
        "date": "2026-10-12",
        "changes": [
            "Factures Lightspeed : les paiements reçus sur compte dans Lightspeed peuvent "
            "maintenant être appliqués aux factures dans Kubios. Kubios propose la "
            "répartition (la facture dont le solde est exactement le montant payé, sinon "
            "les plus anciennes d'abord, avec paiement partiel au besoin) ; on peut choisir "
            "la facture par laquelle commencer, ou « Déjà fait » si le paiement avait été "
            "marqué à la main. Un paiement traité n'est plus jamais reproposé.",
            "Vérification des soldes : pour chaque client relié à Lightspeed, le solde dans "
            "Kubios est comparé au solde de son compte de crédit ; les écarts sont listés "
            "(facture ou paiement manquant d'un côté).",
            "La sauvegarde prise avant l'inscription couvre aussi les paiements appliqués.",
        ],
    },
    {
        "version": "1.11.1",
        "date": "2026-10-12",
        "changes": [
            "Nouvelle page de connexion : image de fond (plan technique aux couleurs de "
            "Kubios par défaut), présentation du logiciel à gauche et formulaire à droite ; "
            "s'adapte aux petits écrans.",
            "Bas de page « Propulsé par Groupe SRB — © année » : l'année se met à jour "
            "automatiquement.",
            "Administration : téléverser sa propre photo comme image de fond de la page "
            "de connexion (JPG, PNG ou WEBP, 8 Mo max.), ou revenir à l'image par défaut.",
        ],
    },
    {
        "version": "1.11.0",
        "date": "2026-10-11",
        "changes": [
            "Comptes à recevoir : nouvel onglet « Factures Lightspeed ». Le bouton "
            "« Vérifier les factures » lit dans Lightspeed les ventes portées au compte "
            "de crédit depuis une date et montre celles qui ne sont pas encore dans "
            "Kubios (comparaison par numéro de vente). Tu choisis pour chacune : "
            "inscrire, plus tard ou ignorer, puis « Inscrire dans Kubios ».",
            "Montant = partie de la vente portée au compte ; un retour porté au compte "
            "devient une note de crédit ; échéance = dernier jour du mois suivant. Les "
            "ventes de clients absents de Kubios sont dans « Autres clients » : on peut "
            "les relier à un client existant ou créer le client (coordonnées lues dans "
            "Lightspeed).",
            "Les paiements reçus sur compte dans Lightspeed sont affichés comme rappel "
            "(Lightspeed ne les relie pas à une facture précise) : ils se marquent "
            "toujours dans Kubios.",
            "Une sauvegarde des comptes à recevoir (clients et factures) est prise avant "
            "chaque inscription ; un administrateur peut tout remettre comme avant "
            "(section « Sauvegardes avant inscription »).",
        ],
    },
    {
        "version": "1.10.3",
        "date": "2026-10-11",
        "changes": [
            "Synchronisation Lightspeed automatique : choix de la fréquence dans "
            "Administration → Lightspeed — désactivée, chaque jour, ou le dernier jour "
            "de chaque mois (à partir de l'heure choisie, 23 h proposé).",
            "La synchronisation de fin de mois garde toujours un rapport PDF « Fin de "
            "mois » dans « Rapports PDF par importation », même si aucun solde n'a "
            "changé, pour avoir le portrait de chaque fin de mois.",
        ],
    },
    {
        "version": "1.10.2",
        "date": "2026-10-11",
        "changes": [
            "Connexion Lightspeed : Lightspeed exige une adresse de retour en https://. "
            "L'adresse proposée est maintenant https://localhost/kubios-lightspeed (la "
            "même pour le test et la prod). Après l'autorisation, le navigateur affiche "
            "une page d'erreur : il suffit de copier l'adresse de la barre d'adresse et "
            "de la coller dans Administration → Lightspeed pour terminer la connexion, "
            "à partir de n'importe quel poste.",
        ],
    },
    {
        "version": "1.10.1",
        "date": "2026-10-11",
        "changes": [
            "Comptes de crédit : une sauvegarde est prise automatiquement avant chaque "
            "importation (réinitialisation de la liste, import des mouvements, "
            "synchronisation Lightspeed manuelle ou automatique). Si la sauvegarde "
            "échoue, l'importation est annulée.",
            "Nouvelle section « Sauvegardes avant importation » : un administrateur "
            "peut remettre les comptes de crédit et leur historique exactement comme "
            "avant une mauvaise importation. L'état actuel est sauvegardé juste avant, "
            "donc une restauration peut elle aussi être annulée. Les comptes à recevoir "
            "ne sont pas touchés.",
            "Une synchronisation sans aucun changement ne garde pas de sauvegarde ; "
            "les 60 plus récentes sont conservées (dossier Backups_comptes_credit).",
        ],
    },
    {
        "version": "1.10.0",
        "date": "2026-10-11",
        "changes": [
            "Comptes de crédit : synchronisation directe avec Lightspeed R-Series "
            "(API). Plus besoin d'exporter le fichier « credit_account_listings » : "
            "le bouton « Synchroniser maintenant » lit les comptes de crédit dans "
            "Lightspeed et met à jour la limite, le montant dû et le dépôt de chaque "
            "client (un changement de solde est inscrit dans l'historique).",
            "Chaque compte Kubios est maintenant relié à son compte Lightspeed par son "
            "numéro : les clients portant le même nom ne se mélangent plus. À la "
            "première synchronisation, l'association se fait par nom ; les homonymes "
            "sont listés dans « Comptes Lightspeed à associer » pour être reliés à la main.",
            "Administration → Lightspeed : Client ID / secret de l'application "
            "Lightspeed, bouton « Connecter à Lightspeed », test de connexion, sens du "
            "solde (détecté automatiquement à la première synchronisation) et "
            "synchronisation automatique quotidienne à l'heure choisie.",
            "Les cartes-cadeaux et les comptes archivés de Lightspeed sont ignorés ; "
            "les comptes « Ne pas synchroniser » sont reliés mais jamais modifiés.",
        ],
    },
    {
        "version": "1.9.3",
        "date": "2026-10-08",
        "changes": [
            "Comptes à recevoir : une facture à montant négatif (note de crédit) "
            "n'est plus affichée « Payée ». Elle porte maintenant un badge bleu "
            "« Crédit », avec son montant et son solde en bleu. Le bouton devient "
            "« Crédit appliqué » (le crédit a été utilisé ou remboursé — son solde "
            "passe à 0, badge « Crédit appliqué ») et peut être annulé.",
            "Dans la liste des clients, un client dont le solde total est négatif "
            "affiche un badge bleu « Crédit » au lieu de « À jour ».",
        ],
    },
    {
        "version": "1.9.2",
        "date": "2026-10-08",
        "changes": [
            "Comptes de crédit : la fiche d'un client permet maintenant de "
            "modifier le compte (nom, limite de crédit, montant dû, dépôt, "
            "notes) et de le supprimer (administrateurs seulement, avec son "
            "historique).",
            "Chaque mouvement de l'historique peut être modifié (date, type, "
            "vente, montant) ou supprimé s'il est en erreur. Le solde du client "
            "est ajusté automatiquement de la différence (une confirmation "
            "indique le montant).",
            "Nouvelle case « Ne pas synchroniser avec l'importation » sur chaque "
            "compte : l'import des mouvements (instantané mensuel ou journal de "
            "transactions) ne touche plus à ce compte et garde tes valeurs. La "
            "réinitialisation complète de la liste, elle, remplace quand même "
            "tout. Un badge « Non synchronisé » s'affiche dans la liste.",
            "Toutes ces actions sont inscrites au journal d'audit.",
        ],
    },
    {
        "version": "1.9.1",
        "date": "2026-10-08",
        "changes": [
            "Comptes de crédit : « Importer / réinitialiser la liste des "
            "clients » accepte maintenant aussi l'export Lightspeed "
            "« credit_account_listings » (.csv en anglais, colonnes First Name, "
            "Last Name, Credit Limit, Debt), en plus du format en français "
            "(Prénom / Entreprise, Nom, Limite de crédit, Montant dû, Dépôt). "
            "Le montant dû vient de la colonne « Debt » ; un « Debt » négatif "
            "(crédit en faveur du client) est importé comme dépôt, avec un "
            "montant dû à 0. L'import mensuel des mouvements applique la même "
            "règle : les clients en crédit ne sont plus comptés deux fois "
            "(solde négatif + dépôt).",
            "Correction : un montant écrit à la française dans un fichier "
            "importé (ex. « 1 234,56 $ ») était lu comme 123 456 $ ; la "
            "virgule décimale est maintenant reconnue.",
        ],
    },
    {
        "version": "1.9.0",
        "date": "2026-10-08",
        "changes": [
            "Comptes à recevoir : nouveau bouton « Modifier le client » dans la "
            "fiche d'un client. Il permet de changer le nom, le courriel, le "
            "téléphone et l'adresse d'un client existant. Lors d'un changement "
            "de nom, toutes ses factures suivent automatiquement et son onglet "
            "dans le fichier Excel est renommé à la prochaine synchronisation "
            "(aucun onglet en double). Chaque modification est inscrite au "
            "journal d'audit avec l'ancienne et la nouvelle valeur.",
            "La fiche d'un client affiche maintenant son courriel et son "
            "téléphone sous son nom.",
        ],
    },
    {
        "version": "1.8.9",
        "date": "2026-10-06",
        "changes": [
            "Licence : l'expiration des licences de 30 jours et d'un an ne "
            "dépend plus seulement de la date de l'ordinateur. L'app vérifie "
            "la date réelle sur Internet (au démarrage puis toutes les 6 "
            "heures) et mémorise la date la plus récente qu'elle a vue. Si la "
            "date de l'ordinateur est reculée de plus d'un jour, l'app se "
            "bloque avec un message demandant de corriger la date, et "
            "l'événement est inscrit au journal d'audit. Sans Internet, la "
            "date mémorisée sert de référence. Les licences à vie ne sont "
            "pas touchées.",
        ],
    },
    {
        "version": "1.8.8",
        "date": "2026-09-30",
        "changes": [
            "Nouveau module « Administration » (réservé aux administrateurs, "
            "accessible depuis la page d'accueil) permettant de personnaliser "
            "le logiciel : nom et courriel de l'entreprise, logo affiché sur "
            "les états de compte et rapports PDF (avec retour possible au "
            "logo par défaut), ainsi que les messages de conclusion affichés "
            "au bas des PDF et dans les courriels.",
        ],
    },
    {
        "version": "1.8.7",
        "date": "2026-09-30",
        "changes": [
            "Ajout d'une page d'accueil (menu) après la connexion : elle "
            "propose des tuiles vers chaque volet accessible (Comptes à "
            "recevoir, Comptes de crédit, Utilisateurs, Audit, Paramètres "
            "d'envoi, Mises à jour, Licence) au lieu d'atterrir directement "
            "sur les comptes à recevoir. Les liens « Accueil » sur les "
            "autres pages ramènent maintenant à ce menu.",
        ],
    },
    {
        "version": "1.8.6",
        "date": "2026-09-30",
        "changes": [
            "Ajout d'un avertissement légal (« Accès autorisé seulement ») "
            "sur la page de connexion, rappelant que le système est réservé "
            "aux personnes autorisées et que les activités peuvent être "
            "surveillées et auditées.",
        ],
    },
    {
        "version": "1.8.5",
        "date": "2026-09-30",
        "changes": [
            "Le style et les couleurs de la nouvelle page de connexion "
            "(Kubios) s'appliquent maintenant à tout le logiciel : en-tête "
            "en dégradé bleu avec le logo sur chaque page, boutons "
            "principaux assortis — sur l'écran principal, Utilisateurs, "
            "Audit, Paramètres d'envoi, Mises à jour, Licence et Comptes de "
            "crédit.",
        ],
    },
    {
        "version": "1.8.4",
        "date": "2026-09-30",
        "changes": [
            "Comptes de crédit : « Importer / réinitialiser la liste des "
            "clients » (qui remplace toute la liste et efface l'historique "
            "des mouvements) est maintenant réservé aux administrateurs — "
            "les utilisateurs avec seulement l'accès « Comptes de crédit » "
            "peuvent encore importer les mouvements/instantanés mensuels et "
            "consulter les rapports, mais plus réinitialiser la liste.",
        ],
    },
    {
        "version": "1.8.3",
        "date": "2026-09-30",
        "changes": [
            "Nouvelle page de connexion : le logiciel s'appelle maintenant "
            "« Kubios » (nouveau logo et design revus) — ce nom n'apparaît "
            "qu'à l'écran de connexion et n'affecte pas les états de compte, "
            "courriels ou documents envoyés aux clients, qui continuent "
            "d'afficher le nom de l'entreprise comme avant.",
        ],
    },
    {
        "version": "1.8.2",
        "date": "2026-09-30",
        "changes": [
            "Ajout d'un filtre « Cacher les clients à 0$ » sur la liste des "
            "comptes de crédit (limite, solde et dépôt tous à zéro).",
            "Ajout de l'export PDF des comptes de crédit (logo en haut à "
            "droite, comme les autres rapports) — soit la liste actuelle, "
            "soit le rapport exact d'une importation passée.",
            "Chaque importation (liste initiale, instantané mensuel ou "
            "journal de transactions) garde maintenant sa propre photo des "
            "soldes, téléchargeable en PDF n'importe quand — même s'il y a "
            "plusieurs importations dans le même mois, chacune garde son "
            "propre rapport.",
            "Ajout d'une option pour exclure les clients à 0$ (limite, solde "
            "et dépôt) des PDF générés, autant pour la liste actuelle que "
            "pour le rapport d'une importation passée.",
        ],
    },
    {
        "version": "1.8.1",
        "date": "2026-09-29",
        "changes": [
            "Correction de l'import mensuel des comptes de crédit : le fichier "
            "Lightspeed réellement reçu chaque mois (« credit_account_listings... "
            ".csv ») est un instantané des soldes actuels (First Name, Last Name, "
            "Credit Limit, Debt), pas un journal de transactions — il causait "
            "l'erreur « Colonnes Customer et Amount introuvables ». Le format est "
            "maintenant détecté automatiquement : instantané mensuel (met à jour "
            "les soldes) ou journal de transactions (ajoute des mouvements), les "
            "deux dans le même bouton « Importer les mouvements du mois ».",
            "Les montants avec le symbole $ (ex. « $150000.00 », « $-219.30 ») "
            "sont maintenant lus correctement dans tous les imports de comptes de "
            "crédit.",
        ],
    },
    {
        "version": "1.8.0",
        "date": "2026-09-29",
        "changes": [
            "Ajout d'un nouveau volet « Comptes de crédit » (Lightspeed), "
            "distinct des comptes à recevoir : liste des clients avec limite "
            "de crédit, solde dû et dépôt, avec alerte si un client dépasse "
            "sa limite.",
            "Import initial de la liste des comptes de crédit depuis un "
            "fichier Excel ou CSV.",
            "Import mensuel des mouvements (transactions) exportés de "
            "Lightspeed en CSV — met à jour les soldes automatiquement, sans "
            "risque de doublons si le même fichier est réimporté par erreur.",
        ],
    },
    {
        "version": "1.7.0",
        "date": "2026-09-29",
        "changes": [
            "Ajout de la date de chaque paiement (en plus du montant) — le "
            "rapport d'âge des comptes à recevoir pour un mois passé (ex. au "
            "31-07-2026) ignore maintenant correctement les paiements reçus "
            "après cette date, au lieu de les soustraire par erreur.",
            "Les factures et le tableau des clients affichent maintenant la "
            "date du paiement partiel ou complet déjà reçu.",
        ],
    },
    {
        "version": "1.6.4",
        "date": "2026-09-27",
        "changes": [
            "Installation d'une mise à jour : demande maintenant explicitement "
            "si cet ordinateur redémarre l'application comme service Windows "
            "ou manuellement via start.bat, au lieu de le deviner tout seul — "
            "utile quand plusieurs ordinateurs n'utilisent pas le même mode.",
        ],
    },
    {
        "version": "1.6.3",
        "date": "2026-09-27",
        "changes": [
            "Correctif important : l'installation automatique des mises à jour "
            "ne fonctionnait pas quand l'application tournait comme service "
            "Windows — le service s'arrêtait bien, mais ne redémarrait jamais "
            "tout seul et le code n'était pas remplacé, à cause d'un chemin "
            "Python incorrect utilisé en arrière-plan dans ce mode précis.",
        ],
    },
    {
        "version": "1.6.2",
        "date": "2026-09-27",
        "changes": [
            "Correctif : la vérification des mises à jour pouvait afficher "
            "« Réponse invalide du serveur de mises à jour » si le fichier de "
            "version en ligne contenait un caractère invisible en début de "
            "fichier ; le message d'erreur précise maintenant la cause exacte.",
        ],
    },
    {
        "version": "1.6.1",
        "date": "2026-09-27",
        "changes": [
            "Correctif : le résultat de « Vérifier les mises à jour » (nouvelle "
            "version disponible ou déjà à jour) ne s'affichait pas à l'écran "
            "même si la vérification fonctionnait correctement en arrière-plan.",
        ],
    },
    {
        "version": "1.6.0",
        "date": "2026-09-27",
        "changes": [
            "Installation automatique des mises à jour : le bouton « Installer "
            "maintenant » télécharge et applique lui-même une mise à jour "
            "détectée, puis redémarre l'application (les données du client — "
            "base de données, fichier Excel, PDF — ne sont jamais touchées).",
        ],
    },
    {
        "version": "1.5.0",
        "date": "2026-09-27",
        "changes": [
            "Ajout d'accès particuliers par utilisateur (Rapports, Audit, Licence, "
            "Paramètres d'envoi, Mises à jour) — gérable depuis la page Utilisateurs, "
            "en plus du statut administrateur.",
            "Ajout de la vérification en ligne des mises à jour (bouton « Vérifier "
            "les mises à jour »).",
        ],
    },
    {
        "version": "1.4.0",
        "date": "2026-09-27",
        "changes": [
            "Ajout d'une page « Mises à jour » (menu admin) qui affiche la version "
            "installée et l'historique complet des changements.",
        ],
    },
    {
        "version": "1.3.0",
        "date": "2026-09-26",
        "changes": [
            "Port de l'application changé de 5050 à 5080 (configurable via APP_PORT).",
            "Remplacement du serveur de développement Flask par un serveur de "
            "production (Waitress) — plus stable pour un usage continu.",
        ],
    },
    {
        "version": "1.2.0",
        "date": "2026-09-26",
        "changes": [
            "Ajout du démarrage automatique avec Windows (service Windows en "
            "arrière-plan, sans fenêtre visible).",
            "Préparation des outils pour produire un installateur Windows "
            "autonome (Setup.exe).",
        ],
    },
    {
        "version": "1.1.0",
        "date": "2026-09-26",
        "changes": [
            "Ajout du système de licence (activation par code — 30 jours, 1 an "
            "ou à vie — avec redemande automatique à l'expiration).",
            "Ajout du rapport mensuel d'envoi de courriels.",
            "Copie automatique (CCI) de chaque courriel envoyé vers "
            f"{COMPANY_EMAIL_DEFAULT}.",
            "Possibilité de modifier le sujet et le message avant l'envoi d'un "
            "état de compte.",
        ],
    },
    {
        "version": "1.0.0",
        "date": None,
        "changes": [
            "Version de référence : gestion des comptes à recevoir, paiements "
            "partiels, envoi des états de compte par Outlook ou par serveur "
            "SMTP, journal d'audit, gestion des utilisateurs et permissions.",
        ],
    },
]

# URL publique (dépôt GitHub géré par Claude) où est déposé, à chaque mise à
# jour livrée, un petit fichier version.json contenant le numéro de version
# le plus récent et son changelog. Ne contient aucune donnée d'entreprise.
UPDATE_CHECK_URL = "https://raw.githubusercontent.com/woofer737/drouxpcr/main/version.json"


def _version_tuple(v):
    """Convertit "1.4.0" en (1, 4, 0) pour pouvoir comparer deux versions."""
    return tuple(int(part) for part in v.strip().split('.'))


# ------------------------------------------------------------
# Installation automatique des mises à jour
# ------------------------------------------------------------
# APP_DIR = C:\DBouxpCR\app (contient app.py, templates, static — remplacé
# par une mise à jour). BASE_DIR = C:\DBouxpCR (contient aussi les données
# du client : data.db, le fichier Excel, les PDF — jamais touchées).
APP_DIR = Path(__file__).resolve().parent
UPDATE_STAGING_DIR = BASE_DIR / "_update_staging"
UPDATE_ZIP_PATH = BASE_DIR / "_update_download.zip"
UPDATE_LOG_PATH = BASE_DIR / "_update_log.txt"
UPDATE_RUNNER_PATH = BASE_DIR / "_run_update.py"


def _real_python_exe():
    """Chemin fiable vers python.exe.

    Quand ce code tourne DANS le service Windows, sys.executable pointe vers
    pythonservice.exe (l'hôte du service, pas un vrai interpréteur Python) —
    lancer un sous-processus avec ce chemin échoue silencieusement. sys.exec_prefix
    reste correct dans les deux cas (service ou lancement normal), donc on
    reconstruit le chemin de python.exe à partir de là, avec repli sur
    sys.executable si jamais il n'existe pas à cet endroit.
    """
    candidate = os.path.join(sys.exec_prefix, "python.exe" if os.name == "nt" else "python3")
    if os.path.exists(candidate):
        return candidate
    return sys.executable

# Script exécuté dans un processus séparé, après que ce processus-ci se soit
# terminé (pour ne jamais copier par-dessus des fichiers encore ouverts). Il
# copie uniquement le CODE (jamais data.db, les .xlsx, service.log,
# __pycache__, .venv), réinstalle les dépendances, puis relance l'app —
# comme service Windows si celui-ci est installé, sinon en rouvrant
# start.bat dans une nouvelle fenêtre.
_UPDATE_RUNNER_SCRIPT = r'''
import os, sys, shutil, subprocess, time

STAGED = r"{staged}"
TARGET = r"{target}"
BASE = r"{base}"
LOG_PATH = os.path.join(BASE, "_update_log.txt")

def log(msg):
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(time.strftime("%Y-%m-%d %H:%M:%S") + " - " + msg + "\n")

def real_python_exe():
    # Ce runner peut avoir ete lance via pythonservice.exe (sys.executable
    # errone dans ce cas) : on reconstruit le vrai python.exe a partir de
    # sys.exec_prefix, qui lui reste correct.
    candidate = os.path.join(sys.exec_prefix, "python.exe" if os.name == "nt" else "python3")
    if os.path.exists(candidate):
        return candidate
    return sys.executable

PYTHON_EXE = real_python_exe()
log("Python utilise pour la mise a jour : " + PYTHON_EXE)

EXCLUDE_NAMES = {{"__pycache__", ".venv"}}
EXCLUDE_FILES = {{"data.db", "service.log"}}
EXCLUDE_EXT = (".xlsx", ".db")

def copy_tree(src, dst):
    for name in os.listdir(src):
        if name in EXCLUDE_NAMES:
            continue
        s = os.path.join(src, name)
        d = os.path.join(dst, name)
        if os.path.isdir(s):
            os.makedirs(d, exist_ok=True)
            copy_tree(s, d)
        else:
            if name in EXCLUDE_FILES or name.lower().endswith(EXCLUDE_EXT):
                continue
            shutil.copy2(s, d)

log("=== Debut de la mise a jour ===")
# Laisse le temps au processus precedent de bien se terminer et de liberer
# le port / les fichiers.
time.sleep(4)

try:
    copy_tree(STAGED, TARGET)
    log("Fichiers copies avec succes depuis " + STAGED)
except Exception as e:
    log("ERREUR copie fichiers: " + repr(e))

try:
    req = os.path.join(TARGET, "requirements.txt")
    if os.path.exists(req):
        r = subprocess.run([PYTHON_EXE, "-m", "pip", "install", "-r", req],
                            capture_output=True, text=True, timeout=180)
        log("pip install rc=" + str(r.returncode))
        if r.returncode != 0:
            log("pip stderr: " + r.stdout[-1000:] + r.stderr[-1000:])
except Exception as e:
    log("ERREUR pip install: " + repr(e))

# Redemarre selon le mode choisi explicitement par la personne au moment de
# cliquer "Installer maintenant" (service Windows ou start.bat) — plus fiable
# qu'une detection automatique, puisque le meme code tourne dans les deux
# types d'environnement chez ce client.
RESTART_MODE = "{restart_mode}"
restarted = False
service_py = os.path.join(TARGET, "service.py")

def restart_via_service():
    global restarted
    try:
        check = subprocess.run(["sc", "query", "ComptesARecevoirOE"],
                                capture_output=True, text=True, timeout=15)
        if check.returncode == 0 and "ComptesARecevoirOE" in check.stdout:
            subprocess.run([PYTHON_EXE, service_py, "restart"], timeout=30)
            log("Service Windows redemarre.")
            restarted = True
        else:
            log("Mode service demande, mais aucun service ComptesARecevoirOE trouve sur cette machine.")
    except Exception as e:
        log("ERREUR redemarrage service: " + repr(e))

def restart_via_startbat():
    global restarted
    try:
        start_bat = os.path.join(TARGET, "start.bat")
        if os.path.exists(start_bat):
            subprocess.Popen(["cmd", "/c", "start", "", "start.bat"],
                              cwd=TARGET, creationflags=subprocess.CREATE_NEW_CONSOLE)
            log("start.bat relance dans une nouvelle fenetre.")
            restarted = True
        else:
            log("Mode start.bat demande, mais start.bat introuvable dans " + TARGET)
    except Exception as e:
        log("ERREUR relance start.bat: " + repr(e))

log("Mode de redemarrage demande : " + RESTART_MODE)
if RESTART_MODE == "service":
    restart_via_service()
else:
    restart_via_startbat()

# Filet de securite : si le mode choisi echoue, on essaie quand meme l'autre
# methode plutot que de laisser l'application eteinte.
if not restarted:
    log("Le mode demande a echoue, tentative de l'autre methode en secours.")
    if RESTART_MODE == "service":
        restart_via_startbat()
    else:
        restart_via_service()

log("=== Mise a jour terminee ===")
'''


STATEMENT_PREFIX = "OE-"

INFO_ROWS = {
    'adresse': 3,
    'ville': 4,
    'province': 5,
    'code_postal': 6,
    'courriel': 7,
}
FIRST_INVOICE_ROW = 8
FORMULA_MIN_LAST_ROW = 1000
MODELE_SHEET = "Modèle"
SOMMAIRE_SHEET = "Sommaire"
LOG_SHEET = "LOG_ENVOIS"

INVALID_SHEET_CHARS = r'[:\\/?*\[\]]'

app = Flask(__name__)


AR_PATH_PREFIXES = ('/comptes-a-recevoir', '/api/client', '/api/invoice', '/api/ar-backups', '/api/lightspeed/ar/',
                    '/api/statements/', '/api/sync', '/api/reports/aging', '/api/reports/envois', '/api/reports/monthly')


def ar_allowed():
    return bool(session.get('is_admin')) or 'comptes_recevoir' in (session.get('permissions') or [])


# ---------- 1.43.0 : registre des sessions (utilisateurs en ligne, déconnexion à distance)
_SESS_REVOKED = set()
_SESS_LOADED = {'ok': False}
SESS_ONLINE_SEC = 300           # « en ligne » = activité dans les 5 dernières minutes


def _sess_ua(ua):
    ua = ua or ''
    b = 'Edge' if 'Edg/' in ua else 'Chrome' if 'Chrome/' in ua else 'Firefox' if 'Firefox/' in ua else 'Safari' if 'Safari/' in ua else 'Navigateur'
    o = 'Windows' if 'Windows' in ua else 'Android' if 'Android' in ua else 'iPhone' if 'iPhone' in ua else 'iPad' if 'iPad' in ua else 'Mac' if 'Mac OS' in ua else 'Linux' if 'Linux' in ua else ''
    return f"{b} · {o}" if o else b


def sess_open(kind, user_id, username, display):
    sid = secrets.token_urlsafe(18)
    conn = get_conn()
    try:
        conn.execute("INSERT INTO user_sessions(sid, kind, user_id, username, display, ip, agent, created_at, last_seen) VALUES (?,?,?,?,?,?,?,?,?)",
                     (sid, kind, user_id, username, display, client_ip(), _sess_ua(request.headers.get('User-Agent')), _at_now(), _at_now()))
        conn.commit()
    finally:
        conn.close()
    return sid


def sess_close(sid, by):
    if not sid:
        return
    conn = get_conn()
    try:
        conn.execute("UPDATE user_sessions SET revoked_at=?, revoked_by=? WHERE sid=? AND revoked_at IS NULL", (_at_now(), by, sid)); conn.commit()
    finally:
        conn.close()


@app.before_request
def _session_registry():
    """Coupe une session fermée par un administrateur, et note la dernière activité (au plus une fois par minute)."""
    if request.endpoint in ('static',) or not (session.get('user_id') or session.get('emp_id')):
        return None
    if not _SESS_LOADED['ok']:
        try:
            conn = get_conn()
            try:
                _SESS_REVOKED.update(r[0] for r in conn.execute("SELECT sid FROM user_sessions WHERE revoked_at IS NOT NULL AND revoked_by<>'déconnexion' "
                                                               "AND revoked_at > datetime('now', '-31 days')").fetchall())
            finally:
                conn.close()
            _SESS_LOADED['ok'] = True
        except Exception:
            return None
    for key, kind in (('sid', 'user'), ('emp_sid', 'portail')):
        sid = session.get(key)
        if kind == 'user' and not session.get('user_id'):
            continue
        if kind == 'portail' and not session.get('emp_id'):
            continue
        if sid and sid in _SESS_REVOKED:
            if kind == 'user':
                for k in ('user_id', 'username', 'is_admin', 'permissions', 'full_name', 'sid', 'sid_ts'):
                    session.pop(k, None)
                session['kicked'] = 1
            else:
                for k in ('emp_id', 'emp_sid', 'emp_sid_ts'):
                    session.pop(k, None)
                session['emp_kicked'] = 1
            continue
        try:
            if not sid:                                   # session ouverte avant la mise à jour : on l'inscrit
                if kind == 'user':
                    session['sid'] = sess_open('user', session['user_id'], session.get('username'), session.get('full_name') or session.get('username'))
                else:
                    session['emp_sid'] = sess_open('portail', session['emp_id'], None, None)
                session[key + '_ts'] = time.time()
            elif time.time() - (session.get(key + '_ts') or 0) > 60:
                conn = get_conn()
                try:
                    conn.execute("UPDATE user_sessions SET last_seen=?, ip=? WHERE sid=?", (_at_now(), client_ip(), sid)); conn.commit()
                finally:
                    conn.close()
                session[key + '_ts'] = time.time()
        except Exception:
            traceback.print_exc()
    return None


@app.before_request
def _ar_permission():
    """Comptes à recevoir réservés aux utilisateurs qui en ont la permission (1.23.0)."""
    if not session.get('user_id') or not request.path.startswith(AR_PATH_PREFIXES) or ar_allowed():
        return None
    if request.path.startswith('/api/'):
        return jsonify({'error': 'forbidden', 'message': "Accès réservé : permission « Comptes à recevoir » requise."}), 403
    return "Accès refusé — permission « Comptes à recevoir » requise.", 403


@app.before_request
def _require_login():
    resp = license_required_check()
    if resp is not None:
        return resp
    resp = login_required_check()
    if resp is not None:
        return resp


# ============================================================
# Base SQLite (source rapide de vérité)
# ============================================================
_db_lock = threading.Lock()


def get_conn():
    conn = sqlite3.connect(str(DB_PATH), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db_schema():
    conn = get_conn()
    conn.execute("PRAGMA journal_mode=WAL")  # meilleure gestion des accès concurrents (plusieurs postes)
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS clients (
        name TEXT PRIMARY KEY,
        sheet_name TEXT UNIQUE,
        phone TEXT, adresse TEXT, ville TEXT, province TEXT,
        code_postal TEXT, courriel TEXT
    );
    CREATE TABLE IF NOT EXISTS invoices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        client_name TEXT NOT NULL REFERENCES clients(name),
        numero TEXT, date_facture TEXT, echeance TEXT,
        montant REAL, notes TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_invoices_client ON invoices(client_name);
    CREATE TABLE IF NOT EXISTS log_envois (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT, client TEXT, courriel TEXT, total REAL, statut TEXT, note TEXT,
        synced INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS meta (
        key TEXT PRIMARY KEY, value TEXT
    );
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        is_admin INTEGER NOT NULL DEFAULT 0,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT,
        permissions TEXT NOT NULL DEFAULT '[]'
    );
    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT, username TEXT, action TEXT, details TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(id DESC);
    CREATE TABLE IF NOT EXISTS credit_clients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        prenom_entreprise TEXT NOT NULL,
        nom TEXT,
        credit_limit REAL NOT NULL DEFAULT 0,
        solde REAL NOT NULL DEFAULT 0,
        deposit REAL NOT NULL DEFAULT 0,
        ligne_source TEXT,
        notes TEXT,
        created_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_credit_clients_nom ON credit_clients(prenom_entreprise, nom);
    CREATE TABLE IF NOT EXISTS credit_movements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        credit_client_id INTEGER NOT NULL REFERENCES credit_clients(id),
        lightspeed_id TEXT,
        date_mouvement TEXT,
        montant REAL NOT NULL DEFAULT 0,
        type TEXT,
        sale TEXT,
        customer_brut TEXT,
        notes TEXT,
        imported_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_credit_movements_client ON credit_movements(credit_client_id);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_credit_movements_lsid
        ON credit_movements(lightspeed_id) WHERE lightspeed_id IS NOT NULL;

    CREATE TABLE IF NOT EXISTS credit_snapshots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        label TEXT,
        source TEXT,
        client_count INTEGER NOT NULL DEFAULT 0,
        total_credit_limit REAL NOT NULL DEFAULT 0,
        total_solde REAL NOT NULL DEFAULT 0,
        total_deposit REAL NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS credit_snapshot_lines (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        snapshot_id INTEGER NOT NULL REFERENCES credit_snapshots(id),
        prenom_entreprise TEXT NOT NULL,
        nom TEXT,
        credit_limit REAL NOT NULL DEFAULT 0,
        solde REAL NOT NULL DEFAULT 0,
        deposit REAL NOT NULL DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_credit_snapshot_lines_snap ON credit_snapshot_lines(snapshot_id);
    """)
    conn.commit()
    # migration : ajoute la colonne montant_paye si elle n'existe pas encore
    # (sur une base créée avant l'ajout du suivi des paiements partiels)
    cols = [r['name'] for r in conn.execute("PRAGMA table_info(invoices)").fetchall()]
    if 'montant_paye' not in cols:
        conn.execute("ALTER TABLE invoices ADD COLUMN montant_paye REAL NOT NULL DEFAULT 0")
        conn.commit()
        cols.append('montant_paye')
    # migration : ajoute la colonne date_paiement si elle n'existe pas encore (sur
    # une base créée avant le suivi des dates de paiement). Sans cette date, un
    # rapport d'âge pour un mois passé ne peut pas savoir si un paiement avait
    # déjà été reçu à cette date-là ou non.
    if 'date_paiement' not in cols:
        conn.execute("ALTER TABLE invoices ADD COLUMN date_paiement TEXT")
        conn.commit()
        # Les paiements déjà saisis avant cette mise à jour n'ont pas de date
        # exacte connue. Par choix explicite du client (Steve, Outillages
        # Express) : on les considère reçus AUJOURD'HUI plutôt que "depuis
        # toujours" — un rapport d'âge pour un mois antérieur à aujourd'hui les
        # affichera donc comme non réglés à cette date passée (plus prudent
        # pour le suivi des comptes à recevoir que de les supposer déjà payés).
        today_str = datetime.date.today().strftime('%Y-%m-%d')
        conn.execute(
            "UPDATE invoices SET date_paiement=? "
            "WHERE montant_paye > 0 AND (date_paiement IS NULL OR date_paiement='')",
            (today_str,)
        )
        conn.commit()
    # migration : ajoute la colonne permissions si elle n'existe pas encore (sur
    # une base créée avant l'ajout des accès granulaires). Les comptes non-admin
    # déjà existants gardent l'accès aux rapports (comportement identique à
    # avant cette fonctionnalité) — les autres permissions doivent être
    # accordées explicitement depuis "Utilisateurs".
    user_cols = [r['name'] for r in conn.execute("PRAGMA table_info(users)").fetchall()]
    if 'permissions' not in user_cols:
        conn.execute("ALTER TABLE users ADD COLUMN permissions TEXT NOT NULL DEFAULT '[]'")
        conn.execute("UPDATE users SET permissions='[\"reports\"]' WHERE is_admin=0")
        conn.commit()
    # migration : case « ne pas synchroniser avec l'importation » sur les comptes de crédit
    cc_cols = [r['name'] for r in conn.execute("PRAGMA table_info(credit_clients)").fetchall()]
    if cc_cols and 'no_sync' not in cc_cols:
        conn.execute("ALTER TABLE credit_clients ADD COLUMN no_sync INTEGER NOT NULL DEFAULT 0")
        conn.commit()
    # migration 1.10.0 : lien avec l'API Lightspeed (identifiant du compte de
    # crédit et du client Lightspeed) + comptes Lightspeed en attente
    # d'association manuelle (homonymes).
    if cc_cols and 'ls_credit_account_id' not in cc_cols:
        conn.execute("ALTER TABLE credit_clients ADD COLUMN ls_credit_account_id TEXT")
        conn.execute("ALTER TABLE credit_clients ADD COLUMN ls_customer_id TEXT")
        conn.commit()
    conn.executescript("""
    CREATE UNIQUE INDEX IF NOT EXISTS idx_credit_clients_lsid
        ON credit_clients(ls_credit_account_id) WHERE ls_credit_account_id IS NOT NULL;
    CREATE TABLE IF NOT EXISTS credit_backups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        label TEXT,
        username TEXT,
        filename TEXT NOT NULL,
        client_count INTEGER NOT NULL DEFAULT 0,
        movement_count INTEGER NOT NULL DEFAULT 0,
        total_solde REAL NOT NULL DEFAULT 0,
        total_deposit REAL NOT NULL DEFAULT 0,
        restored_at TEXT,
        restored_by TEXT
    );
    CREATE TABLE IF NOT EXISTS ls_ar_customers (
        ls_customer_id TEXT PRIMARY KEY,
        client_name TEXT NOT NULL,
        linked_at TEXT
    );
    CREATE TABLE IF NOT EXISTS sales_payments (
        payment_id TEXT PRIMARY KEY, sale_id TEXT, sale_date TEXT, shop_id TEXT, type_id TEXT, name TEXT, ptype TEXT, amount REAL
    );
    CREATE INDEX IF NOT EXISTS idx_pay_date ON sales_payments(sale_date);
    CREATE TABLE IF NOT EXISTS shop_mechanics (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, pin_hash TEXT, cost_rate REAL,
        active INTEGER NOT NULL DEFAULT 1, color TEXT, created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS shop_punches (
        id INTEGER PRIMARY KEY AUTOINCREMENT, mechanic_id INTEGER NOT NULL, job TEXT NOT NULL,
        start_at TEXT NOT NULL, end_at TEXT, ended_by TEXT, created_by TEXT, corrected_by TEXT, corrected_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_punch_job ON shop_punches(job);
    CREATE INDEX IF NOT EXISTS idx_punch_mech ON shop_punches(mechanic_id, start_at);
    CREATE TABLE IF NOT EXISTS shop_jobs (
        job TEXT PRIMARY KEY, client TEXT, item TEXT, work TEXT, mechanic_id INTEGER, due_date TEXT,
        status TEXT NOT NULL DEFAULT 'ouvert', created_by TEXT, created_at TEXT, updated_at TEXT,
        priority TEXT NOT NULL DEFAULT 'normal', notes TEXT, position INTEGER NOT NULL DEFAULT 0, work_date TEXT
    );
    CREATE TABLE IF NOT EXISTS hr_employees (
        id INTEGER PRIMARY KEY AUTOINCREMENT, first_name TEXT, last_name TEXT, position TEXT, department TEXT, hire_date TEXT,
        status TEXT NOT NULL DEFAULT 'actif', probation_end TEXT, end_date TEXT, next_review TEXT, email TEXT, phone TEXT, address TEXT,
        emergency_name TEXT, emergency_phone TEXT, username TEXT, mechanic_id INTEGER, notes TEXT, created_at TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS hr_documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL, category TEXT, title TEXT, filename TEXT, original_name TEXT,
        size INTEGER, expires_on TEXT, created_at TEXT, created_by TEXT
    );
    CREATE TABLE IF NOT EXISTS hr_evaluations (
        id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL, period_start TEXT, period_end TEXT, eval_date TEXT, evaluator TEXT,
        scores TEXT, overall REAL, strengths TEXT, improvements TEXT, objectives TEXT, employee_comments TEXT, status TEXT NOT NULL DEFAULT 'brouillon',
        atelier_stats TEXT, created_at TEXT, updated_at TEXT, criteria TEXT
    );
    CREATE TABLE IF NOT EXISTS hr_notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL, kind TEXT, note_date TEXT, text TEXT, created_by TEXT, created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS hr_portal (
        employee_id INTEGER PRIMARY KEY, login TEXT UNIQUE, password_hash TEXT, active INTEGER NOT NULL DEFAULT 1,
        token TEXT, token_expires TEXT, invited_at TEXT, last_login TEXT, created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS tc_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL, ts TEXT NOT NULL, kind TEXT NOT NULL, station TEXT,
        created_by TEXT, note TEXT, deleted INTEGER NOT NULL DEFAULT 0, corrected_by TEXT, corrected_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_tc_emp_ts ON tc_events(employee_id, ts);
    CREATE TABLE IF NOT EXISTS user_sessions (
        sid TEXT PRIMARY KEY, kind TEXT NOT NULL, user_id INTEGER, username TEXT, display TEXT, ip TEXT, agent TEXT,
        created_at TEXT, last_seen TEXT, revoked_at TEXT, revoked_by TEXT
    );
    CREATE TABLE IF NOT EXISTS sched_shifts (
        employee_id INTEGER NOT NULL, day TEXT NOT NULL, kind TEXT NOT NULL, start TEXT, end TEXT, meal TEXT, note TEXT,
        updated_at TEXT, updated_by TEXT, PRIMARY KEY(employee_id, day)
    );
    CREATE TABLE IF NOT EXISTS sched_published (
        employee_id INTEGER NOT NULL, day TEXT NOT NULL, kind TEXT NOT NULL, start TEXT, end TEXT, meal TEXT, note TEXT,
        updated_at TEXT, updated_by TEXT, PRIMARY KEY(employee_id, day)
    );
    CREATE TABLE IF NOT EXISTS sched_notices (
        id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL, created_at TEXT, text TEXT, seen_at TEXT
    );
    CREATE TABLE IF NOT EXISTS tc_approvals (
        employee_id INTEGER NOT NULL, period_start TEXT NOT NULL, approved_by TEXT, approved_at TEXT, PRIMARY KEY(employee_id, period_start)
    );
    CREATE TABLE IF NOT EXISTS hr_access_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, username TEXT, employee_id INTEGER, action TEXT, ip TEXT
    );
    CREATE TABLE IF NOT EXISTS shop_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, mechanic_id INTEGER NOT NULL, job TEXT,
        kind TEXT NOT NULL DEFAULT 'message', category TEXT, text TEXT, from_side TEXT NOT NULL, username TEXT,
        read_at TEXT, resolved_at TEXT, resolved_by TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_msg_mech ON shop_messages(mechanic_id, id);
    CREATE TABLE IF NOT EXISTS shop_sale_links (
        sale_line_id TEXT PRIMARY KEY, job TEXT, ignored INTEGER NOT NULL DEFAULT 0, username TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS shop_billing (
        job TEXT PRIMARY KEY, billed_minutes REAL, billed_amount REAL, note TEXT, username TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS inventory_snapshots (
        id INTEGER PRIMARY KEY AUTOINCREMENT, taken_at TEXT, kind TEXT, shop_id TEXT, shop_name TEXT, method TEXT,
        items INTEGER, units REAL, cost_value REAL, retail_value REAL, negative_items INTEGER, username TEXT
    );
    CREATE TABLE IF NOT EXISTS inventory_snapshot_lines (
        snapshot_id INTEGER NOT NULL, category TEXT, items INTEGER, units REAL, cost_value REAL, retail_value REAL
    );
    CREATE INDEX IF NOT EXISTS idx_inv_lines ON inventory_snapshot_lines(snapshot_id);
    CREATE TABLE IF NOT EXISTS announcements (
        id INTEGER PRIMARY KEY AUTOINCREMENT, message TEXT NOT NULL, color TEXT NOT NULL DEFAULT 'yellow',
        start_date TEXT, end_date TEXT, active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT, created_by TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS password_resets (
        token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL, created_at REAL, expires_at REAL,
        used_at REAL, ip TEXT
    );
    CREATE TABLE IF NOT EXISTS mfa_challenges (
        user_id INTEGER PRIMARY KEY, code_hash TEXT, expires_at REAL NOT NULL DEFAULT 0,
        attempts INTEGER NOT NULL DEFAULT 0, locked_until REAL NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS sales_lines (
        sale_line_id TEXT PRIMARY KEY,
        sale_id TEXT, sale_date TEXT, shop_id TEXT, item_id TEXT, category_id TEXT,
        qty REAL, subtotal REAL, discount REAL, total REAL, cost REAL
    );
    CREATE INDEX IF NOT EXISTS idx_sales_lines_date ON sales_lines(sale_date);
    CREATE TABLE IF NOT EXISTS sales_days (
        day TEXT PRIMARY KEY, sales_count INTEGER NOT NULL DEFAULT 0,
        complete INTEGER NOT NULL DEFAULT 0, fetched_at TEXT
    );
    CREATE TABLE IF NOT EXISTS ls_categories (category_id TEXT PRIMARY KEY, name TEXT, path TEXT, updated_at TEXT);
    CREATE TABLE IF NOT EXISTS ls_shops (shop_id TEXT PRIMARY KEY, name TEXT, archived INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS ls_tax_classes (tax_class_id TEXT PRIMARY KEY, name TEXT);
    CREATE TABLE IF NOT EXISTS ls_tax_category_classes (
        tax_category_id TEXT NOT NULL, tax_class_id TEXT NOT NULL,
        tax1_rate REAL NOT NULL DEFAULT 0, tax2_rate REAL NOT NULL DEFAULT 0,
        PRIMARY KEY (tax_category_id, tax_class_id)
    );
    CREATE TABLE IF NOT EXISTS ls_tax_categories (
        tax_category_id TEXT PRIMARY KEY, name TEXT, tax1_name TEXT, tax2_name TEXT,
        tax1_rate REAL NOT NULL DEFAULT 0, tax2_rate REAL NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS report_sends (
        id INTEGER PRIMARY KEY AUTOINCREMENT, sent_at TEXT, kind TEXT, period TEXT,
        recipients TEXT, status TEXT, error TEXT, username TEXT
    );
    CREATE TABLE IF NOT EXISTS ls_ar_aliases (
        alias TEXT PRIMARY KEY,          -- nom normalisé (_norm_credit_name)
        display TEXT,                    -- nom tel qu'il était écrit
        client_name TEXT NOT NULL,
        created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS ls_ar_payments (
        sale_id TEXT PRIMARY KEY,
        client_name TEXT,
        payment_date TEXT,
        montant REAL NOT NULL DEFAULT 0,
        status TEXT NOT NULL,
        details TEXT,
        processed_at TEXT,
        username TEXT
    );
    CREATE TABLE IF NOT EXISTS ls_ar_ignored (
        sale_id TEXT PRIMARY KEY,
        ignored_at TEXT,
        username TEXT,
        info TEXT
    );
    CREATE TABLE IF NOT EXISTS ls_pending_accounts (
        ls_credit_account_id TEXT PRIMARY KEY,
        ls_customer_id TEXT,
        prenom_entreprise TEXT,
        nom TEXT,
        credit_limit REAL NOT NULL DEFAULT 0,
        debt REAL NOT NULL DEFAULT 0,
        seen_at TEXT
    );
    """)
    conn.commit()
    # 1.17.0 : taxes gardées avec chaque ligne de vente (rapport des taxes)
    sl_cols = [r[1] for r in conn.execute("PRAGMA table_info(sales_lines)").fetchall()]
    for col, ddl in (('tax1', 'REAL NOT NULL DEFAULT 0'), ('tax2', 'REAL NOT NULL DEFAULT 0'),
                     ('tax1_rate', 'REAL'), ('tax2_rate', 'REAL'), ('taxable', 'INTEGER'), ('tax_cat', 'TEXT'),
                     ('tax_class', 'TEXT'), ('is_fee', 'INTEGER NOT NULL DEFAULT 0'), ('fee_name', 'TEXT'),
                     ('descr', 'TEXT'), ('job_ref', 'TEXT'), ('svc_minutes', 'REAL')):
        if sl_cols and col not in sl_cols:
            conn.execute(f"ALTER TABLE sales_lines ADD COLUMN {col} {ddl}")
    sd_cols = [r[1] for r in conn.execute("PRAGMA table_info(sales_days)").fetchall()]
    if sd_cols and 'tax_ok' not in sd_cols:
        conn.execute("ALTER TABLE sales_days ADD COLUMN tax_ok INTEGER NOT NULL DEFAULT 0")
    if sd_cols and 'ws_ok' not in sd_cols:       # 1.21.0 : numéros de bon HubTiger lus
        conn.execute("ALTER TABLE sales_days ADD COLUMN ws_ok INTEGER NOT NULL DEFAULT 0")
    for tbl, cols in (('hr_employees', (('tc_enabled', 'INTEGER NOT NULL DEFAULT 0'), ('tc_pin_hash', 'TEXT'))),
                      ('hr_documents', (('published', 'INTEGER NOT NULL DEFAULT 0'), ('published_at', 'TEXT'), ('sign_required', 'INTEGER NOT NULL DEFAULT 0'),
                                        ('mgr_sig', 'TEXT'), ('mgr_signed_at', 'TEXT'), ('mgr_signed_by', 'TEXT'), ('emp_sig', 'TEXT'), ('emp_signed_at', 'TEXT'),
                                        ('emp_comment', 'TEXT'), ('emp_sign_ip', 'TEXT'), ('doc_hash', 'TEXT'), ('signed_filename', 'TEXT'),
                                        ('viewed_at', 'TEXT'), ('emailed_at', 'TEXT')))):          # 1.39.0
        have = {r[1] for r in conn.execute(f"PRAGMA table_info({tbl})").fetchall()}
        for col, typ in cols:
            if have and col not in have:
                conn.execute(f"ALTER TABLE {tbl} ADD COLUMN {col} {typ}")
    he_cols = {r[1] for r in conn.execute("PRAGMA table_info(hr_evaluations)").fetchall()}
    if he_cols and 'criteria' not in he_cols:    # 1.31.0 : critères gardés avec chaque évaluation
        conn.execute("ALTER TABLE hr_evaluations ADD COLUMN criteria TEXT")
        conn.execute("UPDATE hr_evaluations SET criteria=? WHERE criteria IS NULL",      # évaluations de la 1.30 : critères d'origine
                     (json.dumps([{'key': k_, 'label': l_, 'hint': h_} for k_, l_, h_ in HR_CRITERIA], ensure_ascii=False),))
    sj_cols = {r[1] for r in conn.execute("PRAGMA table_info(shop_jobs)").fetchall()}
    for col, typ in (('priority', "TEXT NOT NULL DEFAULT 'normal'"), ('notes', 'TEXT'), ('position', 'INTEGER NOT NULL DEFAULT 0'), ('work_date', 'TEXT')):
        if sj_cols and col not in sj_cols:       # 1.25.0 : planification des bons
            conn.execute(f"ALTER TABLE shop_jobs ADD COLUMN {col} {typ}")
    if sd_cols and 'pay_ok' not in sd_cols:      # 1.23.0 : paiements gardés avec les ventes
        conn.execute("ALTER TABLE sales_days ADD COLUMN pay_ok INTEGER NOT NULL DEFAULT 0")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_sales_job ON sales_lines(job_ref)")
    conn.commit()
    # 1.23.0 : nouvelle permission « Comptes à recevoir » — accordée une fois aux utilisateurs
    # existants (non administrateurs), qui y avaient accès sans permission jusqu'ici.
    if not conn.execute("SELECT 1 FROM meta WHERE key='perm_ar_migrated'").fetchone():
        for u in conn.execute("SELECT id, permissions FROM users WHERE is_admin=0").fetchall():
            try:
                perms = json.loads(u['permissions'] or '[]')
            except ValueError:
                perms = []
            if 'comptes_recevoir' not in perms:
                conn.execute("UPDATE users SET permissions=? WHERE id=?", (json.dumps(perms + ['comptes_recevoir']), u['id']))
        conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES ('perm_ar_migrated', '1')")
        conn.commit()
    # 1.14.0 : courriel et double authentification des utilisateurs
    u_cols = [r[1] for r in conn.execute("PRAGMA table_info(users)").fetchall()]
    for col, ddl in (('email', 'TEXT'), ('full_name', 'TEXT'), ('mfa_required', 'INTEGER NOT NULL DEFAULT 0'), ('mfa_method', 'TEXT'),
                     ('mfa_secret', 'TEXT'), ('mfa_last_step', 'INTEGER NOT NULL DEFAULT 0'),
                     ('mfa_pending_secret', 'TEXT')):
        if u_cols and col not in u_cols:
            conn.execute(f"ALTER TABLE users ADD COLUMN {col} {ddl}")
    conn.commit()
    # 1.11.3 : nom du client Lightspeed gardé avec le lien (affiché dans la fiche)
    lc_cols = [r[1] for r in conn.execute("PRAGMA table_info(ls_ar_customers)").fetchall()]
    if 'ls_name' not in lc_cols:
        conn.execute("ALTER TABLE ls_ar_customers ADD COLUMN ls_name TEXT")
        conn.commit()
    # 1.11.0 : sauvegardes des comptes à recevoir dans la même table
    bk_cols = [r[1] for r in conn.execute("PRAGMA table_info(credit_backups)").fetchall()]
    if 'scope' not in bk_cols:
        conn.execute("ALTER TABLE credit_backups ADD COLUMN scope TEXT NOT NULL DEFAULT 'credit'")
        conn.commit()
    conn.close()


def meta_get(key, default=None):
    conn = get_conn()
    row = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
    conn.close()
    return row['value'] if row else default


def meta_set(key, value):
    conn = get_conn()
    conn.execute("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                 (key, str(value)))
    conn.commit()
    conn.close()


def mark_dirty():
    meta_set('dirty', '1')


# ============================================================
# Utilisateurs / connexion
# ============================================================
# Accès granulaires pouvant être accordés à un utilisateur non-administrateur.
# La gestion des utilisateurs elle-même (page "Utilisateurs") reste toujours
# réservée aux administrateurs, pour qu'un compte non-admin ne puisse jamais
# se donner (ou donner à quelqu'un d'autre) davantage de droits.
PERMISSION_KEYS = {
    'comptes_recevoir': "Comptes à recevoir (clients, factures)",
    'reports': "Rapports (état de compte, envoi, vieillissement)",
    'audit': "Journal d'audit",
    'license': "Licence",
    'email_settings': "Paramètres d'envoi (Outlook/SMTP)",
    'updates': "Mises à jour",
    'credit_accounts': "Comptes de crédit (Lightspeed)",
    'custom_reports': "Rapport des ventes (Lightspeed)",
    'tax_reports': "Rapport des taxes (Lightspeed)",
    'inventory_reports': "Valeur de l'inventaire (Lightspeed)",
    'dashboard3d': "Tableau de bord 3D",
    'atelier_punch': "Gestion Atelier — poste de punch",
    'atelier': "Gestion Atelier — tableau et punchs",
    'atelier_profit': "Gestion Atelier — rentabilité et évaluations (données sensibles)",
    'rh': "Gestion RH — dossiers des employés (renseignements personnels)",
    'punch_presence': "Gestion RH — poste de punch des employés (ordinateur de travail)",
}


def _parse_permissions(raw):
    try:
        val = json.loads(raw) if raw else []
        return [p for p in val if p in PERMISSION_KEYS] if isinstance(val, list) else []
    except Exception:
        return []


def _dump_permissions(perms):
    clean = sorted(set(p for p in (perms or []) if p in PERMISSION_KEYS))
    return json.dumps(clean)


def db_list_users():
    conn = get_conn()
    rows = conn.execute(
        "SELECT id, username, full_name, is_admin, active, created_at, permissions, email, mfa_required, mfa_method "
        "FROM users ORDER BY username COLLATE NOCASE"
    ).fetchall()
    conn.close()
    out = []
    for r in rows:
        d = dict(r)
        d['permissions'] = _parse_permissions(d.get('permissions'))
        out.append(d)
    return out


def db_get_user_by_username(username):
    conn = get_conn()
    row = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    d['permissions'] = _parse_permissions(d.get('permissions'))
    return d


def db_get_user(user_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    d['permissions'] = _parse_permissions(d.get('permissions'))
    return d


def db_create_user(username, password, is_admin=False, permissions=None):
    username = (username or '').strip()
    if not username:
        raise ValueError("Nom d'utilisateur requis.")
    if not password or len(password) < 4:
        raise ValueError("Mot de passe trop court (minimum 4 caractères).")
    conn = get_conn()
    try:
        conn.execute(
            "INSERT INTO users(username, password_hash, is_admin, active, created_at, permissions) "
            "VALUES (?,?,?,1,?,?)",
            (username, generate_password_hash(password), 1 if is_admin else 0,
             datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
             _dump_permissions(permissions)),
        )
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        raise ValueError("Ce nom d'utilisateur existe déjà.")
    conn.close()


def db_update_user(user_id, is_admin=None, active=None, new_password=None, permissions=None):
    conn = get_conn()
    if is_admin is not None:
        conn.execute("UPDATE users SET is_admin=? WHERE id=?", (1 if is_admin else 0, user_id))
    if active is not None:
        conn.execute("UPDATE users SET active=? WHERE id=?", (1 if active else 0, user_id))
    if new_password:
        if len(new_password) < 4:
            conn.close()
            raise ValueError("Mot de passe trop court (minimum 4 caractères).")
        conn.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new_password), user_id))
    if permissions is not None:
        conn.execute("UPDATE users SET permissions=? WHERE id=?", (_dump_permissions(permissions), user_id))
    conn.commit()
    conn.close()


def db_delete_user(user_id):
    conn = get_conn()
    conn.execute("DELETE FROM users WHERE id=?", (user_id,))
    conn.commit()
    conn.close()


def db_verify_login(username, password):
    user = db_get_user_by_username((username or '').strip())
    if not user or not user['active']:
        return None
    if not check_password_hash(user['password_hash'], password or ''):
        return None
    return user


def ensure_admin_bootstrap():
    """Crée un compte admin par défaut au tout premier démarrage si aucun utilisateur n'existe."""
    if db_list_users():
        return
    temp_password = secrets.token_urlsafe(9)
    db_create_user('admin', temp_password, is_admin=True)
    print()
    print("=" * 60)
    print("PREMIER DÉMARRAGE — COMPTE ADMINISTRATEUR CRÉÉ")
    print(f"  Nom d'utilisateur : admin")
    print(f"  Mot de passe      : {temp_password}")
    print("Note ce mot de passe maintenant — il ne sera plus réaffiché.")
    print("Connecte-toi puis crée les autres comptes depuis 'Utilisateurs'.")
    print("=" * 60)
    print()


def get_or_create_secret_key():
    key = meta_get('secret_key')
    if not key:
        key = secrets.token_hex(32)
        meta_set('secret_key', key)
    return key


def current_user():
    uid = session.get('user_id')
    if not uid:
        return None
    return db_get_user(uid)


def login_required_check():
    """Retourne une réponse (redirect/JSON 401) si non connecté, sinon None."""
    if request.endpoint in ('login', 'static', 'lightspeed_oauth_callback') + AUTH_PUBLIC_ENDPOINTS \
            or request.endpoint in LICENSE_EXEMPT_ENDPOINTS \
            or request.path.startswith('/static/'):
        return None
    if not session.get('user_id'):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'auth_required'}), 401
        return redirect(url_for('login', next=request.path))
    return None


def admin_required_check():
    if not session.get('is_admin'):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'forbidden', 'message': 'Réservé aux administrateurs.'}), 403
        return "Accès refusé — réservé aux administrateurs.", 403
    return None


def permission_required_check(perm_key):
    """Comme admin_required_check, mais laisse passer un utilisateur non-admin
    qui a reçu la permission granulaire `perm_key` (voir PERMISSION_KEYS).
    Un administrateur a toujours accès à tout."""
    if session.get('is_admin'):
        return None
    if perm_key in (session.get('permissions') or []):
        return None
    if request.path.startswith('/api/'):
        return jsonify({'error': 'forbidden', 'message': "Ton compte n'a pas accès à cette section."}), 403
    return "Accès refusé — ton compte n'a pas accès à cette section.", 403


# ============================================================
# Licence logicielle (30 jours / 1 an / à vie)
# ============================================================
# Seul "license_code" (le code brut collé par le client) est gardé en mémoire.
# Tout le reste (licencié, type, date d'expiration) est re-dérivé à chaque
# vérification à partir de ce code — jamais lu directement d'un champ séparé
# qui pourrait être modifié sans repasser par la signature.
LICENSE_EXEMPT_ENDPOINTS = ('activation_page', 'api_license_activate', 'api_license_status', 'static')


# ------------------------------------------------------------
# Horloge de confiance pour l'expiration des licences
# ------------------------------------------------------------
# Se fier uniquement à datetime.date.today() permettrait de prolonger une
# licence expirée en reculant la date de Windows. On combine donc :
#   1) la date réelle obtenue sur Internet (en-tête HTTP "Date" d'un grand
#      site), rafraîchie au démarrage puis toutes les 6 heures, et prolongée
#      entre deux vérifications avec une horloge monotone (insensible aux
#      changements de date de Windows);
#   2) la date la plus récente déjà vue par l'app ("high-water mark"),
#      gardée dans la table meta — sert de référence quand Internet n'est
#      pas disponible.
# Si la date de l'ordinateur est en retard de plus de CLOCK_TOLERANCE_DAYS
# sur la référence, l'horloge est considérée comme reculée et une licence à
# durée limitée est bloquée. Les licences à vie ne sont jamais concernées.
CLOCK_TOLERANCE_DAYS = 1
NET_TIME_URLS = (
    "https://raw.githubusercontent.com/",
    "https://www.google.com/",
    "https://www.microsoft.com/",
)
NET_TIME_REFRESH_SECONDS = 6 * 3600      # rafraîchissement normal
NET_TIME_RETRY_SECONDS = 15 * 60         # nouvel essai si Internet indisponible
CLOCK_HIGH_WATER_KEY = 'clock_high_water'

_net_time_lock = threading.Lock()
_net_time = {'utc': None, 'mono': None}
_clock_hw_cache = {'value': None}
_clock_alert_state = {'logged': False}


def _fetch_internet_utc():
    """Retourne la date/heure UTC lue dans l'en-tête HTTP "Date" du premier
    site qui répond, ou None si aucun n'est joignable."""
    for url in NET_TIME_URLS:
        header = None
        try:
            req = urllib.request.Request(url, method='HEAD', headers={'Cache-Control': 'no-cache'})
            with urllib.request.urlopen(req, timeout=5) as r:
                header = r.headers.get('Date')
        except urllib.error.HTTPError as e:
            # Même une réponse d'erreur (403, 405...) porte un en-tête Date fiable.
            header = e.headers.get('Date') if e.headers else None
        except Exception:
            continue
        if not header:
            continue
        try:
            dt = email.utils.parsedate_to_datetime(header)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=datetime.timezone.utc)
            return dt.astimezone(datetime.timezone.utc)
        except Exception:
            continue
    return None


def refresh_internet_time():
    dt = _fetch_internet_utc()
    if dt is not None:
        with _net_time_lock:
            _net_time['utc'] = dt
            _net_time['mono'] = time.monotonic()
    return dt


def internet_today():
    """Date du jour selon Internet (convertie à l'heure locale), prolongée
    avec l'horloge monotone depuis la dernière vérification. None si l'heure
    Internet n'a jamais pu être obtenue depuis le démarrage."""
    with _net_time_lock:
        utc, mono = _net_time['utc'], _net_time['mono']
    if utc is None:
        return None
    now_utc = utc + datetime.timedelta(seconds=max(0.0, time.monotonic() - mono))
    return now_utc.astimezone().date()


def _clock_high_water_get():
    if _clock_hw_cache['value'] is not None:
        return _clock_hw_cache['value']
    hw = None
    raw = meta_get(CLOCK_HIGH_WATER_KEY)
    if raw:
        try:
            hw = datetime.date.fromisoformat(raw)
        except Exception:
            hw = None
    if hw is None:
        # Première utilisation : on part de l'action la plus récente du
        # journal d'audit (horodatée par l'app elle-même).
        try:
            conn = get_conn()
            row = conn.execute("SELECT MAX(substr(ts,1,10)) AS m FROM audit_log").fetchone()
            conn.close()
            if row and row['m']:
                hw = datetime.date.fromisoformat(row['m'])
        except Exception:
            hw = None
        if hw is not None:
            _clock_high_water_set(hw)
    _clock_hw_cache['value'] = hw
    return hw


def _clock_high_water_set(d):
    try:
        meta_set(CLOCK_HIGH_WATER_KEY, d.isoformat())
    except Exception:
        traceback.print_exc()
    _clock_hw_cache['value'] = d


def get_trusted_today():
    """Retourne (date_de_reference, horloge_ok, date_locale).
    - Avec Internet : la date Internet fait foi (et corrige au besoin la date
      mémorisée, par exemple si l'horloge avait été avancée par erreur).
    - Sans Internet : la plus récente entre la date locale et la date mémorisée.
    horloge_ok est False si la date de l'ordinateur est en retard de plus de
    CLOCK_TOLERANCE_DAYS sur la référence."""
    local = datetime.date.today()
    tol = datetime.timedelta(days=CLOCK_TOLERANCE_DAYS)
    hw = _clock_high_water_get()
    net = internet_today()
    if net is not None:
        if hw is None or hw < net or hw > net + tol:
            _clock_high_water_set(net)
        reference = net
        effective = net
    else:
        reference = hw
        if hw is None or local > hw:
            _clock_high_water_set(local)
        effective = max(local, hw) if hw else local
    clock_ok = reference is None or local >= reference - tol
    return effective, clock_ok, local


def _clock_problem_message(reference, local):
    return (f"La date de cet ordinateur ({local.isoformat()}) semble antérieure "
            f"à la date réelle ({reference.isoformat()}). Corrige la date et "
            f"l'heure de Windows, puis recharge la page.")


def _report_clock_problem(reference, local):
    if not _clock_alert_state['logged']:
        _clock_alert_state['logged'] = True
        db_add_audit('système', 'Horloge reculée détectée',
                     f"Date de l'ordinateur : {local.isoformat()} — date de référence : "
                     f"{reference.isoformat()}. Licence à durée limitée bloquée.")
        print(f"ATTENTION : horloge reculée détectée (ordinateur {local}, référence {reference}).")


def _net_time_loop():
    while True:
        try:
            ok = refresh_internet_time() is not None
        except Exception:
            ok = False
        time.sleep(NET_TIME_REFRESH_SECONDS if ok else NET_TIME_RETRY_SECONDS)


def get_license_status():
    """État de la licence (noyau) + état de chaque module, mis en cache pour la requête en cours."""
    try:
        from flask import g, has_request_context
        if has_request_context() and getattr(g, '_kubios_lic', None) is not None:
            return g._kubios_lic
    except Exception:
        has_request_context = lambda: False
    st = _license_core_status()
    if st.get('payload') and st.get('reason') != 'clock':
        today = get_trusted_today()[0] if (st['payload'].get('modules') or st['payload'].get('expires')) else datetime.date.today()
        st['modules'] = licensing.modules_status(st['payload'], today)
    else:
        st['modules'] = {}
    try:
        if has_request_context():
            g._kubios_lic = st
    except Exception:
        pass
    return st


def license_module_active(key):
    """Vrai si la licence est active ET que le module (atelier, rh) est inclus et non expiré."""
    st = get_license_status()
    return bool(st.get('active')) and bool((st.get('modules') or {}).get(key, {}).get('active'))


# Endpoints de chaque module (préfixes des fonctions Flask)
MODULE_ENDPOINTS = {'atelier': ('atelier_', 'api_atelier'), 'rh': ('hr_', 'api_hr', 'emp_', 'api_emp', 'tc_', 'api_tc', 'sched_', 'api_sched')}


def endpoint_module(endpoint):
    for key, prefixes in MODULE_ENDPOINTS.items():
        if endpoint and endpoint.startswith(prefixes):
            return key
    return None


def _license_core_status():
    """Revérifie la signature du code de licence stocké à chaque appel.
    Retourne un dict :
      {'active': True, 'payload': {...}, 'days_left': int|None}
      {'active': False, 'reason': 'none'|'invalid'|'expired'|'clock', 'error': str|None, 'payload': {...}|None}
    """
    code = meta_get('license_code', '')
    if not code:
        return {'active': False, 'reason': 'none', 'error': None, 'payload': None}
    result = licensing.verify_license_code(code)
    if not result['ok']:
        return {'active': False, 'reason': 'invalid', 'error': result['error'], 'payload': None}
    payload = result['payload']
    expires = payload.get('expires')
    if expires:
        try:
            exp_date = datetime.date.fromisoformat(expires)
        except Exception:
            return {'active': False, 'reason': 'invalid', 'error': "Date d'expiration illisible.", 'payload': None}
        today, clock_ok, local = get_trusted_today()
        if not clock_ok:
            _report_clock_problem(today, local)
            return {'active': False, 'reason': 'clock', 'payload': payload,
                    'error': _clock_problem_message(today, local)}
        _clock_alert_state['logged'] = False
        days_left = (exp_date - today).days
        if days_left < 0:
            return {'active': False, 'reason': 'expired', 'error': None, 'payload': payload}
        return {'active': True, 'payload': payload, 'days_left': days_left}
    return {'active': True, 'payload': payload, 'days_left': None}


def db_count_active_users():
    conn = get_conn()
    n = conn.execute("SELECT COUNT(*) FROM users WHERE active=1").fetchone()[0]
    conn.close()
    return n


def license_user_limit_error(adding=1):
    """Retourne un message d'erreur si ajouter `adding` utilisateur(s) actif(s)
    dépasserait la limite d'utilisateurs de la licence, sinon None."""
    status = get_license_status()
    limit = licensing.max_users_of(status.get('payload'))
    if limit is None:
        return None
    active = db_count_active_users()
    if active + adding > limit:
        return (f"Limite de la licence atteinte : {limit} utilisateur(s) actif(s) permis "
                f"({active} actuellement). Désactive un compte ou demande une licence "
                f"avec plus d'utilisateurs.")
    return None


def license_required_check():
    """Retourne une réponse (redirect/JSON 402) si aucune licence active,
    sinon None. Bloque TOUT (même la page de connexion) tant qu'aucune
    licence valide et non expirée n'est active — seule la page d'activation
    elle-même et son API restent accessibles."""
    if request.endpoint in LICENSE_EXEMPT_ENDPOINTS or request.path.startswith('/static/'):
        return None
    status = get_license_status()
    if not status['active']:
        if request.path.startswith('/api/'):
            return jsonify({'error': 'license_required', 'reason': status['reason']}), 402
        return redirect(url_for('activation_page'))
    mod = endpoint_module(request.endpoint)          # 1.38.0 : modules vendus séparément
    if mod and not license_module_active(mod):
        m = status['modules'].get(mod, {})
        why = 'expiré' if m.get('included') else 'non inclus'
        if request.path.startswith('/api/'):
            return jsonify({'error': 'module_required', 'module': mod,
                            'message': f"Le module « {licensing.MODULES[mod]} » est {why} dans la licence."}), 402
        return render_template('module_locked.html', company=get_company_name(), module=licensing.MODULES[mod], info=m, module_key=mod,
                               can_license=bool(session.get('is_admin')) or 'license' in (session.get('permissions') or [])), 402
    return None


# ============================================================
# Journal d'audit (visible uniquement par les administrateurs)
# ============================================================
AUDIT_MAX_ROWS = 5000


def db_add_audit(username, action, details=''):
    """Enregistre une action dans le journal d'audit. N'interrompt jamais l'action
    elle-même si l'écriture échoue (l'audit est secondaire, jamais bloquant)."""
    try:
        conn = get_conn()
        cur = conn.execute(
            "INSERT INTO audit_log(ts, username, action, details) VALUES (?,?,?,?)",
            (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), username or '?', action, details or '')
        )
        new_id = cur.lastrowid
        conn.commit()
        # purge périodique pour éviter une croissance illimitée (garde les AUDIT_MAX_ROWS plus récents)
        if new_id % 100 == 0:
            conn.execute(
                "DELETE FROM audit_log WHERE id NOT IN (SELECT id FROM audit_log ORDER BY id DESC LIMIT ?)",
                (AUDIT_MAX_ROWS,)
            )
            conn.commit()
        conn.close()
    except Exception:
        traceback.print_exc()


def log_audit(action, details=''):
    """À appeler depuis une route Flask (a accès à la session courante)."""
    db_add_audit(session.get('username'), action, details)


def db_list_audit(limit=1000):
    conn = get_conn()
    rows = conn.execute(
        "SELECT ts, username, action, details FROM audit_log ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ============================================================
# Paramètres d'envoi (Outlook ou serveur SMTP) — configurables par un admin
# ============================================================
SETTINGS_DEFAULTS = {
    'send_mode': 'outlook',        # 'outlook' ou 'smtp'
    'smtp_host': '',
    'smtp_port': '587',
    'smtp_username': '',
    'smtp_password': '',
    'smtp_encryption': 'starttls',  # 'starttls' | 'ssl' | 'none'
    'smtp_from_email': '',
    'smtp_from_name': '',
    # 1.43.0 : Microsoft 365 (Graph) — application inscrite dans Entra ID avec la permission Mail.Send
    'm365_tenant': '',
    'm365_client_id': '',
    'm365_secret': '',
    'm365_mailbox_ar': '',        # boîte partagée des comptes à recevoir (états de compte)
    'm365_mailbox_general': '',   # boîte de Kubios pour tous les autres envois
    'm365_from_name': '',
    'm365_ar_reply_to': '',      # 1.43.2 : adresse de réponse des états de compte (ex. groupe Teams recevables@)
    'm365_ar_copy': '',          # '1' = copie cachée de chaque état de compte à cette adresse
}


def get_settings():
    return {k: meta_get(k, default) for k, default in SETTINGS_DEFAULTS.items()}


def get_public_settings():
    """Ce qu'un utilisateur non-admin a besoin de savoir (jamais les identifiants SMTP)."""
    return {'send_mode': meta_get('send_mode', SETTINGS_DEFAULTS['send_mode'])}


def set_settings(data):
    for key in SETTINGS_DEFAULTS:
        if key in data and data[key] is not None:
            value = data[key]
            if key in ('smtp_password', 'm365_secret') and value == '':
                continue  # champ laissé vide = on garde l'ancien mot de passe
            meta_set(key, value)


def send_via_smtp(to_email, subject, body, pdf_path, settings, bcc_company=True):
    import smtplib
    from email.message import EmailMessage

    host = (settings.get('smtp_host') or '').strip()
    from_email = (settings.get('smtp_from_email') or '').strip()
    if not host or not from_email:
        raise RuntimeError(
            "Le serveur SMTP n'est pas configuré. Un administrateur doit le configurer "
            "dans 'Paramètres d'envoi'."
        )
    port = int(settings.get('smtp_port') or 587)
    username = (settings.get('smtp_username') or '').strip()
    password = settings.get('smtp_password') or ''
    encryption = settings.get('smtp_encryption') or 'starttls'
    from_name = (settings.get('smtp_from_name') or '').strip() or get_company_name()

    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = f"{from_name} <{from_email}>"
    msg['To'] = to_email
    if bcc_company and get_company_email():
        msg['Bcc'] = get_company_email()
    msg.set_content(body)
    if pdf_path:  # les courriels de sécurité (codes, liens) n'ont pas de pièce jointe
        with open(pdf_path, 'rb') as f:
            pdf_data = f.read()
        msg.add_attachment(pdf_data, maintype='application', subtype='pdf', filename=Path(pdf_path).name)

    if encryption == 'ssl':
        with smtplib.SMTP_SSL(host, port, timeout=30) as smtp:
            if username:
                smtp.login(username, password)
            smtp.send_message(msg)
    else:
        with smtplib.SMTP(host, port, timeout=30) as smtp:
            if encryption == 'starttls':
                smtp.starttls()
            if username:
                smtp.login(username, password)
            smtp.send_message(msg)
    return 'ENVOYÉ'


def test_smtp_connection(settings):
    """Vérifie la connexion/authentification SMTP sans envoyer de courriel."""
    import smtplib

    host = (settings.get('smtp_host') or '').strip()
    if not host:
        raise RuntimeError("Adresse du serveur SMTP manquante.")
    port = int(settings.get('smtp_port') or 587)
    username = (settings.get('smtp_username') or '').strip()
    password = settings.get('smtp_password') or ''
    encryption = settings.get('smtp_encryption') or 'starttls'

    if encryption == 'ssl':
        with smtplib.SMTP_SSL(host, port, timeout=15) as smtp:
            if username:
                smtp.login(username, password)
    else:
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            if encryption == 'starttls':
                smtp.starttls()
            if username:
                smtp.login(username, password)


_M365_TOKEN = {'key': None, 'tok': None, 'exp': 0}


def _m365_http(method, url, data=None, headers=None, form=False):
    import urllib.request, urllib.error, urllib.parse
    body = None
    h = dict(headers or {})
    if data is not None:
        if form:
            body = urllib.parse.urlencode(data).encode(); h['Content-Type'] = 'application/x-www-form-urlencoded'
        else:
            body = json.dumps(data).encode('utf-8'); h['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=body, method=method, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            raw = r.read()
            return r.status, (json.loads(raw) if raw else {})
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read() or b'{}')
        except ValueError:
            return e.code, {}


def _m365_error(code, js):
    err = js.get('error') if isinstance(js.get('error'), dict) else {}
    desc = js.get('error_description') or err.get('message') or ''
    c = js.get('error') if isinstance(js.get('error'), str) else err.get('code', '')
    if 'AADSTS7000215' in desc or 'invalid_client' in str(c):
        return "Microsoft 365 refuse l'accès : le secret client est invalide ou expiré (Entra ID → Inscriptions d'applications → Certificats et secrets)."
    if 'AADSTS700016' in desc or 'AADSTS90002' in desc:
        return "Microsoft 365 ne trouve pas l'application ou le locataire : vérifie l'ID du locataire (tenant) et l'ID de l'application (client)."
    if code == 403 or c in ('ErrorAccessDenied', 'Authorization_RequestDenied'):
        return ("Microsoft 365 refuse l'accès à cette boîte : dans Exchange Online, l'application doit avoir les rôles « Application Mail.Send » "
                "et « Application Mail.ReadWrite » sur une étendue qui inclut cette boîte (le changement peut prendre jusqu'à 2 heures).")
    if code == 404 or c in ('ErrorInvalidUser', 'ResourceNotFound', 'MailboxNotEnabledForRESTAPI'):
        return "Microsoft 365 ne trouve pas cette boîte de courriel : vérifie l'adresse (boîte partagée ou boîte de Kubios)."
    return f"Microsoft 365 a refusé la demande ({code}) : {desc or c or 'erreur inconnue'}"


def m365_token(settings):
    t, cid, sec = (settings.get('m365_tenant') or '').strip(), (settings.get('m365_client_id') or '').strip(), settings.get('m365_secret') or ''
    if not (t and cid and sec):
        raise RuntimeError("Microsoft 365 n'est pas configuré : un administrateur doit entrer le locataire, l'application et le secret dans « Paramètres d'envoi ».")
    key = (t, cid, hashlib.sha256(sec.encode()).hexdigest())
    if _M365_TOKEN['key'] == key and _M365_TOKEN['exp'] > time.time() + 60:
        return _M365_TOKEN['tok']
    code, js = _m365_http('POST', f"https://login.microsoftonline.com/{t}/oauth2/v2.0/token",
                          {'client_id': cid, 'client_secret': sec, 'scope': 'https://graph.microsoft.com/.default', 'grant_type': 'client_credentials'}, form=True)
    if code != 200 or 'access_token' not in js:
        raise RuntimeError(_m365_error(code, js))
    _M365_TOKEN.update(key=key, tok=js['access_token'], exp=time.time() + int(js.get('expires_in') or 3000))
    return js['access_token']


def m365_mailbox(settings, purpose):
    mb = (settings.get('m365_mailbox_ar') or '').strip() if purpose == 'ar' else ''
    mb = mb or (settings.get('m365_mailbox_general') or '').strip()
    if not mb:
        raise RuntimeError("Aucune boîte Microsoft 365 n'est définie pour l'envoi : un administrateur doit la choisir dans « Paramètres d'envoi ».")
    return mb


def send_via_m365(to_email, subject, body, pdf_path, settings, mode='send', bcc_company=True, purpose='general'):
    import urllib.parse
    tok = m365_token(settings)
    mb = m365_mailbox(settings, purpose)
    msg = {'subject': subject, 'body': {'contentType': 'Text', 'content': body},
           'toRecipients': [{'emailAddress': {'address': a.strip()}} for a in re.split(r'[;,]', to_email or '') if a.strip()]}
    bcc = []
    if bcc_company and get_company_email() and get_company_email().lower() != mb.lower():
        bcc.append(get_company_email())
    rt = (settings.get('m365_ar_reply_to') or '').strip() if purpose == 'ar' else ''
    if rt:                                              # réponses des clients dirigées vers la boîte / le groupe des recevables
        msg['replyTo'] = [{'emailAddress': {'address': rt}}]
        if settings.get('m365_ar_copy') == '1' and rt.lower() not in [b.lower() for b in bcc] and mode not in ('draft', 'draft_silent'):
            bcc.append(rt)
    if bcc:
        msg['bccRecipients'] = [{'emailAddress': {'address': b}} for b in bcc]
    if pdf_path:
        with open(pdf_path, 'rb') as f:
            msg['attachments'] = [{'@odata.type': '#microsoft.graph.fileAttachment', 'name': Path(pdf_path).name,
                                   'contentType': 'application/pdf', 'contentBytes': base64.b64encode(f.read()).decode('ascii')}]
    base = f"https://graph.microsoft.com/v1.0/users/{urllib.parse.quote(mb)}"
    auth = {'Authorization': f'Bearer {tok}'}
    if mode in ('draft', 'draft_silent'):
        code, js = _m365_http('POST', base + '/messages', msg, auth)          # brouillon dans la boîte (dossier Brouillons)
        if code not in (200, 201):
            raise RuntimeError(_m365_error(code, js))
        return f'BROUILLON ({mb})'
    code, js = _m365_http('POST', base + '/sendMail', {'message': msg, 'saveToSentItems': True}, auth)
    if code not in (200, 202):
        raise RuntimeError(_m365_error(code, js))
    return 'ENVOYÉ'


def send_email(to_email, subject, body, pdf_path, mode='draft', bcc_company=True, purpose='general'):
    """Point d'entrée unique pour l'envoi : bascule vers Outlook ou SMTP selon les
    paramètres configurés par un administrateur. Le SMTP n'a pas de concept de
    brouillon/relecture — un appel avec mode='draft*' en mode SMTP est refusé plus haut,
    avant d'arriver ici (voir les routes)."""
    settings = get_settings()
    if settings['send_mode'] == 'm365':
        return send_via_m365(to_email, subject, body, pdf_path, settings, mode=mode, bcc_company=bcc_company, purpose=purpose)
    if settings['send_mode'] == 'smtp':
        return send_via_smtp(to_email, subject, body, pdf_path, settings, bcc_company=bcc_company)
    return send_via_outlook(to_email, subject, body, pdf_path, mode=mode, bcc_company=bcc_company)


# ============================================================
# Import unique depuis Excel -> SQLite (au tout premier démarrage)
# ============================================================
def safe_sheet_name(name: str) -> str:
    cleaned = re.sub(INVALID_SHEET_CHARS, '', name).strip()
    return cleaned[:31] if len(cleaned) > 31 else cleaned


def read_client_info_ws(ws):
    def cell(r, c):
        return ws.cell(row=r, column=c).value
    return {
        'phone': cell(2, 2) or '',
        'adresse': cell(INFO_ROWS['adresse'], 2) or '',
        'ville': cell(INFO_ROWS['ville'], 2) or '',
        'province': cell(INFO_ROWS['province'], 2) or '',
        'code_postal': cell(INFO_ROWS['code_postal'], 2) or '',
        'courriel': cell(INFO_ROWS['courriel'], 2) or '',
    }


def read_invoices_ws(ws):
    invoices = []
    r = 2
    max_row = ws.max_row
    while r <= max_row:
        num = ws.cell(row=r, column=3).value
        date_f = ws.cell(row=r, column=4).value
        echeance = ws.cell(row=r, column=5).value
        montant = ws.cell(row=r, column=6).value
        notes = ws.cell(row=r, column=11).value
        if num is not None and montant is not None:
            due = echeance.date() if isinstance(echeance, datetime.datetime) else echeance
            df = date_f.date() if isinstance(date_f, datetime.datetime) else date_f
            invoices.append({
                'numero': str(num),
                'date_facture': df.strftime('%Y-%m-%d') if isinstance(df, datetime.date) else (str(df) if df else ''),
                'echeance': due.strftime('%Y-%m-%d') if isinstance(due, datetime.date) else (str(due) if due else ''),
                'montant': float(montant),
                'notes': notes or '',
            })
        r += 1
    return invoices


def import_excel_into_db():
    """Importe une seule fois toutes les données de l'Excel existant dans la base SQLite."""
    print("Premier démarrage : import des données depuis Excel (peut prendre ~30s)...")
    wb = openpyxl.load_workbook(EXCEL_PATH, data_only=False)
    sommaire = wb[SOMMAIRE_SHEET]

    conn = get_conn()
    r = 3
    n_clients = 0
    n_invoices = 0
    used_sheet_names = set()
    while sommaire.cell(row=r, column=1).value is not None:
        name = sommaire.cell(row=r, column=1).value
        # Le nom d'onglet réel peut différer d'une simple troncature du nom du
        # client (deux clients peuvent tronquer sur le même nom) — on lit donc
        # le vrai nom d'onglet directement dans la formule existante du Sommaire.
        formula = sommaire.cell(row=r, column=2).value  # ex: ="'SheetName'!G2"
        sheet_name = None
        if isinstance(formula, str):
            m = re.match(r"^='([^']+)'!", formula)
            if m:
                sheet_name = m.group(1)
        if not sheet_name:
            sheet_name = safe_sheet_name(name)
        ws = wb[sheet_name] if sheet_name in wb.sheetnames else None
        if ws is not None and sheet_name in used_sheet_names:
            # collision improbable — on ne devrait jamais arriver ici puisqu'on lit
            # le vrai nom d'onglet, mais on se protège quand même
            ws = None
        if ws is not None:
            used_sheet_names.add(sheet_name)
            info = read_client_info_ws(ws)
            conn.execute(
                "INSERT OR REPLACE INTO clients(name, sheet_name, phone, adresse, ville, province, code_postal, courriel) "
                "VALUES (?,?,?,?,?,?,?,?)",
                (name, sheet_name, info['phone'], info['adresse'], info['ville'], info['province'],
                 info['code_postal'], info['courriel'])
            )
            n_clients += 1
            for inv in read_invoices_ws(ws):
                if inv['montant'] == 0 and not inv['numero']:
                    continue
                conn.execute(
                    "INSERT INTO invoices(client_name, numero, date_facture, echeance, montant, notes) VALUES (?,?,?,?,?,?)",
                    (name, inv['numero'], inv['date_facture'], inv['echeance'], inv['montant'], inv['notes'])
                )
                n_invoices += 1
        r += 1

    counter_cell = sommaire.cell(row=2, column=13).value  # M2 : dernier numéro d'état de compte
    try:
        counter_val = int(counter_cell or 0)
    except (TypeError, ValueError):
        counter_val = 0
    conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('statement_counter', ?)", (str(counter_val),))
    conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('dirty', '0')")
    conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('last_sync', ?)",
                 (datetime.datetime.now().isoformat(),))
    conn.commit()
    conn.close()
    print(f"Import terminé : {n_clients} clients, {n_invoices} factures.")


def create_blank_excel_template(path):
    """Crée un classeur Excel neuf (aucun client) avec la structure minimale
    attendue par l'app : onglets Modèle / Sommaire / LOG_ENVOIS. Utilisé au
    tout premier démarrage sur un ordinateur qui n'a jamais eu de fichier
    Excel (nouvelle installation) — toutes les formules et le contenu réel
    de chaque onglet client sont de toute façon régénérés à partir de la
    base SQLite à chaque synchronisation (write_client_sheet/export_to_excel),
    donc ce modèle n'a besoin que d'exister, pas d'être élaboré."""
    wb = openpyxl.Workbook()
    modele = wb.active
    modele.title = MODELE_SHEET
    modele.cell(row=1, column=1, value='Client')
    modele.cell(row=1, column=2, value='Numéro de téléphone')
    modele.cell(row=1, column=3, value='Numéro de facture')
    modele.cell(row=1, column=4, value='Date de facture ')
    modele.cell(row=1, column=5, value='Échéance ')
    modele.cell(row=1, column=6, value='Montant')
    modele.cell(row=1, column=7, value='0-30 jours')
    modele.cell(row=1, column=8, value='31-60 jours')
    modele.cell(row=1, column=9, value='61-90 jours')
    modele.cell(row=1, column=10, value='90+ jours')
    modele.cell(row=1, column=11, value='Notes / Suivi')
    modele.cell(row=1, column=12, value='Payé')
    modele.cell(row=1, column=13, value='Solde')

    sommaire = wb.create_sheet(SOMMAIRE_SHEET)
    sommaire.cell(row=1, column=1, value='Client')
    sommaire.cell(row=1, column=2, value='0-30 jours')
    sommaire.cell(row=1, column=3, value='31-60 jours')
    sommaire.cell(row=1, column=4, value='61-90 jours')
    sommaire.cell(row=1, column=5, value='90+ jours')
    sommaire.cell(row=1, column=6, value='Total')
    sommaire.cell(row=1, column=7, value='Vérfication')
    sommaire.cell(row=2, column=1, value='Sommaire')
    # Ligne 2 (sommes) et lignes clients (3+) sont vides ici : elles sont
    # entièrement régénérées par export_to_excel() dès la première synchronisation.

    log_ws = wb.create_sheet(LOG_SHEET)
    log_ws.cell(row=1, column=1, value='Date')
    log_ws.cell(row=1, column=2, value='Client')
    log_ws.cell(row=1, column=3, value='Courriel')
    log_ws.cell(row=1, column=4, value='Total')
    log_ws.cell(row=1, column=5, value='Statut')
    log_ws.cell(row=1, column=6, value='Note')

    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
    print(f"Nouveau classeur Excel créé (installation neuve) : {path}")


def ensure_db_ready():
    is_new = not DB_PATH.exists()
    init_db_schema()
    if is_new:
        import_excel_into_db()


# ============================================================
# Aging (tranches d'âge) — logique identique aux formules du classeur
# ============================================================
def compute_bucket(today, echeance_str, montant):
    if not echeance_str:
        return {'g': 0.0, 'h': 0.0, 'i': 0.0, 'j': 0.0}
    try:
        echeance = datetime.datetime.strptime(echeance_str, '%Y-%m-%d').date()
    except ValueError:
        return {'g': 0.0, 'h': 0.0, 'i': 0.0, 'j': 0.0}
    diff = (today - echeance).days
    g = montant if today <= echeance else 0.0
    h = montant if 0 < diff <= 30 else 0.0
    i = montant if 30 < diff <= 60 else 0.0
    j = montant if diff > 60 else 0.0
    return {'g': g, 'h': h, 'i': i, 'j': j}


def invoices_with_buckets(rows, ref_date=None):
    """Ajoute à chaque facture son solde restant (montant - montant payé, s'il y a eu un
    paiement partiel ou total) et sa tranche d'âge calculée sur ce solde restant — pas
    sur le montant facturé au complet.

    Pour un rapport d'âge d'un mois PASSÉ (ref_date fourni) : si le paiement enregistré
    (date_paiement) est survenu APRÈS ref_date, on ne le soustrait pas du solde — la
    facture apparaît alors comme elle l'était réellement à cette date-là, sans tenir
    compte d'un paiement reçu depuis. Pour la vue courante (ref_date=None), le paiement
    est toujours pris en compte normalement."""
    today = ref_date or datetime.date.today()
    today_str = today.strftime('%Y-%m-%d')
    out = []
    for r in rows:
        d = dict(r)
        montant_paye_total = d.get('montant_paye') or 0.0
        date_paiement = d.get('date_paiement') or ''
        if montant_paye_total and date_paiement and date_paiement > today_str:
            montant_paye_effectif = 0.0
        else:
            montant_paye_effectif = montant_paye_total
        solde = d['montant'] - montant_paye_effectif
        d['montant_paye'] = montant_paye_total
        d['date_paiement'] = date_paiement
        d['solde'] = solde
        d['bucket'] = compute_bucket(today, d['echeance'], solde)
        out.append(d)
    return out


def sum_totals(invoices):
    """totals['montant'] représente le solde total dû (après paiements partiels) — le nom
    est conservé pour ne pas casser le reste du code qui l'utilise comme 'montant dû'."""
    totals = {'montant': 0.0, 'g': 0.0, 'h': 0.0, 'i': 0.0, 'j': 0.0}
    for inv in invoices:
        totals['montant'] += inv.get('solde', inv['montant'])
        for k in ('g', 'h', 'i', 'j'):
            totals[k] += inv['bucket'][k]
    return totals


# ============================================================
# Accès aux données (rapide, SQLite)
# ============================================================
def db_list_clients():
    conn = get_conn()
    clients = conn.execute("SELECT name, courriel FROM clients ORDER BY name COLLATE NOCASE").fetchall()
    result = []
    for c in clients:
        rows = conn.execute("SELECT * FROM invoices WHERE client_name=?", (c['name'],)).fetchall()
        totals = sum_totals(invoices_with_buckets(rows))
        result.append({'name': c['name'], 'courriel': c['courriel'] or '', 'solde': round(totals['montant'], 2)})
    conn.close()
    return result


def db_client_detail(name):
    conn = get_conn()
    c = conn.execute("SELECT * FROM clients WHERE name=?", (name,)).fetchone()
    if c is None:
        conn.close()
        return None
    rows = conn.execute("SELECT * FROM invoices WHERE client_name=? ORDER BY id", (name,)).fetchall()
    conn.close()
    invoices = invoices_with_buckets(rows)
    totals = sum_totals(invoices)
    info = {'phone': c['phone'] or '', 'adresse': c['adresse'] or '', 'ville': c['ville'] or '',
            'province': c['province'] or '', 'code_postal': c['code_postal'] or '', 'courriel': c['courriel'] or ''}
    return {'name': c['name'], 'info': info, 'invoices': invoices, 'totals': totals}


def db_create_client(name, phone, adresse, ville, province, code_postal, courriel):
    conn = get_conn()
    existing = conn.execute("SELECT 1 FROM clients WHERE name=?", (name,)).fetchone()
    if existing:
        conn.close()
        raise RuntimeError("Ce client existe déjà.")
    base_sheet_name = safe_sheet_name(name)
    sheet_name = base_sheet_name
    suffix = 2
    while conn.execute("SELECT name FROM clients WHERE sheet_name=?", (sheet_name,)).fetchone():
        # collision (deux noms différents tronquent pareil) : on distingue avec un suffixe
        tail = f"_{suffix}"
        sheet_name = base_sheet_name[:31 - len(tail)] + tail
        suffix += 1
    conn.execute(
        "INSERT INTO clients(name, sheet_name, phone, adresse, ville, province, code_postal, courriel) VALUES (?,?,?,?,?,?,?,?)",
        (name, sheet_name, phone or '', adresse or '', ville or '', province or 'Qc', code_postal or '', courriel or '')
    )
    conn.commit()
    conn.close()
    mark_dirty()
    return sheet_name


CLIENT_FIELD_LABELS = {
    'name': "Nom", 'courriel': "Courriel", 'phone': "Téléphone", 'adresse': "Adresse",
    'ville': "Ville", 'province': "Province", 'code_postal': "Code postal",
}


def _unique_sheet_name(conn, name, exclude_client=None):
    """Nom d'onglet Excel valide et unique (insensible à la casse, comme
    Excel) parmi les clients — en excluant éventuellement le client lui-même
    (cas d'un renommage) — et jamais égal à un onglet système."""
    reserved = {MODELE_SHEET.lower(), SOMMAIRE_SHEET.lower(), LOG_SHEET.lower()}
    base = safe_sheet_name(name) or "Client"
    candidate = base
    suffix = 2
    while True:
        if candidate.lower() not in reserved:
            row = conn.execute(
                "SELECT name FROM clients WHERE sheet_name = ? COLLATE NOCASE AND name <> ?",
                (candidate, exclude_client if exclude_client is not None else '\x00')
            ).fetchone()
            if row is None:
                return candidate
        tail = f"_{suffix}"
        candidate = base[:31 - len(tail)] + tail
        suffix += 1


def _queue_sheet_delete(conn, sheet):
    """Mémorise un onglet Excel à supprimer à la prochaine synchronisation
    (client fusionné dans un autre)."""
    row = conn.execute("SELECT value FROM meta WHERE key='pending_sheet_deletes'").fetchone()
    try:
        pending = json.loads(row['value']) if row and row['value'] else []
    except Exception:
        pending = []
    if sheet and sheet not in pending:
        pending.append(sheet)
    conn.execute("INSERT INTO meta(key,value) VALUES('pending_sheet_deletes', ?) "
                 "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (json.dumps(pending, ensure_ascii=False),))


CLIENT_INFO_FIELDS = ('phone', 'adresse', 'ville', 'province', 'code_postal', 'courriel')


def db_merge_clients(source, target, username):
    """Fusionne le client `source` dans `target` : factures, liens Lightspeed,
    paiements traités et noms reconnus passent à `target` ; ses coordonnées
    vides sont complétées par celles de `source` ; `source` est supprimé (son
    onglet Excel le sera à la prochaine synchronisation) et son nom devient un
    nom reconnu de `target`. Une sauvegarde des comptes à recevoir est prise avant."""
    conn = get_conn()
    s = conn.execute("SELECT * FROM clients WHERE name=?", (source,)).fetchone()
    t = conn.execute("SELECT * FROM clients WHERE name=?", (target,)).fetchone()
    conn.close()
    if s is None or t is None:
        raise RuntimeError("Client introuvable.")
    if source == target:
        raise RuntimeError("Choisis deux clients différents.")
    s, t = dict(s), dict(t)
    backup_id = db_backup_scope('ar', f"Avant fusion de « {source} » dans « {target} »", username)
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    conn = get_conn()
    try:
        n_inv = conn.execute("SELECT COUNT(*) n FROM invoices WHERE client_name=?", (source,)).fetchone()['n']
        filled = []
        for f in CLIENT_INFO_FIELDS:
            if not (t.get(f) or '').strip() and (s.get(f) or '').strip():
                conn.execute(f"UPDATE clients SET {f}=? WHERE name=?", (s[f], target))
                filled.append(f)
        conn.execute("UPDATE invoices SET client_name=? WHERE client_name=?", (target, source))
        conn.execute("UPDATE ls_ar_customers SET client_name=? WHERE client_name=?", (target, source))
        conn.execute("UPDATE ls_ar_payments SET client_name=? WHERE client_name=?", (target, source))
        conn.execute("UPDATE ls_ar_aliases SET client_name=? WHERE client_name=?", (target, source))
        if _norm_credit_name(source) != _norm_credit_name(target):
            conn.execute("INSERT OR REPLACE INTO ls_ar_aliases(alias, display, client_name, created_at) "
                         "VALUES (?,?,?,?)", (_norm_credit_name(source), source, target, now))
        conn.execute("DELETE FROM clients WHERE name=?", (source,))
        if s.get('sheet_name'):
            _queue_sheet_delete(conn, s['sheet_name'])
        conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('dirty', '1')")
        conn.commit()
    finally:
        conn.close()
    return {'invoices': n_inv, 'filled': filled, 'backup_id': backup_id}


def db_client_ls_links(name):
    conn = get_conn()
    try:
        customers = [dict(r) for r in conn.execute(
            "SELECT ls_customer_id, ls_name, linked_at FROM ls_ar_customers WHERE client_name=? "
            "ORDER BY linked_at", (name,)).fetchall()]
        aliases = [dict(r) for r in conn.execute(
            "SELECT alias, display, created_at FROM ls_ar_aliases WHERE client_name=? ORDER BY created_at",
            (name,)).fetchall()]
    finally:
        conn.close()
    return {'customers': customers, 'aliases': aliases}


def _queue_sheet_rename(conn, old_sheet, new_sheet):
    """Mémorise un renommage d'onglet Excel à appliquer à la prochaine
    synchronisation (le fichier Excel n'est jamais modifié directement ici)."""
    row = conn.execute("SELECT value FROM meta WHERE key='pending_sheet_renames'").fetchone()
    try:
        pending = json.loads(row['value']) if row and row['value'] else []
    except Exception:
        pending = []
    pending.append([old_sheet, new_sheet])
    conn.execute(
        "INSERT INTO meta(key,value) VALUES('pending_sheet_renames', ?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (json.dumps(pending, ensure_ascii=False),)
    )


def db_update_client(old_name, new_name, phone, adresse, ville, province, code_postal, courriel):
    """Modifie un client existant. Un changement de nom est appliqué en une
    seule transaction au client ET à toutes ses factures. Retourne
    (nouveau_nom, liste des changements [(champ, avant, après)])."""
    new_name = (new_name or '').strip()
    if not new_name:
        raise RuntimeError("Le nom du client est obligatoire.")
    new_values = {
        'name': new_name,
        'courriel': (courriel or '').strip(),
        'phone': (phone or '').strip(),
        'adresse': (adresse or '').strip(),
        'ville': (ville or '').strip(),
        'province': (province or '').strip() or 'Qc',
        'code_postal': (code_postal or '').strip(),
    }
    conn = get_conn()
    try:
        cur = conn.execute("SELECT * FROM clients WHERE name=?", (old_name,)).fetchone()
        if cur is None:
            raise RuntimeError("Client introuvable (il a peut-être déjà été renommé — recharge la page).")
        changes = [(k, cur[k] or '', v) for k, v in new_values.items() if (cur[k] or '') != v]
        if not changes:
            return old_name, []

        renamed = new_name != old_name
        sheet_name = cur['sheet_name']
        if renamed:
            dup = conn.execute(
                "SELECT name FROM clients WHERE name = ? COLLATE NOCASE AND name <> ?",
                (new_name, old_name)
            ).fetchone()
            if dup:
                raise RuntimeError(f"Un autre client porte déjà ce nom : « {dup['name']} ».")
            sheet_name = _unique_sheet_name(conn, new_name, exclude_client=old_name)

        # Les factures référencent clients(name) : on diffère la vérification
        # des clés étrangères à la fin de la transaction pour pouvoir changer
        # le nom des deux côtés.
        conn.execute("PRAGMA defer_foreign_keys = ON")
        conn.execute(
            "UPDATE clients SET name=?, sheet_name=?, phone=?, adresse=?, ville=?, province=?, "
            "code_postal=?, courriel=? WHERE name=?",
            (new_values['name'], sheet_name, new_values['phone'], new_values['adresse'],
             new_values['ville'], new_values['province'], new_values['code_postal'],
             new_values['courriel'], old_name)
        )
        if renamed:
            conn.execute("UPDATE invoices SET client_name=? WHERE client_name=?", (new_name, old_name))
            conn.execute("UPDATE ls_ar_customers SET client_name=? WHERE client_name=?", (new_name, old_name))
            conn.execute("UPDATE ls_ar_payments SET client_name=? WHERE client_name=?", (new_name, old_name))
            conn.execute("UPDATE ls_ar_aliases SET client_name=? WHERE client_name=?", (new_name, old_name))
            if _norm_credit_name(old_name) != _norm_credit_name(new_name):
                conn.execute("INSERT OR REPLACE INTO ls_ar_aliases(alias, display, client_name, created_at) "
                             "VALUES (?,?,?,?)", (_norm_credit_name(old_name), old_name, new_name,
                                                  datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            conn.execute("DELETE FROM ls_ar_aliases WHERE alias=?", (_norm_credit_name(new_name),))
            if sheet_name != cur['sheet_name']:
                _queue_sheet_rename(conn, cur['sheet_name'], sheet_name)
        conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('dirty', '1')")
        conn.commit()
        return new_name, changes
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _resolve_date_paiement(montant_paye, date_paiement, previous_date_paiement=None):
    """Détermine la date de paiement à enregistrer : si un montant payé est présent
    mais qu'aucune date n'a été fournie explicitement, on garde la date précédente
    si elle existe, sinon on utilise aujourd'hui (comportement par défaut, cohérent
    avec la migration initiale) — jamais None tant qu'il y a un montant payé, pour
    que les rapports d'âge de mois passés puissent trancher correctement."""
    if not montant_paye:
        return None
    if date_paiement:
        return date_paiement
    if previous_date_paiement:
        return previous_date_paiement
    return datetime.date.today().strftime('%Y-%m-%d')


def db_add_invoice(client_name, numero, date_facture, echeance, montant, notes,
                    montant_paye=0.0, date_paiement=None):
    conn = get_conn()
    c = conn.execute("SELECT 1 FROM clients WHERE name=?", (client_name,)).fetchone()
    if not c:
        conn.close()
        raise RuntimeError(f"Client introuvable : {client_name}")
    montant_paye = float(montant_paye or 0)
    date_paiement = _resolve_date_paiement(montant_paye, date_paiement)
    conn.execute(
        "INSERT INTO invoices(client_name, numero, date_facture, echeance, montant, notes, montant_paye, date_paiement) "
        "VALUES (?,?,?,?,?,?,?,?)",
        (client_name, str(numero), date_facture, echeance, float(montant), notes or '',
         montant_paye, date_paiement)
    )
    conn.commit()
    conn.close()
    mark_dirty()


def db_update_invoice(invoice_id, numero, date_facture, echeance, montant, notes,
                       montant_paye=0.0, date_paiement=None):
    conn = get_conn()
    existing = conn.execute("SELECT montant_paye, date_paiement FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    if not existing:
        conn.close()
        raise RuntimeError("Facture introuvable.")
    montant_paye = float(montant_paye or 0)
    montant_paye_a_change = abs((existing['montant_paye'] or 0.0) - montant_paye) > 0.005
    # Si le montant payé n'a pas changé, on garde la date déjà enregistrée (même si
    # aucune nouvelle date n'est fournie) ; s'il a changé sans date fournie, on
    # considère que ce changement vient d'être fait aujourd'hui.
    previous = existing['date_paiement'] if not montant_paye_a_change else None
    date_paiement = _resolve_date_paiement(montant_paye, date_paiement, previous)
    conn.execute(
        "UPDATE invoices SET numero=?, date_facture=?, echeance=?, montant=?, notes=?, "
        "montant_paye=?, date_paiement=? WHERE id=?",
        (str(numero), date_facture, echeance, float(montant), notes or '',
         montant_paye, date_paiement, invoice_id)
    )
    conn.commit()
    conn.close()
    mark_dirty()


def db_get_invoice(invoice_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def db_delete_invoice(invoice_id):
    conn = get_conn()
    existing = conn.execute("SELECT 1 FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    if not existing:
        conn.close()
        raise RuntimeError("Facture introuvable.")
    conn.execute("DELETE FROM invoices WHERE id=?", (invoice_id,))
    conn.commit()
    conn.close()
    mark_dirty()


def db_set_invoice_paid(invoice_id, paid, date_paiement=None):
    """Marque une facture comme entièrement payée (montant_paye = montant, avec la
    date de paiement fournie ou aujourd'hui par défaut) ou annule ce marquage (remet
    montant_paye et date_paiement à zéro/vide). Un paiement partiel déjà saisi
    manuellement est écrasé par cette action, dans les deux sens."""
    conn = get_conn()
    row = conn.execute("SELECT montant FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    if not row:
        conn.close()
        raise RuntimeError("Facture introuvable.")
    if paid:
        new_montant_paye = row['montant']
        new_date_paiement = date_paiement or datetime.date.today().strftime('%Y-%m-%d')
    else:
        new_montant_paye = 0.0
        new_date_paiement = None
    conn.execute("UPDATE invoices SET montant_paye=?, date_paiement=? WHERE id=?",
                 (new_montant_paye, new_date_paiement, invoice_id))
    conn.commit()
    conn.close()
    mark_dirty()


def db_next_statement_number():
    conn = get_conn()
    with _db_lock:
        row = conn.execute("SELECT value FROM meta WHERE key='statement_counter'").fetchone()
        current = int(row['value']) if row else 0
        new_val = current + 1
        conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('statement_counter', ?)", (str(new_val),))
        conn.commit()
    conn.close()
    mark_dirty()
    return f"{STATEMENT_PREFIX}{new_val:06d}"


def db_log_envoi(client, courriel, total, statut, note):
    conn = get_conn()
    conn.execute(
        "INSERT INTO log_envois(ts, client, courriel, total, statut, note, synced) VALUES (?,?,?,?,?,?,0)",
        (datetime.datetime.now().isoformat(), client, courriel, total, statut, note)
    )
    conn.commit()
    conn.close()
    mark_dirty()


# ============================================================
# Comptes de crédit (Lightspeed) — volet distinct des comptes à recevoir.
# Liste de clients avec limite de crédit / solde dû / dépôt, alimentée par un
# import initial (Excel/CSV) puis, chaque mois, par un import des mouvements
# (transactions) exportés de Lightspeed, qui met à jour les soldes.
# ============================================================
def _credit_client_display_name(row):
    prenom = (row.get('prenom_entreprise') or '').strip()
    nom = (row.get('nom') or '').strip()
    if nom and nom.lower() not in prenom.lower():
        return f"{prenom} {nom}".strip()
    return prenom or nom


def _norm_credit_name(s):
    return (s or '').strip().lower()


def db_list_credit_clients():
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM credit_clients ORDER BY prenom_entreprise COLLATE NOCASE, nom COLLATE NOCASE"
    ).fetchall()
    conn.close()
    out = []
    for r in rows:
        d = dict(r)
        d['display_name'] = _credit_client_display_name(d)
        out.append(d)
    return out


def db_get_credit_client(client_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM credit_clients WHERE id=?", (client_id,)).fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    d['display_name'] = _credit_client_display_name(d)
    return d


def db_credit_client_movements(client_id):
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM credit_movements WHERE credit_client_id=? ORDER BY date_mouvement, id",
        (client_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _credit_net_debt(row):
    """« Debt » net d'un compte (positif = doit, négatif = crédit/dépôt).
    Les fiches d'avant la 1.9.1 pouvaient avoir un solde négatif brut."""
    solde = float(row.get('solde') or 0.0)
    deposit = float(row.get('deposit') or 0.0)
    return solde if solde < 0 else solde - deposit


def _split_debt(debt):
    """Répartit un Debt net en (montant dû, dépôt)."""
    debt = round(float(debt), 2)
    return max(debt, 0.0), max(-debt, 0.0)


CREDIT_FIELD_LABELS = {
    'prenom_entreprise': "Prénom / entreprise", 'nom': "Nom", 'credit_limit': "Limite de crédit",
    'solde': "Montant dû", 'deposit': "Dépôt", 'notes': "Notes", 'no_sync': "Ne pas synchroniser",
}


def db_update_credit_client(client_id, data):
    """Modifie un compte de crédit. Retourne (avant, changements)."""
    conn = get_conn()
    try:
        cur = conn.execute("SELECT * FROM credit_clients WHERE id=?", (client_id,)).fetchone()
        if cur is None:
            raise RuntimeError("Compte introuvable.")
        cur = dict(cur)
        new = {}
        if 'prenom_entreprise' in data:
            v = (data.get('prenom_entreprise') or '').strip()
            if not v:
                raise RuntimeError("Le prénom / nom d'entreprise est obligatoire.")
            new['prenom_entreprise'] = v
        if 'nom' in data:
            new['nom'] = (data.get('nom') or '').strip() or None
        for k in ('credit_limit', 'solde', 'deposit'):
            if k in data:
                try:
                    val = round(_parse_money(data.get(k)), 2)
                except Exception:
                    raise RuntimeError(f"Montant invalide : {CREDIT_FIELD_LABELS[k]}.")
                if val < 0:
                    raise RuntimeError(f"{CREDIT_FIELD_LABELS[k]} ne peut pas être négatif.")
                new[k] = val
        if 'notes' in data:
            new['notes'] = (data.get('notes') or '').strip() or None
        if 'no_sync' in data:
            new['no_sync'] = 1 if data.get('no_sync') in (True, 1, '1', 'true', 'on') else 0
        changes = []
        for k, v in new.items():
            old = cur.get(k)
            if isinstance(v, float):
                if abs(float(old or 0) - v) >= 0.005:
                    changes.append((k, old, v))
            elif (old if old not in ('',) else None) != v:
                changes.append((k, old, v))
        if changes:
            sets = ", ".join(f"{k}=?" for k, _, _ in changes)
            conn.execute(f"UPDATE credit_clients SET {sets} WHERE id=?",
                         [v for _, _, v in changes] + [client_id])
            conn.commit()
        return cur, changes
    finally:
        conn.close()


def db_delete_credit_client(client_id):
    conn = get_conn()
    try:
        cur = conn.execute("SELECT * FROM credit_clients WHERE id=?", (client_id,)).fetchone()
        if cur is None:
            raise RuntimeError("Compte introuvable.")
        n = conn.execute("SELECT COUNT(*) c FROM credit_movements WHERE credit_client_id=?",
                         (client_id,)).fetchone()['c']
        conn.execute("DELETE FROM credit_movements WHERE credit_client_id=?", (client_id,))
        conn.execute("DELETE FROM credit_clients WHERE id=?", (client_id,))
        conn.commit()
        return dict(cur), n
    finally:
        conn.close()


def _apply_movement_delta(conn, client_id, delta):
    """Ajuste le solde d'un compte de « delta » (positif = le client doit plus)."""
    c = conn.execute("SELECT * FROM credit_clients WHERE id=?", (client_id,)).fetchone()
    if c is None or abs(delta) < 0.005:
        return
    solde, deposit = _split_debt(_credit_net_debt(dict(c)) + delta)
    conn.execute("UPDATE credit_clients SET solde=?, deposit=? WHERE id=?", (solde, deposit, client_id))


def db_update_credit_movement(movement_id, data):
    """Modifie un mouvement ; le solde du client est ajusté de la différence
    de montant. Retourne (avant, après)."""
    conn = get_conn()
    try:
        m = conn.execute("SELECT * FROM credit_movements WHERE id=?", (movement_id,)).fetchone()
        if m is None:
            raise RuntimeError("Mouvement introuvable.")
        m = dict(m)
        date_mv = (data.get('date_mouvement') or '').strip() or None
        if date_mv:
            try:
                datetime.date.fromisoformat(date_mv)
            except Exception:
                raise RuntimeError("Date invalide (format attendu : AAAA-MM-JJ).")
        montant = round(_parse_money(data.get('montant')), 2)
        after = {
            'date_mouvement': date_mv,
            'type': (data.get('type') or '').strip() or None,
            'sale': (data.get('sale') or '').strip() or None,
            'montant': montant,
        }
        conn.execute("UPDATE credit_movements SET date_mouvement=?, type=?, sale=?, montant=? WHERE id=?",
                     (after['date_mouvement'], after['type'], after['sale'], after['montant'], movement_id))
        _apply_movement_delta(conn, m['credit_client_id'], montant - float(m['montant'] or 0))
        conn.commit()
        return m, after
    finally:
        conn.close()


def db_delete_credit_movement(movement_id):
    """Supprime un mouvement et annule son effet sur le solde du client."""
    conn = get_conn()
    try:
        m = conn.execute("SELECT * FROM credit_movements WHERE id=?", (movement_id,)).fetchone()
        if m is None:
            raise RuntimeError("Mouvement introuvable.")
        m = dict(m)
        conn.execute("DELETE FROM credit_movements WHERE id=?", (movement_id,))
        _apply_movement_delta(conn, m['credit_client_id'], -float(m['montant'] or 0))
        conn.commit()
        return m
    finally:
        conn.close()


def db_import_credit_clients(rows):
    """Remplace ENTIÈREMENT la liste des comptes de crédit à partir de lignes
    {prenom_entreprise, nom, credit_limit, solde, deposit, ligne_source}. Utilisé
    pour l'import initial (ou une réinitialisation complète demandée
    explicitement par un administrateur) — jamais appelé automatiquement, et
    n'affecte jamais l'historique des mouvements déjà importés (qui reste lié
    par credit_client_id — une réinitialisation supprime donc aussi, en
    cascade, tout l'historique des mouvements, car les anciens clients
    n'existent plus)."""
    conn = get_conn()
    conn.execute("DELETE FROM credit_movements")
    conn.execute("DELETE FROM credit_clients")
    conn.execute("DELETE FROM ls_pending_accounts")
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    for r in rows:
        conn.execute(
            "INSERT INTO credit_clients(prenom_entreprise, nom, credit_limit, solde, deposit, ligne_source, created_at) "
            "VALUES (?,?,?,?,?,?,?)",
            (r['prenom_entreprise'], r.get('nom') or None, float(r.get('credit_limit') or 0),
             float(r.get('solde') or 0), float(r.get('deposit') or 0),
             str(r['ligne_source']) if r.get('ligne_source') not in (None, '') else None, now)
        )
    conn.commit()
    count = conn.execute("SELECT COUNT(*) c FROM credit_clients").fetchone()['c']
    conn.close()
    mark_dirty()
    return count


def db_import_credit_movements(rows):
    """Importe des mouvements (transactions Lightspeed). Un mouvement déjà
    importé (même lightspeed_id) est ignoré — permet de réimporter le même
    fichier par erreur sans dupliquer. Les autres sont ajoutés et le solde du
    client correspondant (trouvé par nom, créé automatiquement si absent) est
    mis à jour. Retourne un résumé {imported, skipped, created_clients}."""
    conn = get_conn()
    existing_ids = set(
        r['lightspeed_id'] for r in conn.execute(
            "SELECT lightspeed_id FROM credit_movements WHERE lightspeed_id IS NOT NULL"
        ).fetchall()
    )
    clients = conn.execute("SELECT * FROM credit_clients").fetchall()
    by_name = {}
    for c in clients:
        cd = dict(c)
        by_name[_norm_credit_name(_credit_client_display_name(cd))] = cd

    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    imported = 0
    skipped = 0
    created_clients = 0
    locked = 0

    for r in rows:
        lsid = str(r.get('lightspeed_id') or '').strip() or None
        if lsid and lsid in existing_ids:
            skipped += 1
            continue
        customer = (r.get('customer') or '').strip()
        key = _norm_credit_name(customer)
        client = by_name.get(key)
        if client and client.get('no_sync'):
            locked += 1
            continue
        if not client:
            cur = conn.execute(
                "INSERT INTO credit_clients(prenom_entreprise, nom, credit_limit, solde, deposit, notes, created_at) "
                "VALUES (?,?,?,?,?,?,?)",
                (customer or '(client inconnu)', None, 0, 0, 0,
                 "Créé automatiquement lors d'un import de mouvements Lightspeed — "
                 "aucun client existant ne correspond à ce nom, à vérifier.", now)
            )
            client = {'id': cur.lastrowid, 'solde': 0.0, 'deposit': 0.0}
            by_name[key] = client
            created_clients += 1

        montant = float(r.get('montant') or 0)
        conn.execute(
            "INSERT INTO credit_movements(credit_client_id, lightspeed_id, date_mouvement, montant, type, sale, "
            "customer_brut, notes, imported_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (client['id'], lsid, r.get('date'), montant, r.get('type'), r.get('sale'),
             customer, r.get('notes') or '', now)
        )
        client['solde'], client['deposit'] = _split_debt(_credit_net_debt(client) + montant)
        conn.execute("UPDATE credit_clients SET solde=?, deposit=? WHERE id=?",
                     (client['solde'], client['deposit'], client['id']))
        if lsid:
            existing_ids.add(lsid)
        imported += 1

    conn.commit()
    conn.close()
    mark_dirty()
    return {'imported': imported, 'skipped': skipped, 'created_clients': created_clients, 'locked': locked}


def db_update_credit_balances(rows):
    """Met à jour les soldes des comptes de crédit à partir d'un « instantané »
    mensuel Lightspeed (une ligne par client avec sa limite de crédit et son
    solde dû ACTUELS — pas une liste de transactions). Pour chaque ligne : le
    client est trouvé par nom (prénom/entreprise + nom, comparaison insensible
    à la casse/accents), créé automatiquement s'il n'existe pas encore, puis
    sa limite de crédit et son solde sont remplacés par les valeurs du fichier.
    Si le solde change, un mouvement synthétique (type « Ajustement mensuel »)
    est enregistré pour garder un historique consultable dans la fiche client.
    Retourne {updated, unchanged, created_clients}."""
    conn = get_conn()
    clients = conn.execute("SELECT * FROM credit_clients").fetchall()
    by_name = {}
    for c in clients:
        cd = dict(c)
        by_name[_norm_credit_name(_credit_client_display_name(cd))] = cd

    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    today_str = datetime.date.today().strftime('%Y-%m-%d')
    updated = 0
    unchanged = 0
    created_clients = 0
    locked = 0

    for r in rows:
        prenom = (r.get('prenom_entreprise') or '').strip()
        nom = (r.get('nom') or '').strip() or None
        display = _credit_client_display_name({'prenom_entreprise': prenom, 'nom': nom})
        key = _norm_credit_name(display)
        if not key:
            continue
        new_limit = float(r.get('credit_limit') or 0)
        # « Debt » Lightspeed : positif = montant dû ; négatif = crédit en
        # faveur du client, conservé comme dépôt (montant dû à 0).
        debt = float(r.get('solde') or 0)
        new_solde = max(debt, 0.0)
        new_deposit = max(-debt, 0.0)
        client = by_name.get(key)
        if client and client.get('no_sync'):
            locked += 1
            continue
        if not client:
            cur = conn.execute(
                "INSERT INTO credit_clients(prenom_entreprise, nom, credit_limit, solde, deposit, notes, created_at) "
                "VALUES (?,?,?,?,?,?,?)",
                (prenom or '(client inconnu)', nom, new_limit, new_solde, 0,
                 "Créé automatiquement lors d'un import d'instantané mensuel Lightspeed — "
                 "aucun client existant ne correspond à ce nom, à vérifier.", now)
            )
            client = {'id': cur.lastrowid, 'solde': 0.0, 'deposit': 0.0, 'credit_limit': 0.0}
            by_name[key] = client
            created_clients += 1

        old_solde = float(client.get('solde') or 0.0)
        old_deposit = float(client.get('deposit') or 0.0)
        # Ancien « Debt » équivalent : les fiches importées avant la 1.9.1
        # pouvaient avoir un solde négatif (Debt brut) — on le reprend tel quel
        # pour ne pas créer de faux mouvement lors de la conversion en dépôt.
        old_debt = old_solde if old_solde < 0 else old_solde - old_deposit
        delta = round(debt - old_debt, 2)
        conn.execute("UPDATE credit_clients SET credit_limit=?, solde=?, deposit=? WHERE id=?",
                     (new_limit, new_solde, new_deposit, client['id']))
        client['solde'] = new_solde
        client['deposit'] = new_deposit
        client['credit_limit'] = new_limit

        if abs(delta) >= 0.01:
            conn.execute(
                "INSERT INTO credit_movements(credit_client_id, lightspeed_id, date_mouvement, montant, type, sale, "
                "customer_brut, notes, imported_at) VALUES (?,?,?,?,?,?,?,?,?)",
                (client['id'], None, today_str, delta, 'Ajustement mensuel', None, display,
                 f"Instantané Lightspeed importé le {today_str} : Debt {old_debt:.2f}$ -> {debt:.2f}$", now)
            )
            updated += 1
        else:
            unchanged += 1

    conn.commit()
    conn.close()
    mark_dirty()
    return {'updated': updated, 'unchanged': unchanged, 'created_clients': created_clients, 'locked': locked}


def db_capture_credit_snapshot(label, source=None):
    """Prend une photo de l'état COMPLET de la liste des comptes de crédit
    (tous les clients, avec leur limite/solde/dépôt du moment) et la range
    dans credit_snapshots/credit_snapshot_lines. Appelé après chaque import
    (initial, instantané mensuel ou journal de transactions) pour garder un
    rapport téléchargeable par import, même si plusieurs imports ont lieu
    dans le même mois."""
    conn = get_conn()
    clients = conn.execute(
        "SELECT * FROM credit_clients ORDER BY prenom_entreprise COLLATE NOCASE, nom COLLATE NOCASE"
    ).fetchall()
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    total_limit = sum((c['credit_limit'] or 0) for c in clients)
    total_solde = sum((c['solde'] or 0) for c in clients)
    total_deposit = sum((c['deposit'] or 0) for c in clients)
    cur = conn.execute(
        "INSERT INTO credit_snapshots(created_at, label, source, client_count, total_credit_limit, "
        "total_solde, total_deposit) VALUES (?,?,?,?,?,?,?)",
        (now, label, source, len(clients), total_limit, total_solde, total_deposit)
    )
    snap_id = cur.lastrowid
    for c in clients:
        conn.execute(
            "INSERT INTO credit_snapshot_lines(snapshot_id, prenom_entreprise, nom, credit_limit, solde, deposit) "
            "VALUES (?,?,?,?,?,?)",
            (snap_id, c['prenom_entreprise'], c['nom'], c['credit_limit'] or 0, c['solde'] or 0, c['deposit'] or 0)
        )
    conn.commit()
    conn.close()
    mark_dirty()
    return snap_id


def db_list_credit_snapshots():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM credit_snapshots ORDER BY created_at DESC, id DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def db_get_credit_snapshot(snapshot_id):
    conn = get_conn()
    header = conn.execute("SELECT * FROM credit_snapshots WHERE id=?", (snapshot_id,)).fetchone()
    if not header:
        conn.close()
        return None, None
    lines = conn.execute(
        "SELECT * FROM credit_snapshot_lines WHERE snapshot_id=? "
        "ORDER BY prenom_entreprise COLLATE NOCASE, nom COLLATE NOCASE",
        (snapshot_id,)
    ).fetchall()
    conn.close()
    out_lines = []
    for l in lines:
        d = dict(l)
        d['display_name'] = _credit_client_display_name(d)
        out_lines.append(d)
    return dict(header), out_lines


# ============================================================
# Sauvegardes des comptes de crédit avant chaque importation (1.10.1)
# ------------------------------------------------------------
# Avant une réinitialisation, un import de mouvements ou une synchronisation
# Lightspeed, les tables des comptes de crédit sont copiées dans un petit
# fichier SQLite (C:\DBouxpCR\Backups_comptes_credit). Un administrateur peut
# ensuite remettre les comptes exactement comme avant. Les comptes à recevoir
# (factures) ne sont jamais touchés par une restauration.
# ============================================================
CREDIT_BACKUP_DIR = BASE_DIR / "Backups_comptes_credit"
CREDIT_BACKUP_KEEP = 60
CREDIT_BACKUP_TABLES = ('credit_clients', 'credit_movements', 'ls_pending_accounts')

# 1.11.0 : même mécanisme pour les comptes à recevoir (clients + factures).
# Table credit_backups, colonne scope : 'credit' ou 'ar'. Pour 'ar',
# movement_count = nombre de factures, total_solde = solde total à recevoir.
BACKUP_SCOPES = {
    'credit': {
        'dir': CREDIT_BACKUP_DIR, 'prefix': 'comptes_credit',
        'tables': CREDIT_BACKUP_TABLES,
        # ordre d'effacement (enfants d'abord) ; la réinsertion se fait à l'envers
        'delete_order': ('credit_movements', 'ls_pending_accounts', 'credit_clients'),
        'totals': ("SELECT COUNT(*) n, COALESCE(SUM(solde),0) s, COALESCE(SUM(deposit),0) d FROM credit_clients",
                   "SELECT COUNT(*) n FROM credit_movements"),
        'main_table': 'credit_clients',
    },
    'ar': {
        'dir': BASE_DIR / "Backups_comptes_recevoir", 'prefix': 'comptes_recevoir',
        'tables': ('clients', 'invoices', 'ls_ar_customers', 'ls_ar_ignored', 'ls_ar_payments', 'ls_ar_aliases'),
        'delete_order': ('invoices', 'ls_ar_customers', 'ls_ar_ignored', 'ls_ar_payments', 'ls_ar_aliases',
                         'clients'),
        'totals': ("SELECT (SELECT COUNT(*) FROM clients) n, "
                   "COALESCE((SELECT SUM(COALESCE(montant,0) - COALESCE(montant_paye,0)) FROM invoices),0) s, "
                   "0 d", "SELECT COUNT(*) n FROM invoices"),
        'main_table': 'clients',
    },
}


def db_backup_credit(label, username):
    return db_backup_scope('credit', label, username)


def db_backup_scope(scope, label, username):
    """Copie les tables du module (scope) dans un fichier de sauvegarde.
    Retourne l'id de la sauvegarde. Lève RuntimeError si la copie échoue
    (l'importation qui suit doit alors être annulée)."""
    cfg = BACKUP_SCOPES[scope]
    cfg['dir'].mkdir(exist_ok=True)
    now = datetime.datetime.now()
    path = cfg['dir'] / f"{cfg['prefix']}_{now.strftime('%Y-%m-%d_%Hh%M%S')}_{secrets.token_hex(3)}.db"
    conn = get_conn()
    try:
        conn.execute("ATTACH DATABASE ? AS bk", (str(path),))
        conn.execute("BEGIN")
        for t in cfg['tables']:
            conn.execute(f"CREATE TABLE bk.{t} AS SELECT * FROM main.{t}")
        conn.execute("COMMIT")
        conn.execute("DETACH DATABASE bk")
        t = conn.execute(cfg['totals'][0]).fetchone()
        mv = conn.execute(cfg['totals'][1]).fetchone()['n']
        cur = conn.execute(
            "INSERT INTO credit_backups(created_at, label, username, filename, client_count, movement_count, "
            "total_solde, total_deposit, scope) VALUES (?,?,?,?,?,?,?,?,?)",
            (now.strftime('%Y-%m-%d %H:%M:%S'), label, username or '?', path.name,
             t['n'], mv, round(t['s'], 2), round(t['d'], 2), scope))
        conn.commit()
        backup_id = cur.lastrowid
    except Exception as e:
        traceback.print_exc()
        try:
            conn.rollback()
        except Exception:
            pass
        conn.close()
        try:
            path.unlink()
        except OSError:
            pass
        what = "des comptes de crédit" if scope == 'credit' else "des comptes à recevoir"
        raise RuntimeError(f"La sauvegarde {what} a échoué ({e}) : opération annulée, "
                           "aucune donnée n'a été modifiée.")
    conn.close()
    try:
        _prune_scope_backups(scope)
    except Exception:
        traceback.print_exc()  # le ménage des vieilles sauvegardes ne doit jamais bloquer l'opération
    return backup_id


def _backup_path(row):
    return BACKUP_SCOPES[row['scope'] if 'scope' in row.keys() else 'credit']['dir'] / row['filename']


def _prune_scope_backups(scope):
    conn = get_conn()
    try:
        old = conn.execute("SELECT * FROM credit_backups WHERE scope=? ORDER BY id DESC LIMIT -1 OFFSET ?",
                           (scope, CREDIT_BACKUP_KEEP)).fetchall()
        for r in old:
            try:
                _backup_path(r).unlink()
            except OSError:
                pass
            conn.execute("DELETE FROM credit_backups WHERE id=?", (r['id'],))
        conn.commit()
    finally:
        conn.close()


def db_discard_credit_backup(backup_id):
    """Supprime une sauvegarde devenue inutile (importation sans aucun changement)."""
    if not backup_id:
        return
    conn = get_conn()
    try:
        r = conn.execute("SELECT * FROM credit_backups WHERE id=?", (backup_id,)).fetchone()
        if r:
            try:
                _backup_path(r).unlink()
            except OSError:
                pass
            conn.execute("DELETE FROM credit_backups WHERE id=?", (backup_id,))
            conn.commit()
    finally:
        conn.close()


def db_list_credit_backups(scope='credit'):
    conn = get_conn()
    rows = [dict(r) for r in conn.execute("SELECT * FROM credit_backups WHERE scope=? ORDER BY id DESC",
                                          (scope,)).fetchall()]
    conn.close()
    for r in rows:
        r['file_ok'] = _backup_path(r).exists()
    return rows


def db_restore_credit_backup(backup_id, username, scope='credit'):
    """Remet les tables du module (comptes de crédit, ou clients et factures
    des comptes à recevoir) telles qu'elles étaient dans la sauvegarde.
    L'état actuel est sauvegardé juste avant, pour pouvoir annuler la
    restauration."""
    cfg = BACKUP_SCOPES[scope]
    conn = get_conn()
    b = conn.execute("SELECT * FROM credit_backups WHERE id=? AND scope=?", (backup_id, scope)).fetchone()
    conn.close()
    if b is None:
        raise RuntimeError("Sauvegarde introuvable.")
    b = dict(b)
    path = _backup_path(b)
    if not path.exists():
        raise RuntimeError(f"Le fichier de sauvegarde est introuvable ({path}).")
    d, h = b['created_at'][:10], b['created_at'][11:16]
    pre_id = db_backup_scope(scope, f"Avant restauration de la sauvegarde du {d[8:10]}-{d[5:7]}-{d[:4]} {h}",
                             username)
    conn = get_conn()
    try:
        conn.execute("ATTACH DATABASE ? AS bk", (str(path),))
        bk_tables = {r['name'] for r in conn.execute("SELECT name FROM bk.sqlite_master WHERE type='table'")}
        if cfg['main_table'] not in bk_tables:
            raise RuntimeError("Fichier de sauvegarde invalide.")
        conn.execute("BEGIN")
        try:
            for t in cfg['delete_order']:
                conn.execute(f"DELETE FROM main.{t}")
            for t in reversed(cfg['delete_order']):
                if t not in bk_tables:
                    continue
                main_cols = [r['name'] for r in conn.execute(f"PRAGMA main.table_info({t})")]
                bk_cols = {r['name'] for r in conn.execute(f"PRAGMA bk.table_info({t})")}
                cols = ", ".join(c for c in main_cols if c in bk_cols)
                conn.execute(f"INSERT INTO main.{t} ({cols}) SELECT {cols} FROM bk.{t}")
            conn.execute("UPDATE credit_backups SET restored_at=?, restored_by=? WHERE id=?",
                         (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), username or '?', backup_id))
            conn.execute("COMMIT")
        except Exception:
            conn.execute("ROLLBACK")
            raise
    finally:
        try:
            conn.execute("DETACH DATABASE bk")
        except Exception:
            pass
        conn.close()
    mark_dirty()
    return b, pre_id


# ============================================================
# Lightspeed R-Series — connexion à l'API et synchronisation des comptes de
# crédit (1.10.0). Remplace l'export manuel « credit_account_listings » : Kubios
# lit directement les comptes de crédit (CreditAccount) et leurs clients
# (Customer) dans Lightspeed, puis met à jour limite / montant dû / dépôt.
# Chaque compte Kubios est relié à son compte Lightspeed par son identifiant
# (credit_clients.ls_credit_account_id) — les homonymes ne se mélangent plus.
# Les jetons et le secret sont gardés dans la table meta (comme le mot de
# passe SMTP).
# ============================================================
LS_AUTH_BASE = os.environ.get('LS_AUTH_BASE', 'https://cloud.lightspeedapp.com/auth/oauth')
LS_API_BASE = os.environ.get('LS_API_BASE', 'https://api.lightspeedapp.com/API/V3')
LS_SCOPE = 'employee:all'
LS_PAGE_LIMIT = 100
LS_AUTO_CHECK_SECONDS = 300
LS_SYNC_MOVEMENT_TYPE = 'Synchronisation Lightspeed'
LS_BALANCE_SIGNS = ('auto', 'positive_du', 'negative_du')
LS_AUTO_MODES = ('off', 'daily', 'month_end')  # désactivée / chaque jour / dernier jour du mois

_ls_sync_lock = threading.Lock()
_ls_token_lock = threading.Lock()
_ls_token_cache = {'access_token': None, 'expires': 0.0}
_ls_sync_state = {'running': False, 'started_at': None, 'finished_at': None,
                  'progress': '', 'result': None, 'error': None, 'by': None}


class LightspeedError(RuntimeError):
    pass


def meta_delete(*keys):
    conn = get_conn()
    for k in keys:
        conn.execute("DELETE FROM meta WHERE key=?", (k,))
    conn.commit()
    conn.close()


def ls_default_redirect_uri():
    # Lightspeed exige une adresse https:// : aucune page n'y répond, le
    # navigateur affiche une erreur et l'utilisateur colle l'adresse obtenue
    # (qui contient le code d'autorisation) dans Administration → Lightspeed.
    # La même adresse sert pour le test et la prod.
    return "https://localhost/kubios-lightspeed"


def ls_config():
    try:
        hour = int(meta_get('ls_auto_sync_hour') or 22)
    except ValueError:
        hour = 22
    sign = meta_get('ls_balance_sign') or 'auto'
    auto_mode = meta_get('ls_auto_sync_mode')
    if auto_mode not in LS_AUTO_MODES:
        # versions 1.10.0 à 1.10.2 : simple case « chaque jour »
        auto_mode = 'daily' if meta_get('ls_auto_sync') == '1' else 'off'
    redirect_uri = (meta_get('ls_redirect_uri') or '').strip()
    if not redirect_uri or redirect_uri == f"http://localhost:{APP_PORT}/lightspeed/callback":
        # ancienne valeur proposée en 1.10.0/1.10.1, refusée par Lightspeed (http)
        redirect_uri = ls_default_redirect_uri()
    return {
        'client_id': (meta_get('ls_client_id') or '').strip(),
        'client_secret': (meta_get('ls_client_secret') or '').strip(),
        'redirect_uri': redirect_uri,
        'account_id': (meta_get('ls_account_id') or '').strip(),
        'account_name': meta_get('ls_account_name') or '',
        'connected': bool(meta_get('ls_refresh_token')),
        'balance_sign': sign if sign in LS_BALANCE_SIGNS else 'auto',
        'auto_sync': auto_mode != 'off',
        'auto_mode': auto_mode,
        'auto_sync_hour': min(max(hour, 0), 23),
    }


def _truthy(v):
    return str(v).strip().lower() in ('1', 'true', 'yes', 'oui')


def _ls_header(headers, name):
    for k, v in (headers or {}).items():
        if k.lower() == name.lower():
            return v
    return None


def _ls_http(method, url, data=None, headers=None, timeout=60):
    """Requête HTTP vers Lightspeed. Retourne (statut, en-têtes, JSON)."""
    hdrs = {'Accept': 'application/json', 'User-Agent': f'Kubios/{APP_VERSION}'}
    hdrs.update(headers or {})
    body = None
    if data is not None:
        body = urllib.parse.urlencode(data).encode('utf-8')
        hdrs['Content-Type'] = 'application/x-www-form-urlencoded'
    req = urllib.request.Request(url, data=body, headers=hdrs, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode('utf-8', 'replace')
            return r.status, dict(r.headers), (json.loads(raw) if raw.strip() else {})
    except urllib.error.HTTPError as e:
        raw = e.read().decode('utf-8', 'replace')
        try:
            payload = json.loads(raw)
        except Exception:
            payload = {'raw': raw[:300]}
        return e.code, dict(e.headers or {}), payload if isinstance(payload, dict) else {'raw': str(payload)[:300]}
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        reason = getattr(e, 'reason', e)
        raise LightspeedError(f"Impossible de joindre Lightspeed ({reason}). Vérifie la connexion Internet.")
    except ValueError:
        raise LightspeedError("Réponse illisible reçue de Lightspeed.")


def _ls_error_text(payload, status):
    for k in ('error_description', 'message', 'error', 'raw'):
        v = (payload or {}).get(k)
        if v:
            return str(v)
    return f"HTTP {status}"


def _ls_token_request(data):
    cfg = ls_config()
    if not cfg['client_id'] or not cfg['client_secret']:
        raise LightspeedError("Le Client ID et le Client secret Lightspeed ne sont pas configurés "
                              "(Administration → Lightspeed).")
    data = dict(data, client_id=cfg['client_id'], client_secret=cfg['client_secret'])
    status, _, payload = _ls_http('POST', f"{LS_AUTH_BASE}/token", data=data, timeout=30)
    if status != 200 or not payload.get('access_token'):
        raise LightspeedError(f"Lightspeed a refusé l'authentification : {_ls_error_text(payload, status)}. "
                              "Si le problème persiste, reconnecte Kubios à Lightspeed (Administration).")
    _ls_token_cache['access_token'] = payload['access_token']
    try:
        expires_in = int(payload.get('expires_in') or 1800)
    except (TypeError, ValueError):
        expires_in = 1800
    _ls_token_cache['expires'] = time.time() + max(expires_in - 60, 60)
    # Lightspeed peut remettre un nouveau refresh token (l'ancien devient
    # alors invalide) : on le garde immédiatement.
    if payload.get('refresh_token'):
        meta_set('ls_refresh_token', payload['refresh_token'])
    return payload['access_token']


def ls_access_token(force_refresh=False):
    with _ls_token_lock:
        if not force_refresh and _ls_token_cache['access_token'] and time.time() < _ls_token_cache['expires']:
            return _ls_token_cache['access_token']
        rt = meta_get('ls_refresh_token')
        if not rt:
            raise LightspeedError("Kubios n'est pas connecté à Lightspeed "
                                  "(Administration → Lightspeed → Connecter à Lightspeed).")
        return _ls_token_request({'grant_type': 'refresh_token', 'refresh_token': rt})


def _ls_throttle(headers):
    """Respecte la limite de requêtes de Lightspeed (« seau » X-LS-API-Bucket-Level)."""
    level = _ls_header(headers, 'X-LS-API-Bucket-Level') or ''
    try:
        used, cap = (float(x) for x in level.split('/'))
        time.sleep(2.0 if cap and used / cap > 0.7 else 0.3)
    except Exception:
        time.sleep(0.5)


def _ls_api_get(path_or_url, params=None):
    url = path_or_url if path_or_url.startswith('http') else f"{LS_API_BASE}{path_or_url}"
    if params:
        url += ('&' if '?' in url else '?') + urllib.parse.urlencode(params)
    for attempt in range(6):
        token = ls_access_token(force_refresh=(attempt > 0 and _ls_token_cache['access_token'] is None))
        status, headers, payload = _ls_http('GET', url, headers={'Authorization': f'Bearer {token}'})
        if status == 200:
            _ls_throttle(headers)
            return payload
        if status == 401 and attempt == 0:
            _ls_token_cache['access_token'] = None
            continue
        if status in (429, 502, 503, 504):
            try:
                wait = float(_ls_header(headers, 'Retry-After') or 0)
            except ValueError:
                wait = 0
            time.sleep(min(max(wait, 2 ** attempt), 30))
            continue
        raise LightspeedError(f"Erreur de l'API Lightspeed (HTTP {status}) : {_ls_error_text(payload, status)}")
    raise LightspeedError("Lightspeed ne répond pas ou reçoit trop de requêtes. Réessaie dans quelques minutes.")


def _ls_as_list(v):
    if v is None or v == '':
        return []
    return v if isinstance(v, list) else [v]


def _ls_get_all(account_id, resource, params, label, state=None):
    """Lit toutes les pages d'une ressource (pagination « next » de l'API V3,
    ou par offset pour les réponses plus anciennes)."""
    base = f"/Account/{account_id}/{resource}.json"
    url, query = base, dict(params, limit=LS_PAGE_LIMIT)
    out = []
    for _ in range(2000):
        data = _ls_api_get(url, query)
        out.extend(_ls_as_list(data.get(resource)))
        (state if state is not None else _ls_sync_state)['progress'] = f"{label} : {len(out)} lu(s)…"
        attrs = data.get('@attributes') or {}
        nxt = attrs.get('next')
        if nxt:
            url, query = nxt, None
            continue
        try:
            count = int(attrs.get('count') or 0)
            offset = int(attrs.get('offset') or 0)
            lim = int(attrs.get('limit') or LS_PAGE_LIMIT)
        except (TypeError, ValueError):
            break
        if 'offset' in attrs and offset + lim < count:
            url, query = base, dict(params, limit=LS_PAGE_LIMIT, offset=offset + lim)
            continue
        break
    return out


def ls_fetch_account():
    data = _ls_api_get('/Account.json')
    acc = _ls_as_list(data.get('Account'))
    if not acc:
        raise LightspeedError("Aucun compte Lightspeed accessible avec cette connexion.")
    return str(acc[0].get('accountID') or '').strip(), (acc[0].get('name') or '').strip()


def ls_fetch_credit_accounts(account_id):
    """Retourne (comptes, ignorés). Chaque compte : ls_id, ls_customer_id,
    prenom_entreprise, nom, credit_limit, balance (solde brut Lightspeed)."""
    accounts = _ls_get_all(account_id, 'CreditAccount', {}, 'Comptes de crédit')
    customers = _ls_get_all(account_id, 'Customer', {'creditAccountID': '>,0'}, 'Clients')
    by_ca = {}
    for c in customers:
        ca = str(c.get('creditAccountID') or '').strip()
        if ca and ca != '0':
            by_ca[ca] = c
    out = []
    skipped = {'gift_cards': 0, 'archived': 0}
    for a in accounts:
        if _truthy(a.get('giftCard')):
            skipped['gift_cards'] += 1
            continue
        if _truthy(a.get('archived')):
            skipped['archived'] += 1
            continue
        caid = str(a.get('creditAccountID') or '').strip()
        if not caid:
            continue
        cust = by_ca.get(caid) or {}
        first = (cust.get('firstName') or '').strip()
        last = (cust.get('lastName') or '').strip()
        company = (cust.get('company') or '').strip()
        prenom, nom = (first or company), last
        if not prenom:
            prenom, nom = last, ''
        if not prenom:
            prenom = (a.get('name') or '').strip() or f"Compte Lightspeed {caid}"
        out.append({
            'ls_id': caid,
            'ls_customer_id': str(cust.get('customerID') or '').strip() or None,
            'prenom_entreprise': prenom,
            'nom': nom or None,
            'credit_limit': round(_parse_money(a.get('creditLimit')), 2),
            'balance': round(_parse_money(a.get('balance')), 2),
        })
    return out, skipped


def _ls_debt(balance, sign):
    """« Debt » (positif = le client doit) à partir du solde brut Lightspeed."""
    return round(balance if sign == 'positive_du' else -balance, 2)


def _ls_detect_sign(rows):
    """Compare les soldes Lightspeed aux soldes actuels de Kubios (issus de
    l'export CSV) pour déterminer le sens du champ « balance »."""
    clients = db_list_credit_clients()
    by_lsid = {c['ls_credit_account_id']: c for c in clients if c.get('ls_credit_account_id')}
    names = {}
    for c in clients:
        names.setdefault(_norm_credit_name(c['display_name']), []).append(c)
    pos = neg = n = 0
    for r in rows:
        if abs(r['balance']) < 0.01:
            continue
        c = by_lsid.get(r['ls_id'])
        if c is None:
            same = names.get(_norm_credit_name(_credit_client_display_name(r))) or []
            c = same[0] if len(same) == 1 else None
        if c is None:
            continue
        d = _credit_net_debt(c)
        if abs(d) < 0.01:
            continue
        n += 1
        if abs(d - r['balance']) < 0.01:
            pos += 1
        elif abs(d + r['balance']) < 0.01:
            neg += 1
    if n >= 5 and pos >= 0.6 * n and pos > 2 * neg:
        return 'positive_du', (n, pos, neg)
    if n >= 5 and neg >= 0.6 * n and neg > 2 * pos:
        return 'negative_du', (n, pos, neg)
    raise LightspeedError(
        f"Impossible de déterminer automatiquement le sens du solde Lightspeed ({n} compte(s) comparé(s) : "
        f"{pos} concordent avec « positif = montant dû », {neg} avec « négatif = montant dû »). "
        "Choisis-le dans Administration → Lightspeed, puis relance la synchronisation.")


def _ls_apply_values(conn, client, row, debt, now, today, note):
    """Applique limite / dû / dépôt d'un compte Lightspeed à un compte Kubios.
    Retourne 'updated' ou 'unchanged'."""
    old_debt = _credit_net_debt(client)
    delta = round(debt - old_debt, 2)
    solde, deposit = _split_debt(debt)
    limit_changed = abs(float(client.get('credit_limit') or 0) - row['credit_limit']) >= 0.005
    raw_changed = (abs(float(client.get('solde') or 0) - solde) >= 0.005
                   or abs(float(client.get('deposit') or 0) - deposit) >= 0.005)
    if not (limit_changed or raw_changed or abs(delta) >= 0.01):
        return 'unchanged'
    conn.execute("UPDATE credit_clients SET credit_limit=?, solde=?, deposit=? WHERE id=?",
                 (row['credit_limit'], solde, deposit, client['id']))
    client.update(credit_limit=row['credit_limit'], solde=solde, deposit=deposit)
    # Seuil de 1,5 ¢ : d'anciens montants divisés par 2 (import du 29-09) ont
    # 3 décimales — l'arrondi à 2 décimales ne doit pas créer de faux mouvement.
    if abs(delta) >= 0.015:
        conn.execute(
            "INSERT INTO credit_movements(credit_client_id, lightspeed_id, date_mouvement, montant, type, sale, "
            "customer_brut, notes, imported_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (client['id'], None, today, delta, LS_SYNC_MOVEMENT_TYPE, None,
             _credit_client_display_name(row),
             f"{note} le {today} : Debt {old_debt:.2f}$ -> {debt:.2f}$", now))
    return 'updated'


def _ls_insert_client(conn, row, now, note):
    cur = conn.execute(
        "INSERT INTO credit_clients(prenom_entreprise, nom, credit_limit, solde, deposit, notes, created_at, "
        "ls_credit_account_id, ls_customer_id) VALUES (?,?,?,?,?,?,?,?,?)",
        (row['prenom_entreprise'], row['nom'], 0, 0, 0, note, now, row['ls_id'], row.get('ls_customer_id')))
    return {'id': cur.lastrowid, 'prenom_entreprise': row['prenom_entreprise'], 'nom': row['nom'],
            'credit_limit': 0.0, 'solde': 0.0, 'deposit': 0.0, 'no_sync': 0,
            'ls_credit_account_id': row['ls_id']}


def db_ls_apply(rows, sign):
    """Applique les comptes lus dans Lightspeed à la base Kubios.
    1) compte déjà relié (ls_credit_account_id) -> mis à jour ;
    2) sinon, un seul compte Kubios non relié porte le même nom ET un seul
       compte Lightspeed porte ce nom -> relié puis mis à jour ;
    3) homonymes -> mis de côté dans ls_pending_accounts (association
       manuelle dans la page Comptes de crédit), rien n'est modifié ;
    4) aucun compte de ce nom -> nouveau compte Kubios relié.
    Les comptes « Ne pas synchroniser » sont reliés mais jamais modifiés."""
    conn = get_conn()
    try:
        clients = [dict(r) for r in conn.execute("SELECT * FROM credit_clients").fetchall()]
        by_lsid = {c['ls_credit_account_id']: c for c in clients if c.get('ls_credit_account_id')}
        unlinked = {}
        for c in clients:
            if not c.get('ls_credit_account_id'):
                unlinked.setdefault(_norm_credit_name(_credit_client_display_name(c)), []).append(c)
        ls_name_count = {}
        for r in rows:
            if r['ls_id'] not in by_lsid:
                k = _norm_credit_name(_credit_client_display_name(r))
                ls_name_count[k] = ls_name_count.get(k, 0) + 1

        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        today = datetime.date.today().strftime('%Y-%m-%d')
        res = {'updated': 0, 'unchanged': 0, 'linked': 0, 'created': 0, 'renamed': 0,
               'locked': 0, 'pending': 0, 'missing': 0}
        pending = []
        seen_ids = set()
        for r in rows:
            seen_ids.add(r['ls_id'])
            debt = _ls_debt(r['balance'], sign)
            key = _norm_credit_name(_credit_client_display_name(r))
            client = by_lsid.get(r['ls_id'])
            if client is None:
                cands = unlinked.get(key) or []
                if len(cands) == 1 and ls_name_count.get(key, 0) == 1:
                    client = cands[0]
                    unlinked[key] = []
                    conn.execute("UPDATE credit_clients SET ls_credit_account_id=?, ls_customer_id=? WHERE id=?",
                                 (r['ls_id'], r.get('ls_customer_id'), client['id']))
                    client['ls_credit_account_id'] = r['ls_id']
                    res['linked'] += 1
                elif cands:
                    pending.append((r, debt))
                    continue
                else:
                    client = _ls_insert_client(conn, r, now,
                                               "Créé automatiquement par la synchronisation Lightspeed.")
                    res['created'] += 1
                by_lsid[r['ls_id']] = client
            if client.get('no_sync'):
                res['locked'] += 1
                continue
            if _norm_credit_name(_credit_client_display_name(client)) != key:
                conn.execute("UPDATE credit_clients SET prenom_entreprise=?, nom=? WHERE id=?",
                             (r['prenom_entreprise'], r['nom'], client['id']))
                client.update(prenom_entreprise=r['prenom_entreprise'], nom=r['nom'])
                res['renamed'] += 1
            res[_ls_apply_values(conn, client, r, debt, now, today, 'Synchronisation Lightspeed')] += 1

        res['missing'] = sum(1 for k in by_lsid if k not in seen_ids)
        conn.execute("DELETE FROM ls_pending_accounts")
        for r, debt in pending:
            conn.execute(
                "INSERT INTO ls_pending_accounts(ls_credit_account_id, ls_customer_id, prenom_entreprise, nom, "
                "credit_limit, debt, seen_at) VALUES (?,?,?,?,?,?,?)",
                (r['ls_id'], r.get('ls_customer_id'), r['prenom_entreprise'], r['nom'],
                 r['credit_limit'], debt, now))
        res['pending'] = len(pending)
        conn.commit()
        return res
    finally:
        conn.close()


def db_ls_list_pending():
    conn = get_conn()
    try:
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM ls_pending_accounts ORDER BY prenom_entreprise COLLATE NOCASE, nom COLLATE NOCASE"
        ).fetchall()]
        unlinked = {}
        for c in conn.execute("SELECT * FROM credit_clients WHERE ls_credit_account_id IS NULL").fetchall():
            c = dict(c)
            c['display_name'] = _credit_client_display_name(c)
            c['solde'], c['deposit'] = _split_debt(_credit_net_debt(c))
            unlinked.setdefault(_norm_credit_name(c['display_name']), []).append(
                {k: c[k] for k in ('id', 'display_name', 'credit_limit', 'solde', 'deposit', 'no_sync')})
        for r in rows:
            r['display_name'] = _credit_client_display_name(r)
            r['solde'], r['deposit'] = _split_debt(r['debt'])
            r['candidates'] = unlinked.get(_norm_credit_name(r['display_name']), [])
        return rows
    finally:
        conn.close()


def db_ls_link_pending(ls_id, client_id):
    """Associe un compte Lightspeed en attente à un compte Kubios existant
    (client_id) ou à un nouveau compte (client_id None). Retourne (client, action)."""
    conn = get_conn()
    try:
        p = conn.execute("SELECT * FROM ls_pending_accounts WHERE ls_credit_account_id=?", (ls_id,)).fetchone()
        if p is None:
            raise RuntimeError("Ce compte Lightspeed n'est plus en attente (relance la synchronisation).")
        p = dict(p)
        row = {'ls_id': p['ls_credit_account_id'], 'ls_customer_id': p['ls_customer_id'],
               'prenom_entreprise': p['prenom_entreprise'], 'nom': p['nom'],
               'credit_limit': float(p['credit_limit'] or 0)}
        if conn.execute("SELECT 1 FROM credit_clients WHERE ls_credit_account_id=?", (ls_id,)).fetchone():
            raise RuntimeError("Ce compte Lightspeed est déjà associé à un compte Kubios.")
        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        today = datetime.date.today().strftime('%Y-%m-%d')
        if client_id:
            c = conn.execute("SELECT * FROM credit_clients WHERE id=?", (client_id,)).fetchone()
            if c is None:
                raise RuntimeError("Compte Kubios introuvable.")
            client = dict(c)
            if client.get('ls_credit_account_id'):
                raise RuntimeError("Ce compte Kubios est déjà associé à un autre compte Lightspeed.")
            conn.execute("UPDATE credit_clients SET ls_credit_account_id=?, ls_customer_id=? WHERE id=?",
                         (ls_id, row['ls_customer_id'], client['id']))
            action = 'linked'
        else:
            client = _ls_insert_client(conn, row, now,
                                       "Créé lors d'une association manuelle (synchronisation Lightspeed).")
            action = 'created'
        if not client.get('no_sync'):
            _ls_apply_values(conn, client, row, float(p['debt'] or 0), now, today,
                             'Association manuelle Lightspeed')
        conn.execute("DELETE FROM ls_pending_accounts WHERE ls_credit_account_id=?", (ls_id,))
        conn.commit()
        client['display_name'] = _credit_client_display_name(client)
        return client, action, p
    finally:
        conn.close()


def _ls_result_text(res):
    parts = [f"{res.get('total', 0)} compte(s) lu(s)", f"{res['updated']} mis à jour",
             f"{res['unchanged']} inchangé(s)"]
    for k, lbl in (('created', "nouveau(x) compte(s) créé(s)"), ('linked', "associé(s) par nom"),
                   ('renamed', "nom(s) mis à jour"), ('pending', "homonyme(s) à associer manuellement"),
                   ('locked', "non synchronisé(s) ignoré(s)"), ('gift_cards', "carte(s)-cadeaux ignorée(s)"),
                   ('archived', "archivé(s) ignoré(s)"),
                   ('missing', "compte(s) Kubios relié(s) absent(s) de Lightspeed")):
        if res.get(k):
            parts.append(f"{res[k]} {lbl}")
    return ", ".join(parts)


def run_ls_sync(username, auto=False, month_end=False):
    """Synchronisation complète (appelée depuis un fil d'exécution). Lève
    LightspeedError en cas d'échec (le message est aussi gardé pour la page)."""
    if not _ls_sync_lock.acquire(blocking=False):
        raise LightspeedError("Une synchronisation Lightspeed est déjà en cours.")
    st = _ls_sync_state
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    st.update(running=True, started_at=now, finished_at=None, progress="Connexion à Lightspeed…",
              result=None, error=None, by=username)
    kind = ' — automatique de fin de mois' if month_end else (' — automatique' if auto else '')
    label = 'Synchronisation Lightspeed (comptes de crédit)' + kind
    try:
        cfg = ls_config()
        account_id = cfg['account_id']
        if not account_id:
            account_id, name = ls_fetch_account()
            meta_set('ls_account_id', account_id)
            meta_set('ls_account_name', name)
        rows, skipped = ls_fetch_credit_accounts(account_id)
        sign = cfg['balance_sign']
        if sign not in ('positive_du', 'negative_du'):
            sign, (n, pos, neg) = _ls_detect_sign(rows)
            meta_set('ls_balance_sign', sign)
            db_add_audit(username, 'Lightspeed : sens du solde détecté',
                         ("positif = montant dû" if sign == 'positive_du' else "négatif = montant dû")
                         + f" ({n} compte(s) comparé(s), {pos}/{neg})")
        st['progress'] = "Sauvegarde des comptes avant la mise à jour…"
        try:
            backup_id = db_backup_credit(
                "Avant synchronisation Lightspeed" + (" de fin de mois" if month_end else
                                                     (" automatique" if auto else "")), username)
        except RuntimeError as e:
            raise LightspeedError(str(e))
        st['progress'] = "Mise à jour des comptes…"
        res = db_ls_apply(rows, sign)
        if not any(res[k] for k in ('updated', 'created', 'linked', 'renamed')):
            db_discard_credit_backup(backup_id)
            backup_id = None
        res['backup_id'] = backup_id
        res.update(skipped)
        res['total'] = len(rows)
        res['snapshot_id'] = None
        if month_end:
            # Portrait de fin de mois : toujours gardé (rapport PDF), même sans changement.
            res['snapshot_id'] = db_capture_credit_snapshot(
                'Synchronisation Lightspeed de fin de mois (API)', 'API Lightspeed — automatique')
        elif res['updated'] or res['created']:
            res['snapshot_id'] = db_capture_credit_snapshot(
                'Synchronisation Lightspeed (API)', 'API Lightspeed' + (' — automatique' if auto else ''))
        mark_dirty()
        done = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        meta_set('ls_last_sync', done)
        meta_set('ls_last_sync_result', json.dumps(res))
        meta_delete('ls_last_sync_error')
        db_add_audit(username, label, _ls_result_text(res))
        st['result'] = res
        return res
    except Exception as e:
        if not isinstance(e, LightspeedError):
            traceback.print_exc()
        msg = str(e) if isinstance(e, LightspeedError) else f"Erreur inattendue : {e}"
        st['error'] = msg
        meta_set('ls_last_sync_error', f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} — {msg}")
        db_add_audit(username, label + ' — échec', msg)
        raise LightspeedError(msg)
    finally:
        st['running'] = False
        st['finished_at'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        st['progress'] = ''
        _ls_sync_lock.release()


def start_ls_sync_thread(username, auto=False):
    if _ls_sync_state['running']:
        raise LightspeedError("Une synchronisation Lightspeed est déjà en cours.")

    def _run():
        try:
            run_ls_sync(username, auto=auto)
        except LightspeedError as e:
            print("Synchronisation Lightspeed :", e)

    threading.Thread(target=_run, daemon=True).start()


def ls_auto_mode_text(mode, hour):
    if mode == 'daily':
        return f"chaque jour à partir de {hour} h"
    if mode == 'month_end':
        return f"le dernier jour de chaque mois à partir de {hour} h"
    return "désactivée"


def _is_last_day_of_month(d):
    return (d + datetime.timedelta(days=1)).month != d.month


def _ls_auto_sync_loop():
    """Synchronisation automatique (Administration → Lightspeed) : chaque jour
    ou seulement le dernier jour du mois, à partir de l'heure choisie. Une
    seule synchronisation par jour ; un échec n'est pas retenté le même jour
    (il est affiché dans la page Comptes de crédit). Kubios doit être en
    marche à cette heure-là : une synchro de fin de mois manquée n'est pas
    rattrapée le lendemain (les soldes ne seraient plus ceux du mois)."""
    while True:
        time.sleep(LS_AUTO_CHECK_SECONDS)
        try:
            cfg = ls_config()
            if not cfg['auto_sync'] or not cfg['connected'] or _ls_sync_state['running']:
                continue
            now = datetime.datetime.now()
            today = now.strftime('%Y-%m-%d')
            if now.hour < cfg['auto_sync_hour'] or meta_get('ls_last_auto_sync_date') == today:
                continue
            month_end = cfg['auto_mode'] == 'month_end'
            if month_end and not _is_last_day_of_month(now.date()):
                continue
            meta_set('ls_last_auto_sync_date', today)
            run_ls_sync('Synchronisation automatique', auto=True, month_end=month_end)
        except Exception as e:
            print("Synchronisation Lightspeed automatique :", e)


# ============================================================
# Comptes à recevoir — factures Lightspeed (1.11.0)
# ------------------------------------------------------------
# « Vérifier » lit dans Lightspeed les ventes portées au compte de crédit
# d'un client depuis une date, puis montre celles qui ne sont pas encore dans
# Kubios (comparaison par numéro de vente). Rien n'est inscrit sans
# confirmation ; une sauvegarde des comptes à recevoir est prise juste avant.
#  - montant de la facture = partie de la vente portée au compte ;
#  - retour porté au compte (vente négative) = note de crédit (montant < 0) ;
#  - paiement sur compte (total de vente ≈ 0, compte crédité) = simple rappel :
#    Lightspeed ne relie pas un paiement à une facture précise.
# Le lien client Lightspeed -> client Kubios est gardé dans ls_ar_customers.
# ============================================================
_ls_ar_lock = threading.Lock()
_ls_ar_state = {'running': False, 'progress': '', 'error': None, 'preview': None, 'by': None}


def _last_day_next_month(d):
    first_next = (d.replace(day=1) + datetime.timedelta(days=32)).replace(day=1)
    return (first_next + datetime.timedelta(days=32)).replace(day=1) - datetime.timedelta(days=1)


def _ls_local_date(ts):
    """Date locale (AAAA-MM-JJ) d'un horodatage ISO de Lightspeed."""
    if not ts:
        return None
    try:
        dt = datetime.datetime.fromisoformat(str(ts).replace('Z', '+00:00'))
        if dt.tzinfo is not None:
            dt = dt.astimezone()
        return dt.date().isoformat()
    except ValueError:
        return str(ts)[:10]


def _ls_is_account_payment(p):
    ca = str(p.get('creditAccountID') or '').strip()
    if ca and ca != '0':
        return True
    ptype = str((p.get('PaymentType') or {}).get('type') or '').strip().lower()
    return ptype == 'credit account'


def _ls_customer_names(cust):
    """Variantes de nom d'un client Lightspeed (pour l'association par nom)."""
    first = (cust.get('firstName') or '').strip()
    last = (cust.get('lastName') or '').strip()
    company = (cust.get('company') or '').strip()
    display = company or f"{first} {last}".strip() or f"Client Lightspeed {cust.get('customerID') or ''}".strip()
    variants = {v for v in (company, f"{first} {last}".strip(), f"{last} {first}".strip()) if v}
    return display, variants


def _ar_existing_numbers(conn):
    return {str(r['numero']).strip() for r in conn.execute(
        "SELECT numero FROM invoices WHERE numero IS NOT NULL AND TRIM(numero) <> ''").fetchall()}


def ls_ar_build_preview(since, username, include_ignored=False):
    """Lit les ventes portées au compte depuis `since` (date) et prépare
    l'aperçu. Retourne le dictionnaire d'aperçu (gardé en mémoire)."""
    st = _ls_ar_state
    cfg = ls_config()
    account_id = cfg['account_id']
    if not account_id:
        account_id, name = ls_fetch_account()
        meta_set('ls_account_id', account_id)
        meta_set('ls_account_name', name)
    start = datetime.datetime.combine(since, datetime.time()).astimezone().isoformat(timespec='seconds')
    params = {'completed': 'true', 'completeTime': f'>,{start}',
              'load_relations': json.dumps(['SalePayments', 'SalePayments.PaymentType', 'Customer'])}
    sales = _ls_get_all(account_id, 'Sale', params, 'Ventes', state=st)
    st['progress'] = "Comparaison avec Kubios…"

    conn = get_conn()
    try:
        existing = _ar_existing_numbers(conn)
        clients = [r['name'] for r in conn.execute("SELECT name FROM clients").fetchall()]
        mapping = {r['ls_customer_id']: r['client_name']
                   for r in conn.execute("SELECT * FROM ls_ar_customers").fetchall()}
        aliases = [dict(r) for r in conn.execute("SELECT * FROM ls_ar_aliases").fetchall()]
        ignored = {r['sale_id'] for r in conn.execute("SELECT sale_id FROM ls_ar_ignored").fetchall()}
        done_payments = {r['sale_id'] for r in conn.execute("SELECT sale_id FROM ls_ar_payments").fetchall()}
    finally:
        conn.close()
    client_set = set(clients)
    by_norm = {}
    for c in clients:
        by_norm.setdefault(_norm_credit_name(c), []).append(c)
    # noms reconnus (anciens noms, clients fusionnés) -> client Kubios
    for a in aliases:
        if a['client_name'] in client_set and a['client_name'] not in by_norm.get(a['alias'], []):
            by_norm.setdefault(a['alias'], []).append(a['client_name'])

    # Champ du numéro : numéro de vente (saleID) par défaut ; si les numéros
    # déjà dans Kubios correspondent plutôt au numéro de billet, on prend celui-là.
    number_field = meta_get('ls_ar_number_field') or ''
    if number_field not in ('saleID', 'ticketNumber'):
        m_sale = sum(1 for s in sales if str(s.get('saleID') or '').strip() in existing)
        m_ticket = sum(1 for s in sales if str(s.get('ticketNumber') or '').strip() in existing)
        number_field = 'ticketNumber' if m_ticket > m_sale else 'saleID'
        if max(m_sale, m_ticket) >= 3:
            meta_set('ls_ar_number_field', number_field)

    today = datetime.date.today()
    items, payments = [], []
    counts = {'sales': len(sales), 'on_account': 0, 'in_kubios': 0, 'ignored': 0, 'payments_done': 0}
    for s in sales:
        if _truthy(s.get('voided')):
            continue
        on_acct = round(sum(_parse_money(p.get('amount'))
                            for p in _ls_as_list((s.get('SalePayments') or {}).get('SalePayment'))
                            if _ls_is_account_payment(p)), 2)
        if abs(on_acct) < 0.005:
            continue
        counts['on_account'] += 1
        total = _parse_money(s.get('calcTotal') or s.get('total'))
        cust = s.get('Customer') or {}
        cust_id = str(cust.get('customerID') or s.get('customerID') or '').strip()
        display, variants = _ls_customer_names(cust)
        client = mapping.get(cust_id) if mapping.get(cust_id) in client_set else None
        match = 'lien' if client else None
        if client is None:
            found = {c for v in variants for c in by_norm.get(_norm_credit_name(v), [])}
            if len(found) == 1:
                client, match = found.pop(), 'nom'
        date_vente = _ls_local_date(s.get('completeTime') or s.get('timeStamp')) or today.isoformat()
        sale_id = str(s.get('saleID') or '').strip()
        numero = str(s.get(number_field) or sale_id).strip()
        if on_acct < 0 and total >= -0.005:
            if sale_id in done_payments:
                counts['payments_done'] += 1
                continue
            payments.append({'sale_id': sale_id, 'date': date_vente, 'customer': display,
                             'customer_id': cust_id, 'client': client, 'match': match,
                             'montant': round(-on_acct, 2)})
            continue
        if numero in existing or sale_id in existing or str(s.get('ticketNumber') or '').strip() in existing:
            counts['in_kubios'] += 1
            continue
        is_ignored = sale_id in ignored
        if is_ignored:
            counts['ignored'] += 1
            if not include_ignored:
                continue
        try:
            d = datetime.date.fromisoformat(date_vente)
        except ValueError:
            d = today
        items.append({
            'sale_id': sale_id, 'numero': numero, 'date': date_vente,
            'echeance': _last_day_next_month(d).isoformat(),
            'montant': on_acct, 'kind': 'facture' if on_acct > 0 else 'credit',
            'customer_id': cust_id, 'customer': display, 'client': client, 'match': match,
            'ignored': is_ignored, 'sale_total': round(total, 2),
        })
    items.sort(key=lambda x: (x['client'] or x['customer']).lower() + x['date'])
    payments.sort(key=lambda x: (x['date'], x['sale_id']))
    _ar_propose_payments(payments, items)
    st['progress'] = "Vérification des soldes…"
    try:
        balances = _ls_ar_balance_check(account_id, items, payments)
    except LightspeedError as e:
        balances = {'error': str(e), 'rows': [], 'compared': 0, 'ok': 0, 'not_linked': []}
    return {
        'token': secrets.token_urlsafe(16),
        'created_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'since': since.isoformat(), 'until': today.isoformat(), 'by': username,
        'number_field': number_field, 'counts': counts,
        'items': items, 'payments': payments, 'balances': balances,
    }


def _ar_open_invoices(conn, client_names=None):
    """Factures ouvertes (solde > 0) par client, de la plus ancienne à la plus récente."""
    q = ("SELECT id, client_name, numero, date_facture, COALESCE(montant,0) - COALESCE(montant_paye,0) solde "
         "FROM invoices WHERE COALESCE(montant,0) - COALESCE(montant_paye,0) > 0.005")
    out = {}
    for r in conn.execute(q + " ORDER BY date_facture, id").fetchall():
        if client_names is not None and r['client_name'] not in client_names:
            continue
        out.setdefault(r['client_name'], []).append(
            {'id': r['id'], 'numero': r['numero'], 'date': r['date_facture'], 'solde': round(r['solde'], 2)})
    return out


def _ar_allocate(open_invoices, amount, first_id=None):
    """Répartit un paiement sur les factures ouvertes d'un client :
    1) la facture choisie (first_id) en premier, sinon une facture dont le
       solde est exactement le montant payé ; 2) puis les plus anciennes.
    Retourne ([(facture, montant appliqué)], excédent non appliqué)."""
    order = list(open_invoices)
    first = None
    if first_id:
        first = next((i for i in order if i['id'] == first_id), None)
    if first is None:
        first = next((i for i in order if abs(i['solde'] - amount) < 0.005), None)
    if first is not None:
        order = [first] + [i for i in order if i is not first]
    rest = round(amount, 2)
    alloc = []
    for inv in order:
        if rest < 0.005:
            break
        a = round(min(inv['solde'], rest), 2)
        if a < 0.005:
            continue
        alloc.append((inv, a))
        rest = round(rest - a, 2)
    return alloc, max(rest, 0.0)


def _fmt_money_fr(v):
    return f"{v:,.2f}".replace(',', '\u00a0').replace('.', ',') + "\u00a0$"


def _ar_propose_payments(payments, items=()):
    """Ajoute à chaque paiement la répartition proposée (simulée dans l'ordre
    des dates, pour que deux paiements du même client ne visent pas le même
    solde) et la liste des factures ouvertes au moment du paiement."""
    clients = {p['client'] for p in payments if p['client']}
    if not clients:
        return
    conn = get_conn()
    try:
        open_by_client = _ar_open_invoices(conn, clients)
    finally:
        conn.close()
    # Les nouvelles factures de la même vérification comptent aussi (comme à
    # l'application, où elles sont inscrites avant les paiements).
    for it in items:
        if it.get('client') in clients and it['montant'] > 0:
            open_by_client.setdefault(it['client'], []).append(
                {'id': None, 'numero': it['numero'], 'date': it['date'], 'solde': it['montant'], 'new': True})
    for lst in open_by_client.values():
        lst.sort(key=lambda i: (i['date'] or '', i['id'] is None, i['id'] or 0))
    for p in payments:
        p['options'], p['pool'], p['allocations'], p['leftover'] = [], [], [], 0.0
        if not p['client']:
            continue
        opens = open_by_client.get(p['client'], [])
        p['pool'] = [dict(i) for i in opens]
        p['options'] = [dict(i) for i in opens if i['id'] is not None]
        alloc, rest = _ar_allocate(opens, p['montant'])
        p['allocations'] = [{'invoice_id': i['id'], 'numero': i['numero'], 'date': i['date'],
                             'solde': i['solde'], 'applique': a, 'new': bool(i.get('new'))} for i, a in alloc]
        p['leftover'] = rest
        for i, a in alloc:
            i['solde'] = round(i['solde'] - a, 2)
        open_by_client[p['client']] = [i for i in opens if i['solde'] > 0.005]


def _ls_ar_balance_check(account_id, items, payments):
    """Compare, pour chaque client des comptes à recevoir relié à Lightspeed,
    le solde Kubios (factures - payé) au solde de son compte de crédit."""
    sign = ls_config()['balance_sign']
    if sign not in ('positive_du', 'negative_du'):
        raise LightspeedError("Le sens du solde Lightspeed n'est pas encore connu : lance d'abord une "
                              "synchronisation des comptes de crédit (ou choisis-le dans Administration).")
    conn = get_conn()
    try:
        soldes = {r['client_name']: round(r['s'] or 0, 2) for r in conn.execute(
            "SELECT client_name, SUM(COALESCE(montant,0) - COALESCE(montant_paye,0)) s FROM invoices "
            "GROUP BY client_name").fetchall()}
        clients = [r['name'] for r in conn.execute("SELECT name FROM clients").fetchall()]
        mapping = {r['client_name']: r['ls_customer_id'] for r in conn.execute("SELECT * FROM ls_ar_customers")}
        credit_by_name = {}
        for r in conn.execute("SELECT prenom_entreprise, nom, ls_customer_id FROM credit_clients "
                              "WHERE ls_customer_id IS NOT NULL").fetchall():
            credit_by_name.setdefault(_norm_credit_name(_credit_client_display_name(dict(r))), []).append(
                r['ls_customer_id'])
    finally:
        conn.close()
    for it in list(items) + list(payments):
        if it.get('client') and it.get('customer_id') and it['client'] not in mapping:
            mapping[it['client']] = it['customer_id']
    links, not_linked = {}, []
    for c in clients:
        cid = mapping.get(c)
        if not cid:
            same = credit_by_name.get(_norm_credit_name(c)) or []
            cid = same[0] if len(same) == 1 else None
        if cid:
            links[c] = str(cid)
        elif abs(soldes.get(c, 0)) >= 0.01:
            not_linked.append({'client': c, 'kubios': soldes.get(c, 0)})
    # Lightspeed : client -> compte de crédit -> solde
    ids = sorted(set(links.values()))
    ca_by_customer = {}
    for k in range(0, len(ids), 100):
        batch = ids[k:k + 100]
        for cu in _ls_get_all(account_id, 'Customer', {'customerID': 'IN,[' + ','.join(batch) + ']'},
                              'Soldes (clients)', state=_ls_ar_state):
            ca = str(cu.get('creditAccountID') or '').strip()
            if ca and ca != '0':
                ca_by_customer[str(cu.get('customerID'))] = ca
    cas = sorted(set(ca_by_customer.values()))
    balance_by_ca = {}
    for k in range(0, len(cas), 100):
        batch = cas[k:k + 100]
        for a in _ls_get_all(account_id, 'CreditAccount', {'creditAccountID': 'IN,[' + ','.join(batch) + ']'},
                             'Soldes (comptes)', state=_ls_ar_state):
            balance_by_ca[str(a.get('creditAccountID'))] = _parse_money(a.get('balance'))
    pending = {it['client'] for it in list(items) + list(payments) if it.get('client')}
    rows, ok, compared = [], 0, 0
    for c, cid in sorted(links.items(), key=lambda x: x[0].lower()):
        ca = ca_by_customer.get(cid)
        if ca is None or ca not in balance_by_ca:
            if abs(soldes.get(c, 0)) >= 0.01:
                not_linked.append({'client': c, 'kubios': soldes.get(c, 0)})
            continue
        compared += 1
        ls_debt = _ls_debt(balance_by_ca[ca], sign)
        k_solde = soldes.get(c, 0.0)
        ecart = round(k_solde - ls_debt, 2)
        if abs(ecart) < 0.01:
            ok += 1
        else:
            rows.append({'client': c, 'kubios': k_solde, 'lightspeed': ls_debt, 'ecart': ecart,
                         'pending': c in pending})
    rows.sort(key=lambda r: -abs(r['ecart']))
    not_linked.sort(key=lambda r: r['client'].lower())
    return {'error': None, 'rows': rows, 'compared': compared, 'ok': ok, 'not_linked': not_linked}


def start_ls_ar_check(since, username, include_ignored=False):
    if not _ls_ar_lock.acquire(blocking=False):
        raise LightspeedError("Une vérification est déjà en cours.")
    st = _ls_ar_state
    st.update(running=True, progress="Connexion à Lightspeed…", error=None, preview=None, by=username)

    def _run():
        try:
            st['preview'] = ls_ar_build_preview(since, username, include_ignored)
        except Exception as e:
            if not isinstance(e, LightspeedError):
                traceback.print_exc()
            st['error'] = str(e) if isinstance(e, LightspeedError) else f"Erreur inattendue : {e}"
        finally:
            st['running'] = False
            st['progress'] = ''
            _ls_ar_lock.release()

    threading.Thread(target=_run, daemon=True).start()


def _ls_fetch_customer_contact(customer_id):
    """Coordonnées d'un client Lightspeed (pour créer le client dans Kubios)."""
    acct = ls_config()['account_id']
    data = _ls_api_get(f"/Account/{acct}/Customer/{customer_id}.json",
                       {'load_relations': json.dumps(['Contact'])})
    cust = data.get('Customer') or {}
    contact = cust.get('Contact') or {}
    addr = (_ls_as_list((contact.get('Addresses') or {}).get('ContactAddress')) or [{}])[0]
    phones = _ls_as_list((contact.get('Phones') or {}).get('ContactPhone'))
    emails = _ls_as_list((contact.get('Emails') or {}).get('ContactEmail'))
    phone = next((p.get('number') for p in phones if p.get('number')), '')
    email = next((e.get('address') for e in emails if e.get('address')), '')
    adresse = " ".join(x for x in ((addr.get('address1') or '').strip(), (addr.get('address2') or '').strip()) if x)
    return {'phone': phone or '', 'courriel': email or '', 'adresse': adresse,
            'ville': (addr.get('city') or '').strip(), 'province': (addr.get('state') or '').strip() or 'Qc',
            'code_postal': (addr.get('zip') or '').strip()}


def ls_ar_apply(token, choices, username, payment_choices=None):
    """Inscrit les factures choisies et applique les paiements choisis.
    choices : [{sale_id, action: 'inscrire'|'ignorer', client: nom Kubios ou '' (nouveau client)}]
    payment_choices : [{sale_id, action: 'appliquer'|'deja_fait', first_invoice_id: id ou None}]"""
    pv = _ls_ar_state.get('preview')
    if not pv or pv['token'] != token:
        raise RuntimeError("Cette vérification n'est plus à jour : relance « Vérifier les factures ».")
    items = {it['sale_id']: it for it in pv['items']}
    pays = {p['sale_id']: p for p in pv.get('payments', [])}
    to_add, to_ignore, to_pay, to_mark = [], [], [], []
    conn = get_conn()
    known = {r['name'].lower(): r['name'] for r in conn.execute("SELECT name FROM clients").fetchall()}
    conn.close()
    to_link = []   # (ls_customer_id, nom Lightspeed, client Kubios)

    def _existing(name, what):
        c = known.get((name or '').strip().lower())
        if c is None:
            raise RuntimeError(f"« {name} » n'est pas un client existant dans Kubios ({what}). "
                               "Choisis un client dans la liste.")
        return c

    for ch in choices or []:
        it = items.get(str(ch.get('sale_id') or ''))
        if it is None:
            continue
        if ch.get('action') == 'inscrire':
            to_add.append((it, (ch.get('client') or '').strip()))
        elif ch.get('action') == 'ignorer':
            to_ignore.append(it)
        elif ch.get('action') == 'relier' and it['customer_id']:
            to_link.append((it['customer_id'], it['customer'],
                            _existing(ch.get('client') or it.get('client'), f"vente n° {it['numero']}")))
    for ch in payment_choices or []:
        p = pays.get(str(ch.get('sale_id') or ''))
        if p is None:
            continue
        if not p['client'] and ch.get('client') and ch.get('action') in ('appliquer', 'relier'):
            p = dict(p, client=_existing(ch['client'], f"paiement du {p['date']}"))
            if p['customer_id']:
                to_link.append((p['customer_id'], p['customer'], p['client']))
        if ch.get('action') == 'relier' and p['client'] and p['customer_id']:
            to_link.append((p['customer_id'], p['customer'], p['client']))
            continue
        if ch.get('action') == 'appliquer' and p['client']:
            try:
                first = int(ch.get('first_invoice_id') or 0) or None
            except (TypeError, ValueError):
                first = None
            to_pay.append((p, first))
        elif ch.get('action') == 'deja_fait':
            to_mark.append(p)
    if not to_add and not to_ignore and not to_pay and not to_mark and not to_link:
        raise RuntimeError("Aucune facture ni aucun paiement choisi.")

    label = f"Avant inscription de {len(to_add)} facture(s)"
    if to_pay:
        label += f" et {len(to_pay)} paiement(s)"
    backup_id = db_backup_scope('ar', label + " Lightspeed", username)
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    created, added, skipped = [], 0, 0
    conn = get_conn()
    existing_clients = {r['name'].lower(): r['name'] for r in conn.execute("SELECT name FROM clients").fetchall()}
    conn.close()
    # 1) clients à créer (coordonnées lues dans Lightspeed)
    resolved = []
    for it, client in to_add:
        name = client or it['customer']
        if name.lower() in existing_clients:
            resolved.append((it, existing_clients[name.lower()]))
            continue
        try:
            info = _ls_fetch_customer_contact(it['customer_id']) if it['customer_id'] else {}
        except LightspeedError:
            info = {}
        db_create_client(name, info.get('phone'), info.get('adresse'), info.get('ville'),
                         info.get('province'), info.get('code_postal'), info.get('courriel'))
        existing_clients[name.lower()] = name
        created.append(name)
        resolved.append((it, name))
    # 2) factures + liens client, en une transaction
    conn = get_conn()
    try:
        numbers = _ar_existing_numbers(conn)
        for it, client in resolved:
            if it['numero'] in numbers:
                skipped += 1
                continue
            conn.execute(
                "INSERT INTO invoices(client_name, numero, date_facture, echeance, montant, notes, montant_paye, "
                "date_paiement) VALUES (?,?,?,?,?,?,0,NULL)",
                (client, it['numero'], it['date'], it['echeance'], it['montant'],
                 f"Inscrite depuis Lightspeed (vente #{it['sale_id']})"))
            numbers.add(it['numero'])
            added += 1
            if it['customer_id']:
                conn.execute("INSERT OR REPLACE INTO ls_ar_customers(ls_customer_id, client_name, linked_at, ls_name) "
                             "VALUES (?,?,?,?)", (it['customer_id'], client, now, it['customer']))
            conn.execute("DELETE FROM ls_ar_ignored WHERE sale_id=?", (it['sale_id'],))
        for cid, ls_name, client in to_link:
            conn.execute("INSERT OR REPLACE INTO ls_ar_customers(ls_customer_id, client_name, linked_at, ls_name) "
                         "VALUES (?,?,?,?)", (cid, client, now, ls_name))
        for it in to_ignore:
            conn.execute("INSERT OR REPLACE INTO ls_ar_ignored(sale_id, ignored_at, username, info) VALUES (?,?,?,?)",
                         (it['sale_id'], now, username or '?',
                          f"{it['customer']} — n° {it['numero']} — {it['montant']:.2f} $ — {it['date']}"))
        # 3) paiements : répartition recalculée sur les factures ouvertes actuelles
        #    (y compris celles qu'on vient d'inscrire), dans l'ordre des dates.
        applied = []
        open_by_client = _ar_open_invoices(conn, {p['client'] for p, _ in to_pay})
        for p, first in sorted(to_pay, key=lambda x: (x[0]['date'], x[0]['sale_id'])):
            if conn.execute("SELECT 1 FROM ls_ar_payments WHERE sale_id=?", (p['sale_id'],)).fetchone():
                continue
            opens = open_by_client.get(p['client'], [])
            alloc, rest = _ar_allocate(opens, p['montant'], first)
            for inv, a in alloc:
                conn.execute("UPDATE invoices SET montant_paye = ROUND(COALESCE(montant_paye,0) + ?, 2), "
                             "date_paiement = ? WHERE id=?", (a, p['date'], inv['id']))
                inv['solde'] = round(inv['solde'] - a, 2)
            open_by_client[p['client']] = [i for i in opens if i['solde'] > 0.005]
            details = {'allocations': [{'invoice_id': i['id'], 'numero': i['numero'], 'montant': a} for i, a in alloc],
                       'excedent': rest}
            conn.execute("INSERT INTO ls_ar_payments(sale_id, client_name, payment_date, montant, status, details, "
                         "processed_at, username) VALUES (?,?,?,?,?,?,?,?)",
                         (p['sale_id'], p['client'], p['date'], p['montant'], 'applique',
                          json.dumps(details), now, username or '?'))
            applied.append({'client': p['client'], 'montant': p['montant'], 'date': p['date'],
                            'factures': [f"n° {i['numero']} ({_fmt_money_fr(a)})" for i, a in alloc], 'excedent': rest})
        for p in to_mark:
            conn.execute("INSERT OR REPLACE INTO ls_ar_payments(sale_id, client_name, payment_date, montant, status, "
                         "details, processed_at, username) VALUES (?,?,?,?,?,?,?,?)",
                         (p['sale_id'], p['client'] or p['customer'], p['date'], p['montant'], 'deja_fait',
                          None, now, username or '?'))
        conn.commit()
    finally:
        conn.close()
    if not added and not created and not applied:
        db_discard_credit_backup(backup_id)
        backup_id = None
    meta_set('ls_ar_last_until', pv['until'])
    mark_dirty()
    _ls_ar_state['preview'] = None
    return {'added': added, 'ignored': len(to_ignore), 'created_clients': created,
            'skipped': skipped, 'backup_id': backup_id, 'payments_applied': applied,
            'payments_marked': len(to_mark),
            'linked': sorted({f"{n} → {c}" for _, n, c in to_link})}


# ============================================================
# Rapports personnalisés (1.12.0) — « Ventes par catégorie d'articles »
# ------------------------------------------------------------
# L'API R-Series ne fournit pas les rapports de Lightspeed tout faits : on lit
# les ventes complétées de la période avec leurs lignes et l'article de chaque
# ligne, puis on regroupe par catégorie, avec la même logique que le rapport
# « Ventes par catégorie » de Lightspeed :
#   sous-total = prix × quantité, avant rabais et avant taxes ;
#   rabais     = rabais de ligne + part du rabais de la vente ;
#   total      = sous-total − rabais (revenu réel, avant taxes) ;
#   coût       = coût unitaire FIFO (sinon coût moyen) × quantité ;
#   profit     = total − coût ; marge = profit / total.
# Les retours ont une quantité négative et réduisent donc les totaux.
# ============================================================
_rep_lock = threading.Lock()
_rep_state = {'running': False, 'progress': '', 'error': None, 'result': None, 'comparison': None, 'taxes': None, 'by': None}
_ls_ref_cache = {}   # catégories / magasins : gardés 30 min


def _ls_cached(key, loader, ttl=1800):
    hit = _ls_ref_cache.get(key)
    if hit and time.time() - hit[0] < ttl:
        return hit[1]
    data = loader()
    _ls_ref_cache[key] = (time.time(), data)
    return data


def ls_fetch_categories(account_id, state=None):
    def load():
        out = {}
        for c in _ls_get_all(account_id, 'Category', {}, 'Catégories', state=state):
            cid = str(c.get('categoryID') or '').strip()
            if cid:
                name = (c.get('name') or '').strip() or f"Catégorie {cid}"
                out[cid] = {'name': name, 'path': (c.get('fullPathName') or '').strip() or name}
        return out
    return _ls_cached(('categories', account_id), load)


def ls_fetch_shops(account_id):
    def load():
        return [{'id': str(s.get('shopID')), 'name': (s.get('name') or '').strip() or f"Magasin {s.get('shopID')}"}
                for s in _ls_get_all(account_id, 'Shop', {}, 'Magasins') if not _truthy(s.get('archived'))]
    return _ls_cached(('shops', account_id), load)


REP_NO_CATEGORY = "(Sans catégorie)"
REP_MISC = "(Articles divers, sans fiche)"


def _rep_line_values(ln):
    qty = _parse_money(ln.get('unitQuantity'))
    unit = _parse_money(ln.get('unitPrice'))
    raw_sub = ln.get('calcSubtotal')
    subtotal = _parse_money(raw_sub) if raw_sub not in (None, '') else unit * qty
    discount = _parse_money(ln.get('calcLineDiscount')) + _parse_money(ln.get('calcTransactionDiscount'))
    total = subtotal - discount
    unit_cost = _parse_money(ln.get('fifoCost')) or _parse_money(ln.get('avgCost'))
    return qty, subtotal, discount, total, unit_cost * qty


def build_sales_by_category(start, end, shop_id, level, username):
    """start / end : dates (incluses). level : 'full' (catégorie complète) ou
    'top' (catégorie principale seulement)."""
    st = _rep_state
    cfg = ls_config()
    account_id = cfg['account_id']
    if not account_id:
        account_id, name = ls_fetch_account()
        meta_set('ls_account_id', account_id)
        meta_set('ls_account_name', name)
    cats = ls_fetch_categories(account_id, state=st)
    t0 = datetime.datetime.combine(start, datetime.time()).astimezone()
    t1 = datetime.datetime.combine(end + datetime.timedelta(days=1), datetime.time()).astimezone()
    params = {'completed': 'true',
              'completeTime': f"><,{t0.isoformat(timespec='seconds')},{t1.isoformat(timespec='seconds')}",
              'load_relations': json.dumps(['SaleLines', 'SaleLines.Item'])}
    if shop_id:
        params['shopID'] = shop_id
    sales = _ls_get_all(account_id, 'Sale', params, 'Ventes', state=st)
    st['progress'] = "Calcul du rapport…"

    agg = {}
    n_sales = n_lines = 0
    for s in sales:
        if _truthy(s.get('voided')):
            continue
        n_sales += 1
        for ln in _ls_as_list((s.get('SaleLines') or {}).get('SaleLine')):
            item = ln.get('Item') or {}
            item_id = str(ln.get('itemID') or item.get('itemID') or '0').strip()
            if item_id in ('', '0'):
                key = REP_MISC
            else:
                cat = cats.get(str(item.get('categoryID') or '0').strip())
                if cat is None:
                    key = REP_NO_CATEGORY
                else:
                    key = cat['path'].split('/')[0].strip() if level == 'top' else cat['path']
            qty, sub, disc, tot, cost = _rep_line_values(ln)
            a = agg.setdefault(key, {'categorie': key, 'quantite': 0.0, 'sous_total': 0.0, 'rabais': 0.0,
                                     'total': 0.0, 'cout': 0.0, 'lignes': 0})
            a['quantite'] += qty
            a['sous_total'] += sub
            a['rabais'] += disc
            a['total'] += tot
            a['cout'] += cost
            a['lignes'] += 1
            n_lines += 1

    rows = sorted(agg.values(), key=lambda r: -r['total'])
    grand = {k: round(sum(r[k] for r in rows), 2) for k in ('quantite', 'sous_total', 'rabais', 'total', 'cout')}
    grand['lignes'] = n_lines
    for r in rows + [grand]:
        for k in ('quantite', 'sous_total', 'rabais', 'total', 'cout'):
            r[k] = round(r[k], 2)
        r['profit'] = round(r['total'] - r['cout'], 2)
        r['marge'] = round(r['profit'] / r['total'] * 100, 1) if abs(r['total']) >= 0.005 else None
        r['part'] = round(r['total'] / grand['total'] * 100, 1) if abs(grand['total']) >= 0.005 else None
    shop_name = ''
    if shop_id:
        shop_name = next((s['name'] for s in ls_fetch_shops(account_id) if s['id'] == str(shop_id)), f"#{shop_id}")
    return {
        'report': 'ventes_par_categorie', 'title': "Ventes par catégorie d'articles",
        'start': start.isoformat(), 'end': end.isoformat(), 'shop_id': shop_id or '', 'shop_name': shop_name,
        'level': level, 'rows': rows, 'totals': grand, 'sales_count': n_sales,
        'generated_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'by': username,
    }


def start_sales_by_category(start, end, shop_id, level, username):
    if not _rep_lock.acquire(blocking=False):
        raise LightspeedError("Un rapport est déjà en cours de préparation.")
    st = _rep_state
    st.update(running=True, progress="Connexion à Lightspeed…", error=None, result=None, by=username)

    def _run():
        try:
            st['result'] = build_sales_by_category(start, end, shop_id, level, username)
        except Exception as e:
            if not isinstance(e, LightspeedError):
                traceback.print_exc()
            st['error'] = str(e) if isinstance(e, LightspeedError) else f"Erreur inattendue : {e}"
        finally:
            st['running'] = False
            st['progress'] = ''
            _rep_lock.release()

    threading.Thread(target=_run, daemon=True).start()


def _rep_period_label(r):
    def d(x):
        return f"{x[8:10]}-{x[5:7]}-{x[:4]}"
    lbl = f"Du {d(r['start'])} au {d(r['end'])}" if r['start'] != r['end'] else f"Le {d(r['start'])}"
    if r.get('shop_name'):
        lbl += f" — {r['shop_name']}"
    lbl += " — " + ("catégories principales" if r['level'] == 'top' else "catégories complètes")
    return lbl


REP_COLUMNS = (('categorie', 'Catégorie'), ('quantite', 'Qté'), ('sous_total', 'Sous-total'),
               ('rabais', 'Rabais'), ('total', 'Total'), ('cout', 'Coût'), ('profit', 'Profit'),
               ('marge', 'Marge'), ('part', '% des ventes'))


def export_report_xlsx(r):
    """Même mise en page comptable que le PDF (1.23.0) : vraies valeurs numériques."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    if 'payments' not in r:
        r = rep_accounting_layout(dict(r))
    wb = Workbook()
    ws = wb.active
    ws.title = "Ventes par catégorie"
    money, pctf = '#,##0.00 $;-#,##0.00 $', '0.0%'
    head_fill, sub_fill, tot_fill = PatternFill('solid', fgColor='1E3A8A'), PatternFill('solid', fgColor='F1F5F9'), PatternFill('solid', fgColor='DBE3F3')
    ws['A1'] = get_company_name(); ws['A1'].font = Font(bold=True, size=15)
    ws['A2'] = r['title']; ws['A2'].font = Font(bold=True, size=12)
    ws['A3'] = _rep_period_label(r)
    g = r['generated_at']
    ws['A4'] = f"{r['sales_count']} vente(s) — généré le {g[8:10]}-{g[5:7]}-{g[:4]} à {g[11:16]} par {r['by'] or '?'}"
    row = 6

    def section(title):
        nonlocal row
        ws.cell(row=row, column=1, value=title).font = Font(bold=True, size=12, color='1E3A8A')
        row += 1

    def header(labels):
        nonlocal row
        for j, lbl in enumerate(labels, start=1):
            c = ws.cell(row=row, column=j, value=lbl)
            c.font = Font(bold=True, color='FFFFFF'); c.fill = head_fill
            c.alignment = Alignment(horizontal='left' if j <= 2 else 'right', wrap_text=True)
        row += 1

    def put(values, fmts, fill=None, bold=False):
        nonlocal row
        for j, (v, f) in enumerate(zip(values, fmts), start=1):
            c = ws.cell(row=row, column=j, value=v)
            if f: c.number_format = f
            if fill: c.fill = fill
            if bold: c.font = Font(bold=True)
        row += 1

    section("1. Ventes par catégorie d'articles (avec comptes GL)")
    header(["Compte GL", "Catégorie", "Qté", "Sous-total", "Rabais", "Total", "Coût", "Profit", "Marge", "% des ventes"])
    fm = [None, None, '#,##0.##', money, money, money, money, money, pctf, pctf]
    vals = lambda x, name: [x.get('gl') or '', name, x['quantite'], x['sous_total'], x['rabais'], x['total'], x['cout'], x['profit'],
                            None if x.get('marge') is None else x['marge'] / 100, None if x.get('part') is None else x['part'] / 100]
    for k, x in enumerate(r['rows']):
        put(vals(x, x['categorie']), fm)
        if r.get('subtotal') and k == r.get('group_count', 0) - 1:
            put(vals(dict(r['subtotal'], gl=''), r['subtotal']['categorie']), fm, sub_fill, True)
    put(vals(dict(r['totals'], gl=''), 'TOTAL DES VENTES'), fm, tot_fill, True)
    row += 1
    section("2. Répartition par mode de paiement")
    header(["Compte GL", "Mode de paiement", "Total perçu", "% du total"])
    for p in r['payments']:
        put([p['gl'], p['mode'], p['montant'], None if p['part'] is None else p['part'] / 100], [None, None, money, pctf])
    put(['', 'TOTAL PERÇU (taxes incluses)', r['payments_total'], 1 if r['payments'] else None], [None, None, money, pctf], tot_fill, True)
    row += 1
    section("3. Ventilation des taxes (type de taxes)")
    header(["Compte GL", "Type de taxe", "Taux", "Montant de base taxable", "Taxe calculée"])
    for x in r['taxes']:
        put([x['gl'], x['type'], x['taux'] / 100, x['base'], x['taxe']], [None, None, '0.000%', money, money])
    put(['', 'TOTAL DES TAXES', None, None, r['taxes_total']], [None, None, None, None, money], tot_fill, True)
    row += 1
    put(['', 'Grand total (facturé aux clients)', None, None, r['grand_total']], [None, None, None, None, money], PatternFill('solid', fgColor='FEF3C7'), True)
    ws.column_dimensions['A'].width = 11
    ws.column_dimensions['B'].width = 44
    for col in 'CDEFGHIJ':
        ws.column_dimensions[col].width = 15
    out = PDF_DIR / "Rapports_personnalises"
    out.mkdir(exist_ok=True)
    path = out / f"Ventes_par_categorie_{r['start']}_au_{r['end']}.xlsx"
    for ws_ in wb.worksheets:
        _xlsx_disclaimer(ws_)
    wb.save(path)
    return path


def export_report_pdf(r):
    """Rapport de ventes par catégorie, mise en page comptable (1.23.0)."""
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, KeepTogether
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader
    if 'payments' not in r:
        r = rep_accounting_layout(dict(r))
    out = PDF_DIR / "Rapports_personnalises"
    out.mkdir(exist_ok=True)
    path = out / f"Ventes_par_categorie_{r['start']}_au_{r['end']}.pdf"
    page_w, page_h = letter
    lm = rm = 12 * mm
    styles = getSampleStyleSheet()
    cell = ParagraphStyle('c', parent=styles['Normal'], fontSize=7.5, leading=9)
    cellb = ParagraphStyle('cb', parent=cell, fontName='Helvetica-Bold')
    h2 = ParagraphStyle('h2', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=11, spaceBefore=6, spaceAfter=5,
                        textColor=colors.HexColor('#1e3a8a'))
    lvl = 'catégories principales' if r.get('level') == 'top' else 'catégories complètes'
    period = (f"Le {_d(r['start'])}" if r['start'] == r['end'] else f"Du {_d(r['start'])} au {_d(r['end'])}") \
        + (f" — {r['shop_name']}" if r.get('shop_name') else '') + f" — {lvl}"
    g = r['generated_at']
    esc_ = lambda t: str(t).replace('&', '&amp;').replace('<', '&lt;')

    def money(v):
        return '' if v is None else f"{v:,.2f} $".replace(',', ' ').replace('.', ',')

    def pct(v):
        return '' if v is None else f"{v:.1f} %".replace('.', ',')

    def qty(q):
        return f"{q:,.0f}".replace(',', ' ') if float(q).is_integer() else f"{q:,.2f}".replace(',', ' ').replace('.', ',')

    def header(canvas, doc_):
        canvas.saveState()
        top = page_h - 14 * mm
        canvas.setFont('Helvetica-Bold', 17)
        canvas.drawString(lm, top, get_company_name())
        canvas.setFont('Helvetica-Bold', 11.5)
        canvas.drawString(lm, top - 7 * mm, r['title'])
        canvas.setFont('Helvetica', 9)
        canvas.drawString(lm, top - 12.5 * mm, period)
        canvas.drawString(lm, top - 17 * mm, f"{r['sales_count']} vente(s) — généré le {g[8:10]}-{g[5:7]}-{g[:4]} à {g[11:16]}")
        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            lw = 40 * mm
            canvas.drawImage(img, page_w - rm - lw, top - lw * ih / iw + 4 * mm, width=lw, height=lw * ih / iw, mask='auto')
        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.line(lm, top - 21 * mm, page_w - rm, top - 21 * mm)
        canvas.setFont('Helvetica', 7.5)
        canvas.drawString(lm, 8 * mm, f"{get_company_name()} — {r['title']} — {period}")
        canvas.drawRightString(page_w - rm, 8 * mm, f"Page {doc_.page}")
        canvas.restoreState()

    base = [('FONTSIZE', (0, 0), (-1, -1), 7.5), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('LINEBELOW', (0, 0), (-1, -1), 0.25, colors.HexColor('#d1d5db')),
            ('TOPPADDING', (0, 0), (-1, -1), 3), ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'), ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e3a8a'))]
    total_style = lambda row: [('FONTNAME', (0, row), (-1, row), 'Helvetica-Bold'), ('BACKGROUND', (0, row), (-1, row), colors.HexColor('#dbe3f3')),
                               ('LINEABOVE', (0, row), (-1, row), 0.8, colors.HexColor('#1e3a8a'))]
    sub_style = lambda row: [('FONTNAME', (0, row), (-1, row), 'Helvetica-Bold'), ('BACKGROUND', (0, row), (-1, row), colors.HexColor('#f1f5f9'))]
    story = [Paragraph("1. Ventes par catégorie d'articles (avec comptes GL)", h2)]
    data = [["Compte GL", "Catégorie", "Qté", "Sous-total", "Rabais", "Total", "Coût", "Profit", "Marge", "% ventes"]]
    st = list(base)
    line = lambda x, name, bold=False: [x.get('gl', '') or '—', Paragraph(esc_(name), cellb if bold else cell), qty(x['quantite']),
                                        money(x['sous_total']), money(x['rabais']), money(x['total']), money(x['cout']),
                                        money(x['profit']), pct(x['marge']), pct(x['part'])]
    n_grp = r.get('group_count', 0)
    for k, x in enumerate(r['rows']):
        data.append(line(x, x['categorie']))
        if r.get('subtotal') and k == n_grp - 1:
            data.append(line(dict(r['subtotal'], gl='—'), r['subtotal']['categorie'], True))
            st += sub_style(len(data) - 1)
    T = dict(r['totals'], gl='—')
    data.append(line(T, 'TOTAL DES VENTES', True))
    st += total_style(len(data) - 1) + [('ALIGN', (2, 0), (-1, -1), 'RIGHT')]
    t = Table(data, colWidths=[16 * mm, 40 * mm, 12 * mm, 20 * mm, 16 * mm, 20 * mm, 20 * mm, 19 * mm, 14 * mm, 15 * mm], repeatRows=1)
    t.setStyle(TableStyle(st))
    story.append(t)

    data = [["Compte GL", "Mode de paiement", "Total perçu", "% du total"]]
    for p in r['payments']:
        data.append([p['gl'] or '—', Paragraph(esc_(p['mode']), cell), money(p['montant']), pct(p['part'])])
    if not r['payments']:
        data.append(['', Paragraph("Aucun paiement gardé pour cette période (relis la période dans Lightspeed).", cell), '', ''])
    data.append(['—', Paragraph('TOTAL PERÇU', cellb), money(r['payments_total']), '100,0 %' if r['payments'] else ''])
    t = Table(data, colWidths=[22 * mm, 80 * mm, 34 * mm, 26 * mm], repeatRows=1)
    t.setStyle(TableStyle(base + total_style(len(data) - 1) + [('ALIGN', (2, 0), (-1, -1), 'RIGHT')]))
    story.append(KeepTogether([Spacer(1, 6 * mm), Paragraph("2. Répartition par mode de paiement", h2), t,
                               Paragraph("Montants payés par les clients, taxes incluses.", ParagraphStyle('n', parent=cell, textColor=colors.HexColor('#6b7280'), spaceBefore=3))]))

    data = [["Compte GL", "Type de taxe", "Taux", "Montant de base taxable", "Taxe calculée"]]
    for x in r['taxes']:
        data.append([x['gl'] or '—', x['type'], f"{x['taux']:g} %".replace('.', ','), money(x['base']), money(x['taxe'])])
    data.append(['—', Paragraph('TOTAL DES TAXES', cellb), '—', '—', money(r['taxes_total'])])
    t = Table(data, colWidths=[22 * mm, 56 * mm, 20 * mm, 40 * mm, 34 * mm], repeatRows=1)
    t.setStyle(TableStyle(base + total_style(len(data) - 1) + [('ALIGN', (2, 0), (-1, -1), 'RIGHT')]))
    gt = Table([[Paragraph('<b>Grand total (facturé aux clients)</b>', ParagraphStyle('g', parent=styles['Normal'], fontSize=11)),
                 Paragraph(f"<b>{money(r['grand_total'])}</b>", ParagraphStyle('g2', parent=styles['Normal'], fontSize=12, alignment=2))]],
               colWidths=[120 * mm, 52 * mm])
    gt.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#fef3c7')), ('BOX', (0, 0), (-1, -1), 0.8, colors.HexColor('#d97706')),
                            ('TOPPADDING', (0, 0), (-1, -1), 7), ('BOTTOMPADDING', (0, 0), (-1, -1), 7), ('LEFTPADDING', (0, 0), (-1, -1), 8)]))
    story.append(KeepTogether([Spacer(1, 6 * mm), Paragraph("3. Ventilation des taxes (type de taxes)", h2), t, Spacer(1, 6 * mm), gt]))
    doc = SimpleDocTemplate(str(path), pagesize=letter, leftMargin=lm, rightMargin=rm, topMargin=40 * mm, bottomMargin=16 * mm)
    story.append(_pdf_disclaimer())
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


# ============================================================
# Ventes gardées localement + rapports automatiques (1.13.0)
# ------------------------------------------------------------
# Les lignes de vente de Lightspeed sont copiées dans la base Kubios
# (sales_lines), jour par jour (sales_days). Chaque nuit (1 h par défaut) :
# les 7 derniers jours sont relus (retours, annulations), l'historique
# manquant depuis la date de départ est complété, puis le rapport de la
# veille est envoyé aux gestionnaires ; le lundi (ou au premier passage
# suivant), le comparatif de la semaine passée avec la même semaine de
# l'année précédente (52 semaines plus tôt, mêmes jours) est envoyé aussi.
# ============================================================
STORE_DEFAULT_START = '2024-01-01'
STORE_CHUNK_DAYS = 7
_store_lock = threading.Lock()
_store_state = {'running': False, 'progress': '', 'error': None, 'kind': None, 'done_days': 0, 'total_days': 0}


def store_cfg():
    try:
        recipients = json.loads(meta_get('rep_recipients') or '[]')
    except ValueError:
        recipients = []
    try:
        hour = min(max(int(meta_get('rep_nightly_hour') or 1), 0), 23)
    except ValueError:
        hour = 1
    return {'enabled': meta_get('rep_store_enabled') != '0',
            'start': meta_get('rep_history_start') or STORE_DEFAULT_START,
            'hour': hour,
            'auto_daily': meta_get('rep_auto_daily') == '1',
            'auto_weekly': meta_get('rep_auto_weekly') == '1',
            'daily_level': 'top' if meta_get('rep_daily_level') == 'top' else 'full',
            'weekly_level': 'full' if meta_get('rep_weekly_level') == 'full' else 'top',
            'bcc_company': meta_get('rep_bcc_company') == '1',
            'recipients': recipients}


def _store_refresh_refs(account_id, st):
    cats = _ls_get_all(account_id, 'Category', {}, 'Catégories', state=st)
    shops = _ls_get_all(account_id, 'Shop', {}, 'Magasins', state=st)
    try:
        taxcats = _ls_get_all(account_id, 'TaxCategory', {'load_relations': json.dumps(['TaxCategoryClasses'])},
                              'Catégories de taxes', state=st)
    except LightspeedError:
        taxcats = []
    try:
        taxclasses = _ls_get_all(account_id, 'TaxClass', {}, 'Classes de taxes', state=st)
    except LightspeedError:
        taxclasses = []
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    conn = get_conn()
    try:
        for c in cats:
            cid = str(c.get('categoryID') or '').strip()
            if cid:
                name = (c.get('name') or '').strip() or f"Catégorie {cid}"
                conn.execute("INSERT OR REPLACE INTO ls_categories(category_id, name, path, updated_at) VALUES (?,?,?,?)",
                             (cid, name, (c.get('fullPathName') or '').strip() or name, now))
        for s in shops:
            conn.execute("INSERT OR REPLACE INTO ls_shops(shop_id, name, archived) VALUES (?,?,?)",
                         (str(s.get('shopID')), (s.get('name') or '').strip() or f"Magasin {s.get('shopID')}",
                          1 if _truthy(s.get('archived')) else 0))
        for tc in taxclasses:
            cid = str(tc.get('taxClassID') or '').strip()
            if cid:
                conn.execute("INSERT OR REPLACE INTO ls_tax_classes(tax_class_id, name) VALUES (?,?)",
                             (cid, (tc.get('name') or '').strip() or f"Classe {cid}"))
        for t in taxcats:
            row = _ls_taxcat_row(t)
            if not row[0]:
                continue
            for cc in _ls_taxcat_classes(t):
                conn.execute("INSERT OR REPLACE INTO ls_tax_category_classes(tax_category_id, tax_class_id, tax1_rate, "
                             "tax2_rate) VALUES (?,?,?,?)", (row[0], cc[0], cc[1], cc[2]))
            has_real_name = any(isinstance(t.get(k), str) and t.get(k).strip()
                                for k in ('taxCategoryName', 'taxName', 'name', 'description', 'title'))
            known = conn.execute("SELECT name FROM ls_tax_categories WHERE tax_category_id=?", (row[0],)).fetchone()
            if not has_real_name and known and known['name'] and not re.fullmatch(r'Catégorie \d+', known['name']):
                # garder le vrai nom déjà connu ; mettre à jour seulement les taxes
                conn.execute("UPDATE ls_tax_categories SET tax1_name=?, tax2_name=?, tax1_rate=?, tax2_rate=? "
                             "WHERE tax_category_id=?", (row[2], row[3], row[4], row[5], row[0]))
            else:
                conn.execute("INSERT OR REPLACE INTO ls_tax_categories(tax_category_id, name, tax1_name, tax2_name, "
                             "tax1_rate, tax2_rate) VALUES (?,?,?,?,?,?)", row)
        conn.commit()
    finally:
        conn.close()
    _ls_ref_cache.clear()


def _store_fetch_range(account_id, d0, d1, st):
    """Lit les ventes de d0 à d1 (inclus) et remplace les lignes de ces jours."""
    t0 = datetime.datetime.combine(d0, datetime.time()).astimezone()
    t1 = datetime.datetime.combine(d1 + datetime.timedelta(days=1), datetime.time()).astimezone()
    params = {'completed': 'true',
              'completeTime': f"><,{t0.isoformat(timespec='seconds')},{t1.isoformat(timespec='seconds')}",
              'load_relations': ''}
    base_rel = ['SaleLines', 'SaleLines.Item', 'TaxCategory', 'TaxCategory.TaxCategoryClasses', 'SalePayments', 'SalePayments.PaymentType']
    optional = [(flag, rel) for flag, rel in (('ls_no_cccharge', 'SalePayments.CCCharge'), ('ls_no_line_note', 'SaleLines.Note'))
                if meta_get(flag) != '1']
    sales, last_err = None, None
    for drop in range(len(optional) + 1):     # tout d'abord ; puis sans le détail des cartes ; puis sans les notes
        kept, dropped = optional[drop:], optional[:drop]
        params['load_relations'] = json.dumps(base_rel + [rel for _f, rel in kept])
        try:
            sales = _ls_get_all(account_id, 'Sale', params, f"Ventes du {d0.isoformat()} au {d1.isoformat()}", state=st)
        except LightspeedError as e:
            last_err = e
            continue
        for flag, _rel in dropped:            # relation refusée par ce compte : on s'en passe désormais
            meta_set(flag, '1')
        break
    if sales is None:
        raise last_err
    taxcats_seen = {}
    for s_ in sales:
        tc = s_.get('TaxCategory')
        if isinstance(tc, dict) and str(tc.get('taxCategoryID') or s_.get('taxCategoryID') or '').strip():
            tc = dict(tc)
            tc.setdefault('taxCategoryID', s_.get('taxCategoryID'))
            row = _ls_taxcat_row(tc)
            has_real_name = any(isinstance(tc.get(k), str) and tc.get(k).strip()
                                for k in ('taxCategoryName', 'taxName', 'name', 'description', 'title'))
            taxcats_seen[row[0]] = (row, has_real_name)
    conn = get_conn()
    known_classes = {}
    for r in conn.execute("SELECT * FROM ls_tax_category_classes").fetchall():
        known_classes.setdefault(r['tax_category_id'], {})[r['tax_class_id']] = (r['tax1_rate'], r['tax2_rate'])
    conn.close()
    rows, counts, class_rates_seen = [], {}, []
    pay_rows = []
    diag, diag_items, diag_ws, diag_pay = [], [], [], []
    for s in sales:
        if _truthy(s.get('voided')):
            continue
        day = _ls_local_date(s.get('completeTime')) or d0.isoformat()
        sid = str(s.get('saleID') or '').strip()
        counts[day] = counts.get(day, 0) + 1
        tax_cat = str(s.get('taxCategoryID') or '').strip()
        s_r1, s_r2 = _parse_money(s.get('tax1Rate')), _parse_money(s.get('tax2Rate'))
        for k_, p_ in enumerate(_ls_as_list((s.get('SalePayments') or {}).get('SalePayment'))):
            pt = p_.get('PaymentType') if isinstance(p_.get('PaymentType'), dict) else {}
            mode = _ls_payment_mode(p_)
            if len(diag_pay) < 20 and mode not in {d_['mode_kubios'] for d_ in diag_pay}:
                diag_pay.append({'mode_kubios': mode, 'brut': {k: v for k, v in p_.items() if k not in ('Sale',)}})
            pay_rows.append((str(p_.get('salePaymentID') or f"{sid}-p{k_}"), sid, day, str(s.get('shopID') or ''),
                             str(p_.get('paymentTypeID') or pt.get('paymentTypeID') or ''), mode,
                             ((pt.get('type') or '').strip() + ' | ' + (pt.get('name') or '').strip())[:120],
                             round(_parse_money(p_.get('amount')), 2)))
        # taux propres aux classes d'articles dans la catégorie de la vente
        cls_rates = dict(known_classes.get(tax_cat, {}))
        tc = s.get('TaxCategory') if isinstance(s.get('TaxCategory'), dict) else {}
        for cid, a, b in _ls_taxcat_classes(tc):
            cls_rates[cid] = (a, b)
            class_rates_seen.append((tax_cat, cid, a, b))
        lines = []
        for i, ln in enumerate(_ls_as_list((s.get('SaleLines') or {}).get('SaleLine'))):
            item = ln.get('Item') or {}
            qty, sub, disc, tot, cost = _rep_line_values(ln)
            tcls = str(ln.get('taxClassID') or item.get('taxClassID') or '').strip()
            if tcls == '0':
                tcls = ''
            taxable = 0 if str(ln.get('tax', 'true')).strip().lower() == 'false' else 1
            # Taux : celui de la ligne, sinon celui de la classe de l'article dans la
            # catégorie de taxes de la vente, sinon celui de la vente.
            c1, c2 = cls_rates.get(tcls, (s_r1, s_r2))
            r1 = _parse_money(ln.get('tax1Rate')) if ln.get('tax1Rate') not in (None, '') else c1
            r2 = _parse_money(ln.get('tax2Rate')) if ln.get('tax2Rate') not in (None, '') else c2
            t1 = _parse_money(ln.get('calcTax1')) if ln.get('calcTax1') not in (None, '') else (tot * r1 if taxable else 0.0)
            t2 = _parse_money(ln.get('calcTax2')) if ln.get('calcTax2') not in (None, '') else (tot * r2 if taxable else 0.0)
            is_fee, fee_name = _ls_fee_info(ln)
            ws_text, ws_job, ws_min = _ls_workshop_info(ln, qty)
            if ws_job and len(diag_ws) < 25:
                diag_ws.append(ln)
            if (is_fee or str(ln.get('itemID') or '0').strip() in ('', '0')) and len(diag) < 25:
                diag.append(ln)
            elif len(diag_items) < 3:
                diag_items.append(ln)
            lines.append([str(ln.get('saleLineID') or f"{sid}-{i}"), sid, day, str(s.get('shopID') or ''),
                          str(ln.get('itemID') or item.get('itemID') or '0').strip() or '0',
                          str(item.get('categoryID') or '').strip(), qty, round(sub, 4), round(disc, 4),
                          round(tot, 4), round(cost, 4), t1, t2, r1, r2, taxable,
                          str(ln.get('taxCategoryID') or '').strip() or tax_cat, tcls, 1 if is_fee else 0, fee_name,
                          (ws_text[:400] if (ws_job or ws_min or is_fee) else None), ws_job, ws_min])
        # Taxes arrondies PAR VENTE, comme Lightspeed : la somme des lignes est
        # ajustée au total de taxe de la vente.
        for col, idx in ((11, 1), (12, 2)):
            target = _ls_sale_tax_total(s, idx)
            if target is not None and lines:
                adj = _ls_reconcile([l[col] for l in lines], [l[9] if l[15] else 0 for l in lines], target)
                for l, v in zip(lines, adj):
                    l[col] = v
        for l in lines:
            l[11], l[12] = round(l[11], 4), round(l[12], 4)
            rows.append(tuple(l))
    today = datetime.date.today()
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    conn = get_conn()
    try:
        for cat, cid, a, b in class_rates_seen:
            conn.execute("INSERT OR REPLACE INTO ls_tax_category_classes(tax_category_id, tax_class_id, tax1_rate, "
                         "tax2_rate) VALUES (?,?,?,?)", (cat, cid, a, b))
        for row, has_real_name in taxcats_seen.values():
            # ne remplace pas un vrai nom déjà connu par un nom construit à partir des taxes
            known = conn.execute("SELECT name FROM ls_tax_categories WHERE tax_category_id=?", (row[0],)).fetchone()
            if not has_real_name and known and known['name'] and not re.fullmatch(r'Catégorie \d+', known['name']):
                continue
            conn.execute("INSERT OR REPLACE INTO ls_tax_categories(tax_category_id, name, tax1_name, tax2_name, "
                         "tax1_rate, tax2_rate) VALUES (?,?,?,?,?,?)", row)
        conn.execute("DELETE FROM sales_lines WHERE sale_date BETWEEN ? AND ?", (d0.isoformat(), d1.isoformat()))
        conn.execute("DELETE FROM sales_payments WHERE sale_date BETWEEN ? AND ?", (d0.isoformat(), d1.isoformat()))
        conn.executemany("INSERT OR REPLACE INTO sales_payments(payment_id, sale_id, sale_date, shop_id, type_id, name, ptype, amount) "
                         "VALUES (?,?,?,?,?,?,?,?)", pay_rows)
        conn.executemany("INSERT OR REPLACE INTO sales_lines(sale_line_id, sale_id, sale_date, shop_id, item_id, "
                         "category_id, qty, subtotal, discount, total, cost, tax1, tax2, tax1_rate, tax2_rate, "
                         "taxable, tax_cat, tax_class, is_fee, fee_name, descr, job_ref, svc_minutes) "
                         "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
        d = d0
        while d <= d1:
            conn.execute("INSERT OR REPLACE INTO sales_days(day, sales_count, complete, fetched_at, tax_ok, ws_ok, pay_ok) "
                         "VALUES (?,?,?,?,3,1,2)", (d.isoformat(), counts.get(d.isoformat(), 0), 1 if d < today else 0, now))
            d += datetime.timedelta(days=1)
        conn.commit()
    finally:
        conn.close()
    # Diagnostic : quelques lignes brutes (frais, articles divers, articles) pour
    # vérifier comment Lightspeed décrit les frais. Aucune donnée de client.
    if diag or diag_ws or diag_pay:
        try:
            keep = ('saleLineID', 'saleID', 'itemID', 'unitQuantity', 'unitPrice', 'calcSubtotal', 'calcTotal',
                    'calcTax1', 'calcTax2', 'tax', 'taxClassID', 'description', 'lineType', 'type', 'Note', 'note')
            clean = lambda ln: {k: v for k, v in ln.items() if k in keep or 'fee' in k.lower() or k == 'Item'}
            FEE_DIAG_PATH.write_text(json.dumps({'genere_le': now, 'periode': [d0.isoformat(), d1.isoformat()],
                                                 'lignes_frais_ou_divers': [clean(x) for x in diag],
                                                 'lignes_atelier_hubtiger': [clean(x) for x in diag_ws],
                                                 'paiements': diag_pay,
                                                 'exemples_articles': [clean(x) for x in diag_items]},
                                                ensure_ascii=False, indent=2, default=str), encoding='utf-8')
        except Exception:
            traceback.print_exc()


def store_missing_days(d0, d1, need_tax=False, need_ws=False, need_pay=False):
    """Jours de la période absents de la base locale (ou incomplets : aujourd'hui).
    need_tax : exige aussi les montants de taxes (jours récupérés avant 1.17.0)."""
    conn = get_conn()
    have = {r['day'] for r in conn.execute("SELECT day FROM sales_days WHERE complete=1 AND day BETWEEN ? AND ?"
                                           + (" AND tax_ok>=3" if need_tax else "") + (" AND ws_ok=1" if need_ws else "")
                                           + (" AND pay_ok>=2" if need_pay else ""),
                                           (d0.isoformat(), d1.isoformat())).fetchall()}
    conn.close()
    out, d = [], d0
    while d <= d1:
        if d.isoformat() not in have:
            out.append(d)
        d += datetime.timedelta(days=1)
    return out


def _chunks(days):
    """Regroupe des jours en plages consécutives d'au plus STORE_CHUNK_DAYS jours."""
    out = []
    for d in sorted(days):
        if out and (d - out[-1][1]).days == 1 and (d - out[-1][0]).days < STORE_CHUNK_DAYS:
            out[-1][1] = d
        else:
            out.append([d, d])
    return out


def store_sync_days(days, st, kind):
    """Récupère les jours demandés (plages de 7 jours). Retourne le nombre de jours."""
    cfg = ls_config()
    account_id = cfg['account_id']
    if not account_id:
        account_id, name = ls_fetch_account()
        meta_set('ls_account_id', account_id)
        meta_set('ls_account_name', name)
    _store_refresh_refs(account_id, st)
    chunks = _chunks(days)
    st.update(total_days=len(days), done_days=0, kind=kind)
    for a, b in chunks:
        _store_fetch_range(account_id, a, b, st)
        st['done_days'] += (b - a).days + 1
        st['progress'] = f"{st['done_days']} jour(s) sur {st['total_days']} récupéré(s)…"
    return len(days)


def start_store_job(kind, days, username, then=None):
    """Lance une récupération en arrière-plan (historique ou période précise)."""
    if not _store_lock.acquire(blocking=False):
        raise LightspeedError("Une récupération des ventes est déjà en cours.")
    st = _store_state
    st.update(running=True, progress="Connexion à Lightspeed…", error=None, kind=kind, done_days=0, total_days=len(days))

    def _run():
        try:
            n = store_sync_days(days, st, kind)
            db_add_audit(username or '?', 'Ventes Lightspeed récupérées', f"{kind} : {n} jour(s)")
            if then:
                then()
        except Exception as e:
            if not isinstance(e, LightspeedError):
                traceback.print_exc()
            st['error'] = str(e) if isinstance(e, LightspeedError) else f"Erreur inattendue : {e}"
        finally:
            st['running'] = False
            st['progress'] = ''
            _store_lock.release()

    threading.Thread(target=_run, daemon=True).start()


def store_status():
    conn = get_conn()
    r = conn.execute("SELECT COUNT(*) n, MIN(day) a, MAX(day) b, SUM(sales_count) s FROM sales_days WHERE complete=1").fetchone()
    lines = conn.execute("SELECT COUNT(*) n FROM sales_lines").fetchone()['n']
    conn.close()
    cfg = store_cfg()
    try:
        start = datetime.date.fromisoformat(cfg['start'])
    except ValueError:
        start = datetime.date.fromisoformat(STORE_DEFAULT_START)
    yesterday = datetime.date.today() - datetime.timedelta(days=1)
    missing = len(store_missing_days(start, yesterday)) if start <= yesterday else 0
    return {'days': r['n'], 'first': r['a'], 'last': r['b'], 'sales': r['s'] or 0, 'lines': lines,
            'missing': missing, 'start': cfg['start'],
            'last_nightly': meta_get('rep_last_nightly'), 'last_nightly_error': meta_get('rep_last_nightly_error')}


# ---------- calcul des rapports à partir de la base locale ----------
def _store_rows(conn, d0, d1, shop_id, level):
    cats = {r['category_id']: r['path'] for r in conn.execute("SELECT category_id, path FROM ls_categories")}
    q = ("SELECT item_id, category_id, SUM(qty) q, SUM(subtotal) s, SUM(discount) d, SUM(total) t, SUM(cost) c, "
         "COUNT(*) n FROM sales_lines WHERE sale_date BETWEEN ? AND ?")
    args = [d0.isoformat(), d1.isoformat()]
    if shop_id:
        q += " AND shop_id=?"
        args.append(str(shop_id))
    agg = {}
    for r in conn.execute(q + " GROUP BY item_id='0', category_id", args).fetchall():
        if r['item_id'] == '0':
            key = REP_MISC
        else:
            path = cats.get(r['category_id'] or '')
            key = REP_NO_CATEGORY if path is None else (path.split('/')[0].strip() if level == 'top' else path)
        a = agg.setdefault(key, {'categorie': key, 'quantite': 0.0, 'sous_total': 0.0, 'rabais': 0.0,
                                 'total': 0.0, 'cout': 0.0, 'lignes': 0})
        for k, col in (('quantite', 'q'), ('sous_total', 's'), ('rabais', 'd'), ('total', 't'), ('cout', 'c')):
            a[k] += r[col] or 0
        a['lignes'] += r['n']
    return agg


def _finish_rows(agg):
    rows = sorted(agg.values(), key=lambda r: -r['total'])
    grand = {k: round(sum(r[k] for r in rows), 2) for k in ('quantite', 'sous_total', 'rabais', 'total', 'cout')}
    grand['lignes'] = sum(r['lignes'] for r in rows)
    for r in rows + [grand]:
        for k in ('quantite', 'sous_total', 'rabais', 'total', 'cout'):
            r[k] = round(r[k], 2)
        r['profit'] = round(r['total'] - r['cout'], 2)
        r['marge'] = round(r['profit'] / r['total'] * 100, 1) if abs(r['total']) >= 0.005 else None
        r['part'] = round(r['total'] / grand['total'] * 100, 1) if abs(grand['total']) >= 0.005 else None
    return rows, grand


def _shop_name(shop_id):
    if not shop_id:
        return ''
    conn = get_conn()
    r = conn.execute("SELECT name FROM ls_shops WHERE shop_id=?", (str(shop_id),)).fetchone()
    conn.close()
    return r['name'] if r else f"#{shop_id}"


def local_sales_by_category(d0, d1, shop_id='', level='full', username=None):
    conn = get_conn()
    try:
        rows, grand = _finish_rows(_store_rows(conn, d0, d1, shop_id, level))
        n = conn.execute("SELECT COUNT(DISTINCT sale_id) n FROM sales_lines WHERE sale_date BETWEEN ? AND ?"
                         + (" AND shop_id=?" if shop_id else ""),
                         [d0.isoformat(), d1.isoformat()] + ([str(shop_id)] if shop_id else [])).fetchone()['n']
    finally:
        conn.close()
    return rep_accounting_layout({'report': 'ventes_par_categorie', 'title': "Rapport de ventes par catégorie d'articles",
            'start': d0.isoformat(), 'end': d1.isoformat(), 'shop_id': shop_id or '', 'shop_name': _shop_name(shop_id),
            'level': level, 'rows': rows, 'totals': grand, 'sales_count': n,
            'generated_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'by': username})


def last_week_bounds(ref=None):
    """Lundi et dimanche de la dernière semaine complète."""
    ref = ref or datetime.date.today()
    monday = ref - datetime.timedelta(days=ref.weekday())
    return monday - datetime.timedelta(days=7), monday - datetime.timedelta(days=1)


def weekly_comparison(week_start, shop_id='', level='top', username=None):
    """Compare la semaine (lundi -> dimanche) à la même semaine 52 semaines plus tôt."""
    a0, a1 = week_start, week_start + datetime.timedelta(days=6)
    b0, b1 = a0 - datetime.timedelta(days=364), a1 - datetime.timedelta(days=364)
    conn = get_conn()
    try:
        cur, _ = _finish_rows(_store_rows(conn, a0, a1, shop_id, level))
        prev, _ = _finish_rows(_store_rows(conn, b0, b1, shop_id, level))
        days = []
        for i in range(7):
            da, db_ = a0 + datetime.timedelta(days=i), b0 + datetime.timedelta(days=i)
            qa = conn.execute("SELECT COALESCE(SUM(total),0) t, COUNT(DISTINCT sale_id) n FROM sales_lines WHERE sale_date=?"
                              + (" AND shop_id=?" if shop_id else ""), [da.isoformat()] + ([str(shop_id)] if shop_id else [])).fetchone()
            qb = conn.execute("SELECT COALESCE(SUM(total),0) t, COUNT(DISTINCT sale_id) n FROM sales_lines WHERE sale_date=?"
                              + (" AND shop_id=?" if shop_id else ""), [db_.isoformat()] + ([str(shop_id)] if shop_id else [])).fetchone()
            days.append({'jour': ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'][i],
                         'date': da.isoformat(), 'date_prec': db_.isoformat(),
                         'total': round(qa['t'], 2), 'total_prec': round(qb['t'], 2),
                         'ventes': qa['n'], 'ventes_prec': qb['n']})
    finally:
        conn.close()
    pa = {r['categorie']: r for r in cur}
    pb = {r['categorie']: r for r in prev}

    def var(a, b):
        return round((a - b) / abs(b) * 100, 1) if abs(b) >= 0.005 else None
    rows = []
    for k in set(pa) | set(pb):
        a, b = pa.get(k, {}), pb.get(k, {})
        ta, tb = a.get('total', 0.0), b.get('total', 0.0)
        rows.append({'categorie': k, 'total': ta, 'total_prec': tb, 'ecart': round(ta - tb, 2), 'variation': var(ta, tb),
                     'profit': a.get('profit', 0.0), 'profit_prec': b.get('profit', 0.0),
                     'marge': a.get('marge'), 'marge_prec': b.get('marge'),
                     'quantite': a.get('quantite', 0.0), 'quantite_prec': b.get('quantite', 0.0)})
    rows.sort(key=lambda r: -max(r['total'], r['total_prec']))
    T = {k: round(sum(r[k] for r in rows), 2) for k in ('total', 'total_prec', 'profit', 'profit_prec', 'quantite', 'quantite_prec')}
    T['ecart'] = round(T['total'] - T['total_prec'], 2)
    T['variation'] = var(T['total'], T['total_prec'])
    T['marge'] = round(T['profit'] / T['total'] * 100, 1) if abs(T['total']) >= 0.005 else None
    T['marge_prec'] = round(T['profit_prec'] / T['total_prec'] * 100, 1) if abs(T['total_prec']) >= 0.005 else None
    T['ventes'] = sum(d['ventes'] for d in days)
    T['ventes_prec'] = sum(d['ventes_prec'] for d in days)
    return {'report': 'comparatif_hebdo', 'title': "Comparatif hebdomadaire — même semaine l'an dernier",
            'start': a0.isoformat(), 'end': a1.isoformat(), 'start_prec': b0.isoformat(), 'end_prec': b1.isoformat(),
            'shop_id': shop_id or '', 'shop_name': _shop_name(shop_id), 'level': level,
            'rows': rows, 'totals': T, 'days': days,
            'generated_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'by': username}


def _d(x):
    return f"{x[8:10]}-{x[5:7]}-{x[:4]}"


def export_comparison_pdf(r):
    from reportlab.lib.pagesizes import letter, landscape
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.graphics.shapes import Drawing, String
    from reportlab.graphics.charts.barcharts import VerticalBarChart
    from reportlab.lib.utils import ImageReader
    out = PDF_DIR / "Rapports_personnalises"
    out.mkdir(exist_ok=True)
    path = out / f"Comparatif_semaine_{r['start']}.pdf"
    page_w, page_h = landscape(letter)
    styles = getSampleStyleSheet()
    cell = ParagraphStyle('c', parent=styles['Normal'], fontSize=8, leading=9.5)
    cell_b = ParagraphStyle('cb', parent=cell, fontName='Helvetica-Bold')
    T = r['totals']
    y1, y0 = r['start'][:4], r['start_prec'][:4]

    def money(v):
        return f"{v:,.2f} $".replace(',', ' ').replace('.', ',')

    def pct(v, sign=False):
        if v is None:
            return '—'
        s = f"{v:+.1f} %" if sign else f"{v:.1f} %"
        return s.replace('.', ',')

    def header(canvas, doc_):
        canvas.saveState()
        top = page_h - 14 * mm
        canvas.setFont('Helvetica-Bold', 15)
        canvas.drawString(14 * mm, top, r['title'])
        canvas.setFont('Helvetica', 9)
        canvas.drawString(14 * mm, top - 6 * mm, f"Semaine du {_d(r['start'])} au {_d(r['end'])} comparée à celle du "
                                                  f"{_d(r['start_prec'])} au {_d(r['end_prec'])}"
                                                  + (f" — {r['shop_name']}" if r['shop_name'] else ''))
        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            lw = 38 * mm
            canvas.drawImage(img, page_w - 14 * mm - lw, top - lw * ih / iw + 3 * mm, width=lw, height=lw * ih / iw, mask='auto')
        canvas.setFont('Helvetica', 8)
        canvas.drawRightString(page_w - 14 * mm, 8 * mm, f"Page {doc_.page}")
        canvas.restoreState()

    doc = SimpleDocTemplate(str(path), pagesize=landscape(letter), leftMargin=14 * mm, rightMargin=14 * mm,
                            topMargin=28 * mm, bottomMargin=14 * mm)
    story = []
    summary = [["", f"Semaine {y1}", f"Semaine {y0}", "Écart", "Variation"],
               ["Ventes (après rabais)", money(T['total']), money(T['total_prec']), money(T['ecart']), pct(T['variation'], True)],
               ["Profit", money(T['profit']), money(T['profit_prec']), money(T['profit'] - T['profit_prec']), ""],
               ["Marge", pct(T['marge']), pct(T['marge_prec']), "", ""],
               ["Nombre de ventes", str(T['ventes']), str(T['ventes_prec']), str(T['ventes'] - T['ventes_prec']), ""]]
    st = Table(summary, colWidths=[45 * mm, 32 * mm, 32 * mm, 30 * mm, 24 * mm])
    st.setStyle(TableStyle([('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'), ('FONTNAME', (0, 1), (0, -1), 'Helvetica-Bold'),
                            ('FONTSIZE', (0, 0), (-1, -1), 8.5), ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
                            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#e5e7eb')),
                            ('LINEBELOW', (0, 0), (-1, -1), 0.25, colors.HexColor('#d1d5db'))]))
    # graphique : ventes par jour, cette année vs l'an dernier
    dr = Drawing(page_w - 28 * mm - 175 * mm, 52 * mm)
    ch = VerticalBarChart()
    ch.x, ch.y, ch.width, ch.height = 30, 18, dr.width - 40, dr.height - 30
    ch.data = [[d['total'] for d in r['days']], [d['total_prec'] for d in r['days']]]
    ch.categoryAxis.categoryNames = [d['jour'][:3] + '.' for d in r['days']]
    ch.categoryAxis.labels.fontSize = 7
    ch.valueAxis.labels.fontSize = 7
    ch.valueAxis.valueMin = 0
    ch.bars[0].fillColor = colors.HexColor('#2563eb')
    ch.bars[1].fillColor = colors.HexColor('#cbd5e1')
    ch.barSpacing = 1
    ch.bars.strokeColor = None
    ch.groupSpacing = 6
    dr.add(ch)
    dr.add(String(30, dr.height - 8, f"Ventes par jour — {y1} (bleu) vs {y0} (gris)", fontSize=8, fontName='Helvetica-Bold'))
    top_t = Table([[st, dr]], colWidths=[170 * mm, None])
    top_t.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'TOP')]))
    story += [top_t, Spacer(1, 5 * mm)]
    data = [["Catégorie", f"Ventes {y1}", f"Ventes {y0}", "Écart", "Variation", f"Profit {y1}", f"Profit {y0}",
             f"Marge {y1}", f"Marge {y0}"]]
    for row in r['rows'] + [dict(T, categorie='TOTAL')]:
        data.append([Paragraph(row['categorie'].replace('&', '&amp;').replace('<', '&lt;'),
                               cell_b if row['categorie'] == 'TOTAL' else cell),
                     money(row['total']), money(row['total_prec']), money(row['ecart']), pct(row['variation'], True),
                     money(row['profit']), money(row['profit_prec']), pct(row['marge']), pct(row['marge_prec'])])
    t = Table(data, colWidths=[72 * mm, 25 * mm, 25 * mm, 24 * mm, 18 * mm, 24 * mm, 24 * mm, 17 * mm, 17 * mm], repeatRows=1)
    style = [('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'), ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
             ('FONTSIZE', (0, 0), (-1, -1), 8), ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
             ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e3a8a')),
             ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#e5e7eb')),
             ('LINEBELOW', (0, 0), (-1, -1), 0.25, colors.HexColor('#d1d5db')),
             ('ALIGN', (1, 0), (-1, -1), 'RIGHT'), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
             ('TOPPADDING', (0, 0), (-1, -1), 3), ('BOTTOMPADDING', (0, 0), (-1, -1), 3)]
    for i, row in enumerate(r['rows'], start=1):
        style.append(('TEXTCOLOR', (3, i), (4, i), colors.HexColor('#15803d') if row['ecart'] >= 0 else colors.HexColor('#b91c1c')))
    t.setStyle(TableStyle(style))
    story.append(t)
    story.append(_pdf_disclaimer())
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


def export_comparison_xlsx(r):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    wb = Workbook()
    ws = wb.active
    ws.title = "Comparatif"
    y1, y0 = r['start'][:4], r['start_prec'][:4]
    ws['A1'] = r['title']
    ws['A1'].font = Font(bold=True, size=14)
    ws['A2'] = f"Semaine du {_d(r['start'])} au {_d(r['end'])} vs {_d(r['start_prec'])} au {_d(r['end_prec'])}"
    heads = ["Catégorie", f"Ventes {y1}", f"Ventes {y0}", "Écart", "Variation", f"Profit {y1}", f"Profit {y0}",
             f"Marge {y1}", f"Marge {y0}"]
    keys = ['categorie', 'total', 'total_prec', 'ecart', 'variation', 'profit', 'profit_prec', 'marge', 'marge_prec']
    for j, h in enumerate(heads, 1):
        c = ws.cell(row=4, column=j, value=h)
        c.font = Font(bold=True, color='FFFFFF')
        c.fill = PatternFill('solid', fgColor='1E3A8A')
    for i, row in enumerate(r['rows'] + [dict(r['totals'], categorie='TOTAL')], start=5):
        for j, k in enumerate(keys, 1):
            v = row.get(k)
            if k in ('variation', 'marge', 'marge_prec'):
                v = None if v is None else v / 100
            c = ws.cell(row=i, column=j, value=v)
            c.number_format = '0.0%' if k in ('variation', 'marge', 'marge_prec') else ('#,##0.00 $;-#,##0.00 $' if j > 1 else 'General')
            if row['categorie'] == 'TOTAL':
                c.font = Font(bold=True)
    ws2 = wb.create_sheet("Par jour")
    for j, h in enumerate(["Jour", f"Date {y1}", f"Ventes {y1}", f"Date {y0}", f"Ventes {y0}"], 1):
        ws2.cell(row=1, column=j, value=h).font = Font(bold=True)
    for i, d in enumerate(r['days'], 2):
        for j, v in enumerate([d['jour'], d['date'], d['total'], d['date_prec'], d['total_prec']], 1):
            ws2.cell(row=i, column=j, value=v)
    ws.column_dimensions['A'].width = 46
    for col in 'BCDEFGHI':
        ws.column_dimensions[col].width = 15
    out = PDF_DIR / "Rapports_personnalises"
    out.mkdir(exist_ok=True)
    path = out / f"Comparatif_semaine_{r['start']}.xlsx"
    for ws_ in wb.worksheets:
        _xlsx_disclaimer(ws_)
    wb.save(path)
    return path


# ---------- envois par courriel ----------
def _report_email_body(r):
    T = r['totals']

    def m(v):
        return f"{v:,.2f} $".replace(',', ' ').replace('.', ',')
    if r['report'] == 'comparatif_hebdo':
        var = '—' if T['variation'] is None else f"{T['variation']:+.1f} %".replace('.', ',')
        return (f"Bonjour,\n\nVoici le comparatif des ventes de la semaine du {_d(r['start'])} au {_d(r['end'])}, "
                f"comparée à la même semaine l'an dernier (du {_d(r['start_prec'])} au {_d(r['end_prec'])}).\n\n"
                f"Ventes : {m(T['total'])} (l'an dernier : {m(T['total_prec'])}, variation {var})\n"
                f"Profit : {m(T['profit'])} (l'an dernier : {m(T['profit_prec'])})\n\n"
                f"Le détail par catégorie et par jour est dans le PDF joint.\n\n{get_company_name()}"
                f"\n\n— {REPORT_DISCLAIMER_TITLE} : {REPORT_DISCLAIMER}")
    period = f"du {_d(r['start'])}" if r['start'] == r['end'] else f"du {_d(r['start'])} au {_d(r['end'])}"
    marge = '—' if T['marge'] is None else f"{T['marge']:.1f} %".replace('.', ',')
    return (f"Bonjour,\n\nVoici le rapport des ventes par catégorie {period}.\n\n"
            f"Ventes (après rabais) : {m(T['total'])}\nProfit : {m(T['profit'])}\nMarge : {marge}\n"
            f"Nombre de ventes : {r['sales_count']}\n\nLe détail par catégorie est dans le PDF joint.\n\n{get_company_name()}"
            f"\n\n— {REPORT_DISCLAIMER_TITLE} : {REPORT_DISCLAIMER}")


def send_report_email(r, emails, username, auto=False, bcc_company=None):
    """Envoie le rapport (PDF joint) à chaque adresse. Retourne (envoyés, erreurs)."""
    pdf = export_comparison_pdf(r) if r['report'] == 'comparatif_hebdo' else export_report_pdf(r)
    if r['report'] == 'comparatif_hebdo':
        subject = f"Comparatif des ventes — semaine du {_d(r['start'])}"
    else:
        subject = "Ventes par catégorie — " + (_d(r['start']) if r['start'] == r['end'] else f"{_d(r['start'])} au {_d(r['end'])}")
    body = _report_email_body(r)
    if bcc_company is None:
        bcc_company = store_cfg()['bcc_company']
    sent, errors = [], []
    com = False
    if get_settings()['send_mode'] != 'smtp':
        try:
            import pythoncom
            pythoncom.CoInitialize()
            com = True
        except Exception:
            pass
    try:
        for e in emails:
            try:
                send_email(e, subject, body, str(pdf), mode='send', bcc_company=bcc_company)
                sent.append(e)
            except Exception as ex:
                errors.append(f"{e} : {ex}")
    finally:
        if com:
            try:
                import pythoncom
                pythoncom.CoUninitialize()
            except Exception:
                pass
    conn = get_conn()
    conn.execute("INSERT INTO report_sends(sent_at, kind, period, recipients, status, error, username) VALUES (?,?,?,?,?,?,?)",
                 (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                  ('auto ' if auto else '') + ('comparatif' if r['report'] == 'comparatif_hebdo' else 'quotidien'),
                  f"{r['start']} au {r['end']}", ", ".join(sent), 'ok' if not errors else ('partiel' if sent else 'echec'),
                  "; ".join(errors) or None, username or '?'))
    conn.commit()
    conn.close()
    db_add_audit(username or '?', 'Rapport envoyé par courriel' + (' (automatique)' if auto else ''),
                 f"{subject} → {', '.join(sent) or 'aucun'}" + (f" ; erreurs : {'; '.join(errors)}" if errors else ""))
    return sent, errors


# ---------- envoi immédiat des rapports automatiques (1.24.1) ----------
_send_now_state = {'running': False, 'message': '', 'error': None, 'kind': None}


def _send_now_days(kind):
    today = datetime.date.today()
    if kind == 'daily':
        y = today - datetime.timedelta(days=1)
        return y, store_missing_days(y, y)
    w0, _ = last_week_bounds(today)
    w1 = w0 + datetime.timedelta(days=6)
    return w0, store_missing_days(w0, w1) + store_missing_days(w0 - datetime.timedelta(days=364), w0 - datetime.timedelta(days=358))


def _send_now_worker(kind, to, level, username):
    st = _send_now_state
    label = 'le rapport de la veille' if kind == 'daily' else 'le comparatif de la semaine passée'
    try:
        start, missing = _send_now_days(kind)
        if missing:
            if not _store_lock.acquire(blocking=False):
                raise LightspeedError("Une lecture Lightspeed est déjà en cours. Réessaie dans quelques minutes.")
            ss = _store_state
            ss.update(running=True, progress=f"Envoi immédiat : lecture des ventes manquantes ({len(missing)} jour(s))…", error=None, kind='envoi')
            try:
                store_sync_days(sorted(set(missing)), ss, 'envoi')
            finally:
                ss['running'] = False
                ss['progress'] = ''
                _store_lock.release()
        st['message'] = "Préparation et envoi " + ('du rapport de la veille…' if kind == 'daily' else 'du comparatif de la semaine passée…')
        r = local_sales_by_category(start, start, '', level, username) if kind == 'daily' else weekly_comparison(start, '', level, username)
        sent, errors = send_report_email(r, to, username)
        st['message'] = (f"{label[0].upper() + label[1:]} a été envoyé à {len(sent)} gestionnaire(s)." if sent else '') \
            + (f" Erreurs : {'; '.join(errors)}" if errors else '')
        st['error'] = None if not errors else st['message']
    except Exception as e:
        if not isinstance(e, LightspeedError):
            traceback.print_exc()
        st['error'] = st['message'] = f"Envoi impossible : {e}"
        db_add_audit(username or '?', 'Envoi immédiat d\'un rapport — échec', str(e))
    finally:
        st['running'] = False


# ---------- tâche de nuit ----------
def nightly_reports_run(force=False):
    """Récupère les ventes (7 derniers jours + historique manquant), puis envoie
    le rapport de la veille et, au besoin, le comparatif de la semaine passée."""
    cfg = store_cfg()
    if not _store_lock.acquire(blocking=False):
        return
    st = _store_state
    st.update(running=True, progress="Tâche de nuit : connexion à Lightspeed…", error=None, kind='nuit')
    today = datetime.date.today()
    yesterday = today - datetime.timedelta(days=1)
    try:
        start = datetime.date.fromisoformat(cfg['start'])
        days = {yesterday - datetime.timedelta(days=i) for i in range(7)}
        days |= set(store_missing_days(start, yesterday))
        store_sync_days(sorted(d for d in days if d >= start or d >= yesterday - datetime.timedelta(days=6)), st, 'nuit')
        meta_set('rep_last_nightly', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        meta_delete('rep_last_nightly_error')
    except Exception as e:
        if not isinstance(e, LightspeedError):
            traceback.print_exc()
        meta_set('rep_last_nightly_error', f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M')} — {e}")
        db_add_audit('Tâche de nuit', 'Récupération des ventes Lightspeed — échec', str(e))
        return
    finally:
        st['running'] = False
        st['progress'] = ''
        _store_lock.release()
    daily_to = [x['email'] for x in cfg['recipients'] if x.get('daily') and x.get('email')]
    weekly_to = [x['email'] for x in cfg['recipients'] if x.get('weekly') and x.get('email')]
    if cfg['auto_daily'] and daily_to and meta_get('rep_last_daily_sent') != yesterday.isoformat():
        r = local_sales_by_category(yesterday, yesterday, '', cfg['daily_level'], 'Envoi automatique')
        send_report_email(r, daily_to, 'Envoi automatique', auto=True)
        meta_set('rep_last_daily_sent', yesterday.isoformat())
    w0, _ = last_week_bounds(today)
    if cfg['auto_weekly'] and weekly_to and meta_get('rep_last_weekly_sent') != w0.isoformat():
        r = weekly_comparison(w0, '', cfg['weekly_level'], 'Envoi automatique')
        send_report_email(r, weekly_to, 'Envoi automatique', auto=True)
        meta_set('rep_last_weekly_sent', w0.isoformat())


def _nightly_loop():
    while True:
        time.sleep(LS_AUTO_CHECK_SECONDS)
        try:
            cfg = store_cfg()
            if not cfg['enabled'] or not ls_config()['connected']:
                continue
            now = datetime.datetime.now()
            if now.hour < cfg['hour'] or meta_get('rep_nightly_date') == now.date().isoformat():
                continue
            meta_set('rep_nightly_date', now.date().isoformat())
            nightly_reports_run()
        except Exception as e:
            traceback.print_exc()
            print("Tâche de nuit des rapports :", e)


# ============================================================
# Sécurité des comptes (1.14.0) : mot de passe oublié + double authentification
# ------------------------------------------------------------
# - Mot de passe oublié : lien envoyé au courriel de l'utilisateur, valide 1 h,
#   une seule fois (seul le hachage du jeton est gardé). La page ne dit jamais
#   si le compte existe. Réinitialiser le mot de passe ne contourne pas la 2FA.
# - 2FA, exigée utilisateur par utilisateur par un administrateur. L'utilisateur
#   choisit sa méthode à la première connexion : application (TOTP, RFC 6238 :
#   Google / Microsoft Authenticator) ou code de 6 chiffres par courriel.
# ============================================================
RESET_TOKEN_TTL = 3600
RESET_MAX_PER_HOUR = 3
MFA_PENDING_TTL = 600
MFA_EMAIL_CODE_TTL = 600
MFA_MAX_ATTEMPTS = 5
MFA_LOCK_SECONDS = 900
PASSWORD_MIN_LEN = 8


def _sha256(t):
    import hashlib
    return hashlib.sha256(t.encode('utf-8')).hexdigest()


def _send_plain_email(to_email, subject, body):
    """Courriel sans pièce jointe ni copie à l'entreprise (codes, liens)."""
    com = False
    if get_settings()['send_mode'] != 'smtp':
        try:
            import pythoncom
            pythoncom.CoInitialize()
            com = True
        except Exception:
            pass
    try:
        send_email(to_email, subject, body, None, mode='send', bcc_company=False)
    finally:
        if com:
            try:
                import pythoncom
                pythoncom.CoUninitialize()
            except Exception:
                pass


def _mask_email(e):
    if not e or '@' not in e:
        return ''
    name, dom = e.split('@', 1)
    return (name[:2] + '•' * max(1, len(name) - 2)) + '@' + dom


# ---------- TOTP (application d'authentification) ----------
def _b32_secret():
    import base64
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip('=')


def _totp_at(secret, step):
    import base64, hmac, hashlib, struct
    key = base64.b32decode(secret + '=' * (-len(secret) % 8))
    h = hmac.new(key, struct.pack('>Q', step), hashlib.sha1).digest()
    o = h[-1] & 0x0F
    return f"{(struct.unpack('>I', h[o:o + 4])[0] & 0x7FFFFFFF) % 1000000:06d}"


def totp_check(secret, code, last_step=0):
    """Retourne le pas de temps accepté (±30 s de tolérance), ou None. Un code
    déjà utilisé (pas <= last_step) est refusé."""
    code = re.sub(r'\D', '', code or '')
    if len(code) != 6 or not secret:
        return None
    now = int(time.time() // 30)
    if (last_step or 0) > now + 2:        # 1.34.1 : l'horloge du PC a reculé (corrigée) — ne pas bloquer tous les codes
        last_step = 0
    for d in (0, -1, 1, -2, 2):           # ±60 s de tolérance
        s = now + d
        if s > (last_step or 0) and secrets.compare_digest(_totp_at(secret, s), code):
            return s
    return None


def totp_diagnose(secret, code, last_step=0):
    """Code refusé : explique pourquoi (déjà utilisé, ou horloge du PC décalée). Retourne (message, décalage en minutes) ou (None, None)."""
    code = re.sub(r'\D', '', code or '')
    if len(code) != 6 or not secret:
        return None, None
    now = int(time.time() // 30)
    for d in sorted(range(-60, 61), key=abs):     # jusqu'à ±30 minutes
        if secrets.compare_digest(_totp_at(secret, now + d), code):
            if abs(d) <= 2:
                return "Ce code vient d'être utilisé. Attends le prochain code (moins de 30 secondes).", 0
            mins = round(d * 30 / 60)
            return (f"L'horloge de l'ordinateur où roule Kubios semble décalée d'environ {abs(mins) or 1} minute(s) "
                    f"par rapport à ton téléphone ({'le PC est en retard' if d > 0 else 'le PC est en avance'}). "
                    "Sur ce PC : Paramètres Windows → Heure et langue → Date et heure → « Synchroniser maintenant ». "
                    "Vérifie aussi que l'heure du téléphone est automatique."), mins
    return None, None


def totp_qr_svg(username, secret):
    from reportlab.graphics.barcode.qr import QrCodeWidget
    from reportlab.graphics.shapes import Drawing
    from reportlab.graphics import renderSVG
    issuer = f"Kubios — {get_company_name()}"
    uri = (f"otpauth://totp/{urllib.parse.quote(issuer)}:{urllib.parse.quote(username)}"
           f"?secret={secret}&issuer={urllib.parse.quote(issuer)}&digits=6&period=30")
    w = QrCodeWidget(uri)
    b = w.getBounds()
    size = 210
    d = Drawing(size, size, transform=[size / (b[2] - b[0]), 0, 0, size / (b[3] - b[1]), 0, 0])
    d.add(w)
    svg = renderSVG.drawToString(d)
    return svg[svg.find('<svg'):]


# ---------- base de données ----------
def db_user_security(user_id):
    conn = get_conn()
    r = conn.execute("SELECT id, username, full_name, email, active, is_admin, permissions, mfa_required, mfa_method, "
                     "mfa_secret, mfa_last_step, mfa_pending_secret FROM users WHERE id=?", (user_id,)).fetchone()
    conn.close()
    return dict(r) if r else None


def db_set_user_mfa(user_id, **fields):
    allowed = {'mfa_required', 'mfa_method', 'mfa_secret', 'mfa_last_step', 'mfa_pending_secret', 'email', 'full_name'}
    sets = [(k, v) for k, v in fields.items() if k in allowed]
    if not sets:
        return
    conn = get_conn()
    conn.execute("UPDATE users SET " + ", ".join(f"{k}=?" for k, _ in sets) + " WHERE id=?",
                 [v for _, v in sets] + [user_id])
    conn.commit()
    conn.close()


def _mfa_challenge(user_id):
    conn = get_conn()
    r = conn.execute("SELECT * FROM mfa_challenges WHERE user_id=?", (user_id,)).fetchone()
    conn.close()
    return dict(r) if r else {'user_id': user_id, 'code_hash': None, 'expires_at': 0, 'attempts': 0, 'locked_until': 0}


def _mfa_save_challenge(ch):
    conn = get_conn()
    conn.execute("INSERT OR REPLACE INTO mfa_challenges(user_id, code_hash, expires_at, attempts, locked_until) "
                 "VALUES (?,?,?,?,?)", (ch['user_id'], ch['code_hash'], ch['expires_at'], ch['attempts'],
                                        ch['locked_until']))
    conn.commit()
    conn.close()


def mfa_send_email_code(user):
    """Envoie un code de 6 chiffres au courriel de l'utilisateur (valide 10 min)."""
    code = f"{secrets.randbelow(1000000):06d}"
    ch = _mfa_challenge(user['id'])
    ch.update(code_hash=_sha256(f"{user['id']}:{code}"), expires_at=time.time() + MFA_EMAIL_CODE_TTL)
    _mfa_save_challenge(ch)
    _send_plain_email(user['email'], f"Code de connexion Kubios : {code}",
                      f"Bonjour {user['username']},\n\nVotre code de connexion à Kubios est : {code}\n\n"
                      f"Il est valide 10 minutes. Si vous n'avez pas tenté de vous connecter, "
                      f"avertissez un administrateur.\n\n{get_company_name()}")


def mfa_verify(user, code, method=None, secret=None):
    """Vérifie un code (méthode active de l'utilisateur, ou celle en cours
    d'inscription). Retourne (ok, message d'erreur)."""
    ch = _mfa_challenge(user['id'])
    if ch['locked_until'] and time.time() < ch['locked_until']:
        mins = int((ch['locked_until'] - time.time()) // 60) + 1
        return False, f"Trop d'essais. Réessaie dans {mins} minute(s)."
    method = method or user['mfa_method']
    ok = False
    if method == 'totp':
        step = totp_check(secret or user['mfa_secret'], code, user.get('mfa_last_step') or 0)
        if step:
            db_set_user_mfa(user['id'], mfa_last_step=step)
            ok = True
    elif method == 'email':
        c = re.sub(r'\D', '', code or '')
        if ch['code_hash'] and time.time() < ch['expires_at'] and \
                secrets.compare_digest(ch['code_hash'], _sha256(f"{user['id']}:{c}")):
            ok = True
            ch['code_hash'] = None
        elif ch['code_hash'] and time.time() >= ch['expires_at']:
            return False, "Ce code est expiré. Demande un nouveau code."
    if ok:
        ch.update(attempts=0, locked_until=0)
        _mfa_save_challenge(ch)
        return True, None
    diag = None
    if method == 'totp':
        diag, off = totp_diagnose(secret or user['mfa_secret'], code, user.get('mfa_last_step') or 0)
        if off:
            db_add_audit(user['username'], '2FA : horloge du PC décalée', f"environ {off:+d} min par rapport au téléphone")
    ch['attempts'] += 1
    if ch['attempts'] >= MFA_MAX_ATTEMPTS:
        ch.update(attempts=0, locked_until=time.time() + MFA_LOCK_SECONDS)
        _mfa_save_challenge(ch)
        db_add_audit(user['username'], '2FA : compte bloqué 15 minutes (trop d\'essais)')
        return False, "Trop d'essais. Réessaie dans 15 minutes."
    _mfa_save_challenge(ch)
    return False, diag or "Code incorrect."


def db_create_reset_token(user_id, ip):
    token = secrets.token_urlsafe(32)
    now = time.time()
    conn = get_conn()
    try:
        n = conn.execute("SELECT COUNT(*) n FROM password_resets WHERE user_id=? AND created_at > ?",
                         (user_id, now - 3600)).fetchone()['n']
        if n >= RESET_MAX_PER_HOUR:
            return None
        conn.execute("INSERT INTO password_resets(token_hash, user_id, created_at, expires_at, used_at, ip) "
                     "VALUES (?,?,?,?,NULL,?)", (_sha256(token), user_id, now, now + RESET_TOKEN_TTL, ip))
        conn.commit()
    finally:
        conn.close()
    return token


def db_reset_token_user(token):
    conn = get_conn()
    r = conn.execute("SELECT * FROM password_resets WHERE token_hash=?", (_sha256(token or ''),)).fetchone()
    conn.close()
    if not r or r['used_at'] or time.time() > r['expires_at']:
        return None
    u = db_user_security(r['user_id'])
    return u if u and u['active'] else None


def db_use_reset_token(token, user_id, new_password):
    conn = get_conn()
    try:
        conn.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new_password), user_id))
        conn.execute("UPDATE password_resets SET used_at=? WHERE user_id=? AND used_at IS NULL", (time.time(), user_id))
        conn.commit()
    finally:
        conn.close()


def _find_user_for_reset(ident):
    ident = (ident or '').strip()
    if not ident:
        return None
    conn = get_conn()
    r = conn.execute("SELECT id FROM users WHERE active=1 AND (LOWER(username)=LOWER(?) OR "
                     "(email IS NOT NULL AND LOWER(email)=LOWER(?)))", (ident, ident)).fetchall()
    conn.close()
    return db_user_security(r[0]['id']) if len(r) == 1 else None


def _safe_next(nxt):
    nxt = nxt or ''
    return nxt if nxt.startswith('/') and not nxt.startswith('//') else url_for('index')


def _finish_login(user, nxt):
    session.clear()
    session['user_id'] = user['id']
    session['username'] = user['username']
    session['is_admin'] = bool(user['is_admin'])
    perms = user.get('permissions', [])
    if isinstance(perms, str):
        try:
            perms = json.loads(perms or '[]')
        except ValueError:
            perms = []
    session['permissions'] = [p for p in perms if p in PERMISSION_KEYS]
    try:
        conn = get_conn()
        r = conn.execute("SELECT full_name FROM users WHERE id=?", (user['id'],)).fetchone()
        conn.close()
        session['full_name'] = (r['full_name'] if r else None) or None
    except Exception:
        session['full_name'] = None
    session.permanent = True
    try:
        session['sid'] = sess_open('user', user['id'], user['username'], session.get('full_name') or user['username'])
        session['sid_ts'] = time.time()
    except Exception:
        traceback.print_exc()
    try:
        if license_expiring_items():
            session['license_warn'] = True
    except Exception:
        traceback.print_exc()
    db_add_audit(user['username'], 'Connexion', f"adresse {client_ip()}")
    return redirect(_safe_next(nxt))


AUTH_PUBLIC_ENDPOINTS = ('forgot_password', 'reset_password', 'login_mfa', 'login_mfa_setup',
                         'atelier_punch_page', 'api_atelier_kiosk', 'api_atelier_punch', 'atelier_kiosk_login', 'atelier_kiosk_forget',
                         'api_atelier_kiosk_message', 'api_atelier_kiosk_thread',
                         'tc_station_page', 'api_tc_station', 'api_tc_punch', 'emp_login', 'emp_logout', 'emp_activate', 'emp_forgot',
                         'emp_home', 'api_emp_me', 'api_emp_hours', 'api_emp_documents', 'api_emp_doc_file', 'api_emp_doc_sign', 'api_emp_schedule')


# ============================================================
# Messages aux utilisateurs — bandeaux (1.15.0)
# ------------------------------------------------------------
# Un administrateur publie un message (couleur, période). Tant qu'il est actif
# et dans sa période, il s'affiche en bandeau en haut de toutes les pages pour
# les utilisateurs connectés. Le bandeau est inséré automatiquement dans chaque
# page HTML (after_request) : aucune page n'a besoin d'être modifiée.
# ============================================================
ANN_COLORS = {
    'red': ('#fef2f2', '#991b1b', '#fca5a5', '⚠'),
    'yellow': ('#fffbeb', '#854d0e', '#fcd34d', '⚠'),
    'blue': ('#eff6ff', '#1e40af', '#93c5fd', 'ℹ'),
}
ANN_ORDER = {'red': 0, 'yellow': 1, 'blue': 2}
ANN_SKIP_ENDPOINTS = ('login', 'logout', 'static', 'lightspeed_oauth_callback', 'activation_page',
                      'forgot_password', 'reset_password', 'login_mfa', 'login_mfa_setup')


def ann_status(a, today=None):
    today = today or datetime.date.today().isoformat()
    if not a['active']:
        return 'desactive'
    if a['start_date'] and today < a['start_date']:
        return 'programme'
    if a['end_date'] and today > a['end_date']:
        return 'expire'
    return 'actif'


def db_list_announcements():
    conn = get_conn()
    rows = [dict(r) for r in conn.execute("SELECT * FROM announcements ORDER BY id DESC").fetchall()]
    conn.close()
    for r in rows:
        r['status'] = ann_status(r)
    return rows


def db_active_announcements():
    today = datetime.date.today().isoformat()
    conn = get_conn()
    rows = [dict(r) for r in conn.execute(
        "SELECT * FROM announcements WHERE active=1 AND (start_date IS NULL OR start_date <= ?) "
        "AND (end_date IS NULL OR end_date >= ?)", (today, today)).fetchall()]
    conn.close()
    rows.sort(key=lambda a: (ANN_ORDER.get(a['color'], 9), -a['id']))
    return rows


def render_announcement_banners(rows):
    from markupsafe import escape
    out = []
    for a in rows:
        bg, fg, border, icon = ANN_COLORS.get(a['color'], ANN_COLORS['blue'])
        text = str(escape(a['message'])).replace('\n', '<br>')
        until = ''
        if a.get('end_date'):
            e = a['end_date']
            until = (f'<span style="opacity:.75;font-weight:400;white-space:nowrap;margin-left:10px">'
                     f'(jusqu\'au {e[8:10]}-{e[5:7]}-{e[:4]})</span>')
        out.append(
            f'<div class="kubios-banner" role="alert" style="background:{bg};color:{fg};border-bottom:2px solid {border};'
            f'padding:10px 24px;font:600 14px/1.45 Segoe UI,Arial,sans-serif;display:flex;gap:10px;'
            f'align-items:flex-start;justify-content:center;text-align:left;position:relative;z-index:40">'
            f'<span aria-hidden="true" style="font-size:16px;line-height:1.3">{icon}</span>'
            f'<span>{text}{until}</span></div>')
    return ''.join(out)


_BODY_TAG = re.compile(r'<body[^>]*>', re.I)
_BODY_END = re.compile(r'</body\s*>', re.I)

# Menu latéral permanent (1.18.0) : ajouté autour de chaque page HTML des
# utilisateurs connectés ; les pages elles-mêmes ne changent pas.
SIDEBAR_SKIP_ENDPOINTS = ANN_SKIP_ENDPOINTS + ('atelier_punch_page', 'atelier_direct_page', 'tc_station_page', 'emp_login', 'emp_activate',
                                                'emp_forgot', 'emp_home')   # poste de punch : plein écran pour la tablette
SIDEBAR_GROUPS = (
    (None, (('index', 'Accueil', None, 'home'), ('dashboard3d_page', 'Tableau de bord 3D', 'dashboard3d', 'cube'))),
    ('Clients et comptes', (('car_page', 'Comptes à recevoir', 'comptes_recevoir', 'invoice'),
                            ('credit_accounts_page', 'Comptes de crédit', 'credit_accounts', 'card'))),
    ('Rapports', (('custom_reports_page', 'Rapport des ventes', 'custom_reports', 'bars'),
                  ('tax_report_page', 'Rapport des taxes', 'tax_reports', 'percent'),
                  ('inventory_report_page', "Valeur de l'inventaire", 'inventory_reports', 'box'))),
    ('Gestion Atelier', (('atelier_punch_page', 'Poste de punch', 'atelier_punch', 'clock'),
                         ('atelier_page', 'Atelier', 'atelier', 'wrench'))),
    ('Gestion RH', (('hr_page', 'Dossiers des employés', 'rh', 'idcard'), ('sched_page', 'Horaires', 'rh', 'list'), ('tc_sheets_page', 'Feuilles de temps', 'rh', 'clock'),
                    ('tc_station_page', 'Punch des employés', 'punch_presence', 'clock'), ('hr_admin_page', 'Administration RH', 'admin', 'list'))),
    ('Gestion', (('admin_users_page', 'Utilisateurs', 'admin', 'users'), ('sessions_page', 'En ligne', 'admin', 'clock'),
                 ('announcements_page', 'Messages aux utilisateurs', 'admin', 'megaphone'),
                 ('admin_settings_page', 'Entreprise', 'admin', 'building'),
                 ('full_backups_page', 'Sauvegardes', 'admin', 'download'))),
    ('Système', (('email_settings_page', "Paramètres d'envoi", 'email_settings', 'mail'),
                 ('audit_page', "Journal d'audit", 'audit', 'list'),
                 ('updates_page', 'Mises à jour', 'updates', 'refresh'),
                 ('activation_page', 'Licence', 'license', 'lock'))),
)
SIDEBAR_ICONS = {
    'home': '<path d="M3 11l9-7 9 7v9a1 1 0 01-1 1h-5v-6h-6v6H4a1 1 0 01-1-1z"/>',
    'invoice': '<path d="M7 3h10l2 3v15H5V6z"/><path d="M9 11h6M9 15h6"/>',
    'card': '<rect x="3" y="6" width="18" height="13" rx="2"/><path d="M3 10h18"/>',
    'bars': '<path d="M4 19V10M10 19V5M16 19v-6M22 19H2"/>',
    'box': '<path d="M3 7l9-4 9 4v10l-9 4-9-4z"/><path d="M3 7l9 4 9-4M12 11v10"/>',
    'clock': '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    'wrench': '<path d="M14.7 6.3a4 4 0 00-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 005.4-5.4l-2.6 2.6-2.4-.6-.6-2.4z"/>',
    'idcard': '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2.2"/><path d="M5.8 16c.6-1.6 1.8-2.4 3.2-2.4s2.6.8 3.2 2.4M14 10h4M14 13h3"/>',
    'cube': '<path d="M12 2l8 4.5v9L12 20l-8-4.5v-9z"/><path d="M4 6.5l8 4.5 8-4.5M12 11v9"/><path d="M8 4.3l8 4.4"/>',
    'percent': '<path d="M19 5L5 19"/><circle cx="7" cy="7" r="2.5"/><circle cx="17" cy="17" r="2.5"/>',
    'users': '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.5 3.4-5.5 6.5-5.5s5.7 2 6.5 5.5M16 4.5a3.5 3.5 0 010 7"/>',
    'megaphone': '<path d="M3 11l15-6v14L3 13z"/><path d="M8 13v5a2 2 0 004 0v-3.5"/>',
    'building': '<path d="M4 21V8l8-5 8 5v13"/><path d="M9 21v-6h6v6"/>',
    'download': '<path d="M12 3v12M7 10l5 5 5-5"/><path d="M4 17v3h16v-3"/>',
    'mail': '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
    'list': '<path d="M8 4h11v16H8zM5 7v13h11"/><path d="M11 9h5M11 13h5"/>',
    'refresh': '<path d="M20 12a8 8 0 11-2.3-5.7M20 4v5h-5"/>',
    'lock': '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 018 0v3"/>',
    'logout': '<path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h11"/>',
}
SIDEBAR_CSS = '''<style id="kbs-style">
.kbs-shell{display:flex;min-height:100vh;align-items:stretch}
.kbs-side{flex:0 0 248px;width:248px;box-sizing:border-box;background:#0f172a;color:#cbd5e1;padding:16px 12px;
  display:flex;flex-direction:column;gap:2px;font-family:"Segoe UI",system-ui,Arial,sans-serif;font-size:14px;line-height:1.3;
  position:sticky;top:0;height:100vh;overflow-y:auto;z-index:30}
.kbs-side *{box-sizing:border-box}
.kbs-brand{display:flex;align-items:center;gap:10px;padding:4px 10px 14px;color:#fff;font-weight:700;font-size:18px;text-decoration:none}
.kbs-brand img{width:30px;height:30px;border-radius:8px}
.kbs-brand small{display:block;font-weight:400;font-size:11.5px;color:#94a3b8;margin-top:1px}
.kbs-head{font-size:11px;font-weight:700;letter-spacing:.7px;text-transform:uppercase;color:#94a3b8;padding:14px 12px 5px}
.kbs-side a.kbs-item{display:flex;align-items:center;gap:12px;padding:9px 12px;border-radius:9px;color:#cbd5e1;text-decoration:none;font-size:14px;font-weight:400}
.kbs-side a.kbs-item:hover{background:rgba(255,255,255,.08);color:#fff;text-decoration:none}
.kbs-side a.kbs-item.on{background:rgba(96,165,250,.2);color:#fff;font-weight:600}
.kbs-side svg{width:18px;height:18px;flex:none;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.kbs-user{margin-top:auto;border-top:1px solid rgba(255,255,255,.12);padding:12px 6px 0;display:flex;align-items:center;gap:10px}
.kbs-av{width:36px;height:36px;border-radius:50%;background:#3b82f6;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;flex:none}
.kbs-who{flex:1;min-width:0}
.kbs-who b{display:block;color:#fff;font-weight:600;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.kbs-who span{font-size:12px;color:#94a3b8}
.kbs-side a.kbs-out{width:40px;height:40px;border-radius:9px;display:flex;align-items:center;justify-content:center;color:#cbd5e1}
.kbs-side a.kbs-out:hover{background:rgba(255,255,255,.08);color:#fff}
.kbs-main{flex:1 1 auto;min-width:0}
@media (max-width: 900px){
  .kbs-shell{flex-direction:column}
  .kbs-side{position:static;width:auto;flex:none;height:auto;flex-direction:row;flex-wrap:wrap;gap:4px;padding:10px}
  .kbs-head{display:none}.kbs-brand{padding:4px 8px;font-size:16px}
  .kbs-user{margin:0 0 0 auto;border:0;padding:0}.kbs-who{display:none}
}
@media print{.kbs-side{display:none !important}.kbs-shell{display:block}}
</style>'''


def _sidebar_allowed(perm):
    if perm is None:
        return True
    if session.get('is_admin'):
        return True
    return perm != 'admin' and perm in (session.get('permissions') or [])


def current_display_name():
    name = session.get('full_name')
    if not name and session.get('user_id'):
        try:
            conn = get_conn()
            r = conn.execute("SELECT full_name FROM users WHERE id=?", (session['user_id'],)).fetchone()
            conn.close()
            name = r['full_name'] if r else None
        except Exception:
            name = None
    return (name or session.get('username') or '').strip()


def _initials(name):
    parts = [p for p in re.split(r'[\s._-]+', name or '') if p]
    return ((parts[0][0] + (parts[-1][0] if len(parts) > 1 else '')) if parts else '?').upper()


ATELIER_ALERT_SNIPPET = """<style>
.kbs-badge{margin-left:auto;min-width:20px;height:20px;padding:0 6px;border-radius:10px;background:#ef4444;color:#fff;font-size:11.5px;font-weight:800;display:inline-flex;align-items:center;justify-content:center}
.kbs-badge[hidden]{display:none}
#kbsAtToast{position:fixed;right:18px;bottom:18px;z-index:900;max-width:380px;background:#7f1d1d;color:#fff;border-radius:12px;padding:12px 14px 12px 16px;box-shadow:0 12px 32px rgba(0,0,0,.3);font-family:Segoe UI,Arial,sans-serif;font-size:14px;display:flex;gap:10px;align-items:flex-start}
#kbsAtToast.msg{background:#1e3a8a}
#kbsAtToast a{color:#fff;font-weight:700}
#kbsAtToast button{background:transparent;border:0;color:#fff;font-size:18px;cursor:pointer;line-height:1}
</style>
<script>(function(){
  var seen = null;
  function esc(t){ return String(t == null ? '' : t).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function check(){
    fetch('/api/atelier/unread').then(function(r){ return r.ok ? r.json() : null; }).then(function(d){
      if (!d) return;
      var b = document.getElementById('kbsAtBadge');
      if (b){ b.hidden = !d.unread; b.textContent = d.unread; b.title = d.problems ? d.problems + ' problème(s) à régler' : 'Messages non lus'; }
      var l = d.last;
      if (l && seen !== null && l.id > seen && location.hash !== '#messages'){
        var t = document.getElementById('kbsAtToast'); if (t) t.remove();
        t = document.createElement('div'); t.id = 'kbsAtToast'; t.setAttribute('role', 'alert');
        if (l.kind !== 'probleme') t.className = 'msg';
        t.innerHTML = '<span aria-hidden="true">' + (l.kind === 'probleme' ? '⚠' : '💬') + '</span><span style="flex:1"><b>' + esc(l.name) + '</b>'
          + (l.job ? ' — bon ' + esc(l.job) : '') + ' : ' + esc(l.kind === 'probleme' ? l.category_label + (l.text ? ' — ' + l.text : '') : l.text)
          + '<br><a href="__URL__">Voir et répondre</a></span><button aria-label="Fermer">×</button>';
        t.querySelector('button').onclick = function(){ t.remove(); };
        document.body.appendChild(t);
      }
      seen = l ? Math.max(seen || 0, l.id) : (seen || 0);
    }).catch(function(){});
  }
  check(); setInterval(check, 15000);
})();</script>"""


def render_sidebar():
    from markupsafe import escape
    ep = request.endpoint
    out = ['<aside class="kbs-side" aria-label="Menu principal">',
           f'<a class="kbs-brand" href="{url_for("index")}"><img src="{url_for("static", filename="kubios_icon.png")}" alt="">'
           f'<span>Kubios<small>{escape(get_company_name())}</small></span></a>']
    for title, items in SIDEBAR_GROUPS:
        visible = [it for it in items if _sidebar_allowed(it[2]) and
                   (endpoint_module(it[0]) is None or license_module_active(endpoint_module(it[0])))]
        if not visible:
            continue
        if title:
            out.append(f'<div class="kbs-head">{escape(title)}</div>')
        for endpoint, label, _perm, icon in visible:
            try:
                href = url_for(endpoint)
            except Exception:
                continue
            on = ' on' if ep == endpoint else ''
            cur = ' aria-current="page"' if on else ''
            badge = '<span class="kbs-badge" id="kbsAtBadge" hidden></span>' if endpoint == 'atelier_page' else ''
            out.append(f'<a class="kbs-item{on}" href="{href}"{cur}><svg viewBox="0 0 24 24" aria-hidden="true">'
                       f'{SIDEBAR_ICONS[icon]}</svg>{escape(label)}{badge}</a>')
    # Les anciens liens de navigation en haut des pages font double emploi avec le menu : masqués.
    hide = []
    for _t, items in SIDEBAR_GROUPS:
        for endpoint, *_rest in items:
            try:
                hide.append(url_for(endpoint))
            except Exception:
                pass
    hide.append(url_for('logout'))
    out.append('<style>' + ','.join(f'.kbs-main header a[href="{h}"]' for h in hide) + '{display:none !important}</style>')
    if session.get('is_admin') or 'atelier' in (session.get('permissions') or []):
        out.append(ATELIER_ALERT_SNIPPET.replace('__URL__', url_for('atelier_page') + '#messages'))
    name = current_display_name()
    out.append(f'<div class="kbs-user"><span class="kbs-av" aria-hidden="true">{escape(_initials(name))}</span>'
               f'<span class="kbs-who"><b>{escape(name)}</b><span>{"Administrateur" if session.get("is_admin") else "Utilisateur"}</span></span>'
               f'<a class="kbs-out" href="{url_for("logout")}" aria-label="Se déconnecter" title="Se déconnecter">'
               f'<svg viewBox="0 0 24 24" aria-hidden="true">{SIDEBAR_ICONS["logout"]}</svg></a></div></aside>')
    return ''.join(out)

# Avis d'expiration de la licence (1.17.4) : à chaque connexion, si la licence
# expire dans LICENSE_WARN_DAYS jours ou moins, une fenêtre à confirmer
# (« J'ai compris ») s'affiche par-dessus la première page.
LICENSE_WARN_DAYS = 15
_MOIS_FR = ('janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre',
            'octobre', 'novembre', 'décembre')


def license_expiring_items(st=None):
    """Noyau et modules qui expirent d'ici LICENSE_WARN_DAYS jours : [(libellé, date, jours)]."""
    st = st or get_license_status()
    if not st.get('active'):
        return []
    out = []
    if st.get('days_left') is not None and st['days_left'] <= LICENSE_WARN_DAYS:
        out.append(('Votre licence Kubios', datetime.date.fromisoformat(st['payload']['expires']), st['days_left']))
    for key, m in (st.get('modules') or {}).items():
        if m.get('included') and not m.get('legacy') and m.get('active') and m.get('days_left') is not None \
                and m['days_left'] <= LICENSE_WARN_DAYS:
            out.append((f"Le module {m['label']}", datetime.date.fromisoformat(m['expires']), m['days_left']))
    return out


def render_license_warning():
    from markupsafe import escape
    items = license_expiring_items()
    if not items:
        return ''
    def _when(d):
        return "aujourd'hui" if d == 0 else ("demain" if d == 1 else f"dans {d} jours")
    def _date(e):
        return f"{e.day}{'er' if e.day == 1 else ''} {_MOIS_FR[e.month - 1]} {e.year}"
    days = min(it[2] for it in items)
    lines = ''.join(f"<li style=\"margin-bottom:4px\">{escape(lbl)} expire le <b>{_date(e)}</b> (<b>{_when(d)}</b>).</li>" for lbl, e, d in items)
    urgent = days <= 3
    accent, soft = ('#b91c1c', '#fef2f2') if urgent else ('#b45309', '#fffbeb')
    title = "Votre licence Kubios expire bientôt" if items[0][0] == 'Votre licence Kubios' else "Un module de votre licence expire bientôt"
    return f'''<div id="kubiosLicWarn" style="position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:1000;display:flex;align-items:center;justify-content:center;font-family:Segoe UI,Arial,sans-serif">
  <div role="alertdialog" aria-modal="true" aria-labelledby="kubiosLicTitle" style="background:#fff;border-radius:14px;max-width:470px;width:calc(100% - 40px);box-shadow:0 24px 60px rgba(0,0,0,.35);overflow:hidden">
    <div style="background:{soft};border-bottom:3px solid {accent};padding:18px 22px;display:flex;gap:12px;align-items:center">
      <span aria-hidden="true" style="font-size:26px;line-height:1">⚠</span>
      <h2 id="kubiosLicTitle" style="margin:0;font-size:18px;color:{accent}">{title}</h2>
    </div>
    <div style="padding:18px 22px 6px;font-size:14.5px;line-height:1.6;color:#1f2937">
      <ul style="margin:0 0 10px;padding-left:18px">{lines}</ul>
      <p style="margin:0">Pour éviter toute interruption de service, communiquez avec votre fournisseur afin de la renouveler avant cette date.</p>
    </div>
    <div style="padding:16px 22px 20px;text-align:right">
      <button type="button" id="kubiosLicOk" style="background:linear-gradient(135deg,#3b82f6,#2563eb);color:#fff;border:none;padding:10px 22px;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer">J'ai compris</button>
    </div>
  </div>
</div>
<script>(function(){{var b=document.getElementById('kubiosLicOk');b.focus();b.addEventListener('click',function(){{
fetch('/api/license-warning/ack',{{method:'POST'}}).finally(function(){{var w=document.getElementById('kubiosLicWarn');if(w)w.remove();}});}});}})();</script>'''


@app.after_request
def inject_announcement_banners(resp):
    """Ajoute les bandeaux actifs en haut des pages HTML des utilisateurs connectés."""
    try:
        if (resp.status_code not in (200, 402) or resp.mimetype != 'text/html' or resp.direct_passthrough
                or not session.get('user_id') or (request.endpoint in ANN_SKIP_ENDPOINTS and not
                    (request.endpoint == 'activation_page' and get_license_status().get('active')))):
            return resp
        rows = db_active_announcements()
        warn = render_license_warning() if session.get('license_warn') else ''
        html = resp.get_data(as_text=True)
        m = _BODY_TAG.search(html)
        if not m:
            return resp
        ends = list(_BODY_END.finditer(html))
        if ends and (request.endpoint not in SIDEBAR_SKIP_ENDPOINTS or
                     (request.endpoint == 'activation_page' and get_license_status().get('active'))):
            e = ends[-1].start()
            html = (html[:m.end()] + SIDEBAR_CSS + '<div class="kbs-shell">' + render_sidebar() + '<div class="kbs-main">'
                    + warn + render_announcement_banners(rows) + html[m.end():e] + '</div></div>' + html[e:])
        elif rows or warn:
            html = html[:m.end()] + warn + render_announcement_banners(rows) + html[m.end():]
        else:
            return resp
        resp.set_data(html)
    except Exception:
        traceback.print_exc()
    return resp


# ============================================================
# Sauvegardes complètes (1.16.0)
# ------------------------------------------------------------
# Une archive .zip par sauvegarde : data.db (toutes les données ET la
# configuration : entreprise, utilisateurs, envois, Lightspeed, licence,
# comptes, ventes gardées, messages…), le classeur Excel et les images
# personnalisées (logo, fond de connexion), avec un manifest.json.
# - Copie de la base avec l'API « backup » de SQLite : cohérente même si
#   Kubios est en train d'écrire.
# - Automatique une fois par jour à l'heure choisie ; rétention 7/14/30 jours
#   (la plus récente est toujours gardée).
# - Restauration : sauvegarde de l'état actuel d'abord, vérification de
#   l'archive, remplacement de la base (migrée au besoin vers la version
#   actuelle), du classeur et des images. La connexion Lightspeed actuelle est
#   conservée (ses jetons changent à chaque usage : ceux d'une vieille
#   sauvegarde ne seraient plus valides).
# ============================================================
import zipfile
import tempfile

FB_DEFAULT_DIR = BASE_DIR / "Sauvegardes_completes"
FB_RETENTIONS = (7, 14, 30)
FB_NAME_RE = re.compile(r'^kubios_[0-9A-Za-z_\-]+\.zip$')
FB_KIND_LABELS = {'auto': 'Automatique', 'manuelle': 'Manuelle', 'avant_restauration': 'Avant restauration'}
FB_LS_KEEP = ('ls_client_id', 'ls_client_secret', 'ls_redirect_uri', 'ls_refresh_token', 'ls_account_id',
              'ls_account_name')
_fb_lock = threading.Lock()
_fb_state = {'running': False, 'progress': '', 'error': None}


def fb_cfg():
    try:
        hour = min(max(int(meta_get('fb_hour') or 2), 0), 23)
    except ValueError:
        hour = 2
    try:
        ret = int(meta_get('fb_retention') or 30)
    except ValueError:
        ret = 30
    mode = meta_get('fb_notify_mode') or 'fail'
    return {'enabled': meta_get('fb_enabled') != '0', 'hour': hour,
            'retention': ret if ret in FB_RETENTIONS else 30,
            'dir': (meta_get('fb_dir') or '').strip() or str(FB_DEFAULT_DIR),
            'notify_emails': [e for e in (meta_get('fb_notify_emails') or '').split(',') if e.strip()],
            'notify_mode': mode if mode in ('all', 'fail') else 'fail'}


def fb_notify(ok, info=None, error=None, test=False):
    """Avise par courriel du résultat d'une sauvegarde automatique.
    Retourne (envoyés, erreurs)."""
    cfg = fb_cfg()
    emails = cfg['notify_emails']
    if not emails or (ok and cfg['notify_mode'] != 'all' and not test):
        return [], []
    now = datetime.datetime.now()
    when = now.strftime('%d-%m-%Y à %H:%M')
    company = get_company_name()
    if test:
        subject = f"[Test] Kubios — avis de sauvegarde ({company})"
        body = (f"Bonjour,\n\nCeci est un courriel de test envoyé le {when}.\n\nVous recevrez un avis "
                + ("après chaque sauvegarde automatique (réussie ou en échec)." if cfg['notify_mode'] == 'all'
                   else "seulement si une sauvegarde automatique échoue.")
                + f"\n\nSauvegarde automatique : {'activée' if cfg['enabled'] else 'DÉSACTIVÉE'}, chaque jour à {cfg['hour']} h."
                  f"\nDossier : {cfg['dir']}\n\n{company} — Kubios")
    elif ok:
        try:
            n = len(list(fb_dir().glob('kubios_*.zip')))
        except OSError:
            n = '?'
        subject = f"[Réussie] Kubios — sauvegarde du {now.strftime('%d-%m-%Y')} ({company})"
        body = (f"Bonjour,\n\nLa sauvegarde automatique de Kubios a réussi le {when}.\n\n"
                f"Fichier : {info['name']}\nTaille : {max(1, info['size'] // 1024):,} Ko\n".replace(',', ' ')
                + f"Dossier : {cfg['dir']}\nSauvegardes conservées : {n} (rétention de {cfg['retention']} jours)\n\n"
                  f"Aucune action n'est requise.\n\n{company} — Kubios")
    else:
        subject = f"[ÉCHEC] Kubios — la sauvegarde du {now.strftime('%d-%m-%Y')} a échoué ({company})"
        body = (f"Bonjour,\n\nLa sauvegarde automatique de Kubios a ÉCHOUÉ le {when}.\n\n"
                f"Raison : {error}\n\nÀ vérifier :\n"
                f"- le dossier de destination est accessible ({cfg['dir']}) : disque externe branché, dossier réseau disponible ;\n"
                f"- il reste de l'espace sur ce disque ;\n"
                f"- puis, dans Kubios → Sauvegardes, cliquez sur « Faire une sauvegarde maintenant ».\n\n"
                f"Tant que ce problème n'est pas réglé, les données ne sont pas sauvegardées.\n\n{company} — Kubios")
    sent, errors = [], []
    for e in emails:
        try:
            _send_plain_email(e.strip(), subject, body)
            sent.append(e.strip())
        except Exception as ex:
            errors.append(f"{e.strip()} : {ex}")
    if errors:
        meta_set('fb_notify_error', f"{now.strftime('%Y-%m-%d %H:%M')} — " + "; ".join(errors))
    else:
        meta_delete('fb_notify_error')
    if not test:
        db_add_audit('Sauvegarde automatique', 'Avis de sauvegarde envoyé' if sent else 'Avis de sauvegarde non envoyé',
                     ('réussite' if ok else 'échec') + f" → {', '.join(sent) or 'aucun'}"
                     + (f" ; erreurs : {'; '.join(errors)}" if errors else ""))
    return sent, errors


def fb_dir():
    d = Path(fb_cfg()['dir'])
    try:
        d.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise RuntimeError(f"le dossier de destination est inaccessible ({d}) : {e.strerror or e}. "
                           "Vérifie que le disque externe est branché ou que le dossier réseau est disponible.")
    return d


def _fb_static_files():
    st = LOGO_PATH.parent
    out = [p for p in (LOGO_PATH, LOGO_DEFAULT_BACKUP_PATH) if p.exists()]
    out += sorted(st.glob(LOGIN_BG_CUSTOM_PREFIX + '.*')) + sorted(st.glob(LOGIN_VIDEO_PREFIX + '.*'))
    return out


def _fb_do_backup(kind, username):
    """Crée l'archive (sans prendre _fb_lock : l'appelant le tient)."""
    d = fb_dir()
    now = datetime.datetime.now()
    name = f"kubios_{now.strftime('%Y-%m-%d_%Hh%M%S')}_{kind}.zip"
    final = d / name
    tmp_zip = d / (name + '.partiel')
    tmp_db = Path(tempfile.mkstemp(suffix='.db', prefix='kubios_')[1])
    try:
        _fb_state['progress'] = "Copie de la base de données…"
        src = sqlite3.connect(str(DB_PATH), timeout=60)
        dst = sqlite3.connect(str(tmp_db))
        try:
            src.backup(dst)
            ok = dst.execute("PRAGMA integrity_check").fetchone()[0]
        finally:
            dst.close()
            src.close()
        if ok != 'ok':
            raise RuntimeError(f"La base de données copiée est endommagée ({ok}).")
        files = {}
        _fb_state['progress'] = "Création de l'archive…"
        with zipfile.ZipFile(tmp_zip, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            z.write(tmp_db, 'data.db')
            files['data.db'] = tmp_db.stat().st_size
            if EXCEL_PATH.exists():
                got = _sync_lock.acquire(timeout=180)   # pas pendant une écriture du classeur
                try:
                    z.write(EXCEL_PATH, 'excel/' + EXCEL_PATH.name)
                    files['excel/' + EXCEL_PATH.name] = EXCEL_PATH.stat().st_size
                finally:
                    if got:
                        _sync_lock.release()
            for p in _fb_static_files():
                z.write(p, 'static/' + p.name)
                files['static/' + p.name] = p.stat().st_size
            if HR_DIR.exists():                       # 1.30.0 : documents des dossiers RH
                for p in sorted(HR_DIR.rglob('*')):
                    if p.is_file() and not p.name.startswith('_apercu'):
                        arc = 'rh/' + p.relative_to(HR_DIR).as_posix()
                        z.write(p, arc)
                        files[arc] = p.stat().st_size
            manifest = {'application': 'Kubios', 'version': APP_VERSION, 'created_at': now.strftime('%Y-%m-%d %H:%M:%S'),
                        'kind': kind, 'by': username or '?', 'company': get_company_name(), 'files': files}
            z.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
        os.replace(tmp_zip, final)
    except Exception:
        try:
            tmp_zip.unlink()
        except OSError:
            pass
        raise
    finally:
        try:
            tmp_db.unlink()
        except OSError:
            pass
    meta_set('fb_last', now.strftime('%Y-%m-%d %H:%M:%S'))
    meta_delete('fb_last_error')
    removed = fb_prune()
    db_add_audit(username or '?', 'Sauvegarde complète créée',
                 f"{name} ({final.stat().st_size // 1024} Ko)" + (f" ; {removed} ancienne(s) supprimée(s)" if removed else ""))
    return {'name': name, 'size': final.stat().st_size}


def fb_prune():
    """Supprime les sauvegardes plus vieilles que la rétention (garde toujours la plus récente)."""
    ret = fb_cfg()['retention']
    limit = time.time() - ret * 86400
    zips = sorted(fb_dir().glob('kubios_*.zip'), key=lambda p: p.stat().st_mtime, reverse=True)
    n = 0
    for p in zips[1:]:
        if p.stat().st_mtime < limit:
            try:
                p.unlink()
                n += 1
            except OSError:
                pass
    for p in fb_dir().glob('kubios_*.zip.partiel'):
        if p.stat().st_mtime < time.time() - 86400:
            try:
                p.unlink()
            except OSError:
                pass
    return n


def full_backup(kind, username):
    if not _fb_lock.acquire(blocking=False):
        raise RuntimeError("Une sauvegarde ou une restauration est déjà en cours.")
    _fb_state.update(running=True, progress="Démarrage…", error=None)
    try:
        return _fb_do_backup(kind, username)
    except Exception as e:
        traceback.print_exc()
        _fb_state['error'] = str(e)
        meta_set('fb_last_error', f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M')} — {e}")
        db_add_audit(username or '?', 'Sauvegarde complète — échec', str(e))
        raise
    finally:
        _fb_state.update(running=False, progress='')
        _fb_lock.release()


def fb_read_manifest(path):
    try:
        with zipfile.ZipFile(path) as z:
            names = set(z.namelist())
            m = json.loads(z.read('manifest.json').decode('utf-8')) if 'manifest.json' in names else {}
            m['has_db'] = 'data.db' in names
            return m
    except (zipfile.BadZipFile, OSError, ValueError, KeyError):
        return None


def fb_list():
    out = []
    for p in sorted(fb_dir().glob('kubios_*.zip'), key=lambda p: p.stat().st_mtime, reverse=True):
        m = fb_read_manifest(p) or {}
        out.append({'name': p.name, 'size': p.stat().st_size, 'created_at': m.get('created_at') or
                    datetime.datetime.fromtimestamp(p.stat().st_mtime).strftime('%Y-%m-%d %H:%M:%S'),
                    'kind': m.get('kind', ''), 'kind_label': FB_KIND_LABELS.get(m.get('kind'), m.get('kind') or '?'),
                    'version': m.get('version', '?'), 'by': m.get('by', ''), 'valid': bool(m.get('has_db')),
                    'excel': any(k.startswith('excel/') for k in (m.get('files') or {}))})
    return out


def full_restore(zip_path, username, source_label):
    """Restaure une archive. Lève RuntimeError (message pour l'utilisateur)."""
    m = fb_read_manifest(zip_path)
    if not m or not m.get('has_db'):
        raise RuntimeError("Ce fichier n'est pas une sauvegarde Kubios valide.")
    if not _fb_lock.acquire(blocking=False):
        raise RuntimeError("Une sauvegarde ou une restauration est déjà en cours.")
    held = []
    try:
        for name, lk in (('une récupération des ventes', _store_lock), ('une synchronisation Lightspeed', _ls_sync_lock),
                         ('une vérification des factures Lightspeed', _ls_ar_lock)):
            if not lk.acquire(blocking=False):
                raise RuntimeError(f"Impossible pour le moment : {name} est en cours. Réessaie dans quelques minutes.")
            held.append(lk)
        _fb_state.update(running=True, progress="Vérification de la sauvegarde…", error=None)
        tmp_dir = Path(tempfile.mkdtemp(prefix='kubios_restore_'))
        try:
            with zipfile.ZipFile(zip_path) as z:
                z.extract('data.db', tmp_dir)
                others = [n for n in z.namelist() if n.startswith(('excel/', 'static/', 'rh/')) and not n.endswith('/')]
                for n in others:
                    z.extract(n, tmp_dir)
            new_db = tmp_dir / 'data.db'
            c = sqlite3.connect(str(new_db))
            try:
                ok = c.execute("PRAGMA integrity_check").fetchone()[0]
                tables = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            finally:
                c.close()
            if ok != 'ok' or not {'users', 'meta'} <= tables:
                raise RuntimeError("La base de données de cette sauvegarde est endommagée ou incomplète : rien n'a été modifié.")
            _fb_state['progress'] = "Sauvegarde de l'état actuel…"
            pre = _fb_do_backup('avant_restauration', username)
            keep_ls = {k: meta_get(k) for k in FB_LS_KEEP} if meta_get('ls_refresh_token') else None
            _fb_state['progress'] = "Restauration…"
            got = _sync_lock.acquire(timeout=180)
            try:
                src = sqlite3.connect(str(new_db))
                dst = sqlite3.connect(str(DB_PATH), timeout=60)
                try:
                    src.backup(dst)
                finally:
                    dst.close()
                    src.close()
                init_db_schema()          # sauvegarde d'une version plus ancienne : mise à niveau
                if keep_ls:
                    for k, v in keep_ls.items():
                        if v is None:
                            meta_delete(k)
                        else:
                            meta_set(k, v)
                for p in (tmp_dir / 'excel').glob('*') if (tmp_dir / 'excel').exists() else []:
                    part = EXCEL_PATH.with_name(EXCEL_PATH.stem + '.restauration.xlsx')
                    shutil.copy2(p, part)
                    os.replace(part, EXCEL_PATH)
                if (tmp_dir / 'rh').exists():
                    shutil.copytree(tmp_dir / 'rh', HR_DIR, dirs_exist_ok=True)
                if (tmp_dir / 'static').exists():
                    for old in list(LOGO_PATH.parent.glob(LOGIN_BG_CUSTOM_PREFIX + '.*')) + list(LOGO_PATH.parent.glob(LOGIN_VIDEO_PREFIX + '.*')):
                        try:
                            old.unlink()
                        except OSError:
                            pass
                    for p in (tmp_dir / 'static').glob('*'):
                        shutil.copy2(p, LOGO_PATH.parent / p.name)
            finally:
                if got:
                    _sync_lock.release()
            _ls_token_cache['access_token'] = None
            _ls_ref_cache.clear()
            for st in (_rep_state, _ls_ar_state):
                for k in ('result', 'comparison', 'preview'):
                    if k in st:
                        st[k] = None
            db_add_audit(username or '?', 'Restauration complète',
                         f"{source_label} (sauvegarde du {m.get('created_at', '?')}, version {m.get('version', '?')}) ; "
                         f"état précédent sauvegardé : {pre['name']}")
            return {'restored_from': m.get('created_at'), 'version': m.get('version'), 'pre_backup': pre['name']}
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)
    except Exception as e:
        if not isinstance(e, RuntimeError):
            traceback.print_exc()
        _fb_state['error'] = str(e)
        raise
    finally:
        for lk in held:
            lk.release()
        _fb_state.update(running=False, progress='')
        _fb_lock.release()


def _full_backup_loop():
    while True:
        time.sleep(LS_AUTO_CHECK_SECONDS)
        try:
            cfg = fb_cfg()
            now = datetime.datetime.now()
            if not cfg['enabled'] or now.hour < cfg['hour'] or meta_get('fb_auto_date') == now.date().isoformat():
                continue
            meta_set('fb_auto_date', now.date().isoformat())
            try:
                res = full_backup('auto', 'Sauvegarde automatique')
            except Exception as e:
                fb_notify(False, error=str(e))
            else:
                fb_notify(True, info=res)
        except Exception as e:
            print("Sauvegarde automatique :", e)


# ============================================================
# Rapport des taxes (1.17.0)
# ------------------------------------------------------------
# À partir des ventes gardées localement (avec les montants de taxes calculés
# par Lightspeed pour chaque ligne). Ventilation par taxe et par taux (ex.
# TPS 5 %, TVQ 9,975 %, TVH…) : ventes taxables et taxe perçue ; ventes non
# taxables ; détail par catégorie de taxes Lightspeed. Les retours (montants
# négatifs) réduisent les ventes et la taxe perçue.
# ============================================================
TAX_EPS = 0.00005
TAX_DEFAULT_NAMES = {1: 'TPS', 2: 'TVQ'}   # quand le nom est vide dans Lightspeed


def _canon_tax_name(idx, pct):
    """Nom officiel d'une taxe canadienne selon sa position et son taux, pour la
    ventilation (les noms configurés dans Lightspeed peuvent être ambigus)."""
    if idx == 1:
        return 'TPS' if abs(pct - 5) < 0.001 else ('TVH' if pct > 5 else 'Taxe 1')
    return 'TVQ' if abs(pct - 9.975) < 0.001 else 'TVP'


def _ls_taxcat_classes(t):
    """Taux propres à chaque classe d'article dans une catégorie de taxes
    (ex. au Québec, un article « Shopify 13 » taxé à 13 %). Liste de
    (taxClassID, taux1, taux2)."""
    rel = t.get('TaxCategoryClasses') or {}
    out = []
    for c in _ls_as_list(rel.get('TaxCategoryClass') if isinstance(rel, dict) else rel):
        cid = str(c.get('taxClassID') or '').strip()
        if cid:
            out.append((cid, _parse_money(c.get('tax1Rate')), _parse_money(c.get('tax2Rate'))))
    return out


FEE_DIAG_PATH = BASE_DIR / "diagnostic_frais_lightspeed.json"
HT_JOB_RE = re.compile(r'HT\s*:\s*#?\s*0*(\d{1,9})', re.I)
SERVICE_MIN_RE = re.compile(r'\bService\s+(\d{1,4})\s*min', re.I)


def _ls_line_text(ln):
    """Texte affiché d'une ligne de vente : description de l'article + note de la ligne."""
    parts = []
    item = ln.get('Item') if isinstance(ln.get('Item'), dict) else {}
    for v in (item.get('description'), ln.get('description'), ln.get('note')):
        if isinstance(v, str) and v.strip():
            parts.append(v.strip())
    note = ln.get('Note')
    if isinstance(note, dict) and isinstance(note.get('note'), str) and note['note'].strip():
        parts.append(note['note'].strip())
    return ' '.join(parts)


def _ls_workshop_info(ln, qty):
    """(texte, numéro de bon HubTiger, minutes de service facturées) d'une ligne."""
    text = _ls_line_text(ln)
    m = HT_JOB_RE.search(text)
    job = m.group(1) if m else None
    item = ln.get('Item') if isinstance(ln.get('Item'), dict) else {}
    sm = SERVICE_MIN_RE.search(str(item.get('description') or '')) or SERVICE_MIN_RE.search(text)
    minutes = float(sm.group(1)) * qty if sm else None
    return text, job, minutes


def _ls_fee_info(ln):
    """Frais d'article (consigne, écofrais…) ajouté automatiquement par
    Lightspeed ? Retourne (est_un_frais, nom). La forme exacte dans l'API n'est
    pas documentée : on accepte tous les indices raisonnables."""
    fee_obj = None
    is_fee = False
    for k, v in ln.items():
        kl = k.lower()
        if 'fee' not in kl:
            continue
        if isinstance(v, dict) and v:
            is_fee, fee_obj = True, v
        elif isinstance(v, list) and v:
            is_fee, fee_obj = True, (v[0] if isinstance(v[0], dict) else None)
        elif isinstance(v, str) and v.strip() and v.strip().lower() not in ('0', 'false', 'no', 'non'):
            is_fee = True
        elif isinstance(v, (int, float)) and not isinstance(v, bool) and v:
            is_fee = True
        elif v is True:
            is_fee = True
    for k in ('lineType', 'type', 'saleLineType'):
        if str(ln.get(k) or '').strip().lower() in ('fee', 'itemfee', 'item_fee', 'frais'):
            is_fee = True
    if not is_fee:
        return False, None
    name = None
    if isinstance(fee_obj, dict):
        name = fee_obj.get('name') or fee_obj.get('feeName') or fee_obj.get('description')
    note = ln.get('Note') if isinstance(ln.get('Note'), dict) else {}
    name = name or ln.get('description') or ln.get('feeName') or note.get('note') or (ln.get('Item') or {}).get('description')
    return True, (str(name).strip() if name else "Frais")


CARD_BRANDS = (('visa', 'Visa'), ('master', 'Mastercard'), ('mc', 'Mastercard'), ('amex', 'American Express'),
               ('american express', 'American Express'), ('discover', 'Discover'), ('jcb', 'JCB'), ('diners', 'Diners Club'),
               ('unionpay', 'UnionPay'), ('interac', 'Interac (débit)'))
PAY_TYPE_FR = {'cash': 'Comptant', 'check': 'Chèque', 'cheque': 'Chèque', 'debit card': 'Interac (débit)', 'debit': 'Interac (débit)',
               'credit account': 'Compte à recevoir', 'gift card': 'Carte-cadeau', 'gift': 'Carte-cadeau',
               'credit card': 'Carte de crédit (marque inconnue)', 'ecom': 'Paiement en ligne', 'layaway': 'Mise de côté'}


def _ls_card_brand(p_):
    """Marque de la carte d'un paiement : champs du détail de transaction (CCCharge),
    sinon premier chiffre d'un numéro masqué (4 = Visa, 5/2 = Mastercard, 3 = Amex)."""
    cc = p_.get('CCCharge') if isinstance(p_.get('CCCharge'), dict) else {}
    texts = []
    for src in (cc, p_):
        for k in ('cardType', 'cardBrand', 'brand', 'ccType', 'cardName', 'type', 'cardTypeName', 'paymentMethod'):
            v = src.get(k)
            if isinstance(v, str) and v.strip():
                texts.append(v.strip().lower())
    for t in texts:
        for key, label in CARD_BRANDS:
            if t == key or key in t.replace('-', ' ') and (len(key) > 2 or t.startswith(key)):
                return label
    for k in ('xnum', 'cardNumber', 'maskedNumber', 'ccNumber'):
        v = str(cc.get(k) or p_.get(k) or '').strip()
        if v[:1].isdigit():
            return {'4': 'Visa', '5': 'Mastercard', '2': 'Mastercard', '3': 'American Express', '6': 'Discover'}.get(v[0])
    return None


def _ls_payment_mode(p_):
    """Mode de paiement réel (en français) d'un paiement de vente Lightspeed."""
    pt = p_.get('PaymentType') if isinstance(p_.get('PaymentType'), dict) else {}
    name, ptype = (pt.get('name') or '').strip(), (pt.get('type') or '').strip().lower()
    if _ls_is_account_payment(p_):
        return 'Compte à recevoir'
    low = name.lower()
    for key, label in CARD_BRANDS:                       # mode déjà nommé « Visa », « MasterCard »…
        if key in low and len(key) > 2:
            return label
    if ptype == 'credit card' or low in ('credit card', 'carte de crédit', 'carte de credit', 'credit'):
        return _ls_card_brand(p_) or 'Carte de crédit (marque inconnue)'
    if low in PAY_TYPE_FR:
        return PAY_TYPE_FR[low]
    if name:
        return name
    return PAY_TYPE_FR.get(ptype, '(Autre)')


def _ls_sale_tax_total(s, idx):
    """Taxe totale d'une vente telle qu'arrondie par Lightspeed (None si absente)."""
    for k in (f'calcTax{idx}', f'tax{idx}', f'taxTotal{idx}'):
        v = s.get(k)
        if v not in (None, ''):
            try:
                return float(v)
            except (TypeError, ValueError):
                pass
    return None


def _ls_reconcile(values, weights, target):
    """Ajuste des montants de lignes pour que leur somme égale le total de la
    vente (arrondi par Lightspeed). Petite différence d'arrondi : sur la plus
    grosse ligne ; sinon répartie au prorata."""
    diff = round(target - sum(values), 4)
    if abs(diff) < 0.00005 or not values:
        return values
    base = [abs(v) for v in values] if any(abs(v) > 0.00005 for v in values) else [abs(w) for w in weights]
    if not any(base):
        return values
    out = list(values)
    if abs(diff) < 0.5:
        k = max(range(len(base)), key=lambda i: base[i])
        out[k] = round(out[k] + diff, 4)
        return out
    tot = sum(base)
    for i, b in enumerate(base):
        out[i] = round(out[i] + diff * b / tot, 4)
    return out


def _ls_taxcat_row(t):
    """Catégorie de taxes Lightspeed -> (id, nom, taxe1, taxe2, taux1, taux2). Le nom
    peut être dans différents champs selon le compte ; sinon on le construit à
    partir des taxes (jamais un simple numéro)."""
    tid = str(t.get('taxCategoryID') or '').strip()
    n1, n2 = (t.get('tax1Name') or '').strip(), (t.get('tax2Name') or '').strip()
    r1, r2 = _parse_money(t.get('tax1Rate')), _parse_money(t.get('tax2Rate'))
    name = ''
    for k in ('taxCategoryName', 'taxName', 'name', 'description', 'title'):
        v = t.get(k)
        if isinstance(v, str) and v.strip():
            name = v.strip()
            break
    if not name:
        parts = [f"{n or TAX_DEFAULT_NAMES[i]} {f'{_tax_pct(r):g}'.replace('.', ',')} %"
                 for i, (n, r) in enumerate(((n1, r1), (n2, r2)), start=1) if abs(r) > TAX_EPS]
        name = " + ".join(parts) if parts else "Aucune taxe"
    return tid, name, n1, n2, r1, r2


def _tax_pct(r):
    """Taux en pourcentage (Lightspeed : 0.05 ou 5 selon les champs)."""
    r = float(r or 0)
    return round(r * 100, 4) if abs(r) <= 1 else round(r, 4)


def local_tax_report(d0, d1, shop_id='', username=None):
    conn = get_conn()
    try:
        cats = {r['tax_category_id']: dict(r) for r in conn.execute("SELECT * FROM ls_tax_categories").fetchall()}
        q = ("SELECT COALESCE(tax_cat,'') tc, ROUND(COALESCE(tax1_rate,0),6) r1, ROUND(COALESCE(tax2_rate,0),6) r2, "
             "SUM(total) t, SUM(tax1) x1, SUM(tax2) x2, "
             f"SUM(CASE WHEN ABS(tax1)>{TAX_EPS} THEN total ELSE 0 END) b1, "
             f"SUM(CASE WHEN ABS(tax2)>{TAX_EPS} THEN total ELSE 0 END) b2, "
             f"SUM(CASE WHEN ABS(tax1)<={TAX_EPS} AND ABS(tax2)<={TAX_EPS} THEN total ELSE 0 END) nt "
             "FROM sales_lines WHERE sale_date BETWEEN ? AND ?")
        args = [d0.isoformat(), d1.isoformat()]
        if shop_id:
            q += " AND shop_id=?"
            args.append(str(shop_id))
        groups = [dict(r) for r in conn.execute(q + " GROUP BY tc, r1, r2", args).fetchall()]
        class_names = {r['tax_class_id']: r['name'] for r in conn.execute("SELECT * FROM ls_tax_classes").fetchall()}
        qc = ("SELECT COALESCE(tax_class,'') tcl, SUM(subtotal) st, SUM(discount) d, SUM(total) t, SUM(tax1) x1, SUM(tax2) x2, "
              f"SUM(CASE WHEN ABS(tax1)>{TAX_EPS} OR ABS(tax2)>{TAX_EPS} THEN total ELSE 0 END) taxe, "
              f"SUM(CASE WHEN ABS(tax1)<={TAX_EPS} AND ABS(tax2)<={TAX_EPS} THEN total ELSE 0 END) nt "
              "FROM sales_lines WHERE sale_date BETWEEN ? AND ?" + (" AND shop_id=?" if shop_id else "") + " GROUP BY tcl")
        class_groups = [dict(r) for r in conn.execute(qc, args).fetchall()]
        n_sales = conn.execute("SELECT COUNT(DISTINCT sale_id) n FROM sales_lines WHERE sale_date BETWEEN ? AND ?"
                               + (" AND shop_id=?" if shop_id else ""), args).fetchone()['n']
    finally:
        conn.close()
    by_rate, by_cat = {}, {}
    for g in groups:
        c = cats.get(g['tc']) or {}
        for idx in (1, 2):
            amount, base = g[f'x{idx}'] or 0.0, g[f'b{idx}'] or 0.0
            if abs(amount) <= TAX_EPS and abs(base) <= TAX_EPS:
                continue
            rate = _tax_pct(g[f'r{idx}'] or c.get(f'tax{idx}_rate') or 0)
            name = _canon_tax_name(idx, rate)
            row = by_rate.setdefault((name, rate), {'taxe': name, 'taux': rate, 'ventes_taxables': 0.0, 'taxe_percue': 0.0})
            row['ventes_taxables'] += base
            row['taxe_percue'] += amount
        key = g['tc']
        cname = c.get('name') if c.get('name') and not re.fullmatch(r'Catégorie \d+', c.get('name')) else ''
        if not cname:
            if not key:
                cname = '(Aucune catégorie de taxes)'
            else:
                parts = []
                for i in (1, 2):
                    rate_i = g['r%d' % i] or c.get('tax%d_rate' % i) or 0
                    if abs(g['x%d' % i] or 0) > TAX_EPS or abs(rate_i) > TAX_EPS:
                        nm = (c.get('tax%d_name' % i) or '').strip() or TAX_DEFAULT_NAMES[i]
                        parts.append(nm + ' ' + ('%g' % _tax_pct(rate_i)).replace('.', ',') + ' %')
                cname = " + ".join(parts) if parts else "Aucune taxe"
        cr = by_cat.setdefault(key, {'categorie': cname,
                                     'ventes': 0.0, 'non_taxables': 0.0, 'taxes': {}, 'total_taxes': 0.0})
        cr['ventes'] += g['t'] or 0.0
        cr['non_taxables'] += g['nt'] or 0.0
        for idx in (1, 2):
            amount = g[f'x{idx}'] or 0.0
            if abs(amount) > TAX_EPS:
                pct_txt = f"{_tax_pct(g[f'r{idx}'] or c.get(f'tax{idx}_rate') or 0):g}".replace('.', ',')
                lbl = f"{_canon_tax_name(idx, _tax_pct(g[f'r{idx}'] or c.get(f'tax{idx}_rate') or 0))} {pct_txt} %"
                cr['taxes'][lbl] = cr['taxes'].get(lbl, 0.0) + amount
                cr['total_taxes'] += amount
    order = {'TPS': 0, 'GST': 0, 'TVQ': 1, 'QST': 1, 'TVH': 2, 'HST': 2, 'TVP': 3, 'PST': 3}
    rates = sorted(by_rate.values(), key=lambda r: (order.get(r['taxe'].upper(), 9), r['taxe'], r['taux']))
    for r in rates:
        r['ventes_taxables'] = round(r['ventes_taxables'], 2)
        r['taxe_percue'] = round(r['taxe_percue'], 2)
        r['taxe_theorique'] = round(r['ventes_taxables'] * r['taux'] / 100, 2)
    cat_rows = sorted((r for r in by_cat.values() if abs(r['ventes']) >= 0.005 or abs(r['total_taxes']) >= 0.005),
                      key=lambda r: -r['ventes'])
    classes = []
    for g in sorted(class_groups, key=lambda g: -(g['st'] or 0)):
        row = {'classe': class_names.get(g['tcl']) or ('Sans classe' if not g['tcl'] else f"Classe {g['tcl']}"),
               'sous_total': round(g['st'] or 0, 2), 'reductions': round(g['d'] or 0, 2),
               'ventes': round(g['t'] or 0, 2), 'taxe': round(g['taxe'] or 0, 2), 'non_taxe': round(g['nt'] or 0, 2),
               'tps': round(g['x1'] or 0, 2), 'tvq': round(g['x2'] or 0, 2)}
        row['total_taxes'] = round(row['tps'] + row['tvq'], 2)
        row['total'] = round(row['ventes'] + row['total_taxes'], 2)
        if any(abs(row[k]) >= 0.005 for k in ('sous_total', 'ventes', 'total_taxes')):
            classes.append(row)
    for r in cat_rows:
        r['ventes'] = round(r['ventes'], 2)
        r['non_taxables'] = round(r['non_taxables'], 2)
        r['total_taxes'] = round(r['total_taxes'], 2)
        r['taxes'] = [{'taxe': k, 'montant': round(v, 2)} for k, v in sorted(r['taxes'].items())]
        r['total_ttc'] = round(r['ventes'] + r['total_taxes'], 2)
    ventes = round(sum(g['t'] or 0 for g in groups), 2)
    taxes = round(sum((g['x1'] or 0) + (g['x2'] or 0) for g in groups), 2)
    conn = get_conn()
    fetched = conn.execute("SELECT MIN(fetched_at) a, MAX(fetched_at) b FROM sales_days WHERE day BETWEEN ? AND ?",
                           (d0.isoformat(), d1.isoformat())).fetchone()
    fq = ("SELECT COALESCE(NULLIF(TRIM(fee_name),''),'Frais') nom, SUM(qty) q, SUM(subtotal) st, SUM(total) t, "
          "SUM(tax1) x1, SUM(tax2) x2, COUNT(*) n FROM sales_lines WHERE is_fee=1 AND sale_date BETWEEN ? AND ?"
          + (" AND shop_id=?" if shop_id else "") + " GROUP BY nom ORDER BY t DESC")
    fee_rows = [dict(r) for r in conn.execute(fq, [d0.isoformat(), d1.isoformat()] + ([str(shop_id)] if shop_id else [])).fetchall()]
    conn.close()
    fees = []
    for f in fee_rows:
        tx = round((f['x1'] or 0) + (f['x2'] or 0), 2)
        fees.append({'nom': f['nom'], 'quantite': round(f['q'] or 0, 2), 'lignes': f['n'], 'montant': round(f['t'] or 0, 2),
                     'taxes': tx, 'total': round((f['t'] or 0) + tx, 2)})
    fee_totals = {'montant': round(sum(f['montant'] for f in fees), 2), 'taxes': round(sum(f['taxes'] for f in fees), 2),
                  'lignes': sum(f['lignes'] for f in fees)}
    fee_totals['total'] = round(fee_totals['montant'] + fee_totals['taxes'], 2)
    return {'report': 'taxes', 'title': "Rapport des taxes",
            'fetched_oldest': fetched['a'], 'fetched_newest': fetched['b'],
            'start': d0.isoformat(), 'end': d1.isoformat(), 'shop_id': shop_id or '', 'shop_name': _shop_name(shop_id),
            'rates': rates, 'categories': cat_rows, 'classes': classes, 'fees': fees, 'fee_totals': fee_totals,
            'totals': {'ventes': ventes, 'non_taxables': round(sum(g['nt'] or 0 for g in groups), 2),
                       'taxes': taxes, 'ttc': round(ventes + taxes, 2), 'sales_count': n_sales,
                       'sous_total': round(sum(g['st'] or 0 for g in class_groups), 2),
                       'reductions': round(sum(g['d'] or 0 for g in class_groups), 2),
                       'taxables': round(sum(g['taxe'] or 0 for g in class_groups), 2),
                       'tps': round(sum(g['x1'] or 0 for g in groups), 2),
                       'tvq': round(sum(g['x2'] or 0 for g in groups), 2)},
            'generated_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'by': username}


def export_tax_pdf(r):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader
    out = PDF_DIR / "Rapports_personnalises"
    out.mkdir(exist_ok=True)
    path = out / f"Rapport_taxes_{r['start']}_au_{r['end']}.pdf"
    page_w, page_h = letter
    styles = getSampleStyleSheet()
    h2 = ParagraphStyle('h2', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=11, spaceBefore=4, spaceAfter=4)
    cell = ParagraphStyle('c', parent=styles['Normal'], fontSize=8.5, leading=10)
    T = r['totals']

    def money(v):
        return f"{v:,.2f} $".replace(',', ' ').replace('.', ',')

    def pct(v):
        return f"{v:g} %".replace('.', ',')

    period = f"Du {_d(r['start'])} au {_d(r['end'])}" + (f" — {r['shop_name']}" if r['shop_name'] else '')

    def header(canvas, doc_):
        canvas.saveState()
        top = page_h - 16 * mm
        canvas.setFont('Helvetica-Bold', 16)
        canvas.drawString(16 * mm, top, f"Rapport des taxes — {get_company_name()}")
        canvas.setFont('Helvetica', 9.5)
        canvas.drawString(16 * mm, top - 7 * mm, period)
        g = r['generated_at']
        canvas.drawString(16 * mm, top - 12 * mm, f"{T['sales_count']} vente(s) — généré le {g[8:10]}-{g[5:7]}-{g[:4]} à {g[11:16]}")
        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            lw = 38 * mm
            canvas.drawImage(img, page_w - 16 * mm - lw, top - lw * ih / iw + 4 * mm, width=lw, height=lw * ih / iw, mask='auto')
        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.line(16 * mm, top - 16 * mm, page_w - 16 * mm, top - 16 * mm)
        canvas.setFont('Helvetica', 8)
        canvas.drawString(16 * mm, 9 * mm, "Montants calculés à partir des ventes Lightspeed ; les retours réduisent les ventes et la taxe perçue.")
        canvas.drawRightString(page_w - 16 * mm, 9 * mm, f"Page {doc_.page}")
        canvas.restoreState()

    base_style = [('FONTSIZE', (0, 0), (-1, -1), 9), ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
                  ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('LINEBELOW', (0, 0), (-1, -1), 0.25, colors.HexColor('#d1d5db')),
                  ('TOPPADDING', (0, 0), (-1, -1), 4), ('BOTTOMPADDING', (0, 0), (-1, -1), 4)]
    head_style = [('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'), ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                  ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e3a8a'))]
    story = []
    summ = [["Sous-total", money(T.get('sous_total', 0)), "Taxé", money(T.get('taxables', 0))],
            ["Réductions", money(T.get('reductions', 0)), "Non taxé", money(T['non_taxables'])],
            ["Sous-total avec réductions", money(T['ventes']), "", ""],
            ["TPS (1re taxe, incluant la TVH)", money(T.get('tps', 0)), "", ""],
            ["TVQ (2e taxe)", money(T.get('tvq', 0)), "", ""],
            ["Total des taxes", money(T['taxes']), "", ""],
            ["Total avec taxes", money(T['ttc']), "", ""]]
    st = Table(summ, colWidths=[62 * mm, 32 * mm, 22 * mm, 32 * mm])
    st.setStyle(TableStyle(base_style + [('FONTNAME', (0, 5), (1, 6), 'Helvetica-Bold'), ('FONTNAME', (2, 0), (2, 1), 'Helvetica-Bold'),
                                         ('BACKGROUND', (0, 5), (1, 5), colors.HexColor('#eff6ff'))]))
    story += [Paragraph("Sommaire", h2), st, Spacer(1, 6 * mm)]
    if r.get('classes'):
        small = ParagraphStyle('s', parent=cell, fontSize=7.5, leading=9)
        data = [["Classe de taxe", "Sous-total", "Réductions", "Avec réd.", "Taxé", "Non taxé", "TPS", "TVQ", "Taxes", "Total"]]
        for c in r['classes']:
            data.append([Paragraph(c['classe'].replace('&', '&amp;').replace('<', '&lt;'), small), money(c['sous_total']),
                         money(c['reductions']), money(c['ventes']), money(c['taxe']), money(c['non_taxe']), money(c['tps']),
                         money(c['tvq']), money(c['total_taxes']), money(c['total'])])
        data.append(["TOTAL", money(T.get('sous_total', 0)), money(T.get('reductions', 0)), money(T['ventes']),
                     money(T.get('taxables', 0)), money(T['non_taxables']), money(T.get('tps', 0)), money(T.get('tvq', 0)),
                     money(T['taxes']), money(T['ttc'])])
        t = Table(data, colWidths=[24 * mm] + [17.4 * mm] * 9, repeatRows=1)
        t.setStyle(TableStyle(base_style + head_style + [('FONTSIZE', (0, 0), (-1, -1), 7),
                                                         ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
                                                         ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#e5e7eb'))]))
        story += [Paragraph("Par classe de taxe (comme le rapport « Taxe de vente » de Lightspeed)", h2), t, Spacer(1, 6 * mm)]
    story += [Paragraph("Ventilation par taux de taxe", h2)]
    data = [["Taxe", "Taux", "Ventes taxables", "Taxe perçue"]]
    for x in r['rates']:
        data.append([x['taxe'], pct(x['taux']), money(x['ventes_taxables']), money(x['taxe_percue'])])
    data.append(["Total des taxes", "", "", money(T['taxes'])])
    t = Table(data, colWidths=[55 * mm, 25 * mm, 45 * mm, 45 * mm], repeatRows=1)
    t.setStyle(TableStyle(base_style + head_style + [('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
                                                     ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#e5e7eb'))]))
    story += [t, Spacer(1, 6 * mm), Paragraph("Par catégorie de taxes (Lightspeed)", h2)]
    data = [["Catégorie", "Ventes avant taxes", "Non taxables", "Détail des taxes", "Total taxes"]]
    for c in r['categories']:
        det = "<br/>".join(f"{x['taxe']} : {money(x['montant'])}" for x in c['taxes']) or "—"
        data.append([Paragraph(c['categorie'].replace('&', '&amp;').replace('<', '&lt;'), cell), money(c['ventes']),
                     money(c['non_taxables']), Paragraph(det.replace('&', '&amp;'), cell), money(c['total_taxes'])])
    data.append(["TOTAL", money(T['ventes']), money(T['non_taxables']), "", money(T['taxes'])])
    t = Table(data, colWidths=[45 * mm, 32 * mm, 28 * mm, 48 * mm, 28 * mm], repeatRows=1)
    t.setStyle(TableStyle(base_style + head_style + [('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
                                                     ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#e5e7eb'))]))
    story.append(t)
    FT = r.get('fee_totals') or {}
    story += [Spacer(1, 8 * mm), Paragraph("Rapport des frais (Lignes de vente → Frais)", h2)]
    ft = Table([["Total des frais", money(FT.get('montant', 0))]], colWidths=[80 * mm, 40 * mm])
    ft.setStyle(TableStyle(base_style + [('FONTNAME', (0, 0), (-1, -1), 'Helvetica-Bold'), ('FONTSIZE', (0, 0), (-1, -1), 11),
                                         ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#fef9c3'))]))
    story.append(ft)
    if r.get('fees'):
        data = [["Frais", "Quantité", "Montant", "Taxes", "Total avec taxes"]]
        for f in r['fees']:
            data.append([Paragraph(f['nom'].replace('&', '&amp;').replace('<', '&lt;'), cell),
                         f"{f['quantite']:g}".replace('.', ','), money(f['montant']), money(f['taxes']), money(f['total'])])
        data.append(["TOTAL", "", money(FT['montant']), money(FT['taxes']), money(FT['total'])])
        t = Table(data, colWidths=[70 * mm, 22 * mm, 28 * mm, 25 * mm, 32 * mm], repeatRows=1)
        t.setStyle(TableStyle(base_style + head_style + [('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
                                                         ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#e5e7eb'))]))
        story += [Spacer(1, 3 * mm), t]
    else:
        story.append(Paragraph("Aucun frais d'article (consigne, écofrais…) n'a été trouvé pour cette période.", cell))
    doc = SimpleDocTemplate(str(path), pagesize=letter, leftMargin=16 * mm, rightMargin=16 * mm,
                            topMargin=36 * mm, bottomMargin=16 * mm)
    story.append(_pdf_disclaimer())
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


# ============================================================
# Valeur de l'inventaire (1.19.0)
# ------------------------------------------------------------
# Instantané lu dans Lightspeed : pour chaque article actif (non archivé, pas
# « non inventorié »), quantité en main × coût (coût moyen de Lightspeed, sinon
# coût par défaut) ; aussi la valeur au prix de détail. Les quantités négatives
# ne comptent pas dans la valeur (elles sont signalées à part). Les instantanés
# sont gardés dans Kubios (historique par mois) ; planification mensuelle avec
# envoi du PDF par courriel.
# ============================================================
_inv_lock = threading.Lock()
_inv_state = {'running': False, 'progress': '', 'error': None, 'last_id': None, 'last_send': None}
INV_METHODS = {'avg': 'coût moyen', 'default': 'coût par défaut'}


def inv_cfg():
    try:
        recips = json.loads(meta_get('inv_recipients') or '[]')
    except ValueError:
        recips = []
    try:
        hour = min(max(int(meta_get('inv_hour') or 6), 0), 23)
    except ValueError:
        hour = 6
    day = meta_get('inv_day') or '1'
    if day != 'last':
        try:
            day = str(min(max(int(day), 1), 28))
        except ValueError:
            day = '1'
    return {'auto': meta_get('inv_auto') == '1', 'day': day, 'hour': hour,
            'method': meta_get('inv_method') if meta_get('inv_method') in INV_METHODS else 'avg',
            'recipients': [r for r in recips if isinstance(r, str) and r.strip()]}


def _inv_item_cost(it, method):
    avg, dflt = _parse_money(it.get('avgCost')), _parse_money(it.get('defaultCost'))
    return (avg or dflt) if method == 'avg' else (dflt or avg)


def _inv_item_price(it):
    prices = it.get('Prices') or {}
    for p in _ls_as_list(prices.get('ItemPrice') if isinstance(prices, dict) else prices):
        if str(p.get('useType') or '').lower() in ('default', 'prix par défaut') or str(p.get('useTypeID') or '') == '1':
            return _parse_money(p.get('amount'))
    return 0.0


def _inv_item_qoh(it, shop_id):
    shops = _ls_as_list((it.get('ItemShops') or {}).get('ItemShop') if isinstance(it.get('ItemShops'), dict) else it.get('ItemShops'))
    rows = {str(s.get('shopID') or ''): _parse_money(s.get('qoh')) for s in shops}
    if shop_id:
        return rows.get(str(shop_id), 0.0)
    if '0' in rows:            # Lightspeed fournit souvent une ligne « tous les magasins » (shopID 0)
        return rows['0']
    return sum(v for k, v in rows.items() if k not in ('', '0'))


def take_inventory_snapshot(kind, username, shop_id=''):
    """Lit l'inventaire dans Lightspeed et enregistre l'instantané. Retourne son id."""
    st = _inv_state
    cfg = ls_config()
    account_id = cfg['account_id']
    if not account_id:
        account_id, name = ls_fetch_account()
        meta_set('ls_account_id', account_id)
        meta_set('ls_account_name', name)
    _store_refresh_refs(account_id, st)
    method = inv_cfg()['method']
    items = _ls_get_all(account_id, 'Item', {'archived': 'false', 'load_relations': json.dumps(['ItemShops'])},
                        'Articles', state=st)
    st['progress'] = "Calcul de la valeur…"
    conn = get_conn()
    cats = {r['category_id']: r['path'] for r in conn.execute("SELECT category_id, path FROM ls_categories").fetchall()}
    conn.close()
    agg, tot = {}, {'items': 0, 'units': 0.0, 'cost': 0.0, 'retail': 0.0, 'neg': 0}
    for it in items:
        if _truthy(it.get('archived')) or str(it.get('itemType') or '').lower() in ('non_inventory', 'noninventory'):
            continue
        qoh = _inv_item_qoh(it, shop_id)
        if qoh < 0:
            tot['neg'] += 1
            continue
        if qoh == 0:
            continue
        cost, price = _inv_item_cost(it, method), _inv_item_price(it)
        cat = cats.get(str(it.get('categoryID') or '').strip()) or REP_NO_CATEGORY
        a = agg.setdefault(cat, {'items': 0, 'units': 0.0, 'cost': 0.0, 'retail': 0.0})
        a['items'] += 1
        a['units'] += qoh
        a['cost'] += qoh * cost
        a['retail'] += qoh * price
    for a in agg.values():
        for k in ('items', 'units', 'cost', 'retail'):
            tot[k] += a[k]
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    conn = get_conn()
    try:
        cur = conn.execute("INSERT INTO inventory_snapshots(taken_at, kind, shop_id, shop_name, method, items, units, "
                           "cost_value, retail_value, negative_items, username) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                           (now, kind, shop_id or '', _shop_name(shop_id), method, tot['items'], round(tot['units'], 2),
                            round(tot['cost'], 2), round(tot['retail'], 2), tot['neg'], username or '?'))
        sid = cur.lastrowid
        conn.executemany("INSERT INTO inventory_snapshot_lines(snapshot_id, category, items, units, cost_value, retail_value) "
                         "VALUES (?,?,?,?,?,?)", [(sid, c, a['items'], round(a['units'], 2), round(a['cost'], 2),
                                                   round(a['retail'], 2)) for c, a in agg.items()])
        conn.commit()
    finally:
        conn.close()
    db_add_audit(username or '?', "Instantané de la valeur de l'inventaire",
                 f"{'automatique' if kind == 'auto' else 'manuel'} : {_fmt_money_fr(round(tot['cost'], 2))} au {INV_METHODS[method]}")
    return sid


def start_inventory_job(kind, username, shop_id='', then=None):
    if not _inv_lock.acquire(blocking=False):
        raise LightspeedError("Un instantané de l'inventaire est déjà en cours.")
    st = _inv_state
    st.update(running=True, progress="Connexion à Lightspeed…", error=None, last_send=None)

    def _run():
        try:
            st['last_id'] = take_inventory_snapshot(kind, username, shop_id)
            if then:
                st['progress'] = "Envoi par courriel…"
            if then:
                then(st['last_id'])
        except Exception as e:
            if not isinstance(e, LightspeedError):
                traceback.print_exc()
            st['error'] = str(e) if isinstance(e, LightspeedError) else f"Erreur inattendue : {e}"
            if kind == 'auto':
                meta_set('inv_last_error', f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M')} — {st['error']}")
        finally:
            st['running'] = False
            st['progress'] = ''
            _inv_lock.release()

    threading.Thread(target=_run, daemon=True).start()


def db_inventory_snapshot(sid):
    conn = get_conn()
    try:
        s = conn.execute("SELECT * FROM inventory_snapshots WHERE id=?", (sid,)).fetchone()
        if not s:
            return None
        s = dict(s)
        s['lines'] = [dict(r) for r in conn.execute("SELECT * FROM inventory_snapshot_lines WHERE snapshot_id=? "
                                                     "ORDER BY cost_value DESC", (sid,)).fetchall()]
        prev = conn.execute("SELECT cost_value, taken_at FROM inventory_snapshots WHERE id<? AND shop_id=? ORDER BY id DESC LIMIT 1",
                            (sid, s['shop_id'])).fetchone()
        s['previous'] = dict(prev) if prev else None
        return s
    finally:
        conn.close()


def db_inventory_history(limit=36):
    conn = get_conn()
    rows = [dict(r) for r in conn.execute("SELECT id, taken_at, kind, shop_name, method, items, units, cost_value, "
                                          "retail_value, negative_items, username FROM inventory_snapshots "
                                          "ORDER BY id DESC LIMIT ?", (limit,)).fetchall()]
    conn.close()
    return rows


def export_inventory_pdf(sid):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader
    s = db_inventory_snapshot(sid)
    hist = [h for h in db_inventory_history(13) if h['id'] <= sid][:13]
    out = PDF_DIR / "Rapports_personnalises"
    out.mkdir(exist_ok=True)
    path = out / f"Valeur_inventaire_{s['taken_at'][:10]}.pdf"
    page_w, page_h = letter
    styles = getSampleStyleSheet()
    h2 = ParagraphStyle('h2', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=11, spaceBefore=4, spaceAfter=4)
    cell = ParagraphStyle('c', parent=styles['Normal'], fontSize=8.5, leading=10)
    m = _fmt_money_fr
    t = s['taken_at']

    def header(canvas, doc_):
        canvas.saveState()
        top = page_h - 16 * mm
        canvas.setFont('Helvetica-Bold', 16)
        canvas.drawString(16 * mm, top, f"Valeur de l'inventaire — {get_company_name()}")
        canvas.setFont('Helvetica', 9.5)
        canvas.drawString(16 * mm, top - 7 * mm, f"Instantané du {t[8:10]}-{t[5:7]}-{t[:4]} à {t[11:16]}"
                          + (f" — {s['shop_name']}" if s['shop_name'] else " — tous les magasins")
                          + f" — valeur au {INV_METHODS.get(s['method'], s['method'])}")
        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            lw = 38 * mm
            canvas.drawImage(img, page_w - 16 * mm - lw, top - lw * ih / iw + 4 * mm, width=lw, height=lw * ih / iw, mask='auto')
        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.line(16 * mm, top - 12 * mm, page_w - 16 * mm, top - 12 * mm)
        canvas.setFont('Helvetica', 8)
        canvas.drawString(16 * mm, 9 * mm, "Quantités en main × coût, lues dans Lightspeed ; les quantités négatives ne sont pas comptées.")
        canvas.drawRightString(page_w - 16 * mm, 9 * mm, f"Page {doc_.page}")
        canvas.restoreState()

    base = [('FONTSIZE', (0, 0), (-1, -1), 9), ('ALIGN', (1, 0), (-1, -1), 'RIGHT'), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('LINEBELOW', (0, 0), (-1, -1), 0.25, colors.HexColor('#d1d5db')), ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4)]
    head = [('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'), ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e3a8a'))]
    var = ''
    if s['previous'] and s['previous']['cost_value']:
        dv = s['cost_value'] - s['previous']['cost_value']
        pct = f"{dv / s['previous']['cost_value'] * 100:+.1f} %".replace('.', ',')
        var = f"{'+' if dv >= 0 else '−'}{m(abs(dv))} ({pct})"
    summ = [["Valeur de l'inventaire (au coût)", m(s['cost_value'])], ["Valeur au prix de détail", m(s['retail_value'])],
            ["Articles en stock", f"{s['items']:,}".replace(',', ' ')], ["Unités en stock", f"{s['units']:,.0f}".replace(',', ' ')]]
    if var:
        summ.append(["Variation depuis l'instantané précédent", var])
    if s['negative_items']:
        summ.append(["Articles en quantité négative (non comptés)", str(s['negative_items'])])
    st_ = Table(summ, colWidths=[90 * mm, 50 * mm])
    st_.setStyle(TableStyle(base + [('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'), ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#eff6ff'))]))
    story = [Paragraph("Sommaire", h2), st_, Spacer(1, 6 * mm), Paragraph("Par catégorie", h2)]
    data = [["Catégorie", "Articles", "Unités", "Valeur au coût", "Valeur au détail", "% de la valeur"]]
    for l in s['lines']:
        data.append([Paragraph(l['category'].replace('&', '&amp;').replace('<', '&lt;'), cell), str(l['items']),
                     f"{l['units']:,.0f}".replace(',', ' '), m(l['cost_value']), m(l['retail_value']),
                     (f"{l['cost_value'] / s['cost_value'] * 100:.1f} %".replace('.', ',') if s['cost_value'] else '')])
    data.append(["TOTAL", str(s['items']), f"{s['units']:,.0f}".replace(',', ' '), m(s['cost_value']), m(s['retail_value']), "100 %"])
    tb = Table(data, colWidths=[62 * mm, 18 * mm, 20 * mm, 30 * mm, 30 * mm, 22 * mm], repeatRows=1)
    tb.setStyle(TableStyle(base + head + [('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'), ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#e5e7eb'))]))
    story.append(tb)
    if len(hist) > 1:
        story += [Spacer(1, 6 * mm), Paragraph("Historique", h2)]
        data = [["Date", "Valeur au coût", "Variation"]]
        older = list(reversed(hist))
        for i, h in enumerate(older):
            dv = '' if i == 0 else (('+' if h['cost_value'] - older[i - 1]['cost_value'] >= 0 else '−') + m(abs(h['cost_value'] - older[i - 1]['cost_value'])))
            data.append([f"{h['taken_at'][8:10]}-{h['taken_at'][5:7]}-{h['taken_at'][:4]}", m(h['cost_value']), dv])
        th = Table(data, colWidths=[40 * mm, 40 * mm, 40 * mm], repeatRows=1)
        th.setStyle(TableStyle(base + head))
        story.append(th)
    doc = SimpleDocTemplate(str(path), pagesize=letter, leftMargin=16 * mm, rightMargin=16 * mm, topMargin=32 * mm, bottomMargin=16 * mm)
    story.append(_pdf_disclaimer())
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


def send_inventory_email(sid, emails, username, auto=False):
    s = db_inventory_snapshot(sid)
    pdf = export_inventory_pdf(sid)
    t = s['taken_at']
    subject = f"Valeur de l'inventaire — {t[8:10]}-{t[5:7]}-{t[:4]}"
    body = (f"Bonjour,\n\nVoici la valeur de l'inventaire au {t[8:10]}-{t[5:7]}-{t[:4]} ({INV_METHODS.get(s['method'], '')}) :\n\n"
            f"Valeur au coût : {_fmt_money_fr(s['cost_value'])}\nValeur au prix de détail : {_fmt_money_fr(s['retail_value'])}\n"
            f"Articles en stock : {s['items']}\n"
            + (f"Variation depuis le {s['previous']['taken_at'][8:10]}-{s['previous']['taken_at'][5:7]}-{s['previous']['taken_at'][:4]} : "
               f"{'+' if s['cost_value'] >= s['previous']['cost_value'] else '−'}{_fmt_money_fr(abs(s['cost_value'] - s['previous']['cost_value']))}\n"
               if s['previous'] else '')
            + f"\nLe détail par catégorie est dans le PDF joint.\n\n{get_company_name()}"
            + f"\n\n— {REPORT_DISCLAIMER_TITLE} : {REPORT_DISCLAIMER}")
    sent, errors = [], []
    com = False
    if get_settings()['send_mode'] != 'smtp':
        try:
            import pythoncom
            pythoncom.CoInitialize()
            com = True
        except Exception:
            pass
    try:
        for e in emails:
            try:
                send_email(e, subject, body, str(pdf), mode='send', bcc_company=False)
                sent.append(e)
            except Exception as ex:
                errors.append(f"{e} : {ex}")
    finally:
        if com:
            try:
                import pythoncom
                pythoncom.CoUninitialize()
            except Exception:
                pass
    conn = get_conn()
    conn.execute("INSERT INTO report_sends(sent_at, kind, period, recipients, status, error, username) VALUES (?,?,?,?,?,?,?)",
                 (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), ('auto ' if auto else '') + 'inventaire', t[:10],
                  ", ".join(sent), 'ok' if not errors else ('partiel' if sent else 'echec'), "; ".join(errors) or None, username or '?'))
    conn.commit()
    conn.close()
    db_add_audit(username or '?', "Valeur de l'inventaire envoyée par courriel" + (' (automatique)' if auto else ''),
                 f"{subject} → {', '.join(sent) or 'aucun'}" + (f" ; erreurs : {'; '.join(errors)}" if errors else ""))
    return sent, errors


def _inventory_loop():
    """Instantané mensuel planifié (jour du mois ou dernier jour, à l'heure choisie),
    envoyé ensuite aux destinataires. Une seule fois par mois."""
    while True:
        time.sleep(LS_AUTO_CHECK_SECONDS)
        try:
            cfg = inv_cfg()
            if not cfg['auto'] or not ls_config()['connected'] or _inv_state['running']:
                continue
            now = datetime.datetime.now()
            due_day = _is_last_day_of_month(now.date()) if cfg['day'] == 'last' else now.day >= int(cfg['day'])
            month = now.strftime('%Y-%m')
            if not due_day or now.hour < cfg['hour'] or meta_get('inv_last_month') == month:
                continue
            meta_set('inv_last_month', month)
            recips = cfg['recipients']

            def then(sid):
                meta_delete('inv_last_error')
                if recips:
                    send_inventory_email(sid, recips, 'Envoi automatique', auto=True)
            start_inventory_job('auto', 'Instantané automatique', '', then=then)
        except Exception as e:
            print("Instantané de l'inventaire :", e)


# ============================================================
# Tableau de bord 3D (1.20.0)
# ------------------------------------------------------------
# Maquette isométrique (three.js) : magasin = ventes de la période, bâtiment
# mauve = taxes, palettes = dernier instantané d'inventaire, tour verte =
# comptes de crédit, maisons = 10 plus gros soldes à recevoir. Chaque partie
# n'est envoyée que si l'utilisateur a l'accès correspondant.
# ============================================================
# three.js en local (1.20.1) : téléchargé une seule fois depuis le CDN (version
# fixée), vérifié, puis servi par Kubios depuis static/vendor/ — la page n'a plus
# besoin d'Internet. Les mises à jour de Kubios ne touchent pas à ce dossier.
THREE_VERSION = '0.147.0'
THREE_VENDOR_DIR = APP_DIR / 'static' / 'vendor'
THREE_FILES = (
    (f'three-{THREE_VERSION}.min.js', f'https://cdn.jsdelivr.net/npm/three@{THREE_VERSION}/build/three.min.js',
     ('WebGLRenderer', 'REVISION')),
    (f'OrbitControls-{THREE_VERSION}.js', f'https://cdn.jsdelivr.net/npm/three@{THREE_VERSION}/examples/js/controls/OrbitControls.js',
     ('THREE.OrbitControls',)),
)
_three_lock = threading.Lock()
_three_state = {'running': False, 'error': None, 'at': None}


def three_local_ready():
    for name, _url, marks in THREE_FILES:
        p = THREE_VENDOR_DIR / name
        if not p.exists() or p.stat().st_size < 1000:
            return False
    return True


def download_three_vendor():
    """Télécharge et vérifie les deux fichiers ; retourne (ok, message)."""
    if not _three_lock.acquire(blocking=False):
        return False, "Un téléchargement est déjà en cours."
    _three_state.update(running=True, error=None)
    try:
        THREE_VENDOR_DIR.mkdir(parents=True, exist_ok=True)
        for name, url, marks in THREE_FILES:
            req = urllib.request.Request(url, headers={'User-Agent': f'Kubios/{APP_VERSION}'})
            with urllib.request.urlopen(req, timeout=60) as r:
                data = r.read()
            text = data[:200000].decode('utf-8', errors='ignore') + data[-200000:].decode('utf-8', errors='ignore')
            if len(data) < 1000 or not all(m in text for m in marks):
                raise RuntimeError(f"Le fichier reçu pour {name} ne semble pas être three.js {THREE_VERSION}.")
            tmp = THREE_VENDOR_DIR / (name + '.tmp')
            tmp.write_bytes(data)
            os.replace(tmp, THREE_VENDOR_DIR / name)
        _three_state['at'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
        db_add_audit('Kubios', 'three.js installé localement', f"version {THREE_VERSION}")
        return True, f"three.js {THREE_VERSION} est installé dans Kubios."
    except urllib.error.URLError as e:
        msg = ("Kubios n'a pas accès à Internet pour le moment ; il réessaiera au prochain démarrage ou à la prochaine "
               f"ouverture du tableau de bord 3D. ({getattr(e, 'reason', e)})")
        _three_state['error'] = msg
        return False, msg
    except Exception as e:
        msg = f"Téléchargement impossible : {e}"
        _three_state['error'] = msg
        return False, msg
    finally:
        _three_state['running'] = False
        _three_lock.release()


def ensure_three_vendor_async():
    if not three_local_ready() and not _three_state['running']:
        threading.Thread(target=download_three_vendor, daemon=True).start()


def _d3_allowed(perm):
    return bool(session.get('is_admin')) or perm in (session.get('permissions') or [])


def dashboard3d_data(periode):
    today = datetime.date.today()
    if periode == 'mois':
        d0, d1, plabel = today.replace(day=1), today, f"{_MOIS_FR[today.month - 1]} {today.year} (jusqu'à aujourd'hui)"
    else:
        last = today.replace(day=1) - datetime.timedelta(days=1)
        d0, d1, plabel = last.replace(day=1), last, f"{_MOIS_FR[last.month - 1]} {last.year}"
    out = {'asOf': today.isoformat(), 'period': {'code': 'mois' if periode == 'mois' else 'mois_dernier', 'label': plabel,
                                                  'start': d0.isoformat(), 'end': d1.isoformat()}}
    conn = get_conn()
    try:
        # --- comptes à recevoir (permission « Comptes à recevoir »)
        inv = [] if not ar_allowed() else [dict(r) for r in conn.execute(
            "SELECT client_name, echeance, COALESCE(montant,0) m, COALESCE(montant_paye,0) p FROM invoices "
            "WHERE COALESCE(montant,0)-COALESCE(montant_paye,0) > 0.005").fetchall()]
        per = {}
        for r in inv:
            c = per.setdefault(r['client_name'], {'client': r['client_name'], 'solde': 0.0, 'en_retard': 0.0, 'factures': 0, 'plus_vieux_retard': 0})
            due = r['m'] - r['p']
            c['solde'] += due
            c['factures'] += 1
            try:
                late = (today - datetime.date.fromisoformat((r['echeance'] or '')[:10])).days
            except ValueError:
                late = 0
            if late > 0:
                c['en_retard'] += due
                c['plus_vieux_retard'] = max(c['plus_vieux_retard'], late)
        top = sorted(per.values(), key=lambda c: -c['solde'])[:10]
        for c in top:
            c['solde'], c['en_retard'] = round(c['solde'], 2), round(c['en_retard'], 2)
        out['ar'] = None if not ar_allowed() else {'total': round(sum(c['solde'] for c in per.values()), 2),
                     'overdue': round(sum(c['en_retard'] for c in per.values()), 2), 'clients': len(per), 'invoices': len(inv)}
        out['clients'] = top
        # --- comptes de crédit
        if _d3_allowed('credit_accounts'):
            r = conn.execute("SELECT COUNT(*) n, COALESCE(SUM(solde),0) s, COALESCE(SUM(deposit),0) d, "
                             "SUM(CASE WHEN solde>0 THEN 1 ELSE 0 END) nd FROM credit_clients").fetchone()
            out['credit'] = {'du': round(r['s'], 2), 'depots': round(r['d'], 2), 'comptes': r['n'], 'comptes_solde': r['nd'] or 0}
        else:
            out['credit'] = None
        # --- ventes de la période (ventes gardées chaque nuit)
        missing = len(store_missing_days(d0, d1))
        if _d3_allowed('custom_reports') or _d3_allowed('tax_reports'):
            r = conn.execute("SELECT COALESCE(SUM(subtotal),0) st, COALESCE(SUM(discount),0) d, COALESCE(SUM(total),0) t, "
                             "COALESCE(SUM(tax1),0) x1, COALESCE(SUM(tax2),0) x2, COUNT(DISTINCT sale_id) n "
                             "FROM sales_lines WHERE sale_date BETWEEN ? AND ?", (d0.isoformat(), d1.isoformat())).fetchone()
            out['store'] = {'ventes': round(r['t'], 2), 'sous_total': round(r['st'], 2), 'reductions': round(r['d'], 2),
                            'taxes': round(r['x1'] + r['x2'], 2), 'ttc': round(r['t'] + r['x1'] + r['x2'], 2),
                            'nb_ventes': r['n'], 'jours_manquants': missing}
        else:
            out['store'] = None
    finally:
        conn.close()
    # --- taxes de la période (même calcul que le Rapport des taxes)
    if _d3_allowed('tax_reports'):
        try:
            rep = local_tax_report(d0, d1)
            t = {'tps': 0.0, 'tvq': 0.0, 'tvh': 0.0, 'autres': 0.0}
            for x in rep['rates']:
                key = {'TPS': 'tps', 'TVQ': 'tvq', 'TVH': 'tvh'}.get(x['taxe'], 'autres')
                t[key] += x['taxe_percue']
            out['taxes'] = {k: round(v, 2) for k, v in t.items()}
            out['taxes']['total'] = rep['totals']['taxes']
            out['taxes']['jours_manquants'] = len(store_missing_days(d0, d1, need_tax=True))
        except Exception:
            traceback.print_exc()
            out['taxes'] = None
    else:
        out['taxes'] = None
    # --- inventaire (dernier instantané)
    if _d3_allowed('inventory_reports'):
        h = db_inventory_history(2)
        if h:
            cur, prev = h[0], (h[1] if len(h) > 1 else None)
            out['inventory'] = {'cost': cur['cost_value'], 'retail': cur['retail_value'], 'items': cur['items'], 'units': cur['units'],
                                'taken_at': cur['taken_at'], 'shop': cur['shop_name'] or 'Tous les magasins',
                                'previous': prev['cost_value'] if prev else None, 'previous_at': prev['taken_at'] if prev else None}
        else:
            out['inventory'] = {'cost': None}
    else:
        out['inventory'] = None
    return out


# ============================================================
# Gestion Atelier (1.21.0)
# ------------------------------------------------------------
# Les mécaniciens punchent leur temps sur chaque bon HubTiger (poste de punch,
# NIP par mécanicien). Une pause ferme le punch ; « Reprendre » en ouvre un
# nouveau. Débuter un autre bon alors qu'un bon roule déjà demande quoi faire :
# terminer l'ancien, le mettre en pause, ou travailler sur les deux (le temps
# compte alors sur chaque bon). Rentabilité : minutes et montants de service
# facturés (lignes « Service N mins » portant « HT: #bon » dans Lightspeed)
# comparés au temps punché × taux coûtant du mécanicien.
# ============================================================
AT_FMT = '%Y-%m-%d %H:%M:%S'
AT_OPEN_ALERT_HOURS = 10
_at_pin_fail = {}


def _at_now():
    return datetime.datetime.now().strftime(AT_FMT)


def _at_dt(s):
    return datetime.datetime.strptime(s, AT_FMT)


def at_norm_job(j):
    j = re.sub(r'\D', '', str(j or ''))
    return j.lstrip('0') or ('0' if j else '')


def at_default_rate():
    try:
        return float(meta_get('atelier_cost_rate') or 30)
    except ValueError:
        return 30.0


def at_mechanics(include_inactive=False):
    conn = get_conn()
    rows = [dict(r) for r in conn.execute("SELECT * FROM shop_mechanics" + ("" if include_inactive else " WHERE active=1")
                                          + " ORDER BY name COLLATE NOCASE").fetchall()]
    conn.close()
    return rows


def at_verify_pin(mid, pin):
    """Vérifie le NIP (5 erreurs = 5 minutes de blocage). Retourne (mécanicien, erreur)."""
    f = _at_pin_fail.get(mid, [0, 0])
    if f[0] >= 5 and time.time() - f[1] < 300:
        return None, "Trop d'essais : réessaie dans quelques minutes."
    conn = get_conn()
    m = conn.execute("SELECT * FROM shop_mechanics WHERE id=? AND active=1", (mid,)).fetchone()
    conn.close()
    if not m or not m['pin_hash'] or not check_password_hash(m['pin_hash'], str(pin or '')):
        _at_pin_fail[mid] = [f[0] + 1 if time.time() - f[1] < 300 else 1, time.time()]
        return None, "NIP incorrect."
    _at_pin_fail.pop(mid, None)
    return dict(m), None


def _at_open(conn, mid):
    return [dict(r) for r in conn.execute("SELECT * FROM shop_punches WHERE mechanic_id=? AND end_at IS NULL ORDER BY start_at", (mid,)).fetchall()]


def _at_paused_jobs(conn, mid):
    """Bons dont le dernier punch de ce mécanicien s'est terminé par une pause."""
    rows = conn.execute("SELECT job, ended_by, MAX(end_at) e FROM shop_punches WHERE mechanic_id=? AND end_at IS NOT NULL "
                        "AND start_at >= ? GROUP BY job", (mid, (datetime.datetime.now() - datetime.timedelta(days=30)).strftime(AT_FMT))).fetchall()
    out = []
    for r in rows:
        last = conn.execute("SELECT ended_by FROM shop_punches WHERE mechanic_id=? AND job=? AND end_at IS NOT NULL ORDER BY end_at DESC, id DESC LIMIT 1",
                            (mid, r['job'])).fetchone()
        if last and last['ended_by'] == 'pause':
            out.append(r['job'])
    return out


def _at_job_seconds(conn, job):
    now = datetime.datetime.now()
    total = 0.0
    for r in conn.execute("SELECT start_at, end_at FROM shop_punches WHERE job=?", (job,)).fetchall():
        total += ((_at_dt(r['end_at']) if r['end_at'] else now) - _at_dt(r['start_at'])).total_seconds()
    return max(0, total)


def at_mech_state(conn, m):
    now = datetime.datetime.now()
    open_ = _at_open(conn, m['id'])
    paused = [j for j in _at_paused_jobs(conn, m['id']) if j not in {p['job'] for p in open_}]
    recent = [r['job'] for r in conn.execute("SELECT job, MAX(start_at) s FROM shop_punches WHERE mechanic_id=? GROUP BY job "
                                             "ORDER BY s DESC LIMIT 5", (m['id'],)).fetchall()]
    assigned = [r['job'] for r in conn.execute(
        "SELECT job FROM shop_jobs WHERE mechanic_id=? AND status IN ('ouvert','en_cours') AND (work_date IS NULL OR work_date='' OR work_date<=?) "
        "ORDER BY CASE WHEN status='en_cours' THEN 0 ELSE 1 END, COALESCE(NULLIF(work_date,''),'9999'), position, created_at",
        (m['id'], datetime.date.today().isoformat())).fetchall()]
    upcoming = [dict(r) for r in conn.execute(        # 1.33.0 : bons planifiés des prochains jours (pour prendre de l'avance)
        "SELECT job, work_date FROM shop_jobs WHERE mechanic_id=? AND status IN ('ouvert','en_cours') AND work_date>? "
        "ORDER BY work_date, position, created_at LIMIT 60", (m['id'], datetime.date.today().isoformat())).fetchall()]
    infos = at_job_infos(conn, [p['job'] for p in open_] + paused + recent + assigned + [u['job'] for u in upcoming])
    return {'id': m['id'], 'name': m['name'], 'color': m['color'] or '#2563eb',
            'upcoming': [{'job': u['job'], 'date': u['work_date'], 'total': _at_job_seconds(conn, u['job'])} for u in upcoming],
            'open': [{'id': p['id'], 'job': p['job'], 'since': p['start_at'],
                      'seconds': (now - _at_dt(p['start_at'])).total_seconds()} for p in open_],
            'paused': paused,
            'recent': [{'job': j, 'total': _at_job_seconds(conn, j)} for j in recent],
            'assigned': [{'job': j, 'total': _at_job_seconds(conn, j)} for j in assigned],
            'infos': infos, 'unread': at_unread_counts(conn, m['id'])}


def at_punch(mid, action, job, mode=None):
    """Applique une action du poste de punch. Retourne un dict (ok / conflict / error)."""
    job = at_norm_job(job)
    now = _at_now()
    conn = get_conn()
    try:
        m = dict(conn.execute("SELECT * FROM shop_mechanics WHERE id=?", (mid,)).fetchone())
        open_ = _at_open(conn, mid)
        if action == 'start' or action == 'resume':
            if not job:
                return {'ok': False, 'error': "Entre le numéro du bon."}
            if any(p['job'] == job for p in open_):
                return {'ok': True, 'state': at_mech_state(conn, m)}
            others = [p for p in open_ if p['job'] != job]
            if others and mode not in ('stop', 'pause', 'both'):
                return {'ok': False, 'conflict': True, 'open': [{'job': p['job'], 'seconds': (datetime.datetime.now() - _at_dt(p['start_at'])).total_seconds()} for p in others]}
            if others and mode in ('stop', 'pause'):
                for p in others:
                    conn.execute("UPDATE shop_punches SET end_at=?, ended_by=? WHERE id=?", (now, 'fin' if mode == 'stop' else 'pause', p['id']))
            conn.execute("INSERT INTO shop_punches(mechanic_id, job, start_at, end_at, ended_by, created_by) VALUES (?,?,?,NULL,NULL,'poste')",
                         (mid, job, now))
            at_job_set_status(conn, job, 'en_cours')
            if others and mode == 'stop':
                for p in others:
                    at_job_set_status(conn, p['job'], 'termine')
            conn.commit()
            db_add_audit(f"Atelier — {m['name']}", 'Punch : début', f"bon {job}" + (f" ({mode} : {', '.join(p['job'] for p in others)})" if others else ''))
            return {'ok': True, 'state': at_mech_state(conn, m)}
        if action in ('pause', 'finish'):
            p = next((p for p in open_ if p['job'] == job), None)
            session = 0.0
            if p:
                conn.execute("UPDATE shop_punches SET end_at=?, ended_by=? WHERE id=?", (now, 'pause' if action == 'pause' else 'fin', p['id']))
                session = (datetime.datetime.now() - _at_dt(p['start_at'])).total_seconds()
            elif action == 'finish':      # bon en pause terminé sans le reprendre : on note la fin
                conn.execute("INSERT INTO shop_punches(mechanic_id, job, start_at, end_at, ended_by, created_by) VALUES (?,?,?,?,'fin','poste')",
                             (mid, job, now, now))
            else:
                return {'ok': False, 'error': "Ce bon n'est pas en cours."}
            if action == 'finish':
                at_job_set_status(conn, job, 'termine')
            conn.commit()
            db_add_audit(f"Atelier — {m['name']}", 'Punch : ' + ('pause' if action == 'pause' else 'fin'), f"bon {job}")
            return {'ok': True, 'session': session, 'job_total': _at_job_seconds(conn, job), 'state': at_mech_state(conn, m)}
        return {'ok': False, 'error': "Action inconnue."}
    finally:
        conn.close()


def _at_period(args):
    today = datetime.date.today()
    p = args.get('periode', 'jour')
    if args.get('start') and args.get('end'):
        d0, d1 = datetime.date.fromisoformat(args['start']), datetime.date.fromisoformat(args['end'])
    elif p == 'semaine':
        d0, d1 = today - datetime.timedelta(days=today.weekday()), today
    elif p == 'mois':
        d0, d1 = today.replace(day=1), today
    elif p == 'mois_dernier':
        last = today.replace(day=1) - datetime.timedelta(days=1); d0, d1 = last.replace(day=1), last
    elif p == 'trimestre':
        d0, d1 = datetime.date(today.year, (today.month - 1) // 3 * 3 + 1, 1), today
    elif p == 'annee':
        d0, d1 = datetime.date(today.year, 1, 1), today
    else:
        d0, d1 = today, today
    if d1 < d0:
        d0, d1 = d1, d0
    return d0, d1


def _at_clipped(conn, d0, d1):
    """Punchs de la période, ramenés aux bornes de la période (secondes)."""
    a, b = datetime.datetime.combine(d0, datetime.time.min), datetime.datetime.combine(d1 + datetime.timedelta(days=1), datetime.time.min)
    now = datetime.datetime.now()
    out = []
    for r in conn.execute("SELECT p.*, m.name, m.cost_rate FROM shop_punches p JOIN shop_mechanics m ON m.id=p.mechanic_id "
                          "WHERE p.start_at < ? AND (p.end_at IS NULL OR p.end_at > ?)", (b.strftime(AT_FMT), a.strftime(AT_FMT))).fetchall():
        s, e = max(_at_dt(r['start_at']), a), min(_at_dt(r['end_at']) if r['end_at'] else now, b)
        if e > s:
            d = dict(r); d['s'], d['e'] = s, e; d['sec'] = (e - s).total_seconds(); out.append(d)
    return out


def _at_job_status(conn, job):
    if conn.execute("SELECT 1 FROM shop_punches WHERE job=? AND end_at IS NULL", (job,)).fetchone():
        return 'En cours'
    last = conn.execute("SELECT ended_by FROM shop_punches WHERE job=? ORDER BY end_at DESC, id DESC LIMIT 1", (job,)).fetchone()
    return 'Terminé' if last and last['ended_by'] == 'fin' else 'En pause'


def at_live(args):
    d0, d1 = _at_period(args)
    now = datetime.datetime.now()
    conn = get_conn()
    try:
        mechs = [at_mech_state(conn, m) for m in at_mechanics()]
        pun = _at_clipped(conn, d0, d1)
        jobs = {}
        for p in pun:
            j = jobs.setdefault(p['job'], {'job': p['job'], 'sec': 0.0, 'sessions': 0, 'mechs': set()})
            j['sec'] += p['sec']; j['sessions'] += 1; j['mechs'].add(p['name'])
        rows = []
        for j in sorted(jobs.values(), key=lambda x: -x['sec']):
            b = at_billing(conn, j['job'])
            info = at_job_infos(conn, [j['job']]).get(j['job'], {})
            rows.append({'job': j['job'], 'client': info.get('client', ''), 'item': info.get('item', ''),
                         'seconds': j['sec'], 'sessions': j['sessions'], 'mechs': ', '.join(sorted(j['mechs'])),
                         'status': _at_job_status(conn, j['job']), 'billed_minutes': b['minutes'], 'sales': b['sales']})
        today_sec = {}
        for p in _at_clipped(conn, datetime.date.today(), datetime.date.today()):
            today_sec[p['mechanic_id']] = today_sec.get(p['mechanic_id'], 0) + p['sec']
        for m in mechs:
            m['today'] = today_sec.get(m['id'], 0)
        alerts = [{'id': r['id'], 'mechanic': r['name'], 'job': r['job'], 'since': r['start_at']} for r in conn.execute(
            "SELECT p.id, p.job, p.start_at, m.name FROM shop_punches p JOIN shop_mechanics m ON m.id=p.mechanic_id WHERE p.end_at IS NULL "
            "AND p.start_at < ?", ((now - datetime.timedelta(hours=AT_OPEN_ALERT_HOURS)).strftime(AT_FMT),)).fetchall()]
        return {'start': d0.isoformat(), 'end': d1.isoformat(), 'mechanics': mechs, 'jobs': rows, 'alerts': alerts,
                'total_seconds': sum(p['sec'] for p in pun)}
    finally:
        conn.close()


def at_billing(conn, job):
    """Facturé pour un bon : saisie manuelle si présente, sinon lignes Lightspeed « HT: #bon »."""
    o = conn.execute("SELECT * FROM shop_billing WHERE job=?", (job,)).fetchone()
    r = conn.execute("SELECT COALESCE(SUM(svc_minutes),0) mn, COALESCE(SUM(CASE WHEN svc_minutes>0 THEN total ELSE 0 END),0) amt, "
                     "COALESCE(SUM(CASE WHEN COALESCE(svc_minutes,0)=0 THEN total ELSE 0 END),0) parts, "
                     "GROUP_CONCAT(DISTINCT sale_id) sales FROM sales_lines l LEFT JOIN shop_sale_links k ON k.sale_line_id=l.sale_line_id "
                     "WHERE COALESCE(k.ignored,0)=0 AND COALESCE(k.job, l.job_ref)=?", (job,)).fetchone()
    sales = [x for x in (r['sales'] or '').split(',') if x]
    if o:
        return {'minutes': o['billed_minutes'], 'amount': o['billed_amount'], 'parts': round(r['parts'], 2), 'sales': sales,
                'source': 'manuel', 'note': o['note']}
    if not sales:
        return {'minutes': None, 'amount': None, 'parts': 0.0, 'sales': [], 'source': None}
    return {'minutes': round(r['mn'], 1), 'amount': round(r['amt'], 2), 'parts': round(r['parts'], 2), 'sales': sales, 'source': 'lightspeed'}


# ---------- relecture automatique des ventes chaque nuit (1.29.1) ----------
AT_REREAD_HOUR = 2


def at_reread_cfg():
    try:
        days = int(meta_get('atelier_reread_days') or 7)
    except ValueError:
        days = 7
    return {'enabled': meta_get('atelier_reread_enabled') == '1', 'days': days, 'hour': AT_REREAD_HOUR,
            'last': meta_get('atelier_reread_last_at') or '', 'last_result': meta_get('atelier_reread_last_result') or ''}


def _atelier_reread_loop():
    """Une fois par nuit (vers 2 h), relit dans Lightspeed les ventes des N derniers jours :
    une vente souvent corrigée après coup (ex. « HT: #bon » ajouté le lendemain) est ainsi mise à jour."""
    time.sleep(90)
    while True:
        try:
            cfg = at_reread_cfg()
            now = datetime.datetime.now(); today = now.date().isoformat()
            if cfg['enabled'] and now.hour >= AT_REREAD_HOUR and meta_get('atelier_reread_last_day') != today and ls_config()['connected']:
                if _store_lock.acquire(blocking=False):
                    ss = _store_state
                    days = [now.date() - datetime.timedelta(days=i) for i in range(cfg['days'], 0, -1)] + [now.date()]
                    ss.update(running=True, progress=f"Relecture automatique : {len(days)} jour(s)…", error=None, kind='atelier')
                    try:
                        store_sync_days(days, ss, 'atelier')
                        res = f"{len(days)} jour(s) relus"
                    except Exception as e:
                        res = f"échec : {e}"
                    finally:
                        ss['running'] = False; ss['progress'] = ''
                        _store_lock.release()
                    meta_set('atelier_reread_last_day', today); meta_set('atelier_reread_last_at', now.strftime('%Y-%m-%d %H:%M'))
                    meta_set('atelier_reread_last_result', res)
                    db_add_audit('Kubios', 'Atelier : relecture automatique des ventes', res)
        except Exception:
            traceback.print_exc()
        time.sleep(600)


def at_profit_compare(args):
    """Rentabilité de la période + la période précédente de même durée (pour les comparaisons)."""
    r = at_profit(args)
    d0, d1 = datetime.date.fromisoformat(r['start']), datetime.date.fromisoformat(r['end'])
    n = (d1 - d0).days + 1
    p0, p1 = d0 - datetime.timedelta(days=n), d0 - datetime.timedelta(days=1)
    prev = at_profit({'start': p0.isoformat(), 'end': p1.isoformat()})
    r['prev'] = {'start': prev['start'], 'end': prev['end'], 'totals': prev['totals'],
                 'mechanics': {m['id']: {'yield': m['yield'], 'margin': m['margin'], 'real_rate': m['real_rate'], 'seconds': m['seconds'],
                                         'jobs_count': m['jobs_count']} for m in prev['mechanics']}}
    r['all_mechanics'] = [{'id': m['id'], 'name': m['name'], 'active': bool(m['active'])} for m in at_mechanics(True)]
    return r


def at_unmatched(d0, d1):
    """Services facturés (« Service N mins ») de la période qu'on ne peut pas relier à un bon punché :
    sans numéro « HT: # », ou avec un numéro sur lequel personne n'a punché."""
    conn = get_conn()
    try:
        punched = {r['job'] for r in conn.execute("SELECT DISTINCT job FROM shop_punches").fetchall()}
        rows = conn.execute(
            "SELECT l.sale_line_id, l.sale_id, l.sale_date, l.descr, l.svc_minutes, l.total, l.job_ref, k.job link_job, COALESCE(k.ignored,0) ignored "
            "FROM sales_lines l LEFT JOIN shop_sale_links k ON k.sale_line_id=l.sale_line_id "
            "WHERE l.sale_date BETWEEN ? AND ? AND COALESCE(l.svc_minutes,0) > 0 ORDER BY l.sale_date DESC, l.sale_id",
            (d0.isoformat(), d1.isoformat())).fetchall()
        out, ignored = [], 0
        # 1.40.1 : bons déjà associés à une vente (pour ne pas les proposer deux fois)
        used = {r[0] for r in conn.execute("SELECT job_ref FROM sales_lines WHERE job_ref IS NOT NULL AND job_ref<>'' "
                                            "UNION SELECT job FROM shop_sale_links WHERE job IS NOT NULL AND job<>''").fetchall()}
        jobinfo = lambda j: conn.execute("SELECT job, client, item, work, due_date, status FROM shop_jobs WHERE job=?", (j,)).fetchone()
        for r in rows:
            job = r['link_job'] or r['job_ref']
            if r['ignored']:
                ignored += 1
                continue
            if job and job in punched:
                continue
            row = {'line': r['sale_line_id'], 'sale': r['sale_id'], 'date': r['sale_date'], 'descr': r['descr'] or '',
                   'minutes': r['svc_minutes'], 'amount': round(r['total'] or 0, 2), 'job': job or '',
                   'reason': 'sans_bon' if not job else 'sans_punch', 'job_info': None, 'suggest': []}
            if job:
                ji = jobinfo(job)
                row['job_info'] = {'client': ji['client'], 'item': ji['item']} if ji else None
            elif len(out) < 300:
                # bons probables : même durée de service, date prévue proche, pas encore associés à une vente
                sd = datetime.date.fromisoformat(r['sale_date'][:10])
                cand = conn.execute(
                    "SELECT job, client, item, due_date, created_at FROM shop_jobs WHERE work LIKE ? AND status<>'annule' "
                    "AND COALESCE(due_date, substr(created_at,1,10)) BETWEEN ? AND ?",
                    (f"%Service {int(r['svc_minutes'])} mins%", (sd - datetime.timedelta(days=21)).isoformat(), (sd + datetime.timedelta(days=3)).isoformat())).fetchall()
                cand = [c for c in cand if c['job'] not in used]
                cand.sort(key=lambda c: (c['job'] not in punched, abs((datetime.date.fromisoformat((c['due_date'] or c['created_at'])[:10]) - sd).days)))
                row['suggest'] = [{'job': c['job'], 'client': c['client'] or '', 'item': c['item'] or '', 'due': c['due_date'] or '',
                                   'punched': c['job'] in punched} for c in cand[:3]]
            out.append(row)
        return {'rows': out[:300], 'count': len(out), 'ignored': ignored}
    finally:
        conn.close()


def at_profit(args):
    d0, d1 = _at_period(args)
    conn = get_conn()
    try:
        dflt = at_default_rate()
        pun = _at_clipped(conn, d0, d1)
        jobs, mech = {}, {}
        for p in pun:
            rate = p['cost_rate'] if p['cost_rate'] is not None else dflt
            j = jobs.setdefault(p['job'], {'job': p['job'], 'sec': 0.0, 'cost': 0.0, 'by': {}})
            j['sec'] += p['sec']; j['cost'] += p['sec'] / 3600 * rate
            j['by'][p['mechanic_id']] = j['by'].get(p['mechanic_id'], 0) + p['sec']
            mm = mech.setdefault(p['mechanic_id'], {'name': p['name'], 'rate': rate, 'iv': [], 'bmin': 0.0, 'bamt': 0.0, 'bsec': 0.0, 'jobs': []})
            mm['iv'].append((p['s'], p['e']))
        out_jobs = []
        T = {'billed': 0.0, 'cost': 0.0, 'billed_min': 0.0, 'punched_billed_sec': 0.0, 'unbilled': 0, 'cost_all': 0.0}
        for j in jobs.values():
            b = at_billing(conn, j['job'])
            names = ', '.join(sorted({mech[k]['name'] for k in j['by']}))
            info = at_job_infos(conn, [j['job']]).get(j['job'], {})
            row = {'job': j['job'], 'client': info.get('client', ''), 'item': info.get('item', ''),
                   'mechs': names, 'seconds': j['sec'], 'cost': round(j['cost'], 2), 'status': _at_job_status(conn, j['job']),
                   'billed_minutes': b['minutes'], 'billed': b['amount'], 'parts': b['parts'], 'source': b['source'], 'sales': b['sales']}
            T['cost_all'] += j['cost']
            for k, sec in j['by'].items():              # fiche de chaque mécanicien : sa part de chaque bon
                share = sec / j['sec'] if j['sec'] else 0
                bm = (b['minutes'] or 0) * share if b['amount'] is not None else None
                ba = b['amount'] * share if b['amount'] is not None else None
                cost_k = sec / 3600 * mech[k]['rate']
                mech[k]['jobs'].append({'job': j['job'], 'client': info.get('client', ''), 'item': info.get('item', ''), 'status': row['status'],
                                        'seconds': sec, 'shared': len(j['by']) > 1, 'billed_minutes': None if bm is None else round(bm, 1),
                                        'billed': None if ba is None else round(ba, 2), 'cost': round(cost_k, 2),
                                        'gap_minutes': None if bm is None else round(sec / 60 - bm, 1),
                                        'margin': None if ba is None else round(ba - cost_k, 2),
                                        'job_loss': b['amount'] is not None and b['amount'] - j['cost'] < 0})
            if b['amount'] is not None:
                row['margin'] = round(b['amount'] - j['cost'], 2)
                row['gap_minutes'] = round(j['sec'] / 60 - (b['minutes'] or 0), 1)
                T['billed'] += b['amount']; T['cost'] += j['cost']; T['billed_min'] += b['minutes'] or 0; T['punched_billed_sec'] += j['sec']
                for k, sec in j['by'].items():          # partage du facturé selon le temps de chacun
                    share = sec / j['sec'] if j['sec'] else 0
                    mech[k]['bmin'] += (b['minutes'] or 0) * share; mech[k]['bamt'] += b['amount'] * share; mech[k]['bsec'] += sec
            else:
                T['unbilled'] += 1
            out_jobs.append(row)
        out_jobs.sort(key=lambda r: (r.get('margin') is None, r.get('margin') or 0))
        out_mech = []
        for k, mm in mech.items():
            iv = sorted(mm['iv']); tot = 0.0; cs, ce = None, None
            for s_, e_ in iv:                       # temps réel (deux bons en même temps comptés une fois)
                if cs is None or s_ > ce:
                    if cs is not None: tot += (ce - cs).total_seconds()
                    cs, ce = s_, e_
                else:
                    ce = max(ce, e_)
            if cs is not None: tot += (ce - cs).total_seconds()
            js = mm['jobs']
            billed_js = [x for x in js if x['billed'] is not None]
            cost = round(tot / 3600 * mm['rate'], 2)
            a0, a1 = d0.strftime('%Y-%m-%d 00:00:00'), (d1 + datetime.timedelta(days=1)).strftime('%Y-%m-%d 00:00:00')
            problems = conn.execute("SELECT COUNT(*) FROM shop_messages WHERE mechanic_id=? AND kind='probleme' AND created_at>=? AND created_at<?", (k, a0, a1)).fetchone()[0]
            corrections = conn.execute("SELECT COUNT(*) FROM shop_punches WHERE mechanic_id=? AND corrected_by IS NOT NULL AND start_at>=? AND start_at<?", (k, a0, a1)).fetchone()[0]
            lost_sec = max(0.0, mm['bsec'] - mm['bmin'] * 60)
            out_mech.append({'id': k, 'name': mm['name'], 'seconds': tot, 'rate': mm['rate'], 'cost': cost,
                             'billed_minutes': round(mm['bmin'], 1), 'billed': round(mm['bamt'], 2), 'billed_job_seconds': mm['bsec'],
                             'yield': round(mm['bmin'] / (mm['bsec'] / 60) * 100) if mm['bsec'] >= 60 else None,
                             'margin': round(mm['bamt'] - mm['bsec'] / 3600 * mm['rate'], 2),
                             'margin_pct': round((mm['bamt'] - mm['bsec'] / 3600 * mm['rate']) / mm['bamt'] * 100, 1) if mm['bamt'] >= 1 else None,
                             'real_rate': round(mm['bamt'] / (mm['bsec'] / 3600), 2) if mm['bsec'] >= 60 else None,
                             'jobs_count': len(js), 'done_count': sum(1 for x in js if x['status'] == 'Terminé'),
                             'billed_count': len(billed_js), 'unbilled_count': len(js) - len(billed_js),
                             'over_count': sum(1 for x in billed_js if x['gap_minutes'] > 15), 'loss_count': sum(1 for x in billed_js if x['job_loss']),
                             'avg_job_seconds': tot / len(js) if js else 0, 'problems': problems, 'corrections': corrections,
                             'lost_seconds': lost_sec, 'lost_cost': round(lost_sec / 3600 * mm['rate'], 2),
                             'jobs': sorted(js, key=lambda x: -(x['gap_minutes'] if x['gap_minutes'] is not None else -1e9))})
        out_mech.sort(key=lambda r: r['name'])
        return {'start': d0.isoformat(), 'end': d1.isoformat(), 'jobs': out_jobs, 'mechanics': out_mech,
                'totals': {'billed': round(T['billed'], 2), 'cost': round(T['cost'], 2), 'margin': round(T['billed'] - T['cost'], 2),
                           'billed_minutes': round(T['billed_min'], 1), 'punched_billed_seconds': T['punched_billed_sec'],
                           'yield': round(T['billed_min'] / (T['punched_billed_sec'] / 60) * 100) if T['punched_billed_sec'] >= 60 else None,
                           'effective_rate': round(T['billed'] / (T['punched_billed_sec'] / 3600), 2) if T['punched_billed_sec'] >= 60 else None,
                           'unbilled_jobs': T['unbilled'], 'cost_all': round(T['cost_all'], 2),
                           'lost_seconds': max(0.0, T['punched_billed_sec'] - T['billed_min'] * 60),
                           'lost_cost': round(sum(m['lost_cost'] for m in out_mech), 2),
                           'unbilled_seconds': sum(r['seconds'] for r in out_jobs if r['billed'] is None),
                           'unbilled_cost': round(sum(r['cost'] for r in out_jobs if r['billed'] is None), 2),
                           'punched_seconds': sum(m['seconds'] for m in out_mech)},
                'default_rate': dflt, 'missing_days': len([d for d in store_missing_days(d0, d1, need_ws=True) if d < datetime.date.today()]),
                'unmatched': at_unmatched(d0, d1)}
    finally:
        conn.close()


# ---------- Bons de travail créés dans Kubios (1.22.0) ----------
AT_JOB_STATUS = {'ouvert': 'Ouvert', 'en_cours': 'En cours', 'termine': 'Terminé', 'annule': 'Annulé'}
AT_PRIORITY = {'normal': 'Normal', 'jour': 'Dans la journée', 'urgent': 'Urgent'}


def _at_next_position(conn, mid):
    r = conn.execute("SELECT COALESCE(MAX(position),0) FROM shop_jobs WHERE COALESCE(mechanic_id,0)=COALESCE(?,0)", (mid,)).fetchone()
    return (r[0] or 0) + 1


def at_job_infos(conn, jobs):
    """Client / appareil / travaux des bons connus dans Kubios."""
    jobs = [j for j in set(jobs) if j]
    if not jobs:
        return {}
    q = "SELECT j.*, m.name mech_name FROM shop_jobs j LEFT JOIN shop_mechanics m ON m.id=j.mechanic_id WHERE j.job IN (%s)" % ','.join('?' * len(jobs))
    return {r['job']: {'client': r['client'] or '', 'item': r['item'] or '', 'work': r['work'] or '', 'due': r['due_date'] or '',
                       'status': r['status'], 'mechanic': r['mech_name'] or '', 'mechanic_id': r['mechanic_id'],
                       'priority': r['priority'] or 'normal', 'notes': r['notes'] or '', 'position': r['position'] or 0,
                       'work_date': r['work_date'] or ''}
            for r in conn.execute(q, jobs).fetchall()}


def at_job_set_status(conn, job, status):
    conn.execute("UPDATE shop_jobs SET status=?, updated_at=? WHERE job=? AND status<>'annule'", (status, _at_now(), job))


# ---------- Accès du poste de punch sans le login de Kubios (1.22.0) ----------
KIOSK_COOKIE = 'kubios_poste_punch'
KIOSK_MAX_AGE = 400 * 86400
_kiosk_fail = {}


def _kiosk_serializer():
    from itsdangerous import URLSafeTimedSerializer
    return URLSafeTimedSerializer(app.secret_key, salt='kubios-poste-punch')


def kiosk_secret():
    s = meta_get('kiosk_secret')
    if not s:
        s = secrets.token_urlsafe(16)
        meta_set('kiosk_secret', s)
    return s


def kiosk_link_token():
    t = meta_get('kiosk_link_token')
    if not t:
        t = secrets.token_urlsafe(24)
        meta_set('kiosk_link_token', t)
    return t


def kiosk_device_ok():
    raw = request.cookies.get(KIOSK_COOKIE)
    if not raw:
        return False
    try:
        data = _kiosk_serializer().loads(raw, max_age=KIOSK_MAX_AGE)
    except Exception:
        return False
    return secrets.compare_digest(str(data.get('v', '')), kiosk_secret())


def kiosk_allowed():
    """Poste de punch : session Kubios avec la permission, ou tablette autorisée."""
    if session.get('user_id') and (session.get('is_admin') or 'atelier_punch' in (session.get('permissions') or [])):
        return True
    return kiosk_device_ok()


def kiosk_authorize(resp):
    resp.set_cookie(KIOSK_COOKIE, _kiosk_serializer().dumps({'v': kiosk_secret()}), max_age=KIOSK_MAX_AGE,
                    httponly=True, samesite='Lax', secure=request.is_secure)
    return resp


# ============================================================
# Rapport des ventes au format comptable (1.23.0)
# ------------------------------------------------------------
# 1. Ventes par catégorie avec compte GL, sous-total des « ventes élargies »
#    (catégories cochées), puis les autres catégories et le total ;
# 2. répartition par mode de paiement (paiements gardés avec les ventes) ;
# 3. ventilation des taxes ; grand total facturé aux clients.
# Les comptes GL sont réglés par un administrateur (meta « rep_gl »).
# ============================================================
# Valeurs par défaut reprises du modèle de rapport d'Outillages Express (1.23.2) ;
# ce qu'un administrateur enregistre dans « Comptes GL du rapport » a priorité.
REP_GL_DEFAULT = {
    'group_label': 'Ventes élargies',
    'categories': {'Ventes': {'gl': '4100', 'groupe': True}, REP_NO_CATEGORY: {'gl': '4190', 'groupe': True},
                   REP_MISC: {'gl': '4150', 'groupe': True}, 'Location': {'gl': '4200', 'groupe': False},
                   'Pièces de rechange': {'gl': '4300', 'groupe': False}, 'Service': {'gl': '4400', 'groupe': False},
                   'Fond de livraison': {'gl': '4500', 'groupe': False}, 'Usage Interne Magasin': {'gl': '4900', 'groupe': False}},
    'payments': {'Visa': '1020', 'Mastercard': '1025', 'Interac (débit)': '1010', 'Compte à recevoir': '1100', 'Comptant': '1000'},
    'taxes': {'TPS': '2310', 'TVQ': '2315', 'TVH': '', 'TVP': ''}}


def rep_gl_cfg():
    try:
        c = json.loads(meta_get('rep_gl') or '{}')
    except ValueError:
        c = {}
    out = json.loads(json.dumps(REP_GL_DEFAULT))
    if c.get('group_label'):
        out['group_label'] = c['group_label']
    for k in ('categories', 'payments', 'taxes'):       # l'enregistré complète et remplace les valeurs par défaut
        if isinstance(c.get(k), dict):
            out[k].update(c[k])
    return out


def _gl_for_category(cfg, name):
    cats = {str(k).strip().lower(): v for k, v in (cfg.get('categories') or {}).items()}
    n = str(name).strip()
    c = cats.get(n.lower()) or cats.get(n.split('/')[0].strip().lower()) or {}
    return (c.get('gl') or '').strip(), bool(c.get('groupe'))


def rep_payments(d0, d1, shop_id='', cfg=None):
    cfg = cfg or rep_gl_cfg()
    conn = get_conn()
    try:
        rows = [dict(r) for r in conn.execute(
            "SELECT COALESCE(NULLIF(TRIM(name),''),'(Autre)') name, SUM(amount) amt, COUNT(*) n FROM sales_payments "
            "WHERE sale_date BETWEEN ? AND ?" + (" AND shop_id=?" if shop_id else "") + " GROUP BY 1",
            [d0.isoformat(), d1.isoformat()] + ([str(shop_id)] if shop_id else [])).fetchall()]
    finally:
        conn.close()
    total = round(sum(r['amt'] or 0 for r in rows), 2)
    out = [{'gl': (cfg['payments'].get(r['name']) or '').strip(), 'mode': r['name'], 'montant': round(r['amt'] or 0, 2), 'paiements': r['n'],
            'part': round((r['amt'] or 0) / total * 100, 1) if abs(total) >= 0.005 else None} for r in rows]
    out.sort(key=lambda r: -r['montant'])
    return out, total


def rep_taxes(d0, d1, shop_id='', cfg=None):
    cfg = cfg or rep_gl_cfg()
    try:
        t = local_tax_report(d0, d1, shop_id)
    except Exception:
        traceback.print_exc()
        return [], 0.0
    labels = {'TPS': 'TPS (fédérale)', 'TVQ': 'TVQ (provinciale)', 'TVH': 'TVH (harmonisée)', 'TVP': 'TVP (provinciale)'}
    out = [{'gl': (cfg['taxes'].get(x['taxe']) or '').strip(), 'type': labels.get(x['taxe'], x['taxe']), 'taux': x['taux'],
            'base': x['ventes_taxables'], 'taxe': x['taxe_percue']} for x in t['rates']]
    return out, round(t['totals']['taxes'], 2)


def rep_accounting_layout(r, cfg=None):
    """Ajoute au rapport par catégorie : comptes GL, sous-total, paiements, taxes."""
    cfg = cfg or rep_gl_cfg()
    for row in r['rows']:
        row['gl'], row['groupe'] = _gl_for_category(cfg, row['categorie'])
    key = lambda x: (x['gl'] == '', x['gl'], -x['total'])
    grp = sorted([x for x in r['rows'] if x['groupe']], key=lambda x: -x['total'])
    rest = sorted([x for x in r['rows'] if not x['groupe']], key=key)
    sub = None
    if grp:
        sub = {k: round(sum(x[k] for x in grp), 2) for k in ('quantite', 'sous_total', 'rabais', 'total', 'cout')}
        sub['profit'] = round(sub['total'] - sub['cout'], 2)
        sub['marge'] = round(sub['profit'] / sub['total'] * 100, 1) if abs(sub['total']) >= 0.005 else None
        sub['part'] = round(sub['total'] / r['totals']['total'] * 100, 1) if abs(r['totals']['total']) >= 0.005 else None
        sub['categorie'] = f"SOUS-TOTAL ({cfg['group_label'] or 'Ventes élargies'})"
    r['rows'] = grp + rest
    r['group_count'] = len(grp)
    r['subtotal'] = sub
    d0, d1 = datetime.date.fromisoformat(r['start']), datetime.date.fromisoformat(r['end'])
    r['payments'], r['payments_total'] = rep_payments(d0, d1, r.get('shop_id') or '', cfg)
    r['taxes'], r['taxes_total'] = rep_taxes(d0, d1, r.get('shop_id') or '', cfg)
    r['grand_total'] = round(r['totals']['total'] + r['taxes_total'], 2)
    return r


# ---------- Messages de l'atelier (1.26.0) ----------
# Le mécanicien écrit au responsable ou signale un problème sur un bon (poste de punch,
# NIP demandé) ; le responsable voit une pastille et une alerte partout dans Kubios,
# répond, et marque les problèmes résolus. Courriel facultatif pour les problèmes.
AT_PROBLEMS = {'pieces': 'Pièce manquante', 'temps': 'Plus long que prévu', 'client': 'Client à contacter',
               'outil': 'Outil / équipement', 'autre': 'Autre problème'}


def at_unread_counts(conn, mid=None):
    if mid is None:
        r = conn.execute("SELECT COUNT(*) n, SUM(CASE WHEN kind='probleme' AND resolved_at IS NULL THEN 1 ELSE 0 END) p "
                         "FROM shop_messages WHERE from_side='mecanicien' AND read_at IS NULL").fetchone()
        return {'unread': r['n'] or 0, 'problems': r['p'] or 0}
    return conn.execute("SELECT COUNT(*) FROM shop_messages WHERE mechanic_id=? AND from_side='responsable' AND read_at IS NULL",
                        (mid,)).fetchone()[0]


def at_thread(conn, mid, limit=40):
    rows = [dict(r) for r in conn.execute("SELECT * FROM shop_messages WHERE mechanic_id=? ORDER BY id DESC LIMIT ?", (mid, limit)).fetchall()]
    for r in rows:
        r['category_label'] = AT_PROBLEMS.get(r['category'] or '', '')
    return list(reversed(rows))


def _at_notify_problem(mech_name, job, category, text):
    emails = [e.strip() for e in (meta_get('atelier_notify_emails') or '').replace(';', ',').split(',') if '@' in e]
    if not emails:
        return

    def run():
        com = False
        if get_settings()['send_mode'] != 'smtp':
            try:
                import pythoncom
                pythoncom.CoInitialize()
                com = True
            except Exception:
                pass
        try:
            subject = f"Atelier — problème signalé par {mech_name}" + (f" (bon {job})" if job else '')
            body = (f"Bonjour,\n\n{mech_name} a signalé un problème" + (f" sur le bon {job}" if job else '') + f" :\n\n"
                    f"{AT_PROBLEMS.get(category, 'Problème')}" + (f"\n« {text} »" if text else '') +
                    f"\n\nRéponds-lui dans Kubios → Atelier → Messages.\n\n{get_company_name()}")
            for e in emails:
                try:
                    send_email(e, subject, body, None, mode='send', bcc_company=False)
                except Exception as ex:
                    db_add_audit('Atelier', 'Avis de problème par courriel — échec', f"{e} : {ex}")
        finally:
            if com:
                try:
                    import pythoncom
                    pythoncom.CoUninitialize()
                except Exception:
                    pass
    threading.Thread(target=run, daemon=True).start()


# ---------- L'atelier en direct : garage 3D (1.27.0) ----------
def at_direct_state(after=None):
    """État de chaque mécanicien actif pour la vue 3D, et les nouveaux messages (après « after »)."""
    nowd = datetime.datetime.now()
    conn = get_conn()
    try:
        today = {}
        for p in _at_clipped(conn, datetime.date.today(), datetime.date.today()):
            today[p['mechanic_id']] = today.get(p['mechanic_id'], 0) + p['sec']
        problems = {}
        for r in conn.execute("SELECT * FROM shop_messages WHERE kind='probleme' AND resolved_at IS NULL ORDER BY id").fetchall():
            problems[r['mechanic_id']] = {'id': r['id'], 'job': r['job'], 'label': AT_PROBLEMS.get(r['category'] or '', 'Problème'), 'text': r['text'] or ''}
        unread = {r['mechanic_id']: r['n'] for r in conn.execute(
            "SELECT mechanic_id, COUNT(*) n FROM shop_messages WHERE from_side='mecanicien' AND read_at IS NULL GROUP BY mechanic_id").fetchall()}
        mechs = []
        for m in at_mechanics():
            st = at_mech_state(conn, m)
            info = st['infos']
            if st['open']:
                cur = st['open'][0]; job = cur['job']; status = 'work'; since = cur['seconds']
            else:
                job = st['paused'][0] if st['paused'] else ''
                status = 'pause' if job else 'free'
                last = conn.execute("SELECT MAX(end_at) e FROM shop_punches WHERE mechanic_id=? AND end_at IS NOT NULL", (m['id'],)).fetchone()['e']
                start_day = datetime.datetime.combine(datetime.date.today(), datetime.time(7, 0))
                ref = _at_dt(last) if last else start_day
                since = max(0, (nowd - max(ref, start_day if status == 'free' else ref)).total_seconds())
            pb = problems.get(m['id'])
            if pb:
                status = 'alert'
            i = info.get(job, {}) if job else {}
            oubli = [o for o in st['open'] if o['seconds'] > AT_OPEN_ALERT_HOURS * 3600]
            mechs.append({'id': m['id'], 'name': m['name'], 'color': m['color'] or '#2563eb', 'status': status, 'job': job,
                          'client': i.get('client', ''), 'item': i.get('item', ''), 'since_seconds': since,
                          'job_seconds': _at_job_seconds(conn, job) if job else 0, 'today_seconds': today.get(m['id'], 0),
                          'others': [o['job'] for o in st['open'][1:]], 'problem': pb, 'unread': unread.get(m['id'], 0),
                          'oubli': [{'punch': o['id'], 'job': o['job'], 'since': o['since']} for o in oubli],
                          'next': [{'job': a['job'], 'label': ' — '.join(x for x in (info.get(a['job'], {}).get('client', ''), info.get(a['job'], {}).get('item', '')) if x)}
                                   for a in st['assigned'] if a['job'] != job][:3]})
        last_id = conn.execute("SELECT COALESCE(MAX(id),0) FROM shop_messages").fetchone()[0]
        today_iso = datetime.date.today().isoformat()
        names = {m['id']: (m['name'], m['color'] or '#2563eb') for m in at_mechanics(True)}
        todo = [dict(r) for r in conn.execute(
            "SELECT * FROM shop_jobs WHERE status IN ('ouvert','en_cours') AND (work_date=? OR (work_date IS NOT NULL AND work_date<>'' AND work_date<?) "
            "OR job IN (SELECT job FROM shop_punches WHERE end_at IS NULL)) ORDER BY CASE WHEN status='en_cours' THEN 0 ELSE 1 END, mechanic_id, position",
            (today_iso, today_iso)).fetchall()]
        done_jobs = {}
        for r in conn.execute("SELECT job, mechanic_id, MAX(end_at) e FROM shop_punches WHERE ended_by='fin' AND end_at LIKE ? GROUP BY job",
                              (today_iso + '%',)).fetchall():
            done_jobs[r['job']] = (r['mechanic_id'], r['e'])
        for r in conn.execute("SELECT job, mechanic_id, updated_at FROM shop_jobs WHERE status='termine' AND updated_at LIKE ?", (today_iso + '%',)).fetchall():
            done_jobs.setdefault(r['job'], (r['mechanic_id'], r['updated_at']))
        infos = at_job_infos(conn, [t['job'] for t in todo] + list(done_jobs))
        def jrow(job, mid, extra):
            i = infos.get(job, {})
            n = names.get(mid, ('', '#64748b'))
            return dict({'job': job, 'client': i.get('client', ''), 'item': i.get('item', ''), 'priority': i.get('priority', 'normal'),
                         'mechanic': n[0], 'color': n[1], 'seconds': _at_job_seconds(conn, job)}, **extra)
        day = {'todo': [jrow(t['job'], t['mechanic_id'], {'status': t['status'], 'late': bool(t['work_date'] and t['work_date'] < today_iso)}) for t in todo
                        if t['job'] not in done_jobs or t['status'] == 'en_cours'],
               'done': sorted([jrow(jb, v[0], {'finished_at': v[1]}) for jb, v in done_jobs.items()
                               if not any(t['job'] == jb and t['status'] == 'en_cours' for t in todo)], key=lambda x: x['finished_at'] or '', reverse=True)}
        events = []
        if after is not None:
            for r in conn.execute("SELECT s.*, m.name FROM shop_messages s JOIN shop_mechanics m ON m.id=s.mechanic_id "
                                  "WHERE s.id>? AND s.from_side='mecanicien' ORDER BY s.id LIMIT 10", (after,)).fetchall():
                events.append({'id': r['id'], 'mechanic_id': r['mechanic_id'], 'kind': r['kind'], 'job': r['job'],
                               'text': (AT_PROBLEMS.get(r['category'] or '', '') + (' — ' if r['text'] and r['category'] else '') if r['kind'] == 'probleme' else '') + (r['text'] or '')})
        return {'mechanics': mechs, 'last_id': last_id, 'events': events, 'unread_total': sum(unread.values()), 'day': day,
                'server_time': nowd.strftime(AT_FMT), 'company': get_company_name()}
    finally:
        conn.close()


# ---------- PDF de la rentabilité de l'atelier (1.29.0) ----------
def _at_pdf_kit():
    from reportlab.lib.pagesizes import letter, landscape
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, KeepTogether, PageBreak
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    ss = getSampleStyleSheet()
    k = dict(letter=letter, landscape=landscape, mm=mm, colors=colors, SimpleDocTemplate=SimpleDocTemplate, Table=Table, TableStyle=TableStyle,
             Paragraph=Paragraph, Spacer=Spacer, KeepTogether=KeepTogether, PageBreak=PageBreak)
    k['cell'] = ParagraphStyle('c', parent=ss['Normal'], fontSize=8, leading=10)
    k['cellb'] = ParagraphStyle('cb', parent=k['cell'], fontName='Helvetica-Bold')
    k['h1'] = ParagraphStyle('h1', parent=ss['Normal'], fontName='Helvetica-Bold', fontSize=16, leading=19)
    k['h2'] = ParagraphStyle('h2', parent=ss['Normal'], fontName='Helvetica-Bold', fontSize=11, spaceBefore=6, spaceAfter=4, textColor=colors.HexColor('#1e3a8a'))
    k['small'] = ParagraphStyle('s', parent=ss['Normal'], fontSize=8.5, leading=11, textColor=colors.HexColor('#4b5563'))
    k['base'] = [('FONTSIZE', (0, 0), (-1, -1), 8), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('LINEBELOW', (0, 0), (-1, -1), 0.25, colors.HexColor('#d1d5db')),
                 ('TOPPADDING', (0, 0), (-1, -1), 3), ('BOTTOMPADDING', (0, 0), (-1, -1), 3), ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                 ('TEXTCOLOR', (0, 0), (-1, 0), colors.white), ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e3a8a'))]
    return k


def _m(v):
    return '—' if v is None else (('−' if v < 0 else '') + f"{abs(v):,.2f} $".replace(',', ' ').replace('.', ','))


def _hm(sec):
    sec = int(round((sec or 0) / 60)); return f"{sec // 60} h {sec % 60:02d}"


def _pc(v):
    return '—' if v is None else f"{v:g} %".replace('.', ',')


def _gap(v):
    v = round(v or 0)
    return '0 min' if v == 0 else f"{'+' if v > 0 else '−'}{abs(v)} min"


def _period_txt(r):
    return (f"Le {_d(r['start'])}" if r['start'] == r['end'] else f"Du {_d(r['start'])} au {_d(r['end'])}")


def _trend(cur, prev, better_high=True, fmtf=str):
    if cur is None or prev is None:
        return '—'
    if abs(cur - prev) < 1e-9:
        return '='
    up = cur > prev
    return ('▲ ' if up else '▼ ') + fmtf(abs(cur - prev)) + ('' if up == better_high else ' (à surveiller)')


def _at_doc(path, k, title, sub, landscape_=False):
    ps = k['landscape'](k['letter']) if landscape_ else k['letter']
    lm = 14 * k['mm']
    def header(canvas, doc_):
        canvas.saveState()
        w, h = ps
        canvas.setFont('Helvetica-Bold', 15); canvas.drawString(lm, h - 15 * k['mm'], get_company_name())
        canvas.setFont('Helvetica-Bold', 11); canvas.drawString(lm, h - 21.5 * k['mm'], title)
        canvas.setFont('Helvetica', 8.5); canvas.drawString(lm, h - 26.5 * k['mm'], sub)
        if LOGO_PATH.exists():
            from reportlab.lib.utils import ImageReader
            img = ImageReader(str(LOGO_PATH)); iw, ih = img.getSize(); lw = 34 * k['mm']
            canvas.drawImage(img, w - lm - lw, h - 12 * k['mm'] - lw * ih / iw, width=lw, height=lw * ih / iw, mask='auto')
        canvas.setStrokeColor(k['colors'].HexColor('#999999')); canvas.line(lm, h - 29 * k['mm'], w - lm, h - 29 * k['mm'])
        canvas.setFont('Helvetica', 7); canvas.drawString(lm, 8 * k['mm'], f"{get_company_name()} — {title}"); canvas.drawRightString(w - lm, 8 * k['mm'], f"Page {doc_.page}")
        canvas.restoreState()
    doc = k['SimpleDocTemplate'](str(path), pagesize=ps, leftMargin=lm, rightMargin=lm, topMargin=32 * k['mm'], bottomMargin=12 * k['mm'])
    return doc, header


def export_atelier_finance_pdf(r):
    k = _at_pdf_kit(); T = r['totals']; P = r.get('prev', {}).get('totals', {})
    out = PDF_DIR / "Atelier"; out.mkdir(exist_ok=True)
    path = out / f"Rentabilite_atelier_{r['start']}_au_{r['end']}.pdf"
    g = datetime.datetime.now()
    doc, header = _at_doc(path, k, "Rentabilité de l'atelier — rapport financier", f"{_period_txt(r)} — généré le {g:%d-%m-%Y à %H:%M}", True)
    Tb, TS, Pa, C = k['Table'], k['TableStyle'], k['Paragraph'], k['colors']
    story = []
    kp = [["Main-d'œuvre facturée", "Coût (bons facturés)", "Marge", "Rendement", "Taux horaire réel", "Heures punchées"],
          [_m(T['billed']), _m(T['cost']), f"{_m(T['margin'])}" + (f"  ({T['margin'] / T['billed'] * 100:.1f} %)".replace('.', ',') if T['billed'] else ''),
           _pc(T['yield']), (_m(T['effective_rate']) + '/h') if T['effective_rate'] else '—', _hm(T['punched_seconds'])],
          ["Période précédente : " + _m(P.get('billed')), _m(P.get('cost')), _m(P.get('margin')), _pc(P.get('yield')),
           (_m(P.get('effective_rate')) + '/h') if P.get('effective_rate') else '—', _hm(P.get('punched_seconds', 0))]]
    t = Tb(kp, colWidths=[42 * k['mm']] * 6)
    t.setStyle(TS(k['base'] + [('FONTNAME', (0, 1), (-1, 1), 'Helvetica-Bold'), ('FONTSIZE', (0, 1), (-1, 1), 11), ('TEXTCOLOR', (0, 2), (-1, 2), C.HexColor('#6b7280')), ('FONTSIZE', (0, 2), (-1, 2), 7.5)]))
    story += [t, k['Spacer'](1, 4)]
    story.append(Pa(f"Temps punché au-delà du temps facturé (bons facturés) : <b>{_hm(T['lost_seconds'])}</b>, soit un coût de <b>{_m(T['lost_cost'])}</b>. "
                    f"Bons pas encore facturés : <b>{T['unbilled_jobs']}</b> ({_hm(T['unbilled_seconds'])}, coût de {_m(T['unbilled_cost'])}).", k['small']))
    story.append(Pa("Par mécanicien", k['h2']))
    rows = [["Mécanicien", "Bons", "H. punchées", "H. facturées", "Rendement", "Préc.", "Taux réel", "Coût", "Facturé", "Marge", "Marge %", "Dépassés"]]
    for m in r['mechanics']:
        pv = r.get('prev', {}).get('mechanics', {}).get(m['id'], {})
        rows.append([Pa(m['name'], k['cell']), m['jobs_count'], _hm(m['seconds']), _hm(m['billed_minutes'] * 60), _pc(m['yield']), _pc(pv.get('yield')),
                     (_m(m['real_rate']) + '/h') if m['real_rate'] else '—', _m(m['cost']), _m(m['billed']), _m(m['margin']), _pc(m['margin_pct']),
                     f"{m['over_count']} / {m['billed_count']}"])
    rows.append([Pa('<b>Atelier</b>', k['cell']), sum(m['jobs_count'] for m in r['mechanics']), _hm(T['punched_seconds']), _hm(T['billed_minutes'] * 60),
                 _pc(T['yield']), _pc(P.get('yield')), (_m(T['effective_rate']) + '/h') if T['effective_rate'] else '—',
                 _m(sum(m['cost'] for m in r['mechanics'])), _m(T['billed']), _m(T['margin']),
                 _pc(round(T['margin'] / T['billed'] * 100, 1) if T['billed'] else None), f"{sum(m['over_count'] for m in r['mechanics'])} / {sum(m['billed_count'] for m in r['mechanics'])}"])
    t = Tb(rows, colWidths=[44 * k['mm'], 13 * k['mm'], 21 * k['mm'], 21 * k['mm'], 19 * k['mm'], 15 * k['mm'], 22 * k['mm'], 22 * k['mm'], 22 * k['mm'], 22 * k['mm'], 16 * k['mm'], 18 * k['mm']], repeatRows=1)
    t.setStyle(TS(k['base'] + [('ALIGN', (1, 0), (-1, -1), 'RIGHT'), ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'), ('BACKGROUND', (0, -1), (-1, -1), C.HexColor('#dbe3f3'))]))
    story.append(t)
    worst = [j for j in r['jobs'] if j.get('margin') is not None][:15]
    if worst:
        story.append(Pa("Bons les moins rentables", k['h2']))
        rows = [["Bon", "Client / appareil", "Mécaniciens", "Temps passé", "Facturé (min)", "Écart", "Facturé", "Coût", "Marge"]]
        for j in worst:
            rows.append([j['job'], Pa(' — '.join(x for x in (j['client'], j['item']) if x) or '—', k['cell']), Pa(j['mechs'], k['cell']), _hm(j['seconds']),
                         f"{round(j['billed_minutes'] or 0)} min", _gap(j['gap_minutes']), _m(j['billed']), _m(j['cost']), _m(j['margin'])])
        t = Tb(rows, colWidths=[16 * k['mm'], 62 * k['mm'], 46 * k['mm'], 22 * k['mm'], 22 * k['mm'], 20 * k['mm'], 24 * k['mm'], 22 * k['mm'], 22 * k['mm']], repeatRows=1)
        t.setStyle(TS(k['base'] + [('ALIGN', (3, 0), (-1, -1), 'RIGHT')])); story.append(t)
    unb = [j for j in r['jobs'] if j.get('billed') is None][:20]
    if unb:
        story.append(Pa("Bons pas encore facturés", k['h2']))
        rows = [["Bon", "Client / appareil", "Mécaniciens", "Statut", "Temps passé", "Coût"]]
        for j in unb:
            rows.append([j['job'], Pa(' — '.join(x for x in (j['client'], j['item']) if x) or '—', k['cell']), Pa(j['mechs'], k['cell']), j['status'], _hm(j['seconds']), _m(j['cost'])])
        t = Tb(rows, colWidths=[16 * k['mm'], 80 * k['mm'], 60 * k['mm'], 26 * k['mm'], 24 * k['mm'], 24 * k['mm']], repeatRows=1)
        t.setStyle(TS(k['base'] + [('ALIGN', (4, 0), (-1, -1), 'RIGHT')])); story.append(t)
    story.append(_pdf_disclaimer())
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


def _at_shop_avg(r):
    ms = [m for m in r['mechanics'] if m['seconds'] >= 60] or r['mechanics']
    n = len(ms) or 1
    T = r['totals']
    return {'yield': T['yield'], 'real_rate': T['effective_rate'], 'jobs_count': round(sum(m['jobs_count'] for m in ms) / n, 1),
            'avg_job_seconds': sum(m['avg_job_seconds'] for m in ms) / n,
            'over_pct': round(sum(m['over_count'] for m in ms) / max(1, sum(m['billed_count'] for m in ms)) * 100),
            'problems': round(sum(m['problems'] for m in ms) / n, 1), 'corrections': round(sum(m['corrections'] for m in ms) / n, 1),
            'margin_pct': round(T['margin'] / T['billed'] * 100, 1) if T['billed'] else None}


def export_atelier_eval_pdf(r, mech_ids=None, show_cost=True, show_detail=True):
    k = _at_pdf_kit(); out = PDF_DIR / "Atelier"; out.mkdir(exist_ok=True)
    ms = [m for m in r['mechanics'] if not mech_ids or m['id'] in mech_ids]
    tag = 'tous' if not mech_ids or len(ms) != 1 else re.sub(r'[^A-Za-z0-9]+', '_', ms[0]['name'])
    path = out / f"Evaluation_{tag}_{r['start']}_au_{r['end']}.pdf"
    g = datetime.datetime.now()
    doc, header = _at_doc(path, k, "Fiche d'évaluation — performance en atelier", f"{_period_txt(r)} — généré le {g:%d-%m-%Y à %H:%M}")
    Tb, TS, Pa, C, mm = k['Table'], k['TableStyle'], k['Paragraph'], k['colors'], k['mm']
    avg = _at_shop_avg(r)
    from reportlab.platypus import KeepInFrame
    pw, ph = k['letter']
    story = []
    for idx, m in enumerate(ms):
        page_start = len(story)
        pv = r.get('prev', {}).get('mechanics', {}).get(m['id'], {})
        over_pct = round(m['over_count'] / m['billed_count'] * 100) if m['billed_count'] else None
        story.append(Pa(f"{m['name']}", k['h1']))
        story.append(Pa(f"{_period_txt(r)} · période précédente : du {_d(r['prev']['start'])} au {_d(r['prev']['end'])}", k['small']))
        story.append(k['Spacer'](1, 6))
        boxes = [["Heures punchées", "Heures facturées", "Rendement", "Taux horaire réel"],
                 [_hm(m['seconds']), _hm(m['billed_minutes'] * 60), _pc(m['yield']), (_m(m['real_rate']) + '/h') if m['real_rate'] else '—']]
        if show_cost:
            boxes += [["Coût du temps", "Main-d'œuvre facturée", "Marge", "Coût du temps dépassé"],
                      [_m(m['cost']), _m(m['billed']), f"{_m(m['margin'])} ({_pc(m['margin_pct'])})", _m(m['lost_cost'])]]
        t = Tb(boxes, colWidths=[45 * mm] * 4)
        st_ = [('FONTSIZE', (0, 0), (-1, -1), 8), ('ALIGN', (0, 0), (-1, -1), 'CENTER'), ('BOX', (0, 0), (-1, -1), .5, C.HexColor('#cbd5e1')),
               ('INNERGRID', (0, 0), (-1, -1), .25, C.HexColor('#e5e7eb')), ('TEXTCOLOR', (0, 0), (-1, 0), C.HexColor('#4b5563')),
               ('FONTNAME', (0, 1), (-1, 1), 'Helvetica-Bold'), ('FONTSIZE', (0, 1), (-1, 1), 13), ('TOPPADDING', (0, 1), (-1, 1), 6), ('BOTTOMPADDING', (0, 1), (-1, 1), 6)]
        if show_cost:
            st_ += [('TEXTCOLOR', (0, 2), (-1, 2), C.HexColor('#4b5563')), ('FONTNAME', (0, 3), (-1, 3), 'Helvetica-Bold'), ('FONTSIZE', (0, 3), (-1, 3), 11),
                    ('TOPPADDING', (0, 3), (-1, 3), 5), ('BOTTOMPADDING', (0, 3), (-1, 3), 5)]
        t.setStyle(TS(st_)); story += [t]
        story.append(Pa("Comparaison", k['h2']))
        num = lambda v: f"{v:g}".replace('.', ',')
        cmp = [["Indicateur", "Ce mécanicien", "Moyenne de l'atelier", "Période précédente", "Tendance"],
               ["Rendement (facturé ÷ punché)", _pc(m['yield']), _pc(avg['yield']), _pc(pv.get('yield')), _trend(m['yield'], pv.get('yield'), True, lambda v: f"{v:g} pts")],
               ["Taux horaire réel", (_m(m['real_rate']) + '/h') if m['real_rate'] else '—', (_m(avg['real_rate']) + '/h') if avg['real_rate'] else '—',
                (_m(pv.get('real_rate')) + '/h') if pv.get('real_rate') else '—', _trend(m['real_rate'], pv.get('real_rate'), True, _m)],
               ["Bons travaillés", m['jobs_count'], num(avg['jobs_count']), pv.get('jobs_count', '—'), _trend(m['jobs_count'], pv.get('jobs_count'), True, lambda v: f"{v:g}")],
               ["Temps moyen par bon", _hm(m['avg_job_seconds']), _hm(avg['avg_job_seconds']), '—', ''],
               ["Bons dépassant le temps facturé (+15 min)", f"{m['over_count']} / {m['billed_count']}" + (f" ({over_pct} %)" if over_pct is not None else ''), f"{avg['over_pct']} %", '—', ''],
               ["Problèmes signalés", m['problems'], num(avg['problems']), '—', ''],
               ["Punchs corrigés par un gestionnaire", m['corrections'], num(avg['corrections']), '—', '']]
        if show_cost:
            cmp.insert(3, ["Marge sur la main-d'œuvre", _pc(m['margin_pct']), _pc(avg['margin_pct']), '—', ''])
        t = Tb(cmp, colWidths=[62 * mm, 30 * mm, 32 * mm, 30 * mm, 26 * mm])
        t.setStyle(TS(k['base'] + [('ALIGN', (1, 0), (-1, -1), 'CENTER')])); story.append(t)
        obs = []
        if m['yield'] is not None:
            obs.append(f"Rendement {'au-dessus' if m['yield'] >= 100 else 'sous'} du temps facturé ({_pc(m['yield'])}" + (f", moyenne de l'atelier {_pc(avg['yield'])})." if avg['yield'] else ")."))
        if over_pct is not None and over_pct >= 30:
            obs.append(f"{m['over_count']} bon(s) sur {m['billed_count']} dépassent le temps facturé de plus de 15 minutes : à revoir (estimation, pièces, méthode).")
        if m['corrections'] >= 3:
            obs.append(f"{m['corrections']} punch(s) ont dû être corrigés : rappeler l'importance de puncher au début et à la fin.")
        if m['unbilled_count']:
            obs.append(f"{m['unbilled_count']} bon(s) travaillé(s) pas encore facturé(s) : ils ne comptent pas dans le rendement.")
        if obs:
            story.append(Pa("Observations automatiques (à valider par le responsable)", k['h2']))
            for o in obs:
                story.append(Pa('• ' + o, k['small']))
        if show_detail and m['jobs']:
            story.append(Pa("Bons avec le plus grand écart", k['h2']))
            hd = ["Bon", "Client / appareil", "Temps passé", "Temps facturé", "Écart"] + (["Marge"] if show_cost else [])
            rows = [hd]
            for j in [x for x in m['jobs'] if x['gap_minutes'] is not None][:5]:
                rows.append([j['job'] + (' *' if j['shared'] else ''), Pa(' — '.join(x for x in (j['client'], j['item']) if x) or '—', k['cell']), _hm(j['seconds']),
                             f"{round(j['billed_minutes'] or 0)} min", _gap(j['gap_minutes'])] + ([_m(j['margin'])] if show_cost else []))
            if len(rows) > 1:
                cw = [16 * mm, (74 if show_cost else 98) * mm, 24 * mm, 24 * mm, 22 * mm] + ([24 * mm] if show_cost else [])
                t = Tb(rows, colWidths=cw, repeatRows=1); t.setStyle(TS(k['base'] + [('ALIGN', (2, 0), (-1, -1), 'RIGHT')])); story.append(t)
                story.append(Pa("* bon partagé avec un autre mécanicien : le temps facturé est réparti selon le temps de chacun.", k['small']))
        story.append(Pa("Commentaires du responsable", k['h2']))
        lines = Tb([[''] for _ in range(3)], colWidths=[180 * mm], rowHeights=[7 * mm] * 3)
        lines.setStyle(TS([('LINEBELOW', (0, 0), (-1, -1), .5, C.HexColor('#9ca3af'))])); story.append(lines)
        sig = Tb([["Signature du responsable", "", "Signature de l'employé", "", "Date"], ["", "", "", "", ""]], colWidths=[52 * mm, 8 * mm, 52 * mm, 8 * mm, 60 * mm], rowHeights=[6 * mm, 12 * mm])
        sig.setStyle(TS([('FONTSIZE', (0, 0), (-1, -1), 8), ('TEXTCOLOR', (0, 0), (-1, 0), C.HexColor('#4b5563')),
                         ('LINEBELOW', (0, 1), (0, 1), .5, C.black), ('LINEBELOW', (2, 1), (2, 1), .5, C.black), ('LINEBELOW', (4, 1), (4, 1), .5, C.black)]))
        story += [k['Spacer'](1, 4), sig, _pdf_disclaimer(10, 6.5)]
        parts = []
        for f_ in story[page_start:]:                               # KeepInFrame n'accepte pas les KeepTogether
            parts.extend(getattr(f_, '_content', None) or [f_])
        del story[page_start:]                                      # une page par mécanicien : réduit au besoin
        story.append(KeepInFrame(pw - 28 * mm - 2, ph - 44 * mm - 6, parts, mode='shrink'))
        if idx < len(ms) - 1:
            story.append(k['PageBreak']())
    if not ms:
        story.append(Pa("Aucun temps punché pour ce mécanicien dans la période.", k['small']))
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


# ============================================================
# Gestion RH (1.30.0) — dossiers des employés
# ------------------------------------------------------------
# Renseignements personnels : permission « rh » obligatoire, chaque consultation est
# notée (hr_access_log). Ne jamais y mettre de NAS, de renseignements bancaires ou
# médicaux. Les documents sont gardés dans Dossiers_RH\<employé>\ et inclus dans
# les sauvegardes complètes.
# ============================================================
HR_DIR = BASE_DIR / "Dossiers_RH"
HR_DOC_EXT = {'.pdf', '.png', '.jpg', '.jpeg', '.webp', '.docx', '.xlsx', '.txt'}
HR_DOC_MAX = 15 * 1024 * 1024
HR_DOC_CATS = {'contrat': 'Contrat / embauche', 'formation': 'Formation', 'certification': 'Certification', 'evaluation': 'Évaluation',
               'evaluation_atelier': "Fiche d'évaluation (atelier)", 'autre': 'Autre'}
HR_NOTE_KINDS = {'felicitation': 'Félicitation', 'rencontre': 'Rencontre', 'avertissement': 'Avertissement', 'note': 'Note'}
HR_STATUS = {'actif': 'Actif', 'probation': 'En probation', 'conge': 'En congé', 'inactif': 'Inactif (parti)'}
HR_SCALE = {1: 'Insatisfaisant', 2: 'À améliorer', 3: 'Répond aux attentes', 4: 'Dépasse les attentes', 5: 'Exceptionnel'}
HR_CRITERIA = [
    ('service', 'Service à la clientèle', "Accueil, écoute, conseils justes, suivi des demandes et des plaintes."),
    ('produits', 'Connaissance des produits et de la location', "Outils, équipement de location, accessoires, conditions de location."),
    ('qualite', 'Qualité du travail', "Minutie, inspection de l'équipement retourné, entretien, propreté du magasin et des aires de travail."),
    ('securite', 'Sécurité', "Port des ÉPI, procédures sécuritaires, démonstration sécuritaire de l'équipement aux clients."),
    ('procedures', 'Respect des procédures', "Caisse, contrats de location, dépôts, inventaire, documents."),
    ('productivite', 'Productivité et gestion du temps', "Volume de travail, priorités, respect des délais."),
    ('fiabilite', 'Fiabilité et ponctualité', "Assiduité, présence, respect de l'horaire."),
    ('equipe', 'Travail d\u2019équipe et communication', "Collaboration, entraide, communication avec les collègues et la direction."),
    ('initiative', 'Initiative et autonomie', "Prendre les devants, proposer des améliorations, apprendre."),
]


def hr_allowed():
    return bool(session.get('is_admin')) or 'rh' in (session.get('permissions') or [])


def hr_log(conn, emp_id, action):
    conn.execute("INSERT INTO hr_access_log(ts, username, employee_id, action, ip) VALUES (?,?,?,?,?)",
                 (_at_now(), session.get('username') or '?', emp_id, action, client_ip()))


def hr_emp_name(e):
    return f"{e['first_name'] or ''} {e['last_name'] or ''}".strip()


def hr_reminders(conn):
    t = datetime.date.today(); soon = (t + datetime.timedelta(days=30)).isoformat(); ti = t.isoformat()
    out = []
    for r in conn.execute("SELECT d.*, e.first_name, e.last_name FROM hr_documents d JOIN hr_employees e ON e.id=d.employee_id "
                          "WHERE d.expires_on IS NOT NULL AND d.expires_on<>'' AND d.expires_on<=? AND e.status<>'inactif' ORDER BY d.expires_on", (soon,)).fetchall():
        out.append({'employee_id': r['employee_id'], 'name': hr_emp_name(r), 'date': r['expires_on'], 'late': r['expires_on'] < ti,
                    'text': ('Certification expirée : ' if r['expires_on'] < ti else 'Certification à renouveler : ') + (r['title'] or '')})
    for r in conn.execute("SELECT * FROM hr_employees WHERE status='probation' AND probation_end IS NOT NULL AND probation_end<>'' AND probation_end<=?", (soon,)).fetchall():
        out.append({'employee_id': r['id'], 'name': hr_emp_name(r), 'date': r['probation_end'], 'late': r['probation_end'] < ti, 'text': 'Fin de la probation'})
    for r in conn.execute("SELECT * FROM hr_employees WHERE status<>'inactif' AND next_review IS NOT NULL AND next_review<>'' AND next_review<=?", (soon,)).fetchall():
        out.append({'employee_id': r['id'], 'name': hr_emp_name(r), 'date': r['next_review'], 'late': r['next_review'] < ti, 'text': 'Évaluation à faire'})
    for r in conn.execute("SELECT v.*, e.first_name, e.last_name FROM hr_evaluations v JOIN hr_employees e ON e.id=v.employee_id WHERE v.status='brouillon'").fetchall():
        out.append({'employee_id': r['employee_id'], 'name': hr_emp_name(r), 'date': r['eval_date'] or '', 'late': False, 'text': 'Évaluation en brouillon à terminer'})
    out.sort(key=lambda x: x['date'] or '9999')
    return out


def hr_store_file(emp_id, data, original, category, title, expires=None, username=None, conn=None):
    ext = Path(original).suffix.lower()
    d = HR_DIR / str(emp_id); d.mkdir(parents=True, exist_ok=True)
    fname = f"{datetime.datetime.now():%Y%m%d_%H%M%S}_{secrets.token_hex(4)}{ext}"
    (d / fname).write_bytes(data)
    own = conn is None
    conn = conn or get_conn()
    try:
        cur = conn.execute("INSERT INTO hr_documents(employee_id, category, title, filename, original_name, size, expires_on, created_at, created_by) "
                           "VALUES (?,?,?,?,?,?,?,?,?)", (emp_id, category, title[:200], fname, Path(original).name[:200], len(data), expires or None,
                                                          _at_now(), username or session.get('username') or '?'))
        if own:
            conn.commit()
        return cur.lastrowid
    finally:
        if own:
            conn.close()


def hr_atelier_stats(emp, d0, d1):
    """Statistiques d'atelier de la période pour un employé relié à un mécanicien (sans coûts)."""
    if not emp['mechanic_id']:
        return None
    r = at_profit({'start': d0, 'end': d1})
    m = next((x for x in r['mechanics'] if x['id'] == emp['mechanic_id']), None)
    if not m:
        return {'jobs_count': 0}
    return {k: m[k] for k in ('jobs_count', 'done_count', 'seconds', 'billed_minutes', 'yield', 'real_rate', 'over_count', 'billed_count',
                              'problems', 'corrections')} | {'shop_yield': r['totals']['yield']}


def export_hr_eval_pdf(emp, ev):
    k = _at_pdf_kit(); Tb, TS, Pa, C, mm = k['Table'], k['TableStyle'], k['Paragraph'], k['colors'], k['mm']
    d = HR_DIR / str(emp['id']); d.mkdir(parents=True, exist_ok=True)
    path = d / f"_apercu_evaluation_{ev['id']}.pdf"
    per = f"Du {_d(ev['period_start'])} au {_d(ev['period_end'])}" if ev['period_start'] and ev['period_end'] else ''
    doc, header = _at_doc(path, k, "Évaluation du rendement", f"{hr_emp_name(emp)} · {emp['position'] or ''} · {per}")
    scores = json.loads(ev['scores'] or '{}')
    story = [Pa(hr_emp_name(emp), k['h1']),
             Pa(f"Poste : <b>{emp['position'] or '—'}</b> · Embauché le {_d(emp['hire_date']) if emp['hire_date'] else '—'} · "
                f"Évaluation du {_d(ev['eval_date']) if ev['eval_date'] else '—'} · Évaluateur : <b>{ev['evaluator'] or '—'}</b>", k['small']),
             Pa(f"Période évaluée : {per or '—'}", k['small']), k['Spacer'](1, 6)]
    rows = [["Critère", "Note", "Appréciation", "Commentaire"]]
    crit = json.loads(ev.get('criteria') or 'null') or [{'key': c['key'], 'label': c['label'], 'hint': c['hint']} for c in hr_criteria()]
    for c in crit:
        sc = scores.get(c['key']) or {}
        v = sc.get('score')
        rows.append([Pa(f"<b>{c['label']}</b><br/><font size=7 color='#6b7280'>{c['hint']}</font>", k['cell']), f"{v} / 5" if v else ('S.O.' if sc.get('na') else '—'),
                     HR_SCALE.get(int(v), '') if v else ('Ne s’applique pas' if sc.get('na') else ''), Pa((sc.get('comment') or '').replace('<', '&lt;'), k['cell'])])
    rows.append([Pa('<b>Moyenne générale</b>', k['cell']), f"{ev['overall']:.1f} / 5".replace('.', ',') if ev['overall'] else '—',
                 HR_SCALE.get(int(round(ev['overall'])), '') if ev['overall'] else '', ''])
    t = Tb(rows, colWidths=[70 * mm, 16 * mm, 34 * mm, 66 * mm], repeatRows=1)
    t.setStyle(TS(k['base'] + [('ALIGN', (1, 0), (1, -1), 'CENTER'), ('VALIGN', (0, 1), (-1, -1), 'TOP'),
                               ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'), ('BACKGROUND', (0, -1), (-1, -1), C.HexColor('#dbe3f3'))]))
    story.append(t)
    st = json.loads(ev['atelier_stats'] or 'null')
    if st and st.get('jobs_count'):
        story.append(Pa("Statistiques d'atelier de la période", k['h2']))
        rows = [["Bons travaillés", "Heures punchées", "Rendement", "Moy. atelier", "Dépassés +15 min", "Problèmes", "Punchs corrigés"],
                [f"{st['jobs_count']} ({st.get('done_count', 0)} terminés)", _hm(st.get('seconds', 0)), _pc(st.get('yield')), _pc(st.get('shop_yield')),
                 f"{st.get('over_count', 0)} / {st.get('billed_count', 0)}", st.get('problems', 0), st.get('corrections', 0)]]
        t = Tb(rows, colWidths=[30 * mm, 24 * mm, 22 * mm, 26 * mm, 30 * mm, 26 * mm, 26 * mm]); t.setStyle(TS(k['base'] + [('ALIGN', (0, 0), (-1, -1), 'CENTER')])); story.append(t)
    for title, val in (("Points forts", ev['strengths']), ("Points à améliorer", ev['improvements']), ("Objectifs pour la prochaine période", ev['objectives']),
                       ("Commentaires de l'employé", ev['employee_comments'])):
        story.append(Pa(title, k['h2']))
        story.append(Pa((val or '—').replace('<', '&lt;').replace('\n', '<br/>'), k['cell']))
    sig = Tb([["Signature de l'évaluateur", "", "Signature de l'employé", "", "Date"], ["", "", "", "", ""]],
             colWidths=[52 * mm, 8 * mm, 52 * mm, 8 * mm, 60 * mm], rowHeights=[6 * mm, 12 * mm])
    sig.setStyle(TS([('FONTSIZE', (0, 0), (-1, -1), 8), ('TEXTCOLOR', (0, 0), (-1, 0), C.HexColor('#4b5563')),
                     ('LINEBELOW', (0, 1), (0, 1), .5, C.black), ('LINEBELOW', (2, 1), (2, 1), .5, C.black), ('LINEBELOW', (4, 1), (4, 1), .5, C.black)]))
    story += [k['Spacer'](1, 10), Pa("La signature de l'employé confirme qu'il a pris connaissance de l'évaluation, pas nécessairement qu'il est d'accord.", k['small']),
              k['Spacer'](1, 4), sig]
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


# ---------- Administration RH : critères et modèles de documents (1.31.0) ----------
HR_DOC_CATS.update({'disciplinaire': 'Mesure disciplinaire', 'lettre': 'Lettre / document créé'})
HR_TEMPLATES = {
    'avertissement': {'title': 'Avertissement écrit', 'category': 'disciplinaire', 'note_kind': 'avertissement', 'employee_sign': True, 'witness': True,
                      'ack': "En signant ce document, l'employé confirme l'avoir reçu et en avoir pris connaissance. Sa signature ne signifie pas qu'il est d'accord avec son contenu. Il peut inscrire ses commentaires ci-dessous.",
                      'sections': [('objet', 'Objet (motif de l\u2019avertissement)', '', 1),
                                   ('faits', 'Description des faits', '', 5),
                                   ('attentes', 'Attentes et mesures correctives', "Nous nous attendons à ce que la situation soit corrigée immédiatement et de façon durable. N'hésite pas à demander de l'aide à ton responsable au besoin.", 4),
                                   ('consequences', 'Conséquences en cas de récidive', "Tout nouveau manquement de même nature, ou tout autre manquement, pourrait entraîner des mesures disciplinaires plus sévères, pouvant aller jusqu'au congédiement.", 3)]},
    'felicitation': {'title': 'Lettre de reconnaissance', 'category': 'lettre', 'note_kind': 'felicitation', 'employee_sign': False, 'witness': False, 'ack': '',
                     'sections': [('objet', 'Objet', '', 1),
                                  ('texte', 'Message', "Nous tenons à souligner ton excellent travail et ton engagement envers l'entreprise et nos clients. Merci !", 6)]},
    'rencontre': {'title': 'Compte rendu de rencontre', 'category': 'lettre', 'note_kind': 'rencontre', 'employee_sign': True, 'witness': False,
                  'ack': "Les signatures confirment que la rencontre a eu lieu et que le compte rendu a été remis à l'employé.",
                  'sections': [('objet', 'Objet de la rencontre', '', 1), ('presents', 'Personnes présentes', '', 1),
                               ('points', 'Points discutés', '', 5), ('suivis', 'Décisions et suivis', '', 4)]},
    'attestation': {'title': "Attestation d'emploi", 'category': 'lettre', 'note_kind': 'note', 'employee_sign': False, 'witness': False, 'ack': '',
                    'sections': [('texte', 'Texte de l\u2019attestation', "Nous attestons que {nom} est à l'emploi de {entreprise} depuis le {embauche}, au poste de {poste}.", 4),
                                 ('ajout', 'Précisions (facultatif)', '', 2)]},
}


def hr_criteria(active_only=True):
    try:
        saved = json.loads(meta_get('hr_criteria') or 'null')
    except ValueError:
        saved = None
    lst = saved if isinstance(saved, list) and saved else [{'key': k, 'label': l, 'hint': h, 'active': True} for k, l, h in HR_CRITERIA]
    return [c for c in lst if c.get('active', True)] if active_only else lst


def hr_templates():
    try:
        ov = json.loads(meta_get('hr_doc_templates') or '{}')
    except ValueError:
        ov = {}
    out = {}
    for t, tpl in HR_TEMPLATES.items():
        o = ov.get(t, {})
        out[t] = {'title': tpl['title'], 'employee_sign': tpl['employee_sign'], 'witness': tpl['witness'], 'ack': o.get('ack', tpl['ack']),
                  'sections': [{'key': k, 'label': l, 'default': (o.get('defaults') or {}).get(k, d), 'rows': r} for k, l, d, r in tpl['sections']]}
    return out


def export_hr_letter_pdf(emp, ttype, doc_date, fields, author, path):
    """Document RH créé à partir d'un modèle (avertissement, reconnaissance, rencontre, attestation)."""
    k = _at_pdf_kit(); Tb, TS, Pa, C, mm = k['Table'], k['TableStyle'], k['Paragraph'], k['colors'], k['mm']
    tpl = hr_templates()[ttype]
    doc, header = _at_doc(path, k, tpl['title'], f"{hr_emp_name(emp)} · {_d(doc_date)}")
    esc_ = lambda t: (t or '').replace('&', '&amp;').replace('<', '&lt;').replace('\n', '<br/>')
    body = k['cell'].clone('body', fontSize=10, leading=14)
    story = [Pa(tpl['title'], k['h1']), k['Spacer'](1, 6)]
    info = Tb([["Employé", hr_emp_name(emp), "Date", _d(doc_date)],
               ["Poste", emp['position'] or '—', "Embauché le", _d(emp['hire_date']) if emp['hire_date'] else '—']], colWidths=[24 * mm, 70 * mm, 26 * mm, 66 * mm])
    info.setStyle(TS([('FONTSIZE', (0, 0), (-1, -1), 9), ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'), ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
                      ('BOX', (0, 0), (-1, -1), .5, C.HexColor('#cbd5e1')), ('INNERGRID', (0, 0), (-1, -1), .25, C.HexColor('#e5e7eb')),
                      ('BACKGROUND', (0, 0), (0, -1), C.HexColor('#f1f5f9')), ('BACKGROUND', (2, 0), (2, -1), C.HexColor('#f1f5f9'))]))
    story += [info, k['Spacer'](1, 6)]
    for s in tpl['sections']:
        v = (fields.get(s['key']) or '').strip()
        if not v:
            continue
        story.append(Pa(s['label'], k['h2'])); story.append(Pa(esc_(v), body))
    if tpl['employee_sign']:
        if tpl['ack']:
            story += [k['Spacer'](1, 6), Pa(tpl['ack'], k['small'])]
        story.append(Pa("Commentaires de l'employé", k['h2']))
        cm = (fields.get('commentaires') or '').strip()
        if cm:
            story.append(Pa(esc_(cm), body))
        else:
            lines = Tb([[''] for _ in range(3)], colWidths=[180 * mm], rowHeights=[7 * mm] * 3)
            lines.setStyle(TS([('LINEBELOW', (0, 0), (-1, -1), .5, C.HexColor('#9ca3af'))])); story.append(lines)
    if tpl['ack'] and not tpl['employee_sign']:
        story += [k['Spacer'](1, 8), Pa(tpl['ack'], k['small'])]
    cols = [("Signature du responsable", author)] + ([("Signature de l'employé", hr_emp_name(emp))] if tpl['employee_sign'] else []) + ([("Signature du témoin", '')] if tpl['witness'] else [])
    n = len(cols); gap = 10; w = (180 - gap * (n - 1)) / n           # une colonne vide entre chaque signature
    grid = lambda vals: sum(([v, ''] for v in vals), [])[:-1]
    widths = sum(([w * mm, gap * mm] for _ in cols), [])[:-1]
    sig = Tb([grid([c[0] for c in cols]), grid(['' for _ in cols]), grid([c[1] for c in cols]), grid(["Date : ______________" for _ in cols])],
             colWidths=widths, rowHeights=[6 * mm, 14 * mm, 5 * mm, 6 * mm])
    st_ = [('FONTSIZE', (0, 0), (-1, -1), 8), ('TEXTCOLOR', (0, 0), (-1, 0), C.HexColor('#4b5563')), ('TEXTCOLOR', (0, 2), (-1, 2), C.HexColor('#111827')),
           ('LEFTPADDING', (0, 0), (-1, -1), 0)]
    st_ += [('LINEBELOW', (2 * i, 1), (2 * i, 1), .5, C.black) for i in range(n)]
    sig.setStyle(TS(st_))
    story += [k['Spacer'](1, 14), sig]
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


# ============================================================
# Portail employé, signatures et punch de présence (1.39.0) — module RH de la licence
# ============================================================
TC_COOKIE = 'kubios_poste_presence'
TC_MAX_AGE = 400 * 24 * 3600
TC_BREAK_PAID_MAX = 15 * 60          # pause de 15 min ou moins : payée ; plus longue (dîner) : déduite au complet
TC_OT_WEEK = 40 * 3600               # heures supplémentaires au-delà de 40 h / semaine
TC_KINDS = {'in': 'Entrée', 'break_start': 'Début de pause', 'break_end': 'Retour de pause', 'out': 'Sortie'}
_tc_fail = {}


def tc_settings():
    period = meta_get('tc_period') or 'week'
    try:
        anchor = datetime.date.fromisoformat(meta_get('tc_anchor') or '2026-01-05')
    except ValueError:
        anchor = datetime.date(2026, 1, 5)
    anchor -= datetime.timedelta(days=anchor.weekday())       # toujours un lundi
    return {'period': period if period in ('week', '2weeks') else 'week', 'anchor': anchor}


def tc_period_of(d):
    """(début, fin) de la période de paie qui contient la date d (semaines du lundi au dimanche)."""
    st = tc_settings()
    monday = d - datetime.timedelta(days=d.weekday())
    if st['period'] == 'week':
        return monday, monday + datetime.timedelta(days=6)
    n = (monday - st['anchor']).days // 14
    start = st['anchor'] + datetime.timedelta(days=14 * n)
    return start, start + datetime.timedelta(days=13)


def _tc_dt(s):
    return datetime.datetime.strptime(s, AT_FMT)


def tc_events(conn, emp_id, d0, d1):
    a = (datetime.datetime.combine(d0, datetime.time(0)) - datetime.timedelta(hours=14)).strftime(AT_FMT)
    b = datetime.datetime.combine(d1 + datetime.timedelta(days=1), datetime.time(0)).strftime(AT_FMT)
    return [dict(r) for r in conn.execute("SELECT * FROM tc_events WHERE employee_id=? AND deleted=0 AND ts>=? AND ts<? ORDER BY ts, id",
                                          (emp_id, a, b)).fetchall()]


def tc_days(events, d0, d1, now=None):
    """Calcule chaque journée : heures travaillées (pauses ≤ 15 min payées, plus longues déduites), pauses, oublis."""
    now = now or datetime.datetime.now()
    days = {}
    def day(d):
        return days.setdefault(d, {'date': d.isoformat(), 'worked': 0.0, 'paid_breaks': 0.0, 'unpaid_breaks': 0.0,
                                   'first_in': None, 'last_out': None, 'open': False, 'missing_out': False, 'state': 'out'})
    cur = None
    def close(end, missing=False):
        nonlocal cur
        dd = day(cur['start'].date())
        if cur['break_open']:
            cur['breaks'].append((cur['break_open'], end)); cur['break_open'] = None
        if missing:
            dd['missing_out'] = True
        else:
            span = (end - cur['start']).total_seconds()
            unpaid = sum((b - a).total_seconds() for a, b in cur['breaks'] if (b - a).total_seconds() > TC_BREAK_PAID_MAX)
            paid = sum((b - a).total_seconds() for a, b in cur['breaks'] if (b - a).total_seconds() <= TC_BREAK_PAID_MAX)
            dd['worked'] += max(0.0, span - unpaid); dd['paid_breaks'] += paid; dd['unpaid_breaks'] += unpaid
            dd['last_out'] = end.strftime('%H:%M')
        cur = None
    for e in events:
        t = _tc_dt(e['ts']); k = e['kind']
        if k == 'in':
            if cur:
                close(t, missing=True)
            cur = {'start': t, 'breaks': [], 'break_open': None}
            dd = day(t.date())
            dd['first_in'] = dd['first_in'] or t.strftime('%H:%M')
        elif k == 'break_start' and cur and not cur['break_open']:
            cur['break_open'] = t
        elif k == 'break_end' and cur and cur['break_open']:
            cur['breaks'].append((cur['break_open'], t)); cur['break_open'] = None
        elif k == 'out' and cur:
            close(t)
    if cur:
        dd = day(cur['start'].date())
        if cur['start'].date() == now.date():         # quart en cours : compté jusqu'à maintenant
            on_break = cur['break_open'] is not None
            brk = list(cur['breaks']) + ([(cur['break_open'], now)] if on_break else [])
            span = (now - cur['start']).total_seconds()
            unpaid = sum((b - a).total_seconds() for a, b in brk if (b - a).total_seconds() > TC_BREAK_PAID_MAX)
            dd['worked'] += max(0.0, span - unpaid); dd['open'] = True; dd['state'] = 'break' if on_break else 'in'
            dd['since'] = (cur['break_open'] or cur['start']).strftime('%H:%M')
        else:
            dd['missing_out'] = True
    out, d = [], d0
    while d <= d1:
        x = days.get(d) or day(d)
        out.append(x); d += datetime.timedelta(days=1)
    return out


def tc_sheet(conn, emp_id, d0, d1):
    days = tc_days(tc_events(conn, emp_id, d0, d1), d0, d1)
    weeks, ot = [], 0.0
    for i in range(0, len(days), 7):
        w = sum(x['worked'] for x in days[i:i + 7]); weeks.append(w); ot += max(0.0, w - TC_OT_WEEK)
    total = sum(x['worked'] for x in days)
    return {'days': days, 'total': total, 'overtime': ot, 'regular': total - ot, 'weeks': weeks,
            'missing': sum(1 for x in days if x['missing_out'])}


def tc_state(conn, emp_id):
    today = datetime.date.today()
    d = tc_days(tc_events(conn, emp_id, today, today), today, today)[0]
    w0, w1 = today - datetime.timedelta(days=today.weekday()), today
    week = sum(x['worked'] for x in tc_days(tc_events(conn, emp_id, w0, w1), w0, w1))
    last = conn.execute("SELECT kind, ts FROM tc_events WHERE employee_id=? AND deleted=0 ORDER BY ts DESC, id DESC LIMIT 1", (emp_id,)).fetchone()
    state = d['state'] if d['open'] else ('done' if d['last_out'] else 'out')
    return {'state': state, 'since': d.get('since'), 'first_in': d['first_in'], 'last_out': d['last_out'], 'today': d['worked'], 'week': week,
            'last_kind': last['kind'] if last else None}


def tc_allowed():
    if session.get('user_id') and (session.get('is_admin') or {'rh', 'punch_presence'} & set(session.get('permissions') or [])):
        return True
    raw = request.cookies.get(TC_COOKIE)
    if not raw:
        return False
    try:
        from itsdangerous import URLSafeTimedSerializer
        data = URLSafeTimedSerializer(app.secret_key, salt='kubios-poste-presence').loads(raw, max_age=TC_MAX_AGE)
    except Exception:
        return False
    return secrets.compare_digest(str(data.get('v', '')), tc_secret())


def tc_secret():
    s = meta_get('tc_secret')
    if not s:
        s = secrets.token_urlsafe(16); meta_set('tc_secret', s)
    return s


def tc_link_token():
    t = meta_get('tc_link_token')
    if not t:
        t = secrets.token_urlsafe(24); meta_set('tc_link_token', t)
    return t


def tc_authorize(resp):
    from itsdangerous import URLSafeTimedSerializer
    resp.set_cookie(TC_COOKIE, URLSafeTimedSerializer(app.secret_key, salt='kubios-poste-presence').dumps({'v': tc_secret()}),
                    max_age=TC_MAX_AGE, httponly=True, samesite='Lax', secure=request.is_secure)
    return resp


def hm_txt(sec):
    m = int(round((sec or 0) / 60)); return f"{m // 60} h {m % 60:02d}"


def tc_day_details(r):
    """Une ligne par journée avec du prévu ou du punché : prévu, entrée, sortie, pauses, dîner, heures, remarques."""
    out = []
    for x in r['sheet']['days']:
        evs = [e for e in r.get('events', []) if e['ts'][:10] == x['date']]
        if not (x['worked'] or x['missing_out'] or x.get('sched') or evs):
            continue
        rem = []
        if x.get('absent'):
            rem.append('ABSENT (horaire prévu, aucun punch)')
        if x.get('late'):
            rem.append(f"Retard {x['late']} min")
        if x['missing_out']:
            rem.append('Sortie manquante')
        for e in evs:
            if e.get('corrected_by'):
                rem.append(f"{TC_KINDS.get(e['kind'], e['kind'])} {e['ts'][11:16]} corrigé(e) par {e['corrected_by']}" + (f" — {e['note']}" if e.get('note') else ''))
        d = datetime.date.fromisoformat(x['date'])
        out.append({'date': x['date'], 'jour': f"{JOURS_CRT[d.weekday()]} {d.day}", 'prevu': x.get('sched') or '—',
                    'entree': x['first_in'] or '—', 'sortie': ('en cours' if x['open'] else (x['last_out'] or '—')),
                    'pauses': round(x['paid_breaks'] / 60), 'diner': round(x['unpaid_breaks'] / 60), 'heures': x['worked'], 'remarques': rem})
    return out


def export_tc_xlsx(rows, d0, d1, path):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    wb = Workbook(); ws = wb.active; ws.title = "Feuille de temps"
    days = [d0 + datetime.timedelta(days=i) for i in range((d1 - d0).days + 1)]
    J = ('Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim')
    ws['A1'] = f"{get_company_name()} — Feuille de temps"; ws['A1'].font = Font(bold=True, size=14)
    ws['A2'] = f"Période du {_d(d0.isoformat())} au {_d(d1.isoformat())} — heures en format décimal (ex. 7,50 = 7 h 30) — pauses de 15 min ou moins payées, dîner déduit — heures sup. au-delà de 40 h par semaine"
    ws['A2'].font = Font(italic=True, size=9, color='555555')
    head = ['Employé', 'Poste'] + [f"{J[d.weekday()]} {d.day}" for d in days] + ['Heures régulières', 'Heures sup.', 'Total', 'Approuvée']
    ws.append([]); ws.append(head)
    hdr = ws.max_row
    thin = Side(style='thin', color='CCCCCC')
    for c in ws[hdr]:
        c.font = Font(bold=True, color='FFFFFF'); c.fill = PatternFill('solid', fgColor='1E3A8A'); c.alignment = Alignment(horizontal='center', wrap_text=True)
    for r in rows:
        vals = [r['name'], r['position'] or ''] + [round(x['worked'] / 3600, 2) if x['worked'] else None for x in r['sheet']['days']] + \
               [round(r['sheet']['regular'] / 3600, 2), round(r['sheet']['overtime'] / 3600, 2), round(r['sheet']['total'] / 3600, 2), 'Oui' if r['approved'] else 'Non']
        ws.append(vals)
        for i, x in enumerate(r['sheet']['days']):
            if x['missing_out']:
                c = ws.cell(row=ws.max_row, column=3 + i); c.fill = PatternFill('solid', fgColor='FDE68A'); c.value = 'Sortie manquante'
    last = ws.max_row
    ws.append(['TOTAL', ''] + [None] * len(days) + [f"=SUM({col}{hdr + 1}:{col}{last})" for col in
                                                     [ws.cell(row=hdr, column=3 + len(days) + k).column_letter for k in range(3)]] + [''])
    for c in ws[ws.max_row]:
        c.font = Font(bold=True); c.fill = PatternFill('solid', fgColor='DBE3F3')
    for row in ws.iter_rows(min_row=hdr, max_row=ws.max_row):
        for c in row:
            c.border = Border(top=thin, bottom=thin, left=thin, right=thin)
            if c.column > 2 and c.row > hdr and isinstance(c.value, (int, float)):
                c.number_format = '0.00'
    ws.column_dimensions['A'].width = 24; ws.column_dimensions['B'].width = 22
    for k in range(len(days) + 4):
        ws.column_dimensions[ws.cell(row=hdr, column=3 + k).column_letter].width = 11
    ws.freeze_panes = ws.cell(row=hdr + 1, column=3)
    ws3 = wb.create_sheet("Détail par jour")
    ws3.append(['Employé', 'Date', 'Prévu (horaire)', 'Entrée', 'Sortie', 'Pauses payées (min)', 'Dîner déduit (min)', 'Heures', 'Remarques'])
    for c in ws3[1]:
        c.font = Font(bold=True, color='FFFFFF'); c.fill = PatternFill('solid', fgColor='1E3A8A'); c.alignment = Alignment(wrap_text=True, vertical='center')
    for r in rows:
        for dl in tc_day_details(r):
            ws3.append([r['name'], dl['date'], dl['prevu'], dl['entree'], dl['sortie'], dl['pauses'] or None, dl['diner'] or None,
                        round(dl['heures'] / 3600, 2) if dl['heures'] else None, ' ; '.join(dl['remarques'])])
            if dl['remarques']:
                ws3.cell(row=ws3.max_row, column=9).fill = PatternFill('solid', fgColor='FEF3C7')
            ws3.cell(row=ws3.max_row, column=8).number_format = '0.00'
    for col, w in zip('ABCDEFGHI', (24, 12, 26, 9, 9, 12, 12, 9, 70)):
        ws3.column_dimensions[col].width = w
    ws3.freeze_panes = 'B2'
    ws2 = wb.create_sheet("Détail des punchs")
    ws2.append(['Employé', 'Date', 'Heure', 'Punch', 'Note / correction'])
    for c in ws2[1]:
        c.font = Font(bold=True, color='FFFFFF'); c.fill = PatternFill('solid', fgColor='1E3A8A')
    for r in rows:
        for e in r['events']:
            ws2.append([r['name'], e['ts'][:10], e['ts'][11:16], TC_KINDS.get(e['kind'], e['kind']),
                        (e['note'] or '') + (f" (corrigé par {e['corrected_by']})" if e['corrected_by'] else '')])
    for col, w in zip('ABCDE', (24, 12, 8, 18, 40)):
        ws2.column_dimensions[col].width = w
    wb.save(path)
    return path


def export_tc_pdf(rows, d0, d1, path):
    k = _at_pdf_kit(); Tb, TS, Pa, C, mm = k['Table'], k['TableStyle'], k['Paragraph'], k['colors'], k['mm']
    doc, header = _at_doc(path, k, "Feuille de temps", f"Du {_d(d0.isoformat())} au {_d(d1.isoformat())} — généré le {datetime.datetime.now():%d-%m-%Y à %H:%M}", True)
    days = [d0 + datetime.timedelta(days=i) for i in range((d1 - d0).days + 1)]
    J = ('Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim')
    head = ['Employé'] + [f"{J[d.weekday()]} {d.day}" for d in days] + ['Régulières', 'Sup.', 'Total']
    data = [head]
    for r in rows:
        data.append([Pa(f"<b>{r['name']}</b><br/><font size=6.5 color='#6b7280'>{r['position'] or ''}</font>", k['cell'])] +
                    [('oubli' if x['missing_out'] else (hm_txt(x['worked']) if x['worked'] else '—')) for x in r['sheet']['days']] +
                    [hm_txt(r['sheet']['regular']), hm_txt(r['sheet']['overtime']) if r['sheet']['overtime'] else '—', hm_txt(r['sheet']['total'])])
    tot = sum(r['sheet']['total'] for r in rows); otot = sum(r['sheet']['overtime'] for r in rows)
    data.append([Pa('<b>Total</b>', k['cell'])] + [''] * len(days) + [hm_txt(tot - otot), hm_txt(otot), hm_txt(tot)])
    cw = 250 / (len(days) + 4)
    t = Tb(data, colWidths=[40 * mm] + [cw * mm] * len(days) + [cw * 1.15 * mm] * 3, repeatRows=1)
    st_ = k['base'] + [('ALIGN', (1, 0), (-1, -1), 'CENTER'), ('FONTSIZE', (0, 0), (-1, -1), 7.5 if len(days) > 7 else 8.5),
                       ('FONTNAME', (-3, 1), (-1, -1), 'Helvetica-Bold'), ('BACKGROUND', (0, -1), (-1, -1), C.HexColor('#dbe3f3')),
                       ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold')]
    for ri, r in enumerate(rows, start=1):
        for ci, x in enumerate(r['sheet']['days'], start=1):
            if x['missing_out']:
                st_.append(('BACKGROUND', (ci, ri), (ci, ri), C.HexColor('#fde68a')))
        if r['sheet']['overtime']:
            st_.append(('TEXTCOLOR', (-2, ri), (-2, ri), C.HexColor('#b45309')))
    t.setStyle(TS(st_))
    story = [Pa("Résumé de la période", k['h2']), t, k['Spacer'](1, 6),
             Pa("Pauses de 15 minutes ou moins payées ; pauses plus longues (dîner) déduites. Heures supplémentaires : au-delà de 40 h par semaine "
                "(lundi au dimanche). « oubli » = sortie non punchée, à corriger avant la paie.", k['small'])]
    appr = [r['name'] for r in rows if not r['approved']]
    story.append(Pa(("Toutes les feuilles sont approuvées." if not appr else "Non approuvées : " + ', '.join(appr)), k['small']))
    # détail par employé et par jour
    from reportlab.lib.styles import ParagraphStyle
    rem_st = ParagraphStyle('tc_rem', parent=k['cell'], fontSize=7.5, leading=9, textColor=C.HexColor('#9a3412'))
    for r in rows:
        det = tc_day_details(r)
        if not det:
            continue
        story.append(k['PageBreak']())
        story.append(Pa(f"Détail — {r['name']}" + (f" ({r['position']})" if r['position'] else ''), k['h2']))
        data = [['Jour', 'Prévu (horaire)', 'Entrée', 'Sortie', 'Pauses payées', 'Dîner déduit', 'Heures', 'Remarques']]
        for dl in det:
            data.append([dl['jour'], Pa(dl['prevu'], k['cell']), dl['entree'], dl['sortie'], f"{dl['pauses']} min" if dl['pauses'] else '—',
                         f"{dl['diner']} min" if dl['diner'] else '—', hm_txt(dl['heures']) if dl['heures'] else '—',
                         Pa('<br/>'.join(x.replace('<', '&lt;') for x in dl['remarques']) or '', rem_st)])
        data.append(['Total', '', '', '', '', '', hm_txt(r['sheet']['total']), Pa(f"dont {hm_txt(r['sheet']['overtime'])} en heures supplémentaires" if r['sheet']['overtime'] else '', k['cell'])])
        t = Tb(data, colWidths=[16 * mm, 50 * mm, 17 * mm, 17 * mm, 22 * mm, 22 * mm, 18 * mm, 98 * mm], repeatRows=1)
        st2 = k['base'] + [('ALIGN', (2, 0), (6, -1), 'CENTER'), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('FONTSIZE', (0, 0), (-1, -1), 8),
                           ('BACKGROUND', (0, -1), (-1, -1), C.HexColor('#dbe3f3')), ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold')]
        for i, dl in enumerate(det, start=1):
            if dl['remarques']:
                st2.append(('BACKGROUND', (7, i), (7, i), C.HexColor('#fff7ed')))
        t.setStyle(TS(st2))
        story.append(t)
        story.append(Pa("Pauses de 15 min ou moins payées (incluses dans les heures) ; pauses plus longues (dîner) déduites au complet. "
                        "Retard : entrée après l'heure prévue à l'horaire, au-delà de la tolérance.", k['small']))
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


# ---------- signatures électroniques des documents RH ----------
def hr_sig_clean(d):
    mode = 'drawn' if d.get('mode') == 'drawn' else 'typed'
    name = str(d.get('name') or '').strip()[:80]
    if len(name) < 3:
        raise ValueError("Inscris ton nom complet.")
    sig = {'mode': mode, 'name': name}
    if mode == 'drawn':
        img = str(d.get('img') or '')
        if not img.startswith('data:image/png;base64,') or len(img) > 400_000:
            raise ValueError("Dessine ta signature dans le cadre.")
        sig['img'] = img
    return sig


def hr_build_signed_pdf(conn, doc_id):
    """PDF signé = document d'origine + page de signatures (nom, date, heure, poste, empreinte du document)."""
    d = dict(conn.execute("SELECT * FROM hr_documents WHERE id=?", (doc_id,)).fetchone())
    e = dict(conn.execute("SELECT * FROM hr_employees WHERE id=?", (d['employee_id'],)).fetchone())
    folder = HR_DIR / str(d['employee_id']); src = folder / d['filename']
    if not src.exists() or src.suffix.lower() != '.pdf':
        return None
    import io
    from pypdf import PdfReader, PdfWriter
    k = _at_pdf_kit(); Tb, TS, Pa, C, mm = k['Table'], k['TableStyle'], k['Paragraph'], k['colors'], k['mm']
    from reportlab.platypus import Image as RLImage
    buf = io.BytesIO()
    doc = k['SimpleDocTemplate'](buf, pagesize=k['letter'], leftMargin=18 * mm, rightMargin=18 * mm, topMargin=18 * mm, bottomMargin=16 * mm)
    story = [Pa("Page de signatures", k['h1']), k['Spacer'](1, 4),
             Pa(f"Document : <b>{d['title'] or d['original_name']}</b><br/>Employé : <b>{hr_emp_name(e)}</b> — {get_company_name()}<br/>"
                f"Empreinte du document signé (SHA-256) : <font face='Courier' size=7>{d['doc_hash']}</font>", k['small']), k['Spacer'](1, 10)]
    def block(title, sig, when, extra=''):
        if not sig:
            return [Pa(f"<b>{title}</b> : pas encore signé.", k['small']), k['Spacer'](1, 8)]
        s = json.loads(sig)
        if s.get('mode') == 'drawn' and s.get('img'):
            raw = base64.b64decode(s['img'].split(',', 1)[1])
            mark = RLImage(io.BytesIO(raw), width=70 * mm, height=22 * mm, kind='proportional')
        else:
            from reportlab.lib.styles import ParagraphStyle
            mark = Pa(f"<i>{s['name']}</i>", ParagraphStyle('sig', fontName='Times-Italic', fontSize=24, leading=28, textColor=C.HexColor('#1e3a8a')))
        t = Tb([[mark], [Pa(f"<b>{title}</b> — {s['name']}<br/>Signé électroniquement le {when[:10]} à {when[11:16]}{extra}", k['small'])]], colWidths=[120 * mm])
        t.setStyle(TS([('LINEBELOW', (0, 0), (0, 0), .6, C.black), ('LEFTPADDING', (0, 0), (-1, -1), 0)]))
        return [t, k['Spacer'](1, 14)]
    story += block("Gestionnaire", d['mgr_sig'], d['mgr_signed_at'] or '', f" par {d['mgr_signed_by'] or ''}")
    story += block("Employé", d['emp_sig'], d['emp_signed_at'] or '', f" — poste {d['emp_sign_ip'] or ''}")
    if d['emp_comment']:
        story += [Pa("Commentaire de l'employé", k['h2']), Pa((d['emp_comment'] or '').replace('<', '&lt;'), k['cell'])]
    story += [k['Spacer'](1, 10), Pa("La signature de l'employé confirme qu'il a reçu et lu ce document, pas nécessairement qu'il est d'accord avec son contenu. "
                                    "Les signatures ont été apposées dans Kubios ; l'empreinte ci-dessus permet de vérifier que le document n'a pas été modifié.", k['small'])]
    doc.build(story)
    w = PdfWriter()
    for p in PdfReader(str(src)).pages:
        w.add_page(p)
    for p in PdfReader(io.BytesIO(buf.getvalue())).pages:
        w.add_page(p)
    out = folder / f"_signe_{doc_id}.pdf"
    with open(out, 'wb') as f:
        w.write(f)
    conn.execute("UPDATE hr_documents SET signed_filename=? WHERE id=?", (out.name, doc_id))
    return out


def hr_doc_file_hash(conn, doc_id):
    d = conn.execute("SELECT employee_id, filename, doc_hash FROM hr_documents WHERE id=?", (doc_id,)).fetchone()
    if d['doc_hash']:
        return d['doc_hash']
    h = hashlib.sha256((HR_DIR / str(d['employee_id']) / d['filename']).read_bytes()).hexdigest()
    conn.execute("UPDATE hr_documents SET doc_hash=? WHERE id=?", (h, doc_id))
    return h


def emp_session_emp():
    eid = session.get('emp_id')
    if not eid:
        return None
    conn = get_conn()
    try:
        r = conn.execute("SELECT e.*, p.login, p.active AS portal_active FROM hr_employees e JOIN hr_portal p ON p.employee_id=e.id WHERE e.id=?", (eid,)).fetchone()
    finally:
        conn.close()
    if not r or not r['portal_active'] or r['status'] == 'inactif':
        session.pop('emp_id', None)
        return None
    return dict(r)


# ---------- Import des bons HubTiger (export « Jobs booked in detail ») (1.40.0) ----------
HT_DROP_DIR = BASE_DIR / "Import_HubTiger"
HT_PENDING = BASE_DIR / "_import_hubtiger_attente.json"
HT_COLS = {'job': 'job card #', 'booked': 'booked in date', 'sched': 'scheduled date', 'client': 'customer', 'item': 'item',
           'serial': 'serial nr', 'services': 'service types', 'done': 'job completed'}


def _ht_clean(s):
    s = re.sub(r'-{4,}', '', str(s or ''))
    s = re.sub(r'\s+', ' ', s).strip()
    return re.sub(r'\s*-\s*$', '', s).strip()


def _ht_date(s):
    s = str(s or '').strip()[:10].replace('/', '-')
    try:
        return datetime.date.fromisoformat(s).isoformat()
    except ValueError:
        return None


def ht_parse(path):
    """Lit l'export HubTiger (xlsx ou csv). Retourne une liste de bons {job, client, item, work, serial, due, booked, done}."""
    rows = []
    if str(path).lower().endswith('.csv'):
        import csv as _csv
        with open(path, newline='', encoding='utf-8-sig') as f:
            rows = [r for r in _csv.reader(f)]
    else:
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True, data_only=True)
        rows = [list(r) for r in wb.worksheets[0].iter_rows(values_only=True)]
        wb.close()
    head_i = next((i for i, r in enumerate(rows[:10]) if any(str(c or '').strip().lower() == 'job card #' for c in r)), None)
    if head_i is None:
        raise ValueError("Ce fichier ne ressemble pas à l'export « Jobs booked in detail » de HubTiger (colonne « Job Card # » introuvable).")
    head = [str(c or '').strip().lower() for c in rows[head_i]]
    idx = {k: head.index(v) for k, v in HT_COLS.items() if v in head}
    if 'job' not in idx:
        raise ValueError("Colonne « Job Card # » introuvable.")
    get = lambda r, k: (r[idx[k]] if k in idx and idx[k] < len(r) else None)
    out, seen = [], set()
    for r in rows[head_i + 1:]:
        job = at_norm_job(get(r, 'job'))
        if not job or job in seen:
            continue
        seen.add(job)
        svc = [s.strip() for s in str(get(r, 'services') or '').split(';') if s.strip()]
        serial = _ht_clean(get(r, 'serial'))
        if serial.upper() in ('TBD', 'NON IDENTIFIER', 'N/A'):
            serial = ''
        out.append({'job': job, 'client': _ht_clean(get(r, 'client'))[:120], 'item': _ht_clean(get(r, 'item'))[:160],
                    'work': ' · '.join(svc)[:400], 'serial': serial[:80], 'due': _ht_date(get(r, 'sched')),
                    'booked': _ht_date(get(r, 'booked')), 'done': str(get(r, 'done') or '').strip().lower() in ('yes', 'oui', 'true', '1')})
    return out


def ht_plan(conn, items, include_done=True):
    """Ce que l'import ferait, sans rien écrire."""
    plan = {'new_open': [], 'new_done': [], 'update': [], 'complete': [], 'same': 0, 'skipped_done': 0}
    open_punch = {r['job'] for r in conn.execute("SELECT DISTINCT job FROM shop_punches WHERE end_at IS NULL").fetchall()}
    for it in items:
        ex = conn.execute("SELECT * FROM shop_jobs WHERE job=?", (it['job'],)).fetchone()
        if not ex:
            if it['done'] and not include_done:
                plan['skipped_done'] += 1
            else:
                plan['new_done' if it['done'] else 'new_open'].append(it)
            continue
        fill = {k: it[v] for k, v in (('client', 'client'), ('item', 'item'), ('work', 'work'), ('due_date', 'due')) if not ex[k] and it[v]}
        finish = it['done'] and ex['status'] in ('ouvert', 'en_cours') and it['job'] not in open_punch
        if fill:
            plan['update'].append(dict(it, fill=fill))
        if finish:
            plan['complete'].append(it)
        if not fill and not finish:
            plan['same'] += 1
    return plan


def ht_apply(conn, plan, who):
    now = _at_now()
    for it in plan['new_open'] + plan['new_done']:
        conn.execute("INSERT INTO shop_jobs(job, client, item, work, due_date, status, created_by, created_at, updated_at, notes, position, priority) "
                     "VALUES (?,?,?,?,?,?,?,?,?,?,?, 'normal')",
                     (it['job'], it['client'] or None, it['item'] or None, it['work'] or None, it['due'], 'termine' if it['done'] else 'ouvert',
                      'HubTiger (import)', (it['booked'] or now[:10]) + ' 00:00:00',
                      # bon déjà terminé : HubTiger ne donne pas la date de fin, la date prévue s'en approche le plus
                      ((min(it['due'] or it['booked'] or now[:10], now[:10]) + ' 12:00:00') if it['done'] else now),
                      (f"N° de série : {it['serial']}" if it['serial'] else None), _at_next_position(conn, None)))
    for it in plan['update']:
        sets = ', '.join(f"{k}=COALESCE(NULLIF({k}, ''), ?)" for k in it['fill'])
        conn.execute(f"UPDATE shop_jobs SET {sets}, updated_at=? WHERE job=?", list(it['fill'].values()) + [now, it['job']])
    for it in plan['complete']:
        conn.execute("UPDATE shop_jobs SET status='termine', updated_at=? WHERE job=? AND status IN ('ouvert','en_cours')", (now, it['job']))
    conn.commit()
    res = {'created': len(plan['new_open']) + len(plan['new_done']), 'created_open': len(plan['new_open']), 'updated': len(plan['update']),
           'completed': len(plan['complete']), 'same': plan['same']}
    db_add_audit(who, 'Atelier : import HubTiger', f"{res['created']} bon(s) créé(s) dont {res['created_open']} ouvert(s), "
                                                    f"{res['updated']} complété(s), {res['completed']} terminé(s), {res['same']} inchangé(s)")
    return res


def ht_summary(plan):
    return {'new_open': len(plan['new_open']), 'new_done': len(plan['new_done']), 'update': len(plan['update']), 'complete': len(plan['complete']),
            'same': plan['same'], 'skipped_done': plan['skipped_done'],
            'sample_new': [{k: it[k] for k in ('job', 'client', 'item', 'work', 'due')} for it in plan['new_open'][:12]],
            'sample_complete': [it['job'] for it in plan['complete'][:20]]}


def _ht_drop_loop():
    """Dossier de dépôt : un export déposé dans Import_HubTiger est importé tout seul, puis rangé dans « Importés »."""
    time.sleep(120)
    while True:
        try:
            if meta_get('ht_drop_enabled') == '1' and HT_DROP_DIR.exists():
                for f in sorted(HT_DROP_DIR.glob('*')):
                    if f.suffix.lower() not in ('.xlsx', '.csv') or f.name.startswith('~$') or time.time() - f.stat().st_mtime < 20:
                        continue
                    done_dir = HT_DROP_DIR / 'Importés'; done_dir.mkdir(exist_ok=True)
                    try:
                        items = ht_parse(f)
                        conn = get_conn()
                        try:
                            res = ht_apply(conn, ht_plan(conn, items, meta_get('ht_include_done') != '0'), 'Kubios (dossier de dépôt)')
                        finally:
                            conn.close()
                        meta_set('ht_last_drop', json.dumps({'at': _at_now(), 'file': f.name, 'result': res}, ensure_ascii=False))
                        f.replace(done_dir / f"{datetime.datetime.now():%Y-%m-%d_%H%M%S}_{f.name}")
                    except Exception as e:
                        meta_set('ht_last_drop', json.dumps({'at': _at_now(), 'file': f.name, 'error': str(e)}, ensure_ascii=False))
                        f.replace(done_dir / f"ERREUR_{datetime.datetime.now():%Y-%m-%d_%H%M%S}_{f.name}")
                        db_add_audit('Kubios (dossier de dépôt)', 'Atelier : import HubTiger — échec', f"{f.name} : {e}")
        except Exception:
            traceback.print_exc()
        time.sleep(300)


# ============================================================
# Horaires des employés (1.42.0) — module RH de la licence
# ============================================================
SCHED_DEFAULT_TEMPLATES = [['07:00', '16:00'], ['08:00', '17:00'], ['08:00', '16:00'], ['08:00', '13:00']]
SCHED_MEALS = ['11:00', '12:00', '13:00']
JOURS_FR = ('lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche')
JOURS_CRT = ('Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim')


def sched_settings():
    try:
        tpl = json.loads(meta_get('sched_templates') or 'null') or SCHED_DEFAULT_TEMPLATES
    except ValueError:
        tpl = SCHED_DEFAULT_TEMPLATES
    closed = [int(x) for x in (meta_get('sched_closed_days') if meta_get('sched_closed_days') is not None else '6').split(',') if x.strip().isdigit()]
    try:
        grace = int(meta_get('sched_late_grace') or 5)
    except ValueError:
        grace = 5
    return {'templates': tpl, 'meals': SCHED_MEALS, 'closed': closed, 'grace': grace}


def _hm(s):
    h, m = s.split(':'); return int(h) * 60 + int(m)


def sched_paid_min(c):
    if not c or c.get('kind') != 'work' or not c.get('start') or not c.get('end'):
        return 0
    return max(0, _hm(c['end']) - _hm(c['start']) - (60 if c.get('meal') else 0))


def sched_label(c):
    if not c:
        return '—'
    if c['kind'] == 'off':
        return 'Congé'
    t = lambda s: f"{int(s[:2])} h" + (f" {s[3:]}" if s[3:] != '00' else '')
    return f"{t(c['start'])} – {t(c['end'])}" + (f", repas {t(c['meal'])}" if c.get('meal') else '')


def sched_cells(conn, table, d0, d1, emp_id=None):
    q = f"SELECT * FROM {table} WHERE day BETWEEN ? AND ?" + (" AND employee_id=?" if emp_id else "")
    out = {}
    for r in conn.execute(q, (d0.isoformat(), d1.isoformat()) + ((emp_id,) if emp_id else ())).fetchall():
        out.setdefault(r['employee_id'], {})[r['day']] = {'kind': r['kind'], 'start': r['start'], 'end': r['end'], 'meal': r['meal'], 'note': r['note'] or ''}
    return out


def _sched_same(a, b):
    k = ('kind', 'start', 'end', 'meal', 'note')
    return (a is None and b is None) or (a is not None and b is not None and all((a.get(x) or '') == (b.get(x) or '') for x in k))


def sched_employees(conn):
    return [dict(r) for r in conn.execute(
        "SELECT id, first_name, last_name, department, position, email FROM hr_employees WHERE status<>'inactif' "
        "ORDER BY COALESCE(NULLIF(department,''),'~') COLLATE NOCASE, first_name COLLATE NOCASE, last_name COLLATE NOCASE").fetchall()]


def sched_day_fr(iso):
    d = datetime.date.fromisoformat(iso)
    return f"{JOURS_FR[d.weekday()]} {d.day}{'er' if d.day == 1 else ''} {_MOIS_FR[d.month - 1]}"


def export_sched_pdf(conn, d0, d1, path):
    k = _at_pdf_kit(); Tb, TS, Pa, C, mm = k['Table'], k['TableStyle'], k['Paragraph'], k['colors'], k['mm']
    st = sched_settings()
    doc, header = _at_doc(path, k, "Horaire de travail", f"Du {_d(d0.isoformat())} au {_d(d1.isoformat())}", True)
    cells = sched_cells(conn, 'sched_published', d0, d1)
    emps = sched_employees(conn)
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_CENTER
    ctr = ParagraphStyle('sc_ctr', parent=k['cell'], alignment=TA_CENTER, fontSize=8.5, leading=10.5)
    dephd = ParagraphStyle('sc_dep', parent=k['cell'], fontName='Helvetica-Bold', textColor=C.white, fontSize=9)
    story = []
    wk, n = d0, 1
    while wk <= d1:
        days = [wk + datetime.timedelta(days=i) for i in range(7)]
        if n > 1:
            story.append(k['PageBreak']() if 'PageBreak' in k else k['Spacer'](1, 14))
        story.append(Pa(f"PÉRIODE {n} — semaine du {_d(days[0].isoformat())} au {_d(days[-1].isoformat())}", k['h2']))
        for dep in sorted({(e['department'] or 'Sans département') for e in emps}, key=lambda x: (x == 'Sans département', x.lower())):
            data = [[Pa(dep, dephd)] + [f"{JOURS_CRT[d.weekday()]} {d.day}" for d in days] + ['Total']]
            styles = []
            for ri, e in enumerate([e for e in emps if (e['department'] or 'Sans département') == dep], start=1):
                row, tot = [Pa(f"{e['first_name']} {e['last_name']}", k['cell'])], 0
                for ci, d in enumerate(days, start=1):
                    c = (cells.get(e['id']) or {}).get(d.isoformat())
                    if d.weekday() in st['closed'] and not c:
                        row.append('FERMÉ'); styles.append(('TEXTCOLOR', (ci, ri), (ci, ri), C.HexColor('#94a3b8')))
                    elif c and c['kind'] == 'off':
                        row.append('Congé'); styles.append(('BACKGROUND', (ci, ri), (ci, ri), C.HexColor('#fef3c7')))
                    elif c:
                        tot += sched_paid_min(c)
                        row.append(Pa(f"{sched_label(c).split(',')[0]}" + (f"<br/><font size=7 color='#64748b'>repas {int(c['meal'][:2])} h</font>" if c.get('meal') else ''), ctr))
                    else:
                        row.append('')
                row.append(f"{tot // 60} h" + (f" {tot % 60:02d}" if tot % 60 else ''))
                data.append(row)
            if len(data) == 1:
                continue
            t = Tb(data, colWidths=[46 * mm] + [28 * mm] * 7 + [18 * mm], repeatRows=1)
            t.setStyle(TS(k['base'] + [('ALIGN', (1, 0), (-1, -1), 'CENTER'), ('ALIGN', (-1, 1), (-1, -1), 'CENTER'), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('FONTSIZE', (0, 0), (-1, -1), 8.5),
                                       ('FONTNAME', (-1, 1), (-1, -1), 'Helvetica-Bold')] + styles))
            story += [t, k['Spacer'](1, 6)]
        wk += datetime.timedelta(days=7); n += 1
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


def sched_compare(conn, emp_id, days, tc_days_list):
    """Retards et absences : compare l'horaire publié aux punchs (feuilles de temps)."""
    st = sched_settings()
    cells = sched_cells(conn, 'sched_published', datetime.date.fromisoformat(days[0]), datetime.date.fromisoformat(days[-1]), emp_id).get(emp_id, {})
    today = datetime.date.today().isoformat()
    out = []
    for d, x in zip(days, tc_days_list):
        c = cells.get(d)
        info = {'sched': sched_label(c) if c else None, 'late': 0, 'absent': False}
        if c and c['kind'] == 'work':
            if x['first_in']:
                late = _hm(x['first_in']) - _hm(c['start'])
                if late > st['grace']:
                    info['late'] = late
            elif d < today or (d == today and datetime.datetime.now().strftime('%H:%M') > c['end']):
                info['absent'] = True
        out.append(info)
    return out


# ============================================================
# Synchronisation SQLite -> Excel (opération lente, en arrière-plan ou à la demande)
# ============================================================
BACKUP_DIR = BASE_DIR / "Backups_auto"
BACKUP_DIR.mkdir(exist_ok=True)
MAX_BACKUPS = 20
_sync_lock = threading.Lock()
_sync_state = {"running": False, "last_error": None}


def _prune_backups():
    backups = sorted(BACKUP_DIR.glob("Compte à recevoir_*.xlsx"), key=lambda p: p.stat().st_mtime)
    for old in backups[:-MAX_BACKUPS]:
        try:
            old.unlink()
        except OSError:
            pass


def save_wb_atomic(wb):
    """Écriture atomique : fichier temporaire vérifié, puis remplacement. Une
    interruption pendant l'écriture ne peut jamais corrompre le fichier original."""
    if EXCEL_PATH.exists():
        try:
            stamp = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
            shutil.copy2(EXCEL_PATH, BACKUP_DIR / f"Compte à recevoir_{stamp}.xlsx")
            _prune_backups()
        except OSError:
            pass

    tmp_path = EXCEL_PATH.with_name(EXCEL_PATH.stem + ".tmp_write.xlsx")
    try:
        wb.save(tmp_path)
    except PermissionError:
        raise RuntimeError(
            "Impossible d'enregistrer : le fichier Excel est probablement ouvert. "
            "Ferme 'Compte à recevoir.xlsx' dans Excel puis réessaie."
        )
    try:
        check = openpyxl.load_workbook(tmp_path, read_only=True)
        check.close()
    except Exception as e:
        tmp_path.unlink(missing_ok=True)
        raise RuntimeError(f"Écriture invalide, annulée sans toucher l'original. Détail : {e}")
    os.replace(tmp_path, EXCEL_PATH)


def set_row_formulas(ws, row):
    # les tranches d'âge (G-J) se basent sur M (le solde restant après paiement),
    # pas sur F (le montant facturé au complet)
    ws.cell(row=row, column=7, value=f"=IF(TODAY()<=E{row},M{row},0)")
    ws.cell(row=row, column=8, value=f"=IF(AND(TODAY()>E{row},TODAY()-E{row}<=30),M{row},0)")
    ws.cell(row=row, column=9, value=f"=IF(AND(TODAY()-E{row}>30,TODAY()-E{row}<=60),M{row},0)")
    ws.cell(row=row, column=10, value=f"=IF(TODAY()-E{row}>60,M{row},0)")
    ws.cell(row=row, column=13, value=f"=F{row}-L{row}")  # solde = montant - payé
    for c in (7, 8, 9, 10, 12, 13):
        ws.cell(row=row, column=c).number_format = '#,##0.00;\\(#,##0.00\\)'


def refresh_header_sums(ws, last_row):
    last_row = max(last_row, FORMULA_MIN_LAST_ROW)
    for col in (6, 7, 8, 9, 10, 12, 13):
        letter = get_column_letter(col)
        ws.cell(row=2, column=col, value=f"=SUM({letter}3:{letter}{last_row})")


def write_client_sheet(ws, client_row, invoices):
    """Réécrit entièrement le bloc de factures d'un onglet client à partir des
    données SQLite (source unique de vérité)."""
    # efface l'ancien bloc de factures (colonnes C..M, à partir de la ligne 2)
    for r in range(2, max(ws.max_row, FORMULA_MIN_LAST_ROW) + 1):
        for c in range(3, 14):
            ws.cell(row=r, column=c).value = None

    ws.cell(row=1, column=12, value='Payé')
    ws.cell(row=1, column=13, value='Solde')

    ws.cell(row=2, column=1, value=client_row['name'])
    ws.cell(row=2, column=2, value=client_row['phone'] or '')
    ws.cell(row=INFO_ROWS['adresse'], column=1, value='Adresse')
    ws.cell(row=INFO_ROWS['adresse'], column=2, value=client_row['adresse'] or '')
    ws.cell(row=INFO_ROWS['ville'], column=1, value='Ville')
    ws.cell(row=INFO_ROWS['ville'], column=2, value=client_row['ville'] or '')
    ws.cell(row=INFO_ROWS['province'], column=1, value='Province')
    ws.cell(row=INFO_ROWS['province'], column=2, value=client_row['province'] or 'Qc')
    ws.cell(row=INFO_ROWS['code_postal'], column=1, value='Code Postal')
    ws.cell(row=INFO_ROWS['code_postal'], column=2, value=client_row['code_postal'] or '')
    ws.cell(row=INFO_ROWS['courriel'], column=1, value='Adresse couriel')
    ws.cell(row=INFO_ROWS['courriel'], column=2, value=client_row['courriel'] or '')

    row = FIRST_INVOICE_ROW
    for inv in invoices:
        ws.cell(row=row, column=3, value=inv['numero'])
        try:
            d = datetime.datetime.strptime(inv['date_facture'], '%Y-%m-%d') if inv['date_facture'] else None
        except ValueError:
            d = None
        try:
            e = datetime.datetime.strptime(inv['echeance'], '%Y-%m-%d') if inv['echeance'] else None
        except ValueError:
            e = None
        if d:
            ws.cell(row=row, column=4, value=d).number_format = 'dd-mm-yyyy'
        if e:
            ws.cell(row=row, column=5, value=e).number_format = 'dd/mm/yyyy'
        ws.cell(row=row, column=6, value=float(inv['montant'])).number_format = '#,##0.00;\\(#,##0.00\\)'
        if inv['notes']:
            ws.cell(row=row, column=11, value=inv['notes'])
        ws.cell(row=row, column=12, value=float(inv.get('montant_paye') or 0))
        set_row_formulas(ws, row)
        row += 1

    last_row = max(row - 1, FORMULA_MIN_LAST_ROW)
    refresh_header_sums(ws, last_row)


def export_to_excel():
    """Régénère le fichier Excel complet à partir de la base SQLite. Opération
    lente (~20-30s) — appelée en arrière-plan ou à la demande, jamais bloquante
    pour la saisie."""
    with _sync_lock:
        _sync_state["running"] = True
        _sync_state["last_error"] = None
        try:
            wb = openpyxl.load_workbook(EXCEL_PATH, data_only=False)
            conn = get_conn()
            # Renommages d'onglets en attente (clients renommés dans l'app).
            pending_row = conn.execute("SELECT value FROM meta WHERE key='pending_sheet_renames'").fetchone()
            try:
                pending_renames = json.loads(pending_row['value']) if pending_row and pending_row['value'] else []
            except Exception:
                pending_renames = []
            for old_sheet, new_sheet in pending_renames:
                if old_sheet not in wb.sheetnames or old_sheet == new_sheet:
                    continue
                if any(n.lower() == new_sheet.lower() for n in wb.sheetnames if n != old_sheet):
                    continue  # un onglet porte déjà ce nom : on ne touche à rien
                ws_r = wb[old_sheet]
                if old_sheet.lower() == new_sheet.lower():
                    # changement de majuscules seulement : openpyxl exige un nom intermédiaire
                    ws_r.title = "_renommage_tmp_"
                ws_r.title = new_sheet

            clients = conn.execute("SELECT * FROM clients ORDER BY name COLLATE NOCASE").fetchall()

            # Onglets de clients fusionnés dans un autre (1.11.3) : supprimés, sauf
            # si un client utilise encore ce nom d'onglet.
            del_row = conn.execute("SELECT value FROM meta WHERE key='pending_sheet_deletes'").fetchone()
            try:
                pending_deletes = json.loads(del_row['value']) if del_row and del_row['value'] else []
            except Exception:
                pending_deletes = []
            used_sheets = {c['sheet_name'] for c in clients}
            for sh in pending_deletes:
                if sh in wb.sheetnames and sh not in used_sheets and sh not in (SOMMAIRE_SHEET, MODELE_SHEET):
                    wb.remove(wb[sh])

            sommaire = wb[SOMMAIRE_SHEET]
            # efface les anciennes lignes du Sommaire (à partir de la ligne 3)
            for r in range(3, max(sommaire.max_row, len(clients) + 5) + 1):
                for c in range(1, 8):
                    sommaire.cell(row=r, column=c).value = None

            srow = 3
            for c in clients:
                sheet_name = c['sheet_name']
                if sheet_name not in wb.sheetnames:
                    ws = wb.copy_worksheet(wb[MODELE_SHEET])
                    ws.title = sheet_name
                    if ws.title != sheet_name:
                        # openpyxl a ajouté un suffixe (nom déjà pris) : on garde
                        # la base alignée sur le vrai nom de l'onglet.
                        conn.execute("UPDATE clients SET sheet_name=? WHERE name=?", (ws.title, c['name']))
                        sheet_name = ws.title
                else:
                    ws = wb[sheet_name]
                invoices = conn.execute(
                    "SELECT * FROM invoices WHERE client_name=? ORDER BY id", (c['name'],)
                ).fetchall()
                write_client_sheet(ws, c, [dict(i) for i in invoices])

                sommaire.cell(row=srow, column=1, value=c['name'])
                sommaire.cell(row=srow, column=2, value=f"='{sheet_name}'!G2")
                sommaire.cell(row=srow, column=3, value=f"='{sheet_name}'!H2")
                sommaire.cell(row=srow, column=4, value=f"='{sheet_name}'!I2")
                sommaire.cell(row=srow, column=5, value=f"='{sheet_name}'!J2")
                sommaire.cell(row=srow, column=6, value=f"='{sheet_name}'!M2")  # solde restant, pas le montant facturé
                sommaire.cell(row=srow, column=7, value=f"=SUM(B{srow}:E{srow})")
                srow += 1

            last_sommaire_row = max(srow - 1, 3)
            for col in (2, 3, 4, 5, 6):
                letter = get_column_letter(col)
                sommaire.cell(row=2, column=col, value=f"=SUM({letter}3:{letter}{last_sommaire_row})")
            sommaire.cell(row=2, column=7, value="=SUM(B2:E2)")

            counter_row = conn.execute("SELECT value FROM meta WHERE key='statement_counter'").fetchone()
            if counter_row:
                sommaire.cell(row=2, column=13, value=int(counter_row['value']))

            log_ws = wb[LOG_SHEET]
            pending_logs = conn.execute("SELECT * FROM log_envois WHERE synced=0 ORDER BY id").fetchall()
            r = log_ws.max_row + 1
            for lg in pending_logs:
                log_ws.cell(row=r, column=1, value=lg['ts'])
                log_ws.cell(row=r, column=2, value=lg['client'])
                log_ws.cell(row=r, column=3, value=lg['courriel'])
                log_ws.cell(row=r, column=4, value=lg['total'])
                log_ws.cell(row=r, column=5, value=lg['statut'])
                log_ws.cell(row=r, column=6, value=lg['note'])
                r += 1

            save_wb_atomic(wb)

            conn.execute("UPDATE log_envois SET synced=1 WHERE synced=0")
            conn.execute("DELETE FROM meta WHERE key='pending_sheet_renames'")
            conn.execute("DELETE FROM meta WHERE key='pending_sheet_deletes'")
            conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('dirty', '0')")
            conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('last_sync', ?)",
                         (datetime.datetime.now().isoformat(),))
            conn.commit()
            conn.close()
        except Exception as e:
            _sync_state["last_error"] = str(e)
            traceback.print_exc()
            raise
        finally:
            _sync_state["running"] = False


def _auto_sync_loop():
    import time
    while True:
        time.sleep(AUTO_SYNC_SECONDS)
        try:
            if meta_get('dirty', '0') == '1' and not _sync_state["running"]:
                print("Synchronisation automatique vers Excel...")
                export_to_excel()
                print("Synchronisation automatique terminée.")
        except Exception as e:
            print("Erreur de synchronisation automatique :", e)


# ============================================================
# Génération du PDF (État de compte) — reproduit le modèle existant
# ============================================================
HEADER_RESERVED_HEIGHT = 62  # mm réservés en haut de la page 1 pour titre + logo


def generate_statement_pdf(client_name, info, invoices, totals, statement_number):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Table, TableStyle,
                                     Paragraph, Spacer, NextPageTemplate, PageBreak, ListFlowable,
                                     ListItem)
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

    safe_name = re.sub(r'[\\/:*?"<>|]', '_', client_name)
    pdf_path = PDF_DIR / f"Etat_de_compte_{safe_name}_{statement_number}.pdf"

    page_w, page_h = letter
    left_margin = right_margin = 18 * mm
    bottom_margin = 18 * mm

    styles = getSampleStyleSheet()
    h1 = ParagraphStyle('h1', parent=styles['Heading1'], fontSize=13, spaceAfter=6, spaceBefore=2)
    normal = ParagraphStyle('normal', parent=styles['Normal'], fontSize=10, leading=15)
    label_normal = ParagraphStyle('labelnormal', parent=normal)
    small = ParagraphStyle('small', parent=styles['Normal'], fontSize=9, leading=13)
    footer_style = ParagraphStyle('footer', parent=styles['Normal'], fontSize=10)

    emission_date = datetime.date.today().strftime('%Y-%m-%d')

    def draw_header(canvas, doc_):
        canvas.saveState()
        x = left_margin
        top = page_h - 20 * mm

        canvas.setFont('Helvetica-Bold', 22)
        canvas.drawString(x, top, "ÉTAT DE COMPTE")

        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 10 * mm, "Date d'émission :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 32 * mm, top - 10 * mm, emission_date)
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 15 * mm, "Numéro d'état de compte :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 45 * mm, top - 15 * mm, statement_number)

        if LOGO_PATH.exists():
            from reportlab.lib.utils import ImageReader
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            logo_w = 65 * mm
            logo_h = logo_w * ih / iw
            canvas.drawImage(img, page_w - right_margin - logo_w, top - logo_h + 4 * mm,
                              width=logo_w, height=logo_h, mask='auto')

        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.setLineWidth(0.5)
        rule_y = top - 22 * mm
        canvas.line(left_margin, rule_y, page_w - right_margin, rule_y)
        canvas.restoreState()

    def draw_plain(canvas, doc_):
        pass

    frame_first = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                         page_h - bottom_margin - HEADER_RESERVED_HEIGHT * mm, id='first')
    frame_rest = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                        page_h - bottom_margin - 15 * mm, id='rest')

    doc = BaseDocTemplate(str(pdf_path), pagesize=letter)
    doc.addPageTemplates([
        PageTemplate(id='First', frames=[frame_first], onPage=draw_header),
        PageTemplate(id='Rest', frames=[frame_rest], onPage=draw_plain),
    ])

    def field(label, value):
        return Paragraph(f"<b>{label} :</b> {value}", label_normal)

    story = []
    story.append(Paragraph("Information du client", h1))
    story.append(field("Client", client_name))
    story.append(field("Adresse", info.get('adresse', '') or '—'))
    ville_prov = f"{info.get('ville','')}, {info.get('province','')}".strip(', ')
    story.append(field("Ville / Province", ville_prov or '—'))
    story.append(field("Courriel", info.get('courriel', '') or '—'))
    story.append(field("Téléphone", info.get('phone', '') or '—'))
    story.append(Spacer(1, 6 * mm))

    from reportlab.platypus.flowables import HRFlowable
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))
    story.append(Spacer(1, 4 * mm))

    story.append(Paragraph("Sommaire des soldes", h1))
    tranche_rows = [
        ["Tranche", "Montant"],
        ["0 – 30 jours", f"{totals['g']:,.2f} $"],
        ["31 – 60 jours", f"{totals['h']:,.2f} $"],
        ["61 – 90 jours", f"{totals['i']:,.2f} $"],
        ["90+ jours", f"{totals['j']:,.2f} $"],
        ["TOTAL DÛ", f"{totals['montant']:,.2f} $"],
    ]
    tranche_table = Table(tranche_rows, colWidths=[70 * mm, 60 * mm])
    tranche_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('TOPPADDING', (0, 0), (-1, -1), 7),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
        ('LINEBELOW', (0, 0), (-1, 0), 0.5, colors.HexColor('#cccccc')),
        ('ALIGN', (1, 0), (1, -1), 'LEFT'),
    ]))
    story.append(tranche_table)
    story.append(Spacer(1, 4 * mm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))

    story.append(NextPageTemplate('Rest'))
    story.append(PageBreak())

    # Le montant affiché est le solde restant (montant facturé moins paiement partiel
    # déjà reçu) — une facture entièrement payée n'apparaît plus dans le détail.
    billable = [inv for inv in invoices if inv.get('solde', inv['montant']) != 0]
    has_partial = any(inv.get('montant_paye') for inv in billable)
    if billable:
        story.append(Paragraph("Détail des factures dues", h1))
        story.append(Spacer(1, 3 * mm))
        data = [["Facture", "Date", "Échéance", "Montant"]]
        for inv in billable:
            montant_affiche = inv.get('solde', inv['montant'])
            suffix = " *" if inv.get('montant_paye') else ""
            data.append([str(inv['numero']) + suffix, inv['date_facture'], inv['echeance'],
                         f"{montant_affiche:,.2f} $"])
        det_table = Table(data, colWidths=[38 * mm, 33 * mm, 33 * mm, 38 * mm], repeatRows=0)
        det_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
            ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ]))
        story.append(det_table)
        if has_partial:
            story.append(Spacer(1, 2 * mm))
            story.append(Paragraph("* Solde après un paiement partiel déjà reçu.", small))
        story.append(Spacer(1, 6 * mm))

    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph("Modalités et paiement", h1))
    bullets = [
        "Merci d'indiquer le <b>numéro de facture</b> lors du paiement.",
        "Pour toute question concernant votre état de compte, communiquez avec nous.",
        "Les montants indiqués sont dus immédiatement, sauf entente contraire.",
    ]
    story.append(ListFlowable(
        [ListItem(Paragraph(b, small), spaceAfter=4) for b in bullets],
        bulletType='bullet', start='circle', leftIndent=12,
    ))
    story.append(Spacer(1, 6 * mm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph(f"<b>{get_pdf_footer_message()}</b><br/>&nbsp;{get_company_name()}", footer_style))

    doc.build(story)
    return pdf_path


def db_invoices_by_month(year, month):
    """Toutes les factures dont la date de facture tombe dans le mois donné, groupées par client."""
    ym = f"{year:04d}-{month:02d}"
    conn = get_conn()
    rows = conn.execute(
        "SELECT client_name, numero, date_facture, echeance, montant, notes "
        "FROM invoices WHERE date_facture LIKE ? ORDER BY client_name COLLATE NOCASE, date_facture",
        (f"{ym}-%",)
    ).fetchall()
    conn.close()
    by_client = {}
    for r in rows:
        by_client.setdefault(r['client_name'], []).append(dict(r))
    return by_client


MOIS_FR = ["", "Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet",
           "Août", "Septembre", "Octobre", "Novembre", "Décembre"]


def generate_monthly_report_pdf(year, month, by_client):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Table, TableStyle,
                                     Paragraph, Spacer, NextPageTemplate, PageBreak)
    from reportlab.platypus.flowables import HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader

    mois_nom = MOIS_FR[month]
    report_dir = PDF_DIR / "Rapports_mensuels"
    report_dir.mkdir(exist_ok=True)
    pdf_path = report_dir / f"Rapport_{year:04d}-{month:02d}.pdf"

    page_w, page_h = letter
    left_margin = right_margin = 18 * mm
    bottom_margin = 18 * mm
    header_reserved = 55  # mm

    styles = getSampleStyleSheet()
    h1 = ParagraphStyle('h1', parent=styles['Heading1'], fontSize=12, spaceAfter=4, spaceBefore=8)
    footer_style = ParagraphStyle('footer', parent=styles['Normal'], fontSize=10)

    emission_date = datetime.date.today().strftime('%Y-%m-%d')

    def draw_header(canvas, doc_):
        canvas.saveState()
        x = left_margin
        top = page_h - 20 * mm
        canvas.setFont('Helvetica-Bold', 18)
        canvas.drawString(x, top, "RAPPORT MENSUEL — COMPTES À RECEVOIR")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 9 * mm, "Période :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 20 * mm, top - 9 * mm, f"{mois_nom} {year}")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 14 * mm, "Généré le :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 24 * mm, top - 14 * mm, emission_date)

        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            logo_w = 55 * mm
            logo_h = logo_w * ih / iw
            canvas.drawImage(img, page_w - right_margin - logo_w, top - logo_h + 2 * mm,
                              width=logo_w, height=logo_h, mask='auto')

        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.setLineWidth(0.5)
        rule_y = top - 19 * mm
        canvas.line(left_margin, rule_y, page_w - right_margin, rule_y)
        canvas.restoreState()

    def draw_plain(canvas, doc_):
        pass

    frame_first = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                         page_h - bottom_margin - header_reserved * mm, id='first')
    frame_rest = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                        page_h - bottom_margin - 15 * mm, id='rest')

    doc = BaseDocTemplate(str(pdf_path), pagesize=letter)
    doc.addPageTemplates([
        PageTemplate(id='First', frames=[frame_first], onPage=draw_header),
        PageTemplate(id='Rest', frames=[frame_rest], onPage=draw_plain),
    ])

    story = []
    client_names = sorted(by_client.keys(), key=lambda s: s.lower())
    grand_total = 0.0
    n_invoices = 0

    if not client_names:
        story.append(Paragraph(f"Aucune facture datée de {mois_nom} {year} n'a été trouvée.", styles['Normal']))
    else:
        for client_name in client_names:
            invs = by_client[client_name]
            subtotal = sum(i['montant'] for i in invs)
            grand_total += subtotal
            n_invoices += len(invs)

            story.append(Paragraph(client_name, h1))
            data = [["Facture", "Date", "Échéance", "Montant"]]
            for i in invs:
                data.append([str(i['numero']), i['date_facture'], i['echeance'] or '—',
                             f"{i['montant']:,.2f} $"])
            data.append(["", "", "Sous-total :", f"{subtotal:,.2f} $"])
            t = Table(data, colWidths=[38 * mm, 33 * mm, 33 * mm, 38 * mm], repeatRows=1)
            t.setStyle(TableStyle([
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 9),
                ('GRID', (0, 0), (-1, -2), 0.5, colors.black),
                ('LINEABOVE', (0, -1), (-1, -1), 0.75, colors.black),
                ('TOPPADDING', (0, 0), (-1, -1), 5),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ]))
            story.append(t)
            story.append(Spacer(1, 5 * mm))

        story.append(HRFlowable(width="100%", thickness=0.75, color=colors.HexColor('#333333')))
        story.append(Spacer(1, 3 * mm))
        story.append(Paragraph(
            f"<b>TOTAL — {n_invoices} facture(s), {len(client_names)} client(s) : {grand_total:,.2f} $</b>",
            footer_style))

    story.append(_pdf_disclaimer())
    doc.build(story)
    return pdf_path


def db_envois_by_month(year, month):
    """Tous les courriels (brouillons et envois) enregistrés dans le mois donné."""
    ym = f"{year:04d}-{month:02d}"
    conn = get_conn()
    rows = conn.execute(
        "SELECT ts, client, courriel, total, statut, note FROM log_envois "
        "WHERE ts LIKE ? ORDER BY ts",
        (f"{ym}-%",)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def generate_envoi_report_pdf(year, month, rows):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Table, TableStyle,
                                     Paragraph, Spacer, NextPageTemplate, PageBreak)
    from reportlab.platypus.flowables import HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader

    mois_nom = MOIS_FR[month]
    report_dir = PDF_DIR / "Rapports_envois"
    report_dir.mkdir(exist_ok=True)
    pdf_path = report_dir / f"Rapport_envois_{year:04d}-{month:02d}.pdf"

    page_w, page_h = letter
    left_margin = right_margin = 18 * mm
    bottom_margin = 18 * mm
    header_reserved = 55  # mm

    styles = getSampleStyleSheet()
    footer_style = ParagraphStyle('footer', parent=styles['Normal'], fontSize=10)

    emission_date = datetime.date.today().strftime('%Y-%m-%d')

    def draw_header(canvas, doc_):
        canvas.saveState()
        x = left_margin
        top = page_h - 20 * mm
        canvas.setFont('Helvetica-Bold', 18)
        canvas.drawString(x, top, "RAPPORT D'ENVOI — COURRIELS")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 9 * mm, "Période :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 20 * mm, top - 9 * mm, f"{mois_nom} {year}")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 14 * mm, "Généré le :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 24 * mm, top - 14 * mm, emission_date)

        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            logo_w = 55 * mm
            logo_h = logo_w * ih / iw
            canvas.drawImage(img, page_w - right_margin - logo_w, top - logo_h + 2 * mm,
                              width=logo_w, height=logo_h, mask='auto')

        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.setLineWidth(0.5)
        rule_y = top - 19 * mm
        canvas.line(left_margin, rule_y, page_w - right_margin, rule_y)
        canvas.restoreState()

    def draw_plain(canvas, doc_):
        pass

    frame_first = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                         page_h - bottom_margin - header_reserved * mm, id='first')
    frame_rest = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                        page_h - bottom_margin - 15 * mm, id='rest')

    doc = BaseDocTemplate(str(pdf_path), pagesize=letter)
    doc.addPageTemplates([
        PageTemplate(id='First', frames=[frame_first], onPage=draw_header),
        PageTemplate(id='Rest', frames=[frame_rest], onPage=draw_plain),
    ])

    story = []
    if not rows:
        story.append(Paragraph(f"Aucun courriel enregistré pour {mois_nom} {year}.", styles['Normal']))
    else:
        data = [["Date / heure", "Client", "Courriel", "Montant", "Statut", "Note"]]
        grand_total = 0.0
        n_envoyes = 0
        for r in rows:
            ts_disp = (r['ts'] or '')[:16].replace('T', ' ')
            data.append([ts_disp, r['client'] or '', r['courriel'] or '—',
                         f"{(r['total'] or 0):,.2f} $", r['statut'] or '', r['note'] or ''])
            grand_total += (r['total'] or 0)
            if (r['statut'] or '').upper() == 'ENVOYÉ':
                n_envoyes += 1
        t = Table(data, colWidths=[28 * mm, 32 * mm, 38 * mm, 20 * mm, 18 * mm, 40 * mm], repeatRows=1)
        t.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ]))
        story.append(t)
        story.append(Spacer(1, 5 * mm))
        story.append(HRFlowable(width="100%", thickness=0.75, color=colors.HexColor('#333333')))
        story.append(Spacer(1, 3 * mm))
        story.append(Paragraph(
            f"<b>TOTAL — {len(rows)} courriel(s) enregistré(s), dont {n_envoyes} envoyé(s) "
            f"directement : {grand_total:,.2f} $</b>",
            footer_style))

    story.append(_pdf_disclaimer())
    doc.build(story)
    return pdf_path


def month_end_or_today(year, month):
    """Dernier jour du mois choisi, sauf si c'est le mois en cours : dans ce cas on
    utilise la date d'aujourd'hui, pour que le rapport du mois courant corresponde
    exactement à l'état réel actuel."""
    import calendar
    today = datetime.date.today()
    if year == today.year and month == today.month:
        return today
    last_day = calendar.monthrange(year, month)[1]
    return datetime.date(year, month, last_day)


def db_aging_all_clients(ref_date=None):
    """Solde par tranche d'âge (0-30 / 31-60 / 61-90 / 90+), par client, pour tous les
    clients ayant un solde non nul, calculé par rapport à ref_date (aujourd'hui si non
    fourni). Si ref_date est fourni, seules les factures datées au plus tard à ref_date
    sont incluses (pour reproduire l'état tel qu'il était à la fin du mois choisi)."""
    conn = get_conn()
    clients = conn.execute("SELECT name FROM clients ORDER BY name COLLATE NOCASE").fetchall()
    rows = []
    ref_str = ref_date.strftime('%Y-%m-%d') if ref_date else None
    for c in clients:
        invs = conn.execute("SELECT * FROM invoices WHERE client_name=?", (c['name'],)).fetchall()
        if not invs:
            continue
        if ref_str:
            invs = [i for i in invs if (i['date_facture'] or '') <= ref_str]
        if not invs:
            continue
        totals = sum_totals(invoices_with_buckets(invs, ref_date))
        if abs(totals['montant']) < 0.005:
            continue
        rows.append({'name': c['name'], **totals})
    conn.close()
    rows.sort(key=lambda r: r['name'].lower())
    return rows


def generate_aging_report_pdf(rows, ref_date=None, period_label=None):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Table, TableStyle, Paragraph, Spacer
    from reportlab.platypus.flowables import HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader

    ref_date = ref_date or datetime.date.today()
    ref_str = ref_date.strftime('%Y-%m-%d')

    report_dir = PDF_DIR / "Rapports_mensuels"
    report_dir.mkdir(exist_ok=True)
    pdf_path = report_dir / f"Rapport_age_{ref_str}.pdf"

    page_w, page_h = letter
    left_margin = right_margin = 18 * mm
    bottom_margin = 18 * mm
    header_reserved = 50  # mm

    styles = getSampleStyleSheet()
    footer_style = ParagraphStyle('footer', parent=styles['Normal'], fontSize=10)

    emission_date = datetime.date.today().strftime('%Y-%m-%d')
    sous_titre = f"Tous les clients — soldes en date du {ref_str}" + (f" ({period_label})" if period_label else "")

    def draw_header(canvas, doc_):
        canvas.saveState()
        x = left_margin
        top = page_h - 20 * mm
        canvas.setFont('Helvetica-Bold', 16)
        canvas.drawString(x, top, "RAPPORT D'ÂGE DES COMPTES À RECEVOIR")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 9 * mm, "Généré le :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 22 * mm, top - 9 * mm, emission_date)
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x, top - 14 * mm, sous_titre)

        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            logo_w = 50 * mm
            logo_h = logo_w * ih / iw
            canvas.drawImage(img, page_w - right_margin - logo_w, top - logo_h + 2 * mm,
                              width=logo_w, height=logo_h, mask='auto')

        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.setLineWidth(0.5)
        rule_y = top - 18 * mm
        canvas.line(left_margin, rule_y, page_w - right_margin, rule_y)
        canvas.restoreState()

    def draw_plain(canvas, doc_):
        pass

    frame_first = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                         page_h - bottom_margin - header_reserved * mm, id='first')
    frame_rest = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                        page_h - bottom_margin - 15 * mm, id='rest')

    doc = BaseDocTemplate(str(pdf_path), pagesize=letter)
    doc.addPageTemplates([
        PageTemplate(id='First', frames=[frame_first], onPage=draw_header),
        PageTemplate(id='Rest', frames=[frame_rest], onPage=draw_plain),
    ])

    story = []
    if not rows:
        story.append(Paragraph("Aucun client avec un solde dû.", styles['Normal']))
    else:
        data = [["Client", "0 – 30 j", "31 – 60 j", "61 – 90 j", "90+ j", "Total"]]
        grand = {'g': 0.0, 'h': 0.0, 'i': 0.0, 'j': 0.0, 'montant': 0.0}
        for r in rows:
            data.append([
                r['name'],
                f"{r['g']:,.2f} $", f"{r['h']:,.2f} $", f"{r['i']:,.2f} $", f"{r['j']:,.2f} $",
                f"{r['montant']:,.2f} $",
            ])
            for k in ('g', 'h', 'i', 'j', 'montant'):
                grand[k] += r[k]
        data.append([
            "TOTAL — tous les clients",
            f"{grand['g']:,.2f} $", f"{grand['h']:,.2f} $", f"{grand['i']:,.2f} $", f"{grand['j']:,.2f} $",
            f"{grand['montant']:,.2f} $",
        ])

        t = Table(data, colWidths=[55 * mm, 26 * mm, 26 * mm, 26 * mm, 26 * mm, 26 * mm], repeatRows=1)
        t.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8.5),
            ('GRID', (0, 0), (-1, -2), 0.5, colors.black),
            ('LINEABOVE', (0, -1), (-1, -1), 0.75, colors.black),
            ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
            ('ALIGN', (0, 0), (0, -1), 'LEFT'),
            ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#f3f4f6')),
        ]))
        story.append(t)
        story.append(Spacer(1, 4 * mm))
        story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))
        story.append(Spacer(1, 3 * mm))
        story.append(Paragraph(
            f"<b>{len(rows)} client(s) avec solde dû — total général : {grand['montant']:,.2f} $</b>",
            footer_style))

    story.append(_pdf_disclaimer())
    doc.build(story)
    return pdf_path


def generate_credit_accounts_pdf(rows, title, subtitle, filename_stub):
    """Génère un PDF listant les comptes de crédit (client / limite / solde /
    dépôt) avec le logo en haut à droite, sur le même modèle que les autres
    rapports (état de compte, rapport d'âge, etc.). `rows` doit contenir des
    dicts avec au moins display_name (ou prenom_entreprise/nom), credit_limit,
    solde, deposit."""
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Table, TableStyle, Paragraph, Spacer
    from reportlab.platypus.flowables import HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader

    report_dir = PDF_DIR / "Rapports_comptes_credit"
    report_dir.mkdir(exist_ok=True)
    safe_stub = re.sub(r'[^A-Za-z0-9_\-]+', '_', filename_stub)
    pdf_path = report_dir / f"{safe_stub}.pdf"

    page_w, page_h = letter
    left_margin = right_margin = 18 * mm
    bottom_margin = 18 * mm
    header_reserved = 50  # mm

    styles = getSampleStyleSheet()
    footer_style = ParagraphStyle('footer', parent=styles['Normal'], fontSize=10)
    emission_date = datetime.date.today().strftime('%Y-%m-%d')

    def draw_header(canvas, doc_):
        canvas.saveState()
        x = left_margin
        top = page_h - 20 * mm
        canvas.setFont('Helvetica-Bold', 16)
        canvas.drawString(x, top, title)
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 9 * mm, "Généré le :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 22 * mm, top - 9 * mm, emission_date)
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x, top - 14 * mm, subtitle)

        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            logo_w = 50 * mm
            logo_h = logo_w * ih / iw
            canvas.drawImage(img, page_w - right_margin - logo_w, top - logo_h + 2 * mm,
                              width=logo_w, height=logo_h, mask='auto')

        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.setLineWidth(0.5)
        rule_y = top - 18 * mm
        canvas.line(left_margin, rule_y, page_w - right_margin, rule_y)
        canvas.restoreState()

    def draw_plain(canvas, doc_):
        pass

    frame_first = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                         page_h - bottom_margin - header_reserved * mm, id='first')
    frame_rest = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                        page_h - bottom_margin - 15 * mm, id='rest')

    doc = BaseDocTemplate(str(pdf_path), pagesize=letter)
    doc.addPageTemplates([
        PageTemplate(id='First', frames=[frame_first], onPage=draw_header),
        PageTemplate(id='Rest', frames=[frame_rest], onPage=draw_plain),
    ])

    story = []
    if not rows:
        story.append(Paragraph("Aucun client.", styles['Normal']))
    else:
        data = [["Client", "Limite de crédit", "Solde dû", "Dépôt"]]
        grand = {'credit_limit': 0.0, 'solde': 0.0, 'deposit': 0.0}
        for r in rows:
            name = r.get('display_name') or _credit_client_display_name(r)
            climit = r.get('credit_limit') or 0
            solde = r.get('solde') or 0
            deposit = r.get('deposit') or 0
            data.append([
                name,
                f"{climit:,.2f} $", f"{solde:,.2f} $", f"{deposit:,.2f} $",
            ])
            grand['credit_limit'] += climit
            grand['solde'] += solde
            grand['deposit'] += deposit
        data.append([
            "TOTAL",
            f"{grand['credit_limit']:,.2f} $", f"{grand['solde']:,.2f} $", f"{grand['deposit']:,.2f} $",
        ])

        t = Table(data, colWidths=[80 * mm, 35 * mm, 35 * mm, 35 * mm], repeatRows=1)
        t.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8.5),
            ('GRID', (0, 0), (-1, -2), 0.5, colors.black),
            ('LINEABOVE', (0, -1), (-1, -1), 0.75, colors.black),
            ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
            ('ALIGN', (0, 0), (0, -1), 'LEFT'),
            ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#f3f4f6')),
        ]))
        story.append(t)
        story.append(Spacer(1, 4 * mm))
        story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))
        story.append(Spacer(1, 3 * mm))
        story.append(Paragraph(
            f"<b>{len(rows)} client(s) — total dû : {grand['solde']:,.2f} $ — "
            f"total dépôts : {grand['deposit']:,.2f} $</b>",
            footer_style))

    story.append(_pdf_disclaimer())
    doc.build(story)
    return pdf_path


# ============================================================
# Envoi Outlook
# ============================================================
def send_via_outlook(to_email, subject, body, pdf_path, mode='draft', bcc_company=True):
    """mode: 'send' envoie directement, 'draft' ouvre le courriel dans Outlook pour
    relecture, 'draft_silent' l'enregistre dans le dossier Brouillons sans ouvrir de
    fenêtre (utilisé pour la création en lot de plusieurs brouillons à la fois)."""
    import win32com.client as win32
    outlook = win32.Dispatch('outlook.application')
    mail = outlook.CreateItem(0)
    mail.To = to_email
    if bcc_company and get_company_email():
        mail.BCC = get_company_email()
    mail.Subject = subject
    mail.Body = body
    if pdf_path:
        mail.Attachments.Add(str(pdf_path))
    if mode == 'send':
        mail.Send()
        return 'ENVOYÉ'
    elif mode == 'draft_silent':
        mail.Save()
        return 'BROUILLON'
    else:
        mail.Display()
        return 'BROUILLON'


# ============================================================
# Création/envoi en lot pour tous les clients avec solde dû
# ============================================================
_bulk_state = {
    "running": False, "mode": None, "total": 0, "done": 0, "ok": 0, "skipped": 0, "errors": [],
    "finished_at": None,
}
_bulk_lock = threading.Lock()


def _run_bulk(mode, username=None):
    """mode: 'draft_silent' (brouillons dans Outlook, à réviser) ou 'send'
    (envoi direct immédiat, sans révision — irréversible)."""
    import pythoncom
    pythoncom.CoInitialize()
    try:
        clients = [c for c in db_list_clients() if c['solde'] and c['solde'] > 0]
        _bulk_state.update({"running": True, "mode": mode, "total": len(clients), "done": 0,
                             "ok": 0, "skipped": 0, "errors": [], "finished_at": None})
        for c in clients:
            name = c['name']
            try:
                detail = db_client_detail(name)
                to_email = detail['info'].get('courriel') or ''
                if not to_email:
                    _bulk_state["skipped"] += 1
                    _bulk_state["errors"].append(f"{name} : pas de courriel, ignoré")
                    _bulk_state["done"] += 1
                    continue
                statement_number = db_next_statement_number()
                pdf_path = generate_statement_pdf(name, detail['info'], detail['invoices'],
                                                    detail['totals'], statement_number)
                subject = f"État de compte — {name} ({statement_number})"
                body = (
                    f"Bonjour,\n\nVeuillez trouver ci-joint votre état de compte au "
                    f"{datetime.date.today().strftime('%d/%m/%Y')}.\n\n"
                    f"Solde total : {detail['totals']['montant']:,.2f} $\n\n"
                    f"{get_email_closing_message()}\n\n{get_sender_signature()}"
                )
                statut = send_email(to_email, subject, body, pdf_path, mode=mode, purpose='ar')
                label = "Envoi en lot" if mode == 'send' else "Brouillon en lot"
                db_log_envoi(name, to_email, detail['totals']['montant'], statut,
                             f"{label} — {statement_number}")
                _bulk_state["ok"] += 1
            except Exception as e:
                _bulk_state["errors"].append(f"{name} : {e}")
            _bulk_state["done"] += 1
    finally:
        _bulk_state["running"] = False
        _bulk_state["finished_at"] = datetime.datetime.now().isoformat()
        label = "Envoi en lot" if mode == 'send' else "Brouillons en lot"
        db_add_audit(username, label,
                     f"{_bulk_state['ok']} envoyé(s), {_bulk_state['skipped']} ignoré(s), "
                     f"{len(_bulk_state['errors'])} erreur(s)")
        pythoncom.CoUninitialize()


# ============================================================
# Routes — licence
# ============================================================
@app.route('/activation')
def activation_page():
    status = get_license_status()
    if status['active']:
        # Licence valide : cette page devient une vue/renouvellement volontaire,
        # réservée à un administrateur ou à un utilisateur ayant la permission
        # "license", déjà connecté.
        if not (session.get('is_admin') or 'license' in (session.get('permissions') or [])):
            return redirect(url_for('index'))
    return render_template('activation.html', company=get_company_name(), status=status,
                            type_labels=licensing.TYPE_LABELS,
                            users_label=licensing.users_label(status.get('payload')),
                            max_users=licensing.max_users_of(status.get('payload')),
                            active_users=db_count_active_users(), core_label=licensing.CORE_LABEL,
                            modules=status.get('modules') or {}, module_names=licensing.MODULES,
                            locked=licensing.MODULES.get(request.args.get('module') or ''),
                            logged_in=bool(session.get('user_id')), app_name=APP_NAME, year=datetime.date.today().year,
                            bg_url=login_bg_url(), bg_mode=login_bg_mode(), video_url=login_video_url())


@app.route('/api/license/status')
def api_license_status():
    return jsonify(get_license_status())


@app.route('/api/license/activate', methods=['POST'])
def api_license_activate():
    data = request.json or {}
    code = (data.get('code') or '').strip()
    result = licensing.verify_license_code(code)
    if not result['ok']:
        return jsonify({'ok': False, 'error': result['error']}), 400

    payload = result['payload']
    expires = payload.get('expires')
    if expires:
        try:
            exp_date = datetime.date.fromisoformat(expires)
        except Exception:
            return jsonify({'ok': False, 'error': "Date d'expiration illisible dans ce code."}), 400
        today, clock_ok, local = get_trusted_today()
        if not clock_ok:
            return jsonify({'ok': False, 'error': _clock_problem_message(today, local)}), 400
        if exp_date < today:
            return jsonify({'ok': False, 'error':
                             f"Ce code de licence a expiré le {expires}. Demande un nouveau code."}), 400

    code = ''.join(code.split())
    meta_set('license_code', code)
    label = licensing.TYPE_LABELS.get(payload['type'], payload['type'])
    mods = licensing.modules_status(payload, get_trusted_today()[0])
    mods_txt = ', '.join(f"{m['label']} : " + (('à vie' if not m['expires'] else f"jusqu'au {m['expires']}") if m['included'] else 'non inclus')
                         for m in mods.values())
    username = session.get('username') or 'N/A (avant connexion)'
    db_add_audit(username, 'Licence activée',
                 f"{payload['licensee']} — {label}" +
                 (f" — expire le {expires}" if expires else " — à vie") +
                 f" — utilisateurs : {licensing.users_label(payload)} — {mods_txt}")
    return jsonify({'ok': True, 'payload': payload, 'type_label': label, 'modules': mods,
                    'users_label': licensing.users_label(payload)})


# ============================================================
# Routes — connexion / utilisateurs
# ============================================================
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = "Ta session a été fermée par un administrateur. Reconnecte-toi au besoin." if session.pop('kicked', None) else None
    if request.method == 'POST':
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        user = db_verify_login(username, password)
        if user:
            sec = db_user_security(user['id'])
            if sec and sec.get('mfa_required'):
                # 2FA exigée : le mot de passe est bon, il reste le code.
                session.clear()
                session['mfa_pending'] = user['id']
                session['mfa_ts'] = time.time()
                session['mfa_next'] = request.form.get('next') or ''
                if not sec.get('mfa_method'):
                    return redirect(url_for('login_mfa_setup'))
                if sec['mfa_method'] == 'email':
                    try:
                        mfa_send_email_code(sec)
                    except Exception as e:
                        traceback.print_exc()
                        db_add_audit(user['username'], '2FA : envoi du code impossible', str(e))
                return redirect(url_for('login_mfa'))
            return _finish_login(user, request.form.get('next'))
        error = "Nom d'utilisateur ou mot de passe incorrect."
        db_add_audit((request.form.get('username') or '?').strip()[:60], 'Connexion échouée', f"adresse {client_ip()}")
    nxt = request.args.get('next', '')
    try:
        emp_portal = license_module_active('rh')        # 1.39.1 : bouton « Espace employé » si le module RH est actif
    except Exception:
        emp_portal = False
    return render_template('login.html', app_name=APP_NAME, error=error, next=nxt, company=get_company_name(), emp_portal=emp_portal,
                            year=datetime.date.today().year, bg_url=login_bg_url(), bg_mode=login_bg_mode(), video_url=login_video_url())


# ------------------------------------------------------------
# Routes — sécurité des comptes (1.14.0)
# ------------------------------------------------------------
def _auth_render(mode, **kw):
    return render_template('auth.html', app_name=APP_NAME, mode=mode, year=datetime.date.today().year,
                           bg_url=login_bg_url(), bg_mode=login_bg_mode(), video_url=login_video_url(), **kw)


@app.route('/mot-de-passe-oublie', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        ident = request.form.get('ident', '')
        user = _find_user_for_reset(ident)
        if user and user.get('email'):
            token = db_create_reset_token(user['id'], client_ip())
            if token:
                link = request.host_url.rstrip('/') + url_for('reset_password', token=token)
                try:
                    _send_plain_email(user['email'], "Kubios — réinitialisation du mot de passe",
                                      f"Bonjour {user['username']},\n\nPour choisir un nouveau mot de passe, ouvrez ce lien :\n\n"
                                      f"{link}\n\nLe lien est valide 1 heure et ne fonctionne qu'une seule fois. "
                                      f"Si vous n'avez pas fait cette demande, ignorez ce courriel : votre mot de passe "
                                      f"ne change pas.\n\n{get_company_name()}")
                    db_add_audit(user['username'], 'Mot de passe oublié : lien envoyé', _mask_email(user['email']))
                except Exception as e:
                    traceback.print_exc()
                    db_add_audit(user['username'], 'Mot de passe oublié : envoi impossible', str(e))
            else:
                db_add_audit(user['username'], 'Mot de passe oublié : trop de demandes en 1 heure')
        elif user:
            db_add_audit(user['username'], 'Mot de passe oublié : aucun courriel au dossier')
        return _auth_render('forgot_sent')
    return _auth_render('forgot')


@app.route('/reinitialiser/<token>', methods=['GET', 'POST'])
def reset_password(token):
    user = db_reset_token_user(token)
    if user is None:
        return _auth_render('reset_invalid')
    error = None
    if request.method == 'POST':
        p1, p2 = request.form.get('password', ''), request.form.get('password2', '')
        if len(p1) < PASSWORD_MIN_LEN:
            error = f"Le mot de passe doit contenir au moins {PASSWORD_MIN_LEN} caractères."
        elif p1 != p2:
            error = "Les deux mots de passe ne sont pas identiques."
        else:
            db_use_reset_token(token, user['id'], p1)
            db_add_audit(user['username'], 'Mot de passe réinitialisé par lien courriel')
            return _auth_render('reset_done')
    return _auth_render('reset', username=user['username'], error=error, min_len=PASSWORD_MIN_LEN)


def _pending_user():
    uid, ts = session.get('mfa_pending'), session.get('mfa_ts') or 0
    if not uid or time.time() - ts > MFA_PENDING_TTL:
        return None
    u = db_user_security(uid)
    return u if u and u['active'] else None


@app.route('/connexion/verification', methods=['GET', 'POST'])
def login_mfa():
    user = _pending_user()
    if user is None:
        session.pop('mfa_pending', None)
        return redirect(url_for('login'))
    if not user['mfa_method']:
        return redirect(url_for('login_mfa_setup'))
    error, info = None, None
    # 1.35.0 : au choix à chaque connexion — l'application (si configurée) ou un code par courriel (si un courriel est inscrit)
    avail = [m for m in ('totp', 'email') if (m == 'totp' and user.get('mfa_secret')) or (m == 'email' and user.get('email'))]
    if user['mfa_method'] not in avail:
        avail.insert(0, user['mfa_method'])
    via = session.get('mfa_via') if session.get('mfa_via') in avail else user['mfa_method']
    want = request.args.get('via')
    if request.method == 'GET' and want in avail and want != via:
        via = want
        session['mfa_via'] = via
        if via == 'email':
            try:
                mfa_send_email_code(user)
                info = f"Un code vient d'être envoyé à {_mask_email(user['email'])}."
                db_add_audit(user['username'], '2FA : code demandé par courriel (au lieu de l\u2019application)')
            except Exception as e:
                error = f"Envoi impossible : {e}"
    if request.method == 'POST':
        if request.form.get('action') == 'resend' and via == 'email':
            try:
                mfa_send_email_code(user)
                info = f"Nouveau code envoyé à {_mask_email(user['email'])}."
            except Exception as e:
                error = f"Envoi impossible : {e}"
        else:
            ok, error = mfa_verify(user, request.form.get('code', ''), method=via)
            if ok:
                session.pop('mfa_via', None)
                return _finish_login(user, session.get('mfa_next'))
            db_add_audit(user['username'], '2FA : code refusé')
    return _auth_render('mfa', method=via, email=_mask_email(user.get('email')),
                        error=error, info=info, alt=[m for m in avail if m != via])


@app.route('/connexion/configurer-2fa', methods=['GET', 'POST'])
def login_mfa_setup():
    user = _pending_user()
    if user is None:
        return redirect(url_for('login'))
    if user['mfa_method']:
        return redirect(url_for('login_mfa'))
    step = request.values.get('step', 'choose')
    error = None
    if step == 'totp':
        secret = user['mfa_pending_secret']
        if not secret or request.method == 'GET':
            secret = _b32_secret()
            db_set_user_mfa(user['id'], mfa_pending_secret=secret)
            user['mfa_pending_secret'] = secret
        if request.method == 'POST':
            ok, error = mfa_verify(user, request.form.get('code', ''), method='totp', secret=secret)
            if ok:
                db_set_user_mfa(user['id'], mfa_method='totp', mfa_secret=secret, mfa_pending_secret=None)
                db_add_audit(user['username'], '2FA configurée (application)')
                return _finish_login(db_user_security(user['id']), session.get('mfa_next'))
        return _auth_render('setup_totp', qr=totp_qr_svg(user['username'], secret),
                            secret=' '.join(secret[i:i + 4] for i in range(0, len(secret), 4)), error=error)
    if step == 'email':
        if not user.get('email'):
            return _auth_render('setup_choose', error="Aucun courriel n'est inscrit à ton compte : demande à un "
                                                      "administrateur de l'ajouter, ou choisis l'application.",
                                has_email=False)
        if request.method == 'POST' and request.form.get('code'):
            ok, error = mfa_verify(user, request.form.get('code', ''), method='email')
            if ok:
                db_set_user_mfa(user['id'], mfa_method='email', mfa_pending_secret=None)
                db_add_audit(user['username'], '2FA configurée (courriel)')
                return _finish_login(db_user_security(user['id']), session.get('mfa_next'))
        elif request.method == 'GET' or request.form.get('action') == 'resend':
            try:
                mfa_send_email_code(user)
            except Exception as e:
                error = f"Envoi du code impossible : {e}"
        return _auth_render('setup_email', email=_mask_email(user['email']), error=error)
    return _auth_render('setup_choose', has_email=bool(user.get('email')), email=_mask_email(user.get('email')))


@app.route('/api/admin/security/users')
def api_admin_security_users():
    resp = admin_required_check()
    if resp is not None:
        return resp
    conn = get_conn()
    rows = [dict(r) for r in conn.execute("SELECT id, username, email, is_admin, active, mfa_required, mfa_method "
                                          "FROM users ORDER BY username COLLATE NOCASE").fetchall()]
    conn.close()
    return jsonify(rows)


_EMAIL_OK = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')


@app.route('/api/admin/security/users/<int:user_id>', methods=['POST'])
def api_admin_security_user(user_id):
    resp = admin_required_check()
    if resp is not None:
        return resp
    u = db_user_security(user_id)
    if u is None:
        return jsonify({'ok': False, 'error': 'Utilisateur introuvable.'}), 404
    data = request.get_json(silent=True) or {}
    if data.get('reset_mfa'):
        db_set_user_mfa(user_id, mfa_method=None, mfa_secret=None, mfa_pending_secret=None, mfa_last_step=0)
        conn = get_conn()
        conn.execute("DELETE FROM mfa_challenges WHERE user_id=?", (user_id,))
        conn.commit()
        conn.close()
        log_audit('2FA réinitialisée par un administrateur', u['username'])
        return jsonify({'ok': True})
    email = (data.get('email') or '').strip() or None
    if email and not _EMAIL_OK.match(email):
        return jsonify({'ok': False, 'error': f"Adresse invalide : {email}"}), 400
    req = 1 if data.get('mfa_required') else 0
    full_name = (data.get('full_name') or '').strip()[:80] or None
    db_set_user_mfa(user_id, email=email, mfa_required=req, full_name=full_name)
    if (u.get('full_name') or None) != full_name:
        log_audit('Nom complet modifié', f"{u['username']} — {full_name or 'aucun'}")
        if user_id == session.get('user_id'):
            session['full_name'] = full_name
    changes = []
    if (u.get('email') or None) != email:
        changes.append(f"courriel : {email or 'aucun'}")
    if bool(u.get('mfa_required')) != bool(req):
        changes.append("2FA " + ("obligatoire" if req else "non exigée"))
    if changes:
        log_audit('Sécurité du compte modifiée', f"{u['username']} — " + "; ".join(changes))
    return jsonify({'ok': True})


# ------------------------------------------------------------
# Routes — messages aux utilisateurs (1.15.0)
# ------------------------------------------------------------
def _ann_payload(data):
    msg = (data.get('message') or '').strip()
    if not msg:
        raise ValueError("Écris le message à afficher.")
    if len(msg) > 600:
        raise ValueError("Le message est trop long (600 caractères au maximum).")
    color = data.get('color') if data.get('color') in ANN_COLORS else 'yellow'
    start = (data.get('start_date') or '').strip() or datetime.date.today().isoformat()
    end = (data.get('end_date') or '').strip() or None
    try:
        datetime.date.fromisoformat(start)
        if end:
            datetime.date.fromisoformat(end)
    except ValueError:
        raise ValueError("Date invalide.")
    if end and end < start:
        raise ValueError("La date de fin est avant la date de début.")
    return msg, color, start, end


@app.route('/api/license-warning/ack', methods=['POST'])
def api_license_warning_ack():
    if session.pop('license_warn', None):
        st = get_license_status()
        db_add_audit(session.get('username') or '?', "Avis d'expiration de la licence confirmé",
                     f"{st.get('days_left')} jour(s) restant(s)")
    return jsonify({'ok': True})


@app.route('/admin/messages')
def announcements_page():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return render_template('announcements.html', company=get_company_name(), username=session.get('username'))


@app.route('/api/admin/announcements')
def api_list_announcements():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return jsonify(db_list_announcements())


@app.route('/api/admin/announcements', methods=['POST'])
def api_create_announcement():
    resp = admin_required_check()
    if resp is not None:
        return resp
    try:
        msg, color, start, end = _ann_payload(request.get_json(silent=True) or {})
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    conn = get_conn()
    conn.execute("INSERT INTO announcements(message, color, start_date, end_date, active, created_at, created_by, "
                 "updated_at) VALUES (?,?,?,?,1,?,?,?)", (msg, color, start, end, now, session.get('username'), now))
    conn.commit()
    conn.close()
    log_audit('Message aux utilisateurs publié', f"{color}, du {start} au {end or '(sans fin)'} : {msg[:120]}")
    return jsonify({'ok': True})


@app.route('/api/admin/announcements/<int:ann_id>', methods=['PUT', 'DELETE'])
def api_update_announcement(ann_id):
    resp = admin_required_check()
    if resp is not None:
        return resp
    conn = get_conn()
    a = conn.execute("SELECT * FROM announcements WHERE id=?", (ann_id,)).fetchone()
    if a is None:
        conn.close()
        return jsonify({'ok': False, 'error': 'Message introuvable.'}), 404
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    try:
        if request.method == 'DELETE':
            conn.execute("DELETE FROM announcements WHERE id=?", (ann_id,))
            conn.commit()
            log_audit('Message aux utilisateurs supprimé', a['message'][:120])
            return jsonify({'ok': True})
        data = request.get_json(silent=True) or {}
        if set(data) == {'active'}:
            conn.execute("UPDATE announcements SET active=?, updated_at=? WHERE id=?",
                         (1 if data['active'] else 0, now, ann_id))
            conn.commit()
            log_audit('Message aux utilisateurs ' + ('réactivé' if data['active'] else 'désactivé'), a['message'][:120])
            return jsonify({'ok': True})
        try:
            msg, color, start, end = _ann_payload(data)
        except ValueError as e:
            return jsonify({'ok': False, 'error': str(e)}), 400
        conn.execute("UPDATE announcements SET message=?, color=?, start_date=?, end_date=?, updated_at=? WHERE id=?",
                     (msg, color, start, end, now, ann_id))
        conn.commit()
        log_audit('Message aux utilisateurs modifié', f"{color}, du {start} au {end or '(sans fin)'} : {msg[:120]}")
        return jsonify({'ok': True})
    finally:
        conn.close()


# ------------------------------------------------------------
# Routes — sauvegardes complètes (1.16.0)
# ------------------------------------------------------------
@app.route('/sauvegardes')
def full_backups_page():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return render_template('backups.html', company=get_company_name(), username=session.get('username'))


@app.route('/api/full-backups')
def api_full_backups():
    resp = admin_required_check()
    if resp is not None:
        return resp
    cfg = fb_cfg()
    try:
        items = fb_list()
        du = shutil.disk_usage(fb_dir())
        dir_error = None
    except (OSError, RuntimeError) as e:
        items, du, dir_error = [], None, f"Dossier inaccessible : {e}"
    return jsonify({'settings': cfg, 'default_dir': str(FB_DEFAULT_DIR), 'backups': items,
                    'total_size': sum(b['size'] for b in items), 'free': du.free if du else None,
                    'dir_error': dir_error, 'last': meta_get('fb_last'), 'last_error': meta_get('fb_last_error'),
                    'notify_error': meta_get('fb_notify_error'),
                    'running': _fb_state['running'], 'progress': _fb_state['progress'], 'error': _fb_state['error']})


@app.route('/api/full-backups/settings', methods=['POST'])
def api_full_backups_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}
    try:
        hour = int(data.get('hour', 2))
        ret = int(data.get('retention', 30))
        if not 0 <= hour <= 23 or ret not in FB_RETENTIONS:
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': "Heure ou rétention invalide."}), 400
    emails = [e.strip() for e in re.split(r'[,;\s]+', data.get('notify_emails') or '') if e.strip()]
    bad = [e for e in emails if not _EMAIL_OK.match(e)]
    if bad:
        return jsonify({'ok': False, 'error': "Adresse courriel invalide : " + ", ".join(bad)}), 400
    mode = 'all' if data.get('notify_mode') == 'all' else 'fail'
    d = (data.get('dir') or '').strip() or str(FB_DEFAULT_DIR)
    try:
        p = Path(d)
        if not p.is_absolute():
            raise OSError("le chemin doit être complet (ex. E:\\Sauvegardes Kubios)")
        p.mkdir(parents=True, exist_ok=True)
        test = p / '.kubios_test'
        test.write_text('ok')
        test.unlink()
    except OSError as e:
        return jsonify({'ok': False, 'error': f"Dossier inutilisable : {e}"}), 400
    meta_set('fb_enabled', '1' if data.get('enabled', True) else '0')
    meta_set('fb_hour', hour)
    meta_set('fb_retention', ret)
    meta_set('fb_dir', '' if Path(d) == FB_DEFAULT_DIR else d)
    meta_set('fb_notify_emails', ','.join(emails))
    meta_set('fb_notify_mode', mode)
    log_audit('Paramètres des sauvegardes modifiés',
              f"{'activées' if data.get('enabled', True) else 'désactivées'} ; à {hour} h ; rétention {ret} jours ; dossier {d}"
              f" ; avis : {', '.join(emails) or 'aucun'} ({'à chaque sauvegarde' if mode == 'all' else 'échecs seulement'})")
    return jsonify({'ok': True})


@app.route('/api/full-backups/notify-test', methods=['POST'])
def api_full_backups_notify_test():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if not fb_cfg()['notify_emails']:
        return jsonify({'ok': False, 'error': "Inscris d'abord au moins une adresse, puis clique sur Enregistrer."}), 400
    sent, errors = fb_notify(True, test=True)
    log_audit('Avis de sauvegarde : courriel de test', f"{', '.join(sent) or 'aucun'}" + (f" ; erreurs : {'; '.join(errors)}" if errors else ""))
    return jsonify({'ok': bool(sent), 'sent': sent, 'errors': errors,
                    'error': "; ".join(errors) if errors and not sent else None})


@app.route('/api/full-backups/run', methods=['POST'])
def api_full_backups_run():
    resp = admin_required_check()
    if resp is not None:
        return resp
    try:
        res = full_backup('manuelle', session.get('username'))
    except RuntimeError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    except Exception as e:
        return jsonify({'ok': False, 'error': f"Sauvegarde impossible : {e}"}), 500
    return jsonify(dict(res, ok=True))


def _fb_path(name):
    if not FB_NAME_RE.match(name or ''):
        return None
    p = fb_dir() / name
    return p if p.exists() else None


@app.route('/api/full-backups/<name>/download')
def api_full_backups_download(name):
    resp = admin_required_check()
    if resp is not None:
        return resp
    p = _fb_path(name)
    if p is None:
        return jsonify({'error': 'Sauvegarde introuvable.'}), 404
    log_audit('Sauvegarde complète téléchargée', name)
    return send_file(str(p), as_attachment=True, download_name=name)


def _fb_restore_response(path, label):
    try:
        res = full_restore(path, session.get('username'), label)
    except RuntimeError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': f"Restauration impossible : {e}"}), 500
    session.clear()   # les comptes ont pu changer : on se reconnecte
    return jsonify(dict(res, ok=True))


@app.route('/api/full-backups/<name>/restore', methods=['POST'])
def api_full_backups_restore(name):
    resp = admin_required_check()
    if resp is not None:
        return resp
    if (request.get_json(silent=True) or {}).get('confirm') != 'RESTAURER':
        return jsonify({'ok': False, 'error': "Confirmation manquante."}), 400
    p = _fb_path(name)
    if p is None:
        return jsonify({'ok': False, 'error': 'Sauvegarde introuvable.'}), 404
    return _fb_restore_response(p, f"sauvegarde {name}")


@app.route('/api/full-backups/restore-upload', methods=['POST'])
def api_full_backups_restore_upload():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if request.form.get('confirm') != 'RESTAURER':
        return jsonify({'ok': False, 'error': "Confirmation manquante."}), 400
    f = request.files.get('file')
    if not f or not f.filename.lower().endswith('.zip'):
        return jsonify({'ok': False, 'error': "Choisis un fichier de sauvegarde Kubios (.zip)."}), 400
    tmp = Path(tempfile.mkstemp(suffix='.zip', prefix='kubios_upload_')[1])
    try:
        f.save(str(tmp))
        return _fb_restore_response(tmp, f"fichier téléversé {f.filename}")
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass


# ------------------------------------------------------------
# Routes — rapport des taxes (1.17.0)
# ------------------------------------------------------------
@app.route('/rapport-taxes')
def tax_report_page():
    resp = permission_required_check('tax_reports')
    if resp is not None:
        return resp
    return render_template('tax_report.html', company=get_company_name(), username=session.get('username'),
                           is_admin=session.get('is_admin'))


@app.route('/api/taxes/status')
def api_taxes_status():
    resp = permission_required_check('tax_reports')
    if resp is not None:
        return resp
    ss = _store_state
    conn = get_conn()
    shops = [dict(r) for r in conn.execute("SELECT shop_id id, name FROM ls_shops WHERE archived=0 ORDER BY name").fetchall()]
    conn.close()
    return jsonify({'connected': ls_config()['connected'], 'is_admin': bool(session.get('is_admin')),
                    'running': ss['running'], 'progress': ss['progress'], 'job': ss['kind'] if ss['running'] else None,
                    'error': _rep_state['error'] or (ss['error'] if not ss['running'] else None),
                    'result': _rep_state.get('taxes') if not ss['running'] else None, 'shops': shops})


@app.route('/api/taxes/report', methods=['POST'])
def api_taxes_report():
    resp = permission_required_check('tax_reports')
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}
    try:
        start, end = _rep_dates(data)
    except ValueError:
        return jsonify({'ok': False, 'error': "Dates invalides."}), 400
    if end < start:
        return jsonify({'ok': False, 'error': "La date de fin est avant la date de début."}), 400
    end = min(end, datetime.date.today())
    if start > end:
        return jsonify({'ok': False, 'error': "La période choisie est dans le futur."}), 400
    if (end - start).days > 800:
        return jsonify({'ok': False, 'error': "Période trop longue (maximum environ 2 ans)."}), 400
    shop_id = str(data.get('shop_id') or '').strip()
    refresh = bool(data.get('refresh'))
    if refresh:
        # Relire TOUTE la période dans Lightspeed (ventes modifiées, annulées ou
        # retournées après coup) : les lignes gardées sont remplacées.
        if not ls_config()['connected']:
            return jsonify({'ok': False, 'error': "Kubios n'est pas connecté à Lightspeed (Administration → Lightspeed)."}), 400
        missing = [start + datetime.timedelta(days=i) for i in range((end - start).days + 1)]
    else:
        missing = store_missing_days(start, end, need_tax=True)
    if missing and not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Des jours de cette période ne sont pas encore dans Kubios et Kubios n'est "
                                              "pas connecté à Lightspeed (Administration → Lightspeed)."}), 400
    user = session.get('username')
    _rep_state['error'] = None
    try:
        ready = _rep_run_local('taxes', missing, lambda: local_tax_report(start, end, shop_id, user), user)
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    log_audit('Rapport des taxes ' + ('régénéré à partir de Lightspeed' if refresh else 'demandé'),
              f"{start} au {end}" + (f", magasin #{shop_id}" if shop_id else ""))
    return jsonify({'ok': True, 'ready': ready, 'missing': len(missing), 'refresh': refresh})


@app.route('/api/taxes/export/pdf')
def api_taxes_export_pdf():
    resp = permission_required_check('tax_reports')
    if resp is not None:
        return resp
    r = _rep_state.get('taxes')
    if not r:
        return jsonify({'error': "Aucun rapport à exporter : génère-le d'abord."}), 400
    path = export_tax_pdf(r)
    return send_file(str(path), as_attachment=True, download_name=path.name)


# ------------------------------------------------------------
# Routes — valeur de l'inventaire (1.19.0)
# ------------------------------------------------------------
@app.route('/valeur-inventaire')
def inventory_report_page():
    resp = permission_required_check('inventory_reports')
    if resp is not None:
        return resp
    return render_template('inventory.html', company=get_company_name(), username=session.get('username'),
                           is_admin=session.get('is_admin'))


@app.route('/api/inventory/status')
def api_inventory_status():
    resp = permission_required_check('inventory_reports')
    if resp is not None:
        return resp
    conn = get_conn()
    shops = [dict(r) for r in conn.execute("SELECT shop_id id, name FROM ls_shops WHERE archived=0 ORDER BY name").fetchall()]
    conn.close()
    st = _inv_state
    out = {'connected': ls_config()['connected'], 'is_admin': bool(session.get('is_admin')), 'running': st['running'],
           'progress': st['progress'], 'error': st['error'] if not st['running'] else None, 'last_id': st['last_id'],
           'history': db_inventory_history(), 'shops': shops, 'last_error': meta_get('inv_last_error'),
           'last_send': st['last_send'] if not st['running'] else None, 'recipients': inv_cfg()['recipients']}
    if session.get('is_admin'):
        out['settings'] = inv_cfg()
    return jsonify(out)


@app.route('/api/inventory/snapshot', methods=['POST'])
def api_inventory_take():
    resp = permission_required_check('inventory_reports')
    if resp is not None:
        return resp
    if not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Kubios n'est pas connecté à Lightspeed (Administration → Lightspeed)."}), 400
    data = request.get_json(silent=True) or {}
    shop_id = str(data.get('shop_id') or '').strip()
    send_to = sorted({e.strip() for e in (data.get('send_to') or []) if isinstance(e, str) and e.strip()})
    bad = [e for e in send_to if not _EMAIL_RE.match(e)]
    if bad:
        return jsonify({'ok': False, 'error': "Adresse invalide : " + ", ".join(bad)}), 400
    if data.get('send') and not send_to:
        return jsonify({'ok': False, 'error': "Choisis au moins un destinataire."}), 400
    user = session.get('username')
    then = None
    if send_to:
        def then(sid):
            sent, errors = send_inventory_email(sid, send_to, user)
            _inv_state['last_send'] = {'snapshot_id': sid, 'sent': sent, 'errors': errors}
    try:
        start_inventory_job('manuel', user, shop_id, then=then)
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    return jsonify({'ok': True})


@app.route('/api/inventory/snapshot/<int:sid>')
def api_inventory_get(sid):
    resp = permission_required_check('inventory_reports')
    if resp is not None:
        return resp
    s = db_inventory_snapshot(sid)
    return jsonify(s) if s else (jsonify({'error': 'Instantané introuvable.'}), 404)


@app.route('/api/inventory/snapshot/<int:sid>', methods=['DELETE'])
def api_inventory_delete(sid):
    resp = admin_required_check()
    if resp is not None:
        return resp
    conn = get_conn()
    s = conn.execute("SELECT taken_at, cost_value FROM inventory_snapshots WHERE id=?", (sid,)).fetchone()
    conn.execute("DELETE FROM inventory_snapshot_lines WHERE snapshot_id=?", (sid,))
    conn.execute("DELETE FROM inventory_snapshots WHERE id=?", (sid,))
    conn.commit()
    conn.close()
    if s:
        log_audit("Instantané de l'inventaire supprimé", f"{s['taken_at'][:16]} — {_fmt_money_fr(s['cost_value'])}")
    return jsonify({'ok': True})


@app.route('/api/inventory/snapshot/<int:sid>/pdf')
def api_inventory_pdf(sid):
    resp = permission_required_check('inventory_reports')
    if resp is not None:
        return resp
    if not db_inventory_snapshot(sid):
        return jsonify({'error': 'Instantané introuvable.'}), 404
    path = export_inventory_pdf(sid)
    return send_file(str(path), as_attachment=True, download_name=path.name)


@app.route('/api/inventory/snapshot/<int:sid>/send', methods=['POST'])
def api_inventory_send(sid):
    resp = permission_required_check('inventory_reports')
    if resp is not None:
        return resp
    emails = sorted({e.strip() for e in ((request.get_json(silent=True) or {}).get('emails') or []) if isinstance(e, str) and e.strip()})
    bad = [e for e in emails if not _EMAIL_RE.match(e)]
    if not emails or bad:
        return jsonify({'ok': False, 'error': ("Adresse invalide : " + ", ".join(bad)) if bad else "Choisis au moins un destinataire."}), 400
    if not db_inventory_snapshot(sid):
        return jsonify({'ok': False, 'error': 'Instantané introuvable.'}), 404
    sent, errors = send_inventory_email(sid, emails, session.get('username'))
    return jsonify({'ok': bool(sent), 'sent': sent, 'errors': errors, 'error': "; ".join(errors) if errors and not sent else None})


@app.route('/api/inventory/settings', methods=['POST'])
def api_inventory_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    recips = sorted({e.strip() for e in (d.get('recipients') or []) if isinstance(e, str) and e.strip()})
    bad = [e for e in recips if not _EMAIL_RE.match(e)]
    if bad:
        return jsonify({'ok': False, 'error': "Adresse invalide : " + ", ".join(bad)}), 400
    day = str(d.get('day') or '1')
    try:
        hour = int(d.get('hour', 6))
        if day != 'last' and not 1 <= int(day) <= 28 or not 0 <= hour <= 23:
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': "Jour ou heure invalide."}), 400
    meta_set('inv_auto', '1' if d.get('auto') else '0')
    meta_set('inv_day', day)
    meta_set('inv_hour', hour)
    meta_set('inv_method', d.get('method') if d.get('method') in INV_METHODS else 'avg')
    meta_set('inv_recipients', json.dumps(recips))
    log_audit("Paramètres de la valeur de l'inventaire modifiés",
              (f"chaque mois le {'dernier jour' if day == 'last' else day} à {hour} h" if d.get('auto') else "planification désactivée")
              + f" ; {INV_METHODS.get(d.get('method'), 'coût moyen')} ; destinataires : {', '.join(recips) or 'aucun'}")
    return jsonify({'ok': True})


# ------------------------------------------------------------
# Routes — tableau de bord 3D (1.20.0)
# ------------------------------------------------------------
@app.route('/tableau-de-bord-3d')
def dashboard3d_page():
    resp = permission_required_check('dashboard3d')
    if resp is not None:
        return resp
    local = three_local_ready()
    if not local:
        ensure_three_vendor_async()          # la prochaine ouverture utilisera la copie locale
    return render_template('dashboard3d.html', company=get_company_name(), three_local=local)


@app.route('/api/admin/three', methods=['GET', 'POST'])
def api_admin_three():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if request.method == 'POST':
        ok, msg = download_three_vendor()
        return jsonify({'ok': ok, 'message': msg, 'installed': three_local_ready(), 'version': THREE_VERSION}), (200 if ok else 502)
    return jsonify({'installed': three_local_ready(), 'version': THREE_VERSION, 'running': _three_state['running'],
                    'error': _three_state['error'], 'folder': str(THREE_VENDOR_DIR),
                    'files': [f[0] for f in THREE_FILES]})


@app.route('/api/dashboard3d/data')
def api_dashboard3d_data():
    resp = permission_required_check('dashboard3d')
    if resp is not None:
        return resp
    return jsonify(dashboard3d_data(request.args.get('periode', 'mois_dernier')))


# ------------------------------------------------------------
# Routes — Gestion Atelier (1.21.0)
# ------------------------------------------------------------
@app.route('/atelier/punch')
def atelier_punch_page():
    cle = request.args.get('cle')
    if cle:                                   # lien direct : autorise cette tablette
        if secrets.compare_digest(cle, kiosk_link_token()):
            db_add_audit('Poste de punch', 'Tablette autorisée (lien direct)', client_ip())
            return kiosk_authorize(redirect(url_for('atelier_punch_page')))
        return render_template('atelier_kiosk_login.html', company=get_company_name(), error="Ce lien n'est plus valide.")
    if not kiosk_allowed():
        return render_template('atelier_kiosk_login.html', company=get_company_name(), error=None)
    return render_template('atelier_punch.html', company=get_company_name(), device_only=not session.get('user_id'))


@app.route('/atelier')
def atelier_page():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    return render_template('atelier.html', company=get_company_name(), is_admin=bool(session.get('is_admin')),
                           can_profit=bool(session.get('is_admin')) or 'atelier_profit' in (session.get('permissions') or []),
                           can_rh=bool(session.get('is_admin')) or 'rh' in (session.get('permissions') or []))


@app.route('/api/atelier/kiosk')
def api_atelier_kiosk():
    if not kiosk_allowed():
        return jsonify({'error': 'Poste de punch non autorisé.'}), 401
    conn = get_conn()
    try:
        return jsonify({'mechanics': [at_mech_state(conn, m) for m in at_mechanics()], 'now': _at_now(), 'idle_minutes': kiosk_idle_minutes()})
    finally:
        conn.close()


@app.route('/api/atelier/punch', methods=['POST'])
def api_atelier_punch():
    if not kiosk_allowed():
        return jsonify({'error': 'Poste de punch non autorisé.'}), 401
    d = request.get_json(silent=True) or {}
    try:
        mid = int(d.get('mechanic_id'))
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Mécanicien inconnu.'}), 400
    m, err = at_verify_pin(mid, d.get('pin'))
    if err:
        return jsonify({'ok': False, 'error': err, 'pin': True}), 403
    if d.get('action') == 'login':
        conn = get_conn()
        try:
            return jsonify({'ok': True, 'state': at_mech_state(conn, m)})
        finally:
            conn.close()
    return jsonify(at_punch(mid, d.get('action'), d.get('job'), d.get('mode')))


@app.route('/api/atelier/live')
def api_atelier_live():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    return jsonify(at_live(request.args))


@app.route('/api/atelier/punches')
def api_atelier_punches():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d0, d1 = _at_period(request.args)
    a, b = d0.strftime('%Y-%m-%d 00:00:00'), (d1 + datetime.timedelta(days=1)).strftime('%Y-%m-%d 00:00:00')
    conn = get_conn()
    rows = [dict(r) for r in conn.execute("SELECT p.*, m.name FROM shop_punches p JOIN shop_mechanics m ON m.id=p.mechanic_id "
                                          "WHERE p.start_at < ? AND (p.end_at IS NULL OR p.end_at >= ?) ORDER BY p.start_at DESC",
                                          (b, a)).fetchall()]
    conn.close()
    return jsonify({'start': d0.isoformat(), 'end': d1.isoformat(), 'punches': rows,
                    'mechanics': [{'id': m['id'], 'name': m['name']} for m in at_mechanics(True)]})


def _at_parse_dt(v):
    v = (v or '').strip().replace('T', ' ')
    if not v:
        return None
    if len(v) == 16:
        v += ':00'
    return _at_dt(v).strftime(AT_FMT)


@app.route('/api/atelier/punches', methods=['POST'])
@app.route('/api/atelier/punches/<int:pid>', methods=['PUT', 'DELETE'])
def api_atelier_punch_edit(pid=None):
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        old = dict(conn.execute("SELECT * FROM shop_punches WHERE id=?", (pid,)).fetchone() or {}) if pid else None
        if pid and not old:
            return jsonify({'ok': False, 'error': 'Punch introuvable.'}), 404
        if request.method == 'DELETE':
            conn.execute("DELETE FROM shop_punches WHERE id=?", (pid,))
            conn.commit()
            log_audit('Atelier : punch supprimé', f"bon {old['job']}, {old['start_at']} → {old['end_at'] or 'ouvert'}")
            return jsonify({'ok': True})
        d = request.get_json(silent=True) or {}
        try:
            start, end = _at_parse_dt(d.get('start_at')), _at_parse_dt(d.get('end_at'))
            mid = int(d.get('mechanic_id') or (old or {}).get('mechanic_id'))
        except (TypeError, ValueError):
            return jsonify({'ok': False, 'error': 'Date ou mécanicien invalide.'}), 400
        job = at_norm_job(d.get('job') or (old or {}).get('job'))
        if not start or not job:
            return jsonify({'ok': False, 'error': 'Le bon et le début sont requis.'}), 400
        if end and end <= start:
            return jsonify({'ok': False, 'error': 'La fin doit être après le début.'}), 400
        ended_by = d.get('ended_by') if d.get('ended_by') in ('pause', 'fin') else ('fin' if end else None)
        if pid:
            conn.execute("UPDATE shop_punches SET mechanic_id=?, job=?, start_at=?, end_at=?, ended_by=?, corrected_by=?, corrected_at=? WHERE id=?",
                         (mid, job, start, end, ended_by, session.get('username'), _at_now(), pid))
            conn.commit()
            log_audit('Atelier : punch corrigé', f"bon {old['job']} {old['start_at']} → {old['end_at'] or 'ouvert'} devient bon {job} {start} → {end or 'ouvert'}")
        else:
            conn.execute("INSERT INTO shop_punches(mechanic_id, job, start_at, end_at, ended_by, created_by, corrected_by, corrected_at) "
                         "VALUES (?,?,?,?,?,?,?,?)", (mid, job, start, end, ended_by, 'manuel', session.get('username'), _at_now()))
            conn.commit()
            log_audit('Atelier : punch ajouté', f"bon {job} {start} → {end or 'ouvert'}")
        conn.commit()
        return jsonify({'ok': True})
    finally:
        conn.close()


@app.route('/api/atelier/jobs/<job>/manual', methods=['GET', 'POST'])
def api_atelier_job_manual(job):
    """1.41.0 : le responsable ajoute du temps oublié sur un bon et/ou le termine."""
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    job = at_norm_job(job)
    conn = get_conn()
    try:
        j = conn.execute("SELECT * FROM shop_jobs WHERE job=?", (job,)).fetchone()
        open_p = [dict(r) for r in conn.execute(
            "SELECT p.id, p.start_at, p.mechanic_id, m.name FROM shop_punches p LEFT JOIN shop_mechanics m ON m.id=p.mechanic_id "
            "WHERE p.job=? AND p.end_at IS NULL", (job,)).fetchall()]
        if request.method == 'GET':
            m = re.search(r'Service\s+(\d+)\s*min', (j['work'] if j else '') or '', re.I)
            return jsonify({'ok': True, 'job': job, 'exists': bool(j), 'status': j['status'] if j else None, 'mechanic_id': j['mechanic_id'] if j else None,
                            'seconds': _at_job_seconds(conn, job), 'suggest_minutes': int(m.group(1)) if m else None, 'open': open_p})
        d = request.get_json(silent=True) or {}
        try:
            minutes = int(d.get('minutes') or 0)
        except (TypeError, ValueError):
            return jsonify({'ok': False, 'error': 'Durée invalide.'}), 400
        finish = bool(d.get('finish'))
        reason = str(d.get('reason') or '').strip()[:200]
        if minutes < 0 or minutes > 16 * 60:
            return jsonify({'ok': False, 'error': 'La durée doit être entre 1 minute et 16 heures.'}), 400
        if not minutes and not finish:
            return jsonify({'ok': False, 'error': 'Indique une durée, ou coche « Marquer le bon terminé ».'}), 400
        if minutes and not reason:
            return jsonify({'ok': False, 'error': 'Indique la raison (ex. oubli de punch).'}), 400
        who = current_display_name()
        done = []
        if minutes:
            try:
                mid = int(d.get('mechanic_id'))
                start = datetime.datetime.strptime(f"{d.get('date')} {d.get('start')}", '%Y-%m-%d %H:%M')
            except (TypeError, ValueError):
                return jsonify({'ok': False, 'error': 'Choisis le mécanicien, la date et l\u2019heure de début.'}), 400
            if not conn.execute("SELECT 1 FROM shop_mechanics WHERE id=?", (mid,)).fetchone():
                return jsonify({'ok': False, 'error': 'Mécanicien introuvable.'}), 400
            end = start + datetime.timedelta(minutes=minutes)
            if end > datetime.datetime.now() + datetime.timedelta(minutes=5):
                return jsonify({'ok': False, 'error': 'Ce temps finirait dans le futur : vérifie la date et l\u2019heure de début.'}), 400
            clash = conn.execute("SELECT job, start_at, end_at FROM shop_punches WHERE mechanic_id=? AND start_at < ? AND COALESCE(end_at, ?) > ?",
                                 (mid, end.strftime(AT_FMT), _at_now(), start.strftime(AT_FMT))).fetchone()
            if clash:
                return jsonify({'ok': False, 'error': f"Ce mécanicien a déjà du temps punché dans cette plage (bon {clash['job']}, "
                                                      f"{clash['start_at'][11:16]} à {(clash['end_at'] or 'en cours')[11:16]}). Choisis une autre heure de début."}), 400
            conn.execute("INSERT INTO shop_punches(mechanic_id, job, start_at, end_at, ended_by, created_by, corrected_by, corrected_at) VALUES (?,?,?,?,?,?,?,?)",
                         (mid, job, start.strftime(AT_FMT), end.strftime(AT_FMT), 'fin' if finish else 'pause', 'manuel (responsable)', who, _at_now()))
            done.append(f"{minutes} min ajoutées le {start:%Y-%m-%d} de {start:%H:%M} à {end:%H:%M} (mécanicien #{mid}) — {reason}")
        if finish:
            closes = d.get('close') or {}
            for p in open_p:                                   # punch oublié ouvert : fermé à l'heure indiquée par le responsable
                try:
                    end_p = datetime.datetime.strptime(str(closes.get(str(p['id'])) or ''), '%Y-%m-%dT%H:%M')
                except ValueError:
                    return jsonify({'ok': False, 'error': f"Indique l'heure de fin du punch oublié de {p['name'] or 'ce mécanicien'}."}), 400
                st_p = datetime.datetime.strptime(p['start_at'], AT_FMT)
                if end_p <= st_p or end_p > datetime.datetime.now() + datetime.timedelta(minutes=1):
                    return jsonify({'ok': False, 'error': f"L'heure de fin du punch de {p['name'] or 'ce mécanicien'} doit être après son début "
                                                          f"({p['start_at'][:16]}) et pas dans le futur."}), 400
                conn.execute("UPDATE shop_punches SET end_at=?, ended_by='fin', corrected_by=?, corrected_at=? WHERE id=?",
                             (end_p.strftime(AT_FMT), who, _at_now(), p['id']))
                done.append(f"punch oublié de {p['name'] or 'mécanicien'} fermé : {p['start_at'][:16]} → {end_p:%Y-%m-%d %H:%M}")
            if j:
                conn.execute("UPDATE shop_jobs SET status='termine', updated_at=? WHERE job=?", (_at_now(), job))
            else:
                conn.execute("INSERT INTO shop_jobs(job, status, created_by, created_at, updated_at, position, priority) VALUES (?,?,?,?,?,?, 'normal')",
                             (job, 'termine', who, _at_now(), _at_now(), _at_next_position(conn, None)))
            done.append('bon marqué terminé')
        conn.commit()
        secs = _at_job_seconds(conn, job)
    finally:
        conn.close()
    log_audit('Atelier : temps ajouté / bon terminé par le responsable', f"bon {job} — " + ' ; '.join(done))
    return jsonify({'ok': True, 'seconds': secs, 'done': done})


@app.route('/api/atelier/profit')
def api_atelier_profit():
    resp = permission_required_check('atelier_profit')
    if resp is not None:
        return resp
    return jsonify(at_profit_compare(request.args))


@app.route('/api/atelier/billing/<job>', methods=['POST', 'DELETE'])
def api_atelier_billing(job):
    resp = permission_required_check('atelier_profit')
    if resp is not None:
        return resp
    job = at_norm_job(job)
    conn = get_conn()
    try:
        if request.method == 'DELETE':
            conn.execute("DELETE FROM shop_billing WHERE job=?", (job,))
            conn.commit()
            log_audit('Atelier : facturé manuel retiré', f"bon {job}")
            return jsonify({'ok': True})
        d = request.get_json(silent=True) or {}
        try:
            minutes, amount = float(d.get('minutes') or 0), float(d.get('amount') or 0)
        except (TypeError, ValueError):
            return jsonify({'ok': False, 'error': 'Montant ou minutes invalides.'}), 400
        conn.execute("INSERT OR REPLACE INTO shop_billing(job, billed_minutes, billed_amount, note, username, updated_at) VALUES (?,?,?,?,?,?)",
                     (job, minutes, amount, (d.get('note') or '')[:200], session.get('username'), _at_now()))
        conn.commit()
        log_audit('Atelier : facturé saisi à la main', f"bon {job} : {minutes:g} min, {_fmt_money_fr(amount)}")
        return jsonify({'ok': True})
    finally:
        conn.close()


@app.route('/api/atelier/jobs/<job>/move', methods=['POST'])
def api_atelier_job_move(job):
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    up = (request.get_json(silent=True) or {}).get('dir') == 'up'
    job = at_norm_job(job)
    conn = get_conn()
    try:
        j = conn.execute("SELECT * FROM shop_jobs WHERE job=?", (job,)).fetchone()
        if not j:
            return jsonify({'ok': False, 'error': 'Bon introuvable.'}), 404
        lst = [r['job'] for r in conn.execute("SELECT job FROM shop_jobs WHERE COALESCE(mechanic_id,0)=COALESCE(?,0) "
                                              "AND status IN ('ouvert','en_cours') ORDER BY position, COALESCE(due_date,'9999'), created_at",
                                              (j['mechanic_id'],)).fetchall()]
        i = lst.index(job) if job in lst else -1
        k = i - 1 if up else i + 1
        if i < 0 or k < 0 or k >= len(lst):
            return jsonify({'ok': True})
        lst[i], lst[k] = lst[k], lst[i]
        for pos, jb in enumerate(lst, start=1):           # renumérote proprement la liste du mécanicien
            conn.execute("UPDATE shop_jobs SET position=? WHERE job=?", (pos, jb))
        conn.commit()
        return jsonify({'ok': True})
    finally:
        conn.close()


@app.route('/api/atelier/jobs/<job>/place', methods=['POST'])
def api_atelier_job_place(job):
    """Glisser-déposer : attribue le bon à un mécanicien (ou à personne), à un rang de sa liste,
    et, si « work_date » est fourni, à une journée de travail (vide = à planifier)."""
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    job = at_norm_job(job)
    try:
        mid = int(d['mechanic_id']) if d.get('mechanic_id') not in (None, '') else None
        index = int(d['index']) if d.get('index') not in (None, '') else None
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Valeurs invalides.'}), 400
    wd = None
    if 'work_date' in d:
        wd = (d.get('work_date') or '').strip() or ''
        if wd:
            try:
                datetime.date.fromisoformat(wd)
            except ValueError:
                return jsonify({'ok': False, 'error': 'Date de travail invalide.'}), 400
    conn = get_conn()
    try:
        j = conn.execute("SELECT * FROM shop_jobs WHERE job=?", (job,)).fetchone()
        if not j:
            return jsonify({'ok': False, 'error': 'Bon introuvable.'}), 404
        if mid is not None and not conn.execute("SELECT 1 FROM shop_mechanics WHERE id=?", (mid,)).fetchone():
            return jsonify({'ok': False, 'error': 'Mécanicien introuvable.'}), 404
        lst = [r['job'] for r in conn.execute("SELECT job FROM shop_jobs WHERE COALESCE(mechanic_id,0)=COALESCE(?,0) AND job<>? "
                                              "AND status IN ('ouvert','en_cours') ORDER BY position, COALESCE(due_date,'9999'), created_at",
                                              (mid, job)).fetchall()]
        lst.insert(len(lst) if index is None else max(0, min(index, len(lst))), job)
        for pos, jb in enumerate(lst, start=1):
            conn.execute("UPDATE shop_jobs SET position=? WHERE job=?", (pos, jb))
        conn.execute("UPDATE shop_jobs SET mechanic_id=?, updated_at=?" + (", work_date=?" if wd is not None else "") + " WHERE job=?",
                     ((mid, _at_now()) + ((wd or None,) if wd is not None else ()) + (job,)))
        conn.commit()
        names = {m['id']: m['name'] for m in at_mechanics(True)}
    finally:
        conn.close()
    changes = []
    if j['mechanic_id'] != mid:
        changes.append('attribué à ' + names.get(mid, 'personne'))
    if wd is not None and (j['work_date'] or '') != wd:
        changes.append(('planifié le ' + wd) if wd else 'retiré du calendrier')
    if changes:
        log_audit('Atelier : bon de travail déplacé', f"bon {job} — " + ', '.join(changes))
    return jsonify({'ok': True})


@app.route('/api/atelier/jobs/<job>', methods=['DELETE'])
def api_atelier_job_delete(job):
    resp = admin_required_check()
    if resp is not None:
        return resp
    job = at_norm_job(job)
    conn = get_conn()
    try:
        j = conn.execute("SELECT * FROM shop_jobs WHERE job=?", (job,)).fetchone()
        if not j:
            return jsonify({'ok': False, 'error': 'Bon introuvable.'}), 404
        conn.execute("DELETE FROM shop_jobs WHERE job=?", (job,))
        conn.commit()
    finally:
        conn.close()
    log_audit('Atelier : bon de travail supprimé', f"bon {job} — {j['client'] or ''} {j['item'] or ''}".strip())
    return jsonify({'ok': True})


@app.route('/api/atelier/sale-link', methods=['POST'])
def api_atelier_sale_link():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    line = str(d.get('line') or '')
    action = d.get('action')
    conn = get_conn()
    try:
        r = conn.execute("SELECT sale_id, descr FROM sales_lines WHERE sale_line_id=?", (line,)).fetchone()
        if not r:
            return jsonify({'ok': False, 'error': 'Ligne de vente introuvable.'}), 404
        if action == 'link':
            job = at_norm_job(d.get('job'))
            if not job:
                return jsonify({'ok': False, 'error': 'Entre le numéro du bon.'}), 400
            conn.execute("INSERT OR REPLACE INTO shop_sale_links(sale_line_id, job, ignored, username, updated_at) VALUES (?,?,0,?,?)",
                         (line, job, session.get('username'), _at_now()))
            msg = f"vente {r['sale_id']} associée au bon {job}"
        elif action == 'ignore':
            conn.execute("INSERT OR REPLACE INTO shop_sale_links(sale_line_id, job, ignored, username, updated_at) VALUES (?,NULL,1,?,?)",
                         (line, session.get('username'), _at_now()))
            msg = f"vente {r['sale_id']} ignorée"
        elif action == 'reset':
            conn.execute("DELETE FROM shop_sale_links WHERE sale_line_id=?", (line,))
            msg = f"vente {r['sale_id']} : association retirée"
        else:
            return jsonify({'ok': False, 'error': 'Action inconnue.'}), 400
        conn.commit()
    finally:
        conn.close()
    log_audit('Atelier : service facturé', f"{msg} — {(r['descr'] or '')[:80]}")
    return jsonify({'ok': True})


@app.route('/api/atelier/unmatched')
def api_atelier_unmatched():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d0, d1 = _at_period(request.args)
    return jsonify({'start': d0.isoformat(), 'end': d1.isoformat(), 'unmatched': at_unmatched(d0, d1),
                    'missing_days': len([d for d in store_missing_days(d0, d1, need_ws=True) if d < datetime.date.today()]),
                    'auto': at_reread_cfg(), 'connected': ls_config()['connected']})


@app.route('/api/atelier/auto-reread', methods=['POST'])
def api_atelier_auto_reread():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    try:
        days = max(1, min(31, int(d.get('days') or 7)))
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Nombre de jours invalide.'}), 400
    meta_set('atelier_reread_enabled', '1' if d.get('enabled') else '0')
    meta_set('atelier_reread_days', days)
    log_audit('Atelier : relecture automatique des ventes', ('activée' if d.get('enabled') else 'désactivée') + f", {days} derniers jours")
    return jsonify({'ok': True, 'auto': at_reread_cfg()})


@app.route('/api/atelier/ignored')
def api_atelier_ignored():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d0, d1 = _at_period(request.args)
    conn = get_conn()
    rows = [dict(r) for r in conn.execute(
        "SELECT l.sale_line_id line, l.sale_id sale, l.sale_date date, l.descr, l.svc_minutes minutes, l.total amount, k.username, k.updated_at "
        "FROM shop_sale_links k JOIN sales_lines l ON l.sale_line_id=k.sale_line_id WHERE k.ignored=1 AND l.sale_date BETWEEN ? AND ? "
        "ORDER BY l.sale_date DESC", (d0.isoformat(), d1.isoformat())).fetchall()]
    conn.close()
    return jsonify({'rows': rows})


@app.route('/api/atelier/relire/status')
def api_atelier_relire_status():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    ss = _store_state
    return jsonify({'running': ss['running'], 'progress': ss['progress'], 'error': None if ss['running'] else ss['error']})


@app.route('/api/atelier/mechanics/<int:mid>', methods=['DELETE'])
def api_atelier_mechanic_delete(mid):
    resp = admin_required_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        m = conn.execute("SELECT * FROM shop_mechanics WHERE id=?", (mid,)).fetchone()
        if not m:
            return jsonify({'ok': False, 'error': 'Mécanicien introuvable.'}), 404
        n = conn.execute("SELECT COUNT(*) FROM shop_punches WHERE mechanic_id=?", (mid,)).fetchone()[0]
        if n and request.args.get('force') != '1':
            return jsonify({'ok': False, 'punches': n,
                            'error': f"{m['name']} a {n} punch(s) enregistré(s)."}), 409
        conn.execute("DELETE FROM shop_punches WHERE mechanic_id=?", (mid,))
        conn.execute("UPDATE shop_jobs SET mechanic_id=NULL WHERE mechanic_id=?", (mid,))
        conn.execute("DELETE FROM shop_mechanics WHERE id=?", (mid,))
        conn.commit()
    finally:
        conn.close()
    log_audit('Atelier : mécanicien supprimé', f"{m['name']}" + (f" (et ses {n} punch(s))" if n else ''))
    return jsonify({'ok': True})


@app.route('/api/atelier/relire', methods=['POST'])
def api_atelier_relire():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d0, d1 = _at_period(request.get_json(silent=True) or {})
    if not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Kubios n'est pas connecté à Lightspeed."}), 400
    days = [d0 + datetime.timedelta(days=i) for i in range((d1 - d0).days + 1)]
    try:
        start_store_job('ventes de l\'atelier', days, session.get('username'))
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    return jsonify({'ok': True, 'days': len(days)})


@app.route('/api/atelier/mechanics', methods=['GET', 'POST'])
@app.route('/api/atelier/mechanics/<int:mid>', methods=['PUT'])
def api_atelier_mechanics(mid=None):
    resp = admin_required_check()
    if resp is not None:
        return resp
    if request.method == 'GET':
        return jsonify({'mechanics': [{k: m[k] for k in ('id', 'name', 'cost_rate', 'active', 'color')} | {'has_pin': bool(m['pin_hash'])}
                                      for m in at_mechanics(True)], 'default_rate': at_default_rate(),
                        'busy': _store_state['running']})
    d = request.get_json(silent=True) or {}
    if d.get('default_rate') is not None and mid is None and not d.get('name'):
        try:
            meta_set('atelier_cost_rate', float(d['default_rate']))
        except (TypeError, ValueError):
            return jsonify({'ok': False, 'error': 'Taux invalide.'}), 400
        log_audit('Atelier : taux coûtant par défaut modifié', str(d['default_rate']))
        return jsonify({'ok': True})
    name = (d.get('name') or '').strip()[:60]
    pin = str(d.get('pin') or '').strip()
    if pin and not re.fullmatch(r'\d{4,6}', pin):
        return jsonify({'ok': False, 'error': 'Le NIP doit avoir 4 à 6 chiffres.'}), 400
    try:
        rate = float(d['cost_rate']) if d.get('cost_rate') not in (None, '') else None
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Taux invalide.'}), 400
    conn = get_conn()
    try:
        if mid is None:
            if not name or not pin:
                return jsonify({'ok': False, 'error': 'Le nom et un NIP de 4 à 6 chiffres sont requis.'}), 400
            conn.execute("INSERT INTO shop_mechanics(name, pin_hash, cost_rate, active, color, created_at) VALUES (?,?,?,1,?,?)",
                         (name, generate_password_hash(pin), rate, d.get('color') or '#2563eb', _at_now()))
            conn.commit()
            log_audit('Atelier : mécanicien ajouté', name)
        else:
            old = conn.execute("SELECT * FROM shop_mechanics WHERE id=?", (mid,)).fetchone()
            if not old:
                return jsonify({'ok': False, 'error': 'Mécanicien introuvable.'}), 404
            conn.execute("UPDATE shop_mechanics SET name=?, cost_rate=?, active=?, color=? WHERE id=?",
                         (name or old['name'], rate, 1 if d.get('active', True) else 0, d.get('color') or old['color'], mid))
            if pin:
                conn.execute("UPDATE shop_mechanics SET pin_hash=? WHERE id=?", (generate_password_hash(pin), mid))
            conn.commit()
            log_audit('Atelier : mécanicien modifié', (name or old['name']) + (' (nouveau NIP)' if pin else ''))
        conn.commit()
        return jsonify({'ok': True})
    finally:
        conn.close()


# ------------------------------------------------------------
# Routes — bons de travail et accès du poste de punch (1.22.0)
# ------------------------------------------------------------
@app.route('/atelier/punch/acces', methods=['POST'])
def atelier_kiosk_login():
    ip = client_ip()
    f = _kiosk_fail.get(ip, [0, 0])
    if f[0] >= 8 and time.time() - f[1] < 900:
        return render_template('atelier_kiosk_login.html', company=get_company_name(), error="Trop d'essais : réessaie dans 15 minutes.")
    h = meta_get('kiosk_code_hash')
    if h and check_password_hash(h, request.form.get('code', '')):
        _kiosk_fail.pop(ip, None)
        db_add_audit('Poste de punch', 'Tablette autorisée (code d\'accès)', ip)
        return kiosk_authorize(redirect(url_for('atelier_punch_page')))
    _kiosk_fail[ip] = [f[0] + 1 if time.time() - f[1] < 900 else 1, time.time()]
    return render_template('atelier_kiosk_login.html', company=get_company_name(),
                           error="Code incorrect." if h else "Aucun code d'accès n'est défini : un administrateur doit le créer dans Kubios → Atelier → Mécaniciens.")


@app.route('/atelier/punch/oublier')
def atelier_kiosk_forget():
    resp = redirect(url_for('atelier_punch_page'))
    resp.delete_cookie(KIOSK_COOKIE)
    return resp


KIOSK_IDLE_CHOICES = (1, 5, 30, 60, 240, 480)


def kiosk_idle_minutes():
    """Délai avant le retour automatique à l'accueil du poste de punch (1.34.0 : 4 h par défaut)."""
    try:
        v = int(meta_get('kiosk_idle_minutes') or 240)
    except ValueError:
        v = 240
    return v if v in KIOSK_IDLE_CHOICES else 240


@app.route('/api/atelier/kiosk-access', methods=['GET', 'POST'])
def api_atelier_kiosk_access():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if request.method == 'POST':
        d = request.get_json(silent=True) or {}
        if 'idle_minutes' in d:
            try:
                v = int(d['idle_minutes'])
            except (TypeError, ValueError):
                v = 0
            if v not in KIOSK_IDLE_CHOICES:
                return jsonify({'ok': False, 'error': 'Délai invalide.'}), 400
            meta_set('kiosk_idle_minutes', v)
            log_audit('Poste de punch : retour automatique à l\u2019accueil', f"après {v} min")
            return jsonify({'ok': True})
        if d.get('revoke'):
            meta_set('kiosk_secret', secrets.token_urlsafe(16))
            meta_set('kiosk_link_token', secrets.token_urlsafe(24))
            log_audit('Poste de punch : tablettes révoquées', 'nouveau lien direct créé')
            return jsonify({'ok': True})
        code = str(d.get('code') or '')
        if len(code) < 6:
            return jsonify({'ok': False, 'error': "Le code d'accès doit avoir au moins 6 caractères."}), 400
        meta_set('kiosk_code_hash', generate_password_hash(code))
        log_audit("Poste de punch : code d'accès modifié", '')
        return jsonify({'ok': True})
    return jsonify({'has_code': bool(meta_get('kiosk_code_hash')), 'idle_minutes': kiosk_idle_minutes(),
                    'link': request.host_url.rstrip('/') + url_for('atelier_punch_page') + '?cle=' + kiosk_link_token()})


@app.route('/api/atelier/jobs')
def api_atelier_jobs():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    a = request.args
    st = a.get('statut') or 'ouverts'
    done_expr = "COALESCE((SELECT MAX(p.end_at) FROM shop_punches p WHERE p.job=j.job AND p.ended_by='fin'), j.updated_at)"
    where, params = [], []
    if st == 'ouverts':
        where.append("j.status IN ('ouvert','en_cours')")
    elif st in ('termine', 'annule', 'en_cours'):
        where.append("j.status=?"); params.append(st)
    elif st == 'cal':                                   # calendrier : bons ouverts + ceux planifiés dans la semaine affichée
        where.append("(j.status IN ('ouvert','en_cours') OR j.work_date BETWEEN ? AND ?)"); params += [a.get('from') or '', a.get('to') or '']
    q = (a.get('q') or '').strip()
    if q:
        like = f"%{q}%"
        where.append("(j.job LIKE ? OR j.client LIKE ? OR j.item LIKE ? OR j.work LIKE ? OR j.notes LIKE ?)"); params += [like] * 5
    if a.get('mech') == 'none':
        where.append("j.mechanic_id IS NULL")
    elif (a.get('mech') or '').isdigit():
        where.append("j.mechanic_id=?"); params.append(int(a['mech']))
    if st == 'termine' and a.get('from') and a.get('to'):
        where.append(f"{done_expr} >= ? AND {done_expr} < ?"); params += [a['from'], (datetime.date.fromisoformat(a['to']) + datetime.timedelta(days=1)).isoformat()]
    order = {'termine': "done_at DESC", 'annule': "j.updated_at DESC", 'tous': "j.created_at DESC"}.get(
        st, "COALESCE(m.name,'~'), j.position, COALESCE(j.due_date,'9999'), j.created_at")
    sql_where = (" WHERE " + " AND ".join(where)) if where else ""
    paged = a.get('page') is not None
    page = max(1, int(a.get('page') or 1)) if (a.get('page') or '1').isdigit() else 1
    per_page = 50
    conn = get_conn()
    try:
        total = conn.execute(f"SELECT COUNT(*) FROM shop_jobs j LEFT JOIN shop_mechanics m ON m.id=j.mechanic_id{sql_where}", params).fetchone()[0]
        rows = [dict(r) for r in conn.execute(
            f"SELECT j.*, m.name mech_name, {done_expr} done_at FROM shop_jobs j LEFT JOIN shop_mechanics m ON m.id=j.mechanic_id{sql_where} "
            f"ORDER BY {order}" + (f" LIMIT {per_page} OFFSET {(page - 1) * per_page}" if paged else " LIMIT 2000"), params).fetchall()]
        for r in rows:
            r['seconds'] = _at_job_seconds(conn, r['job'])
            r['status_label'] = AT_JOB_STATUS.get(r['status'], r['status'])
        return jsonify({'jobs': rows, 'total': total, 'page': page, 'per_page': per_page if paged else total,
                        'mechanics': [{'id': m['id'], 'name': m['name'], 'color': m['color']} for m in at_mechanics()],
                        'is_admin': bool(session.get('is_admin'))})
    finally:
        conn.close()


@app.route('/api/atelier/jobs', methods=['POST'])
@app.route('/api/atelier/jobs/<job>', methods=['PUT'])
def api_atelier_job_save(job=None):
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    num = at_norm_job(d.get('job') if job is None else job)
    if not num:
        return jsonify({'ok': False, 'error': 'Entre le numéro du bon (celui de HubTiger).'}), 400
    try:
        mid = int(d['mechanic_id']) if d.get('mechanic_id') not in (None, '') else None
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Mécanicien invalide.'}), 400
    due = (d.get('due_date') or '').strip() or None
    if due:
        try:
            datetime.date.fromisoformat(due)
        except ValueError:
            return jsonify({'ok': False, 'error': 'Date promise invalide.'}), 400
    status = d.get('status') if d.get('status') in AT_JOB_STATUS else None
    fields = {k: (str(d.get(k) or '').strip()[:300] or None) for k in ('client', 'item', 'work')}
    notes = str(d.get('notes') or '').strip()[:1000] or None
    work_date = (d.get('work_date') or '').strip() or None
    if work_date:
        try:
            datetime.date.fromisoformat(work_date)
        except ValueError:
            return jsonify({'ok': False, 'error': 'Date de travail invalide.'}), 400
    priority = d.get('priority') if d.get('priority') in AT_PRIORITY else None
    new_num = at_norm_job(d.get('new_job')) if job is not None and d.get('new_job') else None
    if new_num and new_num != num and not session.get('is_admin'):
        return jsonify({'ok': False, 'error': "Seul un administrateur peut changer le numéro d'un bon."}), 403
    conn = get_conn()
    try:
        exists = conn.execute("SELECT * FROM shop_jobs WHERE job=?", (num,)).fetchone()
        if job is None and exists:
            return jsonify({'ok': False, 'error': f"Le bon {num} existe déjà."}), 409
        if job is not None and not exists:
            return jsonify({'ok': False, 'error': 'Bon introuvable.'}), 404
        if exists:
            pos = exists['position'] if exists['mechanic_id'] == mid else _at_next_position(conn, mid)
            conn.execute("UPDATE shop_jobs SET client=?, item=?, work=?, mechanic_id=?, due_date=?, status=?, updated_at=?, "
                         "notes=?, priority=?, position=?, work_date=? WHERE job=?",
                         (fields['client'], fields['item'], fields['work'], mid, due, status or exists['status'], _at_now(),
                          notes if 'notes' in d else exists['notes'], priority or exists['priority'] or 'normal', pos,
                          work_date if 'work_date' in d else exists['work_date'], num))
            if new_num and new_num != num:
                if conn.execute("SELECT 1 FROM shop_jobs WHERE job=?", (new_num,)).fetchone():
                    conn.rollback()
                    return jsonify({'ok': False, 'error': f"Le bon {new_num} existe déjà."}), 409
                for tbl in ('shop_jobs', 'shop_punches', 'shop_billing', 'shop_sale_links'):
                    conn.execute(f"UPDATE {tbl} SET job=? WHERE job=?", (new_num, num))
            conn.commit()
            changes = []
            if exists['mechanic_id'] != mid:
                changes.append('attribué à ' + (next((m['name'] for m in at_mechanics(True) if m['id'] == mid), 'personne')))
            if status and status != exists['status']:
                changes.append('statut : ' + AT_JOB_STATUS[status])
            if priority and priority != (exists['priority'] or 'normal'):
                changes.append('priorité : ' + AT_PRIORITY[priority])
            if new_num and new_num != num:
                changes.append(f'numéro changé pour {new_num}')
            log_audit('Atelier : bon de travail modifié', f"bon {num}" + (' — ' + ', '.join(changes) if changes else ''))
            num = new_num or num
        else:
            conn.execute("INSERT INTO shop_jobs(job, client, item, work, mechanic_id, due_date, status, created_by, created_at, updated_at, "
                         "notes, priority, position, work_date) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                         (num, fields['client'], fields['item'], fields['work'], mid, due, status or 'ouvert', session.get('username'),
                          _at_now(), _at_now(), notes, priority or 'normal', _at_next_position(conn, mid), work_date))
            conn.commit()
            log_audit('Atelier : bon de travail créé', f"bon {num} — {fields['client'] or ''} {fields['item'] or ''}".strip())
        conn.commit()
        return jsonify({'ok': True, 'job': num})
    finally:
        conn.close()


@app.route('/api/reports/gl', methods=['GET', 'POST'])
def api_reports_gl():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if request.method == 'POST':
        d = request.get_json(silent=True) or {}
        clean = lambda v: re.sub(r'[^0-9A-Za-z.\-]', '', str(v or ''))[:20]
        cfg = {'group_label': str(d.get('group_label') or 'Ventes élargies')[:60],
               'categories': {str(k)[:200]: {'gl': clean(v.get('gl')), 'groupe': bool(v.get('groupe'))}
                              for k, v in (d.get('categories') or {}).items() if isinstance(v, dict)},
               'payments': {str(k)[:120]: clean(v) for k, v in (d.get('payments') or {}).items()},
               'taxes': {k: clean((d.get('taxes') or {}).get(k)) for k in ('TPS', 'TVQ', 'TVH', 'TVP')}}
        meta_set('rep_gl', json.dumps(cfg, ensure_ascii=False))
        log_audit('Rapport des ventes : comptes GL modifiés', f"{len(cfg['categories'])} catégorie(s), {len(cfg['payments'])} mode(s) de paiement")
        return jsonify({'ok': True})
    conn = get_conn()
    try:
        cats = [r['name'] for r in conn.execute("SELECT name FROM ls_categories WHERE path NOT LIKE '%/%' OR path IS NULL ORDER BY name COLLATE NOCASE").fetchall()]
        pays = [r['name'] for r in conn.execute("SELECT DISTINCT name FROM sales_payments WHERE name IS NOT NULL AND TRIM(name)<>'' ORDER BY name").fetchall()]
        pays = sorted(set(pays) | set(rep_gl_cfg()['payments']), key=str.lower)
    finally:
        conn.close()
    cfg = rep_gl_cfg()
    known = {c.lower() for c in cats}
    cats += [c for c in cfg['categories'] if c.lower() not in known and c not in (REP_NO_CATEGORY, REP_MISC)]
    return jsonify({'config': cfg, 'categories': cats + [REP_NO_CATEGORY, REP_MISC], 'payments': pays})


@app.context_processor
def _inject_report_disclaimer():
    return {'report_disclaimer': REPORT_DISCLAIMER, 'report_disclaimer_title': REPORT_DISCLAIMER_TITLE}


# ------------------------------------------------------------
# Routes — messages de l'atelier (1.26.0)
# ------------------------------------------------------------
@app.route('/api/atelier/kiosk/message', methods=['POST'])
def api_atelier_kiosk_message():
    if not kiosk_allowed():
        return jsonify({'error': 'Poste de punch non autorisé.'}), 401
    d = request.get_json(silent=True) or {}
    try:
        mid = int(d.get('mechanic_id'))
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Mécanicien inconnu.'}), 400
    m, err = at_verify_pin(mid, d.get('pin'))
    if err:
        return jsonify({'ok': False, 'error': err, 'pin': True}), 403
    kind = 'probleme' if d.get('kind') == 'probleme' else 'message'
    category = d.get('category') if d.get('category') in AT_PROBLEMS else None
    text = str(d.get('text') or '').strip()[:1000]
    job = at_norm_job(d.get('job')) or None
    if kind == 'message' and not text:
        return jsonify({'ok': False, 'error': 'Écris ton message.'}), 400
    if kind == 'probleme' and not category:
        return jsonify({'ok': False, 'error': 'Choisis le type de problème.'}), 400
    conn = get_conn()
    try:
        conn.execute("INSERT INTO shop_messages(created_at, mechanic_id, job, kind, category, text, from_side) VALUES (?,?,?,?,?,?,'mecanicien')",
                     (_at_now(), mid, job, kind, category, text or None))
        conn.commit()
    finally:
        conn.close()
    db_add_audit(f"Atelier — {m['name']}", 'Problème signalé' if kind == 'probleme' else 'Message au responsable',
                 (f"bon {job} — " if job else '') + (AT_PROBLEMS.get(category, '') + (' : ' if text and category else '') if category else '') + text)
    if kind == 'probleme':
        _at_notify_problem(m['name'], job, category, text)
    return jsonify({'ok': True})


@app.route('/api/atelier/kiosk/thread', methods=['POST'])
def api_atelier_kiosk_thread():
    if not kiosk_allowed():
        return jsonify({'error': 'Poste de punch non autorisé.'}), 401
    d = request.get_json(silent=True) or {}
    try:
        mid = int(d.get('mechanic_id'))
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Mécanicien inconnu.'}), 400
    m, err = at_verify_pin(mid, d.get('pin'))
    if err:
        return jsonify({'ok': False, 'error': err, 'pin': True}), 403
    conn = get_conn()
    try:
        thread = at_thread(conn, mid)
        conn.execute("UPDATE shop_messages SET read_at=? WHERE mechanic_id=? AND from_side='responsable' AND read_at IS NULL", (_at_now(), mid))
        conn.commit()
        return jsonify({'ok': True, 'thread': thread, 'problems': AT_PROBLEMS})
    finally:
        conn.close()


@app.route('/api/atelier/unread')
def api_atelier_unread():
    if not (session.get('is_admin') or 'atelier' in (session.get('permissions') or [])):
        return jsonify({'unread': 0, 'problems': 0})
    conn = get_conn()
    try:
        c = at_unread_counts(conn)
        last = conn.execute("SELECT s.id, s.kind, s.category, s.job, s.text, m.name FROM shop_messages s JOIN shop_mechanics m ON m.id=s.mechanic_id "
                            "WHERE s.from_side='mecanicien' AND s.read_at IS NULL ORDER BY s.id DESC LIMIT 1").fetchone()
        c['last'] = dict(last) if last else None
        if c['last']:
            c['last']['category_label'] = AT_PROBLEMS.get(c['last']['category'] or '', '')
        return jsonify(c)
    finally:
        conn.close()


@app.route('/api/atelier/messages')
def api_atelier_messages():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        out = []
        for m in at_mechanics(True):
            thread = at_thread(conn, m['id'])
            if not thread and not m['active']:
                continue
            unread = sum(1 for x in thread if x['from_side'] == 'mecanicien' and not x['read_at'])
            open_p = sum(1 for x in thread if x['kind'] == 'probleme' and not x['resolved_at'])
            out.append({'id': m['id'], 'name': m['name'], 'color': m['color'], 'thread': thread, 'unread': unread,
                        'open_problems': open_p, 'last_at': thread[-1]['created_at'] if thread else ''})
        out.sort(key=lambda x: x['last_at'], reverse=True)                   # plus récent d'abord…
        out.sort(key=lambda x: (-x['open_problems'], -x['unread']))           # …mais problèmes et non lus en tête
        return jsonify({'conversations': out, 'counts': at_unread_counts(conn),
                        'notify_emails': meta_get('atelier_notify_emails') or '', 'is_admin': bool(session.get('is_admin'))})
    finally:
        conn.close()


@app.route('/api/atelier/messages', methods=['POST'])
def api_atelier_message_reply():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    try:
        mid = int(d.get('mechanic_id'))
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Mécanicien inconnu.'}), 400
    text = str(d.get('text') or '').strip()[:1000]
    if not text:
        return jsonify({'ok': False, 'error': 'Écris ta réponse.'}), 400
    conn = get_conn()
    try:
        conn.execute("INSERT INTO shop_messages(created_at, mechanic_id, job, kind, text, from_side, username) VALUES (?,?,?,?,?,'responsable',?)",
                     (_at_now(), mid, at_norm_job(d.get('job')) or None, 'message', text, current_display_name()))
        conn.execute("UPDATE shop_messages SET read_at=? WHERE mechanic_id=? AND from_side='mecanicien' AND read_at IS NULL", (_at_now(), mid))
        conn.commit()
    finally:
        conn.close()
    return jsonify({'ok': True})


@app.route('/api/atelier/messages/read', methods=['POST'])
def api_atelier_messages_read():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    conn = get_conn()
    try:
        conn.execute("UPDATE shop_messages SET read_at=? WHERE mechanic_id=? AND from_side='mecanicien' AND read_at IS NULL",
                     (_at_now(), int(d.get('mechanic_id') or 0)))
        conn.commit()
    finally:
        conn.close()
    return jsonify({'ok': True})


@app.route('/api/atelier/messages/<int:msg_id>/resolve', methods=['POST'])
def api_atelier_message_resolve(msg_id):
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    undo = (request.get_json(silent=True) or {}).get('undo')
    conn = get_conn()
    try:
        r = conn.execute("SELECT * FROM shop_messages WHERE id=?", (msg_id,)).fetchone()
        if not r:
            return jsonify({'ok': False, 'error': 'Message introuvable.'}), 404
        conn.execute("UPDATE shop_messages SET resolved_at=?, resolved_by=?, read_at=COALESCE(read_at, ?) WHERE id=?",
                     (None if undo else _at_now(), None if undo else current_display_name(), _at_now(), msg_id))
        conn.commit()
    finally:
        conn.close()
    log_audit('Atelier : problème ' + ('rouvert' if undo else 'résolu'), f"bon {r['job'] or '—'} — {AT_PROBLEMS.get(r['category'] or '', '')}")
    return jsonify({'ok': True})


@app.route('/api/atelier/notify-emails', methods=['POST'])
def api_atelier_notify_emails():
    resp = admin_required_check()
    if resp is not None:
        return resp
    v = str((request.get_json(silent=True) or {}).get('emails') or '').strip()[:500]
    bad = [e for e in re.split(r'[;,]\s*', v) if e and not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+', e)]
    if bad:
        return jsonify({'ok': False, 'error': 'Adresse invalide : ' + ', '.join(bad)}), 400
    meta_set('atelier_notify_emails', v)
    log_audit('Atelier : courriels avisés des problèmes', v or '(aucun)')
    return jsonify({'ok': True})


@app.route('/atelier/direct')
def atelier_direct_page():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    local = three_local_ready()
    if not local:
        ensure_three_vendor_async()
    return render_template('atelier_direct.html', company=get_company_name(), three_local=local)


@app.route('/api/atelier/direct')
def api_atelier_direct():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    a = request.args.get('after')
    try:
        after = int(a) if a not in (None, '', '-1') else None
    except ValueError:
        after = None
    return jsonify(at_direct_state(after))


@app.route('/api/atelier/profit/pdf')
def api_atelier_profit_pdf():
    resp = permission_required_check('atelier_profit')
    if resp is not None:
        return resp
    a = request.args
    r = at_profit_compare(a)
    try:
        if a.get('type') == 'eval':
            ids = None if a.get('mechanic') in (None, '', 'all') else [int(a['mechanic'])]
            path = export_atelier_eval_pdf(r, ids, a.get('cost', '1') == '1', a.get('detail', '1') == '1')
            log_audit("Atelier : fiche d'évaluation (PDF)", f"{'tous' if not ids else ids[0]} — {r['start']} au {r['end']}")
            if a.get('save_rh') == '1' and hr_allowed():      # copie classée au dossier RH de chaque employé relié
                conn = get_conn()
                try:
                    for m in r['mechanics']:
                        if ids and m['id'] not in ids:
                            continue
                        emp = conn.execute("SELECT * FROM hr_employees WHERE mechanic_id=?", (m['id'],)).fetchone()
                        if not emp:
                            continue
                        one = export_atelier_eval_pdf(r, [m['id']], a.get('cost', '1') == '1', a.get('detail', '1') == '1')
                        hr_store_file(emp['id'], one.read_bytes(), one.name, 'evaluation_atelier',
                                      f"Fiche d'atelier du {_d(r['start'])} au {_d(r['end'])}", username=session.get('username'), conn=conn)
                        hr_log(conn, emp['id'], "Fiche d'évaluation de l'atelier classée au dossier")
                    conn.commit()
                finally:
                    conn.close()
        else:
            path = export_atelier_finance_pdf(r)
            log_audit('Atelier : rapport financier (PDF)', f"{r['start']} au {r['end']}")
    except (ValueError, TypeError) as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    return send_file(str(path), mimetype='application/pdf', as_attachment=False, download_name=path.name)


# ------------------------------------------------------------
# Routes — Gestion RH (1.30.0)
# ------------------------------------------------------------
def _hr_check():
    return permission_required_check('rh')


def _hr_emp(conn, eid):
    e = conn.execute("SELECT * FROM hr_employees WHERE id=?", (eid,)).fetchone()
    return dict(e) if e else None


@app.route('/rh')
def hr_page():
    resp = _hr_check()
    if resp is not None:
        return resp
    return render_template('rh.html', company=get_company_name(), is_admin=bool(session.get('is_admin')))


@app.route('/api/rh/employees')
def api_hr_employees():
    resp = _hr_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        rows = [dict(r) for r in conn.execute("SELECT id, first_name, last_name, position, status, hire_date, mechanic_id FROM hr_employees "
                                              "ORDER BY status='inactif', last_name COLLATE NOCASE, first_name COLLATE NOCASE").fetchall()]
        return jsonify({'employees': rows, 'reminders': hr_reminders(conn), 'status': HR_STATUS, 'scale': HR_SCALE,
                        'criteria': [[c['key'], c['label'], c['hint']] for c in hr_criteria()], 'templates': hr_templates(), 'template_order': list(HR_TEMPLATES),
                        'doc_cats': HR_DOC_CATS, 'note_kinds': HR_NOTE_KINDS,
                        'mechanics': [{'id': m['id'], 'name': m['name']} for m in at_mechanics(True)],
                        'users': [r['username'] for r in conn.execute("SELECT username FROM users ORDER BY username").fetchall()]})
    finally:
        conn.close()


@app.route('/api/rh/employees/<int:eid>')
def api_hr_employee(eid):
    resp = _hr_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        e = _hr_emp(conn, eid)
        if not e:
            return jsonify({'error': 'Employé introuvable.'}), 404
        hr_log(conn, eid, 'Consultation du dossier'); conn.commit()
        docs = [dict(r) for r in conn.execute("SELECT * FROM hr_documents WHERE employee_id=? ORDER BY created_at DESC", (eid,)).fetchall()]
        evals = [dict(r) for r in conn.execute("SELECT * FROM hr_evaluations WHERE employee_id=? ORDER BY COALESCE(eval_date, created_at) DESC", (eid,)).fetchall()]
        notes = [dict(r) for r in conn.execute("SELECT * FROM hr_notes WHERE employee_id=? ORDER BY note_date DESC, id DESC", (eid,)).fetchall()]
        log = [dict(r) for r in conn.execute("SELECT * FROM hr_access_log WHERE employee_id=? ORDER BY id DESC LIMIT 100", (eid,)).fetchall()] if session.get('is_admin') else None
        e['tc_has_pin'] = bool(e.pop('tc_pin_hash', None))          # jamais l'empreinte du NIP
        p = conn.execute("SELECT login, active, invited_at, last_login, password_hash IS NOT NULL AS has_password FROM hr_portal WHERE employee_id=?", (eid,)).fetchone()
        for x in docs:
            x['mgr_sig'] = bool(x.get('mgr_sig')); x['emp_sig'] = bool(x.get('emp_sig'))
        return jsonify({'employee': e, 'documents': docs, 'evaluations': evals, 'notes': notes, 'log': log, 'portal': dict(p) if p else None})
    finally:
        conn.close()


HR_FIELDS = ('first_name', 'last_name', 'position', 'department', 'hire_date', 'status', 'probation_end', 'end_date', 'next_review',
             'email', 'phone', 'address', 'emergency_name', 'emergency_phone', 'username', 'notes')


@app.route('/api/rh/employees', methods=['POST'])
@app.route('/api/rh/employees/<int:eid>', methods=['PUT', 'DELETE'])
def api_hr_employee_save(eid=None):
    resp = _hr_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        if request.method == 'DELETE':
            if not session.get('is_admin'):
                return jsonify({'ok': False, 'error': "Seul un administrateur peut supprimer un dossier. Marque plutôt l'employé « Inactif »."}), 403
            e = _hr_emp(conn, eid)
            if not e:
                return jsonify({'ok': False, 'error': 'Employé introuvable.'}), 404
            for t in ('hr_documents', 'hr_evaluations', 'hr_notes', 'hr_portal', 'tc_events', 'tc_approvals'):
                conn.execute(f"DELETE FROM {t} WHERE employee_id=?", (eid,))
            conn.execute("DELETE FROM hr_employees WHERE id=?", (eid,))
            hr_log(conn, eid, 'Dossier supprimé'); conn.commit()
            shutil.rmtree(HR_DIR / str(eid), ignore_errors=True)
            log_audit('RH : dossier supprimé', hr_emp_name(e))
            return jsonify({'ok': True})
        d = request.get_json(silent=True) or {}
        vals = {f: (str(d.get(f) or '').strip()[:1000] or None) for f in HR_FIELDS}
        if not vals['first_name'] or not vals['last_name']:
            return jsonify({'ok': False, 'error': 'Le prénom et le nom sont requis.'}), 400
        if vals['status'] not in HR_STATUS:
            vals['status'] = 'actif'
        for f in ('hire_date', 'probation_end', 'end_date', 'next_review'):
            if vals[f]:
                try:
                    datetime.date.fromisoformat(vals[f])
                except ValueError:
                    return jsonify({'ok': False, 'error': 'Date invalide.'}), 400
        if re.search(r'\b\d{3}[ -]?\d{3}[ -]?\d{3}\b', (vals['notes'] or '')):
            return jsonify({'ok': False, 'error': "Les notes semblent contenir un numéro d'assurance sociale : ne l'inscris pas dans Kubios."}), 400
        try:
            mid = int(d['mechanic_id']) if d.get('mechanic_id') not in (None, '') else None
        except (TypeError, ValueError):
            mid = None
        if eid is None:
            cur = conn.execute("INSERT INTO hr_employees(" + ','.join(HR_FIELDS) + ", mechanic_id, created_at, updated_at) VALUES ("
                               + ','.join('?' * (len(HR_FIELDS) + 3)) + ")", [vals[f] for f in HR_FIELDS] + [mid, _at_now(), _at_now()])
            eid = cur.lastrowid
            hr_log(conn, eid, 'Dossier créé')
            msg = 'RH : dossier créé'
        else:
            if not _hr_emp(conn, eid):
                return jsonify({'ok': False, 'error': 'Employé introuvable.'}), 404
            conn.execute("UPDATE hr_employees SET " + ', '.join(f + '=?' for f in HR_FIELDS) + ", mechanic_id=?, updated_at=? WHERE id=?",
                         [vals[f] for f in HR_FIELDS] + [mid, _at_now(), eid])
            hr_log(conn, eid, 'Profil modifié')
            msg = 'RH : profil modifié'
        conn.commit()
    finally:
        conn.close()
    log_audit(msg, f"{vals['first_name']} {vals['last_name']}")
    return jsonify({'ok': True, 'id': eid})


@app.route('/api/rh/employees/<int:eid>/documents', methods=['POST'])
def api_hr_doc_upload(eid):
    resp = _hr_check()
    if resp is not None:
        return resp
    f = request.files.get('file')
    if not f or not f.filename:
        return jsonify({'ok': False, 'error': 'Choisis un fichier.'}), 400
    if Path(f.filename).suffix.lower() not in HR_DOC_EXT:
        return jsonify({'ok': False, 'error': 'Type de fichier non accepté (PDF, image, Word, Excel ou texte).'}), 400
    data = f.read()
    if len(data) > HR_DOC_MAX:
        return jsonify({'ok': False, 'error': 'Fichier trop gros (15 Mo au maximum).'}), 400
    cat = request.form.get('category') if request.form.get('category') in HR_DOC_CATS else 'autre'
    exp = (request.form.get('expires_on') or '').strip() or None
    if exp:
        try:
            datetime.date.fromisoformat(exp)
        except ValueError:
            return jsonify({'ok': False, 'error': "Date d'échéance invalide."}), 400
    conn = get_conn()
    try:
        e = _hr_emp(conn, eid)
        if not e:
            return jsonify({'ok': False, 'error': 'Employé introuvable.'}), 404
        hr_store_file(eid, data, f.filename, cat, (request.form.get('title') or Path(f.filename).stem).strip(), exp, conn=conn)
        hr_log(conn, eid, 'Document ajouté : ' + f.filename[:80]); conn.commit()
    finally:
        conn.close()
    log_audit('RH : document ajouté', f"{hr_emp_name(e)} — {f.filename}")
    return jsonify({'ok': True})


@app.route('/api/rh/documents/<int:did>', methods=['GET', 'DELETE'])
def api_hr_doc(did):
    resp = _hr_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        d = conn.execute("SELECT * FROM hr_documents WHERE id=?", (did,)).fetchone()
        if not d:
            return jsonify({'error': 'Document introuvable.'}), 404
        p = HR_DIR / str(d['employee_id']) / d['filename']
        if request.method == 'DELETE':
            conn.execute("DELETE FROM hr_documents WHERE id=?", (did,))
            hr_log(conn, d['employee_id'], 'Document supprimé : ' + (d['original_name'] or '')); conn.commit()
            try:
                p.unlink()
            except OSError:
                pass
            log_audit('RH : document supprimé', d['original_name'] or '')
            return jsonify({'ok': True})
        hr_log(conn, d['employee_id'], 'Document ouvert : ' + (d['original_name'] or '')); conn.commit()
        if request.args.get('signed') == '1' and d['signed_filename']:
            p = HR_DIR / str(d['employee_id']) / d['signed_filename']
    finally:
        conn.close()
    if not p.exists():
        return "Fichier introuvable sur le disque.", 404
    return send_file(str(p), as_attachment=request.args.get('dl') == '1', download_name=d['original_name'] or p.name)


@app.route('/api/rh/employees/<int:eid>/notes', methods=['POST'])
@app.route('/api/rh/notes/<int:nid>', methods=['DELETE'])
def api_hr_note(eid=None, nid=None):
    resp = _hr_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        if nid is not None:
            n = conn.execute("SELECT * FROM hr_notes WHERE id=?", (nid,)).fetchone()
            if not n:
                return jsonify({'ok': False, 'error': 'Note introuvable.'}), 404
            conn.execute("DELETE FROM hr_notes WHERE id=?", (nid,)); hr_log(conn, n['employee_id'], 'Note supprimée'); conn.commit()
            return jsonify({'ok': True})
        d = request.get_json(silent=True) or {}
        text = str(d.get('text') or '').strip()[:3000]
        if not text:
            return jsonify({'ok': False, 'error': 'Écris la note.'}), 400
        kind = d.get('kind') if d.get('kind') in HR_NOTE_KINDS else 'note'
        nd = (d.get('note_date') or '').strip() or datetime.date.today().isoformat()
        conn.execute("INSERT INTO hr_notes(employee_id, kind, note_date, text, created_by, created_at) VALUES (?,?,?,?,?,?)",
                     (eid, kind, nd, text, current_display_name(), _at_now()))
        hr_log(conn, eid, 'Note ajoutée : ' + HR_NOTE_KINDS[kind]); conn.commit()
        return jsonify({'ok': True})
    finally:
        conn.close()


@app.route('/api/rh/employees/<int:eid>/evaluations', methods=['POST'])
@app.route('/api/rh/evaluations/<int:vid>', methods=['PUT', 'DELETE'])
def api_hr_eval_save(eid=None, vid=None):
    resp = _hr_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        if vid is not None:
            ev = conn.execute("SELECT * FROM hr_evaluations WHERE id=?", (vid,)).fetchone()
            if not ev:
                return jsonify({'ok': False, 'error': 'Évaluation introuvable.'}), 404
            eid = ev['employee_id']
            if request.method == 'DELETE':
                if ev['status'] == 'finalisee' and not session.get('is_admin'):
                    return jsonify({'ok': False, 'error': 'Seul un administrateur peut supprimer une évaluation finalisée.'}), 403
                conn.execute("DELETE FROM hr_evaluations WHERE id=?", (vid,)); hr_log(conn, eid, 'Évaluation supprimée'); conn.commit()
                return jsonify({'ok': True})
            if ev['status'] == 'finalisee':
                return jsonify({'ok': False, 'error': 'Cette évaluation est finalisée : elle ne peut plus être modifiée.'}), 409
        e = _hr_emp(conn, eid)
        if not e:
            return jsonify({'ok': False, 'error': 'Employé introuvable.'}), 404
        d = request.get_json(silent=True) or {}
        crit = json.loads(ev['criteria']) if vid is not None and ev['criteria'] and ev['status'] == 'finalisee' else \
            [{'key': c['key'], 'label': c['label'], 'hint': c['hint']} for c in hr_criteria()]
        scores = {}
        for c in crit:
            sc = (d.get('scores') or {}).get(c['key']) or {}
            na = sc.get('score') == 'na'
            try:
                v = int(sc.get('score')) if sc.get('score') not in (None, '', 'na') else None
            except (TypeError, ValueError):
                v = None
            scores[c['key']] = {'score': v if v in HR_SCALE else None, 'na': na, 'comment': str(sc.get('comment') or '')[:500]}
        got = [s['score'] for s in scores.values() if s['score']]
        overall = round(sum(got) / len(got), 2) if got else None
        p0, p1 = (d.get('period_start') or '').strip() or None, (d.get('period_end') or '').strip() or None
        for x in (p0, p1, d.get('eval_date') or None):
            if x:
                try:
                    datetime.date.fromisoformat(x)
                except ValueError:
                    return jsonify({'ok': False, 'error': 'Date invalide.'}), 400
        stats = hr_atelier_stats(e, p0, p1) if p0 and p1 else None
        final = bool(d.get('finalize'))
        if final and any(not s['score'] and not s['na'] for s in scores.values()):
            return jsonify({'ok': False, 'error': 'Note chaque critère, ou marque-le « S.O. » (ne s’applique pas), avant de finaliser.'}), 400
        if final and not got:
            return jsonify({'ok': False, 'error': 'Au moins un critère doit être noté.'}), 400
        vals = (p0, p1, d.get('eval_date') or datetime.date.today().isoformat(), str(d.get('evaluator') or current_display_name())[:120],
                json.dumps(scores, ensure_ascii=False), overall, *(str(d.get(k) or '')[:3000] for k in ('strengths', 'improvements', 'objectives', 'employee_comments')),
                'finalisee' if final else 'brouillon', json.dumps(stats) if stats else None, _at_now(), json.dumps(crit, ensure_ascii=False))
        if vid is None:
            cur = conn.execute("INSERT INTO hr_evaluations(period_start, period_end, eval_date, evaluator, scores, overall, strengths, improvements, objectives, "
                               "employee_comments, status, atelier_stats, updated_at, criteria, employee_id, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                               vals + (eid, _at_now()))
            vid = cur.lastrowid
        else:
            conn.execute("UPDATE hr_evaluations SET period_start=?, period_end=?, eval_date=?, evaluator=?, scores=?, overall=?, strengths=?, improvements=?, "
                         "objectives=?, employee_comments=?, status=?, atelier_stats=?, updated_at=?, criteria=? WHERE id=?", vals + (vid,))
        hr_log(conn, eid, 'Évaluation ' + ('finalisée' if final else 'enregistrée (brouillon)'))
        if final:
            ev = dict(conn.execute("SELECT * FROM hr_evaluations WHERE id=?", (vid,)).fetchone())
            p = export_hr_eval_pdf(e, ev)
            hr_store_file(eid, p.read_bytes(), f"Evaluation_{ev['eval_date']}.pdf", 'evaluation', f"Évaluation du {_d(ev['eval_date'])}", username=session.get('username'), conn=conn)
            try:
                p.unlink()
            except OSError:
                pass
            if not e['next_review'] or e['next_review'] <= datetime.date.today().isoformat():
                nr = (datetime.date.fromisoformat(ev['eval_date']) + datetime.timedelta(days=365)).isoformat()
                conn.execute("UPDATE hr_employees SET next_review=? WHERE id=?", (nr, eid))
        conn.commit()
    finally:
        conn.close()
    if final:
        log_audit('RH : évaluation finalisée', hr_emp_name(e))
    return jsonify({'ok': True, 'id': vid})


@app.route('/api/rh/evaluations/<int:vid>/pdf')
def api_hr_eval_pdf(vid):
    resp = _hr_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        ev = conn.execute("SELECT * FROM hr_evaluations WHERE id=?", (vid,)).fetchone()
        if not ev:
            return "Évaluation introuvable.", 404
        e = _hr_emp(conn, ev['employee_id']); hr_log(conn, ev['employee_id'], 'Aperçu PDF de l\u2019évaluation'); conn.commit()
    finally:
        conn.close()
    p = export_hr_eval_pdf(e, dict(ev))
    return send_file(str(p), mimetype='application/pdf', as_attachment=False, download_name=f"Evaluation_{hr_emp_name(e).replace(' ', '_')}.pdf")


@app.route('/api/rh/employees/<int:eid>/atelier-stats')
def api_hr_atelier_stats(eid):
    resp = _hr_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        e = _hr_emp(conn, eid)
    finally:
        conn.close()
    if not e:
        return jsonify({'error': 'Employé introuvable.'}), 404
    try:
        return jsonify({'stats': hr_atelier_stats(e, request.args.get('start'), request.args.get('end'))})
    except (ValueError, TypeError):
        return jsonify({'stats': None})


@app.route('/rh/administration')
def hr_admin_page():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return render_template('rh_admin.html', company=get_company_name())


@app.route('/api/rh/settings', methods=['GET', 'POST'])
def api_hr_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if request.method == 'GET':
        return jsonify({'criteria': hr_criteria(False), 'templates': hr_templates(), 'template_order': list(HR_TEMPLATES)})
    d = request.get_json(silent=True) or {}
    if 'criteria' in d:
        out, used = [], set()
        for c in d['criteria'] or []:
            label = str(c.get('label') or '').strip()[:120]
            if not label:
                continue
            key = re.sub(r'[^a-z0-9]+', '_', str(c.get('key') or '').lower()).strip('_')[:40]
            if not key:
                base = re.sub(r'[^a-z0-9]+', '_', unicodedata.normalize('NFKD', label).encode('ascii', 'ignore').decode().lower()).strip('_')[:30] or 'critere'
                key, n = base, 2
                while key in used:
                    key = f"{base}_{n}"; n += 1
            if key in used:
                continue
            used.add(key)
            out.append({'key': key, 'label': label, 'hint': str(c.get('hint') or '').strip()[:300], 'active': bool(c.get('active', True))})
        if not any(c['active'] for c in out):
            return jsonify({'ok': False, 'error': 'Garde au moins un critère actif.'}), 400
        meta_set('hr_criteria', json.dumps(out, ensure_ascii=False))
        log_audit('RH : critères d\u2019évaluation modifiés', f"{sum(1 for c in out if c['active'])} critère(s) actif(s)")
    if 'templates' in d:
        ov = {}
        for t, v in (d['templates'] or {}).items():
            if t in HR_TEMPLATES and isinstance(v, dict):
                keys = {s[0] for s in HR_TEMPLATES[t]['sections']}
                ov[t] = {'ack': str(v.get('ack') or '')[:1000], 'defaults': {kk: str(vv or '')[:3000] for kk, vv in (v.get('defaults') or {}).items() if kk in keys}}
        meta_set('hr_doc_templates', json.dumps(ov, ensure_ascii=False))
        log_audit('RH : modèles de documents modifiés', '')
    return jsonify({'ok': True, 'criteria': hr_criteria(False), 'templates': hr_templates(), 'template_order': list(HR_TEMPLATES)})


@app.route('/api/rh/employees/<int:eid>/generate', methods=['POST'])
def api_hr_generate(eid):
    resp = _hr_check()
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    ttype = d.get('type')
    if ttype not in HR_TEMPLATES:
        return jsonify({'ok': False, 'error': 'Type de document inconnu.'}), 400
    dd = (d.get('date') or '').strip() or datetime.date.today().isoformat()
    try:
        datetime.date.fromisoformat(dd)
    except ValueError:
        return jsonify({'ok': False, 'error': 'Date invalide.'}), 400
    fields = {kk: str(v or '')[:5000] for kk, v in (d.get('fields') or {}).items()}
    conn = get_conn()
    try:
        e = _hr_emp(conn, eid)
        if not e:
            return jsonify({'ok': False, 'error': 'Employé introuvable.'}), 404
        tpl = HR_TEMPLATES[ttype]
        if ttype != 'attestation' and not (fields.get('objet') or '').strip():
            return jsonify({'ok': False, 'error': "Inscris l'objet du document."}), 400
        rep_ = {'{nom}': hr_emp_name(e), '{entreprise}': get_company_name(), '{embauche}': _d(e['hire_date']) if e['hire_date'] else '—', '{poste}': e['position'] or '—'}
        for kk in fields:
            for a, b in rep_.items():
                fields[kk] = fields[kk].replace(a, b)
        d_ = HR_DIR / str(eid); d_.mkdir(parents=True, exist_ok=True)
        tmp = d_ / f"_apercu_{ttype}.pdf"
        export_hr_letter_pdf(e, ttype, dd, fields, current_display_name(), tmp)
        if d.get('preview'):
            hr_log(conn, eid, f"Aperçu : {tpl['title']}"); conn.commit()
            return send_file(str(tmp), mimetype='application/pdf', as_attachment=False, download_name=f"{tpl['title']}.pdf")
        title = tpl['title'] + (f" — {fields.get('objet').strip()[:80]}" if (fields.get('objet') or '').strip() else '')
        did = hr_store_file(eid, tmp.read_bytes(), f"{re.sub(r'[^A-Za-z0-9]+', '_', tpl['title'])}_{dd}.pdf", tpl['category'], f"{title} ({_d(dd)})",
                            username=session.get('username'), conn=conn)
        conn.execute("INSERT INTO hr_notes(employee_id, kind, note_date, text, created_by, created_at) VALUES (?,?,?,?,?,?)",
                     (eid, tpl['note_kind'], dd, f"{title} — document créé et classé au dossier.", current_display_name(), _at_now()))
        hr_log(conn, eid, f"Document créé : {tpl['title']}"); conn.commit()
        try:
            tmp.unlink()
        except OSError:
            pass
    finally:
        conn.close()
    log_audit('RH : document créé', f"{hr_emp_name(e)} — {title}")
    return jsonify({'ok': True, 'document_id': did})


# ------------------------------------------------------------
# Routes — poste de punch des employés (1.39.0)
# ------------------------------------------------------------
@app.route('/punch-employes', methods=['GET', 'POST'])
def tc_station_page():
    if request.method == 'POST':                       # code d'accès du poste
        h = meta_get('tc_code_hash')
        if h and check_password_hash(h, (request.form.get('code') or '').strip()):
            db_add_audit('Poste de punch des employés', 'Poste autorisé (code)', client_ip())
            return tc_authorize(redirect(url_for('tc_station_page')))
        return render_template('tc_station.html', company=get_company_name(), mode='code',
                               error="Code d'accès incorrect." if h else "Aucun code d'accès n'est défini : un administrateur doit le créer dans Administration RH.")
    tok = request.args.get('cle')
    if tok and secrets.compare_digest(tok, tc_link_token()):
        db_add_audit('Poste de punch des employés', 'Poste autorisé (lien direct)', client_ip())
        return tc_authorize(redirect(url_for('tc_station_page')))
    if not tc_allowed():
        return render_template('tc_station.html', company=get_company_name(), mode='code', error=None)
    return render_template('tc_station.html', company=get_company_name(), mode='station', error=None)


@app.route('/api/tc/station')
def api_tc_station():
    if not tc_allowed():
        return jsonify({'error': 'Poste non autorisé.'}), 401
    conn = get_conn()
    try:
        out = []
        for e in conn.execute("SELECT id, first_name, last_name, position FROM hr_employees WHERE tc_enabled=1 AND status<>'inactif' "
                              "ORDER BY first_name COLLATE NOCASE, last_name COLLATE NOCASE").fetchall():
            st = tc_state(conn, e['id'])
            out.append({'id': e['id'], 'name': f"{e['first_name']} {e['last_name']}", 'position': e['position'] or '',
                        'state': st['state'], 'since': st['since'], 'first_in': st['first_in'], 'last_out': st['last_out']})
        return jsonify({'employees': out, 'now': datetime.datetime.now().strftime(AT_FMT)})
    finally:
        conn.close()


@app.route('/api/tc/punch', methods=['POST'])
def api_tc_punch():
    if not tc_allowed():
        return jsonify({'ok': False, 'error': 'Poste non autorisé.'}), 401
    d = request.get_json(silent=True) or {}
    try:
        eid = int(d.get('employee_id'))
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Employé inconnu.'}), 400
    f = _tc_fail.get(eid, {'n': 0, 'until': 0})
    if f['until'] > time.time():
        return jsonify({'ok': False, 'error': f"Trop d'essais. Réessaie dans {int((f['until'] - time.time()) // 60) + 1} minute(s).", 'pin': True}), 429
    conn = get_conn()
    try:
        e = conn.execute("SELECT * FROM hr_employees WHERE id=? AND tc_enabled=1 AND status<>'inactif'", (eid,)).fetchone()
        if not e or not e['tc_pin_hash']:
            return jsonify({'ok': False, 'error': "Cet employé n'a pas de NIP de punch : demande à ton gestionnaire."}), 400
        if not check_password_hash(e['tc_pin_hash'], str(d.get('pin') or '')):
            f['n'] += 1
            if f['n'] >= 5:
                f = {'n': 0, 'until': time.time() + 300}
            _tc_fail[eid] = f
            return jsonify({'ok': False, 'error': 'NIP incorrect.', 'pin': True}), 403
        _tc_fail.pop(eid, None)
        act = d.get('action')
        st = tc_state(conn, eid)
        allowed = {'out': ('in',), 'done': ('in',), 'in': ('break_start', 'out'), 'break': ('break_end', 'out')}[st['state']]
        if act != 'login':
            if act not in allowed:
                return jsonify({'ok': False, 'error': 'Ce punch ne correspond pas à ton état actuel.'}), 400
            if act == 'out' and st['state'] == 'break':
                conn.execute("INSERT INTO tc_events(employee_id, ts, kind, station, created_by) VALUES (?,?,?,?,?)",
                             (eid, _at_now(), 'break_end', client_ip(), 'poste'))
            conn.execute("INSERT INTO tc_events(employee_id, ts, kind, station, created_by) VALUES (?,?,?,?,?)", (eid, _at_now(), act, client_ip(), 'poste'))
            conn.commit()
            st = tc_state(conn, eid)
        allowed = {'out': ['in'], 'done': ['in'], 'in': ['break_start', 'out'], 'break': ['break_end', 'out']}[st['state']]
        return jsonify({'ok': True, 'done': act != 'login', 'action': act, 'name': f"{e['first_name']} {e['last_name']}", 'first_name': e['first_name'],
                        'state': st, 'allowed': allowed, 'time': datetime.datetime.now().strftime('%H:%M')})
    finally:
        conn.close()


# ------------------------------------------------------------
# Routes — feuilles de temps (gestionnaire)
# ------------------------------------------------------------
@app.route('/rh/feuilles-de-temps')
def tc_sheets_page():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    return render_template('tc_sheets.html', company=get_company_name(), is_admin=bool(session.get('is_admin')))


def _tc_period_from_args():
    try:
        d = datetime.date.fromisoformat(request.args.get('start') or '')
    except ValueError:
        d = datetime.date.today()
    return tc_period_of(d)


def _tc_rows(conn, d0, d1, with_events=False):
    rows = []
    for e in conn.execute("SELECT * FROM hr_employees WHERE tc_enabled=1 OR id IN (SELECT DISTINCT employee_id FROM tc_events WHERE deleted=0 AND ts>=? AND ts<?) "
                          "ORDER BY status='inactif', first_name COLLATE NOCASE", (d0.isoformat(), (d1 + datetime.timedelta(days=1)).isoformat())).fetchall():
        sh = tc_sheet(conn, e['id'], d0, d1)
        appr = conn.execute("SELECT approved_by, approved_at FROM tc_approvals WHERE employee_id=? AND period_start=?", (e['id'], d0.isoformat())).fetchone()
        cmp_ = sched_compare(conn, e['id'], [x['date'] for x in sh['days']], sh['days'])
        for x, cinfo in zip(sh['days'], cmp_):
            x.update(cinfo)
        sh['lates'] = sum(1 for c in cmp_ if c['late']); sh['absences'] = sum(1 for c in cmp_ if c['absent'])
        r = {'id': e['id'], 'name': f"{e['first_name']} {e['last_name']}", 'position': e['position'], 'sheet': sh,
             'approved': dict(appr) if appr else None, 'state': tc_state(conn, e['id'])['state'] if d0 <= datetime.date.today() <= d1 else None}
        if with_events:
            r['events'] = tc_events(conn, e['id'], d0, d1)
        rows.append(r)
    return rows


@app.route('/api/tc/sheet')
def api_tc_sheet():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    d0, d1 = _tc_period_from_args()
    conn = get_conn()
    try:
        rows = _tc_rows(conn, d0, d1)
    finally:
        conn.close()
    st = tc_settings()
    late_now = []
    today = datetime.date.today()
    if d0 <= today <= d1:
        now_hm = datetime.datetime.now().strftime('%H:%M'); grace = sched_settings()['grace']
        conn = get_conn()
        try:
            pub = sched_cells(conn, 'sched_published', today, today)
            for e in conn.execute("SELECT id, first_name, last_name FROM hr_employees WHERE tc_enabled=1 AND status<>'inactif'").fetchall():
                c = (pub.get(e['id']) or {}).get(today.isoformat())
                if not c or c['kind'] != 'work':
                    continue
                d = tc_days(tc_events(conn, e['id'], today, today), today, today)[0]
                if not d['first_in'] and _hm(now_hm) > _hm(c['start']) + grace and now_hm < c['end']:
                    late_now.append({'name': f"{e['first_name']} {e['last_name']}", 'kind': 'absent', 'start': c['start']})
                elif d['first_in'] and _hm(d['first_in']) - _hm(c['start']) > grace:
                    late_now.append({'name': f"{e['first_name']} {e['last_name']}", 'kind': 'late', 'start': c['start'],
                                     'minutes': _hm(d['first_in']) - _hm(c['start'])})
        finally:
            conn.close()
    return jsonify({'start': d0.isoformat(), 'end': d1.isoformat(), 'rows': rows, 'period': st['period'], 'late_now': late_now,
                    'prev': (d0 - datetime.timedelta(days=1)).isoformat(), 'next': (d1 + datetime.timedelta(days=1)).isoformat()})


@app.route('/api/tc/day')
def api_tc_day():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    try:
        eid, d = int(request.args.get('employee_id')), datetime.date.fromisoformat(request.args.get('date'))
    except (TypeError, ValueError):
        return jsonify({'error': 'Paramètres invalides.'}), 400
    conn = get_conn()
    try:
        ev = [x for x in tc_events(conn, eid, d, d) if x['ts'][:10] == d.isoformat() or True]
        day = tc_days(ev, d, d)[0]
        return jsonify({'events': [x for x in ev if x['ts'] >= (d - datetime.timedelta(hours=14)).isoformat()], 'day': day, 'kinds': TC_KINDS})
    finally:
        conn.close()


@app.route('/api/tc/events', methods=['POST'])
@app.route('/api/tc/events/<int:ev_id>', methods=['PUT', 'DELETE'])
def api_tc_event(ev_id=None):
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    note = str(d.get('note') or '').strip()[:200]
    conn = get_conn()
    try:
        if request.method == 'DELETE':
            ev = conn.execute("SELECT * FROM tc_events WHERE id=?", (ev_id,)).fetchone()
            if not ev:
                return jsonify({'ok': False, 'error': 'Punch introuvable.'}), 404
            conn.execute("UPDATE tc_events SET deleted=1, corrected_by=?, corrected_at=?, note=? WHERE id=?",
                         (current_display_name(), _at_now(), note or ev['note'], ev_id))
            conn.commit(); log_audit('RH : punch retiré', f"employé #{ev['employee_id']} — {ev['ts']} {TC_KINDS.get(ev['kind'])}")
            return jsonify({'ok': True})
        kind = d.get('kind')
        try:
            ts = datetime.datetime.strptime(str(d.get('ts') or ''), '%Y-%m-%dT%H:%M').strftime(AT_FMT)
        except ValueError:
            return jsonify({'ok': False, 'error': 'Date et heure invalides.'}), 400
        if kind not in TC_KINDS:
            return jsonify({'ok': False, 'error': 'Type de punch invalide.'}), 400
        if not note:
            return jsonify({'ok': False, 'error': 'Indique la raison de la correction (ex. oubli de punch).'}), 400
        if ev_id is None:
            eid = int(d.get('employee_id') or 0)
            conn.execute("INSERT INTO tc_events(employee_id, ts, kind, station, created_by, note, corrected_by, corrected_at) VALUES (?,?,?,?,?,?,?,?)",
                         (eid, ts, kind, 'correction', current_display_name(), note, current_display_name(), _at_now()))
            msg = f"employé #{eid} — ajout {ts} {TC_KINDS[kind]} — {note}"
        else:
            ev = conn.execute("SELECT * FROM tc_events WHERE id=?", (ev_id,)).fetchone()
            if not ev:
                return jsonify({'ok': False, 'error': 'Punch introuvable.'}), 404
            conn.execute("UPDATE tc_events SET ts=?, kind=?, note=?, corrected_by=?, corrected_at=? WHERE id=?",
                         (ts, kind, note, current_display_name(), _at_now(), ev_id))
            msg = f"employé #{ev['employee_id']} — {ev['ts']} → {ts} {TC_KINDS[kind]} — {note}"
        conn.commit()
    finally:
        conn.close()
    log_audit('RH : punch corrigé', msg)
    return jsonify({'ok': True})


@app.route('/api/tc/approve', methods=['POST'])
def api_tc_approve():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    try:
        d0 = datetime.date.fromisoformat(d.get('start'))
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Période invalide.'}), 400
    ids = [int(x) for x in d.get('employee_ids') or []]
    conn = get_conn()
    try:
        for i in ids:
            if d.get('undo'):
                conn.execute("DELETE FROM tc_approvals WHERE employee_id=? AND period_start=?", (i, d0.isoformat()))
            else:
                conn.execute("INSERT OR REPLACE INTO tc_approvals(employee_id, period_start, approved_by, approved_at) VALUES (?,?,?,?)",
                             (i, d0.isoformat(), current_display_name(), _at_now()))
        conn.commit()
    finally:
        conn.close()
    log_audit('RH : feuilles de temps ' + ('désapprouvées' if d.get('undo') else 'approuvées'), f"période du {d0} — {len(ids)} employé(s)")
    return jsonify({'ok': True})


@app.route('/api/tc/export')
def api_tc_export():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    d0, d1 = _tc_period_from_args()
    conn = get_conn()
    try:
        rows = [r for r in _tc_rows(conn, d0, d1, with_events=True) if r['sheet']['total'] or r['sheet']['missing'] or r['events']]
    finally:
        conn.close()
    out = PDF_DIR / "Feuilles_de_temps"; out.mkdir(parents=True, exist_ok=True)
    if request.args.get('fmt') == 'pdf':
        p = export_tc_pdf(rows, d0, d1, out / f"Feuille_de_temps_{d0}_au_{d1}.pdf")
        log_audit('RH : feuille de temps (PDF)', f"{d0} au {d1}")
        return send_file(str(p), mimetype='application/pdf', as_attachment=False, download_name=p.name)
    p = export_tc_xlsx(rows, d0, d1, out / f"Feuille_de_temps_{d0}_au_{d1}.xlsx")
    log_audit('RH : feuille de temps (Excel)', f"{d0} au {d1}")
    return send_file(str(p), as_attachment=True, download_name=p.name)


@app.route('/api/tc/settings', methods=['GET', 'POST'])
def api_tc_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if request.method == 'POST':
        d = request.get_json(silent=True) or {}
        if d.get('period') in ('week', '2weeks'):
            meta_set('tc_period', d['period'])
        if d.get('anchor'):
            try:
                meta_set('tc_anchor', datetime.date.fromisoformat(d['anchor']).isoformat())
            except ValueError:
                return jsonify({'ok': False, 'error': 'Date de début invalide.'}), 400
        if d.get('code') is not None:
            c = str(d['code']).strip()
            if len(c) < 6:
                return jsonify({'ok': False, 'error': "Le code d'accès doit avoir au moins 6 caractères."}), 400
            meta_set('tc_code_hash', generate_password_hash(c))
        if d.get('revoke'):
            meta_set('tc_secret', secrets.token_urlsafe(16)); meta_set('tc_link_token', secrets.token_urlsafe(24))
        log_audit('RH : réglages du punch modifiés', json.dumps({k: v for k, v in d.items() if k != 'code'}, ensure_ascii=False))
    st = tc_settings()
    return jsonify({'ok': True, 'period': st['period'], 'anchor': st['anchor'].isoformat(), 'has_code': bool(meta_get('tc_code_hash')),
                    'link': request.host_url.rstrip('/') + url_for('tc_station_page', cle=tc_link_token())})


# ------------------------------------------------------------
# Routes — documents RH : publier, signer, envoyer ; accès au portail
# ------------------------------------------------------------
@app.route('/api/rh/documents/<int:did>/publish', methods=['POST'])
def api_hr_doc_publish(did):
    resp = _hr_check()
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    conn = get_conn()
    try:
        doc = conn.execute("SELECT * FROM hr_documents WHERE id=?", (did,)).fetchone()
        if not doc:
            return jsonify({'ok': False, 'error': 'Document introuvable.'}), 404
        pub = bool(d.get('published'))
        sign = bool(d.get('sign_required')) and pub
        if sign and not doc['filename'].lower().endswith('.pdf'):
            return jsonify({'ok': False, 'error': 'Seuls les documents PDF peuvent être signés.'}), 400
        if sign:
            hr_doc_file_hash(conn, did)
        conn.execute("UPDATE hr_documents SET published=?, published_at=?, sign_required=? WHERE id=?",
                     (1 if pub else 0, _at_now() if pub and not doc['published'] else doc['published_at'], 1 if sign else 0, did))
        hr_log(conn, doc['employee_id'], ('Publié dans le portail' if pub else 'Retiré du portail') + f" : {doc['title']}" + (' (signature demandée)' if sign else ''))
        conn.commit()
    finally:
        conn.close()
    return jsonify({'ok': True})


@app.route('/api/rh/documents/<int:did>/sign', methods=['POST'])
def api_hr_doc_sign(did):
    resp = _hr_check()
    if resp is not None:
        return resp
    try:
        sig = hr_sig_clean(request.get_json(silent=True) or {})
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    conn = get_conn()
    try:
        doc = conn.execute("SELECT * FROM hr_documents WHERE id=?", (did,)).fetchone()
        if not doc or not doc['filename'].lower().endswith('.pdf'):
            return jsonify({'ok': False, 'error': 'Seuls les documents PDF peuvent être signés.'}), 400
        hr_doc_file_hash(conn, did)
        conn.execute("UPDATE hr_documents SET mgr_sig=?, mgr_signed_at=?, mgr_signed_by=? WHERE id=?",
                     (json.dumps(sig, ensure_ascii=False), _at_now(), current_display_name(), did))
        hr_build_signed_pdf(conn, did)
        hr_log(conn, doc['employee_id'], f"Signé par le gestionnaire : {doc['title']}")
        conn.commit()
    finally:
        conn.close()
    log_audit('RH : document signé (gestionnaire)', doc['title'] or '')
    return jsonify({'ok': True})


@app.route('/api/rh/documents/<int:did>/email', methods=['POST'])
def api_hr_doc_email(did):
    resp = _hr_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        doc = conn.execute("SELECT * FROM hr_documents WHERE id=?", (did,)).fetchone()
        if not doc:
            return jsonify({'ok': False, 'error': 'Document introuvable.'}), 404
        e = dict(conn.execute("SELECT * FROM hr_employees WHERE id=?", (doc['employee_id'],)).fetchone())
        if not e.get('email'):
            return jsonify({'ok': False, 'error': "Aucun courriel n'est inscrit dans le profil de l'employé."}), 400
        folder = HR_DIR / str(doc['employee_id'])
        p = folder / (doc['signed_filename'] or doc['filename'])
        if p.suffix.lower() != '.pdf':
            return jsonify({'ok': False, 'error': 'Seuls les documents PDF peuvent être envoyés par courriel.'}), 400
        signed = bool(doc['signed_filename'])
        body = (f"Bonjour {e['first_name']},\n\nTu trouveras ci-joint une copie du document « {doc['title']} »"
                + (" avec les signatures." if signed else ".") + f"\n\nCe courriel est confidentiel.\n\n{get_company_name()}")
        try:
            send_email(e['email'], f"{get_company_name()} — {doc['title']}", body, str(p), mode='send', bcc_company=False)
        except Exception as ex:
            return jsonify({'ok': False, 'error': f"Envoi impossible : {ex}"}), 400
        conn.execute("UPDATE hr_documents SET emailed_at=? WHERE id=?", (_at_now(), did))
        hr_log(conn, doc['employee_id'], f"Copie envoyée par courriel : {doc['title']}"); conn.commit()
    finally:
        conn.close()
    log_audit('RH : document envoyé par courriel', f"{doc['title']} → {e['email']}")
    return jsonify({'ok': True, 'to': e['email']})


@app.route('/api/rh/employees/<int:eid>/portal', methods=['POST'])
def api_hr_portal(eid):
    resp = _hr_check()
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    act = d.get('action')
    conn = get_conn()
    try:
        e = conn.execute("SELECT * FROM hr_employees WHERE id=?", (eid,)).fetchone()
        if not e:
            return jsonify({'ok': False, 'error': 'Employé introuvable.'}), 404
        if act == 'revoke':
            conn.execute("UPDATE hr_portal SET active=0, token=NULL WHERE employee_id=?", (eid,))
            hr_log(conn, eid, 'Accès au portail retiré'); conn.commit()
            log_audit('RH : accès au portail retiré', hr_emp_name(e))
            return jsonify({'ok': True})
        if not e['email']:
            return jsonify({'ok': False, 'error': "Inscris d'abord le courriel de l'employé dans son profil : il servira à se connecter."}), 400
        login = e['email'].strip().lower()
        dup = conn.execute("SELECT employee_id FROM hr_portal WHERE login=? AND employee_id<>?", (login, eid)).fetchone()
        if dup:
            return jsonify({'ok': False, 'error': 'Ce courriel est déjà utilisé par le portail d\u2019un autre employé.'}), 400
        tok = secrets.token_urlsafe(24); exp = (datetime.datetime.now() + datetime.timedelta(days=7)).strftime(AT_FMT)
        if conn.execute("SELECT 1 FROM hr_portal WHERE employee_id=?", (eid,)).fetchone():
            conn.execute("UPDATE hr_portal SET login=?, active=1, token=?, token_expires=?, invited_at=? WHERE employee_id=?", (login, tok, exp, _at_now(), eid))
        else:
            conn.execute("INSERT INTO hr_portal(employee_id, login, active, token, token_expires, invited_at, created_at) VALUES (?,?,1,?,?,?,?)",
                         (eid, login, tok, exp, _at_now(), _at_now()))
        hr_log(conn, eid, 'Invitation au portail envoyée'); conn.commit()
    finally:
        conn.close()
    link = request.host_url.rstrip('/') + url_for('emp_activate', t=tok)
    sent, err = False, None
    try:
        send_email(login, f"{get_company_name()} — ton espace employé",
                   f"Bonjour {e['first_name']},\n\n{get_company_name()} t'a créé un espace employé dans Kubios : tu pourras y consulter tes heures "
                   f"et tes documents, et signer ceux qui te sont envoyés.\n\nPour choisir ton mot de passe, ouvre ce lien (valide 7 jours) :\n{link}\n\n"
                   f"Ton identifiant : {login}\n\n{get_company_name()}", None, mode='send', bcc_company=False)
        sent = True
    except Exception as ex:
        err = str(ex)
    log_audit('RH : invitation au portail', f"{hr_emp_name(e)} — {'envoyée' if sent else 'non envoyée : ' + (err or '')}")
    return jsonify({'ok': True, 'sent': sent, 'error': err, 'link': link, 'login': login})


@app.route('/api/rh/employees/<int:eid>/punch', methods=['POST'])
def api_hr_emp_punch_cfg(eid):
    resp = _hr_check()
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    conn = get_conn()
    try:
        e = conn.execute("SELECT * FROM hr_employees WHERE id=?", (eid,)).fetchone()
        if not e:
            return jsonify({'ok': False, 'error': 'Employé introuvable.'}), 404
        if 'enabled' in d:
            conn.execute("UPDATE hr_employees SET tc_enabled=? WHERE id=?", (1 if d['enabled'] else 0, eid))
        if d.get('pin'):
            pin = str(d['pin']).strip()
            if not re.fullmatch(r'\d{4,6}', pin):
                return jsonify({'ok': False, 'error': 'Le NIP doit avoir de 4 à 6 chiffres.'}), 400
            conn.execute("UPDATE hr_employees SET tc_pin_hash=? WHERE id=?", (generate_password_hash(pin), eid))
        hr_log(conn, eid, 'Réglages du punch modifiés'); conn.commit()
    finally:
        conn.close()
    return jsonify({'ok': True})


# ------------------------------------------------------------
# Routes — portail employé
# ------------------------------------------------------------
def _emp_render(mode, **kw):
    return render_template('employe_auth.html', mode=mode, company=get_company_name(), app_name=APP_NAME, year=datetime.date.today().year,
                           bg_url=login_bg_url(), bg_mode=login_bg_mode(), video_url=login_video_url(), **kw)


@app.route('/employe/connexion', methods=['GET', 'POST'])
def emp_login():
    if request.method == 'POST':
        login = (request.form.get('login') or '').strip().lower()
        key = 'emp:' + login
        f = _tc_fail.get(key, {'n': 0, 'until': 0})
        if f['until'] > time.time():
            return _emp_render('login', error="Trop d'essais. Réessaie dans quelques minutes.", login=login)
        conn = get_conn()
        try:
            p = conn.execute("SELECT p.*, e.status FROM hr_portal p JOIN hr_employees e ON e.id=p.employee_id WHERE p.login=?", (login,)).fetchone()
            ok = p and p['active'] and p['status'] != 'inactif' and p['password_hash'] and check_password_hash(p['password_hash'], request.form.get('password') or '')
            if ok:
                conn.execute("UPDATE hr_portal SET last_login=? WHERE employee_id=?", (_at_now(), p['employee_id']))
                hr_log(conn, p['employee_id'], 'Connexion au portail (employé)'); conn.commit()
        finally:
            conn.close()
        if ok:
            _tc_fail.pop(key, None)
            session['emp_id'] = p['employee_id']; session.permanent = True
            try:
                conn2 = get_conn()
                e2 = conn2.execute("SELECT first_name, last_name FROM hr_employees WHERE id=?", (p['employee_id'],)).fetchone()
                conn2.close()
                session['emp_sid'] = sess_open('portail', p['employee_id'], login, f"{e2['first_name']} {e2['last_name']}" if e2 else login)
                session['emp_sid_ts'] = time.time()
            except Exception:
                traceback.print_exc()
            return redirect(url_for('emp_home'))
        f['n'] += 1
        if f['n'] >= 6:
            f = {'n': 0, 'until': time.time() + 600}
        _tc_fail[key] = f
        return _emp_render('login', error='Courriel ou mot de passe incorrect.', login=login)
    if emp_session_emp():
        return redirect(url_for('emp_home'))
    return _emp_render('login', error="Ta session a été fermée par ton gestionnaire." if session.pop('emp_kicked', None) else None, login='')


@app.route('/employe/deconnexion')
def emp_logout():
    sess_close(session.get('emp_sid'), 'déconnexion')
    session.pop('emp_id', None); session.pop('emp_sid', None)
    return redirect(url_for('emp_login'))


@app.route('/employe/activer', methods=['GET', 'POST'])
def emp_activate():
    tok = request.values.get('t') or ''
    conn = get_conn()
    try:
        p = conn.execute("SELECT p.*, e.first_name FROM hr_portal p JOIN hr_employees e ON e.id=p.employee_id WHERE p.token=? AND p.active=1", (tok,)).fetchone() if tok else None
        if not p or (p['token_expires'] or '') < _at_now():
            return _emp_render('expired', error=None)
        if request.method == 'POST':
            pw, pw2 = request.form.get('password') or '', request.form.get('password2') or ''
            if len(pw) < 8:
                return _emp_render('activate', error='Le mot de passe doit avoir au moins 8 caractères.', t=tok, first_name=p['first_name'], login=p['login'])
            if pw != pw2:
                return _emp_render('activate', error='Les deux mots de passe ne sont pas identiques.', t=tok, first_name=p['first_name'], login=p['login'])
            conn.execute("UPDATE hr_portal SET password_hash=?, token=NULL, token_expires=NULL WHERE employee_id=?", (generate_password_hash(pw), p['employee_id']))
            hr_log(conn, p['employee_id'], 'Mot de passe du portail défini (employé)'); conn.commit()
            session['emp_id'] = p['employee_id']; session.permanent = True
            return redirect(url_for('emp_home'))
        return _emp_render('activate', error=None, t=tok, first_name=p['first_name'], login=p['login'])
    finally:
        conn.close()


@app.route('/employe/mot-de-passe-oublie', methods=['GET', 'POST'])
def emp_forgot():
    if request.method == 'POST':
        login = (request.form.get('login') or '').strip().lower()
        conn = get_conn()
        try:
            p = conn.execute("SELECT p.*, e.first_name FROM hr_portal p JOIN hr_employees e ON e.id=p.employee_id WHERE p.login=? AND p.active=1", (login,)).fetchone()
            if p:
                tok = secrets.token_urlsafe(24)
                conn.execute("UPDATE hr_portal SET token=?, token_expires=? WHERE employee_id=?",
                             (tok, (datetime.datetime.now() + datetime.timedelta(hours=2)).strftime(AT_FMT), p['employee_id'])); conn.commit()
                try:
                    send_email(login, f"{get_company_name()} — nouveau mot de passe",
                               f"Bonjour {p['first_name']},\n\nPour choisir un nouveau mot de passe pour ton espace employé, ouvre ce lien (valide 2 heures) :\n"
                               f"{request.host_url.rstrip('/') + url_for('emp_activate', t=tok)}\n\nSi tu n'as rien demandé, ignore ce courriel.\n\n{get_company_name()}",
                               None, mode='send', bcc_company=False)
                except Exception:
                    traceback.print_exc()
        finally:
            conn.close()
        return _emp_render('forgot_sent', error=None)
    return _emp_render('forgot', error=None)


@app.route('/employe')
def emp_home():
    e = emp_session_emp()
    if not e:
        return redirect(url_for('emp_login'))
    return render_template('employe.html', company=get_company_name(), emp=e)


@app.route('/api/emp/me')
def api_emp_me():
    e = emp_session_emp()
    if not e:
        return jsonify({'error': 'Session expirée.'}), 401
    conn = get_conn()
    try:
        st = tc_state(conn, e['id']) if e.get('tc_enabled') else None
        to_sign = conn.execute("SELECT COUNT(*) FROM hr_documents WHERE employee_id=? AND published=1 AND sign_required=1 AND emp_signed_at IS NULL", (e['id'],)).fetchone()[0]
    finally:
        conn.close()
    return jsonify({'first_name': e['first_name'], 'last_name': e['last_name'], 'position': e['position'], 'tc': bool(e.get('tc_enabled')),
                    'state': st, 'to_sign': to_sign, 'company': get_company_name(), 'weekly_hours': 40})


@app.route('/api/emp/hours')
def api_emp_hours():
    e = emp_session_emp()
    if not e:
        return jsonify({'error': 'Session expirée.'}), 401
    try:
        d = datetime.date.fromisoformat(request.args.get('start') or '')
    except ValueError:
        d = datetime.date.today()
    w0 = d - datetime.timedelta(days=d.weekday()); w1 = w0 + datetime.timedelta(days=6)
    conn = get_conn()
    try:
        sh = tc_sheet(conn, e['id'], w0, w1)
    finally:
        conn.close()
    return jsonify({'start': w0.isoformat(), 'end': w1.isoformat(), 'sheet': sh,
                    'prev': (w0 - datetime.timedelta(days=7)).isoformat(), 'next': (w0 + datetime.timedelta(days=7)).isoformat()})


@app.route('/api/emp/documents')
def api_emp_documents():
    e = emp_session_emp()
    if not e:
        return jsonify({'error': 'Session expirée.'}), 401
    conn = get_conn()
    try:
        rows = [dict(r) for r in conn.execute("SELECT id, category, title, published_at, sign_required, mgr_signed_at, mgr_signed_by, emp_signed_at, viewed_at, filename "
                                              "FROM hr_documents WHERE employee_id=? AND published=1 ORDER BY published_at DESC", (e['id'],)).fetchall()]
    finally:
        conn.close()
    for r in rows:
        r['category_label'] = HR_DOC_CATS.get(r['category'], r['category']); r['pdf'] = r.pop('filename', '').lower().endswith('.pdf')
    return jsonify({'documents': rows})


@app.route('/api/emp/documents/<int:did>/file')
def api_emp_doc_file(did):
    e = emp_session_emp()
    if not e:
        return "Session expirée.", 401
    conn = get_conn()
    try:
        d = conn.execute("SELECT * FROM hr_documents WHERE id=? AND employee_id=? AND published=1", (did, e['id'])).fetchone()
        if not d:
            return "Document introuvable.", 404
        if not d['viewed_at']:
            conn.execute("UPDATE hr_documents SET viewed_at=? WHERE id=?", (_at_now(), did))
        hr_log(conn, e['id'], f"Document consulté par l'employé : {d['title']}"); conn.commit()
    finally:
        conn.close()
    p = HR_DIR / str(e['id']) / (d['signed_filename'] or d['filename'])
    if not p.exists():
        return "Fichier introuvable.", 404
    return send_file(str(p), as_attachment=request.args.get('dl') == '1', download_name=(d['title'] or 'document') + p.suffix)


@app.route('/api/emp/documents/<int:did>/sign', methods=['POST'])
def api_emp_doc_sign(did):
    e = emp_session_emp()
    if not e:
        return jsonify({'ok': False, 'error': 'Session expirée.'}), 401
    d = request.get_json(silent=True) or {}
    if not d.get('ack'):
        return jsonify({'ok': False, 'error': 'Coche la case « J\u2019ai lu ce document ».'}), 400
    try:
        sig = hr_sig_clean(d)
    except ValueError as ex:
        return jsonify({'ok': False, 'error': str(ex)}), 400
    conn = get_conn()
    try:
        doc = conn.execute("SELECT * FROM hr_documents WHERE id=? AND employee_id=? AND published=1 AND sign_required=1", (did, e['id'])).fetchone()
        if not doc:
            return jsonify({'ok': False, 'error': 'Ce document ne demande pas de signature.'}), 404
        if doc['emp_signed_at']:
            return jsonify({'ok': False, 'error': 'Tu as déjà signé ce document.'}), 409
        h = hashlib.sha256((HR_DIR / str(e['id']) / doc['filename']).read_bytes()).hexdigest()
        if doc['doc_hash'] and h != doc['doc_hash']:
            return jsonify({'ok': False, 'error': 'Le document a été modifié depuis sa publication : demande à ton gestionnaire de le republier.'}), 409
        conn.execute("UPDATE hr_documents SET emp_sig=?, emp_signed_at=?, emp_comment=?, emp_sign_ip=?, doc_hash=? WHERE id=?",
                     (json.dumps(sig, ensure_ascii=False), _at_now(), str(d.get('comment') or '').strip()[:1000] or None, client_ip(), h, did))
        hr_build_signed_pdf(conn, did)
        hr_log(conn, e['id'], f"Signé par l'employé : {doc['title']}"); conn.commit()
    finally:
        conn.close()
    db_add_audit(f"Portail — {e['first_name']} {e['last_name']}", 'Document signé (employé)', doc['title'] or '')
    return jsonify({'ok': True})


@app.route('/api/atelier/hubtiger/preview', methods=['POST'])
def api_atelier_ht_preview():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    f = request.files.get('file')
    if not f or not f.filename or Path(f.filename).suffix.lower() not in ('.xlsx', '.csv'):
        return jsonify({'ok': False, 'error': "Choisis l'export HubTiger (fichier .xlsx ou .csv)."}), 400
    tmp = BASE_DIR / ('_import_hubtiger' + Path(f.filename).suffix.lower())
    f.save(str(tmp))
    try:
        items = ht_parse(tmp)
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass
    if not items:
        return jsonify({'ok': False, 'error': 'Aucun bon trouvé dans ce fichier.'}), 400
    include_done = request.form.get('include_done', '1') == '1'
    conn = get_conn()
    try:
        plan = ht_plan(conn, items, include_done)
    finally:
        conn.close()
    token = secrets.token_hex(8)
    HT_PENDING.write_text(json.dumps({'token': token, 'user': session.get('username'), 'items': items, 'include_done': include_done,
                                      'file': f.filename}, ensure_ascii=False), encoding='utf-8')
    return jsonify({'ok': True, 'token': token, 'total': len(items), 'file': f.filename, **ht_summary(plan)})


@app.route('/api/atelier/hubtiger/import', methods=['POST'])
def api_atelier_ht_import():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    try:
        pend = json.loads(HT_PENDING.read_text(encoding='utf-8'))
    except Exception:
        pend = None
    if not pend or pend.get('token') != d.get('token'):
        return jsonify({'ok': False, 'error': "L'aperçu n'est plus disponible : dépose le fichier de nouveau."}), 400
    conn = get_conn()
    try:
        res = ht_apply(conn, ht_plan(conn, pend['items'], pend['include_done']), current_display_name())
    finally:
        conn.close()
    try:
        HT_PENDING.unlink()
    except OSError:
        pass
    return jsonify({'ok': True, **res})


@app.route('/api/atelier/hubtiger/settings', methods=['GET', 'POST'])
def api_atelier_ht_settings():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    if request.method == 'POST':
        d = request.get_json(silent=True) or {}
        if 'drop' in d:
            meta_set('ht_drop_enabled', '1' if d['drop'] else '0')
            if d['drop']:
                HT_DROP_DIR.mkdir(parents=True, exist_ok=True)
        if 'include_done' in d:
            meta_set('ht_include_done', '1' if d['include_done'] else '0')
        log_audit('Atelier : réglages de l\u2019import HubTiger', json.dumps(d, ensure_ascii=False))
    try:
        last = json.loads(meta_get('ht_last_drop') or 'null')
    except ValueError:
        last = None
    return jsonify({'ok': True, 'drop': meta_get('ht_drop_enabled') == '1', 'include_done': meta_get('ht_include_done') != '0',
                    'folder': str(HT_DROP_DIR), 'last': last})


# ------------------------------------------------------------
# Routes — horaires (gestionnaire)
# ------------------------------------------------------------
@app.route('/rh/horaires')
def sched_page():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    return render_template('sched.html', company=get_company_name(), is_admin=bool(session.get('is_admin')))


def sched_period_of(d):
    """L'horaire se fait toujours sur 2 semaines (Période 1 et Période 2), alignées sur la date de départ de la paie."""
    anchor = tc_settings()['anchor']
    monday = d - datetime.timedelta(days=d.weekday())
    start = anchor + datetime.timedelta(days=14 * ((monday - anchor).days // 14))
    return start, start + datetime.timedelta(days=13)


def _sched_period():
    try:
        d = datetime.date.fromisoformat(request.values.get('start') or '')
    except ValueError:
        d = datetime.date.today()
    return sched_period_of(d)


@app.route('/api/sched')
def api_sched():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    d0, d1 = _sched_period()
    conn = get_conn()
    try:
        draft, pub = sched_cells(conn, 'sched_shifts', d0, d1), sched_cells(conn, 'sched_published', d0, d1)
        emps = sched_employees(conn)
        changed = 0
        for e in emps:
            for i in range((d1 - d0).days + 1):
                day = (d0 + datetime.timedelta(days=i)).isoformat()
                if not _sched_same((draft.get(e['id']) or {}).get(day), (pub.get(e['id']) or {}).get(day)):
                    changed += 1
    finally:
        conn.close()
    return jsonify({'start': d0.isoformat(), 'end': d1.isoformat(), 'prev': (d0 - datetime.timedelta(days=1)).isoformat(),
                    'next': (d1 + datetime.timedelta(days=1)).isoformat(), 'employees': [{k: e[k] for k in ('id', 'first_name', 'last_name', 'department', 'position')} for e in emps],
                    'draft': draft, 'published': pub, 'changed': changed, 'last_publish': meta_get('sched_last_publish'), 'settings': sched_settings()})


@app.route('/api/sched/cells', methods=['POST'])
def api_sched_cells():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    cells = (request.get_json(silent=True) or {}).get('cells') or []
    conn = get_conn()
    try:
        for c in cells[:400]:
            eid, day = int(c.get('employee_id') or 0), str(c.get('day') or '')
            datetime.date.fromisoformat(day)
            kind = c.get('kind')
            if kind is None:
                conn.execute("DELETE FROM sched_shifts WHERE employee_id=? AND day=?", (eid, day)); continue
            if kind not in ('work', 'off'):
                return jsonify({'ok': False, 'error': 'Type de journée invalide.'}), 400
            start, end, meal = (c.get('start') or None), (c.get('end') or None), (c.get('meal') or None)
            if kind == 'work':
                if not (start and end and re.fullmatch(r'\d\d:\d\d', start) and re.fullmatch(r'\d\d:\d\d', end)) or _hm(end) <= _hm(start):
                    return jsonify({'ok': False, 'error': 'Heures de début et de fin invalides.'}), 400
                if meal and (not re.fullmatch(r'\d\d:\d\d', meal) or not (_hm(start) <= _hm(meal) <= _hm(end) - 60)):
                    return jsonify({'ok': False, 'error': 'Le repas doit être pendant le quart.'}), 400
            else:
                start = end = meal = None
            conn.execute("INSERT OR REPLACE INTO sched_shifts(employee_id, day, kind, start, end, meal, note, updated_at, updated_by) VALUES (?,?,?,?,?,?,?,?,?)",
                         (eid, day, kind, start, end, meal, str(c.get('note') or '').strip()[:120] or None, _at_now(), current_display_name()))
        conn.commit()
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Données invalides.'}), 400
    finally:
        conn.close()
    return jsonify({'ok': True})


@app.route('/api/sched/copy', methods=['POST'])
def api_sched_copy():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    d0, d1 = _sched_period()
    mode = request.values.get('mode') or 'prev'
    w2 = d0 + datetime.timedelta(days=7)
    if mode == 'p1_to_p2':        # même chose la 2e semaine
        p0, p1, t0, t1 = d0, d0 + datetime.timedelta(days=6), w2, d1
    elif mode == 'p2_to_p1':
        p0, p1, t0, t1 = w2, d1, d0, d0 + datetime.timedelta(days=6)
    else:                          # les 2 semaines précédentes
        p0, p1 = d0 - datetime.timedelta(days=14), d0 - datetime.timedelta(days=1)
        t0, t1 = d0, d1
    off = (t0 - p0).days
    conn = get_conn()
    try:
        src = [dict(r) for r in conn.execute("SELECT * FROM sched_shifts WHERE day BETWEEN ? AND ?", (p0.isoformat(), p1.isoformat())).fetchall()]
        if not src:
            return jsonify({'ok': False, 'error': "Il n'y a pas d'horaire à copier pour ces dates."}), 400
        conn.execute("DELETE FROM sched_shifts WHERE day BETWEEN ? AND ?", (t0.isoformat(), t1.isoformat()))
        for r in src:
            nd = (datetime.date.fromisoformat(r['day']) + datetime.timedelta(days=off)).isoformat()
            if t0.isoformat() <= nd <= t1.isoformat():
                conn.execute("INSERT OR REPLACE INTO sched_shifts(employee_id, day, kind, start, end, meal, note, updated_at, updated_by) VALUES (?,?,?,?,?,?,?,?,?)",
                             (r['employee_id'], nd, r['kind'], r['start'], r['end'], r['meal'], None, _at_now(), current_display_name()))
        conn.commit()
    finally:
        conn.close()
    log_audit('RH : horaire copié', f"{p0} au {p1} → {t0} au {t1}")
    return jsonify({'ok': True, 'copied': len(src)})


@app.route('/api/sched/publish', methods=['POST'])
def api_sched_publish():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    d0, d1 = _sched_period()
    conn = get_conn()
    try:
        draft, pub = sched_cells(conn, 'sched_shifts', d0, d1), sched_cells(conn, 'sched_published', d0, d1)
        emps = {e['id']: e for e in sched_employees(conn)}
        changes = {}
        for eid in set(draft) | set(pub):
            for i in range((d1 - d0).days + 1):
                day = (d0 + datetime.timedelta(days=i)).isoformat()
                a, b = (pub.get(eid) or {}).get(day), (draft.get(eid) or {}).get(day)
                if not _sched_same(a, b):
                    changes.setdefault(eid, []).append((day, a, b))
        conn.execute("DELETE FROM sched_published WHERE day BETWEEN ? AND ?", (d0.isoformat(), d1.isoformat()))
        conn.execute("INSERT INTO sched_published SELECT * FROM sched_shifts WHERE day BETWEEN ? AND ?", (d0.isoformat(), d1.isoformat()))
        first = not pub
        sent, failed = 0, 0
        for eid, ch in changes.items():
            e = emps.get(eid)
            if not e:
                continue
            fmt = lambda c: sched_label(c) if c else 'aucun quart'
            if first or not any(pub.get(eid, {}).values()):
                txt = f"Ton horaire du {sched_day_fr(d0.isoformat())} au {sched_day_fr(d1.isoformat())} est publié."
                lines = [f"  • {sched_day_fr(day)} : {fmt(b)}" for day, a, b in sorted(ch) if b]
            else:
                txt = f"Ton horaire a changé ({len(ch)} journée{'s' if len(ch) > 1 else ''})."
                lines = [f"  • {sched_day_fr(day)} : {fmt(b)} (avant : {fmt(a)})" for day, a, b in sorted(ch)]
            short = txt if len(ch) > 3 else txt + ' ' + ' ; '.join(f"{sched_day_fr(day)} : {fmt(b)}" for day, a, b in sorted(ch))
            conn.execute("INSERT INTO sched_notices(employee_id, created_at, text) VALUES (?,?,?)", (eid, _at_now(), short[:400]))
            if e.get('email'):
                try:
                    send_email(e['email'], f"{get_company_name()} — ton horaire",
                               f"Bonjour {e['first_name']},\n\n{txt}\n\n" + '\n'.join(lines) +
                               "\n\nTu peux consulter ton horaire complet dans ton espace employé.\n\n" + get_company_name(), None, mode='send', bcc_company=False)
                    sent += 1
                except Exception:
                    failed += 1
        conn.commit()
    finally:
        conn.close()
    meta_set('sched_last_publish', _at_now())
    log_audit('RH : horaire publié', f"{d0} au {d1} — {len(changes)} employé(s) touché(s), {sent} courriel(s) envoyé(s), {failed} échec(s)")
    return jsonify({'ok': True, 'employees': len(changes), 'sent': sent, 'failed': failed})


@app.route('/api/sched/pdf')
def api_sched_pdf():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    d0, d1 = _sched_period()
    out = PDF_DIR / "Horaires"; out.mkdir(parents=True, exist_ok=True)
    conn = get_conn()
    try:
        p = export_sched_pdf(conn, d0, d1, out / f"Horaire_{d0}_au_{d1}.pdf")
    finally:
        conn.close()
    return send_file(str(p), mimetype='application/pdf', as_attachment=False, download_name=p.name)


@app.route('/api/sched/settings', methods=['POST'])
def api_sched_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    if 'templates' in d:
        tpl = [[a, b] for a, b in d['templates'] if re.fullmatch(r'\d\d:\d\d', a or '') and re.fullmatch(r'\d\d:\d\d', b or '') and _hm(b) > _hm(a)][:8]
        if not tpl:
            return jsonify({'ok': False, 'error': 'Au moins un quart type est requis.'}), 400
        meta_set('sched_templates', json.dumps(tpl))
    if 'closed' in d:
        meta_set('sched_closed_days', ','.join(str(int(x)) for x in d['closed'] if 0 <= int(x) <= 6))
    if 'grace' in d:
        meta_set('sched_late_grace', str(max(0, min(60, int(d['grace'] or 0)))))
    log_audit('RH : réglages des horaires', json.dumps(d, ensure_ascii=False))
    return jsonify({'ok': True, 'settings': sched_settings()})


# ------------------------------------------------------------
# Routes — horaire dans le portail employé
# ------------------------------------------------------------
@app.route('/api/emp/schedule')
def api_emp_schedule():
    e = emp_session_emp()
    if not e:
        return jsonify({'error': 'Session expirée.'}), 401
    try:
        d = datetime.date.fromisoformat(request.args.get('start') or '')
    except ValueError:
        d = datetime.date.today()
    w0 = d - datetime.timedelta(days=d.weekday()); w1 = w0 + datetime.timedelta(days=13)
    conn = get_conn()
    try:
        everyone = request.args.get('all') == '1'
        cells = sched_cells(conn, 'sched_published', w0, w1, None if everyone else e['id'])
        notices = [dict(r) for r in conn.execute("SELECT id, created_at, text FROM sched_notices WHERE employee_id=? AND seen_at IS NULL ORDER BY id DESC LIMIT 3", (e['id'],)).fetchall()]
        if request.args.get('seen') == '1':
            conn.execute("UPDATE sched_notices SET seen_at=? WHERE employee_id=? AND seen_at IS NULL", (_at_now(), e['id'])); conn.commit()
        emps = sched_employees(conn) if everyone else []
    finally:
        conn.close()
    for eid in cells:
        for c in cells[eid].values():
            c['paid'] = sched_paid_min(c)
            if eid != e['id']:
                c['note'] = ''                      # les notes ne sont visibles que par l'employé concerné
    return jsonify({'start': w0.isoformat(), 'mine': cells.get(e['id'], {}), 'all': {str(k): v for k, v in cells.items()} if everyone else None,
                    'employees': [{'id': x['id'], 'name': f"{x['first_name']} {x['last_name']}", 'department': x['department'] or ''} for x in emps],
                    'notices': notices, 'closed': sched_settings()['closed'], 'me': e['id'],
                    'prev': (w0 - datetime.timedelta(days=7)).isoformat(), 'next': (w0 + datetime.timedelta(days=7)).isoformat()})


@app.route('/logout')
def logout():
    if session.get('username'):
        db_add_audit(session.get('username'), 'Déconnexion')
    sess_close(session.get('sid'), 'déconnexion')
    emp_keep = {k: session.get(k) for k in ('emp_id', 'emp_sid', 'emp_sid_ts') if session.get(k)}
    session.clear()
    session.update(emp_keep)                       # se déconnecter de Kubios ne ferme pas le portail employé
    return redirect(url_for('login'))


@app.route('/admin/users')
def admin_users_page():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return render_template('admin_users.html', company=get_company_name(), username=session.get('username'),
                            permission_keys=PERMISSION_KEYS)


@app.route('/audit')
def audit_page():
    resp = permission_required_check('audit')
    if resp is not None:
        return resp
    return render_template('audit.html', company=get_company_name(), username=session.get('username'),
                            is_admin=session.get('is_admin', False), permissions=session.get('permissions') or [])


@app.route('/api/audit')
def api_audit():
    resp = permission_required_check('audit')
    if resp is not None:
        return resp
    return jsonify(db_list_audit())


@app.route('/admin/email-settings')
def email_settings_page():
    resp = permission_required_check('email_settings')
    if resp is not None:
        return resp
    return render_template('email_settings.html', company=get_company_name(), username=session.get('username'),
                            is_admin=session.get('is_admin', False), permissions=session.get('permissions') or [])


@app.route('/api/settings/send-mode')
def api_send_mode():
    return jsonify(get_public_settings())


# ============================================================
# Routes — Administration (personnalisation : nom d'entreprise, logo des
# PDF, textes des PDF/courriels). Réservé aux administrateurs.
# ============================================================
ADMIN_SETTINGS_LOGO_EXTS = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp'}
ADMIN_SETTINGS_LOGO_MAX_BYTES = 5 * 1024 * 1024  # 5 Mo


@app.route('/admin/settings')
def admin_settings_page():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return render_template('admin_settings.html', company=get_company_name(), app_name=APP_NAME,
                            username=session.get('username'))


@app.route('/api/admin-settings')
def api_get_admin_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return jsonify({
        'company_name': get_company_name(),
        'company_email': get_company_email(),
        'company_phone': get_company_phone(),
        'pdf_footer_message': get_pdf_footer_message(),
        'email_closing_message': get_email_closing_message(),
        'logo_customized': bool(meta_get('logo_customized')),
        'login_bg_customized': _login_bg_custom_file() is not None,
        'login_bg_url': login_bg_url(),
        'login_bg_mode': meta_get('login_bg_mode') or 'mosaique',
        'login_video_url': login_video_url(),
        'defaults': {
            'company_name': COMPANY_NAME_DEFAULT,
            'company_email': COMPANY_EMAIL_DEFAULT,
            'company_phone': COMPANY_PHONE_DEFAULT,
            'pdf_footer_message': PDF_FOOTER_MESSAGE_DEFAULT,
            'email_closing_message': EMAIL_CLOSING_MESSAGE_DEFAULT,
        },
    })


@app.route('/api/admin-settings', methods=['POST'])
def api_set_admin_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}

    name = (data.get('company_name') or '').strip()
    if not name:
        return jsonify({'error': 'Le nom de l\'entreprise est requis.'}), 400

    email = (data.get('company_email') or '').strip()
    if email and '@' not in email:
        return jsonify({'error': 'Adresse courriel invalide.'}), 400

    meta_set('company_name', name)
    meta_set('company_email', email)
    meta_set('company_phone', (data.get('company_phone') or '').strip())
    meta_set('pdf_footer_message', (data.get('pdf_footer_message') or '').strip() or PDF_FOOTER_MESSAGE_DEFAULT)
    meta_set('email_closing_message', (data.get('email_closing_message') or '').strip() or EMAIL_CLOSING_MESSAGE_DEFAULT)

    log_audit("Modification des paramètres de personnalisation (Administration)")
    return jsonify({'ok': True})


@app.route('/api/admin-settings/logo', methods=['POST'])
def api_upload_admin_logo():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if 'file' not in request.files or not request.files['file'].filename:
        return jsonify({'error': 'Aucun fichier reçu.'}), 400
    f = request.files['file']
    ext = Path(f.filename).suffix.lower()
    if ext not in ADMIN_SETTINGS_LOGO_EXTS:
        return jsonify({'error': 'Format d\'image non supporté (PNG, JPG, GIF, BMP ou WEBP).'}), 400
    raw = f.read()
    if not raw:
        return jsonify({'error': 'Fichier vide.'}), 400
    if len(raw) > ADMIN_SETTINGS_LOGO_MAX_BYTES:
        return jsonify({'error': 'Image trop volumineuse (max 5 Mo).'}), 400

    # On conserve une copie du logo d'origine avant la toute première
    # personnalisation, pour permettre un retour en arrière plus tard.
    if not meta_get('logo_customized') and LOGO_PATH.exists() and not LOGO_DEFAULT_BACKUP_PATH.exists():
        try:
            shutil.copyfile(str(LOGO_PATH), str(LOGO_DEFAULT_BACKUP_PATH))
        except Exception:
            pass

    LOGO_PATH.write_bytes(raw)
    meta_set('logo_customized', '1')
    log_audit("Changement du logo utilisé dans les PDF (Administration)", f.filename)
    return jsonify({'ok': True})


def _login_bg_custom_file():
    name = meta_get('login_bg_custom') or ''
    path = LOGO_PATH.parent / name if name.startswith(LOGIN_BG_CUSTOM_PREFIX) else None
    return path if path is not None and path.exists() else None


def _login_video_file():
    name = meta_get('login_video_custom') or ''
    path = LOGO_PATH.parent / name if name.startswith(LOGIN_VIDEO_PREFIX) else None
    return path if path is not None and path.exists() else None


def login_video_url():
    p = _login_video_file()
    if not p:
        return None
    return url_for('static', filename=p.name, v=int(p.stat().st_mtime))


def login_bg_mode():
    """Fond choisi pour la page de connexion, avec repli sur l'animation si le fichier manque."""
    m = meta_get('login_bg_mode') or 'mosaique'
    if m == 'video' and not _login_video_file():
        return 'mosaique'
    if m == 'image' and not _login_bg_custom_file():
        return 'mosaique'
    return m if m in LOGIN_BG_MODES else 'mosaique'


def login_bg_url():
    """Adresse de l'image de fond de la page de connexion (photo personnalisée
    si elle existe, sinon l'image par défaut). Le paramètre v force le
    navigateur à recharger l'image quand elle change."""
    path = _login_bg_custom_file() or (LOGO_PATH.parent / LOGIN_BG_DEFAULT_NAME)
    try:
        v = int(path.stat().st_mtime)
    except OSError:
        v = 0
    return url_for('static', filename=path.name, v=v)


@app.route('/api/admin-settings/login-bg', methods=['POST'])
def api_upload_login_bg():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if 'file' not in request.files or not request.files['file'].filename:
        return jsonify({'error': 'Aucun fichier reçu.'}), 400
    f = request.files['file']
    ext = Path(f.filename).suffix.lower()
    if ext not in LOGIN_BG_EXTS:
        return jsonify({'error': "Format d'image non supporté (JPG, PNG ou WEBP)."}), 400
    raw = f.read()
    if not raw:
        return jsonify({'error': 'Fichier vide.'}), 400
    if len(raw) > LOGIN_BG_MAX_BYTES:
        return jsonify({'error': 'Image trop volumineuse (max 8 Mo).'}), 400
    for old in LOGO_PATH.parent.glob(LOGIN_BG_CUSTOM_PREFIX + '.*'):
        try:
            old.unlink()
        except OSError:
            pass
    name = LOGIN_BG_CUSTOM_PREFIX + ('.jpg' if ext == '.jpeg' else ext)
    (LOGO_PATH.parent / name).write_bytes(raw)
    meta_set('login_bg_custom', name); meta_set('login_bg_mode', 'image')
    log_audit("Changement de l'image de fond de la page de connexion (Administration)", f.filename)
    return jsonify({'ok': True, 'url': login_bg_url()})


@app.route('/api/admin-settings/login-video', methods=['POST', 'DELETE'])
def api_login_video():
    resp = admin_required_check()
    if resp is not None:
        return resp
    def clear():
        for old in LOGO_PATH.parent.glob(LOGIN_VIDEO_PREFIX + '.*'):
            try:
                old.unlink()
            except OSError:
                pass
    if request.method == 'DELETE':
        clear(); meta_set('login_video_custom', '')
        if meta_get('login_bg_mode') == 'video':
            meta_set('login_bg_mode', 'mosaique')
        log_audit("Vidéo de fond de la page de connexion retirée (Administration)")
        return jsonify({'ok': True})
    f = request.files.get('file')
    if not f or not f.filename:
        return jsonify({'error': 'Aucun fichier reçu.'}), 400
    ext = Path(f.filename).suffix.lower()
    if ext not in LOGIN_VIDEO_EXTS:
        return jsonify({'error': 'Format vidéo non supporté (MP4 ou WebM).'}), 400
    raw = f.read()
    if not raw:
        return jsonify({'error': 'Fichier vide.'}), 400
    if len(raw) > LOGIN_VIDEO_MAX_BYTES:
        return jsonify({'error': 'Vidéo trop volumineuse (80 Mo au maximum). Une vidéo de 15 à 30 secondes suffit.'}), 400
    clear()
    name = LOGIN_VIDEO_PREFIX + ext
    (LOGO_PATH.parent / name).write_bytes(raw)
    meta_set('login_video_custom', name); meta_set('login_bg_mode', 'video')
    log_audit("Vidéo de fond de la page de connexion (Administration)", f.filename)
    return jsonify({'ok': True, 'url': login_video_url(), 'mode': 'video'})


@app.route('/api/admin-settings/login-bg-mode', methods=['POST'])
def api_login_bg_mode():
    resp = admin_required_check()
    if resp is not None:
        return resp
    m = (request.get_json(silent=True) or {}).get('mode')
    if m not in LOGIN_BG_MODES:
        return jsonify({'error': 'Choix invalide.'}), 400
    if m == 'video' and not _login_video_file():
        return jsonify({'error': "Téléverse d'abord une vidéo."}), 400
    if m == 'image' and not _login_bg_custom_file():
        return jsonify({'error': "Téléverse d'abord une image."}), 400
    meta_set('login_bg_mode', m)
    log_audit('Fond de la page de connexion', {'mosaique': 'Animation Kubios', 'image': 'Image personnalisée', 'video': 'Vidéo personnalisée'}[m])
    return jsonify({'ok': True, 'mode': m})


@app.route('/api/admin-settings/login-bg/reset', methods=['POST'])
def api_reset_login_bg():
    resp = admin_required_check()
    if resp is not None:
        return resp
    for old in LOGO_PATH.parent.glob(LOGIN_BG_CUSTOM_PREFIX + '.*'):
        try:
            old.unlink()
        except OSError:
            pass
    meta_set('login_bg_custom', '')
    log_audit("Retour à l'image de fond par défaut de la page de connexion (Administration)")
    return jsonify({'ok': True, 'url': login_bg_url()})


@app.route('/api/admin-settings/logo/reset', methods=['POST'])
def api_reset_admin_logo():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if LOGO_DEFAULT_BACKUP_PATH.exists():
        shutil.copyfile(str(LOGO_DEFAULT_BACKUP_PATH), str(LOGO_PATH))
    meta_set('logo_customized', '')
    log_audit("Réinitialisation du logo par défaut (Administration)")
    return jsonify({'ok': True})


# ============================================================
# Routes — mises à jour (version et changelog)
# ============================================================
@app.route('/admin/updates')
def updates_page():
    resp = permission_required_check('updates')
    if resp is not None:
        return resp
    return render_template('updates.html', company=get_company_name(), username=session.get('username'),
                            version=APP_VERSION, changelog=CHANGELOG,
                            is_admin=session.get('is_admin', False), permissions=session.get('permissions') or [])


@app.route('/api/updates')
def api_updates():
    resp = permission_required_check('updates')
    if resp is not None:
        return resp
    return jsonify({'version': APP_VERSION, 'changelog': CHANGELOG})


@app.route('/api/updates/check')
def api_updates_check():
    resp = permission_required_check('updates')
    if resp is not None:
        return resp
    try:
        req = urllib.request.Request(UPDATE_CHECK_URL, headers={'Cache-Control': 'no-cache'})
        with urllib.request.urlopen(req, timeout=6) as r:
            raw_body = r.read().decode('utf-8-sig').strip()
            remote = json.loads(raw_body)
    except urllib.error.URLError:
        return jsonify({'ok': False, 'error':
                         "Impossible de joindre le serveur de mises à jour. "
                         "Vérifie ta connexion Internet et réessaie."})
    except Exception as e:
        return jsonify({'ok': False, 'error':
                         "Réponse invalide du serveur de mises à jour (%s)." % e})

    remote_version = remote.get('version', '')
    remote_changelog = remote.get('changelog', [])
    try:
        up_to_date = _version_tuple(APP_VERSION) >= _version_tuple(remote_version)
    except Exception:
        return jsonify({'ok': False, 'error': "Numéro de version distant illisible."})

    # Les changements plus récents que la version installée (pour affichage).
    new_entries = [e for e in remote_changelog
                   if _version_tuple(e.get('version', '0.0.0')) > _version_tuple(APP_VERSION)]

    return jsonify({
        'ok': True,
        'installed_version': APP_VERSION,
        'latest_version': remote_version,
        'up_to_date': up_to_date,
        'new_entries': new_entries,
        'can_auto_install': bool(remote.get('download_url')),
    })


@app.route('/api/updates/install', methods=['POST'])
def api_updates_install():
    resp = permission_required_check('updates')
    if resp is not None:
        return resp

    body = request.get_json(silent=True) or {}
    restart_mode = body.get('restart_mode')
    if restart_mode not in ('service', 'startbat'):
        return jsonify({'ok': False, 'error':
                         "Précise comment cet ordinateur redémarre l'application "
                         "(service Windows ou start.bat) avant de continuer."}), 400

    try:
        req = urllib.request.Request(UPDATE_CHECK_URL, headers={'Cache-Control': 'no-cache'})
        with urllib.request.urlopen(req, timeout=6) as r:
            remote = json.loads(r.read().decode('utf-8-sig').strip())
    except Exception as e:
        return jsonify({'ok': False, 'error': "Impossible de joindre le serveur de mises à jour (%s)." % e}), 400

    download_url = remote.get('download_url')
    if not download_url:
        return jsonify({'ok': False, 'error':
                         "Aucun paquet de mise à jour téléchargeable pour l'instant. "
                         "Utilise « Vérifier les mises à jour » pour voir ce qui a changé."}), 400

    try:
        # Télécharge et extrait le paquet de code dans un dossier temporaire,
        # HORS du dossier de l'app (C:\DBouxpCR\app) — jamais dans le dossier
        # en cours d'utilisation par ce processus.
        if UPDATE_STAGING_DIR.exists():
            shutil.rmtree(UPDATE_STAGING_DIR, ignore_errors=True)
        UPDATE_STAGING_DIR.mkdir(parents=True, exist_ok=True)

        dl_req = urllib.request.Request(download_url, headers={'Cache-Control': 'no-cache'})
        with urllib.request.urlopen(dl_req, timeout=30) as r:
            zip_bytes = r.read()
        UPDATE_ZIP_PATH.write_bytes(zip_bytes)

        with zipfile.ZipFile(UPDATE_ZIP_PATH) as zf:
            zf.extractall(UPDATE_STAGING_DIR)

        staged_app_dir = UPDATE_STAGING_DIR / "app"
        if not (staged_app_dir / "app.py").exists():
            return jsonify({'ok': False, 'error':
                             "Le paquet téléchargé est invalide (app.py introuvable dedans)."}), 400
    except Exception as e:
        return jsonify({'ok': False, 'error': f"Échec du téléchargement du paquet : {e}"}), 400

    err = _launch_update(staged_app_dir, restart_mode)
    if err:
        return jsonify({'ok': False, 'error': err}), 400
    db_add_audit(session.get('username'), 'Mise à jour installée', f"vers v{remote.get('version')}")
    return jsonify({'ok': True, 'message':
                     "Téléchargement terminé. L'application redémarre maintenant — "
                     "recharge cette page dans environ 30 secondes."})


def _launch_update(staged_app_dir, restart_mode):
    """Lance le script qui copie le paquet préparé par-dessus app\\ puis redémarre Kubios.
    Retourne un message d'erreur, ou None si l'installation est lancée."""
    try:
        runner_src = _UPDATE_RUNNER_SCRIPT.format(
            staged=str(staged_app_dir), target=str(APP_DIR), base=str(BASE_DIR),
            restart_mode=restart_mode)
        UPDATE_RUNNER_PATH.write_text(runner_src, encoding='utf-8')
        popen_kwargs = {'cwd': str(BASE_DIR), 'close_fds': True}
        if sys.platform == 'win32':
            popen_kwargs['creationflags'] = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
        subprocess.Popen([_real_python_exe(), str(UPDATE_RUNNER_PATH)], **popen_kwargs)
    except Exception as e:
        return f"Impossible de démarrer l'installation : {e}"

    # Laisse le temps à la réponse HTTP de partir avant de fermer ce processus — le script
    # lancé ci-dessus attend, de son côté, que ce processus soit bien terminé avant de copier.
    def _delayed_exit():
        time.sleep(1.5)
        os._exit(0)
    threading.Thread(target=_delayed_exit, daemon=True).start()
    return None


# ---------- 1.36.0 : installer un paquet téléversé (mise à jour locale, sans GitHub) ----------
UPDATE_UPLOAD_MAX = 150 * 1024 * 1024


def _version_tuple(v):
    try:
        return tuple(int(x) for x in str(v).strip().lstrip('vV').split('.'))
    except ValueError:
        return (0,)


def _read_package_info(app_py):
    """Lit APP_VERSION et CHANGELOG dans le app.py d'un paquet, sans l'exécuter."""
    import ast
    tree = ast.parse(app_py.read_text(encoding='utf-8-sig'))
    info = {'version': None, 'changelog': []}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            if name == 'APP_VERSION':
                info['version'] = ast.literal_eval(node.value)
            elif name == 'CHANGELOG' and isinstance(node.value, ast.List):
                class _Plain(ast.NodeTransformer):     # texte avec valeur insérée : on garde la partie fixe
                    def visit_JoinedStr(self, n):
                        return ast.copy_location(ast.Constant(''.join(v.value for v in n.values if isinstance(v, ast.Constant) and isinstance(v.value, str))), n)
                for el in node.value.elts:            # entrée par entrée : une entrée illisible ne bloque pas les autres
                    try:
                        info['changelog'].append(ast.literal_eval(ast.fix_missing_locations(_Plain().visit(el))))
                    except (ValueError, TypeError, SyntaxError):
                        pass
    return info


@app.route('/api/updates/upload', methods=['POST'])
def api_updates_upload():
    """Étape 1 : reçoit le zip, le vérifie et le prépare ; retourne sa version et ses changements."""
    resp = permission_required_check('updates')
    if resp is not None:
        return resp
    f = request.files.get('file')
    if not f or not f.filename:
        return jsonify({'ok': False, 'error': 'Choisis le fichier du paquet (kubios-x.y.z.zip).'}), 400
    if not f.filename.lower().endswith('.zip'):
        return jsonify({'ok': False, 'error': 'Le paquet doit être un fichier .zip.'}), 400
    data = f.read()
    if not data or len(data) > UPDATE_UPLOAD_MAX:
        return jsonify({'ok': False, 'error': 'Fichier vide ou trop volumineux (150 Mo au maximum).'}), 400
    try:
        if UPDATE_STAGING_DIR.exists():
            shutil.rmtree(UPDATE_STAGING_DIR, ignore_errors=True)
        UPDATE_STAGING_DIR.mkdir(parents=True, exist_ok=True)
        UPDATE_ZIP_PATH.write_bytes(data)
        with zipfile.ZipFile(UPDATE_ZIP_PATH) as zf:
            bad = zf.testzip()
            if bad:
                return jsonify({'ok': False, 'error': f"Le fichier zip est endommagé ({bad})."}), 400
            names = zf.namelist()
            zf.extractall(UPDATE_STAGING_DIR)          # extractall neutralise les chemins « .. » et absolus
    except zipfile.BadZipFile:
        return jsonify({'ok': False, 'error': "Ce fichier n'est pas un zip valide."}), 400
    except Exception as e:
        return jsonify({'ok': False, 'error': f"Impossible d'ouvrir le paquet : {e}"}), 400
    staged = UPDATE_STAGING_DIR / 'app'
    if not (staged / 'app.py').exists():
        shutil.rmtree(UPDATE_STAGING_DIR, ignore_errors=True)
        return jsonify({'ok': False, 'error': "Ce n'est pas un paquet Kubios : le dossier « app » avec app.py est introuvable dans le zip."}), 400
    try:
        info = _read_package_info(staged / 'app.py')
    except Exception as e:
        shutil.rmtree(UPDATE_STAGING_DIR, ignore_errors=True)
        return jsonify({'ok': False, 'error': f"Le app.py du paquet est illisible ({e})."}), 400
    if not info['version']:
        shutil.rmtree(UPDATE_STAGING_DIR, ignore_errors=True)
        return jsonify({'ok': False, 'error': "Version introuvable dans le paquet (APP_VERSION)."}), 400
    cur, new = _version_tuple(APP_VERSION), _version_tuple(info['version'])
    cmp_ = 'newer' if new > cur else ('same' if new == cur else 'older')
    entries = [e for e in info['changelog'] if isinstance(e, dict) and _version_tuple(e.get('version')) > cur] if cmp_ == 'newer' else info['changelog'][:1]
    token = hashlib.sha256(data).hexdigest()
    session['update_upload_token'] = token
    db_add_audit(session.get('username'), 'Mise à jour : paquet téléversé', f"{f.filename} — v{info['version']}")
    return jsonify({'ok': True, 'version': info['version'], 'current': APP_VERSION, 'compare': cmp_, 'token': token,
                    'filename': f.filename, 'size': len(data), 'files': len([n for n in names if not n.endswith('/')]),
                    'entries': [{'version': e.get('version'), 'date': e.get('date'), 'changes': e.get('changes', [])} for e in entries][:20]})


@app.route('/api/updates/upload/install', methods=['POST'])
def api_updates_upload_install():
    """Étape 2 : installe le paquet préparé à l'étape 1."""
    resp = permission_required_check('updates')
    if resp is not None:
        return resp
    body = request.get_json(silent=True) or {}
    restart_mode = body.get('restart_mode')
    if restart_mode not in ('service', 'startbat'):
        return jsonify({'ok': False, 'error': "Précise comment cet ordinateur redémarre l'application (service Windows ou start.bat)."}), 400
    token = body.get('token') or ''
    if not token or token != session.get('update_upload_token') or not UPDATE_ZIP_PATH.exists() \
            or hashlib.sha256(UPDATE_ZIP_PATH.read_bytes()).hexdigest() != token:
        return jsonify({'ok': False, 'error': 'Le paquet vérifié n\u2019est plus disponible : téléverse-le de nouveau.'}), 400
    staged = UPDATE_STAGING_DIR / 'app'
    if not (staged / 'app.py').exists():
        return jsonify({'ok': False, 'error': 'Le paquet vérifié n\u2019est plus disponible : téléverse-le de nouveau.'}), 400
    info = _read_package_info(staged / 'app.py')
    if _version_tuple(info['version']) < _version_tuple(APP_VERSION) and not body.get('allow_older'):
        return jsonify({'ok': False, 'error': f"Ce paquet (v{info['version']}) est plus ancien que la version installée (v{APP_VERSION}). Coche la confirmation pour revenir en arrière."}), 400
    err = _launch_update(staged, restart_mode)
    if err:
        return jsonify({'ok': False, 'error': err}), 400
    session.pop('update_upload_token', None)
    db_add_audit(session.get('username'), 'Mise à jour installée (paquet téléversé)', f"v{APP_VERSION} → v{info['version']}")
    return jsonify({'ok': True, 'message': f"Installation de la v{info['version']} lancée. L'application redémarre maintenant — recharge cette page dans environ 30 secondes."})


@app.route('/api/settings/email', methods=['GET'])
def api_get_email_settings():
    resp = permission_required_check('email_settings')
    if resp is not None:
        return resp
    settings = get_settings()
    settings['smtp_password_set'] = bool(settings.get('smtp_password'))
    settings.pop('smtp_password', None)
    settings['m365_secret_set'] = bool(settings.get('m365_secret'))
    settings.pop('m365_secret', None)
    return jsonify(settings)


@app.route('/api/settings/email', methods=['PUT'])
def api_set_email_settings():
    resp = permission_required_check('email_settings')
    if resp is not None:
        return resp
    data = request.json or {}
    send_mode = data.get('send_mode', 'outlook')
    if send_mode == 'smtp':
        host = (data.get('smtp_host') or '').strip()
        from_email = (data.get('smtp_from_email') or '').strip()
        if not host or not from_email:
            return jsonify({'ok': False, 'error':
                             "Pour activer le mode SMTP, il faut au minimum l'adresse du "
                             "serveur et l'adresse courriel d'expédition."}), 400
    if send_mode == 'm365':
        need = [k for k, lbl in (('m365_tenant', 'ID du locataire'), ('m365_client_id', "ID de l'application"), ('m365_mailbox_general', 'boîte de Kubios'))
                if not (data.get(k) or '').strip()]
        if not (data.get('m365_secret') or meta_get('m365_secret')):
            need.append('m365_secret')
        if need:
            return jsonify({'ok': False, 'error': "Pour Microsoft 365, il faut l'ID du locataire, l'ID de l'application, le secret client "
                                                  "et au moins la boîte de Kubios."}), 400
        for k in ('m365_mailbox_ar', 'm365_mailbox_general', 'm365_ar_reply_to'):
            v = (data.get(k) or '').strip()
            if v and not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+', v):
                return jsonify({'ok': False, 'error': f"Adresse de boîte invalide : {v}"}), 400
        _M365_TOKEN.update(key=None, tok=None, exp=0)
    set_settings(data)
    log_audit('Modification paramètres d\'envoi', f"mode={send_mode}")
    return jsonify({'ok': True})


@app.route('/api/settings/email/test', methods=['POST'])
def api_test_email_settings():
    resp = permission_required_check('email_settings')
    if resp is not None:
        return resp
    data = request.json or {}
    # Si le mot de passe n'est pas fourni (champ laissé vide dans le formulaire),
    # on utilise celui déjà enregistré pour permettre de tester sans le retaper.
    settings = dict(data)
    if not settings.get('smtp_password'):
        settings['smtp_password'] = meta_get('smtp_password', '')
    if data.get('send_mode') == 'm365':
        if not settings.get('m365_secret'):
            settings['m365_secret'] = meta_get('m365_secret', '')
        to = (data.get('test_to') or '').strip() or get_company_email() or ''
        if not to:
            return jsonify({'ok': False, 'error': "Indique l'adresse qui recevra le courriel de test."}), 400
        purpose = 'ar' if data.get('test_box') == 'ar' else 'general'
        try:
            mb = m365_mailbox(settings, purpose)
            send_via_m365(to, f"{get_company_name()} — test d'envoi Microsoft 365",
                          f"Bonjour,\n\nCe courriel de test a été envoyé par Kubios depuis la boîte {mb} avec Microsoft 365.\n\n{get_company_name()}",
                          None, settings, mode='send', bcc_company=False, purpose=purpose)
            log_audit('Paramètres d\'envoi : test Microsoft 365 réussi', f"{mb} → {to}")
            return jsonify({'ok': True, 'message': f"Courriel de test envoyé depuis {mb} à {to}."})
        except Exception as e:
            return jsonify({'ok': False, 'error': str(e)}), 400
    try:
        test_smtp_connection(settings)
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/admin/sessions')
def sessions_page():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return render_template('sessions.html', company=get_company_name(), my_sid=session.get('sid'))


def sess_list(conn):
    lim = (datetime.datetime.now() - datetime.timedelta(days=30)).strftime(AT_FMT)
    rows = [dict(r) for r in conn.execute("SELECT * FROM user_sessions WHERE revoked_at IS NULL AND last_seen > ? ORDER BY last_seen DESC", (lim,)).fetchall()]
    now = datetime.datetime.now()
    for r in rows:
        r['idle'] = int((now - datetime.datetime.strptime(r['last_seen'], AT_FMT)).total_seconds())
        r['online'] = r['idle'] <= SESS_ONLINE_SEC
    return rows


@app.route('/api/sessions')
def api_sessions():
    resp = admin_required_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        rows = sess_list(conn)
    finally:
        conn.close()
    return jsonify({'sessions': rows, 'me': session.get('sid')})


@app.route('/api/sessions/revoke', methods=['POST'])
def api_sessions_revoke():
    resp = admin_required_check()
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    conn = get_conn()
    try:
        if d.get('sid'):
            sids = [d['sid']]
        elif d.get('user_id') and d.get('kind') in ('user', 'portail'):
            sids = [r[0] for r in conn.execute("SELECT sid FROM user_sessions WHERE kind=? AND user_id=? AND revoked_at IS NULL", (d['kind'], int(d['user_id']))).fetchall()]
        else:
            return jsonify({'ok': False, 'error': 'Session introuvable.'}), 400
        sids = [x for x in sids if x != session.get('sid')]
        if not sids:
            return jsonify({'ok': False, 'error': "Tu ne peux pas fermer ta propre session d'ici : utilise « Se déconnecter »."}), 400
        who = [r for r in conn.execute(f"SELECT display, kind FROM user_sessions WHERE sid IN ({','.join('?' * len(sids))})", sids).fetchall()]
        conn.execute(f"UPDATE user_sessions SET revoked_at=?, revoked_by=? WHERE sid IN ({','.join('?' * len(sids))}) AND revoked_at IS NULL",
                     [_at_now(), current_display_name()] + sids)
        conn.commit()
    finally:
        conn.close()
    _SESS_REVOKED.update(sids)
    log_audit('Session fermée à distance', ', '.join(f"{w['display']} ({'portail' if w['kind'] == 'portail' else 'Kubios'})" for w in who))
    return jsonify({'ok': True, 'closed': len(sids)})


@app.route('/api/users', methods=['GET'])
def api_list_users():
    resp = admin_required_check()
    if resp is not None:
        return resp
    users = db_list_users()
    conn = get_conn()
    try:                                     # 1.37.0 : dernière connexion (journal d'audit)
        last = {r['username']: r['ts'] for r in conn.execute(
            "SELECT username, MAX(ts) ts FROM audit_log WHERE action='Connexion' GROUP BY username").fetchall()}
    finally:
        conn.close()
    conn = get_conn()
    try:
        online = {r['user_id'] for r in sess_list(conn) if r['kind'] == 'user' and r['online']}
    finally:
        conn.close()
    for u in users:
        u['last_login'] = last.get(u['username'])
        u['online'] = u['id'] in online
    if request.args.get('meta') == '1':
        lic = get_license_status()
        return jsonify({'users': users, 'max_users': licensing.max_users_of(lic.get('payload')), 'active_users': db_count_active_users()})
    return jsonify(users)


@app.route('/api/users', methods=['POST'])
def api_create_user():
    resp = admin_required_check()
    if resp is not None:
        return resp
    data = request.json or {}
    email = (data.get('email') or '').strip() or None
    if email and not _EMAIL_OK.match(email):
        return jsonify({'ok': False, 'error': f"Adresse courriel invalide : {email}"}), 400
    limit_error = license_user_limit_error()
    if limit_error:
        return jsonify({'ok': False, 'error': limit_error}), 400
    try:
        db_create_user(data.get('username', ''), data.get('password', ''), bool(data.get('is_admin')),
                        permissions=data.get('permissions'))
        created = db_get_user_by_username(data.get('username', ''))
        full_name = (data.get('full_name') or '').strip()[:80] or None
        if created and (email or data.get('mfa_required') or full_name):
            db_set_user_mfa(created['id'], email=email, mfa_required=1 if data.get('mfa_required') else 0,
                            full_name=full_name)
        log_audit('Création utilisateur', data.get('username', '')
                  + (f" — courriel {email}" if email else "") + (" — 2FA obligatoire" if data.get('mfa_required') else ""))
        return jsonify({'ok': True})
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/users/<int:user_id>', methods=['PUT'])
def api_update_user(user_id):
    resp = admin_required_check()
    if resp is not None:
        return resp
    data = request.json or {}
    if user_id == session.get('user_id') and data.get('active') is False:
        return jsonify({'ok': False, 'error': "Tu ne peux pas désactiver ton propre compte."}), 400
    if data.get('active') is True:
        current = db_get_user(user_id)
        if current and not current['active']:
            limit_error = license_user_limit_error()
            if limit_error:
                return jsonify({'ok': False, 'error': limit_error}), 400
    try:
        db_update_user(
            user_id,
            is_admin=data.get('is_admin'),
            active=data.get('active'),
            new_password=data.get('password') or None,
            permissions=data.get('permissions'),
        )
        target = db_get_user(user_id)
        target_name = target['username'] if target else str(user_id)
        changes = []
        if data.get('is_admin') is not None:
            changes.append('admin' if data.get('is_admin') else 'retrait admin')
        if data.get('active') is not None:
            changes.append('réactivé' if data.get('active') else 'désactivé')
        if data.get('password'):
            changes.append('mot de passe réinitialisé')
        if data.get('permissions') is not None:
            changes.append(f"accès : {', '.join(data.get('permissions')) or 'aucun'}")
        log_audit('Modification utilisateur', f"{target_name} ({', '.join(changes) or 'aucun changement'})")
        return jsonify({'ok': True})
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/users/<int:user_id>', methods=['DELETE'])
def api_delete_user(user_id):
    resp = admin_required_check()
    if resp is not None:
        return resp
    if user_id == session.get('user_id'):
        return jsonify({'ok': False, 'error': "Tu ne peux pas supprimer ton propre compte."}), 400
    target = db_get_user(user_id)
    db_delete_user(user_id)
    log_audit('Suppression utilisateur', target['username'] if target else str(user_id))
    return jsonify({'ok': True})


@app.route('/api/me')
def api_me():
    u = current_user()
    if not u:
        return jsonify({'error': 'auth_required'}), 401
    return jsonify({'username': u['username'], 'is_admin': bool(u['is_admin'])})


# ============================================================
# Routes
# ============================================================
@app.route('/')
def index():
    """Page d'accueil (menu) affichée juste après la connexion — donne accès
    aux différents volets du logiciel selon les permissions de la personne
    connectée, plutôt que d'atterrir directement sur les comptes à recevoir."""
    is_admin = bool(session.get('is_admin', False))
    perms = session.get('permissions') or []
    now = datetime.datetime.now()
    moment = request.args.get('moment') if request.args.get('moment') in HOME_MOMENTS else home_moment(now)
    name = current_display_name()
    greet, sub = HOME_MOMENTS[moment]
    date_txt = f"{_JOURS_FR[now.weekday()]} {now.day}{'er' if now.day == 1 else ''} {_MOIS_FR[now.month - 1]} {now.year}"
    return render_template('home.html', company=get_company_name(), app_name=APP_NAME,
                           username=session.get('username'), display_name=name,
                           first_name=(name.split()[0] if name else ''), greeting=greet, subline=sub, date_txt=date_txt,
                           t=HOME_BANNER_THEMES[moment], is_admin=is_admin, permissions=perms,
                           dash=home_dashboard(is_admin, perms), year=now.year, version=APP_VERSION)


# Bandeau d'accueil « Bord de mer » (1.18.0) : couleurs selon le moment de la journée
HOME_BANNER_THEMES = {
 "matin": {
  "sky": "linear-gradient(180deg,#fde4c8 0%,#fbd0a8 45%,#cfe3ff 100%)",
  "astro": "#f59e0b",
  "astroX": 720,
  "astroY": 150,
  "starsOn": 0,
  "beamOn": 0,
  "gullsOn": 0.8,
  "boatOn": 1,
  "gull": "#334155",
  "sea": "#7fa6cf",
  "hull": "#1e3a8a",
  "rock": "#6b5b4d",
  "lamp": "#fde68a",
  "heroText": "#0b1324",
  "scrim": "linear-gradient(90deg,rgba(255,250,244,.82) 0%,rgba(255,250,244,.55) 38%,rgba(255,250,244,0) 62%)",
  "shadow": "0 1px 2px rgba(255,255,255,.7)"
 },
 "apres-midi": {
  "sky": "linear-gradient(180deg,#8ec5ff 0%,#bfdcff 60%,#e3f1ff 100%)",
  "astro": "#fde047",
  "astroX": 860,
  "astroY": 44,
  "starsOn": 0,
  "beamOn": 0,
  "gullsOn": 0.9,
  "boatOn": 1,
  "gull": "#1e293b",
  "sea": "#2f78c4",
  "hull": "#b91c1c",
  "rock": "#5c4d40",
  "lamp": "#e2e8f0",
  "heroText": "#0b1324",
  "scrim": "linear-gradient(90deg,rgba(244,249,255,.82) 0%,rgba(244,249,255,.55) 38%,rgba(244,249,255,0) 62%)",
  "shadow": "0 1px 2px rgba(255,255,255,.7)"
 },
 "soir": {
  "sky": "linear-gradient(180deg,#0b1226 0%,#1b1a49 60%,#2b2f6e 100%)",
  "astro": "#e2e8f0",
  "astroX": 760,
  "astroY": 56,
  "starsOn": 1,
  "beamOn": 1,
  "gullsOn": 0,
  "boatOn": 0,
  "gull": "#ffffff",
  "sea": "#142045",
  "hull": "#1e293b",
  "rock": "#1c1f33",
  "lamp": "#fde047",
  "heroText": "#ffffff",
  "scrim": "linear-gradient(90deg,rgba(8,13,32,.78) 0%,rgba(8,13,32,.5) 38%,rgba(8,13,32,0) 62%)",
  "shadow": "0 1px 3px rgba(0,0,0,.65)"
 }
}
HOME_MOMENTS = {
    'matin': ('Bon matin', "Voici ce qui demande ton attention aujourd'hui."),
    'apres-midi': ('Bon après-midi', "Un coup d'œil rapide sur la journée en cours."),
    'soir': ('Bonsoir', 'Les rapports de la journée seront prêts cette nuit.'),
}
_JOURS_FR = ('lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche')


def home_moment(now=None):
    h = (now or datetime.datetime.now()).hour
    return 'matin' if 5 <= h < 12 else ('apres-midi' if 12 <= h < 18 else 'soir')


def home_dashboard(is_admin, perms):
    """Indicateurs de l'accueil (1.18.0) : seulement ce que la personne a le droit de voir."""
    today = datetime.date.today()
    # chaque indicateur existe toujours (None = non affiché pour cet utilisateur)
    d = {'overdue': None, 'week': None, 'yesterday': None, 'backup': None, 'license': None, 'ar': ar_allowed()}
    conn = get_conn()
    try:
        r = None if not d['ar'] else conn.execute("SELECT COUNT(*) n, COALESCE(SUM(COALESCE(montant,0)-COALESCE(montant_paye,0)),0) s FROM invoices "
                         "WHERE echeance IS NOT NULL AND echeance <> '' AND echeance < ? "
                         "AND COALESCE(montant,0)-COALESCE(montant_paye,0) > 0.005", (today.isoformat(),)).fetchone()
        d['overdue'] = {'count': r['n'], 'amount': round(r['s'] or 0, 2)} if r else None
        if is_admin or 'custom_reports' in perms:
            days = [today - datetime.timedelta(days=i) for i in range(7, 0, -1)]
            vals = {row['sale_date']: row['t'] for row in conn.execute(
                "SELECT sale_date, SUM(total) t FROM sales_lines WHERE sale_date BETWEEN ? AND ? GROUP BY sale_date",
                (days[0].isoformat(), days[-1].isoformat())).fetchall()}
            have = conn.execute("SELECT COUNT(*) n FROM sales_days WHERE complete=1 AND day BETWEEN ? AND ?",
                                (days[0].isoformat(), days[-1].isoformat())).fetchone()['n']
            noms = ('Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim')
            week = [{'label': noms[x.weekday()], 'date': x.isoformat(), 'total': round(vals.get(x.isoformat(), 0) or 0, 2)} for x in days]
            top = max([w['total'] for w in week] + [0])
            for w in week:
                w['pct'] = 0 if top <= 0 else max(3, round(w['total'] / top * 100))
            d['week'] = {'days': week, 'total': round(sum(w['total'] for w in week), 2), 'has_data': have > 0}
            d['yesterday'] = week[-1]['total'] if have else None
    finally:
        conn.close()
    if is_admin:
        last, err = meta_get('fb_last'), meta_get('fb_last_error')
        d['backup'] = {'last': last, 'error': err,
                       'ok': bool(last) and (not err or err[:16] < last[:16])}
    if is_admin or 'license' in perms:
        try:
            st = get_license_status()
            d['license'] = {'active': bool(st.get('active')), 'days_left': st.get('days_left'),
                            'expires': (st.get('payload') or {}).get('expires')}
        except Exception:
            d['license'] = None
    return d


@app.route('/comptes-a-recevoir')
def car_page():
    return render_template('index.html', company=get_company_name(), company_email=get_company_email(),
                            username=session.get('username'), is_admin=session.get('is_admin', False),
                            permissions=session.get('permissions') or [])


@app.route('/api/clients')
def api_clients():
    clients = db_list_clients()
    return jsonify(clients)


@app.route('/api/client/<path:name>')
def api_client_detail(name):
    data = db_client_detail(name)
    if data is None:
        return jsonify({'error': 'Client introuvable'}), 404
    data['invoices'] = [i for i in data['invoices'] if i['montant'] != 0 or i['numero']]
    return jsonify(data)


@app.route('/api/client', methods=['POST'])
def api_create_client():
    data = request.json
    try:
        sheet_name = db_create_client(
            data['name'], data.get('phone', ''), data.get('adresse', ''),
            data.get('ville', ''), data.get('province', 'Qc'),
            data.get('code_postal', ''), data.get('courriel', ''),
        )
        log_audit('Création client', data['name'])
        return jsonify({'ok': True, 'sheet': sheet_name})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/client/<path:name>', methods=['PUT'])
def api_update_client(name):
    data = request.json or {}
    try:
        new_name, changes = db_update_client(
            name, data.get('name', ''), data.get('phone', ''), data.get('adresse', ''),
            data.get('ville', ''), data.get('province', 'Qc'),
            data.get('code_postal', ''), data.get('courriel', ''),
        )
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    if changes:
        details = "; ".join(f"{CLIENT_FIELD_LABELS.get(k, k)} : « {a} » → « {b} »" for k, a, b in changes)
        log_audit('Modification client', f"{name} — {details}")
    return jsonify({'ok': True, 'name': new_name, 'changed': len(changes)})


@app.route('/api/client/<path:name>/merge', methods=['POST'])
def api_merge_client(name):
    """Fusionne le client `name` dans le client `into` (celui qui est gardé)."""
    data = request.get_json(silent=True) or {}
    into = (data.get('into') or '').strip()
    try:
        res = db_merge_clients(name, into, session.get('username'))
    except RuntimeError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': f"Fusion impossible : {e}. Aucune donnée n'a été modifiée."}), 500
    log_audit('Fusion de clients', f"« {name} » fusionné dans « {into} » — {res['invoices']} facture(s) déplacée(s)"
              + (f" ; coordonnées complétées : {', '.join(CLIENT_FIELD_LABELS.get(f, f) for f in res['filled'])}"
                 if res['filled'] else ""))
    return jsonify(dict(res, ok=True, name=into))


@app.route('/api/client/<path:name>/ls-links')
def api_client_ls_links(name):
    return jsonify(db_client_ls_links(name))


@app.route('/api/client/<path:name>/ls-links/remove', methods=['POST'])
def api_client_ls_link_remove(name):
    data = request.get_json(silent=True) or {}
    conn = get_conn()
    try:
        if data.get('customer_id'):
            n = conn.execute("DELETE FROM ls_ar_customers WHERE client_name=? AND ls_customer_id=?",
                             (name, str(data['customer_id']))).rowcount
            what = f"lien avec le client Lightspeed #{data['customer_id']}"
        elif data.get('alias'):
            n = conn.execute("DELETE FROM ls_ar_aliases WHERE client_name=? AND alias=?",
                             (name, data['alias'])).rowcount
            what = f"nom reconnu « {data.get('display') or data['alias']} »"
        else:
            return jsonify({'ok': False, 'error': 'Rien à retirer.'}), 400
        conn.commit()
    finally:
        conn.close()
    if n:
        log_audit('Lien Lightspeed retiré', f"{name} — {what}")
    return jsonify({'ok': bool(n)})


@app.route('/api/client/<path:name>/invoice', methods=['POST'])
def api_add_invoice(name):
    data = request.json
    try:
        db_add_invoice(
            name, data['numero'], data['date_facture'], data['echeance'],
            data['montant'], data.get('notes', ''), data.get('montant_paye', 0) or 0,
            data.get('date_paiement') or None,
        )
        log_audit('Ajout facture', f"{name} — n° {data['numero']} — {float(data['montant']):,.2f} $")
        return jsonify({'ok': True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/invoice/<int:invoice_id>', methods=['PUT'])
def api_update_invoice(invoice_id):
    data = request.json
    try:
        existing = db_get_invoice(invoice_id)
        db_update_invoice(
            invoice_id, data['numero'], data['date_facture'], data['echeance'],
            data['montant'], data.get('notes', ''), data.get('montant_paye', 0) or 0,
            data.get('date_paiement') or None,
        )
        client_name = existing['client_name'] if existing else ''
        log_audit('Modification facture', f"{client_name} — n° {data['numero']}")
        return jsonify({'ok': True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/invoice/<int:invoice_id>', methods=['DELETE'])
def api_delete_invoice(invoice_id):
    try:
        inv = db_get_invoice(invoice_id)
        db_delete_invoice(invoice_id)
        detail = f"{inv['client_name']} — n° {inv['numero']} — {inv['montant']:,.2f} $" if inv else f"id={invoice_id}"
        log_audit('Suppression facture', detail)
        return jsonify({'ok': True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/invoice/<int:invoice_id>/paid', methods=['PUT'])
def api_set_invoice_paid(invoice_id):
    data = request.json or {}
    try:
        paid = bool(data.get('paid', True))
        inv = db_get_invoice(invoice_id)
        db_set_invoice_paid(invoice_id, paid, data.get('date_paiement') or None)
        detail = f"{inv['client_name']} — n° {inv['numero']}" if inv else f"id={invoice_id}"
        is_credit = bool(inv) and float(inv['montant'] or 0) < 0
        if is_credit:
            log_audit('Crédit appliqué' if paid else 'Crédit appliqué annulé', detail)
        else:
            log_audit('Facture marquée payée' if paid else 'Paiement annulé', detail)
        return jsonify({'ok': True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/client/<path:name>/statement', methods=['POST'])
def api_statement(name):
    """Génère le PDF et (selon le mode) crée un brouillon ou envoie le courriel via Outlook.
    Ne touche pas à l'Excel — tout vient de la base rapide (le PDF/courriel n'a pas besoin
    d'attendre une synchronisation Excel)."""
    data = request.json or {}
    mode = data.get('mode', 'draft')
    if mode in ('draft', 'draft_silent') and get_settings()['send_mode'] == 'smtp':
        return jsonify({'ok': False, 'error':
                         "Le mode brouillon n'est pas disponible en mode d'envoi SMTP "
                         "(pas de fenêtre de relecture) — utilise \"Envoyer directement\"."}), 400
    try:
        client = db_client_detail(name)
        if client is None:
            return jsonify({'ok': False, 'error': 'Client introuvable'}), 404
        info, invoices, totals = client['info'], client['invoices'], client['totals']

        statement_number = db_next_statement_number()
        pdf_path = generate_statement_pdf(name, info, invoices, totals, statement_number)

        to_email = data.get('email') or info.get('courriel') or ''
        subject = data.get('subject') or f"État de compte — {name} ({statement_number})"
        body = data.get('body') or (
            f"Bonjour,\n\nVeuillez trouver ci-joint votre état de compte au "
            f"{datetime.date.today().strftime('%d/%m/%Y')}.\n\n"
            f"Solde total : {totals['montant']:,.2f} $\n\n"
            f"{get_email_closing_message()}\n\n{get_sender_signature()}"
        )

        if not to_email:
            statut = 'PDF_SEULEMENT'
            db_log_envoi(name, to_email, totals['montant'], statut, 'Aucun courriel client — PDF généré seulement')
            log_audit('État de compte généré', f"{name} — {statement_number} — PDF seulement (aucun courriel)")
            return jsonify({'ok': True, 'pdf': str(pdf_path), 'statut': statut,
                             'warning': "Aucune adresse courriel pour ce client — PDF généré mais courriel non préparé."})

        statut = send_email(to_email, subject, body, pdf_path, mode=mode, purpose='ar')
        db_log_envoi(name, to_email, totals['montant'], statut, f"Via app locale ({mode}) — {statement_number}")
        log_audit('État de compte généré', f"{name} — {statement_number} — {mode} — {totals['montant']:,.2f} $")
        return jsonify({'ok': True, 'pdf': str(pdf_path), 'statut': statut, 'statement_number': statement_number})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/client/<path:name>/pdf')
def api_get_pdf(name):
    client = db_client_detail(name)
    if client is None:
        return jsonify({'error': 'Client introuvable'}), 404
    statement_number = db_next_statement_number()
    pdf_path = generate_statement_pdf(name, client['info'], client['invoices'], client['totals'], statement_number)
    log_audit('PDF état de compte téléchargé', f"{name} — {statement_number}")
    return send_file(str(pdf_path), as_attachment=True)


@app.route('/api/reports/monthly')
def api_monthly_report():
    resp = permission_required_check('reports')
    if resp is not None:
        return resp
    try:
        year = int(request.args.get('year'))
        month = int(request.args.get('month'))
        if not (1 <= month <= 12):
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({'error': "Paramètres 'year' et 'month' invalides."}), 400
    by_client = db_invoices_by_month(year, month)
    pdf_path = generate_monthly_report_pdf(year, month, by_client)
    log_audit('Rapport mensuel généré', f"{MOIS_FR[month]} {year}")
    return send_file(str(pdf_path), as_attachment=True,
                      download_name=f"Rapport_{MOIS_FR[month]}_{year}.pdf")


@app.route('/api/reports/envois')
def api_envois_report():
    resp = permission_required_check('reports')
    if resp is not None:
        return resp
    try:
        year = int(request.args.get('year'))
        month = int(request.args.get('month'))
        if not (1 <= month <= 12):
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({'error': "Paramètres 'year' et 'month' invalides."}), 400
    rows = db_envois_by_month(year, month)
    pdf_path = generate_envoi_report_pdf(year, month, rows)
    log_audit('Rapport d\'envoi généré', f"{MOIS_FR[month]} {year}")
    return send_file(str(pdf_path), as_attachment=True,
                      download_name=f"Rapport_envois_{MOIS_FR[month]}_{year}.pdf")


@app.route('/api/reports/aging')
def api_aging_report():
    resp = permission_required_check('reports')
    if resp is not None:
        return resp
    year_raw = request.args.get('year')
    month_raw = request.args.get('month')
    ref_date = None
    period_label = None
    if year_raw or month_raw:
        try:
            year = int(year_raw)
            month = int(month_raw)
            if not (1 <= month <= 12):
                raise ValueError
        except (TypeError, ValueError):
            return jsonify({'error': "Paramètres 'year' et 'month' invalides."}), 400
        ref_date = month_end_or_today(year, month)
        period_label = f"{MOIS_FR[month]} {year}"

    rows = db_aging_all_clients(ref_date)
    pdf_path = generate_aging_report_pdf(rows, ref_date, period_label)
    ref_str = (ref_date or datetime.date.today()).strftime('%Y-%m-%d')
    log_audit('Rapport d\'âge généré', period_label or "aujourd'hui")
    return send_file(str(pdf_path), as_attachment=True,
                      download_name=f"Rapport_age_{ref_str}.pdf")


@app.route('/comptes-de-credit')
def credit_accounts_page():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    return render_template('credit_accounts.html', company=get_company_name(),
                            username=session.get('username'), is_admin=session.get('is_admin'),
                            permissions=session.get('permissions') or [])


@app.route('/api/credit-clients')
def api_list_credit_clients():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    return jsonify(db_list_credit_clients())


@app.route('/api/credit-clients/<int:client_id>')
def api_get_credit_client(client_id):
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    client = db_get_credit_client(client_id)
    if not client:
        return jsonify({'error': 'Client introuvable.'}), 404
    client['movements'] = db_credit_client_movements(client_id)
    client['can_delete'] = bool(session.get('is_admin'))
    return jsonify(client)


def _fmt_credit_val(k, v):
    if k == 'no_sync':
        return "oui" if v else "non"
    if isinstance(v, (int, float)) and k != 'no_sync':
        return f"{float(v):,.2f} $".replace(',', ' ')
    return v if v not in (None, '') else '—'


@app.route('/api/credit-clients/<int:client_id>', methods=['PUT'])
def api_update_credit_client(client_id):
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    try:
        before, changes = db_update_credit_client(client_id, request.json or {})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    if changes:
        details = "; ".join(f"{CREDIT_FIELD_LABELS.get(k, k)} : {_fmt_credit_val(k, a)} → {_fmt_credit_val(k, b)}"
                            for k, a, b in changes)
        log_audit('Modification compte de crédit', f"{_credit_client_display_name(before)} — {details}")
    return jsonify({'ok': True, 'changed': len(changes)})


@app.route('/api/credit-clients/<int:client_id>', methods=['DELETE'])
def api_delete_credit_client(client_id):
    resp = admin_required_check()
    if resp is not None:
        return resp
    try:
        before, n = db_delete_credit_client(client_id)
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    log_audit('Suppression compte de crédit',
              f"{_credit_client_display_name(before)} — limite {_fmt_credit_val('x', before.get('credit_limit') or 0)}, "
              f"dû {_fmt_credit_val('x', before.get('solde') or 0)}, dépôt {_fmt_credit_val('x', before.get('deposit') or 0)}, "
              f"{n} mouvement(s) supprimé(s)")
    return jsonify({'ok': True})


@app.route('/api/credit-movements/<int:movement_id>', methods=['PUT'])
def api_update_credit_movement(movement_id):
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    try:
        before, after = db_update_credit_movement(movement_id, request.json or {})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    client = db_get_credit_client(before['credit_client_id']) or {}
    log_audit('Modification mouvement de crédit',
              f"{client.get('display_name', '?')} — {before.get('date_mouvement') or '—'} "
              f"{before.get('type') or ''} {float(before.get('montant') or 0):.2f} $ → "
              f"{after['date_mouvement'] or '—'} {after['type'] or ''} {after['montant']:.2f} $")
    return jsonify({'ok': True})


@app.route('/api/credit-movements/<int:movement_id>', methods=['DELETE'])
def api_delete_credit_movement(movement_id):
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    try:
        m = db_delete_credit_movement(movement_id)
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    client = db_get_credit_client(m['credit_client_id']) or {}
    log_audit('Suppression mouvement de crédit',
              f"{client.get('display_name', '?')} — {m.get('date_mouvement') or '—'} {m.get('type') or ''} "
              f"{float(m.get('montant') or 0):.2f} $ (solde ajusté)")
    return jsonify({'ok': True})


def _read_upload_rows(file_storage):
    """Lit un fichier .xlsx ou .csv téléversé et retourne (headers, rows) —
    rows est une liste de listes, headers la première ligne. Détecte le
    format par l'extension du nom de fichier."""
    filename = (file_storage.filename or '').lower()
    raw = file_storage.read()
    if filename.endswith('.csv'):
        try:
            text = raw.decode('utf-8-sig')
        except UnicodeDecodeError:
            text = raw.decode('latin-1')
        reader = csv.reader(io.StringIO(text))
        all_rows = [row for row in reader if any((c or '').strip() for c in row)]
        if not all_rows:
            return [], []
        return all_rows[0], all_rows[1:]
    else:
        wb = openpyxl.load_workbook(io.BytesIO(raw), data_only=True)
        ws = wb.worksheets[0]
        all_rows = [list(r) for r in ws.iter_rows(values_only=True)
                    if any(c not in (None, '') for c in r)]
        if not all_rows:
            return [], []
        return [str(h or '') for h in all_rows[0]], all_rows[1:]


def _find_col(headers, *candidates):
    """Trouve l'index d'une colonne par nom (insensible à la casse/accents
    approximative), en essayant chaque candidat dans l'ordre."""
    norm_headers = [(h or '').strip().lower() for h in headers]
    for cand in candidates:
        cand_l = cand.strip().lower()
        for i, h in enumerate(norm_headers):
            if h == cand_l:
                return i
    return None


def _parse_money(v):
    """Convertit une valeur monétaire venant d'un fichier importé (nombre,
    ou texte du genre "$150000.00", "$-219.30", "1 234,56$", "") en float.
    Tolère le symbole $ avant ou après le signe négatif, les espaces et les
    séparateurs de milliers (virgule ou espace)."""
    if v is None:
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    if not s:
        return 0.0
    neg = '-' in s
    s = s.replace('$', '').replace('-', '').replace(' ', '').replace('\xa0', '').replace('\u202f', '')
    if ',' in s and '.' not in s and re.search(r',\d{1,2}$', s):
        # Format français : la virgule est le séparateur décimal (« 1 234,56 $ »).
        s = s.replace(',', '.')
    else:
        s = s.replace(',', '')
    if not s:
        return 0.0
    try:
        val = float(s)
    except ValueError:
        return 0.0
    return -val if neg else val


@app.route('/api/credit-clients/import', methods=['POST'])
def api_import_credit_clients():
    # Remplace/réinitialise TOUTE la liste des clients (et supprime l'historique
    # des mouvements en cascade) — opération destructrice réservée aux
    # administrateurs, contrairement aux autres actions de ce module qui ne
    # demandent que la permission 'credit_accounts'.
    resp = admin_required_check()
    if resp is not None:
        return resp
    if 'file' not in request.files or not request.files['file'].filename:
        return jsonify({'ok': False, 'error': "Aucun fichier reçu."}), 400
    divide_by_2 = str(request.form.get('divide_by_2', '')).lower() in ('1', 'true', 'on')
    try:
        headers, data_rows = _read_upload_rows(request.files['file'])
        # Deux formats acceptés : le fichier en français (Prénom / Entreprise,
        # Nom, Limite de crédit, Montant dû, Dépôt) ou l'export Lightspeed
        # « credit_account_listings » en anglais (First Name, Last Name,
        # Credit Limit, Debt).
        i_prenom = _find_col(headers, 'Prénom / Entreprise', 'Prenom / Entreprise', 'First Name',
                             'Nom', 'Client')
        i_nom = _find_col(headers, 'Last Name') if _find_col(headers, 'First Name') == i_prenom \
            else _find_col(headers, 'Nom', 'Last Name')
        i_limit = _find_col(headers, 'Limite de crédit', 'Limite de credit', 'Credit Limit')
        i_du = _find_col(headers, 'Montant dû', 'Montant du', 'Debt', 'Solde')
        i_dep = _find_col(headers, 'Dépôt', 'Depot', 'Deposit')
        i_src = _find_col(headers, 'Ligne source')
        if i_prenom is None:
            return jsonify({'ok': False, 'error':
                             "Colonne du nom du client introuvable (attendu : "
                             "« Prénom / Entreprise » ou, pour l'export Lightspeed, "
                             "« First Name »)."}), 400
        rows = []
        for r in data_rows:
            def cell(i):
                return r[i] if i is not None and i < len(r) else None
            montant_du = _parse_money(cell(i_du))
            deposit = _parse_money(cell(i_dep))
            if i_dep is None and montant_du < 0:
                # Export Lightspeed (pas de colonne Dépôt) : un « Debt » négatif
                # est un crédit en faveur du client — c'est son dépôt, et il ne
                # doit rien.
                deposit = -montant_du
                montant_du = 0.0
            if divide_by_2:
                montant_du = montant_du / 2
                deposit = deposit / 2
            rows.append({
                'prenom_entreprise': (str(cell(i_prenom)).strip() if cell(i_prenom) is not None else ''),
                'nom': (str(cell(i_nom)).strip() or None) if cell(i_nom) is not None else None,
                'credit_limit': _parse_money(cell(i_limit)),
                'solde': montant_du,
                'deposit': deposit,
                'ligne_source': cell(i_src),
            })
        rows = [r for r in rows if r['prenom_entreprise']]
        db_backup_credit(f"Avant réinitialisation de la liste ({request.files['file'].filename})",
                         session.get('username'))
        count = db_import_credit_clients(rows)
        log_audit('Import liste comptes de crédit', f"{count} client(s)" + (" (montants divisés par 2)" if divide_by_2 else ""))
        snap_id = db_capture_credit_snapshot(
            'Import initial / réinitialisation de la liste', request.files['file'].filename)
        return jsonify({'ok': True, 'count': count, 'snapshot_id': snap_id})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/credit-movements/import', methods=['POST'])
def api_import_credit_movements():
    """Accepte deux formats de fichier Lightspeed, détectés automatiquement
    à partir des en-têtes de colonnes :
      1) Journal de transactions (colonnes Customer + Amount, ex. la feuille
         « Mouvements ») -> chaque ligne est ajoutée comme mouvement distinct.
      2) Instantané mensuel des soldes (colonnes First Name/Last Name +
         Debt/Credit Limit, ex. l'export récurrent
         « credit_account_listings... .csv ») -> chaque ligne remplace la
         limite de crédit et le solde actuel du client correspondant."""
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    if 'file' not in request.files or not request.files['file'].filename:
        return jsonify({'ok': False, 'error': "Aucun fichier reçu."}), 400
    try:
        headers, data_rows = _read_upload_rows(request.files['file'])
        i_amount = _find_col(headers, 'Amount', 'Montant')
        i_customer = _find_col(headers, 'Customer', 'Client')
        i_first = _find_col(headers, 'First Name', 'Prénom / Entreprise', 'Prenom / Entreprise', 'Prénom', 'Prenom')
        i_last = _find_col(headers, 'Last Name', 'Nom')
        i_debt = _find_col(headers, 'Debt', 'Montant dû', 'Montant du', 'Solde')
        i_limit = _find_col(headers, 'Credit Limit', 'Limite de crédit', 'Limite de credit')

        if i_customer is not None and i_amount is not None:
            # --- Format 1 : journal de transactions ---
            i_id = _find_col(headers, 'ID')
            i_date = _find_col(headers, 'Date')
            i_type = _find_col(headers, 'Type')
            i_sale = _find_col(headers, 'Sale')
            rows = []
            for r in data_rows:
                def cell(i):
                    return r[i] if i is not None and i < len(r) else None
                date_raw = cell(i_date)
                date_str = str(date_raw)[:10] if date_raw else None
                rows.append({
                    'lightspeed_id': cell(i_id),
                    'date': date_str,
                    'montant': _parse_money(cell(i_amount)),
                    'type': cell(i_type),
                    'sale': cell(i_sale),
                    'customer': cell(i_customer),
                })
            rows = [r for r in rows if r['customer']]
            backup_id = db_backup_credit(
                f"Avant import du journal de transactions ({request.files['file'].filename})",
                session.get('username'))
            summary = db_import_credit_movements(rows)
            if not summary['imported'] and not summary['created_clients']:
                db_discard_credit_backup(backup_id)
            log_audit('Import mouvements comptes de crédit (journal de transactions)',
                      f"{summary['imported']} importé(s), {summary['skipped']} ignoré(s) (déjà présents), "
                      f"{summary['created_clients']} nouveau(x) client(s), "
                      f"{summary['locked']} ligne(s) ignorée(s) (compte non synchronisé)")
            snap_id = db_capture_credit_snapshot(
                'Import journal de transactions', request.files['file'].filename)
            return jsonify({'ok': True, 'mode': 'transactions', 'snapshot_id': snap_id, **summary})

        elif i_first is not None and (i_debt is not None or i_limit is not None):
            # --- Format 2 : instantané mensuel des soldes ---
            rows = []
            for r in data_rows:
                def cell(i):
                    return r[i] if i is not None and i < len(r) else None
                prenom = cell(i_first)
                if not prenom:
                    continue
                rows.append({
                    'prenom_entreprise': prenom,
                    'nom': cell(i_last),
                    'credit_limit': _parse_money(cell(i_limit)),
                    'solde': _parse_money(cell(i_debt)),
                })
            backup_id = db_backup_credit(
                f"Avant import de l'instantané mensuel ({request.files['file'].filename})",
                session.get('username'))
            summary = db_update_credit_balances(rows)
            if not summary['updated'] and not summary['created_clients']:
                db_discard_credit_backup(backup_id)
            log_audit('Import mouvements comptes de crédit (instantané mensuel)',
                      f"{summary['updated']} solde(s) mis à jour, {summary['unchanged']} inchangé(s), "
                      f"{summary['created_clients']} nouveau(x) client(s), "
                      f"{summary['locked']} compte(s) non synchronisé(s) ignoré(s)")
            snap_id = db_capture_credit_snapshot(
                'Import instantané mensuel Lightspeed', request.files['file'].filename)
            return jsonify({'ok': True, 'mode': 'snapshot', 'snapshot_id': snap_id, **summary})

        else:
            return jsonify({'ok': False, 'error':
                             "Format de fichier non reconnu. Colonnes attendues : soit « Customer » "
                             "et « Amount » (journal de transactions), soit « First Name » et "
                             "« Debt » / « Credit Limit » (instantané mensuel Lightspeed)."}), 400
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/credit-snapshots')
def api_list_credit_snapshots():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    return jsonify(db_list_credit_snapshots())


@app.route('/api/credit-snapshots/<int:snapshot_id>/pdf')
def api_credit_snapshot_pdf(snapshot_id):
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    exclude_zero = str(request.args.get('exclude_zero', '')).lower() in ('1', 'true', 'on')
    header, lines = db_get_credit_snapshot(snapshot_id)
    if not header:
        return jsonify({'error': "Instantané introuvable."}), 404
    if exclude_zero:
        lines = [l for l in lines if (l.get('credit_limit') or 0) != 0
                 or (l.get('solde') or 0) != 0 or (l.get('deposit') or 0) != 0]
    dt = header['created_at']
    dt_label = dt[:16].replace('T', ' ')
    subtitle = f"Photo prise le {dt_label}" + (f" — {header['label']}" if header.get('label') else "")
    if exclude_zero:
        subtitle += " (clients à 0$ exclus)"
    pdf_path = generate_credit_accounts_pdf(
        lines, "COMPTES DE CRÉDIT", subtitle,
        f"Comptes_credit_{dt[:10]}_{dt[11:13]}h{dt[14:16]}_{snapshot_id}" + ('_sans0' if exclude_zero else '')
    )
    log_audit('PDF comptes de crédit généré', f"Import #{snapshot_id} du {dt_label}" +
              (" (clients à 0$ exclus)" if exclude_zero else ""))
    return send_file(str(pdf_path), as_attachment=True,
                      download_name=f"Comptes_de_credit_{dt[:10]}_{dt[11:13]}h{dt[14:16]}.pdf")


@app.route('/api/credit-clients/pdf')
def api_credit_clients_pdf():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    exclude_zero = str(request.args.get('exclude_zero', '')).lower() in ('1', 'true', 'on')
    clients = db_list_credit_clients()
    if exclude_zero:
        clients = [c for c in clients if (c.get('credit_limit') or 0) != 0
                   or (c.get('solde') or 0) != 0 or (c.get('deposit') or 0) != 0]
    today_str = datetime.date.today().strftime('%Y-%m-%d')
    subtitle = f"Liste actuelle au {today_str}" + (" (clients à 0$ exclus)" if exclude_zero else "")
    pdf_path = generate_credit_accounts_pdf(
        clients, "COMPTES DE CRÉDIT", subtitle,
        f"Comptes_credit_actuel_{today_str}" + ('_sans0' if exclude_zero else '')
    )
    log_audit('PDF comptes de crédit généré', "Liste actuelle" + (" (clients à 0$ exclus)" if exclude_zero else ""))
    return send_file(str(pdf_path), as_attachment=True,
                      download_name=f"Comptes_de_credit_actuel_{today_str}.pdf")


# ------------------------------------------------------------
# Routes — rapports personnalisés (1.12.0)
# ------------------------------------------------------------
@app.route('/rapports-personnalises')
def custom_reports_page():
    resp = permission_required_check('custom_reports')
    if resp is not None:
        return resp
    return render_template('custom_reports.html', company=get_company_name(),
                           username=session.get('username'), is_admin=session.get('is_admin'),
                           permissions=session.get('permissions') or [])


def _rep_run_local(kind, days_needed, compute, username):
    """Calcule un rapport à partir de la base locale ; si des jours manquent,
    les récupère d'abord dans Lightspeed (en arrière-plan)."""
    st = _rep_state
    st.update(error=None)
    if not days_needed:
        st[kind] = compute()
        return True
    st[kind] = None

    def then():
        try:
            st[kind] = compute()
        except Exception as e:
            traceback.print_exc()
            st['error'] = f"Erreur inattendue : {e}"
    start_store_job('période demandée', days_needed, username, then=then)
    return False


@app.route('/api/reports/status')
def api_reports_status():
    resp = permission_required_check('custom_reports')
    if resp is not None:
        return resp
    st, ss = _rep_state, _store_state
    cfg = ls_config()
    conn = get_conn()
    shops = [dict(r) for r in conn.execute("SELECT shop_id id, name FROM ls_shops WHERE archived=0 ORDER BY name").fetchall()]
    sends = [dict(r) for r in conn.execute("SELECT * FROM report_sends ORDER BY id DESC LIMIT 25").fetchall()]
    conn.close()
    sc = store_cfg()
    running = ss['running']
    return jsonify({'connected': cfg['connected'], 'is_admin': bool(session.get('is_admin')),
                    'running': running, 'progress': ss['progress'], 'job': ss['kind'] if running else None,
                    'error': st['error'] or (ss['error'] if not running else None),
                    'result': st.get('result') if not running else None,
                    'comparison': st.get('comparison') if not running else None,
                    'shops': shops, 'store': store_status(), 'sends': sends,
                    'recipients': sc['recipients'], 'last_week': last_week_bounds()[0].isoformat(),
                    'settings': {k: sc[k] for k in ('enabled', 'start', 'hour', 'auto_daily', 'auto_weekly',
                                                    'daily_level', 'weekly_level', 'bcc_company')},
                    'company_email': get_company_email(), 'send_now': dict(_send_now_state)})


@app.route('/api/reports/send-now', methods=['POST'])
def api_reports_send_now():
    resp = admin_required_check()
    if resp is not None:
        return resp
    kind = (request.get_json(silent=True) or {}).get('kind')
    if kind not in ('daily', 'weekly'):
        return jsonify({'ok': False, 'error': 'Rapport inconnu.'}), 400
    cfg = store_cfg()
    to = [x['email'] for x in cfg['recipients'] if x.get('daily' if kind == 'daily' else 'weekly') and x.get('email')]
    if not to:
        return jsonify({'ok': False, 'error': "Aucun gestionnaire n'est coché pour ce rapport dans la liste ci-dessus."}), 400
    _start, missing = _send_now_days(kind)
    if missing and not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Des jours ne sont pas encore dans Kubios et Kubios n'est pas connecté à Lightspeed."}), 400
    if _send_now_state['running']:
        return jsonify({'ok': False, 'error': 'Un envoi est déjà en cours.'}), 409
    if missing and _store_state['running']:
        return jsonify({'ok': False, 'error': 'Une lecture Lightspeed est déjà en cours. Réessaie dans quelques minutes.'}), 409
    _send_now_state.update(running=True, error=None, kind=kind, message='Envoi en cours…')
    threading.Thread(target=_send_now_worker, daemon=True,
                     args=(kind, to, cfg['daily_level'] if kind == 'daily' else cfg['weekly_level'], session.get('username'))).start()
    return jsonify({'ok': True, 'recipients': to, 'missing': len(missing)})


def _rep_dates(data):
    start = datetime.date.fromisoformat(data.get('start') or '')
    end = datetime.date.fromisoformat(data.get('end') or '')
    return start, end


@app.route('/api/reports/sales-by-category', methods=['POST'])
def api_reports_sales_by_category():
    resp = permission_required_check('custom_reports')
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}
    try:
        start, end = _rep_dates(data)
    except ValueError:
        return jsonify({'ok': False, 'error': "Dates invalides."}), 400
    if end < start:
        return jsonify({'ok': False, 'error': "La date de fin est avant la date de début."}), 400
    end = min(end, datetime.date.today())
    level = 'top' if data.get('level') == 'top' else 'full'
    shop_id = str(data.get('shop_id') or '').strip()
    missing = store_missing_days(start, end, need_tax=True, need_pay=True)
    if missing and not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Des jours de cette période ne sont pas encore dans Kubios et Kubios n'est "
                                              "pas connecté à Lightspeed (Administration → Lightspeed)."}), 400
    user = session.get('username')
    try:
        ready = _rep_run_local('result', missing, lambda: local_sales_by_category(start, end, shop_id, level, user), user)
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    return jsonify({'ok': True, 'ready': ready, 'missing': len(missing)})


@app.route('/api/reports/weekly', methods=['POST'])
def api_reports_weekly():
    resp = permission_required_check('custom_reports')
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}
    try:
        w0 = datetime.date.fromisoformat(data.get('week_start') or '')
    except ValueError:
        return jsonify({'ok': False, 'error': "Semaine invalide."}), 400
    w0 = w0 - datetime.timedelta(days=w0.weekday())
    w1 = min(w0 + datetime.timedelta(days=6), datetime.date.today())
    level = 'full' if data.get('level') == 'full' else 'top'
    shop_id = str(data.get('shop_id') or '').strip()
    missing = store_missing_days(w0, w1) + store_missing_days(w0 - datetime.timedelta(days=364),
                                                               w0 - datetime.timedelta(days=358))
    if missing and not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Des jours ne sont pas encore dans Kubios et Kubios n'est pas connecté à Lightspeed."}), 400
    user = session.get('username')
    try:
        ready = _rep_run_local('comparison', missing, lambda: weekly_comparison(w0, shop_id, level, user), user)
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    return jsonify({'ok': True, 'ready': ready, 'missing': len(missing)})


@app.route('/api/reports/weekly/export/<fmt>')
def api_reports_weekly_export(fmt):
    resp = permission_required_check('custom_reports')
    if resp is not None:
        return resp
    r = _rep_state.get('comparison')
    if not r:
        return jsonify({'error': "Aucun comparatif à exporter : génère-le d'abord."}), 400
    path = export_comparison_xlsx(r) if fmt == 'xlsx' else export_comparison_pdf(r)
    return send_file(str(path), as_attachment=(fmt == 'xlsx'), download_name=path.name)


_EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')


@app.route('/api/reports/send', methods=['POST'])
def api_reports_send():
    resp = permission_required_check('custom_reports')
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}
    r = _rep_state.get('comparison' if data.get('kind') == 'weekly' else 'result')
    if not r:
        return jsonify({'ok': False, 'error': "Génère d'abord le rapport."}), 400
    emails = sorted({e.strip() for e in (data.get('emails') or []) if isinstance(e, str) and e.strip()})
    bad = [e for e in emails if not _EMAIL_RE.match(e)]
    if not emails or bad:
        return jsonify({'ok': False, 'error': "Adresse invalide : " + ", ".join(bad) if bad else "Choisis au moins un destinataire."}), 400
    try:
        sent, errors = send_report_email(r, emails, session.get('username'),
                                         bcc_company=bool(data.get('bcc_company')))
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': f"Envoi impossible : {e}"}), 500
    return jsonify({'ok': bool(sent), 'sent': sent, 'errors': errors,
                    'error': "; ".join(errors) if errors and not sent else None})


@app.route('/api/reports/settings', methods=['POST'])
def api_reports_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}
    recips = []
    for x in data.get('recipients') or []:
        e = (x.get('email') or '').strip()
        if not e:
            continue
        if not _EMAIL_RE.match(e):
            return jsonify({'ok': False, 'error': f"Adresse invalide : {e}"}), 400
        recips.append({'name': (x.get('name') or '').strip(), 'email': e,
                       'daily': bool(x.get('daily')), 'weekly': bool(x.get('weekly'))})
    try:
        start = datetime.date.fromisoformat(data.get('start') or STORE_DEFAULT_START)
        hour = int(data.get('hour', 1))
        if not 0 <= hour <= 23:
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': "Date de départ ou heure invalide."}), 400
    meta_set('rep_recipients', json.dumps(recips, ensure_ascii=False))
    meta_set('rep_history_start', start.isoformat())
    meta_set('rep_nightly_hour', hour)
    meta_set('rep_store_enabled', '1' if data.get('enabled', True) else '0')
    meta_set('rep_auto_daily', '1' if data.get('auto_daily') else '0')
    meta_set('rep_auto_weekly', '1' if data.get('auto_weekly') else '0')
    meta_set('rep_daily_level', 'top' if data.get('daily_level') == 'top' else 'full')
    meta_set('rep_weekly_level', 'full' if data.get('weekly_level') == 'full' else 'top')
    meta_set('rep_bcc_company', '1' if data.get('bcc_company') else '0')
    log_audit('Paramètres des rapports automatiques modifiés',
              f"{len(recips)} gestionnaire(s) ; quotidien {'oui' if data.get('auto_daily') else 'non'} ; "
              f"hebdomadaire {'oui' if data.get('auto_weekly') else 'non'} ; à {hour} h ; historique depuis {start}")
    return jsonify({'ok': True})


@app.route('/api/reports/history/start', methods=['POST'])
def api_reports_history_start():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Kubios n'est pas connecté à Lightspeed."}), 400
    start = datetime.date.fromisoformat(store_cfg()['start'])
    yesterday = datetime.date.today() - datetime.timedelta(days=1)
    missing = store_missing_days(start, yesterday)
    if not missing:
        return jsonify({'ok': True, 'missing': 0})
    try:
        start_store_job('historique', missing, session.get('username'))
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    return jsonify({'ok': True, 'missing': len(missing)})


@app.route('/api/reports/nightly/run', methods=['POST'])
def api_reports_nightly_run():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if _store_state['running']:
        return jsonify({'ok': False, 'error': "Une récupération est déjà en cours."}), 409
    threading.Thread(target=nightly_reports_run, daemon=True).start()
    log_audit('Tâche de nuit des rapports lancée manuellement')
    return jsonify({'ok': True})


@app.route('/api/reports/sales-by-category/export/<fmt>')
def api_reports_export(fmt):
    resp = permission_required_check('custom_reports')
    if resp is not None:
        return resp
    r = _rep_state.get('result')
    if not r:
        return jsonify({'error': "Aucun rapport à exporter : génère-le d'abord."}), 400
    try:
        path = export_report_xlsx(r) if fmt == 'xlsx' else export_report_pdf(r) if fmt == 'pdf' else None
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': f"Exportation impossible : {e}"}), 500
    if path is None:
        return jsonify({'error': 'Format inconnu.'}), 400
    return send_file(str(path), as_attachment=(fmt == 'xlsx'), download_name=path.name)


# ------------------------------------------------------------
# Routes — comptes à recevoir : factures Lightspeed + sauvegardes (1.11.0)
# ------------------------------------------------------------
def _ls_ar_default_since():
    last = meta_get('ls_ar_last_until')
    try:
        # quelques jours de chevauchement : les factures déjà inscrites sont ignorées
        return datetime.date.fromisoformat(last) - datetime.timedelta(days=3)
    except (TypeError, ValueError):
        return datetime.date.today() - datetime.timedelta(days=30)


@app.route('/api/lightspeed/ar/status')
def api_ls_ar_status():
    st = _ls_ar_state
    cfg = ls_config()
    return jsonify({
        'connected': cfg['connected'],
        'is_admin': bool(session.get('is_admin')),
        'running': st['running'], 'progress': st['progress'], 'error': st['error'],
        'preview': st['preview'] if not st['running'] else None,
        'default_since': _ls_ar_default_since().isoformat(),
        'last_until': meta_get('ls_ar_last_until'),
    })


@app.route('/api/lightspeed/ar/check', methods=['POST'])
def api_ls_ar_check():
    if not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Kubios n'est pas connecté à Lightspeed "
                                              "(Administration → Lightspeed)."}), 400
    data = request.get_json(silent=True) or {}
    try:
        since = datetime.date.fromisoformat(data.get('since') or '')
    except ValueError:
        return jsonify({'ok': False, 'error': "Date de départ invalide."}), 400
    if since > datetime.date.today():
        return jsonify({'ok': False, 'error': "La date de départ est dans le futur."}), 400
    try:
        start_ls_ar_check(since, session.get('username'), bool(data.get('include_ignored')))
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    return jsonify({'ok': True})


@app.route('/api/lightspeed/ar/apply', methods=['POST'])
def api_ls_ar_apply():
    data = request.get_json(silent=True) or {}
    if _ls_ar_state['running']:
        return jsonify({'ok': False, 'error': "Une vérification est en cours."}), 409
    try:
        res = ls_ar_apply(data.get('token'), data.get('choices'), session.get('username'),
                          data.get('payment_choices'))
    except (RuntimeError, LightspeedError) as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': f"Erreur inattendue : {e}"}), 500
    parts = [f"{res['added']} facture(s) inscrite(s)"]
    if res['created_clients']:
        parts.append(f"{len(res['created_clients'])} client(s) créé(s) : " + ", ".join(res['created_clients']))
    if res['ignored']:
        parts.append(f"{res['ignored']} vente(s) ignorée(s)")
    if res['skipped']:
        parts.append(f"{res['skipped']} déjà présente(s)")
    for pa in res['payments_applied']:
        parts.append(f"paiement {_fmt_money_fr(pa['montant'])} du {pa['date']} ({pa['client']}) → "
                     + (", ".join(pa['factures']) or "aucune facture ouverte")
                     + (f", excédent {_fmt_money_fr(pa['excedent'])}" if pa['excedent'] else ""))
    if res['payments_marked']:
        parts.append(f"{res['payments_marked']} paiement(s) marqué(s) « déjà fait »")
    if res['linked']:
        parts.append("client(s) Lightspeed relié(s) : " + ", ".join(res['linked']))
    log_audit('Factures Lightspeed inscrites', "; ".join(parts))
    return jsonify(dict(res, ok=True))


@app.route('/api/ar-backups')
def api_list_ar_backups():
    return jsonify({'backups': db_list_credit_backups('ar'), 'can_restore': bool(session.get('is_admin'))})


@app.route('/api/ar-backups/<int:backup_id>/restore', methods=['POST'])
def api_restore_ar_backup(backup_id):
    resp = admin_required_check()
    if resp is not None:
        return resp
    if not _ls_ar_lock.acquire(blocking=False):
        return jsonify({'ok': False, 'error': "Une vérification Lightspeed est en cours. Réessaie dans un instant."}), 409
    try:
        b, pre_id = db_restore_credit_backup(backup_id, session.get('username'), scope='ar')
        _ls_ar_state['preview'] = None
    except RuntimeError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': f"Restauration impossible : {e}. Aucune donnée n'a été modifiée."}), 500
    finally:
        _ls_ar_lock.release()
    log_audit('Restauration des comptes à recevoir',
              f"Sauvegarde du {b['created_at'][:16]} ({b['label']}) — {b['client_count']} client(s), "
              f"{b['movement_count']} facture(s). L'état précédent a été sauvegardé (#{pre_id}).")
    return jsonify({'ok': True, 'client_count': b['client_count'], 'invoice_count': b['movement_count'],
                    'pre_backup_id': pre_id})


# ------------------------------------------------------------
# Routes — sauvegardes des comptes de crédit (1.10.1)
# ------------------------------------------------------------
@app.route('/api/credit-backups')
def api_list_credit_backups():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    return jsonify({'backups': db_list_credit_backups(), 'can_restore': bool(session.get('is_admin')),
                    'folder': str(CREDIT_BACKUP_DIR), 'keep': CREDIT_BACKUP_KEEP})


@app.route('/api/credit-backups/<int:backup_id>/restore', methods=['POST'])
def api_restore_credit_backup(backup_id):
    # Remplace toute la liste des comptes de crédit : réservé aux administrateurs.
    resp = admin_required_check()
    if resp is not None:
        return resp
    if not _ls_sync_lock.acquire(blocking=False):
        return jsonify({'ok': False, 'error': "Une synchronisation Lightspeed est en cours. "
                                              "Réessaie quand elle sera terminée."}), 409
    try:
        b, pre_id = db_restore_credit_backup(backup_id, session.get('username'))
    except RuntimeError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': f"Restauration impossible : {e}. Aucune donnée n'a été modifiée."}), 500
    finally:
        _ls_sync_lock.release()
    log_audit('Restauration des comptes de crédit',
              f"Sauvegarde du {b['created_at'][:16]} ({b['label']}) — {b['client_count']} compte(s), "
              f"{b['movement_count']} mouvement(s). L'état précédent a été sauvegardé (#{pre_id}).")
    return jsonify({'ok': True, 'client_count': b['client_count'], 'pre_backup_id': pre_id})


# ------------------------------------------------------------
# Routes — Lightspeed (1.10.0)
# ------------------------------------------------------------
def _ls_status_payload():
    cfg = ls_config()
    try:
        last_result = json.loads(meta_get('ls_last_sync_result') or 'null')
    except ValueError:
        last_result = None
    conn = get_conn()
    pending = conn.execute("SELECT COUNT(*) c FROM ls_pending_accounts").fetchone()['c']
    conn.close()
    return {
        'connected': cfg['connected'],
        'account_id': cfg['account_id'],
        'account_name': cfg['account_name'],
        'auto_sync': cfg['auto_sync'],
        'auto_mode': cfg['auto_mode'],
        'auto_mode_text': ls_auto_mode_text(cfg['auto_mode'], cfg['auto_sync_hour']),
        'auto_sync_hour': cfg['auto_sync_hour'],
        'balance_sign': cfg['balance_sign'],
        'last_sync': meta_get('ls_last_sync'),
        'last_result': last_result,
        'last_result_text': _ls_result_text(last_result) if last_result else '',
        'last_error': meta_get('ls_last_sync_error'),
        'pending': pending,
        'running': _ls_sync_state['running'],
        'progress': _ls_sync_state['progress'],
        'current_error': _ls_sync_state['error'],
        'current_result': _ls_sync_state['result'],
        'current_result_text': _ls_result_text(_ls_sync_state['result']) if _ls_sync_state['result'] else '',
    }


@app.route('/api/lightspeed/settings')
def api_ls_get_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    cfg = ls_config()
    return jsonify({
        'client_id': cfg['client_id'],
        'secret_set': bool(cfg['client_secret']),
        'redirect_uri': cfg['redirect_uri'],
        'default_redirect_uri': ls_default_redirect_uri(),
        'connected': cfg['connected'],
        'account_id': cfg['account_id'],
        'account_name': cfg['account_name'],
        'balance_sign': cfg['balance_sign'],
        'auto_sync': cfg['auto_sync'],
        'auto_mode': cfg['auto_mode'],
        'auto_mode_text': ls_auto_mode_text(cfg['auto_mode'], cfg['auto_sync_hour']),
        'auto_sync_hour': cfg['auto_sync_hour'],
        'last_sync': meta_get('ls_last_sync'),
    })


@app.route('/api/lightspeed/settings', methods=['POST'])
def api_ls_set_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}
    old = ls_config()
    client_id = (data.get('client_id') or '').strip()
    secret = (data.get('client_secret') or '').strip()
    redirect_uri = (data.get('redirect_uri') or '').strip() or ls_default_redirect_uri()
    if not redirect_uri.lower().startswith(('http://', 'https://')):
        return jsonify({'ok': False, 'error': "L'adresse de retour doit commencer par http:// ou https://."}), 400
    sign = data.get('balance_sign') or 'auto'
    if sign not in LS_BALANCE_SIGNS:
        return jsonify({'ok': False, 'error': "Sens du solde invalide."}), 400
    try:
        hour = int(data.get('auto_sync_hour', 22))
        if not 0 <= hour <= 23:
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': "Heure de synchronisation invalide."}), 400
    meta_set('ls_client_id', client_id)
    if secret:
        meta_set('ls_client_secret', secret)
    meta_set('ls_redirect_uri', redirect_uri)
    meta_set('ls_balance_sign', sign)
    auto_mode = data.get('auto_mode')
    if auto_mode is None:
        auto_mode = 'daily' if data.get('auto_sync') else 'off'
    if auto_mode not in LS_AUTO_MODES:
        return jsonify({'ok': False, 'error': "Fréquence de synchronisation invalide."}), 400
    meta_set('ls_auto_sync_mode', auto_mode)
    meta_set('ls_auto_sync', '0' if auto_mode == 'off' else '1')
    meta_set('ls_auto_sync_hour', hour)
    disconnected = False
    if old['connected'] and (client_id != old['client_id'] or (secret and secret != old['client_secret'])):
        # Nouvelle application Lightspeed : l'ancienne connexion n'est plus valide.
        meta_delete('ls_refresh_token', 'ls_account_id', 'ls_account_name')
        _ls_token_cache['access_token'] = None
        disconnected = True
    changes = []
    if client_id != old['client_id']:
        changes.append("Client ID modifié")
    if secret:
        changes.append("Client secret modifié")
    if sign != old['balance_sign']:
        changes.append(f"sens du solde : {sign}")
    if auto_mode != old['auto_mode'] or (auto_mode != 'off' and hour != old['auto_sync_hour']):
        changes.append("synchro automatique : " + ls_auto_mode_text(auto_mode, hour))
    log_audit('Paramètres Lightspeed modifiés', "; ".join(changes) or "aucun changement important")
    return jsonify({'ok': True, 'disconnected': disconnected})


@app.route('/lightspeed/connect')
def lightspeed_connect():
    resp = admin_required_check()
    if resp is not None:
        return resp
    cfg = ls_config()
    if not cfg['client_id'] or not cfg['client_secret']:
        return redirect(url_for('admin_settings_page'))
    state = secrets.token_urlsafe(24)
    meta_set('ls_oauth_state', json.dumps({'state': state, 'ts': time.time(),
                                           'username': session.get('username')}))
    params = {'response_type': 'code', 'client_id': cfg['client_id'], 'scope': LS_SCOPE,
              'state': state, 'redirect_uri': cfg['redirect_uri']}
    return redirect(f"{LS_AUTH_BASE}/authorize?" + urllib.parse.urlencode(params))


_LS_CALLBACK_PAGE = """<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Lightspeed — Kubios</title>
<style>body{margin:0;font-family:Segoe UI,Arial,sans-serif;background:#f4f6f8;color:#1f2937}
.box{max-width:520px;margin:60px auto;background:#fff;border:1px solid #e1e5ea;border-radius:10px;padding:24px}
h1{font-size:18px;margin-top:0}.ok{color:#166534}.err{color:#991b1b}a{color:#2563eb}</style></head>
<body><div class="box"><h1 class="{{ cls }}">{{ title }}</h1><p>{{ text }}</p>
<p><a href="{{ url_for('admin_settings_page') }}">Retour à l'administration</a> ·
<a href="{{ url_for('credit_accounts_page') }}">Comptes de crédit</a></p></div></body></html>"""


def _ls_complete_oauth(args):
    """Termine la connexion à partir des paramètres renvoyés par Lightspeed
    (code + state). Retourne (ok, titre, texte, statut HTTP)."""
    try:
        saved = json.loads(meta_get('ls_oauth_state') or '{}')
    except ValueError:
        saved = {}
    state = args.get('state') or ''
    if not saved.get('state') or not secrets.compare_digest(state, saved['state']) \
            or time.time() - float(saved.get('ts') or 0) > 900:
        return (False, "Connexion refusée",
                "La demande de connexion est expirée ou invalide (elle est valide 15 minutes et une seule "
                "fois). Recommence à partir de Administration → Lightspeed → Connecter à Lightspeed.", 400)
    meta_delete('ls_oauth_state')
    username = saved.get('username') or '?'
    if args.get('error'):
        db_add_audit(username, 'Connexion Lightspeed refusée', args.get('error'))
        return (False, "Connexion annulée",
                f"Lightspeed n'a pas autorisé la connexion ({args.get('error')}).", 400)
    code = args.get('code') or ''
    if not code:
        return (False, "Connexion refusée", "Lightspeed n'a pas renvoyé de code d'autorisation.", 400)
    try:
        _ls_token_request({'grant_type': 'authorization_code', 'code': code,
                           'redirect_uri': ls_config()['redirect_uri']})
        account_id, name = ls_fetch_account()
        meta_set('ls_account_id', account_id)
        meta_set('ls_account_name', name)
    except LightspeedError as e:
        db_add_audit(username, 'Connexion Lightspeed échouée', str(e))
        return (False, "Connexion échouée", str(e), 502)
    db_add_audit(username, 'Connexion à Lightspeed', f"Compte « {name} » (#{account_id})")
    return (True, "Kubios est connecté à Lightspeed",
            f"Compte « {name} » (#{account_id}). Tu peux maintenant synchroniser les comptes de "
            "crédit à partir de la page Comptes de crédit.", 200)


@app.route('/api/lightspeed/oauth-paste', methods=['POST'])
def api_ls_oauth_paste():
    """Fin de connexion par copier-coller : l'adresse https:// de retour n'est
    servie par personne, l'utilisateur colle l'adresse complète affichée par
    le navigateur (elle contient code=… et state=…)."""
    resp = admin_required_check()
    if resp is not None:
        return resp
    raw = ((request.get_json(silent=True) or {}).get('url') or '').strip()
    query = urllib.parse.urlparse(raw).query if '://' in raw else raw.lstrip('?')
    args = {k: v[0] for k, v in urllib.parse.parse_qs(query).items()}
    if not args.get('code') and not args.get('error'):
        return jsonify({'ok': False, 'error': "Cette adresse ne contient pas de code d'autorisation. Copie "
                                              "l'adresse complète de la barre d'adresse (elle contient « code= »)."}), 400
    ok, title, text, status = _ls_complete_oauth(args)
    return jsonify({'ok': ok, 'title': title, 'message': text}), (200 if ok else status)


@app.route('/lightspeed/callback')
def lightspeed_oauth_callback():
    """Retour de Lightspeed après autorisation. Exemptée de la connexion à
    Kubios (le navigateur peut revenir sur « localhost » sans le témoin de
    session) : protégée par le jeton « state » à usage unique, valide 15 min."""
    from flask import render_template_string

    def page(ok, title, text, code=200):
        return render_template_string(_LS_CALLBACK_PAGE, cls='ok' if ok else 'err',
                                      title=title, text=text), code

    return page(*_ls_complete_oauth(request.args))


@app.route('/api/lightspeed/disconnect', methods=['POST'])
def api_ls_disconnect():
    resp = admin_required_check()
    if resp is not None:
        return resp
    meta_delete('ls_refresh_token', 'ls_account_id', 'ls_account_name')
    _ls_token_cache['access_token'] = None
    log_audit('Déconnexion de Lightspeed')
    return jsonify({'ok': True})


@app.route('/api/lightspeed/test', methods=['POST'])
def api_ls_test():
    resp = admin_required_check()
    if resp is not None:
        return resp
    try:
        account_id, name = ls_fetch_account()
        meta_set('ls_account_id', account_id)
        meta_set('ls_account_name', name)
        return jsonify({'ok': True, 'account_id': account_id, 'account_name': name})
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 502


@app.route('/api/lightspeed/status')
def api_ls_status():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    return jsonify(_ls_status_payload())


@app.route('/api/lightspeed/sync', methods=['POST'])
def api_ls_sync():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    if not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Kubios n'est pas connecté à Lightspeed "
                                              "(Administration → Lightspeed)."}), 400
    try:
        start_ls_sync_thread(session.get('username'))
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    return jsonify({'ok': True})


@app.route('/api/lightspeed/pending')
def api_ls_pending():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    return jsonify(db_ls_list_pending())


@app.route('/api/lightspeed/pending/<ls_id>/link', methods=['POST'])
def api_ls_link_pending(ls_id):
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}
    client_id = data.get('client_id')
    try:
        client_id = int(client_id) if client_id not in (None, '', 'new') else None
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': "Compte Kubios invalide."}), 400
    if _ls_sync_state['running']:
        return jsonify({'ok': False, 'error': "Une synchronisation est en cours, réessaie dans un instant."}), 409
    try:
        client, action, p = db_ls_link_pending(ls_id, client_id)
    except RuntimeError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    mark_dirty()
    log_audit('Association manuelle Lightspeed',
              f"Compte Lightspeed #{ls_id} ({_credit_client_display_name(p)}) → "
              + ("nouveau compte Kubios" if action == 'created' else f"compte Kubios « {client['display_name']} »"))
    return jsonify({'ok': True, 'action': action, 'client_id': client['id']})


@app.route('/api/sync', methods=['POST'])
def api_sync():
    try:
        export_to_excel()
        log_audit('Synchronisation manuelle vers Excel')
        return jsonify({'ok': True, 'last_sync': meta_get('last_sync')})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/sync/status')
def api_sync_status():
    return jsonify({
        'dirty': meta_get('dirty', '0') == '1',
        'running': _sync_state["running"],
        'last_error': _sync_state["last_error"],
        'last_sync': meta_get('last_sync'),
    })


@app.route('/api/statements/bulk-draft', methods=['POST'])
def api_bulk_draft():
    if get_settings()['send_mode'] == 'smtp':
        return jsonify({'ok': False, 'error':
                         "Le mode brouillon n'est pas disponible en mode d'envoi SMTP "
                         "(pas de fenêtre de relecture) — utilise \"Envoyer directement\"."}), 400
    with _bulk_lock:
        if _bulk_state["running"]:
            return jsonify({'ok': False, 'error': 'Une opération en lot est déjà en cours.'}), 409
        t = threading.Thread(target=_run_bulk, args=('draft_silent', session.get('username')), daemon=True)
        t.start()
    return jsonify({'ok': True})


@app.route('/api/statements/bulk-send', methods=['POST'])
def api_bulk_send():
    with _bulk_lock:
        if _bulk_state["running"]:
            return jsonify({'ok': False, 'error': 'Une opération en lot est déjà en cours.'}), 409
        t = threading.Thread(target=_run_bulk, args=('send', session.get('username')), daemon=True)
        t.start()
    return jsonify({'ok': True})


@app.route('/api/statements/bulk-draft/status')
def api_bulk_draft_status():
    return jsonify(_bulk_state)


def _detect_lan_ip():
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))  # aucune donnée envoyée, juste pour détecter l'interface réseau
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return None


def start_app():
    """Point d'entrée commun : démarrage interactif (start.bat) ET démarrage
    comme service Windows (service.py) appellent cette même fonction, pour
    garantir exactement la même initialisation dans les deux cas."""
    print(f"Fichier Excel utilisé : {EXCEL_PATH}")
    if not EXCEL_PATH.exists():
        # Nouvelle installation (aucune donnée existante) : on part d'un
        # classeur vierge plutôt que de bloquer le démarrage.
        create_blank_excel_template(EXCEL_PATH)
    ensure_db_ready()
    app.secret_key = get_or_create_secret_key()
    app.config['PERMANENT_SESSION_LIFETIME'] = datetime.timedelta(days=30)
    ensure_admin_bootstrap()
    t = threading.Thread(target=_auto_sync_loop, daemon=True)
    t.start()
    threading.Thread(target=_net_time_loop, daemon=True).start()
    threading.Thread(target=_ls_auto_sync_loop, daemon=True).start()
    threading.Thread(target=_nightly_loop, daemon=True).start()
    threading.Thread(target=_full_backup_loop, daemon=True).start()
    threading.Thread(target=_inventory_loop, daemon=True).start()
    threading.Thread(target=_atelier_reread_loop, daemon=True).start()
    threading.Thread(target=_ht_drop_loop, daemon=True).start()
    ensure_three_vendor_async()

    print()
    print("=" * 60)
    print(f"Accès depuis CET ordinateur :  http://127.0.0.1:{APP_PORT}")
    lan_ip = _detect_lan_ip()
    if lan_ip:
        print(f"Accès depuis un AUTRE ordinateur du même réseau :")
        print(f"    http://{lan_ip}:{APP_PORT}")
        print("(Windows peut demander une autorisation de pare-feu la")
        print(" première fois — accepte pour le réseau 'Privé'.)")
    print("=" * 60)
    print()

    # Serveur de production (Waitress) au lieu du serveur de développement
    # Flask — celui-ci n'est pas conçu pour tourner sans surveillance en
    # tant que service et affiche un avertissement à cet effet.
    from waitress import serve
    serve(app, host='0.0.0.0', port=APP_PORT, threads=8)


if __name__ == '__main__':
    start_app()
