# -*- coding: utf-8 -*-
"""
App locale de gestion des Comptes à recevoir.

Architecture (v2 — rapide) :
- Une base SQLite locale (data.db) est la source de données pour l'app :
  toutes les lectures/écritures (ajout de facture, nouveau client) sont
  quasi instantanées.
- Le fichier "Compte à recevoir.xlsx" reste le document "officiel" que tu
  peux ouvrir dans Excel — il est régénéré à partir de la base SQLite,
  soit automatiquement en arrière-plan (toutes les quelques minutes),
  soit à la demande (bouton "Synchroniser vers Excel").
- Au tout premier démarrage, toutes les données de l'Excel existant sont
  importées une seule fois dans la base (ça prend ~30s la première fois
  seulement). Ensuite, tout est instantané.

IMPORTANT : une fois l'app utilisée, la base SQLite devient la référence.
Si tu modifies le fichier Excel à la main entre deux synchronisations, ces
changements seront écrasés à la prochaine synchronisation. Fais tes
changements dans l'app plutôt que dans Excel.

Démarrage : double-cliquer sur start.bat (voir README.txt)
"""
import os
import re
import io
import csv
import sys
import json
import base64
import hashlib
import unicodedata
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path

from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash

import openpyxl
from openpyxl.utils import get_column_letter

import licensing

# ---------- Tronc commun (1.45.0) : modules séparés, mêmes noms qu'avant ----------
from kubios_base import DB_PATH, _at_now, client_ip, db_add_audit, get_company_name, get_conn, meta_get, meta_set
from kubios_pdf import REPORT_DISCLAIMER, REPORT_DISCLAIMER_TITLE
from kubios_license import _net_time, _net_time_lock, get_license_status, license_module_active
from kubios_sessions import _session_registry, sess_close, sess_open
from kubios_version import APP_NAME, APP_VERSION
from kubios_app import APP_DIR, BASE_DIR, app
from kubios_auth import PERMISSION_KEYS, current_display_name, permission_required_check
from kubios_systeme import (
    ANN_COLORS, VERSIONS_DIR, VERSIONS_KEEP, db_create_user, db_get_user, db_get_user_by_username,
    db_list_users, db_set_user_mfa, db_user_security, login_bg_mode, login_bg_url, login_video_url,
)
from kubios_rh_outils import PDF_DIR, _MOIS_FR
from kubios_lightspeed import (
    APP_PORT, LightspeedError, _ls_as_list, _ls_get_all, _ls_ref_cache, _ls_sync_state,
    _rep_line_values, _store_lock, _store_state, _truthy, ls_config, ls_fetch_account, store_sync_days,
)
from kubios_outils import ensure_three_vendor_async
from kubios_atelier import AT_REREAD_HOUR, HT_DROP_DIR, at_reread_cfg, ht_apply, ht_parse, ht_plan
from kubios_comptes import (
    BACKUP_DIR, EXCEL_PATH, INFO_ROWS, LOG_SHEET, MODELE_SHEET, SOMMAIRE_SHEET, _sync_state,
    export_to_excel, safe_sheet_name,
)
from kubios_rapports import (
    REP_MISC, REP_NO_CATEGORY, _inv_state, _rep_state, ar_allowed, inv_cfg, meta_delete,
    nightly_reports_run, send_inventory_email, start_inventory_job, store_cfg,
)
from kubios_lightspeed_pages import run_ls_sync
from kubios_sauvegardes import _send_plain_email, fb_cfg, fb_notify, full_backup, init_db_schema
# Modules de pages et d'outils : les importer enregistre leurs pages dans Kubios (ne pas retirer).
import kubios_base
import kubios_mail
import kubios_pdf
import kubios_license
import kubios_sessions
import kubios_version
import kubios_app
import kubios_auth
import kubios_systeme
import kubios_atelier_outils
import kubios_rh_outils
import kubios_rh
import kubios_temps
import kubios_portail
import kubios_lightspeed
import kubios_outils
import kubios_atelier
import kubios_comptes
import kubios_credit
import kubios_rapports
import kubios_lightspeed_pages
import kubios_sauvegardes
import kubios_sante
from kubios_sante import start_health_monitor


# ============================================================
# CONFIGURATION
# ============================================================
PDF_DIR.mkdir(exist_ok=True)


AUTO_SYNC_SECONDS = 180  # synchronise automatiquement vers Excel toutes les 3 minutes s'il y a des changements

# Valeurs par défaut (utilisées tant que rien n'a été personnalisé depuis le
# module Administration). Les valeurs effectives sont lues dynamiquement via
# les fonctions get_company_name()/get_company_email()/... ci-dessous, qui
# consultent d'abord la table `meta` (personnalisation admin) avant de
# retomber sur ces constantes.

# Image de fond de la page de connexion (1.11.1). L'image par défaut est livrée
# avec les mises à jour ; une photo personnalisée est gardée sous un autre nom
# (login_bg_custom.*) pour qu'une mise à jour ne l'écrase jamais.
























# Nom du LOGICIEL lui-même (affiché sur l'écran de connexion) — distinct du
# nom de l'entreprise (personnalisable via le module Administration) qui
# reste utilisé pour les états de compte, courriels et documents envoyés
# aux clients.

# ============================================================
# Version du logiciel et historique des changements
# ------------------------------------------------------------
# À chaque modification livrée, on ajoute une nouvelle entrée en haut de
# CHANGELOG et on augmente APP_VERSION. La page "Mises à jour" (admin)
# affiche cette liste — c'est la source de vérité pour savoir ce qui a
# changé et à quelle version l'application installée correspond.
# ============================================================


# URL publique (dépôt GitHub géré par Claude) où est déposé, à chaque mise à
# jour livrée, un petit fichier version.json contenant le numéro de version
# le plus récent et son changelog. Ne contient aucune donnée d'entreprise.


# ------------------------------------------------------------
# Installation automatique des mises à jour
# ------------------------------------------------------------
# APP_DIR = C:\DBouxpCR\app (contient app.py, templates, static — remplacé
# par une mise à jour). BASE_DIR = C:\DBouxpCR (contient aussi les données
# du client : data.db, le fichier Excel, les PDF — jamais touchées).
UPDATE_LOG_PATH = BASE_DIR / "_update_log.txt"



# Script exécuté dans un processus séparé, après que ce processus-ci se soit
# terminé (pour ne jamais copier par-dessus des fichiers encore ouverts). Il
# copie uniquement le CODE (jamais data.db, les .xlsx, service.log,
# __pycache__, .venv), réinstalle les dépendances, puis relance l'app —
# comme service Windows si celui-ci est installé, sinon en rouvrant
# start.bat dans une nouvelle fenêtre.







AR_PATH_PREFIXES = ('/comptes-a-recevoir', '/api/client', '/api/invoice', '/api/ar-backups', '/api/lightspeed/ar/',
                    '/api/statements/', '/api/sync', '/api/reports/aging', '/api/reports/envois', '/api/reports/monthly')




# ---------- 1.43.0 : registre des sessions (utilisateurs en ligne, déconnexion à distance)








app.before_request(_session_registry)   # (fonction dans kubios_sessions.py ; même ordre qu'avant)


@app.before_request
def _ar_permission():
    """Comptes à recevoir réservés aux utilisateurs qui en ont la permission (1.23.0)."""
    if not session.get('user_id') or not request.path.startswith(AR_PATH_PREFIXES) or ar_allowed():
        return None
    if request.path.startswith('/api/'):
        return jsonify({'error': 'forbidden', 'message': "Accès réservé : permission « Comptes à recevoir » requise."}), 403
    return "Accès refusé — permission « Comptes à recevoir » requise.", 403


@app.before_request
def _require_login():
    resp = license_required_check()
    if resp is not None:
        return resp
    resp = login_required_check()
    if resp is not None:
        return resp


# ============================================================
# Base SQLite (source rapide de vérité)
# ============================================================












# ============================================================
# Utilisateurs / connexion
# ============================================================
# Accès granulaires pouvant être accordés à un utilisateur non-administrateur.
# La gestion des utilisateurs elle-même (page "Utilisateurs") reste toujours
# réservée aux administrateurs, pour qu'un compte non-admin ne puisse jamais
# se donner (ou donner à quelqu'un d'autre) davantage de droits.


















def db_verify_login(username, password):
    user = db_get_user_by_username((username or '').strip())
    if not user or not user['active']:
        return None
    if not check_password_hash(user['password_hash'], password or ''):
        return None
    return user


def ensure_admin_bootstrap():
    """Crée un compte admin par défaut au tout premier démarrage si aucun utilisateur n'existe."""
    if db_list_users():
        return
    temp_password = secrets.token_urlsafe(9)
    db_create_user('admin', temp_password, is_admin=True)
    print()
    print("=" * 60)
    print("PREMIER DÉMARRAGE — COMPTE ADMINISTRATEUR CRÉÉ")
    print(f"  Nom d'utilisateur : admin")
    print(f"  Mot de passe      : {temp_password}")
    print("Note ce mot de passe maintenant — il ne sera plus réaffiché.")
    print("Connecte-toi puis crée les autres comptes depuis 'Utilisateurs'.")
    print("=" * 60)
    print()


def get_or_create_secret_key():
    key = meta_get('secret_key')
    if not key:
        key = secrets.token_hex(32)
        meta_set('secret_key', key)
    return key


def current_user():
    uid = session.get('user_id')
    if not uid:
        return None
    return db_get_user(uid)


def login_required_check():
    """Retourne une réponse (redirect/JSON 401) si non connecté, sinon None."""
    if request.endpoint in ('login', 'static', 'lightspeed_oauth_callback') + AUTH_PUBLIC_ENDPOINTS \
            or request.endpoint in LICENSE_EXEMPT_ENDPOINTS \
            or request.path.startswith('/static/'):
        return None
    if not session.get('user_id'):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'auth_required'}), 401
        return redirect(url_for('login', next=request.path))
    return None






# ============================================================
# Licence logicielle (30 jours / 1 an / à vie)
# ============================================================
# Seul "license_code" (le code brut collé par le client) est gardé en mémoire.
# Tout le reste (licencié, type, date d'expiration) est re-dérivé à chaque
# vérification à partir de ce code — jamais lu directement d'un champ séparé
# qui pourrait être modifié sans repasser par la signature.
LICENSE_EXEMPT_ENDPOINTS = ('activation_page', 'api_license_activate', 'api_license_status', 'static')


# ------------------------------------------------------------
# Horloge de confiance pour l'expiration des licences
# ------------------------------------------------------------
# Se fier uniquement à datetime.date.today() permettrait de prolonger une
# licence expirée en reculant la date de Windows. On combine donc :
#   1) la date réelle obtenue sur Internet (en-tête HTTP "Date" d'un grand
#      site), rafraîchie au démarrage puis toutes les 6 heures, et prolongée
#      entre deux vérifications avec une horloge monotone (insensible aux
#      changements de date de Windows);
#   2) la date la plus récente déjà vue par l'app ("high-water mark"),
#      gardée dans la table meta — sert de référence quand Internet n'est
#      pas disponible.
# Si la date de l'ordinateur est en retard de plus de CLOCK_TOLERANCE_DAYS
# sur la référence, l'horloge est considérée comme reculée et une licence à
# durée limitée est bloquée. Les licences à vie ne sont jamais concernées.
NET_TIME_URLS = (
    "https://raw.githubusercontent.com/",
    "https://www.google.com/",
    "https://www.microsoft.com/",
)
NET_TIME_REFRESH_SECONDS = 6 * 3600      # rafraîchissement normal
NET_TIME_RETRY_SECONDS = 15 * 60         # nouvel essai si Internet indisponible



def _fetch_internet_utc():
    """Retourne la date/heure UTC lue dans l'en-tête HTTP "Date" du premier
    site qui répond, ou None si aucun n'est joignable."""
    for url in NET_TIME_URLS:
        header = None
        try:
            req = urllib.request.Request(url, method='HEAD', headers={'Cache-Control': 'no-cache'})
            with urllib.request.urlopen(req, timeout=5) as r:
                header = r.headers.get('Date')
        except urllib.error.HTTPError as e:
            # Même une réponse d'erreur (403, 405...) porte un en-tête Date fiable.
            header = e.headers.get('Date') if e.headers else None
        except Exception:
            continue
        if not header:
            continue
        try:
            dt = email.utils.parsedate_to_datetime(header)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=datetime.timezone.utc)
            return dt.astimezone(datetime.timezone.utc)
        except Exception:
            continue
    return None


def refresh_internet_time():
    dt = _fetch_internet_utc()
    if dt is not None:
        with _net_time_lock:
            _net_time['utc'] = dt
            _net_time['mono'] = time.monotonic()
    return dt














def _net_time_loop():
    while True:
        try:
            ok = refresh_internet_time() is not None
        except Exception:
            ok = False
        time.sleep(NET_TIME_REFRESH_SECONDS if ok else NET_TIME_RETRY_SECONDS)






# Endpoints de chaque module (préfixes des fonctions Flask)
MODULE_ENDPOINTS = {'atelier': ('atelier_', 'api_atelier'), 'rh': ('hr_', 'api_hr', 'emp_', 'api_emp', 'tc_', 'api_tc', 'sched_', 'api_sched', 'leave_', 'api_leave')}


def endpoint_module(endpoint):
    for key, prefixes in MODULE_ENDPOINTS.items():
        if endpoint and endpoint.startswith(prefixes):
            return key
    return None








def license_required_check():
    """Retourne une réponse (redirect/JSON 402) si aucune licence active,
    sinon None. Bloque TOUT (même la page de connexion) tant qu'aucune
    licence valide et non expirée n'est active — seule la page d'activation
    elle-même et son API restent accessibles."""
    if request.endpoint in LICENSE_EXEMPT_ENDPOINTS or request.path.startswith('/static/'):
        return None
    status = get_license_status()
    if not status['active']:
        if request.path.startswith('/api/'):
            return jsonify({'error': 'license_required', 'reason': status['reason']}), 402
        return redirect(url_for('activation_page'))
    mod = endpoint_module(request.endpoint)          # 1.38.0 : modules vendus séparément
    if mod and not license_module_active(mod):
        m = status['modules'].get(mod, {})
        why = 'expiré' if m.get('included') else 'non inclus'
        if request.path.startswith('/api/'):
            return jsonify({'error': 'module_required', 'module': mod,
                            'message': f"Le module « {licensing.MODULES[mod]} » est {why} dans la licence."}), 402
        return render_template('module_locked.html', company=get_company_name(), module=licensing.MODULES[mod], info=m, module_key=mod,
                               can_license=bool(session.get('is_admin')) or 'license' in (session.get('permissions') or [])), 402
    return None


# ============================================================
# Journal d'audit (visible uniquement par les administrateurs)
# ============================================================








# ============================================================
# Paramètres d'envoi (Outlook ou serveur SMTP) — configurables par un admin
# ============================================================




































# ============================================================
# Import unique depuis Excel -> SQLite (au tout premier démarrage)
# ============================================================


def read_client_info_ws(ws):
    def cell(r, c):
        return ws.cell(row=r, column=c).value
    return {
        'phone': cell(2, 2) or '',
        'adresse': cell(INFO_ROWS['adresse'], 2) or '',
        'ville': cell(INFO_ROWS['ville'], 2) or '',
        'province': cell(INFO_ROWS['province'], 2) or '',
        'code_postal': cell(INFO_ROWS['code_postal'], 2) or '',
        'courriel': cell(INFO_ROWS['courriel'], 2) or '',
    }


def read_invoices_ws(ws):
    invoices = []
    r = 2
    max_row = ws.max_row
    while r <= max_row:
        num = ws.cell(row=r, column=3).value
        date_f = ws.cell(row=r, column=4).value
        echeance = ws.cell(row=r, column=5).value
        montant = ws.cell(row=r, column=6).value
        notes = ws.cell(row=r, column=11).value
        if num is not None and montant is not None:
            due = echeance.date() if isinstance(echeance, datetime.datetime) else echeance
            df = date_f.date() if isinstance(date_f, datetime.datetime) else date_f
            invoices.append({
                'numero': str(num),
                'date_facture': df.strftime('%Y-%m-%d') if isinstance(df, datetime.date) else (str(df) if df else ''),
                'echeance': due.strftime('%Y-%m-%d') if isinstance(due, datetime.date) else (str(due) if due else ''),
                'montant': float(montant),
                'notes': notes or '',
            })
        r += 1
    return invoices


def import_excel_into_db():
    """Importe une seule fois toutes les données de l'Excel existant dans la base SQLite."""
    print("Premier démarrage : import des données depuis Excel (peut prendre ~30s)...")
    wb = openpyxl.load_workbook(EXCEL_PATH, data_only=False)
    sommaire = wb[SOMMAIRE_SHEET]

    conn = get_conn()
    r = 3
    n_clients = 0
    n_invoices = 0
    used_sheet_names = set()
    while sommaire.cell(row=r, column=1).value is not None:
        name = sommaire.cell(row=r, column=1).value
        # Le nom d'onglet réel peut différer d'une simple troncature du nom du
        # client (deux clients peuvent tronquer sur le même nom) — on lit donc
        # le vrai nom d'onglet directement dans la formule existante du Sommaire.
        formula = sommaire.cell(row=r, column=2).value  # ex: ="'SheetName'!G2"
        sheet_name = None
        if isinstance(formula, str):
            m = re.match(r"^='([^']+)'!", formula)
            if m:
                sheet_name = m.group(1)
        if not sheet_name:
            sheet_name = safe_sheet_name(name)
        ws = wb[sheet_name] if sheet_name in wb.sheetnames else None
        if ws is not None and sheet_name in used_sheet_names:
            # collision improbable — on ne devrait jamais arriver ici puisqu'on lit
            # le vrai nom d'onglet, mais on se protège quand même
            ws = None
        if ws is not None:
            used_sheet_names.add(sheet_name)
            info = read_client_info_ws(ws)
            conn.execute(
                "INSERT OR REPLACE INTO clients(name, sheet_name, phone, adresse, ville, province, code_postal, courriel) "
                "VALUES (?,?,?,?,?,?,?,?)",
                (name, sheet_name, info['phone'], info['adresse'], info['ville'], info['province'],
                 info['code_postal'], info['courriel'])
            )
            n_clients += 1
            for inv in read_invoices_ws(ws):
                if inv['montant'] == 0 and not inv['numero']:
                    continue
                conn.execute(
                    "INSERT INTO invoices(client_name, numero, date_facture, echeance, montant, notes) VALUES (?,?,?,?,?,?)",
                    (name, inv['numero'], inv['date_facture'], inv['echeance'], inv['montant'], inv['notes'])
                )
                n_invoices += 1
        r += 1

    counter_cell = sommaire.cell(row=2, column=13).value  # M2 : dernier numéro d'état de compte
    try:
        counter_val = int(counter_cell or 0)
    except (TypeError, ValueError):
        counter_val = 0
    conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('statement_counter', ?)", (str(counter_val),))
    conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('dirty', '0')")
    conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('last_sync', ?)",
                 (datetime.datetime.now().isoformat(),))
    conn.commit()
    conn.close()
    print(f"Import terminé : {n_clients} clients, {n_invoices} factures.")


def create_blank_excel_template(path):
    """Crée un classeur Excel neuf (aucun client) avec la structure minimale
    attendue par l'app : onglets Modèle / Sommaire / LOG_ENVOIS. Utilisé au
    tout premier démarrage sur un ordinateur qui n'a jamais eu de fichier
    Excel (nouvelle installation) — toutes les formules et le contenu réel
    de chaque onglet client sont de toute façon régénérés à partir de la
    base SQLite à chaque synchronisation (write_client_sheet/export_to_excel),
    donc ce modèle n'a besoin que d'exister, pas d'être élaboré."""
    wb = openpyxl.Workbook()
    modele = wb.active
    modele.title = MODELE_SHEET
    modele.cell(row=1, column=1, value='Client')
    modele.cell(row=1, column=2, value='Numéro de téléphone')
    modele.cell(row=1, column=3, value='Numéro de facture')
    modele.cell(row=1, column=4, value='Date de facture ')
    modele.cell(row=1, column=5, value='Échéance ')
    modele.cell(row=1, column=6, value='Montant')
    modele.cell(row=1, column=7, value='0-30 jours')
    modele.cell(row=1, column=8, value='31-60 jours')
    modele.cell(row=1, column=9, value='61-90 jours')
    modele.cell(row=1, column=10, value='90+ jours')
    modele.cell(row=1, column=11, value='Notes / Suivi')
    modele.cell(row=1, column=12, value='Payé')
    modele.cell(row=1, column=13, value='Solde')

    sommaire = wb.create_sheet(SOMMAIRE_SHEET)
    sommaire.cell(row=1, column=1, value='Client')
    sommaire.cell(row=1, column=2, value='0-30 jours')
    sommaire.cell(row=1, column=3, value='31-60 jours')
    sommaire.cell(row=1, column=4, value='61-90 jours')
    sommaire.cell(row=1, column=5, value='90+ jours')
    sommaire.cell(row=1, column=6, value='Total')
    sommaire.cell(row=1, column=7, value='Vérfication')
    sommaire.cell(row=2, column=1, value='Sommaire')
    # Ligne 2 (sommes) et lignes clients (3+) sont vides ici : elles sont
    # entièrement régénérées par export_to_excel() dès la première synchronisation.

    log_ws = wb.create_sheet(LOG_SHEET)
    log_ws.cell(row=1, column=1, value='Date')
    log_ws.cell(row=1, column=2, value='Client')
    log_ws.cell(row=1, column=3, value='Courriel')
    log_ws.cell(row=1, column=4, value='Total')
    log_ws.cell(row=1, column=5, value='Statut')
    log_ws.cell(row=1, column=6, value='Note')

    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
    print(f"Nouveau classeur Excel créé (installation neuve) : {path}")


def ensure_db_ready():
    is_new = not DB_PATH.exists()
    init_db_schema()
    if is_new:
        import_excel_into_db()


# ============================================================
# Aging (tranches d'âge) — logique identique aux formules du classeur
# ============================================================






# ============================================================
# Accès aux données (rapide, SQLite)
# ============================================================






































# ============================================================
# Comptes de crédit (Lightspeed) — volet distinct des comptes à recevoir.
# Liste de clients avec limite de crédit / solde dû / dépôt, alimentée par un
# import initial (Excel/CSV) puis, chaque mois, par un import des mouvements
# (transactions) exportés de Lightspeed, qui met à jour les soldes.
# ============================================================






































# ============================================================
# Sauvegardes des comptes de crédit avant chaque importation (1.10.1)
# ------------------------------------------------------------
# Avant une réinitialisation, un import de mouvements ou une synchronisation
# Lightspeed, les tables des comptes de crédit sont copiées dans un petit
# fichier SQLite (C:\DBouxpCR\Backups_comptes_credit). Un administrateur peut
# ensuite remettre les comptes exactement comme avant. Les comptes à recevoir
# (factures) ne sont jamais touchés par une restauration.
# ============================================================

# 1.11.0 : même mécanisme pour les comptes à recevoir (clients + factures).
# Table credit_backups, colonne scope : 'credit' ou 'ar'. Pour 'ar',
# movement_count = nombre de factures, total_solde = solde total à recevoir.
















# ============================================================
# Lightspeed R-Series — connexion à l'API et synchronisation des comptes de
# crédit (1.10.0). Remplace l'export manuel « credit_account_listings » : Kubios
# lit directement les comptes de crédit (CreditAccount) et leurs clients
# (Customer) dans Lightspeed, puis met à jour limite / montant dû / dépôt.
# Chaque compte Kubios est relié à son compte Lightspeed par son identifiant
# (credit_clients.ls_credit_account_id) — les homonymes ne se mélangent plus.
# Les jetons et le secret sont gardés dans la table meta (comme le mot de
# passe SMTP).
# ============================================================
LS_AUTO_CHECK_SECONDS = 300

























































def _is_last_day_of_month(d):
    return (d + datetime.timedelta(days=1)).month != d.month


def _ls_auto_sync_loop():
    """Synchronisation automatique (Administration → Lightspeed) : chaque jour
    ou seulement le dernier jour du mois, à partir de l'heure choisie. Une
    seule synchronisation par jour ; un échec n'est pas retenté le même jour
    (il est affiché dans la page Comptes de crédit). Kubios doit être en
    marche à cette heure-là : une synchro de fin de mois manquée n'est pas
    rattrapée le lendemain (les soldes ne seraient plus ceux du mois)."""
    while True:
        time.sleep(LS_AUTO_CHECK_SECONDS)
        try:
            cfg = ls_config()
            if not cfg['auto_sync'] or not cfg['connected'] or _ls_sync_state['running']:
                continue
            now = datetime.datetime.now()
            today = now.strftime('%Y-%m-%d')
            if now.hour < cfg['auto_sync_hour'] or meta_get('ls_last_auto_sync_date') == today:
                continue
            month_end = cfg['auto_mode'] == 'month_end'
            if month_end and not _is_last_day_of_month(now.date()):
                continue
            meta_set('ls_last_auto_sync_date', today)
            run_ls_sync('Synchronisation automatique', auto=True, month_end=month_end)
        except Exception as e:
            print("Synchronisation Lightspeed automatique :", e)


# ============================================================
# Comptes à recevoir — factures Lightspeed (1.11.0)
# ------------------------------------------------------------
# « Vérifier » lit dans Lightspeed les ventes portées au compte de crédit
# d'un client depuis une date, puis montre celles qui ne sont pas encore dans
# Kubios (comparaison par numéro de vente). Rien n'est inscrit sans
# confirmation ; une sauvegarde des comptes à recevoir est prise juste avant.
#  - montant de la facture = partie de la vente portée au compte ;
#  - retour porté au compte (vente négative) = note de crédit (montant < 0) ;
#  - paiement sur compte (total de vente ≈ 0, compte crédité) = simple rappel :
#    Lightspeed ne relie pas un paiement à une facture précise.
# Le lien client Lightspeed -> client Kubios est gardé dans ls_ar_customers.
# ============================================================






























# ============================================================
# Rapports personnalisés (1.12.0) — « Ventes par catégorie d'articles »
# ------------------------------------------------------------
# L'API R-Series ne fournit pas les rapports de Lightspeed tout faits : on lit
# les ventes complétées de la période avec leurs lignes et l'article de chaque
# ligne, puis on regroupe par catégorie, avec la même logique que le rapport
# « Ventes par catégorie » de Lightspeed :
#   sous-total = prix × quantité, avant rabais et avant taxes ;
#   rabais     = rabais de ligne + part du rabais de la vente ;
#   total      = sous-total − rabais (revenu réel, avant taxes) ;
#   coût       = coût unitaire FIFO (sinon coût moyen) × quantité ;
#   profit     = total − coût ; marge = profit / total.
# Les retours ont une quantité négative et réduisent donc les totaux.
# ============================================================
_rep_lock = threading.Lock()


def _ls_cached(key, loader, ttl=1800):
    hit = _ls_ref_cache.get(key)
    if hit and time.time() - hit[0] < ttl:
        return hit[1]
    data = loader()
    _ls_ref_cache[key] = (time.time(), data)
    return data


def ls_fetch_categories(account_id, state=None):
    def load():
        out = {}
        for c in _ls_get_all(account_id, 'Category', {}, 'Catégories', state=state):
            cid = str(c.get('categoryID') or '').strip()
            if cid:
                name = (c.get('name') or '').strip() or f"Catégorie {cid}"
                out[cid] = {'name': name, 'path': (c.get('fullPathName') or '').strip() or name}
        return out
    return _ls_cached(('categories', account_id), load)


def ls_fetch_shops(account_id):
    def load():
        return [{'id': str(s.get('shopID')), 'name': (s.get('name') or '').strip() or f"Magasin {s.get('shopID')}"}
                for s in _ls_get_all(account_id, 'Shop', {}, 'Magasins') if not _truthy(s.get('archived'))]
    return _ls_cached(('shops', account_id), load)






def build_sales_by_category(start, end, shop_id, level, username):
    """start / end : dates (incluses). level : 'full' (catégorie complète) ou
    'top' (catégorie principale seulement)."""
    st = _rep_state
    cfg = ls_config()
    account_id = cfg['account_id']
    if not account_id:
        account_id, name = ls_fetch_account()
        meta_set('ls_account_id', account_id)
        meta_set('ls_account_name', name)
    cats = ls_fetch_categories(account_id, state=st)
    t0 = datetime.datetime.combine(start, datetime.time()).astimezone()
    t1 = datetime.datetime.combine(end + datetime.timedelta(days=1), datetime.time()).astimezone()
    params = {'completed': 'true',
              'completeTime': f"><,{t0.isoformat(timespec='seconds')},{t1.isoformat(timespec='seconds')}",
              'load_relations': json.dumps(['SaleLines', 'SaleLines.Item'])}
    if shop_id:
        params['shopID'] = shop_id
    sales = _ls_get_all(account_id, 'Sale', params, 'Ventes', state=st)
    st['progress'] = "Calcul du rapport…"

    agg = {}
    n_sales = n_lines = 0
    for s in sales:
        if _truthy(s.get('voided')):
            continue
        n_sales += 1
        for ln in _ls_as_list((s.get('SaleLines') or {}).get('SaleLine')):
            item = ln.get('Item') or {}
            item_id = str(ln.get('itemID') or item.get('itemID') or '0').strip()
            if item_id in ('', '0'):
                key = REP_MISC
            else:
                cat = cats.get(str(item.get('categoryID') or '0').strip())
                if cat is None:
                    key = REP_NO_CATEGORY
                else:
                    key = cat['path'].split('/')[0].strip() if level == 'top' else cat['path']
            qty, sub, disc, tot, cost = _rep_line_values(ln)
            a = agg.setdefault(key, {'categorie': key, 'quantite': 0.0, 'sous_total': 0.0, 'rabais': 0.0,
                                     'total': 0.0, 'cout': 0.0, 'lignes': 0})
            a['quantite'] += qty
            a['sous_total'] += sub
            a['rabais'] += disc
            a['total'] += tot
            a['cout'] += cost
            a['lignes'] += 1
            n_lines += 1

    rows = sorted(agg.values(), key=lambda r: -r['total'])
    grand = {k: round(sum(r[k] for r in rows), 2) for k in ('quantite', 'sous_total', 'rabais', 'total', 'cout')}
    grand['lignes'] = n_lines
    for r in rows + [grand]:
        for k in ('quantite', 'sous_total', 'rabais', 'total', 'cout'):
            r[k] = round(r[k], 2)
        r['profit'] = round(r['total'] - r['cout'], 2)
        r['marge'] = round(r['profit'] / r['total'] * 100, 1) if abs(r['total']) >= 0.005 else None
        r['part'] = round(r['total'] / grand['total'] * 100, 1) if abs(grand['total']) >= 0.005 else None
    shop_name = ''
    if shop_id:
        shop_name = next((s['name'] for s in ls_fetch_shops(account_id) if s['id'] == str(shop_id)), f"#{shop_id}")
    return {
        'report': 'ventes_par_categorie', 'title': "Ventes par catégorie d'articles",
        'start': start.isoformat(), 'end': end.isoformat(), 'shop_id': shop_id or '', 'shop_name': shop_name,
        'level': level, 'rows': rows, 'totals': grand, 'sales_count': n_sales,
        'generated_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'by': username,
    }


def start_sales_by_category(start, end, shop_id, level, username):
    if not _rep_lock.acquire(blocking=False):
        raise LightspeedError("Un rapport est déjà en cours de préparation.")
    st = _rep_state
    st.update(running=True, progress="Connexion à Lightspeed…", error=None, result=None, by=username)

    def _run():
        try:
            st['result'] = build_sales_by_category(start, end, shop_id, level, username)
        except Exception as e:
            if not isinstance(e, LightspeedError):
                traceback.print_exc()
            st['error'] = str(e) if isinstance(e, LightspeedError) else f"Erreur inattendue : {e}"
        finally:
            st['running'] = False
            st['progress'] = ''
            _rep_lock.release()

    threading.Thread(target=_run, daemon=True).start()




REP_COLUMNS = (('categorie', 'Catégorie'), ('quantite', 'Qté'), ('sous_total', 'Sous-total'),
               ('rabais', 'Rabais'), ('total', 'Total'), ('cout', 'Coût'), ('profit', 'Profit'),
               ('marge', 'Marge'), ('part', '% des ventes'))






# ============================================================
# Ventes gardées localement + rapports automatiques (1.13.0)
# ------------------------------------------------------------
# Les lignes de vente de Lightspeed sont copiées dans la base Kubios
# (sales_lines), jour par jour (sales_days). Chaque nuit (1 h par défaut) :
# les 7 derniers jours sont relus (retours, annulations), l'historique
# manquant depuis la date de départ est complété, puis le rapport de la
# veille est envoyé aux gestionnaires ; le lundi (ou au premier passage
# suivant), le comparatif de la semaine passée avec la même semaine de
# l'année précédente (52 semaines plus tôt, mêmes jours) est envoyé aussi.
# ============================================================


















# ---------- calcul des rapports à partir de la base locale ----------


















# ---------- envois par courriel ----------




# ---------- envoi immédiat des rapports automatiques (1.24.1) ----------






# ---------- tâche de nuit ----------


def _nightly_loop():
    while True:
        time.sleep(LS_AUTO_CHECK_SECONDS)
        try:
            cfg = store_cfg()
            if not cfg['enabled'] or not ls_config()['connected']:
                continue
            now = datetime.datetime.now()
            if now.hour < cfg['hour'] or meta_get('rep_nightly_date') == now.date().isoformat():
                continue
            meta_set('rep_nightly_date', now.date().isoformat())
            nightly_reports_run()
        except Exception as e:
            traceback.print_exc()
            print("Tâche de nuit des rapports :", e)


# ============================================================
# Sécurité des comptes (1.14.0) : mot de passe oublié + double authentification
# ------------------------------------------------------------
# - Mot de passe oublié : lien envoyé au courriel de l'utilisateur, valide 1 h,
#   une seule fois (seul le hachage du jeton est gardé). La page ne dit jamais
#   si le compte existe. Réinitialiser le mot de passe ne contourne pas la 2FA.
# - 2FA, exigée utilisateur par utilisateur par un administrateur. L'utilisateur
#   choisit sa méthode à la première connexion : application (TOTP, RFC 6238 :
#   Google / Microsoft Authenticator) ou code de 6 chiffres par courriel.
# ============================================================
RESET_TOKEN_TTL = 3600
RESET_MAX_PER_HOUR = 3
MFA_PENDING_TTL = 600
MFA_EMAIL_CODE_TTL = 600
MFA_MAX_ATTEMPTS = 5
MFA_LOCK_SECONDS = 900
PASSWORD_MIN_LEN = 8


def _sha256(t):
    import hashlib
    return hashlib.sha256(t.encode('utf-8')).hexdigest()




def _mask_email(e):
    if not e or '@' not in e:
        return ''
    name, dom = e.split('@', 1)
    return (name[:2] + '•' * max(1, len(name) - 2)) + '@' + dom


# ---------- TOTP (application d'authentification) ----------
def _b32_secret():
    import base64
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip('=')


def _totp_at(secret, step):
    import base64, hmac, hashlib, struct
    key = base64.b32decode(secret + '=' * (-len(secret) % 8))
    h = hmac.new(key, struct.pack('>Q', step), hashlib.sha1).digest()
    o = h[-1] & 0x0F
    return f"{(struct.unpack('>I', h[o:o + 4])[0] & 0x7FFFFFFF) % 1000000:06d}"


def totp_check(secret, code, last_step=0):
    """Retourne le pas de temps accepté (±30 s de tolérance), ou None. Un code
    déjà utilisé (pas <= last_step) est refusé."""
    code = re.sub(r'\D', '', code or '')
    if len(code) != 6 or not secret:
        return None
    now = int(time.time() // 30)
    if (last_step or 0) > now + 2:        # 1.34.1 : l'horloge du PC a reculé (corrigée) — ne pas bloquer tous les codes
        last_step = 0
    for d in (0, -1, 1, -2, 2):           # ±60 s de tolérance
        s = now + d
        if s > (last_step or 0) and secrets.compare_digest(_totp_at(secret, s), code):
            return s
    return None


def totp_diagnose(secret, code, last_step=0):
    """Code refusé : explique pourquoi (déjà utilisé, ou horloge du PC décalée). Retourne (message, décalage en minutes) ou (None, None)."""
    code = re.sub(r'\D', '', code or '')
    if len(code) != 6 or not secret:
        return None, None
    now = int(time.time() // 30)
    for d in sorted(range(-60, 61), key=abs):     # jusqu'à ±30 minutes
        if secrets.compare_digest(_totp_at(secret, now + d), code):
            if abs(d) <= 2:
                return "Ce code vient d'être utilisé. Attends le prochain code (moins de 30 secondes).", 0
            mins = round(d * 30 / 60)
            return (f"L'horloge de l'ordinateur où roule Kubios semble décalée d'environ {abs(mins) or 1} minute(s) "
                    f"par rapport à ton téléphone ({'le PC est en retard' if d > 0 else 'le PC est en avance'}). "
                    "Sur ce PC : Paramètres Windows → Heure et langue → Date et heure → « Synchroniser maintenant ». "
                    "Vérifie aussi que l'heure du téléphone est automatique."), mins
    return None, None


def totp_qr_svg(username, secret):
    from reportlab.graphics.barcode.qr import QrCodeWidget
    from reportlab.graphics.shapes import Drawing
    from reportlab.graphics import renderSVG
    issuer = f"Kubios — {get_company_name()}"
    uri = (f"otpauth://totp/{urllib.parse.quote(issuer)}:{urllib.parse.quote(username)}"
           f"?secret={secret}&issuer={urllib.parse.quote(issuer)}&digits=6&period=30")
    w = QrCodeWidget(uri)
    b = w.getBounds()
    size = 210
    d = Drawing(size, size, transform=[size / (b[2] - b[0]), 0, 0, size / (b[3] - b[1]), 0, 0])
    d.add(w)
    svg = renderSVG.drawToString(d)
    return svg[svg.find('<svg'):]


# ---------- base de données ----------




def _mfa_challenge(user_id):
    conn = get_conn()
    r = conn.execute("SELECT * FROM mfa_challenges WHERE user_id=?", (user_id,)).fetchone()
    conn.close()
    return dict(r) if r else {'user_id': user_id, 'code_hash': None, 'expires_at': 0, 'attempts': 0, 'locked_until': 0}


def _mfa_save_challenge(ch):
    conn = get_conn()
    conn.execute("INSERT OR REPLACE INTO mfa_challenges(user_id, code_hash, expires_at, attempts, locked_until) "
                 "VALUES (?,?,?,?,?)", (ch['user_id'], ch['code_hash'], ch['expires_at'], ch['attempts'],
                                        ch['locked_until']))
    conn.commit()
    conn.close()


def mfa_send_email_code(user):
    """Envoie un code de 6 chiffres au courriel de l'utilisateur (valide 10 min)."""
    code = f"{secrets.randbelow(1000000):06d}"
    ch = _mfa_challenge(user['id'])
    ch.update(code_hash=_sha256(f"{user['id']}:{code}"), expires_at=time.time() + MFA_EMAIL_CODE_TTL)
    _mfa_save_challenge(ch)
    _send_plain_email(user['email'], f"Code de connexion Kubios : {code}",
                      f"Bonjour {user['username']},\n\nVotre code de connexion à Kubios est : {code}\n\n"
                      f"Il est valide 10 minutes. Si vous n'avez pas tenté de vous connecter, "
                      f"avertissez un administrateur.\n\n{get_company_name()}")


def mfa_verify(user, code, method=None, secret=None):
    """Vérifie un code (méthode active de l'utilisateur, ou celle en cours
    d'inscription). Retourne (ok, message d'erreur)."""
    ch = _mfa_challenge(user['id'])
    if ch['locked_until'] and time.time() < ch['locked_until']:
        mins = int((ch['locked_until'] - time.time()) // 60) + 1
        return False, f"Trop d'essais. Réessaie dans {mins} minute(s)."
    method = method or user['mfa_method']
    ok = False
    if method == 'totp':
        step = totp_check(secret or user['mfa_secret'], code, user.get('mfa_last_step') or 0)
        if step:
            db_set_user_mfa(user['id'], mfa_last_step=step)
            ok = True
    elif method == 'email':
        c = re.sub(r'\D', '', code or '')
        if ch['code_hash'] and time.time() < ch['expires_at'] and \
                secrets.compare_digest(ch['code_hash'], _sha256(f"{user['id']}:{c}")):
            ok = True
            ch['code_hash'] = None
        elif ch['code_hash'] and time.time() >= ch['expires_at']:
            return False, "Ce code est expiré. Demande un nouveau code."
    if ok:
        ch.update(attempts=0, locked_until=0)
        _mfa_save_challenge(ch)
        return True, None
    diag = None
    if method == 'totp':
        diag, off = totp_diagnose(secret or user['mfa_secret'], code, user.get('mfa_last_step') or 0)
        if off:
            db_add_audit(user['username'], '2FA : horloge du PC décalée', f"environ {off:+d} min par rapport au téléphone")
    ch['attempts'] += 1
    if ch['attempts'] >= MFA_MAX_ATTEMPTS:
        ch.update(attempts=0, locked_until=time.time() + MFA_LOCK_SECONDS)
        _mfa_save_challenge(ch)
        db_add_audit(user['username'], '2FA : compte bloqué 15 minutes (trop d\'essais)')
        return False, "Trop d'essais. Réessaie dans 15 minutes."
    _mfa_save_challenge(ch)
    return False, diag or "Code incorrect."


def db_create_reset_token(user_id, ip):
    token = secrets.token_urlsafe(32)
    now = time.time()
    conn = get_conn()
    try:
        n = conn.execute("SELECT COUNT(*) n FROM password_resets WHERE user_id=? AND created_at > ?",
                         (user_id, now - 3600)).fetchone()['n']
        if n >= RESET_MAX_PER_HOUR:
            return None
        conn.execute("INSERT INTO password_resets(token_hash, user_id, created_at, expires_at, used_at, ip) "
                     "VALUES (?,?,?,?,NULL,?)", (_sha256(token), user_id, now, now + RESET_TOKEN_TTL, ip))
        conn.commit()
    finally:
        conn.close()
    return token


def db_reset_token_user(token):
    conn = get_conn()
    r = conn.execute("SELECT * FROM password_resets WHERE token_hash=?", (_sha256(token or ''),)).fetchone()
    conn.close()
    if not r or r['used_at'] or time.time() > r['expires_at']:
        return None
    u = db_user_security(r['user_id'])
    return u if u and u['active'] else None


def db_use_reset_token(token, user_id, new_password):
    conn = get_conn()
    try:
        conn.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new_password), user_id))
        conn.execute("UPDATE password_resets SET used_at=? WHERE user_id=? AND used_at IS NULL", (time.time(), user_id))
        conn.commit()
    finally:
        conn.close()


def _find_user_for_reset(ident):
    ident = (ident or '').strip()
    if not ident:
        return None
    conn = get_conn()
    r = conn.execute("SELECT id FROM users WHERE active=1 AND (LOWER(username)=LOWER(?) OR "
                     "(email IS NOT NULL AND LOWER(email)=LOWER(?)))", (ident, ident)).fetchall()
    conn.close()
    return db_user_security(r[0]['id']) if len(r) == 1 else None


def _safe_next(nxt):
    nxt = nxt or ''
    return nxt if nxt.startswith('/') and not nxt.startswith('//') else url_for('index')


def _finish_login(user, nxt):
    session.clear()
    session['user_id'] = user['id']
    session['username'] = user['username']
    session['is_admin'] = bool(user['is_admin'])
    try:
        session['is_superadmin'] = bool(user['is_superadmin'])
    except (IndexError, KeyError):
        session['is_superadmin'] = False
    perms = user.get('permissions', [])
    if isinstance(perms, str):
        try:
            perms = json.loads(perms or '[]')
        except ValueError:
            perms = []
    session['permissions'] = [p for p in perms if p in PERMISSION_KEYS]
    try:
        conn = get_conn()
        r = conn.execute("SELECT full_name FROM users WHERE id=?", (user['id'],)).fetchone()
        conn.close()
        session['full_name'] = (r['full_name'] if r else None) or None
    except Exception:
        session['full_name'] = None
    session.permanent = True
    try:
        session['sid'] = sess_open('user', user['id'], user['username'], session.get('full_name') or user['username'])
        session['sid_ts'] = time.time()
    except Exception:
        traceback.print_exc()
    try:
        if license_expiring_items():
            session['license_warn'] = True
    except Exception:
        traceback.print_exc()
    db_add_audit(user['username'], 'Connexion', f"adresse {client_ip()}")
    return redirect(_safe_next(nxt))


AUTH_PUBLIC_ENDPOINTS = ('forgot_password', 'reset_password', 'login_mfa', 'login_mfa_setup',
                         'atelier_punch_page', 'api_atelier_kiosk', 'api_atelier_punch', 'atelier_kiosk_login', 'atelier_kiosk_forget',
                         'api_atelier_kiosk_message', 'api_atelier_kiosk_thread',
                         'tc_station_page', 'api_tc_station', 'api_tc_punch', 'emp_login', 'emp_logout', 'emp_activate', 'emp_forgot',
                         'emp_home', 'api_emp_me', 'api_emp_hours', 'api_emp_documents', 'api_emp_doc_file', 'api_emp_doc_sign', 'api_emp_schedule', 'api_emp_schedule_pdf', 'api_emp_leaves', 'api_emp_leave_cancel')


# ============================================================
# Messages aux utilisateurs — bandeaux (1.15.0)
# ------------------------------------------------------------
# Un administrateur publie un message (couleur, période). Tant qu'il est actif
# et dans sa période, il s'affiche en bandeau en haut de toutes les pages pour
# les utilisateurs connectés. Le bandeau est inséré automatiquement dans chaque
# page HTML (after_request) : aucune page n'a besoin d'être modifiée.
# ============================================================
ANN_ORDER = {'red': 0, 'yellow': 1, 'blue': 2}
ANN_SKIP_ENDPOINTS = ('login', 'logout', 'static', 'lightspeed_oauth_callback', 'activation_page',
                      'forgot_password', 'reset_password', 'login_mfa', 'login_mfa_setup')






def db_active_announcements():
    today = datetime.date.today().isoformat()
    conn = get_conn()
    rows = [dict(r) for r in conn.execute(
        "SELECT * FROM announcements WHERE active=1 AND (start_date IS NULL OR start_date <= ?) "
        "AND (end_date IS NULL OR end_date >= ?)", (today, today)).fetchall()]
    conn.close()
    rows.sort(key=lambda a: (ANN_ORDER.get(a['color'], 9), -a['id']))
    return rows


def render_announcement_banners(rows):
    from markupsafe import escape
    out = []
    for a in rows:
        bg, fg, border, icon = ANN_COLORS.get(a['color'], ANN_COLORS['blue'])
        text = str(escape(a['message'])).replace('\n', '<br>')
        until = ''
        if a.get('end_date'):
            e = a['end_date']
            until = (f'<span style="opacity:.75;font-weight:400;white-space:nowrap;margin-left:10px">'
                     f'(jusqu\'au {e[8:10]}-{e[5:7]}-{e[:4]})</span>')
        out.append(
            f'<div class="kubios-banner" role="alert" style="background:{bg};color:{fg};border-bottom:2px solid {border};'
            f'padding:10px 24px;font:600 14px/1.45 Segoe UI,Arial,sans-serif;display:flex;gap:10px;'
            f'align-items:flex-start;justify-content:center;text-align:left;position:relative;z-index:40">'
            f'<span aria-hidden="true" style="font-size:16px;line-height:1.3">{icon}</span>'
            f'<span>{text}{until}</span></div>')
    return ''.join(out)


_BODY_TAG = re.compile(r'<body[^>]*>', re.I)
_BODY_END = re.compile(r'</body\s*>', re.I)

# Menu latéral permanent (1.18.0) : ajouté autour de chaque page HTML des
# utilisateurs connectés ; les pages elles-mêmes ne changent pas.
SIDEBAR_SKIP_ENDPOINTS = ANN_SKIP_ENDPOINTS + ('atelier_punch_page', 'atelier_direct_page', 'tc_station_page', 'emp_login', 'emp_activate',
                                                'emp_forgot', 'emp_home')   # poste de punch : plein écran pour la tablette
SIDEBAR_GROUPS = (
    (None, (('index', 'Accueil', None, 'home'), ('dashboard3d_page', 'Tableau de bord 3D', 'dashboard3d', 'cube'))),
    ('Clients et comptes', (('car_page', 'Comptes à recevoir', 'comptes_recevoir', 'invoice'),
                            ('credit_accounts_page', 'Comptes de crédit', 'credit_accounts', 'card'))),
    ('Rapports', (('custom_reports_page', 'Rapport des ventes', 'custom_reports', 'bars'),
                  ('tax_report_page', 'Rapport des taxes', 'tax_reports', 'percent'),
                  ('inventory_report_page', "Valeur de l'inventaire", 'inventory_reports', 'box'))),
    ('Gestion Atelier', (('atelier_punch_page', 'Poste de punch', 'atelier_punch', 'clock'),
                         ('atelier_page', 'Atelier', 'atelier', 'wrench'))),
    ('Gestion RH', (('hr_page', 'Dossiers des employés', 'rh', 'idcard'), ('sched_page', 'Horaires', 'rh', 'list'), ('leave_page', 'Congés', 'rh', 'idcard'), ('tc_sheets_page', 'Feuilles de temps', 'rh', 'clock'),
                    ('tc_station_page', 'Punch des employés', 'punch_presence', 'clock'), ('hr_admin_page', 'Administration RH', 'admin', 'list'))),
    ('Gestion', (('admin_users_page', 'Utilisateurs', 'admin', 'users'), ('sessions_page', 'En ligne', 'admin', 'clock'),
                 ('announcements_page', 'Messages aux utilisateurs', 'admin', 'megaphone'),
                 ('admin_settings_page', 'Entreprise', 'admin', 'building'),
                 ('full_backups_page', 'Sauvegardes', 'admin', 'download'))),
    ('Système', (('email_settings_page', "Paramètres d'envoi", 'email_settings', 'mail'), ('email_log_page', 'Journal des envois', 'email_settings', 'mail'),
                 ('audit_page', "Journal d'audit", 'audit', 'list'),
                 ('updates_page', 'Mises à jour', 'updates', 'refresh'),
                 ('activation_page', 'Licence', 'license', 'lock'),
                 ('sante_page', 'Santé du système', 'superadmin', 'clock'))),
)
SIDEBAR_ICONS = {
    'home': '<path d="M3 11l9-7 9 7v9a1 1 0 01-1 1h-5v-6h-6v6H4a1 1 0 01-1-1z"/>',
    'invoice': '<path d="M7 3h10l2 3v15H5V6z"/><path d="M9 11h6M9 15h6"/>',
    'card': '<rect x="3" y="6" width="18" height="13" rx="2"/><path d="M3 10h18"/>',
    'bars': '<path d="M4 19V10M10 19V5M16 19v-6M22 19H2"/>',
    'box': '<path d="M3 7l9-4 9 4v10l-9 4-9-4z"/><path d="M3 7l9 4 9-4M12 11v10"/>',
    'clock': '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    'wrench': '<path d="M14.7 6.3a4 4 0 00-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 005.4-5.4l-2.6 2.6-2.4-.6-.6-2.4z"/>',
    'idcard': '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2.2"/><path d="M5.8 16c.6-1.6 1.8-2.4 3.2-2.4s2.6.8 3.2 2.4M14 10h4M14 13h3"/>',
    'cube': '<path d="M12 2l8 4.5v9L12 20l-8-4.5v-9z"/><path d="M4 6.5l8 4.5 8-4.5M12 11v9"/><path d="M8 4.3l8 4.4"/>',
    'percent': '<path d="M19 5L5 19"/><circle cx="7" cy="7" r="2.5"/><circle cx="17" cy="17" r="2.5"/>',
    'users': '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.5 3.4-5.5 6.5-5.5s5.7 2 6.5 5.5M16 4.5a3.5 3.5 0 010 7"/>',
    'megaphone': '<path d="M3 11l15-6v14L3 13z"/><path d="M8 13v5a2 2 0 004 0v-3.5"/>',
    'building': '<path d="M4 21V8l8-5 8 5v13"/><path d="M9 21v-6h6v6"/>',
    'download': '<path d="M12 3v12M7 10l5 5 5-5"/><path d="M4 17v3h16v-3"/>',
    'mail': '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
    'list': '<path d="M8 4h11v16H8zM5 7v13h11"/><path d="M11 9h5M11 13h5"/>',
    'refresh': '<path d="M20 12a8 8 0 11-2.3-5.7M20 4v5h-5"/>',
    'lock': '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 018 0v3"/>',
    'logout': '<path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h11"/>',
}
SIDEBAR_CSS = '''<style id="kbs-style">
.kbs-shell{display:flex;min-height:100vh;align-items:stretch}
.kbs-side{flex:0 0 248px;width:248px;box-sizing:border-box;background:#0f172a;color:#cbd5e1;padding:16px 12px;
  display:flex;flex-direction:column;gap:2px;font-family:"Segoe UI",system-ui,Arial,sans-serif;font-size:14px;line-height:1.3;
  position:sticky;top:0;height:100vh;overflow-y:auto;z-index:30}
.kbs-side *{box-sizing:border-box}
.kbs-brand{display:flex;align-items:center;gap:10px;padding:4px 10px 14px;color:#fff;font-weight:700;font-size:18px;text-decoration:none}
.kbs-brand img{width:30px;height:30px;border-radius:8px}
.kbs-brand small{display:block;font-weight:400;font-size:11.5px;color:#94a3b8;margin-top:1px}
.kbs-head{font-size:11px;font-weight:700;letter-spacing:.7px;text-transform:uppercase;color:#94a3b8;padding:14px 12px 5px}
.kbs-side a.kbs-item{display:flex;align-items:center;gap:12px;padding:9px 12px;border-radius:9px;color:#cbd5e1;text-decoration:none;font-size:14px;font-weight:400}
.kbs-side a.kbs-item:hover{background:rgba(255,255,255,.08);color:#fff;text-decoration:none}
.kbs-side a.kbs-item.on{background:rgba(96,165,250,.2);color:#fff;font-weight:600}
.kbs-side svg{width:18px;height:18px;flex:none;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.kbs-user{margin-top:auto;border-top:1px solid rgba(255,255,255,.12);padding:12px 6px 0;display:flex;align-items:center;gap:10px}
.kbs-av{width:36px;height:36px;border-radius:50%;background:#3b82f6;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;flex:none}
.kbs-who{flex:1;min-width:0}
.kbs-who b{display:block;color:#fff;font-weight:600;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.kbs-who span{font-size:12px;color:#94a3b8}
.kbs-side a.kbs-out{width:40px;height:40px;border-radius:9px;display:flex;align-items:center;justify-content:center;color:#cbd5e1}
.kbs-side a.kbs-out:hover{background:rgba(255,255,255,.08);color:#fff}
.kbs-main{flex:1 1 auto;min-width:0}
@media (max-width: 900px){
  .kbs-shell{flex-direction:column}
  .kbs-side{position:static;width:auto;flex:none;height:auto;flex-direction:row;flex-wrap:wrap;gap:4px;padding:10px}
  .kbs-head{display:none}.kbs-brand{padding:4px 8px;font-size:16px}
  .kbs-user{margin:0 0 0 auto;border:0;padding:0}.kbs-who{display:none}
}
@media print{.kbs-side{display:none !important}.kbs-shell{display:block}}
</style>'''


def _sidebar_allowed(perm):
    if perm is None:
        return True
    if perm == 'superadmin':                       # 1.51.0 : santé du système, réservée au fournisseur
        return bool(session.get('is_superadmin'))
    if session.get('is_admin'):
        return True
    return perm != 'admin' and perm in (session.get('permissions') or [])




def _initials(name):
    parts = [p for p in re.split(r'[\s._-]+', name or '') if p]
    return ((parts[0][0] + (parts[-1][0] if len(parts) > 1 else '')) if parts else '?').upper()


ATELIER_ALERT_SNIPPET = """<style>
.kbs-badge{margin-left:auto;min-width:20px;height:20px;padding:0 6px;border-radius:10px;background:#ef4444;color:#fff;font-size:11.5px;font-weight:800;display:inline-flex;align-items:center;justify-content:center}
.kbs-badge[hidden]{display:none}
#kbsAtToast{position:fixed;right:18px;bottom:18px;z-index:900;max-width:380px;background:#7f1d1d;color:#fff;border-radius:12px;padding:12px 14px 12px 16px;box-shadow:0 12px 32px rgba(0,0,0,.3);font-family:Segoe UI,Arial,sans-serif;font-size:14px;display:flex;gap:10px;align-items:flex-start}
#kbsAtToast.msg{background:#1e3a8a}
#kbsAtToast a{color:#fff;font-weight:700}
#kbsAtToast button{background:transparent;border:0;color:#fff;font-size:18px;cursor:pointer;line-height:1}
</style>
<script>(function(){
  var seen = null;
  function esc(t){ return String(t == null ? '' : t).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function check(){
    fetch('/api/atelier/unread').then(function(r){ return r.ok ? r.json() : null; }).then(function(d){
      if (!d) return;
      var b = document.getElementById('kbsAtBadge');
      if (b){ b.hidden = !d.unread; b.textContent = d.unread; b.title = d.problems ? d.problems + ' problème(s) à régler' : 'Messages non lus'; }
      var l = d.last;
      if (l && seen !== null && l.id > seen && location.hash !== '#messages'){
        var t = document.getElementById('kbsAtToast'); if (t) t.remove();
        t = document.createElement('div'); t.id = 'kbsAtToast'; t.setAttribute('role', 'alert');
        if (l.kind !== 'probleme') t.className = 'msg';
        t.innerHTML = '<span aria-hidden="true">' + (l.kind === 'probleme' ? '⚠' : '💬') + '</span><span style="flex:1"><b>' + esc(l.name) + '</b>'
          + (l.job ? ' — bon ' + esc(l.job) : '') + ' : ' + esc(l.kind === 'probleme' ? l.category_label + (l.text ? ' — ' + l.text : '') : l.text)
          + '<br><a href="__URL__">Voir et répondre</a></span><button aria-label="Fermer">×</button>';
        t.querySelector('button').onclick = function(){ t.remove(); };
        document.body.appendChild(t);
      }
      seen = l ? Math.max(seen || 0, l.id) : (seen || 0);
    }).catch(function(){});
  }
  check(); setInterval(check, 15000);
})();</script>"""


def render_sidebar():
    from markupsafe import escape
    ep = request.endpoint
    out = ['<aside class="kbs-side" aria-label="Menu principal">',
           f'<a class="kbs-brand" href="{url_for("index")}"><img src="{url_for("static", filename="kubios_icon.png")}" alt="">'
           f'<span>Kubios<small>{escape(get_company_name())}</small></span></a>']
    for title, items in SIDEBAR_GROUPS:
        visible = [it for it in items if _sidebar_allowed(it[2]) and
                   (endpoint_module(it[0]) is None or license_module_active(endpoint_module(it[0])))]
        if not visible:
            continue
        if title:
            out.append(f'<div class="kbs-head">{escape(title)}</div>')
        for endpoint, label, _perm, icon in visible:
            try:
                href = url_for(endpoint)
            except Exception:
                continue
            on = ' on' if ep == endpoint else ''
            cur = ' aria-current="page"' if on else ''
            badge = '<span class="kbs-badge" id="kbsAtBadge" hidden></span>' if endpoint == 'atelier_page' else ''
            out.append(f'<a class="kbs-item{on}" href="{href}"{cur}><svg viewBox="0 0 24 24" aria-hidden="true">'
                       f'{SIDEBAR_ICONS[icon]}</svg>{escape(label)}{badge}</a>')
    # Les anciens liens de navigation en haut des pages font double emploi avec le menu : masqués.
    hide = []
    for _t, items in SIDEBAR_GROUPS:
        for endpoint, *_rest in items:
            try:
                hide.append(url_for(endpoint))
            except Exception:
                pass
    hide.append(url_for('logout'))
    out.append('<style>' + ','.join(f'.kbs-main header a[href="{h}"]' for h in hide) + '{display:none !important}</style>')
    if session.get('is_admin') or 'atelier' in (session.get('permissions') or []):
        out.append(ATELIER_ALERT_SNIPPET.replace('__URL__', url_for('atelier_page') + '#messages'))
    name = current_display_name()
    out.append(f'<div class="kbs-user"><span class="kbs-av" aria-hidden="true">{escape(_initials(name))}</span>'
               f'<span class="kbs-who"><b>{escape(name)}</b><span>{"Administrateur" if session.get("is_admin") else "Utilisateur"}</span></span>'
               f'<a class="kbs-out" href="{url_for("logout")}" aria-label="Se déconnecter" title="Se déconnecter">'
               f'<svg viewBox="0 0 24 24" aria-hidden="true">{SIDEBAR_ICONS["logout"]}</svg></a></div></aside>')
    return ''.join(out)

# Avis d'expiration de la licence (1.17.4) : à chaque connexion, si la licence
# expire dans LICENSE_WARN_DAYS jours ou moins, une fenêtre à confirmer
# (« J'ai compris ») s'affiche par-dessus la première page.
LICENSE_WARN_DAYS = 15


def license_expiring_items(st=None):
    """Noyau et modules qui expirent d'ici LICENSE_WARN_DAYS jours : [(libellé, date, jours)]."""
    st = st or get_license_status()
    if not st.get('active'):
        return []
    out = []
    if st.get('days_left') is not None and st['days_left'] <= LICENSE_WARN_DAYS:
        out.append(('Votre licence Kubios', datetime.date.fromisoformat(st['payload']['expires']), st['days_left']))
    for key, m in (st.get('modules') or {}).items():
        if m.get('included') and not m.get('legacy') and m.get('active') and m.get('days_left') is not None \
                and m['days_left'] <= LICENSE_WARN_DAYS:
            out.append((f"Le module {m['label']}", datetime.date.fromisoformat(m['expires']), m['days_left']))
    return out


def render_license_warning():
    from markupsafe import escape
    items = license_expiring_items()
    if not items:
        return ''
    def _when(d):
        return "aujourd'hui" if d == 0 else ("demain" if d == 1 else f"dans {d} jours")
    def _date(e):
        return f"{e.day}{'er' if e.day == 1 else ''} {_MOIS_FR[e.month - 1]} {e.year}"
    days = min(it[2] for it in items)
    lines = ''.join(f"<li style=\"margin-bottom:4px\">{escape(lbl)} expire le <b>{_date(e)}</b> (<b>{_when(d)}</b>).</li>" for lbl, e, d in items)
    urgent = days <= 3
    accent, soft = ('#b91c1c', '#fef2f2') if urgent else ('#b45309', '#fffbeb')
    title = "Votre licence Kubios expire bientôt" if items[0][0] == 'Votre licence Kubios' else "Un module de votre licence expire bientôt"
    return f'''<div id="kubiosLicWarn" style="position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:1000;display:flex;align-items:center;justify-content:center;font-family:Segoe UI,Arial,sans-serif">
  <div role="alertdialog" aria-modal="true" aria-labelledby="kubiosLicTitle" style="background:#fff;border-radius:14px;max-width:470px;width:calc(100% - 40px);box-shadow:0 24px 60px rgba(0,0,0,.35);overflow:hidden">
    <div style="background:{soft};border-bottom:3px solid {accent};padding:18px 22px;display:flex;gap:12px;align-items:center">
      <span aria-hidden="true" style="font-size:26px;line-height:1">⚠</span>
      <h2 id="kubiosLicTitle" style="margin:0;font-size:18px;color:{accent}">{title}</h2>
    </div>
    <div style="padding:18px 22px 6px;font-size:14.5px;line-height:1.6;color:#1f2937">
      <ul style="margin:0 0 10px;padding-left:18px">{lines}</ul>
      <p style="margin:0">Pour éviter toute interruption de service, communiquez avec votre fournisseur afin de la renouveler avant cette date.</p>
    </div>
    <div style="padding:16px 22px 20px;text-align:right">
      <button type="button" id="kubiosLicOk" style="background:linear-gradient(135deg,#3b82f6,#2563eb);color:#fff;border:none;padding:10px 22px;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer">J'ai compris</button>
    </div>
  </div>
</div>
<script>(function(){{var b=document.getElementById('kubiosLicOk');b.focus();b.addEventListener('click',function(){{
fetch('/api/license-warning/ack',{{method:'POST'}}).finally(function(){{var w=document.getElementById('kubiosLicWarn');if(w)w.remove();}});}});}})();</script>'''


@app.after_request
def inject_announcement_banners(resp):
    """Ajoute les bandeaux actifs en haut des pages HTML des utilisateurs connectés."""
    try:
        if (resp.status_code not in (200, 402) or resp.mimetype != 'text/html' or resp.direct_passthrough
                or not session.get('user_id') or (request.endpoint in ANN_SKIP_ENDPOINTS and not
                    (request.endpoint == 'activation_page' and get_license_status().get('active')))):
            return resp
        rows = db_active_announcements()
        warn = render_license_warning() if session.get('license_warn') else ''
        html = resp.get_data(as_text=True)
        m = _BODY_TAG.search(html)
        if not m:
            return resp
        ends = list(_BODY_END.finditer(html))
        if ends and (request.endpoint not in SIDEBAR_SKIP_ENDPOINTS or
                     (request.endpoint == 'activation_page' and get_license_status().get('active'))):
            e = ends[-1].start()
            html = (html[:m.end()] + SIDEBAR_CSS + '<div class="kbs-shell">' + render_sidebar() + '<div class="kbs-main">'
                    + warn + render_announcement_banners(rows) + html[m.end():e] + '</div></div>' + html[e:])
        elif rows or warn:
            html = html[:m.end()] + warn + render_announcement_banners(rows) + html[m.end():]
        else:
            return resp
        resp.set_data(html)
    except Exception:
        traceback.print_exc()
    return resp


# ============================================================
# Sauvegardes complètes (1.16.0)
# ------------------------------------------------------------
# Une archive .zip par sauvegarde : data.db (toutes les données ET la
# configuration : entreprise, utilisateurs, envois, Lightspeed, licence,
# comptes, ventes gardées, messages…), le classeur Excel et les images
# personnalisées (logo, fond de connexion), avec un manifest.json.
# - Copie de la base avec l'API « backup » de SQLite : cohérente même si
#   Kubios est en train d'écrire.
# - Automatique une fois par jour à l'heure choisie ; rétention 7/14/30 jours
#   (la plus récente est toujours gardée).
# - Restauration : sauvegarde de l'état actuel d'abord, vérification de
#   l'archive, remplacement de la base (migrée au besoin vers la version
#   actuelle), du classeur et des images. La connexion Lightspeed actuelle est
#   conservée (ses jetons changent à chaque usage : ceux d'une vieille
#   sauvegarde ne seraient plus valides).
# ============================================================
import zipfile
import tempfile























def _full_backup_loop():
    while True:
        time.sleep(LS_AUTO_CHECK_SECONDS)
        try:
            cfg = fb_cfg()
            now = datetime.datetime.now()
            if not cfg['enabled'] or now.hour < cfg['hour'] or meta_get('fb_auto_date') == now.date().isoformat():
                continue
            meta_set('fb_auto_date', now.date().isoformat())
            try:
                res = full_backup('auto', 'Sauvegarde automatique')
            except Exception as e:
                fb_notify(False, error=str(e))
            else:
                fb_notify(True, info=res)
        except Exception as e:
            print("Sauvegarde automatique :", e)


# ============================================================
# Rapport des taxes (1.17.0)
# ------------------------------------------------------------
# À partir des ventes gardées localement (avec les montants de taxes calculés
# par Lightspeed pour chaque ligne). Ventilation par taxe et par taux (ex.
# TPS 5 %, TVQ 9,975 %, TVH…) : ventes taxables et taxe perçue ; ventes non
# taxables ; détail par catégorie de taxes Lightspeed. Les retours (montants
# négatifs) réduisent les ventes et la taxe perçue.
# ============================================================
































# ============================================================
# Valeur de l'inventaire (1.19.0)
# ------------------------------------------------------------
# Instantané lu dans Lightspeed : pour chaque article actif (non archivé, pas
# « non inventorié »), quantité en main × coût (coût moyen de Lightspeed, sinon
# coût par défaut) ; aussi la valeur au prix de détail. Les quantités négatives
# ne comptent pas dans la valeur (elles sont signalées à part). Les instantanés
# sont gardés dans Kubios (historique par mois) ; planification mensuelle avec
# envoi du PDF par courriel.
# ============================================================






















def _inventory_loop():
    """Instantané mensuel planifié (jour du mois ou dernier jour, à l'heure choisie),
    envoyé ensuite aux destinataires. Une seule fois par mois."""
    while True:
        time.sleep(LS_AUTO_CHECK_SECONDS)
        try:
            cfg = inv_cfg()
            if not cfg['auto'] or not ls_config()['connected'] or _inv_state['running']:
                continue
            now = datetime.datetime.now()
            due_day = _is_last_day_of_month(now.date()) if cfg['day'] == 'last' else now.day >= int(cfg['day'])
            month = now.strftime('%Y-%m')
            if not due_day or now.hour < cfg['hour'] or meta_get('inv_last_month') == month:
                continue
            meta_set('inv_last_month', month)
            recips = cfg['recipients']

            def then(sid):
                meta_delete('inv_last_error')
                if recips:
                    send_inventory_email(sid, recips, 'Envoi automatique', auto=True)
            start_inventory_job('auto', 'Instantané automatique', '', then=then)
        except Exception as e:
            print("Instantané de l'inventaire :", e)


# ============================================================
# Tableau de bord 3D (1.20.0)
# ------------------------------------------------------------
# Maquette isométrique (three.js) : magasin = ventes de la période, bâtiment
# mauve = taxes, palettes = dernier instantané d'inventaire, tour verte =
# comptes de crédit, maisons = 10 plus gros soldes à recevoir. Chaque partie
# n'est envoyée que si l'utilisateur a l'accès correspondant.
# ============================================================
# three.js en local (1.20.1) : téléchargé une seule fois depuis le CDN (version
# fixée), vérifié, puis servi par Kubios depuis static/vendor/ — la page n'a plus
# besoin d'Internet. Les mises à jour de Kubios ne touchent pas à ce dossier.












# ============================================================
# Gestion Atelier (1.21.0)
# ------------------------------------------------------------
# Les mécaniciens punchent leur temps sur chaque bon HubTiger (poste de punch,
# NIP par mécanicien). Une pause ferme le punch ; « Reprendre » en ouvre un
# nouveau. Débuter un autre bon alors qu'un bon roule déjà demande quoi faire :
# terminer l'ancien, le mettre en pause, ou travailler sur les deux (le temps
# compte alors sur chaque bon). Rentabilité : minutes et montants de service
# facturés (lignes « Service N mins » portant « HT: #bon » dans Lightspeed)
# comparés au temps punché × taux coûtant du mécanicien.
# ============================================================


































# ---------- relecture automatique des ventes chaque nuit (1.29.1) ----------




def _atelier_reread_loop():
    """Une fois par nuit (vers 2 h), relit dans Lightspeed les ventes des N derniers jours :
    une vente souvent corrigée après coup (ex. « HT: #bon » ajouté le lendemain) est ainsi mise à jour."""
    time.sleep(90)
    while True:
        try:
            cfg = at_reread_cfg()
            now = datetime.datetime.now(); today = now.date().isoformat()
            if cfg['enabled'] and now.hour >= AT_REREAD_HOUR and meta_get('atelier_reread_last_day') != today and ls_config()['connected']:
                if _store_lock.acquire(blocking=False):
                    ss = _store_state
                    days = [now.date() - datetime.timedelta(days=i) for i in range(cfg['days'], 0, -1)] + [now.date()]
                    ss.update(running=True, progress=f"Relecture automatique : {len(days)} jour(s)…", error=None, kind='atelier')
                    try:
                        store_sync_days(days, ss, 'atelier')
                        res = f"{len(days)} jour(s) relus"
                    except Exception as e:
                        res = f"échec : {e}"
                    finally:
                        ss['running'] = False; ss['progress'] = ''
                        _store_lock.release()
                    meta_set('atelier_reread_last_day', today); meta_set('atelier_reread_last_at', now.strftime('%Y-%m-%d %H:%M'))
                    meta_set('atelier_reread_last_result', res)
                    db_add_audit('Kubios', 'Atelier : relecture automatique des ventes', res)
        except Exception:
            traceback.print_exc()
        time.sleep(600)








# ---------- Bons de travail créés dans Kubios (1.22.0) ----------








# ---------- Accès du poste de punch sans le login de Kubios (1.22.0) ----------














# ============================================================
# Rapport des ventes au format comptable (1.23.0)
# ------------------------------------------------------------
# 1. Ventes par catégorie avec compte GL, sous-total des « ventes élargies »
#    (catégories cochées), puis les autres catégories et le total ;
# 2. répartition par mode de paiement (paiements gardés avec les ventes) ;
# 3. ventilation des taxes ; grand total facturé aux clients.
# Les comptes GL sont réglés par un administrateur (meta « rep_gl »).
# ============================================================
# Valeurs par défaut d'un modèle de rapport type (1.23.2) ;
# ce qu'un administrateur enregistre dans « Comptes GL du rapport » a priorité.












# ---------- Messages de l'atelier (1.26.0) ----------
# Le mécanicien écrit au responsable ou signale un problème sur un bon (poste de punch,
# NIP demandé) ; le responsable voit une pastille et une alerte partout dans Kubios,
# répond, et marque les problèmes résolus. Courriel facultatif pour les problèmes.








# ---------- L'atelier en direct : garage 3D (1.27.0) ----------


# ---------- PDF de la rentabilité de l'atelier (1.29.0) ----------






















# ============================================================
# Gestion RH (1.30.0) — dossiers des employés
# ------------------------------------------------------------
# Renseignements personnels : permission « rh » obligatoire, chaque consultation est
# notée (hr_access_log). Ne jamais y mettre de NAS, de renseignements bancaires ou
# médicaux. Les documents sont gardés dans Dossiers_RH\<employé>\ et inclus dans
# les sauvegardes complètes.
# ============================================================
















# ---------- Administration RH : critères et modèles de documents (1.31.0) ----------








# ============================================================
# Portail employé, signatures et punch de présence (1.39.0) — module RH de la licence
# ============================================================
































# ---------- signatures électroniques des documents RH ----------








# ---------- Import des bons HubTiger (export « Jobs booked in detail ») (1.40.0) ----------














def _ht_drop_loop():
    """Dossier de dépôt : un export déposé dans Import_HubTiger est importé tout seul, puis rangé dans « Importés »."""
    time.sleep(120)
    while True:
        try:
            if meta_get('ht_drop_enabled') == '1' and HT_DROP_DIR.exists():
                for f in sorted(HT_DROP_DIR.glob('*')):
                    if f.suffix.lower() not in ('.xlsx', '.csv') or f.name.startswith('~$') or time.time() - f.stat().st_mtime < 20:
                        continue
                    done_dir = HT_DROP_DIR / 'Importés'; done_dir.mkdir(exist_ok=True)
                    try:
                        items = ht_parse(f)
                        conn = get_conn()
                        try:
                            res = ht_apply(conn, ht_plan(conn, items, meta_get('ht_include_done') != '0'), 'Kubios (dossier de dépôt)')
                        finally:
                            conn.close()
                        meta_set('ht_last_drop', json.dumps({'at': _at_now(), 'file': f.name, 'result': res}, ensure_ascii=False))
                        f.replace(done_dir / f"{datetime.datetime.now():%Y-%m-%d_%H%M%S}_{f.name}")
                    except Exception as e:
                        meta_set('ht_last_drop', json.dumps({'at': _at_now(), 'file': f.name, 'error': str(e)}, ensure_ascii=False))
                        f.replace(done_dir / f"ERREUR_{datetime.datetime.now():%Y-%m-%d_%H%M%S}_{f.name}")
                        db_add_audit('Kubios (dossier de dépôt)', 'Atelier : import HubTiger — échec', f"{f.name} : {e}")
        except Exception:
            traceback.print_exc()
        time.sleep(300)


# ============================================================
# Horaires des employés (1.42.0) — module RH de la licence
# ============================================================






















# ============================================================
# Congés (1.44.0) et courriel d'horaire en HTML
# ============================================================
























# ============================================================
# Synchronisation SQLite -> Excel (opération lente, en arrière-plan ou à la demande)
# ============================================================
BACKUP_DIR.mkdir(exist_ok=True)














def _auto_sync_loop():
    import time
    while True:
        time.sleep(AUTO_SYNC_SECONDS)
        try:
            if meta_get('dirty', '0') == '1' and not _sync_state["running"]:
                print("Synchronisation automatique vers Excel...")
                export_to_excel()
                print("Synchronisation automatique terminée.")
        except Exception as e:
            print("Erreur de synchronisation automatique :", e)


# ============================================================
# Génération du PDF (État de compte) — reproduit le modèle existant
# ============================================================






















# ============================================================
# Envoi Outlook
# ============================================================


# ============================================================
# Création/envoi en lot pour tous les clients avec solde dû
# ============================================================




# ============================================================
# Routes — licence
# ============================================================






# ============================================================
# Routes — connexion / utilisateurs
# ============================================================
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = "Ta session a été fermée par un administrateur. Reconnecte-toi au besoin." if session.pop('kicked', None) else None
    if request.method == 'POST':
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        user = db_verify_login(username, password)
        if user:
            sec = db_user_security(user['id'])
            if sec and sec.get('mfa_required'):
                # 2FA exigée : le mot de passe est bon, il reste le code.
                session.clear()
                session['mfa_pending'] = user['id']
                session['mfa_ts'] = time.time()
                session['mfa_next'] = request.form.get('next') or ''
                if not sec.get('mfa_method'):
                    return redirect(url_for('login_mfa_setup'))
                if sec['mfa_method'] == 'email':
                    try:
                        mfa_send_email_code(sec)
                    except Exception as e:
                        traceback.print_exc()
                        db_add_audit(user['username'], '2FA : envoi du code impossible', str(e))
                return redirect(url_for('login_mfa'))
            return _finish_login(user, request.form.get('next'))
        error = "Nom d'utilisateur ou mot de passe incorrect."
        db_add_audit((request.form.get('username') or '?').strip()[:60], 'Connexion échouée', f"adresse {client_ip()}")
    nxt = request.args.get('next', '')
    try:
        emp_portal = license_module_active('rh')        # 1.39.1 : bouton « Espace employé » si le module RH est actif
    except Exception:
        emp_portal = False
    return render_template('login.html', app_name=APP_NAME, error=error, next=nxt, company=get_company_name(), emp_portal=emp_portal,
                            year=datetime.date.today().year, bg_url=login_bg_url(), bg_mode=login_bg_mode(), video_url=login_video_url())


# ------------------------------------------------------------
# Routes — sécurité des comptes (1.14.0)
# ------------------------------------------------------------
def _auth_render(mode, **kw):
    return render_template('auth.html', app_name=APP_NAME, mode=mode, year=datetime.date.today().year,
                           bg_url=login_bg_url(), bg_mode=login_bg_mode(), video_url=login_video_url(), **kw)


@app.route('/mot-de-passe-oublie', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        ident = request.form.get('ident', '')
        user = _find_user_for_reset(ident)
        if user and user.get('email'):
            token = db_create_reset_token(user['id'], client_ip())
            if token:
                link = request.host_url.rstrip('/') + url_for('reset_password', token=token)
                try:
                    _send_plain_email(user['email'], "Kubios — réinitialisation du mot de passe",
                                      f"Bonjour {user['username']},\n\nPour choisir un nouveau mot de passe, ouvrez ce lien :\n\n"
                                      f"{link}\n\nLe lien est valide 1 heure et ne fonctionne qu'une seule fois. "
                                      f"Si vous n'avez pas fait cette demande, ignorez ce courriel : votre mot de passe "
                                      f"ne change pas.\n\n{get_company_name()}")
                    db_add_audit(user['username'], 'Mot de passe oublié : lien envoyé', _mask_email(user['email']))
                except Exception as e:
                    traceback.print_exc()
                    db_add_audit(user['username'], 'Mot de passe oublié : envoi impossible', str(e))
            else:
                db_add_audit(user['username'], 'Mot de passe oublié : trop de demandes en 1 heure')
        elif user:
            db_add_audit(user['username'], 'Mot de passe oublié : aucun courriel au dossier')
        return _auth_render('forgot_sent')
    return _auth_render('forgot')


@app.route('/reinitialiser/<token>', methods=['GET', 'POST'])
def reset_password(token):
    user = db_reset_token_user(token)
    if user is None:
        return _auth_render('reset_invalid')
    error = None
    if request.method == 'POST':
        p1, p2 = request.form.get('password', ''), request.form.get('password2', '')
        if len(p1) < PASSWORD_MIN_LEN:
            error = f"Le mot de passe doit contenir au moins {PASSWORD_MIN_LEN} caractères."
        elif p1 != p2:
            error = "Les deux mots de passe ne sont pas identiques."
        else:
            db_use_reset_token(token, user['id'], p1)
            db_add_audit(user['username'], 'Mot de passe réinitialisé par lien courriel')
            return _auth_render('reset_done')
    return _auth_render('reset', username=user['username'], error=error, min_len=PASSWORD_MIN_LEN)


def _pending_user():
    uid, ts = session.get('mfa_pending'), session.get('mfa_ts') or 0
    if not uid or time.time() - ts > MFA_PENDING_TTL:
        return None
    u = db_user_security(uid)
    return u if u and u['active'] else None


@app.route('/connexion/verification', methods=['GET', 'POST'])
def login_mfa():
    user = _pending_user()
    if user is None:
        session.pop('mfa_pending', None)
        return redirect(url_for('login'))
    if not user['mfa_method']:
        return redirect(url_for('login_mfa_setup'))
    error, info = None, None
    # 1.35.0 : au choix à chaque connexion — l'application (si configurée) ou un code par courriel (si un courriel est inscrit)
    avail = [m for m in ('totp', 'email') if (m == 'totp' and user.get('mfa_secret')) or (m == 'email' and user.get('email'))]
    if user['mfa_method'] not in avail:
        avail.insert(0, user['mfa_method'])
    via = session.get('mfa_via') if session.get('mfa_via') in avail else user['mfa_method']
    want = request.args.get('via')
    if request.method == 'GET' and want in avail and want != via:
        via = want
        session['mfa_via'] = via
        if via == 'email':
            try:
                mfa_send_email_code(user)
                info = f"Un code vient d'être envoyé à {_mask_email(user['email'])}."
                db_add_audit(user['username'], '2FA : code demandé par courriel (au lieu de l\u2019application)')
            except Exception as e:
                error = f"Envoi impossible : {e}"
    if request.method == 'POST':
        if request.form.get('action') == 'resend' and via == 'email':
            try:
                mfa_send_email_code(user)
                info = f"Nouveau code envoyé à {_mask_email(user['email'])}."
            except Exception as e:
                error = f"Envoi impossible : {e}"
        else:
            ok, error = mfa_verify(user, request.form.get('code', ''), method=via)
            if ok:
                session.pop('mfa_via', None)
                return _finish_login(user, session.get('mfa_next'))
            db_add_audit(user['username'], '2FA : code refusé')
    return _auth_render('mfa', method=via, email=_mask_email(user.get('email')),
                        error=error, info=info, alt=[m for m in avail if m != via])


@app.route('/connexion/configurer-2fa', methods=['GET', 'POST'])
def login_mfa_setup():
    user = _pending_user()
    if user is None:
        return redirect(url_for('login'))
    if user['mfa_method']:
        return redirect(url_for('login_mfa'))
    step = request.values.get('step', 'choose')
    error = None
    if step == 'totp':
        secret = user['mfa_pending_secret']
        if not secret or request.method == 'GET':
            secret = _b32_secret()
            db_set_user_mfa(user['id'], mfa_pending_secret=secret)
            user['mfa_pending_secret'] = secret
        if request.method == 'POST':
            ok, error = mfa_verify(user, request.form.get('code', ''), method='totp', secret=secret)
            if ok:
                db_set_user_mfa(user['id'], mfa_method='totp', mfa_secret=secret, mfa_pending_secret=None)
                db_add_audit(user['username'], '2FA configurée (application)')
                return _finish_login(db_user_security(user['id']), session.get('mfa_next'))
        return _auth_render('setup_totp', qr=totp_qr_svg(user['username'], secret),
                            secret=' '.join(secret[i:i + 4] for i in range(0, len(secret), 4)), error=error)
    if step == 'email':
        if not user.get('email'):
            return _auth_render('setup_choose', error="Aucun courriel n'est inscrit à ton compte : demande à un "
                                                      "administrateur de l'ajouter, ou choisis l'application.",
                                has_email=False)
        if request.method == 'POST' and request.form.get('code'):
            ok, error = mfa_verify(user, request.form.get('code', ''), method='email')
            if ok:
                db_set_user_mfa(user['id'], mfa_method='email', mfa_pending_secret=None)
                db_add_audit(user['username'], '2FA configurée (courriel)')
                return _finish_login(db_user_security(user['id']), session.get('mfa_next'))
        elif request.method == 'GET' or request.form.get('action') == 'resend':
            try:
                mfa_send_email_code(user)
            except Exception as e:
                error = f"Envoi du code impossible : {e}"
        return _auth_render('setup_email', email=_mask_email(user['email']), error=error)
    return _auth_render('setup_choose', has_email=bool(user.get('email')), email=_mask_email(user.get('email')))








# ------------------------------------------------------------
# Routes — messages aux utilisateurs (1.15.0)
# ------------------------------------------------------------












# ------------------------------------------------------------
# Routes — sauvegardes complètes (1.16.0)
# ------------------------------------------------------------




















# ------------------------------------------------------------
# Routes — rapport des taxes (1.17.0)
# ------------------------------------------------------------








# ------------------------------------------------------------
# Routes — valeur de l'inventaire (1.19.0)
# ------------------------------------------------------------
















# ------------------------------------------------------------
# Routes — tableau de bord 3D (1.20.0)
# ------------------------------------------------------------






# ------------------------------------------------------------
# Routes — Gestion Atelier (1.21.0)
# ------------------------------------------------------------












































# ------------------------------------------------------------
# Routes — bons de travail et accès du poste de punch (1.22.0)
# ------------------------------------------------------------
















@app.context_processor
def _inject_report_disclaimer():
    return {'report_disclaimer': REPORT_DISCLAIMER, 'report_disclaimer_title': REPORT_DISCLAIMER_TITLE}


# ------------------------------------------------------------
# Routes — messages de l'atelier (1.26.0)
# ------------------------------------------------------------






















# ------------------------------------------------------------
# Routes — Gestion RH (1.30.0)
# ------------------------------------------------------------
































# ------------------------------------------------------------
# Routes — poste de punch des employés (1.39.0)
# ------------------------------------------------------------






# ------------------------------------------------------------
# Routes — feuilles de temps (gestionnaire)
# ------------------------------------------------------------


















# ------------------------------------------------------------
# Routes — documents RH : publier, signer, envoyer ; accès au portail
# ------------------------------------------------------------










# ------------------------------------------------------------
# Routes — portail employé
# ------------------------------------------------------------




























# ------------------------------------------------------------
# Routes — horaires (gestionnaire)
# ------------------------------------------------------------


















# ------------------------------------------------------------
# Routes — horaire dans le portail employé
# ------------------------------------------------------------




# ------------------------------------------------------------
# Routes — congés (gestionnaire et portail) et journal des envois
# ------------------------------------------------------------
















@app.route('/logout')
def logout():
    if session.get('username'):
        db_add_audit(session.get('username'), 'Déconnexion')
    sess_close(session.get('sid'), 'déconnexion')
    emp_keep = {k: session.get(k) for k in ('emp_id', 'emp_sid', 'emp_sid_ts') if session.get(k)}
    session.clear()
    session.update(emp_keep)                       # se déconnecter de Kubios ne ferme pas le portail employé
    return redirect(url_for('login'))




@app.route('/audit')
def audit_page():
    resp = permission_required_check('audit')
    if resp is not None:
        return resp
    return render_template('audit.html', company=get_company_name(), username=session.get('username'),
                            is_admin=session.get('is_admin', False), permissions=session.get('permissions') or [])








# ============================================================
# Routes — Administration (personnalisation : nom d'entreprise, logo des
# PDF, textes des PDF/courriels). Réservé aux administrateurs.
# ============================================================






























# ============================================================
# Routes — mises à jour (version et changelog)
# ============================================================








# ---------- 1.44.4 : versions conservées pour revenir en arrière
_VERSION_SKIP_DIRS = {'__pycache__', '.venv', 'Claude outputs'}
_VERSION_SKIP_EXT = ('.db', '.db-wal', '.db-shm', '.xlsx', '.log', '.bak', '.pyc')


def version_snapshot():
    """Garde une copie du programme de la version qui tourne (sans la base ni les fichiers lourds), si ce n'est pas déjà fait."""
    try:
        VERSIONS_DIR.mkdir(exist_ok=True)
        if any(VERSIONS_DIR.glob(f"kubios-{APP_VERSION}__*.zip")):
            return None
        tmp = VERSIONS_DIR / f"_en_cours_{APP_VERSION}.zip"
        with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for f in APP_DIR.rglob('*'):
                rel = f.relative_to(APP_DIR)
                if not f.is_file() or any(part in _VERSION_SKIP_DIRS for part in rel.parts) or f.name.lower().endswith(_VERSION_SKIP_EXT) \
                        or f.name.startswith(('login_video_custom', 'login_bg_custom')) or f.stat().st_size > 15 * 1024 * 1024:
                    continue
                z.write(f, Path('app') / rel)
        dst = VERSIONS_DIR / f"kubios-{APP_VERSION}__{datetime.datetime.now():%Y%m%d-%H%M%S}.zip"
        tmp.replace(dst)
        for old in sorted(VERSIONS_DIR.glob('kubios-*__*.zip'), key=lambda x: x.stat().st_mtime, reverse=True)[VERSIONS_KEEP:]:
            old.unlink(missing_ok=True)
        return dst
    except Exception:
        traceback.print_exc()
        return None






# ---------- 1.36.0 : installer un paquet téléversé (mise à jour locale, sans GitHub) ----------




































@app.route('/api/me')
def api_me():
    u = current_user()
    if not u:
        return jsonify({'error': 'auth_required'}), 401
    return jsonify({'username': u['username'], 'is_admin': bool(u['is_admin'])})


# ============================================================
# Routes
# ============================================================
@app.route('/')
def index():
    """Page d'accueil (menu) affichée juste après la connexion — donne accès
    aux différents volets du logiciel selon les permissions de la personne
    connectée, plutôt que d'atterrir directement sur les comptes à recevoir."""
    is_admin = bool(session.get('is_admin', False))
    perms = session.get('permissions') or []
    now = datetime.datetime.now()
    moment = request.args.get('moment') if request.args.get('moment') in HOME_MOMENTS else home_moment(now)
    name = current_display_name()
    greet, sub = HOME_MOMENTS[moment]
    date_txt = f"{_JOURS_FR[now.weekday()]} {now.day}{'er' if now.day == 1 else ''} {_MOIS_FR[now.month - 1]} {now.year}"
    return render_template('home.html', company=get_company_name(), app_name=APP_NAME,
                           username=session.get('username'), display_name=name,
                           first_name=(name.split()[0] if name else ''), greeting=greet, subline=sub, date_txt=date_txt,
                           t=HOME_BANNER_THEMES[moment], is_admin=is_admin, permissions=perms,
                           dash=home_dashboard(is_admin, perms), year=now.year, version=APP_VERSION)


# Bandeau d'accueil « Bord de mer » (1.18.0) : couleurs selon le moment de la journée
HOME_BANNER_THEMES = {
 "matin": {
  "sky": "linear-gradient(180deg,#fde4c8 0%,#fbd0a8 45%,#cfe3ff 100%)",
  "astro": "#f59e0b",
  "astroX": 720,
  "astroY": 150,
  "starsOn": 0,
  "beamOn": 0,
  "gullsOn": 0.8,
  "boatOn": 1,
  "gull": "#334155",
  "sea": "#7fa6cf",
  "hull": "#1e3a8a",
  "rock": "#6b5b4d",
  "lamp": "#fde68a",
  "heroText": "#0b1324",
  "scrim": "linear-gradient(90deg,rgba(255,250,244,.82) 0%,rgba(255,250,244,.55) 38%,rgba(255,250,244,0) 62%)",
  "shadow": "0 1px 2px rgba(255,255,255,.7)"
 },
 "apres-midi": {
  "sky": "linear-gradient(180deg,#8ec5ff 0%,#bfdcff 60%,#e3f1ff 100%)",
  "astro": "#fde047",
  "astroX": 860,
  "astroY": 44,
  "starsOn": 0,
  "beamOn": 0,
  "gullsOn": 0.9,
  "boatOn": 1,
  "gull": "#1e293b",
  "sea": "#2f78c4",
  "hull": "#b91c1c",
  "rock": "#5c4d40",
  "lamp": "#e2e8f0",
  "heroText": "#0b1324",
  "scrim": "linear-gradient(90deg,rgba(244,249,255,.82) 0%,rgba(244,249,255,.55) 38%,rgba(244,249,255,0) 62%)",
  "shadow": "0 1px 2px rgba(255,255,255,.7)"
 },
 "soir": {
  "sky": "linear-gradient(180deg,#0b1226 0%,#1b1a49 60%,#2b2f6e 100%)",
  "astro": "#e2e8f0",
  "astroX": 760,
  "astroY": 56,
  "starsOn": 1,
  "beamOn": 1,
  "gullsOn": 0,
  "boatOn": 0,
  "gull": "#ffffff",
  "sea": "#142045",
  "hull": "#1e293b",
  "rock": "#1c1f33",
  "lamp": "#fde047",
  "heroText": "#ffffff",
  "scrim": "linear-gradient(90deg,rgba(8,13,32,.78) 0%,rgba(8,13,32,.5) 38%,rgba(8,13,32,0) 62%)",
  "shadow": "0 1px 3px rgba(0,0,0,.65)"
 }
}
HOME_MOMENTS = {
    'matin': ('Bon matin', "Voici ce qui demande ton attention aujourd'hui."),
    'apres-midi': ('Bon après-midi', "Un coup d'œil rapide sur la journée en cours."),
    'soir': ('Bonsoir', 'Les rapports de la journée seront prêts cette nuit.'),
}
_JOURS_FR = ('lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche')


def home_moment(now=None):
    h = (now or datetime.datetime.now()).hour
    return 'matin' if 5 <= h < 12 else ('apres-midi' if 12 <= h < 18 else 'soir')


def home_dashboard(is_admin, perms):
    """Indicateurs de l'accueil (1.18.0) : seulement ce que la personne a le droit de voir."""
    today = datetime.date.today()
    # chaque indicateur existe toujours (None = non affiché pour cet utilisateur)
    d = {'overdue': None, 'week': None, 'yesterday': None, 'backup': None, 'license': None, 'ar': ar_allowed()}
    conn = get_conn()
    try:
        r = None if not d['ar'] else conn.execute("SELECT COUNT(*) n, COALESCE(SUM(COALESCE(montant,0)-COALESCE(montant_paye,0)),0) s FROM invoices "
                         "WHERE echeance IS NOT NULL AND echeance <> '' AND echeance < ? "
                         "AND COALESCE(montant,0)-COALESCE(montant_paye,0) > 0.005", (today.isoformat(),)).fetchone()
        d['overdue'] = {'count': r['n'], 'amount': round(r['s'] or 0, 2)} if r else None
        if is_admin or 'custom_reports' in perms:
            days = [today - datetime.timedelta(days=i) for i in range(7, 0, -1)]
            vals = {row['sale_date']: row['t'] for row in conn.execute(
                "SELECT sale_date, SUM(total) t FROM sales_lines WHERE sale_date BETWEEN ? AND ? GROUP BY sale_date",
                (days[0].isoformat(), days[-1].isoformat())).fetchall()}
            have = conn.execute("SELECT COUNT(*) n FROM sales_days WHERE complete=1 AND day BETWEEN ? AND ?",
                                (days[0].isoformat(), days[-1].isoformat())).fetchone()['n']
            noms = ('Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim')
            week = [{'label': noms[x.weekday()], 'date': x.isoformat(), 'total': round(vals.get(x.isoformat(), 0) or 0, 2)} for x in days]
            top = max([w['total'] for w in week] + [0])
            for w in week:
                w['pct'] = 0 if top <= 0 else max(3, round(w['total'] / top * 100))
            d['week'] = {'days': week, 'total': round(sum(w['total'] for w in week), 2), 'has_data': have > 0}
            d['yesterday'] = week[-1]['total'] if have else None
    finally:
        conn.close()
    if is_admin:
        last, err = meta_get('fb_last'), meta_get('fb_last_error')
        d['backup'] = {'last': last, 'error': err,
                       'ok': bool(last) and (not err or err[:16] < last[:16])}
    if is_admin or 'license' in perms:
        try:
            st = get_license_status()
            d['license'] = {'active': bool(st.get('active')), 'days_left': st.get('days_left'),
                            'expires': (st.get('payload') or {}).get('expires')}
        except Exception:
            d['license'] = None
    return d




































































# ------------------------------------------------------------
# Routes — rapports personnalisés (1.12.0)
# ------------------------------------------------------------




























# ------------------------------------------------------------
# Routes — comptes à recevoir : factures Lightspeed + sauvegardes (1.11.0)
# ------------------------------------------------------------












# ------------------------------------------------------------
# Routes — sauvegardes des comptes de crédit (1.10.1)
# ------------------------------------------------------------




# ------------------------------------------------------------
# Routes — Lightspeed (1.10.0)
# ------------------------------------------------------------






































def _detect_lan_ip():
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))  # aucune donnée envoyée, juste pour détecter l'interface réseau
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return None


def start_app():
    """Point d'entrée commun : démarrage interactif (start.bat) ET démarrage
    comme service Windows (service.py) appellent cette même fonction, pour
    garantir exactement la même initialisation dans les deux cas."""
    print(f"Fichier Excel utilisé : {EXCEL_PATH}")
    if not EXCEL_PATH.exists():
        # Nouvelle installation (aucune donnée existante) : on part d'un
        # classeur vierge plutôt que de bloquer le démarrage.
        create_blank_excel_template(EXCEL_PATH)
    ensure_db_ready()
    app.secret_key = get_or_create_secret_key()
    app.config['PERMANENT_SESSION_LIFETIME'] = datetime.timedelta(days=30)
    ensure_admin_bootstrap()
    t = threading.Thread(target=_auto_sync_loop, name='_auto_sync_loop', daemon=True)
    t.start()
    threading.Thread(target=_net_time_loop, name='_net_time_loop', daemon=True).start()
    threading.Thread(target=_ls_auto_sync_loop, name='_ls_auto_sync_loop', daemon=True).start()
    threading.Thread(target=_nightly_loop, name='_nightly_loop', daemon=True).start()
    threading.Thread(target=_full_backup_loop, name='_full_backup_loop', daemon=True).start()
    threading.Thread(target=_inventory_loop, name='_inventory_loop', daemon=True).start()
    threading.Thread(target=_atelier_reread_loop, name='_atelier_reread_loop', daemon=True).start()
    threading.Thread(target=_ht_drop_loop, name='_ht_drop_loop', daemon=True).start()
    threading.Thread(target=version_snapshot, name='version_snapshot', daemon=True).start()
    start_health_monitor()
    ensure_three_vendor_async()

    print()
    print("=" * 60)
    print(f"Accès depuis CET ordinateur :  http://127.0.0.1:{APP_PORT}")
    lan_ip = _detect_lan_ip()
    if lan_ip:
        print(f"Accès depuis un AUTRE ordinateur du même réseau :")
        print(f"    http://{lan_ip}:{APP_PORT}")
        print("(Windows peut demander une autorisation de pare-feu la")
        print(" première fois — accepte pour le réseau 'Privé'.)")
    print("=" * 60)
    print()

    # Serveur de production (Waitress) au lieu du serveur de développement
    # Flask — celui-ci n'est pas conçu pour tourner sans surveillance en
    # tant que service et affiche un avertissement à cet effet.
    from waitress import serve
    serve(app, host='0.0.0.0', port=APP_PORT, threads=8)


if __name__ == '__main__':
    start_app()
