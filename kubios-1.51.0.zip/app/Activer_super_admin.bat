@echo off
chcp 65001 > nul
cd /d "%~dp0"
echo.
echo   Kubios - Super administrateur (fournisseur)
echo   -------------------------------------------
echo   A lancer seulement sur l'ordinateur serveur de Kubios.
echo   Le compte doit deja exister dans Kubios (Gestion - Utilisateurs).
echo.
set /p KUSER=Nom d'utilisateur a promouvoir : 
if "%KUSER%"=="" goto fin
if exist ".venv\Scripts\python.exe" (set PY=.venv\Scripts\python.exe) else (set PY=python)
%PY% kubios_sante.py --promouvoir "%KUSER%"
:fin
echo.
pause
