# -*- coding: utf-8 -*-
"""Licence : état du noyau et des modules, horloge de confiance.
Module du tronc commun de Kubios (découpé de app.py en 1.45.0, code inchangé)."""
import os, re, io, csv, sys, json, base64, hashlib, unicodedata, time, shutil, secrets, sqlite3, zipfile, threading, subprocess, datetime, traceback
import urllib.request, urllib.error, urllib.parse, email.utils
from pathlib import Path
from flask import request, session, has_request_context
import licensing
from kubios_base import db_add_audit, get_conn, meta_get, meta_set

__all__ = ['CLOCK_HIGH_WATER_KEY', 'CLOCK_TOLERANCE_DAYS', '_clock_alert_state', '_clock_high_water_get', '_clock_high_water_set', '_clock_hw_cache', '_clock_problem_message', '_license_core_status', '_net_time', '_net_time_lock', '_report_clock_problem', 'get_license_status', 'get_trusted_today', 'internet_today', 'license_module_active']


CLOCK_TOLERANCE_DAYS = 1


CLOCK_HIGH_WATER_KEY = 'clock_high_water'


_net_time_lock = threading.Lock()


_net_time = {'utc': None, 'mono': None}


_clock_hw_cache = {'value': None}


_clock_alert_state = {'logged': False}


def internet_today():
    """Date du jour selon Internet (convertie à l'heure locale), prolongée
    avec l'horloge monotone depuis la dernière vérification. None si l'heure
    Internet n'a jamais pu être obtenue depuis le démarrage."""
    with _net_time_lock:
        utc, mono = _net_time['utc'], _net_time['mono']
    if utc is None:
        return None
    now_utc = utc + datetime.timedelta(seconds=max(0.0, time.monotonic() - mono))
    return now_utc.astimezone().date()


def _clock_high_water_get():
    if _clock_hw_cache['value'] is not None:
        return _clock_hw_cache['value']
    hw = None
    raw = meta_get(CLOCK_HIGH_WATER_KEY)
    if raw:
        try:
            hw = datetime.date.fromisoformat(raw)
        except Exception:
            hw = None
    if hw is None:
        # Première utilisation : on part de l'action la plus récente du
        # journal d'audit (horodatée par l'app elle-même).
        try:
            conn = get_conn()
            row = conn.execute("SELECT MAX(substr(ts,1,10)) AS m FROM audit_log").fetchone()
            conn.close()
            if row and row['m']:
                hw = datetime.date.fromisoformat(row['m'])
        except Exception:
            hw = None
        if hw is not None:
            _clock_high_water_set(hw)
    _clock_hw_cache['value'] = hw
    return hw


def _clock_high_water_set(d):
    try:
        meta_set(CLOCK_HIGH_WATER_KEY, d.isoformat())
    except Exception:
        traceback.print_exc()
    _clock_hw_cache['value'] = d


def get_trusted_today():
    """Retourne (date_de_reference, horloge_ok, date_locale).
    - Avec Internet : la date Internet fait foi (et corrige au besoin la date
      mémorisée, par exemple si l'horloge avait été avancée par erreur).
    - Sans Internet : la plus récente entre la date locale et la date mémorisée.
    horloge_ok est False si la date de l'ordinateur est en retard de plus de
    CLOCK_TOLERANCE_DAYS sur la référence."""
    local = datetime.date.today()
    tol = datetime.timedelta(days=CLOCK_TOLERANCE_DAYS)
    hw = _clock_high_water_get()
    net = internet_today()
    if net is not None:
        if hw is None or hw < net or hw > net + tol:
            _clock_high_water_set(net)
        reference = net
        effective = net
    else:
        reference = hw
        if hw is None or local > hw:
            _clock_high_water_set(local)
        effective = max(local, hw) if hw else local
    clock_ok = reference is None or local >= reference - tol
    return effective, clock_ok, local


def _clock_problem_message(reference, local):
    return (f"La date de cet ordinateur ({local.isoformat()}) semble antérieure "
            f"à la date réelle ({reference.isoformat()}). Corrige la date et "
            f"l'heure de Windows, puis recharge la page.")


def _report_clock_problem(reference, local):
    if not _clock_alert_state['logged']:
        _clock_alert_state['logged'] = True
        db_add_audit('système', 'Horloge reculée détectée',
                     f"Date de l'ordinateur : {local.isoformat()} — date de référence : "
                     f"{reference.isoformat()}. Licence à durée limitée bloquée.")
        print(f"ATTENTION : horloge reculée détectée (ordinateur {local}, référence {reference}).")


def get_license_status():
    """État de la licence (noyau) + état de chaque module, mis en cache pour la requête en cours."""
    try:
        from flask import g, has_request_context
        if has_request_context() and getattr(g, '_kubios_lic', None) is not None:
            return g._kubios_lic
    except Exception:
        has_request_context = lambda: False
    st = _license_core_status()
    if st.get('payload') and st.get('reason') != 'clock':
        today = get_trusted_today()[0] if (st['payload'].get('modules') or st['payload'].get('expires')) else datetime.date.today()
        st['modules'] = licensing.modules_status(st['payload'], today)
    else:
        st['modules'] = {}
    try:
        if has_request_context():
            g._kubios_lic = st
    except Exception:
        pass
    return st


def license_module_active(key):
    """Vrai si la licence est active ET que le module (atelier, rh) est inclus et non expiré."""
    st = get_license_status()
    return bool(st.get('active')) and bool((st.get('modules') or {}).get(key, {}).get('active'))


def _license_core_status():
    """Revérifie la signature du code de licence stocké à chaque appel.
    Retourne un dict :
      {'active': True, 'payload': {...}, 'days_left': int|None}
      {'active': False, 'reason': 'none'|'invalid'|'expired'|'clock', 'error': str|None, 'payload': {...}|None}
    """
    code = meta_get('license_code', '')
    if not code:
        return {'active': False, 'reason': 'none', 'error': None, 'payload': None}
    result = licensing.verify_license_code(code)
    if not result['ok']:
        return {'active': False, 'reason': 'invalid', 'error': result['error'], 'payload': None}
    payload = result['payload']
    expires = payload.get('expires')
    if expires:
        try:
            exp_date = datetime.date.fromisoformat(expires)
        except Exception:
            return {'active': False, 'reason': 'invalid', 'error': "Date d'expiration illisible.", 'payload': None}
        today, clock_ok, local = get_trusted_today()
        if not clock_ok:
            _report_clock_problem(today, local)
            return {'active': False, 'reason': 'clock', 'payload': payload,
                    'error': _clock_problem_message(today, local)}
        _clock_alert_state['logged'] = False
        days_left = (exp_date - today).days
        if days_left < 0:
            return {'active': False, 'reason': 'expired', 'error': None, 'payload': payload}
        return {'active': True, 'payload': payload, 'days_left': days_left}
    return {'active': True, 'payload': payload, 'days_left': None}
