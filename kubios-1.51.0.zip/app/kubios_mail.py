# -*- coding: utf-8 -*-
"""Envoi des courriels (Outlook, SMTP, Microsoft 365) et journal des envois.
Module du tronc commun de Kubios (découpé de app.py en 1.45.0, code inchangé)."""
import os, re, io, csv, sys, json, base64, hashlib, unicodedata, time, shutil, secrets, sqlite3, zipfile, threading, subprocess, datetime, traceback
import urllib.request, urllib.error, urllib.parse, email.utils
from pathlib import Path
from flask import request, session, has_request_context
import licensing
from kubios_base import _at_now, get_company_email, get_company_name, get_conn, get_settings

__all__ = ['EMAIL_SECRET_WORDS', '_M365_TOKEN', '_email_category', '_email_sender', '_m365_error', '_m365_http', '_send_email_raw', 'email_log_add', 'm365_mailbox', 'm365_token', 'send_email', 'send_via_m365', 'send_via_outlook', 'send_via_smtp', 'test_smtp_connection']


def send_via_smtp(to_email, subject, body, pdf_path, settings, bcc_company=True, html=None):
    import smtplib
    from email.message import EmailMessage

    host = (settings.get('smtp_host') or '').strip()
    from_email = (settings.get('smtp_from_email') or '').strip()
    if not host or not from_email:
        raise RuntimeError(
            "Le serveur SMTP n'est pas configuré. Un administrateur doit le configurer "
            "dans 'Paramètres d'envoi'."
        )
    port = int(settings.get('smtp_port') or 587)
    username = (settings.get('smtp_username') or '').strip()
    password = settings.get('smtp_password') or ''
    encryption = settings.get('smtp_encryption') or 'starttls'
    from_name = (settings.get('smtp_from_name') or '').strip() or get_company_name()

    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = f"{from_name} <{from_email}>"
    msg['To'] = to_email
    if bcc_company and get_company_email():
        msg['Bcc'] = get_company_email()
    msg.set_content(body)
    if html:
        msg.add_alternative(html, subtype='html')
    if pdf_path:  # les courriels de sécurité (codes, liens) n'ont pas de pièce jointe
        with open(pdf_path, 'rb') as f:
            pdf_data = f.read()
        msg.add_attachment(pdf_data, maintype='application', subtype='pdf', filename=Path(pdf_path).name)

    if encryption == 'ssl':
        with smtplib.SMTP_SSL(host, port, timeout=30) as smtp:
            if username:
                smtp.login(username, password)
            smtp.send_message(msg)
    else:
        with smtplib.SMTP(host, port, timeout=30) as smtp:
            if encryption == 'starttls':
                smtp.starttls()
            if username:
                smtp.login(username, password)
            smtp.send_message(msg)
    return 'ENVOYÉ'


def test_smtp_connection(settings):
    """Vérifie la connexion/authentification SMTP sans envoyer de courriel."""
    import smtplib

    host = (settings.get('smtp_host') or '').strip()
    if not host:
        raise RuntimeError("Adresse du serveur SMTP manquante.")
    port = int(settings.get('smtp_port') or 587)
    username = (settings.get('smtp_username') or '').strip()
    password = settings.get('smtp_password') or ''
    encryption = settings.get('smtp_encryption') or 'starttls'

    if encryption == 'ssl':
        with smtplib.SMTP_SSL(host, port, timeout=15) as smtp:
            if username:
                smtp.login(username, password)
    else:
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            if encryption == 'starttls':
                smtp.starttls()
            if username:
                smtp.login(username, password)


_M365_TOKEN = {'key': None, 'tok': None, 'exp': 0}


def _m365_http(method, url, data=None, headers=None, form=False):
    import urllib.request, urllib.error, urllib.parse
    body = None
    h = dict(headers or {})
    if data is not None:
        if form:
            body = urllib.parse.urlencode(data).encode(); h['Content-Type'] = 'application/x-www-form-urlencoded'
        else:
            body = json.dumps(data).encode('utf-8'); h['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=body, method=method, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            raw = r.read()
            return r.status, (json.loads(raw) if raw else {})
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read() or b'{}')
        except ValueError:
            return e.code, {}


def _m365_error(code, js):
    err = js.get('error') if isinstance(js.get('error'), dict) else {}
    desc = js.get('error_description') or err.get('message') or ''
    c = js.get('error') if isinstance(js.get('error'), str) else err.get('code', '')
    if 'AADSTS7000215' in desc or 'invalid_client' in str(c):
        return "Microsoft 365 refuse l'accès : le secret client est invalide ou expiré (Entra ID → Inscriptions d'applications → Certificats et secrets)."
    if 'AADSTS700016' in desc or 'AADSTS90002' in desc:
        return "Microsoft 365 ne trouve pas l'application ou le locataire : vérifie l'ID du locataire (tenant) et l'ID de l'application (client)."
    if code == 403 or c in ('ErrorAccessDenied', 'Authorization_RequestDenied'):
        return ("Microsoft 365 refuse l'accès à cette boîte : dans Exchange Online, l'application doit avoir les rôles « Application Mail.Send » "
                "et « Application Mail.ReadWrite » sur une étendue qui inclut cette boîte (le changement peut prendre jusqu'à 2 heures).")
    if code == 404 or c in ('ErrorInvalidUser', 'ResourceNotFound', 'MailboxNotEnabledForRESTAPI'):
        return "Microsoft 365 ne trouve pas cette boîte de courriel : vérifie l'adresse (boîte partagée ou boîte de Kubios)."
    return f"Microsoft 365 a refusé la demande ({code}) : {desc or c or 'erreur inconnue'}"


def m365_token(settings):
    t, cid, sec = (settings.get('m365_tenant') or '').strip(), (settings.get('m365_client_id') or '').strip(), settings.get('m365_secret') or ''
    if not (t and cid and sec):
        raise RuntimeError("Microsoft 365 n'est pas configuré : un administrateur doit entrer le locataire, l'application et le secret dans « Paramètres d'envoi ».")
    key = (t, cid, hashlib.sha256(sec.encode()).hexdigest())
    if _M365_TOKEN['key'] == key and _M365_TOKEN['exp'] > time.time() + 60:
        return _M365_TOKEN['tok']
    code, js = _m365_http('POST', f"https://login.microsoftonline.com/{t}/oauth2/v2.0/token",
                          {'client_id': cid, 'client_secret': sec, 'scope': 'https://graph.microsoft.com/.default', 'grant_type': 'client_credentials'}, form=True)
    if code != 200 or 'access_token' not in js:
        raise RuntimeError(_m365_error(code, js))
    _M365_TOKEN.update(key=key, tok=js['access_token'], exp=time.time() + int(js.get('expires_in') or 3000))
    return js['access_token']


def m365_mailbox(settings, purpose):
    mb = (settings.get('m365_mailbox_ar') or '').strip() if purpose == 'ar' else ''
    mb = mb or (settings.get('m365_mailbox_general') or '').strip()
    if not mb:
        raise RuntimeError("Aucune boîte Microsoft 365 n'est définie pour l'envoi : un administrateur doit la choisir dans « Paramètres d'envoi ».")
    return mb


def send_via_m365(to_email, subject, body, pdf_path, settings, mode='send', bcc_company=True, purpose='general', html=None):
    import urllib.parse
    tok = m365_token(settings)
    mb = m365_mailbox(settings, purpose)
    msg = {'subject': subject, 'body': {'contentType': 'HTML', 'content': html} if html else {'contentType': 'Text', 'content': body},
           'toRecipients': [{'emailAddress': {'address': a.strip()}} for a in re.split(r'[;,]', to_email or '') if a.strip()]}
    bcc = []
    if bcc_company and get_company_email() and get_company_email().lower() != mb.lower():
        bcc.append(get_company_email())
    rt = (settings.get('m365_ar_reply_to') or '').strip() if purpose == 'ar' else ''
    if rt:                                              # réponses des clients dirigées vers la boîte / le groupe des recevables
        msg['replyTo'] = [{'emailAddress': {'address': rt}}]
        if settings.get('m365_ar_copy') == '1' and rt.lower() not in [b.lower() for b in bcc] and mode not in ('draft', 'draft_silent'):
            bcc.append(rt)
    if bcc:
        msg['bccRecipients'] = [{'emailAddress': {'address': b}} for b in bcc]
    if pdf_path:
        with open(pdf_path, 'rb') as f:
            msg['attachments'] = [{'@odata.type': '#microsoft.graph.fileAttachment', 'name': Path(pdf_path).name,
                                   'contentType': 'application/pdf', 'contentBytes': base64.b64encode(f.read()).decode('ascii')}]
    base = f"https://graph.microsoft.com/v1.0/users/{urllib.parse.quote(mb)}"
    auth = {'Authorization': f'Bearer {tok}'}
    if mode in ('draft', 'draft_silent'):
        code, js = _m365_http('POST', base + '/messages', msg, auth)          # brouillon dans la boîte (dossier Brouillons)
        if code not in (200, 201):
            raise RuntimeError(_m365_error(code, js))
        return f'BROUILLON ({mb})'
    code, js = _m365_http('POST', base + '/sendMail', {'message': msg, 'saveToSentItems': True}, auth)
    if code not in (200, 202):
        raise RuntimeError(_m365_error(code, js))
    return 'ENVOYÉ'


EMAIL_SECRET_WORDS = ('code', 'mot de passe', 'vérification', 'verification', 'connexion', 'espace employé', 'nouveau mot de passe')


def _email_category(subject, purpose, category):
    if category:
        return category
    sl = (subject or '').lower()
    if purpose == 'ar' or 'état de compte' in sl or 'etat de compte' in sl:
        return 'États de compte'
    if any(w in sl for w in EMAIL_SECRET_WORDS):
        return 'Sécurité'
    for k, lbl in (('horaire', 'Horaires'), ('congé', 'Congés'), ('rapport', 'Rapports'), ('inventaire', 'Inventaire'), ('sauvegarde', 'Sauvegardes'),
                   ('test', 'Tests'), ('atelier', 'Atelier'), ('problème', 'Atelier')):
        if k in sl:
            return lbl
    return 'Autres'


def _email_sender(settings, purpose):
    m = settings.get('send_mode')
    if m == 'm365':
        try:
            return m365_mailbox(settings, purpose)
        except Exception:
            return '(boîte non configurée)'
    if m == 'smtp':
        return (settings.get('smtp_from_email') or '').strip() or '(SMTP)'
    return 'Outlook du poste Kubios'


def email_log_add(method, sender, to_email, subject, category, attachment, mode, status, error, summary):
    try:
        who = None
        try:
            from flask import has_request_context
            if has_request_context():
                who = session.get('username') or (f"portail #{session.get('emp_id')}" if session.get('emp_id') else None)
        except Exception:
            pass
        conn = get_conn()
        try:
            conn.execute("INSERT INTO email_log(ts, method, sender, recipient, subject, category, attachment, mode, status, error, username, summary) "
                         "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (_at_now(), method, sender, (to_email or '')[:300], (subject or '')[:300], category, attachment, mode,
                                                         status, (error or '')[:500] or None, who or 'Kubios (automatique)', summary))
            conn.commit()
        finally:
            conn.close()
    except Exception:
        traceback.print_exc()


def send_email(to_email, subject, body, pdf_path, mode='draft', bcc_company=True, purpose='general', html=None, category=None):
    """Envoie par la méthode choisie (Outlook, SMTP ou Microsoft 365) et note l'envoi au journal des envois."""
    settings = get_settings()
    cat = _email_category(subject, purpose, category)
    summary = '(contenu confidentiel non conservé)' if cat == 'Sécurité' else re.sub(r'\s+', ' ', body or '').strip()[:400]
    method = {'m365': 'Microsoft 365', 'smtp': 'SMTP'}.get(settings.get('send_mode'), 'Outlook')
    try:
        res = _send_email_raw(to_email, subject, body, pdf_path, mode=mode, bcc_company=bcc_company, purpose=purpose, html=html)
    except Exception as e:
        email_log_add(method, _email_sender(settings, purpose), to_email, subject, cat, Path(pdf_path).name if pdf_path else None,
                      mode, 'erreur', str(e), summary)
        raise
    email_log_add(method, _email_sender(settings, purpose), to_email, subject, cat, Path(pdf_path).name if pdf_path else None,
                  mode, 'brouillon' if str(res or '').upper().startswith('BROUILLON') or mode in ('draft', 'draft_silent') else 'envoyé', None, summary)
    return res


def _send_email_raw(to_email, subject, body, pdf_path, mode='draft', bcc_company=True, purpose='general', html=None):
    """Point d'entrée unique pour l'envoi : bascule vers Outlook ou SMTP selon les
    paramètres configurés par un administrateur. Le SMTP n'a pas de concept de
    brouillon/relecture — un appel avec mode='draft*' en mode SMTP est refusé plus haut,
    avant d'arriver ici (voir les routes)."""
    settings = get_settings()
    if settings['send_mode'] == 'm365':
        return send_via_m365(to_email, subject, body, pdf_path, settings, mode=mode, bcc_company=bcc_company, purpose=purpose, html=html)
    if settings['send_mode'] == 'smtp':
        return send_via_smtp(to_email, subject, body, pdf_path, settings, bcc_company=bcc_company, html=html)
    return send_via_outlook(to_email, subject, body, pdf_path, mode=mode, bcc_company=bcc_company, html=html)


def send_via_outlook(to_email, subject, body, pdf_path, mode='draft', bcc_company=True, html=None):
    """mode: 'send' envoie directement, 'draft' ouvre le courriel dans Outlook pour
    relecture, 'draft_silent' l'enregistre dans le dossier Brouillons sans ouvrir de
    fenêtre (utilisé pour la création en lot de plusieurs brouillons à la fois)."""
    import win32com.client as win32
    outlook = win32.Dispatch('outlook.application')
    mail = outlook.CreateItem(0)
    mail.To = to_email
    if bcc_company and get_company_email():
        mail.BCC = get_company_email()
    mail.Subject = subject
    if html:
        mail.HTMLBody = html
    else:
        mail.Body = body
    if pdf_path:
        mail.Attachments.Add(str(pdf_path))
    if mode == 'send':
        mail.Send()
        return 'ENVOYÉ'
    elif mode == 'draft_silent':
        mail.Save()
        return 'BROUILLON'
    else:
        mail.Display()
        return 'BROUILLON'
