# -*- coding: utf-8 -*-
"""Pages des rapports : ventes, taxes, valeur de l'inventaire, tableau de bord 3D, envois automatiques.
Module de Kubios (découpé de app.py en 1.49.0, code inchangé)."""
import os
import re
import io
import csv
import sys
import json
import base64
import hashlib
import unicodedata
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import openpyxl
from openpyxl.utils import get_column_letter
import licensing
from kubios_base import db_add_audit, get_company_email, get_company_name, get_conn, get_settings, meta_get, meta_set
from kubios_mail import send_email
from kubios_pdf import LOGO_PATH, REPORT_DISCLAIMER, REPORT_DISCLAIMER_TITLE, _pdf_disclaimer
from kubios_app import app
from kubios_auth import admin_required_check, log_audit, permission_required_check
from kubios_systeme import three_local_ready
from kubios_atelier_outils import store_missing_days
from kubios_rh_outils import PDF_DIR, _MOIS_FR, _d
from kubios_lightspeed import (
    LightspeedError, TAX_DEFAULT_NAMES, TAX_EPS, _ls_as_list, _ls_get_all, _parse_money, _store_lock,
    _store_refresh_refs, _store_state, _tax_pct, _truthy, ls_config, ls_fetch_account, start_store_job,
    store_sync_days,
)
from kubios_outils import _fmt_money_fr, ensure_three_vendor_async

__all__ = ['INV_METHODS', 'REP_GL_DEFAULT', 'REP_MISC', 'REP_NO_CATEGORY', 'STORE_DEFAULT_START', '_EMAIL_RE', '_canon_tax_name', '_d3_allowed', '_finish_rows', '_gl_for_category', '_inv_item_cost', '_inv_item_price', '_inv_item_qoh', '_inv_lock', '_inv_state', '_rep_dates', '_rep_period_label', '_rep_run_local', '_rep_state', '_report_email_body', '_send_now_days', '_send_now_state', '_send_now_worker', '_shop_name', '_store_rows', '_xlsx_disclaimer', 'api_dashboard3d_data', 'api_inventory_delete', 'api_inventory_get', 'api_inventory_pdf', 'api_inventory_send', 'api_inventory_settings', 'api_inventory_status', 'api_inventory_take', 'api_reports_export', 'api_reports_gl', 'api_reports_history_start', 'api_reports_nightly_run', 'api_reports_sales_by_category', 'api_reports_send', 'api_reports_send_now', 'api_reports_settings', 'api_reports_status', 'api_reports_weekly', 'api_reports_weekly_export', 'api_taxes_export_pdf', 'api_taxes_report', 'api_taxes_status', 'ar_allowed', 'custom_reports_page', 'dashboard3d_data', 'dashboard3d_page', 'db_inventory_history', 'db_inventory_snapshot', 'export_comparison_pdf', 'export_comparison_xlsx', 'export_inventory_pdf', 'export_report_pdf', 'export_report_xlsx', 'export_tax_pdf', 'inv_cfg', 'inventory_report_page', 'last_week_bounds', 'local_sales_by_category', 'local_tax_report', 'meta_delete', 'nightly_reports_run', 'rep_accounting_layout', 'rep_gl_cfg', 'rep_payments', 'rep_taxes', 'send_inventory_email', 'send_report_email', 'start_inventory_job', 'store_cfg', 'store_status', 'take_inventory_snapshot', 'tax_report_page', 'weekly_comparison']


def _xlsx_disclaimer(ws):
    """Avis à la fin d'une feuille Excel de rapport."""
    from openpyxl.styles import Font, Alignment
    r = ws.max_row + 2
    c = ws.cell(row=r, column=1, value=f"{REPORT_DISCLAIMER_TITLE} — {REPORT_DISCLAIMER}")
    c.font = Font(italic=True, size=9, color='4B5563')
    c.alignment = Alignment(wrap_text=True, vertical='top')
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=max(4, min(ws.max_column, 10)))
    ws.row_dimensions[r].height = 48


def ar_allowed():
    return bool(session.get('is_admin')) or 'comptes_recevoir' in (session.get('permissions') or [])


def meta_delete(*keys):
    conn = get_conn()
    for k in keys:
        conn.execute("DELETE FROM meta WHERE key=?", (k,))
    conn.commit()
    conn.close()


_rep_state = {'running': False, 'progress': '', 'error': None, 'result': None, 'comparison': None, 'taxes': None, 'by': None}


REP_NO_CATEGORY = "(Sans catégorie)"


REP_MISC = "(Articles divers, sans fiche)"


def _rep_period_label(r):
    def d(x):
        return f"{x[8:10]}-{x[5:7]}-{x[:4]}"
    lbl = f"Du {d(r['start'])} au {d(r['end'])}" if r['start'] != r['end'] else f"Le {d(r['start'])}"
    if r.get('shop_name'):
        lbl += f" — {r['shop_name']}"
    lbl += " — " + ("catégories principales" if r['level'] == 'top' else "catégories complètes")
    return lbl


def export_report_xlsx(r):
    """Même mise en page comptable que le PDF (1.23.0) : vraies valeurs numériques."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    if 'payments' not in r:
        r = rep_accounting_layout(dict(r))
    wb = Workbook()
    ws = wb.active
    ws.title = "Ventes par catégorie"
    money, pctf = '#,##0.00 $;-#,##0.00 $', '0.0%'
    head_fill, sub_fill, tot_fill = PatternFill('solid', fgColor='1E3A8A'), PatternFill('solid', fgColor='F1F5F9'), PatternFill('solid', fgColor='DBE3F3')
    ws['A1'] = get_company_name(); ws['A1'].font = Font(bold=True, size=15)
    ws['A2'] = r['title']; ws['A2'].font = Font(bold=True, size=12)
    ws['A3'] = _rep_period_label(r)
    g = r['generated_at']
    ws['A4'] = f"{r['sales_count']} vente(s) — généré le {g[8:10]}-{g[5:7]}-{g[:4]} à {g[11:16]} par {r['by'] or '?'}"
    row = 6

    def section(title):
        nonlocal row
        ws.cell(row=row, column=1, value=title).font = Font(bold=True, size=12, color='1E3A8A')
        row += 1

    def header(labels):
        nonlocal row
        for j, lbl in enumerate(labels, start=1):
            c = ws.cell(row=row, column=j, value=lbl)
            c.font = Font(bold=True, color='FFFFFF'); c.fill = head_fill
            c.alignment = Alignment(horizontal='left' if j <= 2 else 'right', wrap_text=True)
        row += 1

    def put(values, fmts, fill=None, bold=False):
        nonlocal row
        for j, (v, f) in enumerate(zip(values, fmts), start=1):
            c = ws.cell(row=row, column=j, value=v)
            if f: c.number_format = f
            if fill: c.fill = fill
            if bold: c.font = Font(bold=True)
        row += 1

    section("1. Ventes par catégorie d'articles (avec comptes GL)")
    header(["Compte GL", "Catégorie", "Qté", "Sous-total", "Rabais", "Total", "Coût", "Profit", "Marge", "% des ventes"])
    fm = [None, None, '#,##0.##', money, money, money, money, money, pctf, pctf]
    vals = lambda x, name: [x.get('gl') or '', name, x['quantite'], x['sous_total'], x['rabais'], x['total'], x['cout'], x['profit'],
                            None if x.get('marge') is None else x['marge'] / 100, None if x.get('part') is None else x['part'] / 100]
    for k, x in enumerate(r['rows']):
        put(vals(x, x['categorie']), fm)
        if r.get('subtotal') and k == r.get('group_count', 0) - 1:
            put(vals(dict(r['subtotal'], gl=''), r['subtotal']['categorie']), fm, sub_fill, True)
    put(vals(dict(r['totals'], gl=''), 'TOTAL DES VENTES'), fm, tot_fill, True)
    row += 1
    section("2. Répartition par mode de paiement")
    header(["Compte GL", "Mode de paiement", "Total perçu", "% du total"])
    for p in r['payments']:
        put([p['gl'], p['mode'], p['montant'], None if p['part'] is None else p['part'] / 100], [None, None, money, pctf])
    put(['', 'TOTAL PERÇU (taxes incluses)', r['payments_total'], 1 if r['payments'] else None], [None, None, money, pctf], tot_fill, True)
    row += 1
    section("3. Ventilation des taxes (type de taxes)")
    header(["Compte GL", "Type de taxe", "Taux", "Montant de base taxable", "Taxe calculée"])
    for x in r['taxes']:
        put([x['gl'], x['type'], x['taux'] / 100, x['base'], x['taxe']], [None, None, '0.000%', money, money])
    put(['', 'TOTAL DES TAXES', None, None, r['taxes_total']], [None, None, None, None, money], tot_fill, True)
    row += 1
    put(['', 'Grand total (facturé aux clients)', None, None, r['grand_total']], [None, None, None, None, money], PatternFill('solid', fgColor='FEF3C7'), True)
    ws.column_dimensions['A'].width = 11
    ws.column_dimensions['B'].width = 44
    for col in 'CDEFGHIJ':
        ws.column_dimensions[col].width = 15
    out = PDF_DIR / "Rapports_personnalises"
    out.mkdir(exist_ok=True)
    path = out / f"Ventes_par_categorie_{r['start']}_au_{r['end']}.xlsx"
    for ws_ in wb.worksheets:
        _xlsx_disclaimer(ws_)
    wb.save(path)
    return path


def export_report_pdf(r):
    """Rapport de ventes par catégorie, mise en page comptable (1.23.0)."""
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, KeepTogether
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader
    if 'payments' not in r:
        r = rep_accounting_layout(dict(r))
    out = PDF_DIR / "Rapports_personnalises"
    out.mkdir(exist_ok=True)
    path = out / f"Ventes_par_categorie_{r['start']}_au_{r['end']}.pdf"
    page_w, page_h = letter
    lm = rm = 12 * mm
    styles = getSampleStyleSheet()
    cell = ParagraphStyle('c', parent=styles['Normal'], fontSize=7.5, leading=9)
    cellb = ParagraphStyle('cb', parent=cell, fontName='Helvetica-Bold')
    h2 = ParagraphStyle('h2', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=11, spaceBefore=6, spaceAfter=5,
                        textColor=colors.HexColor('#1e3a8a'))
    lvl = 'catégories principales' if r.get('level') == 'top' else 'catégories complètes'
    period = (f"Le {_d(r['start'])}" if r['start'] == r['end'] else f"Du {_d(r['start'])} au {_d(r['end'])}") \
        + (f" — {r['shop_name']}" if r.get('shop_name') else '') + f" — {lvl}"
    g = r['generated_at']
    esc_ = lambda t: str(t).replace('&', '&amp;').replace('<', '&lt;')

    def money(v):
        return '' if v is None else f"{v:,.2f} $".replace(',', ' ').replace('.', ',')

    def pct(v):
        return '' if v is None else f"{v:.1f} %".replace('.', ',')

    def qty(q):
        return f"{q:,.0f}".replace(',', ' ') if float(q).is_integer() else f"{q:,.2f}".replace(',', ' ').replace('.', ',')

    def header(canvas, doc_):
        canvas.saveState()
        top = page_h - 14 * mm
        canvas.setFont('Helvetica-Bold', 17)
        canvas.drawString(lm, top, get_company_name())
        canvas.setFont('Helvetica-Bold', 11.5)
        canvas.drawString(lm, top - 7 * mm, r['title'])
        canvas.setFont('Helvetica', 9)
        canvas.drawString(lm, top - 12.5 * mm, period)
        canvas.drawString(lm, top - 17 * mm, f"{r['sales_count']} vente(s) — généré le {g[8:10]}-{g[5:7]}-{g[:4]} à {g[11:16]}")
        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            lw = 40 * mm
            canvas.drawImage(img, page_w - rm - lw, top - lw * ih / iw + 4 * mm, width=lw, height=lw * ih / iw, mask='auto')
        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.line(lm, top - 21 * mm, page_w - rm, top - 21 * mm)
        canvas.setFont('Helvetica', 7.5)
        canvas.drawString(lm, 8 * mm, f"{get_company_name()} — {r['title']} — {period}")
        canvas.drawRightString(page_w - rm, 8 * mm, f"Page {doc_.page}")
        canvas.restoreState()

    base = [('FONTSIZE', (0, 0), (-1, -1), 7.5), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('LINEBELOW', (0, 0), (-1, -1), 0.25, colors.HexColor('#d1d5db')),
            ('TOPPADDING', (0, 0), (-1, -1), 3), ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'), ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e3a8a'))]
    total_style = lambda row: [('FONTNAME', (0, row), (-1, row), 'Helvetica-Bold'), ('BACKGROUND', (0, row), (-1, row), colors.HexColor('#dbe3f3')),
                               ('LINEABOVE', (0, row), (-1, row), 0.8, colors.HexColor('#1e3a8a'))]
    sub_style = lambda row: [('FONTNAME', (0, row), (-1, row), 'Helvetica-Bold'), ('BACKGROUND', (0, row), (-1, row), colors.HexColor('#f1f5f9'))]
    story = [Paragraph("1. Ventes par catégorie d'articles (avec comptes GL)", h2)]
    data = [["Compte GL", "Catégorie", "Qté", "Sous-total", "Rabais", "Total", "Coût", "Profit", "Marge", "% ventes"]]
    st = list(base)
    line = lambda x, name, bold=False: [x.get('gl', '') or '—', Paragraph(esc_(name), cellb if bold else cell), qty(x['quantite']),
                                        money(x['sous_total']), money(x['rabais']), money(x['total']), money(x['cout']),
                                        money(x['profit']), pct(x['marge']), pct(x['part'])]
    n_grp = r.get('group_count', 0)
    for k, x in enumerate(r['rows']):
        data.append(line(x, x['categorie']))
        if r.get('subtotal') and k == n_grp - 1:
            data.append(line(dict(r['subtotal'], gl='—'), r['subtotal']['categorie'], True))
            st += sub_style(len(data) - 1)
    T = dict(r['totals'], gl='—')
    data.append(line(T, 'TOTAL DES VENTES', True))
    st += total_style(len(data) - 1) + [('ALIGN', (2, 0), (-1, -1), 'RIGHT')]
    t = Table(data, colWidths=[16 * mm, 40 * mm, 12 * mm, 20 * mm, 16 * mm, 20 * mm, 20 * mm, 19 * mm, 14 * mm, 15 * mm], repeatRows=1)
    t.setStyle(TableStyle(st))
    story.append(t)

    data = [["Compte GL", "Mode de paiement", "Total perçu", "% du total"]]
    for p in r['payments']:
        data.append([p['gl'] or '—', Paragraph(esc_(p['mode']), cell), money(p['montant']), pct(p['part'])])
    if not r['payments']:
        data.append(['', Paragraph("Aucun paiement gardé pour cette période (relis la période dans Lightspeed).", cell), '', ''])
    data.append(['—', Paragraph('TOTAL PERÇU', cellb), money(r['payments_total']), '100,0 %' if r['payments'] else ''])
    t = Table(data, colWidths=[22 * mm, 80 * mm, 34 * mm, 26 * mm], repeatRows=1)
    t.setStyle(TableStyle(base + total_style(len(data) - 1) + [('ALIGN', (2, 0), (-1, -1), 'RIGHT')]))
    story.append(KeepTogether([Spacer(1, 6 * mm), Paragraph("2. Répartition par mode de paiement", h2), t,
                               Paragraph("Montants payés par les clients, taxes incluses.", ParagraphStyle('n', parent=cell, textColor=colors.HexColor('#6b7280'), spaceBefore=3))]))

    data = [["Compte GL", "Type de taxe", "Taux", "Montant de base taxable", "Taxe calculée"]]
    for x in r['taxes']:
        data.append([x['gl'] or '—', x['type'], f"{x['taux']:g} %".replace('.', ','), money(x['base']), money(x['taxe'])])
    data.append(['—', Paragraph('TOTAL DES TAXES', cellb), '—', '—', money(r['taxes_total'])])
    t = Table(data, colWidths=[22 * mm, 56 * mm, 20 * mm, 40 * mm, 34 * mm], repeatRows=1)
    t.setStyle(TableStyle(base + total_style(len(data) - 1) + [('ALIGN', (2, 0), (-1, -1), 'RIGHT')]))
    gt = Table([[Paragraph('<b>Grand total (facturé aux clients)</b>', ParagraphStyle('g', parent=styles['Normal'], fontSize=11)),
                 Paragraph(f"<b>{money(r['grand_total'])}</b>", ParagraphStyle('g2', parent=styles['Normal'], fontSize=12, alignment=2))]],
               colWidths=[120 * mm, 52 * mm])
    gt.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#fef3c7')), ('BOX', (0, 0), (-1, -1), 0.8, colors.HexColor('#d97706')),
                            ('TOPPADDING', (0, 0), (-1, -1), 7), ('BOTTOMPADDING', (0, 0), (-1, -1), 7), ('LEFTPADDING', (0, 0), (-1, -1), 8)]))
    story.append(KeepTogether([Spacer(1, 6 * mm), Paragraph("3. Ventilation des taxes (type de taxes)", h2), t, Spacer(1, 6 * mm), gt]))
    doc = SimpleDocTemplate(str(path), pagesize=letter, leftMargin=lm, rightMargin=rm, topMargin=40 * mm, bottomMargin=16 * mm)
    story.append(_pdf_disclaimer())
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


STORE_DEFAULT_START = '2024-01-01'


def store_cfg():
    try:
        recipients = json.loads(meta_get('rep_recipients') or '[]')
    except ValueError:
        recipients = []
    try:
        hour = min(max(int(meta_get('rep_nightly_hour') or 1), 0), 23)
    except ValueError:
        hour = 1
    return {'enabled': meta_get('rep_store_enabled') != '0',
            'start': meta_get('rep_history_start') or STORE_DEFAULT_START,
            'hour': hour,
            'auto_daily': meta_get('rep_auto_daily') == '1',
            'auto_weekly': meta_get('rep_auto_weekly') == '1',
            'daily_level': 'top' if meta_get('rep_daily_level') == 'top' else 'full',
            'weekly_level': 'full' if meta_get('rep_weekly_level') == 'full' else 'top',
            'bcc_company': meta_get('rep_bcc_company') == '1',
            'recipients': recipients}


def store_status():
    conn = get_conn()
    r = conn.execute("SELECT COUNT(*) n, MIN(day) a, MAX(day) b, SUM(sales_count) s FROM sales_days WHERE complete=1").fetchone()
    lines = conn.execute("SELECT COUNT(*) n FROM sales_lines").fetchone()['n']
    conn.close()
    cfg = store_cfg()
    try:
        start = datetime.date.fromisoformat(cfg['start'])
    except ValueError:
        start = datetime.date.fromisoformat(STORE_DEFAULT_START)
    yesterday = datetime.date.today() - datetime.timedelta(days=1)
    missing = len(store_missing_days(start, yesterday)) if start <= yesterday else 0
    return {'days': r['n'], 'first': r['a'], 'last': r['b'], 'sales': r['s'] or 0, 'lines': lines,
            'missing': missing, 'start': cfg['start'],
            'last_nightly': meta_get('rep_last_nightly'), 'last_nightly_error': meta_get('rep_last_nightly_error')}


def _store_rows(conn, d0, d1, shop_id, level):
    cats = {r['category_id']: r['path'] for r in conn.execute("SELECT category_id, path FROM ls_categories")}
    q = ("SELECT item_id, category_id, SUM(qty) q, SUM(subtotal) s, SUM(discount) d, SUM(total) t, SUM(cost) c, "
         "COUNT(*) n FROM sales_lines WHERE sale_date BETWEEN ? AND ?")
    args = [d0.isoformat(), d1.isoformat()]
    if shop_id:
        q += " AND shop_id=?"
        args.append(str(shop_id))
    agg = {}
    for r in conn.execute(q + " GROUP BY item_id='0', category_id", args).fetchall():
        if r['item_id'] == '0':
            key = REP_MISC
        else:
            path = cats.get(r['category_id'] or '')
            key = REP_NO_CATEGORY if path is None else (path.split('/')[0].strip() if level == 'top' else path)
        a = agg.setdefault(key, {'categorie': key, 'quantite': 0.0, 'sous_total': 0.0, 'rabais': 0.0,
                                 'total': 0.0, 'cout': 0.0, 'lignes': 0})
        for k, col in (('quantite', 'q'), ('sous_total', 's'), ('rabais', 'd'), ('total', 't'), ('cout', 'c')):
            a[k] += r[col] or 0
        a['lignes'] += r['n']
    return agg


def _finish_rows(agg):
    rows = sorted(agg.values(), key=lambda r: -r['total'])
    grand = {k: round(sum(r[k] for r in rows), 2) for k in ('quantite', 'sous_total', 'rabais', 'total', 'cout')}
    grand['lignes'] = sum(r['lignes'] for r in rows)
    for r in rows + [grand]:
        for k in ('quantite', 'sous_total', 'rabais', 'total', 'cout'):
            r[k] = round(r[k], 2)
        r['profit'] = round(r['total'] - r['cout'], 2)
        r['marge'] = round(r['profit'] / r['total'] * 100, 1) if abs(r['total']) >= 0.005 else None
        r['part'] = round(r['total'] / grand['total'] * 100, 1) if abs(grand['total']) >= 0.005 else None
    return rows, grand


def _shop_name(shop_id):
    if not shop_id:
        return ''
    conn = get_conn()
    r = conn.execute("SELECT name FROM ls_shops WHERE shop_id=?", (str(shop_id),)).fetchone()
    conn.close()
    return r['name'] if r else f"#{shop_id}"


def local_sales_by_category(d0, d1, shop_id='', level='full', username=None):
    conn = get_conn()
    try:
        rows, grand = _finish_rows(_store_rows(conn, d0, d1, shop_id, level))
        n = conn.execute("SELECT COUNT(DISTINCT sale_id) n FROM sales_lines WHERE sale_date BETWEEN ? AND ?"
                         + (" AND shop_id=?" if shop_id else ""),
                         [d0.isoformat(), d1.isoformat()] + ([str(shop_id)] if shop_id else [])).fetchone()['n']
    finally:
        conn.close()
    return rep_accounting_layout({'report': 'ventes_par_categorie', 'title': "Rapport de ventes par catégorie d'articles",
            'start': d0.isoformat(), 'end': d1.isoformat(), 'shop_id': shop_id or '', 'shop_name': _shop_name(shop_id),
            'level': level, 'rows': rows, 'totals': grand, 'sales_count': n,
            'generated_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'by': username})


def last_week_bounds(ref=None):
    """Lundi et dimanche de la dernière semaine complète."""
    ref = ref or datetime.date.today()
    monday = ref - datetime.timedelta(days=ref.weekday())
    return monday - datetime.timedelta(days=7), monday - datetime.timedelta(days=1)


def weekly_comparison(week_start, shop_id='', level='top', username=None):
    """Compare la semaine (lundi -> dimanche) à la même semaine 52 semaines plus tôt."""
    a0, a1 = week_start, week_start + datetime.timedelta(days=6)
    b0, b1 = a0 - datetime.timedelta(days=364), a1 - datetime.timedelta(days=364)
    conn = get_conn()
    try:
        cur, _ = _finish_rows(_store_rows(conn, a0, a1, shop_id, level))
        prev, _ = _finish_rows(_store_rows(conn, b0, b1, shop_id, level))
        days = []
        for i in range(7):
            da, db_ = a0 + datetime.timedelta(days=i), b0 + datetime.timedelta(days=i)
            qa = conn.execute("SELECT COALESCE(SUM(total),0) t, COUNT(DISTINCT sale_id) n FROM sales_lines WHERE sale_date=?"
                              + (" AND shop_id=?" if shop_id else ""), [da.isoformat()] + ([str(shop_id)] if shop_id else [])).fetchone()
            qb = conn.execute("SELECT COALESCE(SUM(total),0) t, COUNT(DISTINCT sale_id) n FROM sales_lines WHERE sale_date=?"
                              + (" AND shop_id=?" if shop_id else ""), [db_.isoformat()] + ([str(shop_id)] if shop_id else [])).fetchone()
            days.append({'jour': ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'][i],
                         'date': da.isoformat(), 'date_prec': db_.isoformat(),
                         'total': round(qa['t'], 2), 'total_prec': round(qb['t'], 2),
                         'ventes': qa['n'], 'ventes_prec': qb['n']})
    finally:
        conn.close()
    pa = {r['categorie']: r for r in cur}
    pb = {r['categorie']: r for r in prev}

    def var(a, b):
        return round((a - b) / abs(b) * 100, 1) if abs(b) >= 0.005 else None
    rows = []
    for k in set(pa) | set(pb):
        a, b = pa.get(k, {}), pb.get(k, {})
        ta, tb = a.get('total', 0.0), b.get('total', 0.0)
        rows.append({'categorie': k, 'total': ta, 'total_prec': tb, 'ecart': round(ta - tb, 2), 'variation': var(ta, tb),
                     'profit': a.get('profit', 0.0), 'profit_prec': b.get('profit', 0.0),
                     'marge': a.get('marge'), 'marge_prec': b.get('marge'),
                     'quantite': a.get('quantite', 0.0), 'quantite_prec': b.get('quantite', 0.0)})
    rows.sort(key=lambda r: -max(r['total'], r['total_prec']))
    T = {k: round(sum(r[k] for r in rows), 2) for k in ('total', 'total_prec', 'profit', 'profit_prec', 'quantite', 'quantite_prec')}
    T['ecart'] = round(T['total'] - T['total_prec'], 2)
    T['variation'] = var(T['total'], T['total_prec'])
    T['marge'] = round(T['profit'] / T['total'] * 100, 1) if abs(T['total']) >= 0.005 else None
    T['marge_prec'] = round(T['profit_prec'] / T['total_prec'] * 100, 1) if abs(T['total_prec']) >= 0.005 else None
    T['ventes'] = sum(d['ventes'] for d in days)
    T['ventes_prec'] = sum(d['ventes_prec'] for d in days)
    return {'report': 'comparatif_hebdo', 'title': "Comparatif hebdomadaire — même semaine l'an dernier",
            'start': a0.isoformat(), 'end': a1.isoformat(), 'start_prec': b0.isoformat(), 'end_prec': b1.isoformat(),
            'shop_id': shop_id or '', 'shop_name': _shop_name(shop_id), 'level': level,
            'rows': rows, 'totals': T, 'days': days,
            'generated_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'by': username}


def export_comparison_pdf(r):
    from reportlab.lib.pagesizes import letter, landscape
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.graphics.shapes import Drawing, String
    from reportlab.graphics.charts.barcharts import VerticalBarChart
    from reportlab.lib.utils import ImageReader
    out = PDF_DIR / "Rapports_personnalises"
    out.mkdir(exist_ok=True)
    path = out / f"Comparatif_semaine_{r['start']}.pdf"
    page_w, page_h = landscape(letter)
    styles = getSampleStyleSheet()
    cell = ParagraphStyle('c', parent=styles['Normal'], fontSize=8, leading=9.5)
    cell_b = ParagraphStyle('cb', parent=cell, fontName='Helvetica-Bold')
    T = r['totals']
    y1, y0 = r['start'][:4], r['start_prec'][:4]

    def money(v):
        return f"{v:,.2f} $".replace(',', ' ').replace('.', ',')

    def pct(v, sign=False):
        if v is None:
            return '—'
        s = f"{v:+.1f} %" if sign else f"{v:.1f} %"
        return s.replace('.', ',')

    def header(canvas, doc_):
        canvas.saveState()
        top = page_h - 14 * mm
        canvas.setFont('Helvetica-Bold', 15)
        canvas.drawString(14 * mm, top, r['title'])
        canvas.setFont('Helvetica', 9)
        canvas.drawString(14 * mm, top - 6 * mm, f"Semaine du {_d(r['start'])} au {_d(r['end'])} comparée à celle du "
                                                  f"{_d(r['start_prec'])} au {_d(r['end_prec'])}"
                                                  + (f" — {r['shop_name']}" if r['shop_name'] else ''))
        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            lw = 38 * mm
            canvas.drawImage(img, page_w - 14 * mm - lw, top - lw * ih / iw + 3 * mm, width=lw, height=lw * ih / iw, mask='auto')
        canvas.setFont('Helvetica', 8)
        canvas.drawRightString(page_w - 14 * mm, 8 * mm, f"Page {doc_.page}")
        canvas.restoreState()

    doc = SimpleDocTemplate(str(path), pagesize=landscape(letter), leftMargin=14 * mm, rightMargin=14 * mm,
                            topMargin=28 * mm, bottomMargin=14 * mm)
    story = []
    summary = [["", f"Semaine {y1}", f"Semaine {y0}", "Écart", "Variation"],
               ["Ventes (après rabais)", money(T['total']), money(T['total_prec']), money(T['ecart']), pct(T['variation'], True)],
               ["Profit", money(T['profit']), money(T['profit_prec']), money(T['profit'] - T['profit_prec']), ""],
               ["Marge", pct(T['marge']), pct(T['marge_prec']), "", ""],
               ["Nombre de ventes", str(T['ventes']), str(T['ventes_prec']), str(T['ventes'] - T['ventes_prec']), ""]]
    st = Table(summary, colWidths=[45 * mm, 32 * mm, 32 * mm, 30 * mm, 24 * mm])
    st.setStyle(TableStyle([('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'), ('FONTNAME', (0, 1), (0, -1), 'Helvetica-Bold'),
                            ('FONTSIZE', (0, 0), (-1, -1), 8.5), ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
                            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#e5e7eb')),
                            ('LINEBELOW', (0, 0), (-1, -1), 0.25, colors.HexColor('#d1d5db'))]))
    # graphique : ventes par jour, cette année vs l'an dernier
    dr = Drawing(page_w - 28 * mm - 175 * mm, 52 * mm)
    ch = VerticalBarChart()
    ch.x, ch.y, ch.width, ch.height = 30, 18, dr.width - 40, dr.height - 30
    ch.data = [[d['total'] for d in r['days']], [d['total_prec'] for d in r['days']]]
    ch.categoryAxis.categoryNames = [d['jour'][:3] + '.' for d in r['days']]
    ch.categoryAxis.labels.fontSize = 7
    ch.valueAxis.labels.fontSize = 7
    ch.valueAxis.valueMin = 0
    ch.bars[0].fillColor = colors.HexColor('#2563eb')
    ch.bars[1].fillColor = colors.HexColor('#cbd5e1')
    ch.barSpacing = 1
    ch.bars.strokeColor = None
    ch.groupSpacing = 6
    dr.add(ch)
    dr.add(String(30, dr.height - 8, f"Ventes par jour — {y1} (bleu) vs {y0} (gris)", fontSize=8, fontName='Helvetica-Bold'))
    top_t = Table([[st, dr]], colWidths=[170 * mm, None])
    top_t.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'TOP')]))
    story += [top_t, Spacer(1, 5 * mm)]
    data = [["Catégorie", f"Ventes {y1}", f"Ventes {y0}", "Écart", "Variation", f"Profit {y1}", f"Profit {y0}",
             f"Marge {y1}", f"Marge {y0}"]]
    for row in r['rows'] + [dict(T, categorie='TOTAL')]:
        data.append([Paragraph(row['categorie'].replace('&', '&amp;').replace('<', '&lt;'),
                               cell_b if row['categorie'] == 'TOTAL' else cell),
                     money(row['total']), money(row['total_prec']), money(row['ecart']), pct(row['variation'], True),
                     money(row['profit']), money(row['profit_prec']), pct(row['marge']), pct(row['marge_prec'])])
    t = Table(data, colWidths=[72 * mm, 25 * mm, 25 * mm, 24 * mm, 18 * mm, 24 * mm, 24 * mm, 17 * mm, 17 * mm], repeatRows=1)
    style = [('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'), ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
             ('FONTSIZE', (0, 0), (-1, -1), 8), ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
             ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e3a8a')),
             ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#e5e7eb')),
             ('LINEBELOW', (0, 0), (-1, -1), 0.25, colors.HexColor('#d1d5db')),
             ('ALIGN', (1, 0), (-1, -1), 'RIGHT'), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
             ('TOPPADDING', (0, 0), (-1, -1), 3), ('BOTTOMPADDING', (0, 0), (-1, -1), 3)]
    for i, row in enumerate(r['rows'], start=1):
        style.append(('TEXTCOLOR', (3, i), (4, i), colors.HexColor('#15803d') if row['ecart'] >= 0 else colors.HexColor('#b91c1c')))
    t.setStyle(TableStyle(style))
    story.append(t)
    story.append(_pdf_disclaimer())
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


def export_comparison_xlsx(r):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    wb = Workbook()
    ws = wb.active
    ws.title = "Comparatif"
    y1, y0 = r['start'][:4], r['start_prec'][:4]
    ws['A1'] = r['title']
    ws['A1'].font = Font(bold=True, size=14)
    ws['A2'] = f"Semaine du {_d(r['start'])} au {_d(r['end'])} vs {_d(r['start_prec'])} au {_d(r['end_prec'])}"
    heads = ["Catégorie", f"Ventes {y1}", f"Ventes {y0}", "Écart", "Variation", f"Profit {y1}", f"Profit {y0}",
             f"Marge {y1}", f"Marge {y0}"]
    keys = ['categorie', 'total', 'total_prec', 'ecart', 'variation', 'profit', 'profit_prec', 'marge', 'marge_prec']
    for j, h in enumerate(heads, 1):
        c = ws.cell(row=4, column=j, value=h)
        c.font = Font(bold=True, color='FFFFFF')
        c.fill = PatternFill('solid', fgColor='1E3A8A')
    for i, row in enumerate(r['rows'] + [dict(r['totals'], categorie='TOTAL')], start=5):
        for j, k in enumerate(keys, 1):
            v = row.get(k)
            if k in ('variation', 'marge', 'marge_prec'):
                v = None if v is None else v / 100
            c = ws.cell(row=i, column=j, value=v)
            c.number_format = '0.0%' if k in ('variation', 'marge', 'marge_prec') else ('#,##0.00 $;-#,##0.00 $' if j > 1 else 'General')
            if row['categorie'] == 'TOTAL':
                c.font = Font(bold=True)
    ws2 = wb.create_sheet("Par jour")
    for j, h in enumerate(["Jour", f"Date {y1}", f"Ventes {y1}", f"Date {y0}", f"Ventes {y0}"], 1):
        ws2.cell(row=1, column=j, value=h).font = Font(bold=True)
    for i, d in enumerate(r['days'], 2):
        for j, v in enumerate([d['jour'], d['date'], d['total'], d['date_prec'], d['total_prec']], 1):
            ws2.cell(row=i, column=j, value=v)
    ws.column_dimensions['A'].width = 46
    for col in 'BCDEFGHI':
        ws.column_dimensions[col].width = 15
    out = PDF_DIR / "Rapports_personnalises"
    out.mkdir(exist_ok=True)
    path = out / f"Comparatif_semaine_{r['start']}.xlsx"
    for ws_ in wb.worksheets:
        _xlsx_disclaimer(ws_)
    wb.save(path)
    return path


def _report_email_body(r):
    T = r['totals']

    def m(v):
        return f"{v:,.2f} $".replace(',', ' ').replace('.', ',')
    if r['report'] == 'comparatif_hebdo':
        var = '—' if T['variation'] is None else f"{T['variation']:+.1f} %".replace('.', ',')
        return (f"Bonjour,\n\nVoici le comparatif des ventes de la semaine du {_d(r['start'])} au {_d(r['end'])}, "
                f"comparée à la même semaine l'an dernier (du {_d(r['start_prec'])} au {_d(r['end_prec'])}).\n\n"
                f"Ventes : {m(T['total'])} (l'an dernier : {m(T['total_prec'])}, variation {var})\n"
                f"Profit : {m(T['profit'])} (l'an dernier : {m(T['profit_prec'])})\n\n"
                f"Le détail par catégorie et par jour est dans le PDF joint.\n\n{get_company_name()}"
                f"\n\n— {REPORT_DISCLAIMER_TITLE} : {REPORT_DISCLAIMER}")
    period = f"du {_d(r['start'])}" if r['start'] == r['end'] else f"du {_d(r['start'])} au {_d(r['end'])}"
    marge = '—' if T['marge'] is None else f"{T['marge']:.1f} %".replace('.', ',')
    return (f"Bonjour,\n\nVoici le rapport des ventes par catégorie {period}.\n\n"
            f"Ventes (après rabais) : {m(T['total'])}\nProfit : {m(T['profit'])}\nMarge : {marge}\n"
            f"Nombre de ventes : {r['sales_count']}\n\nLe détail par catégorie est dans le PDF joint.\n\n{get_company_name()}"
            f"\n\n— {REPORT_DISCLAIMER_TITLE} : {REPORT_DISCLAIMER}")


def send_report_email(r, emails, username, auto=False, bcc_company=None):
    """Envoie le rapport (PDF joint) à chaque adresse. Retourne (envoyés, erreurs)."""
    pdf = export_comparison_pdf(r) if r['report'] == 'comparatif_hebdo' else export_report_pdf(r)
    if r['report'] == 'comparatif_hebdo':
        subject = f"Comparatif des ventes — semaine du {_d(r['start'])}"
    else:
        subject = "Ventes par catégorie — " + (_d(r['start']) if r['start'] == r['end'] else f"{_d(r['start'])} au {_d(r['end'])}")
    body = _report_email_body(r)
    if bcc_company is None:
        bcc_company = store_cfg()['bcc_company']
    sent, errors = [], []
    com = False
    if get_settings()['send_mode'] != 'smtp':
        try:
            import pythoncom
            pythoncom.CoInitialize()
            com = True
        except Exception:
            pass
    try:
        for e in emails:
            try:
                send_email(e, subject, body, str(pdf), mode='send', bcc_company=bcc_company)
                sent.append(e)
            except Exception as ex:
                errors.append(f"{e} : {ex}")
    finally:
        if com:
            try:
                import pythoncom
                pythoncom.CoUninitialize()
            except Exception:
                pass
    conn = get_conn()
    conn.execute("INSERT INTO report_sends(sent_at, kind, period, recipients, status, error, username) VALUES (?,?,?,?,?,?,?)",
                 (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                  ('auto ' if auto else '') + ('comparatif' if r['report'] == 'comparatif_hebdo' else 'quotidien'),
                  f"{r['start']} au {r['end']}", ", ".join(sent), 'ok' if not errors else ('partiel' if sent else 'echec'),
                  "; ".join(errors) or None, username or '?'))
    conn.commit()
    conn.close()
    db_add_audit(username or '?', 'Rapport envoyé par courriel' + (' (automatique)' if auto else ''),
                 f"{subject} → {', '.join(sent) or 'aucun'}" + (f" ; erreurs : {'; '.join(errors)}" if errors else ""))
    return sent, errors


_send_now_state = {'running': False, 'message': '', 'error': None, 'kind': None}


def _send_now_days(kind):
    today = datetime.date.today()
    if kind == 'daily':
        y = today - datetime.timedelta(days=1)
        return y, store_missing_days(y, y)
    w0, _ = last_week_bounds(today)
    w1 = w0 + datetime.timedelta(days=6)
    return w0, store_missing_days(w0, w1) + store_missing_days(w0 - datetime.timedelta(days=364), w0 - datetime.timedelta(days=358))


def _send_now_worker(kind, to, level, username):
    st = _send_now_state
    label = 'le rapport de la veille' if kind == 'daily' else 'le comparatif de la semaine passée'
    try:
        start, missing = _send_now_days(kind)
        if missing:
            if not _store_lock.acquire(blocking=False):
                raise LightspeedError("Une lecture Lightspeed est déjà en cours. Réessaie dans quelques minutes.")
            ss = _store_state
            ss.update(running=True, progress=f"Envoi immédiat : lecture des ventes manquantes ({len(missing)} jour(s))…", error=None, kind='envoi')
            try:
                store_sync_days(sorted(set(missing)), ss, 'envoi')
            finally:
                ss['running'] = False
                ss['progress'] = ''
                _store_lock.release()
        st['message'] = "Préparation et envoi " + ('du rapport de la veille…' if kind == 'daily' else 'du comparatif de la semaine passée…')
        r = local_sales_by_category(start, start, '', level, username) if kind == 'daily' else weekly_comparison(start, '', level, username)
        sent, errors = send_report_email(r, to, username)
        st['message'] = (f"{label[0].upper() + label[1:]} a été envoyé à {len(sent)} gestionnaire(s)." if sent else '') \
            + (f" Erreurs : {'; '.join(errors)}" if errors else '')
        st['error'] = None if not errors else st['message']
    except Exception as e:
        if not isinstance(e, LightspeedError):
            traceback.print_exc()
        st['error'] = st['message'] = f"Envoi impossible : {e}"
        db_add_audit(username or '?', 'Envoi immédiat d\'un rapport — échec', str(e))
    finally:
        st['running'] = False


def nightly_reports_run(force=False):
    """Récupère les ventes (7 derniers jours + historique manquant), puis envoie
    le rapport de la veille et, au besoin, le comparatif de la semaine passée."""
    cfg = store_cfg()
    if not _store_lock.acquire(blocking=False):
        return
    st = _store_state
    st.update(running=True, progress="Tâche de nuit : connexion à Lightspeed…", error=None, kind='nuit')
    today = datetime.date.today()
    yesterday = today - datetime.timedelta(days=1)
    try:
        start = datetime.date.fromisoformat(cfg['start'])
        days = {yesterday - datetime.timedelta(days=i) for i in range(7)}
        days |= set(store_missing_days(start, yesterday))
        store_sync_days(sorted(d for d in days if d >= start or d >= yesterday - datetime.timedelta(days=6)), st, 'nuit')
        meta_set('rep_last_nightly', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        meta_delete('rep_last_nightly_error')
    except Exception as e:
        if not isinstance(e, LightspeedError):
            traceback.print_exc()
        meta_set('rep_last_nightly_error', f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M')} — {e}")
        db_add_audit('Tâche de nuit', 'Récupération des ventes Lightspeed — échec', str(e))
        return
    finally:
        st['running'] = False
        st['progress'] = ''
        _store_lock.release()
    daily_to = [x['email'] for x in cfg['recipients'] if x.get('daily') and x.get('email')]
    weekly_to = [x['email'] for x in cfg['recipients'] if x.get('weekly') and x.get('email')]
    if cfg['auto_daily'] and daily_to and meta_get('rep_last_daily_sent') != yesterday.isoformat():
        r = local_sales_by_category(yesterday, yesterday, '', cfg['daily_level'], 'Envoi automatique')
        send_report_email(r, daily_to, 'Envoi automatique', auto=True)
        meta_set('rep_last_daily_sent', yesterday.isoformat())
    w0, _ = last_week_bounds(today)
    if cfg['auto_weekly'] and weekly_to and meta_get('rep_last_weekly_sent') != w0.isoformat():
        r = weekly_comparison(w0, '', cfg['weekly_level'], 'Envoi automatique')
        send_report_email(r, weekly_to, 'Envoi automatique', auto=True)
        meta_set('rep_last_weekly_sent', w0.isoformat())


def _canon_tax_name(idx, pct):
    """Nom officiel d'une taxe canadienne selon sa position et son taux, pour la
    ventilation (les noms configurés dans Lightspeed peuvent être ambigus)."""
    if idx == 1:
        return 'TPS' if abs(pct - 5) < 0.001 else ('TVH' if pct > 5 else 'Taxe 1')
    return 'TVQ' if abs(pct - 9.975) < 0.001 else 'TVP'


def local_tax_report(d0, d1, shop_id='', username=None):
    conn = get_conn()
    try:
        cats = {r['tax_category_id']: dict(r) for r in conn.execute("SELECT * FROM ls_tax_categories").fetchall()}
        q = ("SELECT COALESCE(tax_cat,'') tc, ROUND(COALESCE(tax1_rate,0),6) r1, ROUND(COALESCE(tax2_rate,0),6) r2, "
             "SUM(total) t, SUM(tax1) x1, SUM(tax2) x2, "
             f"SUM(CASE WHEN ABS(tax1)>{TAX_EPS} THEN total ELSE 0 END) b1, "
             f"SUM(CASE WHEN ABS(tax2)>{TAX_EPS} THEN total ELSE 0 END) b2, "
             f"SUM(CASE WHEN ABS(tax1)<={TAX_EPS} AND ABS(tax2)<={TAX_EPS} THEN total ELSE 0 END) nt "
             "FROM sales_lines WHERE sale_date BETWEEN ? AND ?")
        args = [d0.isoformat(), d1.isoformat()]
        if shop_id:
            q += " AND shop_id=?"
            args.append(str(shop_id))
        groups = [dict(r) for r in conn.execute(q + " GROUP BY tc, r1, r2", args).fetchall()]
        class_names = {r['tax_class_id']: r['name'] for r in conn.execute("SELECT * FROM ls_tax_classes").fetchall()}
        qc = ("SELECT COALESCE(tax_class,'') tcl, SUM(subtotal) st, SUM(discount) d, SUM(total) t, SUM(tax1) x1, SUM(tax2) x2, "
              f"SUM(CASE WHEN ABS(tax1)>{TAX_EPS} OR ABS(tax2)>{TAX_EPS} THEN total ELSE 0 END) taxe, "
              f"SUM(CASE WHEN ABS(tax1)<={TAX_EPS} AND ABS(tax2)<={TAX_EPS} THEN total ELSE 0 END) nt "
              "FROM sales_lines WHERE sale_date BETWEEN ? AND ?" + (" AND shop_id=?" if shop_id else "") + " GROUP BY tcl")
        class_groups = [dict(r) for r in conn.execute(qc, args).fetchall()]
        n_sales = conn.execute("SELECT COUNT(DISTINCT sale_id) n FROM sales_lines WHERE sale_date BETWEEN ? AND ?"
                               + (" AND shop_id=?" if shop_id else ""), args).fetchone()['n']
    finally:
        conn.close()
    by_rate, by_cat = {}, {}
    for g in groups:
        c = cats.get(g['tc']) or {}
        for idx in (1, 2):
            amount, base = g[f'x{idx}'] or 0.0, g[f'b{idx}'] or 0.0
            if abs(amount) <= TAX_EPS and abs(base) <= TAX_EPS:
                continue
            rate = _tax_pct(g[f'r{idx}'] or c.get(f'tax{idx}_rate') or 0)
            name = _canon_tax_name(idx, rate)
            row = by_rate.setdefault((name, rate), {'taxe': name, 'taux': rate, 'ventes_taxables': 0.0, 'taxe_percue': 0.0})
            row['ventes_taxables'] += base
            row['taxe_percue'] += amount
        key = g['tc']
        cname = c.get('name') if c.get('name') and not re.fullmatch(r'Catégorie \d+', c.get('name')) else ''
        if not cname:
            if not key:
                cname = '(Aucune catégorie de taxes)'
            else:
                parts = []
                for i in (1, 2):
                    rate_i = g['r%d' % i] or c.get('tax%d_rate' % i) or 0
                    if abs(g['x%d' % i] or 0) > TAX_EPS or abs(rate_i) > TAX_EPS:
                        nm = (c.get('tax%d_name' % i) or '').strip() or TAX_DEFAULT_NAMES[i]
                        parts.append(nm + ' ' + ('%g' % _tax_pct(rate_i)).replace('.', ',') + ' %')
                cname = " + ".join(parts) if parts else "Aucune taxe"
        cr = by_cat.setdefault(key, {'categorie': cname,
                                     'ventes': 0.0, 'non_taxables': 0.0, 'taxes': {}, 'total_taxes': 0.0})
        cr['ventes'] += g['t'] or 0.0
        cr['non_taxables'] += g['nt'] or 0.0
        for idx in (1, 2):
            amount = g[f'x{idx}'] or 0.0
            if abs(amount) > TAX_EPS:
                pct_txt = f"{_tax_pct(g[f'r{idx}'] or c.get(f'tax{idx}_rate') or 0):g}".replace('.', ',')
                lbl = f"{_canon_tax_name(idx, _tax_pct(g[f'r{idx}'] or c.get(f'tax{idx}_rate') or 0))} {pct_txt} %"
                cr['taxes'][lbl] = cr['taxes'].get(lbl, 0.0) + amount
                cr['total_taxes'] += amount
    order = {'TPS': 0, 'GST': 0, 'TVQ': 1, 'QST': 1, 'TVH': 2, 'HST': 2, 'TVP': 3, 'PST': 3}
    rates = sorted(by_rate.values(), key=lambda r: (order.get(r['taxe'].upper(), 9), r['taxe'], r['taux']))
    for r in rates:
        r['ventes_taxables'] = round(r['ventes_taxables'], 2)
        r['taxe_percue'] = round(r['taxe_percue'], 2)
        r['taxe_theorique'] = round(r['ventes_taxables'] * r['taux'] / 100, 2)
    cat_rows = sorted((r for r in by_cat.values() if abs(r['ventes']) >= 0.005 or abs(r['total_taxes']) >= 0.005),
                      key=lambda r: -r['ventes'])
    classes = []
    for g in sorted(class_groups, key=lambda g: -(g['st'] or 0)):
        row = {'classe': class_names.get(g['tcl']) or ('Sans classe' if not g['tcl'] else f"Classe {g['tcl']}"),
               'sous_total': round(g['st'] or 0, 2), 'reductions': round(g['d'] or 0, 2),
               'ventes': round(g['t'] or 0, 2), 'taxe': round(g['taxe'] or 0, 2), 'non_taxe': round(g['nt'] or 0, 2),
               'tps': round(g['x1'] or 0, 2), 'tvq': round(g['x2'] or 0, 2)}
        row['total_taxes'] = round(row['tps'] + row['tvq'], 2)
        row['total'] = round(row['ventes'] + row['total_taxes'], 2)
        if any(abs(row[k]) >= 0.005 for k in ('sous_total', 'ventes', 'total_taxes')):
            classes.append(row)
    for r in cat_rows:
        r['ventes'] = round(r['ventes'], 2)
        r['non_taxables'] = round(r['non_taxables'], 2)
        r['total_taxes'] = round(r['total_taxes'], 2)
        r['taxes'] = [{'taxe': k, 'montant': round(v, 2)} for k, v in sorted(r['taxes'].items())]
        r['total_ttc'] = round(r['ventes'] + r['total_taxes'], 2)
    ventes = round(sum(g['t'] or 0 for g in groups), 2)
    taxes = round(sum((g['x1'] or 0) + (g['x2'] or 0) for g in groups), 2)
    conn = get_conn()
    fetched = conn.execute("SELECT MIN(fetched_at) a, MAX(fetched_at) b FROM sales_days WHERE day BETWEEN ? AND ?",
                           (d0.isoformat(), d1.isoformat())).fetchone()
    fq = ("SELECT COALESCE(NULLIF(TRIM(fee_name),''),'Frais') nom, SUM(qty) q, SUM(subtotal) st, SUM(total) t, "
          "SUM(tax1) x1, SUM(tax2) x2, COUNT(*) n FROM sales_lines WHERE is_fee=1 AND sale_date BETWEEN ? AND ?"
          + (" AND shop_id=?" if shop_id else "") + " GROUP BY nom ORDER BY t DESC")
    fee_rows = [dict(r) for r in conn.execute(fq, [d0.isoformat(), d1.isoformat()] + ([str(shop_id)] if shop_id else [])).fetchall()]
    conn.close()
    fees = []
    for f in fee_rows:
        tx = round((f['x1'] or 0) + (f['x2'] or 0), 2)
        fees.append({'nom': f['nom'], 'quantite': round(f['q'] or 0, 2), 'lignes': f['n'], 'montant': round(f['t'] or 0, 2),
                     'taxes': tx, 'total': round((f['t'] or 0) + tx, 2)})
    fee_totals = {'montant': round(sum(f['montant'] for f in fees), 2), 'taxes': round(sum(f['taxes'] for f in fees), 2),
                  'lignes': sum(f['lignes'] for f in fees)}
    fee_totals['total'] = round(fee_totals['montant'] + fee_totals['taxes'], 2)
    return {'report': 'taxes', 'title': "Rapport des taxes",
            'fetched_oldest': fetched['a'], 'fetched_newest': fetched['b'],
            'start': d0.isoformat(), 'end': d1.isoformat(), 'shop_id': shop_id or '', 'shop_name': _shop_name(shop_id),
            'rates': rates, 'categories': cat_rows, 'classes': classes, 'fees': fees, 'fee_totals': fee_totals,
            'totals': {'ventes': ventes, 'non_taxables': round(sum(g['nt'] or 0 for g in groups), 2),
                       'taxes': taxes, 'ttc': round(ventes + taxes, 2), 'sales_count': n_sales,
                       'sous_total': round(sum(g['st'] or 0 for g in class_groups), 2),
                       'reductions': round(sum(g['d'] or 0 for g in class_groups), 2),
                       'taxables': round(sum(g['taxe'] or 0 for g in class_groups), 2),
                       'tps': round(sum(g['x1'] or 0 for g in groups), 2),
                       'tvq': round(sum(g['x2'] or 0 for g in groups), 2)},
            'generated_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'by': username}


def export_tax_pdf(r):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader
    out = PDF_DIR / "Rapports_personnalises"
    out.mkdir(exist_ok=True)
    path = out / f"Rapport_taxes_{r['start']}_au_{r['end']}.pdf"
    page_w, page_h = letter
    styles = getSampleStyleSheet()
    h2 = ParagraphStyle('h2', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=11, spaceBefore=4, spaceAfter=4)
    cell = ParagraphStyle('c', parent=styles['Normal'], fontSize=8.5, leading=10)
    T = r['totals']

    def money(v):
        return f"{v:,.2f} $".replace(',', ' ').replace('.', ',')

    def pct(v):
        return f"{v:g} %".replace('.', ',')

    period = f"Du {_d(r['start'])} au {_d(r['end'])}" + (f" — {r['shop_name']}" if r['shop_name'] else '')

    def header(canvas, doc_):
        canvas.saveState()
        top = page_h - 16 * mm
        canvas.setFont('Helvetica-Bold', 16)
        canvas.drawString(16 * mm, top, f"Rapport des taxes — {get_company_name()}")
        canvas.setFont('Helvetica', 9.5)
        canvas.drawString(16 * mm, top - 7 * mm, period)
        g = r['generated_at']
        canvas.drawString(16 * mm, top - 12 * mm, f"{T['sales_count']} vente(s) — généré le {g[8:10]}-{g[5:7]}-{g[:4]} à {g[11:16]}")
        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            lw = 38 * mm
            canvas.drawImage(img, page_w - 16 * mm - lw, top - lw * ih / iw + 4 * mm, width=lw, height=lw * ih / iw, mask='auto')
        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.line(16 * mm, top - 16 * mm, page_w - 16 * mm, top - 16 * mm)
        canvas.setFont('Helvetica', 8)
        canvas.drawString(16 * mm, 9 * mm, "Montants calculés à partir des ventes Lightspeed ; les retours réduisent les ventes et la taxe perçue.")
        canvas.drawRightString(page_w - 16 * mm, 9 * mm, f"Page {doc_.page}")
        canvas.restoreState()

    base_style = [('FONTSIZE', (0, 0), (-1, -1), 9), ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
                  ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('LINEBELOW', (0, 0), (-1, -1), 0.25, colors.HexColor('#d1d5db')),
                  ('TOPPADDING', (0, 0), (-1, -1), 4), ('BOTTOMPADDING', (0, 0), (-1, -1), 4)]
    head_style = [('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'), ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                  ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e3a8a'))]
    story = []
    summ = [["Sous-total", money(T.get('sous_total', 0)), "Taxé", money(T.get('taxables', 0))],
            ["Réductions", money(T.get('reductions', 0)), "Non taxé", money(T['non_taxables'])],
            ["Sous-total avec réductions", money(T['ventes']), "", ""],
            ["TPS (1re taxe, incluant la TVH)", money(T.get('tps', 0)), "", ""],
            ["TVQ (2e taxe)", money(T.get('tvq', 0)), "", ""],
            ["Total des taxes", money(T['taxes']), "", ""],
            ["Total avec taxes", money(T['ttc']), "", ""]]
    st = Table(summ, colWidths=[62 * mm, 32 * mm, 22 * mm, 32 * mm])
    st.setStyle(TableStyle(base_style + [('FONTNAME', (0, 5), (1, 6), 'Helvetica-Bold'), ('FONTNAME', (2, 0), (2, 1), 'Helvetica-Bold'),
                                         ('BACKGROUND', (0, 5), (1, 5), colors.HexColor('#eff6ff'))]))
    story += [Paragraph("Sommaire", h2), st, Spacer(1, 6 * mm)]
    if r.get('classes'):
        small = ParagraphStyle('s', parent=cell, fontSize=7.5, leading=9)
        data = [["Classe de taxe", "Sous-total", "Réductions", "Avec réd.", "Taxé", "Non taxé", "TPS", "TVQ", "Taxes", "Total"]]
        for c in r['classes']:
            data.append([Paragraph(c['classe'].replace('&', '&amp;').replace('<', '&lt;'), small), money(c['sous_total']),
                         money(c['reductions']), money(c['ventes']), money(c['taxe']), money(c['non_taxe']), money(c['tps']),
                         money(c['tvq']), money(c['total_taxes']), money(c['total'])])
        data.append(["TOTAL", money(T.get('sous_total', 0)), money(T.get('reductions', 0)), money(T['ventes']),
                     money(T.get('taxables', 0)), money(T['non_taxables']), money(T.get('tps', 0)), money(T.get('tvq', 0)),
                     money(T['taxes']), money(T['ttc'])])
        t = Table(data, colWidths=[24 * mm] + [17.4 * mm] * 9, repeatRows=1)
        t.setStyle(TableStyle(base_style + head_style + [('FONTSIZE', (0, 0), (-1, -1), 7),
                                                         ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
                                                         ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#e5e7eb'))]))
        story += [Paragraph("Par classe de taxe (comme le rapport « Taxe de vente » de Lightspeed)", h2), t, Spacer(1, 6 * mm)]
    story += [Paragraph("Ventilation par taux de taxe", h2)]
    data = [["Taxe", "Taux", "Ventes taxables", "Taxe perçue"]]
    for x in r['rates']:
        data.append([x['taxe'], pct(x['taux']), money(x['ventes_taxables']), money(x['taxe_percue'])])
    data.append(["Total des taxes", "", "", money(T['taxes'])])
    t = Table(data, colWidths=[55 * mm, 25 * mm, 45 * mm, 45 * mm], repeatRows=1)
    t.setStyle(TableStyle(base_style + head_style + [('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
                                                     ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#e5e7eb'))]))
    story += [t, Spacer(1, 6 * mm), Paragraph("Par catégorie de taxes (Lightspeed)", h2)]
    data = [["Catégorie", "Ventes avant taxes", "Non taxables", "Détail des taxes", "Total taxes"]]
    for c in r['categories']:
        det = "<br/>".join(f"{x['taxe']} : {money(x['montant'])}" for x in c['taxes']) or "—"
        data.append([Paragraph(c['categorie'].replace('&', '&amp;').replace('<', '&lt;'), cell), money(c['ventes']),
                     money(c['non_taxables']), Paragraph(det.replace('&', '&amp;'), cell), money(c['total_taxes'])])
    data.append(["TOTAL", money(T['ventes']), money(T['non_taxables']), "", money(T['taxes'])])
    t = Table(data, colWidths=[45 * mm, 32 * mm, 28 * mm, 48 * mm, 28 * mm], repeatRows=1)
    t.setStyle(TableStyle(base_style + head_style + [('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
                                                     ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#e5e7eb'))]))
    story.append(t)
    FT = r.get('fee_totals') or {}
    story += [Spacer(1, 8 * mm), Paragraph("Rapport des frais (Lignes de vente → Frais)", h2)]
    ft = Table([["Total des frais", money(FT.get('montant', 0))]], colWidths=[80 * mm, 40 * mm])
    ft.setStyle(TableStyle(base_style + [('FONTNAME', (0, 0), (-1, -1), 'Helvetica-Bold'), ('FONTSIZE', (0, 0), (-1, -1), 11),
                                         ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#fef9c3'))]))
    story.append(ft)
    if r.get('fees'):
        data = [["Frais", "Quantité", "Montant", "Taxes", "Total avec taxes"]]
        for f in r['fees']:
            data.append([Paragraph(f['nom'].replace('&', '&amp;').replace('<', '&lt;'), cell),
                         f"{f['quantite']:g}".replace('.', ','), money(f['montant']), money(f['taxes']), money(f['total'])])
        data.append(["TOTAL", "", money(FT['montant']), money(FT['taxes']), money(FT['total'])])
        t = Table(data, colWidths=[70 * mm, 22 * mm, 28 * mm, 25 * mm, 32 * mm], repeatRows=1)
        t.setStyle(TableStyle(base_style + head_style + [('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
                                                         ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#e5e7eb'))]))
        story += [Spacer(1, 3 * mm), t]
    else:
        story.append(Paragraph("Aucun frais d'article (consigne, écofrais…) n'a été trouvé pour cette période.", cell))
    doc = SimpleDocTemplate(str(path), pagesize=letter, leftMargin=16 * mm, rightMargin=16 * mm,
                            topMargin=36 * mm, bottomMargin=16 * mm)
    story.append(_pdf_disclaimer())
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


_inv_lock = threading.Lock()


_inv_state = {'running': False, 'progress': '', 'error': None, 'last_id': None, 'last_send': None}


INV_METHODS = {'avg': 'coût moyen', 'default': 'coût par défaut'}


def inv_cfg():
    try:
        recips = json.loads(meta_get('inv_recipients') or '[]')
    except ValueError:
        recips = []
    try:
        hour = min(max(int(meta_get('inv_hour') or 6), 0), 23)
    except ValueError:
        hour = 6
    day = meta_get('inv_day') or '1'
    if day != 'last':
        try:
            day = str(min(max(int(day), 1), 28))
        except ValueError:
            day = '1'
    return {'auto': meta_get('inv_auto') == '1', 'day': day, 'hour': hour,
            'method': meta_get('inv_method') if meta_get('inv_method') in INV_METHODS else 'avg',
            'recipients': [r for r in recips if isinstance(r, str) and r.strip()]}


def _inv_item_cost(it, method):
    avg, dflt = _parse_money(it.get('avgCost')), _parse_money(it.get('defaultCost'))
    return (avg or dflt) if method == 'avg' else (dflt or avg)


def _inv_item_price(it):
    prices = it.get('Prices') or {}
    for p in _ls_as_list(prices.get('ItemPrice') if isinstance(prices, dict) else prices):
        if str(p.get('useType') or '').lower() in ('default', 'prix par défaut') or str(p.get('useTypeID') or '') == '1':
            return _parse_money(p.get('amount'))
    return 0.0


def _inv_item_qoh(it, shop_id):
    shops = _ls_as_list((it.get('ItemShops') or {}).get('ItemShop') if isinstance(it.get('ItemShops'), dict) else it.get('ItemShops'))
    rows = {str(s.get('shopID') or ''): _parse_money(s.get('qoh')) for s in shops}
    if shop_id:
        return rows.get(str(shop_id), 0.0)
    if '0' in rows:            # Lightspeed fournit souvent une ligne « tous les magasins » (shopID 0)
        return rows['0']
    return sum(v for k, v in rows.items() if k not in ('', '0'))


def take_inventory_snapshot(kind, username, shop_id=''):
    """Lit l'inventaire dans Lightspeed et enregistre l'instantané. Retourne son id."""
    st = _inv_state
    cfg = ls_config()
    account_id = cfg['account_id']
    if not account_id:
        account_id, name = ls_fetch_account()
        meta_set('ls_account_id', account_id)
        meta_set('ls_account_name', name)
    _store_refresh_refs(account_id, st)
    method = inv_cfg()['method']
    items = _ls_get_all(account_id, 'Item', {'archived': 'false', 'load_relations': json.dumps(['ItemShops'])},
                        'Articles', state=st)
    st['progress'] = "Calcul de la valeur…"
    conn = get_conn()
    cats = {r['category_id']: r['path'] for r in conn.execute("SELECT category_id, path FROM ls_categories").fetchall()}
    conn.close()
    agg, tot = {}, {'items': 0, 'units': 0.0, 'cost': 0.0, 'retail': 0.0, 'neg': 0}
    for it in items:
        if _truthy(it.get('archived')) or str(it.get('itemType') or '').lower() in ('non_inventory', 'noninventory'):
            continue
        qoh = _inv_item_qoh(it, shop_id)
        if qoh < 0:
            tot['neg'] += 1
            continue
        if qoh == 0:
            continue
        cost, price = _inv_item_cost(it, method), _inv_item_price(it)
        cat = cats.get(str(it.get('categoryID') or '').strip()) or REP_NO_CATEGORY
        a = agg.setdefault(cat, {'items': 0, 'units': 0.0, 'cost': 0.0, 'retail': 0.0})
        a['items'] += 1
        a['units'] += qoh
        a['cost'] += qoh * cost
        a['retail'] += qoh * price
    for a in agg.values():
        for k in ('items', 'units', 'cost', 'retail'):
            tot[k] += a[k]
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    conn = get_conn()
    try:
        cur = conn.execute("INSERT INTO inventory_snapshots(taken_at, kind, shop_id, shop_name, method, items, units, "
                           "cost_value, retail_value, negative_items, username) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                           (now, kind, shop_id or '', _shop_name(shop_id), method, tot['items'], round(tot['units'], 2),
                            round(tot['cost'], 2), round(tot['retail'], 2), tot['neg'], username or '?'))
        sid = cur.lastrowid
        conn.executemany("INSERT INTO inventory_snapshot_lines(snapshot_id, category, items, units, cost_value, retail_value) "
                         "VALUES (?,?,?,?,?,?)", [(sid, c, a['items'], round(a['units'], 2), round(a['cost'], 2),
                                                   round(a['retail'], 2)) for c, a in agg.items()])
        conn.commit()
    finally:
        conn.close()
    db_add_audit(username or '?', "Instantané de la valeur de l'inventaire",
                 f"{'automatique' if kind == 'auto' else 'manuel'} : {_fmt_money_fr(round(tot['cost'], 2))} au {INV_METHODS[method]}")
    return sid


def start_inventory_job(kind, username, shop_id='', then=None):
    if not _inv_lock.acquire(blocking=False):
        raise LightspeedError("Un instantané de l'inventaire est déjà en cours.")
    st = _inv_state
    st.update(running=True, progress="Connexion à Lightspeed…", error=None, last_send=None)

    def _run():
        try:
            st['last_id'] = take_inventory_snapshot(kind, username, shop_id)
            if then:
                st['progress'] = "Envoi par courriel…"
            if then:
                then(st['last_id'])
        except Exception as e:
            if not isinstance(e, LightspeedError):
                traceback.print_exc()
            st['error'] = str(e) if isinstance(e, LightspeedError) else f"Erreur inattendue : {e}"
            if kind == 'auto':
                meta_set('inv_last_error', f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M')} — {st['error']}")
        finally:
            st['running'] = False
            st['progress'] = ''
            _inv_lock.release()

    threading.Thread(target=_run, daemon=True).start()


def db_inventory_snapshot(sid):
    conn = get_conn()
    try:
        s = conn.execute("SELECT * FROM inventory_snapshots WHERE id=?", (sid,)).fetchone()
        if not s:
            return None
        s = dict(s)
        s['lines'] = [dict(r) for r in conn.execute("SELECT * FROM inventory_snapshot_lines WHERE snapshot_id=? "
                                                     "ORDER BY cost_value DESC", (sid,)).fetchall()]
        prev = conn.execute("SELECT cost_value, taken_at FROM inventory_snapshots WHERE id<? AND shop_id=? ORDER BY id DESC LIMIT 1",
                            (sid, s['shop_id'])).fetchone()
        s['previous'] = dict(prev) if prev else None
        return s
    finally:
        conn.close()


def db_inventory_history(limit=36):
    conn = get_conn()
    rows = [dict(r) for r in conn.execute("SELECT id, taken_at, kind, shop_name, method, items, units, cost_value, "
                                          "retail_value, negative_items, username FROM inventory_snapshots "
                                          "ORDER BY id DESC LIMIT ?", (limit,)).fetchall()]
    conn.close()
    return rows


def export_inventory_pdf(sid):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader
    s = db_inventory_snapshot(sid)
    hist = [h for h in db_inventory_history(13) if h['id'] <= sid][:13]
    out = PDF_DIR / "Rapports_personnalises"
    out.mkdir(exist_ok=True)
    path = out / f"Valeur_inventaire_{s['taken_at'][:10]}.pdf"
    page_w, page_h = letter
    styles = getSampleStyleSheet()
    h2 = ParagraphStyle('h2', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=11, spaceBefore=4, spaceAfter=4)
    cell = ParagraphStyle('c', parent=styles['Normal'], fontSize=8.5, leading=10)
    m = _fmt_money_fr
    t = s['taken_at']

    def header(canvas, doc_):
        canvas.saveState()
        top = page_h - 16 * mm
        canvas.setFont('Helvetica-Bold', 16)
        canvas.drawString(16 * mm, top, f"Valeur de l'inventaire — {get_company_name()}")
        canvas.setFont('Helvetica', 9.5)
        canvas.drawString(16 * mm, top - 7 * mm, f"Instantané du {t[8:10]}-{t[5:7]}-{t[:4]} à {t[11:16]}"
                          + (f" — {s['shop_name']}" if s['shop_name'] else " — tous les magasins")
                          + f" — valeur au {INV_METHODS.get(s['method'], s['method'])}")
        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            lw = 38 * mm
            canvas.drawImage(img, page_w - 16 * mm - lw, top - lw * ih / iw + 4 * mm, width=lw, height=lw * ih / iw, mask='auto')
        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.line(16 * mm, top - 12 * mm, page_w - 16 * mm, top - 12 * mm)
        canvas.setFont('Helvetica', 8)
        canvas.drawString(16 * mm, 9 * mm, "Quantités en main × coût, lues dans Lightspeed ; les quantités négatives ne sont pas comptées.")
        canvas.drawRightString(page_w - 16 * mm, 9 * mm, f"Page {doc_.page}")
        canvas.restoreState()

    base = [('FONTSIZE', (0, 0), (-1, -1), 9), ('ALIGN', (1, 0), (-1, -1), 'RIGHT'), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('LINEBELOW', (0, 0), (-1, -1), 0.25, colors.HexColor('#d1d5db')), ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4)]
    head = [('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'), ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e3a8a'))]
    var = ''
    if s['previous'] and s['previous']['cost_value']:
        dv = s['cost_value'] - s['previous']['cost_value']
        pct = f"{dv / s['previous']['cost_value'] * 100:+.1f} %".replace('.', ',')
        var = f"{'+' if dv >= 0 else '−'}{m(abs(dv))} ({pct})"
    summ = [["Valeur de l'inventaire (au coût)", m(s['cost_value'])], ["Valeur au prix de détail", m(s['retail_value'])],
            ["Articles en stock", f"{s['items']:,}".replace(',', ' ')], ["Unités en stock", f"{s['units']:,.0f}".replace(',', ' ')]]
    if var:
        summ.append(["Variation depuis l'instantané précédent", var])
    if s['negative_items']:
        summ.append(["Articles en quantité négative (non comptés)", str(s['negative_items'])])
    st_ = Table(summ, colWidths=[90 * mm, 50 * mm])
    st_.setStyle(TableStyle(base + [('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'), ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#eff6ff'))]))
    story = [Paragraph("Sommaire", h2), st_, Spacer(1, 6 * mm), Paragraph("Par catégorie", h2)]
    data = [["Catégorie", "Articles", "Unités", "Valeur au coût", "Valeur au détail", "% de la valeur"]]
    for l in s['lines']:
        data.append([Paragraph(l['category'].replace('&', '&amp;').replace('<', '&lt;'), cell), str(l['items']),
                     f"{l['units']:,.0f}".replace(',', ' '), m(l['cost_value']), m(l['retail_value']),
                     (f"{l['cost_value'] / s['cost_value'] * 100:.1f} %".replace('.', ',') if s['cost_value'] else '')])
    data.append(["TOTAL", str(s['items']), f"{s['units']:,.0f}".replace(',', ' '), m(s['cost_value']), m(s['retail_value']), "100 %"])
    tb = Table(data, colWidths=[62 * mm, 18 * mm, 20 * mm, 30 * mm, 30 * mm, 22 * mm], repeatRows=1)
    tb.setStyle(TableStyle(base + head + [('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'), ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#e5e7eb'))]))
    story.append(tb)
    if len(hist) > 1:
        story += [Spacer(1, 6 * mm), Paragraph("Historique", h2)]
        data = [["Date", "Valeur au coût", "Variation"]]
        older = list(reversed(hist))
        for i, h in enumerate(older):
            dv = '' if i == 0 else (('+' if h['cost_value'] - older[i - 1]['cost_value'] >= 0 else '−') + m(abs(h['cost_value'] - older[i - 1]['cost_value'])))
            data.append([f"{h['taken_at'][8:10]}-{h['taken_at'][5:7]}-{h['taken_at'][:4]}", m(h['cost_value']), dv])
        th = Table(data, colWidths=[40 * mm, 40 * mm, 40 * mm], repeatRows=1)
        th.setStyle(TableStyle(base + head))
        story.append(th)
    doc = SimpleDocTemplate(str(path), pagesize=letter, leftMargin=16 * mm, rightMargin=16 * mm, topMargin=32 * mm, bottomMargin=16 * mm)
    story.append(_pdf_disclaimer())
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


def send_inventory_email(sid, emails, username, auto=False):
    s = db_inventory_snapshot(sid)
    pdf = export_inventory_pdf(sid)
    t = s['taken_at']
    subject = f"Valeur de l'inventaire — {t[8:10]}-{t[5:7]}-{t[:4]}"
    body = (f"Bonjour,\n\nVoici la valeur de l'inventaire au {t[8:10]}-{t[5:7]}-{t[:4]} ({INV_METHODS.get(s['method'], '')}) :\n\n"
            f"Valeur au coût : {_fmt_money_fr(s['cost_value'])}\nValeur au prix de détail : {_fmt_money_fr(s['retail_value'])}\n"
            f"Articles en stock : {s['items']}\n"
            + (f"Variation depuis le {s['previous']['taken_at'][8:10]}-{s['previous']['taken_at'][5:7]}-{s['previous']['taken_at'][:4]} : "
               f"{'+' if s['cost_value'] >= s['previous']['cost_value'] else '−'}{_fmt_money_fr(abs(s['cost_value'] - s['previous']['cost_value']))}\n"
               if s['previous'] else '')
            + f"\nLe détail par catégorie est dans le PDF joint.\n\n{get_company_name()}"
            + f"\n\n— {REPORT_DISCLAIMER_TITLE} : {REPORT_DISCLAIMER}")
    sent, errors = [], []
    com = False
    if get_settings()['send_mode'] != 'smtp':
        try:
            import pythoncom
            pythoncom.CoInitialize()
            com = True
        except Exception:
            pass
    try:
        for e in emails:
            try:
                send_email(e, subject, body, str(pdf), mode='send', bcc_company=False)
                sent.append(e)
            except Exception as ex:
                errors.append(f"{e} : {ex}")
    finally:
        if com:
            try:
                import pythoncom
                pythoncom.CoUninitialize()
            except Exception:
                pass
    conn = get_conn()
    conn.execute("INSERT INTO report_sends(sent_at, kind, period, recipients, status, error, username) VALUES (?,?,?,?,?,?,?)",
                 (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), ('auto ' if auto else '') + 'inventaire', t[:10],
                  ", ".join(sent), 'ok' if not errors else ('partiel' if sent else 'echec'), "; ".join(errors) or None, username or '?'))
    conn.commit()
    conn.close()
    db_add_audit(username or '?', "Valeur de l'inventaire envoyée par courriel" + (' (automatique)' if auto else ''),
                 f"{subject} → {', '.join(sent) or 'aucun'}" + (f" ; erreurs : {'; '.join(errors)}" if errors else ""))
    return sent, errors


def _d3_allowed(perm):
    return bool(session.get('is_admin')) or perm in (session.get('permissions') or [])


def dashboard3d_data(periode):
    today = datetime.date.today()
    if periode == 'mois':
        d0, d1, plabel = today.replace(day=1), today, f"{_MOIS_FR[today.month - 1]} {today.year} (jusqu'à aujourd'hui)"
    else:
        last = today.replace(day=1) - datetime.timedelta(days=1)
        d0, d1, plabel = last.replace(day=1), last, f"{_MOIS_FR[last.month - 1]} {last.year}"
    out = {'asOf': today.isoformat(), 'period': {'code': 'mois' if periode == 'mois' else 'mois_dernier', 'label': plabel,
                                                  'start': d0.isoformat(), 'end': d1.isoformat()}}
    conn = get_conn()
    try:
        # --- comptes à recevoir (permission « Comptes à recevoir »)
        inv = [] if not ar_allowed() else [dict(r) for r in conn.execute(
            "SELECT client_name, echeance, COALESCE(montant,0) m, COALESCE(montant_paye,0) p FROM invoices "
            "WHERE COALESCE(montant,0)-COALESCE(montant_paye,0) > 0.005").fetchall()]
        per = {}
        for r in inv:
            c = per.setdefault(r['client_name'], {'client': r['client_name'], 'solde': 0.0, 'en_retard': 0.0, 'factures': 0, 'plus_vieux_retard': 0})
            due = r['m'] - r['p']
            c['solde'] += due
            c['factures'] += 1
            try:
                late = (today - datetime.date.fromisoformat((r['echeance'] or '')[:10])).days
            except ValueError:
                late = 0
            if late > 0:
                c['en_retard'] += due
                c['plus_vieux_retard'] = max(c['plus_vieux_retard'], late)
        top = sorted(per.values(), key=lambda c: -c['solde'])[:10]
        for c in top:
            c['solde'], c['en_retard'] = round(c['solde'], 2), round(c['en_retard'], 2)
        out['ar'] = None if not ar_allowed() else {'total': round(sum(c['solde'] for c in per.values()), 2),
                     'overdue': round(sum(c['en_retard'] for c in per.values()), 2), 'clients': len(per), 'invoices': len(inv)}
        out['clients'] = top
        # --- comptes de crédit
        if _d3_allowed('credit_accounts'):
            r = conn.execute("SELECT COUNT(*) n, COALESCE(SUM(solde),0) s, COALESCE(SUM(deposit),0) d, "
                             "SUM(CASE WHEN solde>0 THEN 1 ELSE 0 END) nd FROM credit_clients").fetchone()
            out['credit'] = {'du': round(r['s'], 2), 'depots': round(r['d'], 2), 'comptes': r['n'], 'comptes_solde': r['nd'] or 0}
        else:
            out['credit'] = None
        # --- ventes de la période (ventes gardées chaque nuit)
        missing = len(store_missing_days(d0, d1))
        if _d3_allowed('custom_reports') or _d3_allowed('tax_reports'):
            r = conn.execute("SELECT COALESCE(SUM(subtotal),0) st, COALESCE(SUM(discount),0) d, COALESCE(SUM(total),0) t, "
                             "COALESCE(SUM(tax1),0) x1, COALESCE(SUM(tax2),0) x2, COUNT(DISTINCT sale_id) n "
                             "FROM sales_lines WHERE sale_date BETWEEN ? AND ?", (d0.isoformat(), d1.isoformat())).fetchone()
            out['store'] = {'ventes': round(r['t'], 2), 'sous_total': round(r['st'], 2), 'reductions': round(r['d'], 2),
                            'taxes': round(r['x1'] + r['x2'], 2), 'ttc': round(r['t'] + r['x1'] + r['x2'], 2),
                            'nb_ventes': r['n'], 'jours_manquants': missing}
        else:
            out['store'] = None
    finally:
        conn.close()
    # --- taxes de la période (même calcul que le Rapport des taxes)
    if _d3_allowed('tax_reports'):
        try:
            rep = local_tax_report(d0, d1)
            t = {'tps': 0.0, 'tvq': 0.0, 'tvh': 0.0, 'autres': 0.0}
            for x in rep['rates']:
                key = {'TPS': 'tps', 'TVQ': 'tvq', 'TVH': 'tvh'}.get(x['taxe'], 'autres')
                t[key] += x['taxe_percue']
            out['taxes'] = {k: round(v, 2) for k, v in t.items()}
            out['taxes']['total'] = rep['totals']['taxes']
            out['taxes']['jours_manquants'] = len(store_missing_days(d0, d1, need_tax=True))
        except Exception:
            traceback.print_exc()
            out['taxes'] = None
    else:
        out['taxes'] = None
    # --- inventaire (dernier instantané)
    if _d3_allowed('inventory_reports'):
        h = db_inventory_history(2)
        if h:
            cur, prev = h[0], (h[1] if len(h) > 1 else None)
            out['inventory'] = {'cost': cur['cost_value'], 'retail': cur['retail_value'], 'items': cur['items'], 'units': cur['units'],
                                'taken_at': cur['taken_at'], 'shop': cur['shop_name'] or 'Tous les magasins',
                                'previous': prev['cost_value'] if prev else None, 'previous_at': prev['taken_at'] if prev else None}
        else:
            out['inventory'] = {'cost': None}
    else:
        out['inventory'] = None
    return out


REP_GL_DEFAULT = {
    'group_label': 'Ventes élargies',
    'categories': {'Ventes': {'gl': '4100', 'groupe': True}, REP_NO_CATEGORY: {'gl': '4190', 'groupe': True},
                   REP_MISC: {'gl': '4150', 'groupe': True}, 'Location': {'gl': '4200', 'groupe': False},
                   'Pièces de rechange': {'gl': '4300', 'groupe': False}, 'Service': {'gl': '4400', 'groupe': False},
                   'Fond de livraison': {'gl': '4500', 'groupe': False}, 'Usage Interne Magasin': {'gl': '4900', 'groupe': False}},
    'payments': {'Visa': '1020', 'Mastercard': '1025', 'Interac (débit)': '1010', 'Compte à recevoir': '1100', 'Comptant': '1000'},
    'taxes': {'TPS': '2310', 'TVQ': '2315', 'TVH': '', 'TVP': ''}}


def rep_gl_cfg():
    try:
        c = json.loads(meta_get('rep_gl') or '{}')
    except ValueError:
        c = {}
    out = json.loads(json.dumps(REP_GL_DEFAULT))
    if c.get('group_label'):
        out['group_label'] = c['group_label']
    for k in ('categories', 'payments', 'taxes'):       # l'enregistré complète et remplace les valeurs par défaut
        if isinstance(c.get(k), dict):
            out[k].update(c[k])
    return out


def _gl_for_category(cfg, name):
    cats = {str(k).strip().lower(): v for k, v in (cfg.get('categories') or {}).items()}
    n = str(name).strip()
    c = cats.get(n.lower()) or cats.get(n.split('/')[0].strip().lower()) or {}
    return (c.get('gl') or '').strip(), bool(c.get('groupe'))


def rep_payments(d0, d1, shop_id='', cfg=None):
    cfg = cfg or rep_gl_cfg()
    conn = get_conn()
    try:
        rows = [dict(r) for r in conn.execute(
            "SELECT COALESCE(NULLIF(TRIM(name),''),'(Autre)') name, SUM(amount) amt, COUNT(*) n FROM sales_payments "
            "WHERE sale_date BETWEEN ? AND ?" + (" AND shop_id=?" if shop_id else "") + " GROUP BY 1",
            [d0.isoformat(), d1.isoformat()] + ([str(shop_id)] if shop_id else [])).fetchall()]
    finally:
        conn.close()
    total = round(sum(r['amt'] or 0 for r in rows), 2)
    out = [{'gl': (cfg['payments'].get(r['name']) or '').strip(), 'mode': r['name'], 'montant': round(r['amt'] or 0, 2), 'paiements': r['n'],
            'part': round((r['amt'] or 0) / total * 100, 1) if abs(total) >= 0.005 else None} for r in rows]
    out.sort(key=lambda r: -r['montant'])
    return out, total


def rep_taxes(d0, d1, shop_id='', cfg=None):
    cfg = cfg or rep_gl_cfg()
    try:
        t = local_tax_report(d0, d1, shop_id)
    except Exception:
        traceback.print_exc()
        return [], 0.0
    labels = {'TPS': 'TPS (fédérale)', 'TVQ': 'TVQ (provinciale)', 'TVH': 'TVH (harmonisée)', 'TVP': 'TVP (provinciale)'}
    out = [{'gl': (cfg['taxes'].get(x['taxe']) or '').strip(), 'type': labels.get(x['taxe'], x['taxe']), 'taux': x['taux'],
            'base': x['ventes_taxables'], 'taxe': x['taxe_percue']} for x in t['rates']]
    return out, round(t['totals']['taxes'], 2)


def rep_accounting_layout(r, cfg=None):
    """Ajoute au rapport par catégorie : comptes GL, sous-total, paiements, taxes."""
    cfg = cfg or rep_gl_cfg()
    for row in r['rows']:
        row['gl'], row['groupe'] = _gl_for_category(cfg, row['categorie'])
    key = lambda x: (x['gl'] == '', x['gl'], -x['total'])
    grp = sorted([x for x in r['rows'] if x['groupe']], key=lambda x: -x['total'])
    rest = sorted([x for x in r['rows'] if not x['groupe']], key=key)
    sub = None
    if grp:
        sub = {k: round(sum(x[k] for x in grp), 2) for k in ('quantite', 'sous_total', 'rabais', 'total', 'cout')}
        sub['profit'] = round(sub['total'] - sub['cout'], 2)
        sub['marge'] = round(sub['profit'] / sub['total'] * 100, 1) if abs(sub['total']) >= 0.005 else None
        sub['part'] = round(sub['total'] / r['totals']['total'] * 100, 1) if abs(r['totals']['total']) >= 0.005 else None
        sub['categorie'] = f"SOUS-TOTAL ({cfg['group_label'] or 'Ventes élargies'})"
    r['rows'] = grp + rest
    r['group_count'] = len(grp)
    r['subtotal'] = sub
    d0, d1 = datetime.date.fromisoformat(r['start']), datetime.date.fromisoformat(r['end'])
    r['payments'], r['payments_total'] = rep_payments(d0, d1, r.get('shop_id') or '', cfg)
    r['taxes'], r['taxes_total'] = rep_taxes(d0, d1, r.get('shop_id') or '', cfg)
    r['grand_total'] = round(r['totals']['total'] + r['taxes_total'], 2)
    return r


@app.route('/rapport-taxes')
def tax_report_page():
    resp = permission_required_check('tax_reports')
    if resp is not None:
        return resp
    return render_template('tax_report.html', company=get_company_name(), username=session.get('username'),
                           is_admin=session.get('is_admin'))


@app.route('/api/taxes/status')
def api_taxes_status():
    resp = permission_required_check('tax_reports')
    if resp is not None:
        return resp
    ss = _store_state
    conn = get_conn()
    shops = [dict(r) for r in conn.execute("SELECT shop_id id, name FROM ls_shops WHERE archived=0 ORDER BY name").fetchall()]
    conn.close()
    return jsonify({'connected': ls_config()['connected'], 'is_admin': bool(session.get('is_admin')),
                    'running': ss['running'], 'progress': ss['progress'], 'job': ss['kind'] if ss['running'] else None,
                    'error': _rep_state['error'] or (ss['error'] if not ss['running'] else None),
                    'result': _rep_state.get('taxes') if not ss['running'] else None, 'shops': shops})


@app.route('/api/taxes/report', methods=['POST'])
def api_taxes_report():
    resp = permission_required_check('tax_reports')
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}
    try:
        start, end = _rep_dates(data)
    except ValueError:
        return jsonify({'ok': False, 'error': "Dates invalides."}), 400
    if end < start:
        return jsonify({'ok': False, 'error': "La date de fin est avant la date de début."}), 400
    end = min(end, datetime.date.today())
    if start > end:
        return jsonify({'ok': False, 'error': "La période choisie est dans le futur."}), 400
    if (end - start).days > 800:
        return jsonify({'ok': False, 'error': "Période trop longue (maximum environ 2 ans)."}), 400
    shop_id = str(data.get('shop_id') or '').strip()
    refresh = bool(data.get('refresh'))
    if refresh:
        # Relire TOUTE la période dans Lightspeed (ventes modifiées, annulées ou
        # retournées après coup) : les lignes gardées sont remplacées.
        if not ls_config()['connected']:
            return jsonify({'ok': False, 'error': "Kubios n'est pas connecté à Lightspeed (Administration → Lightspeed)."}), 400
        missing = [start + datetime.timedelta(days=i) for i in range((end - start).days + 1)]
    else:
        missing = store_missing_days(start, end, need_tax=True)
    if missing and not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Des jours de cette période ne sont pas encore dans Kubios et Kubios n'est "
                                              "pas connecté à Lightspeed (Administration → Lightspeed)."}), 400
    user = session.get('username')
    _rep_state['error'] = None
    try:
        ready = _rep_run_local('taxes', missing, lambda: local_tax_report(start, end, shop_id, user), user)
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    log_audit('Rapport des taxes ' + ('régénéré à partir de Lightspeed' if refresh else 'demandé'),
              f"{start} au {end}" + (f", magasin #{shop_id}" if shop_id else ""))
    return jsonify({'ok': True, 'ready': ready, 'missing': len(missing), 'refresh': refresh})


@app.route('/api/taxes/export/pdf')
def api_taxes_export_pdf():
    resp = permission_required_check('tax_reports')
    if resp is not None:
        return resp
    r = _rep_state.get('taxes')
    if not r:
        return jsonify({'error': "Aucun rapport à exporter : génère-le d'abord."}), 400
    path = export_tax_pdf(r)
    return send_file(str(path), as_attachment=True, download_name=path.name)


@app.route('/valeur-inventaire')
def inventory_report_page():
    resp = permission_required_check('inventory_reports')
    if resp is not None:
        return resp
    return render_template('inventory.html', company=get_company_name(), username=session.get('username'),
                           is_admin=session.get('is_admin'))


@app.route('/api/inventory/status')
def api_inventory_status():
    resp = permission_required_check('inventory_reports')
    if resp is not None:
        return resp
    conn = get_conn()
    shops = [dict(r) for r in conn.execute("SELECT shop_id id, name FROM ls_shops WHERE archived=0 ORDER BY name").fetchall()]
    conn.close()
    st = _inv_state
    out = {'connected': ls_config()['connected'], 'is_admin': bool(session.get('is_admin')), 'running': st['running'],
           'progress': st['progress'], 'error': st['error'] if not st['running'] else None, 'last_id': st['last_id'],
           'history': db_inventory_history(), 'shops': shops, 'last_error': meta_get('inv_last_error'),
           'last_send': st['last_send'] if not st['running'] else None, 'recipients': inv_cfg()['recipients']}
    if session.get('is_admin'):
        out['settings'] = inv_cfg()
    return jsonify(out)


@app.route('/api/inventory/snapshot', methods=['POST'])
def api_inventory_take():
    resp = permission_required_check('inventory_reports')
    if resp is not None:
        return resp
    if not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Kubios n'est pas connecté à Lightspeed (Administration → Lightspeed)."}), 400
    data = request.get_json(silent=True) or {}
    shop_id = str(data.get('shop_id') or '').strip()
    send_to = sorted({e.strip() for e in (data.get('send_to') or []) if isinstance(e, str) and e.strip()})
    bad = [e for e in send_to if not _EMAIL_RE.match(e)]
    if bad:
        return jsonify({'ok': False, 'error': "Adresse invalide : " + ", ".join(bad)}), 400
    if data.get('send') and not send_to:
        return jsonify({'ok': False, 'error': "Choisis au moins un destinataire."}), 400
    user = session.get('username')
    then = None
    if send_to:
        def then(sid):
            sent, errors = send_inventory_email(sid, send_to, user)
            _inv_state['last_send'] = {'snapshot_id': sid, 'sent': sent, 'errors': errors}
    try:
        start_inventory_job('manuel', user, shop_id, then=then)
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    return jsonify({'ok': True})


@app.route('/api/inventory/snapshot/<int:sid>')
def api_inventory_get(sid):
    resp = permission_required_check('inventory_reports')
    if resp is not None:
        return resp
    s = db_inventory_snapshot(sid)
    return jsonify(s) if s else (jsonify({'error': 'Instantané introuvable.'}), 404)


@app.route('/api/inventory/snapshot/<int:sid>', methods=['DELETE'])
def api_inventory_delete(sid):
    resp = admin_required_check()
    if resp is not None:
        return resp
    conn = get_conn()
    s = conn.execute("SELECT taken_at, cost_value FROM inventory_snapshots WHERE id=?", (sid,)).fetchone()
    conn.execute("DELETE FROM inventory_snapshot_lines WHERE snapshot_id=?", (sid,))
    conn.execute("DELETE FROM inventory_snapshots WHERE id=?", (sid,))
    conn.commit()
    conn.close()
    if s:
        log_audit("Instantané de l'inventaire supprimé", f"{s['taken_at'][:16]} — {_fmt_money_fr(s['cost_value'])}")
    return jsonify({'ok': True})


@app.route('/api/inventory/snapshot/<int:sid>/pdf')
def api_inventory_pdf(sid):
    resp = permission_required_check('inventory_reports')
    if resp is not None:
        return resp
    if not db_inventory_snapshot(sid):
        return jsonify({'error': 'Instantané introuvable.'}), 404
    path = export_inventory_pdf(sid)
    return send_file(str(path), as_attachment=True, download_name=path.name)


@app.route('/api/inventory/snapshot/<int:sid>/send', methods=['POST'])
def api_inventory_send(sid):
    resp = permission_required_check('inventory_reports')
    if resp is not None:
        return resp
    emails = sorted({e.strip() for e in ((request.get_json(silent=True) or {}).get('emails') or []) if isinstance(e, str) and e.strip()})
    bad = [e for e in emails if not _EMAIL_RE.match(e)]
    if not emails or bad:
        return jsonify({'ok': False, 'error': ("Adresse invalide : " + ", ".join(bad)) if bad else "Choisis au moins un destinataire."}), 400
    if not db_inventory_snapshot(sid):
        return jsonify({'ok': False, 'error': 'Instantané introuvable.'}), 404
    sent, errors = send_inventory_email(sid, emails, session.get('username'))
    return jsonify({'ok': bool(sent), 'sent': sent, 'errors': errors, 'error': "; ".join(errors) if errors and not sent else None})


@app.route('/api/inventory/settings', methods=['POST'])
def api_inventory_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    recips = sorted({e.strip() for e in (d.get('recipients') or []) if isinstance(e, str) and e.strip()})
    bad = [e for e in recips if not _EMAIL_RE.match(e)]
    if bad:
        return jsonify({'ok': False, 'error': "Adresse invalide : " + ", ".join(bad)}), 400
    day = str(d.get('day') or '1')
    try:
        hour = int(d.get('hour', 6))
        if day != 'last' and not 1 <= int(day) <= 28 or not 0 <= hour <= 23:
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': "Jour ou heure invalide."}), 400
    meta_set('inv_auto', '1' if d.get('auto') else '0')
    meta_set('inv_day', day)
    meta_set('inv_hour', hour)
    meta_set('inv_method', d.get('method') if d.get('method') in INV_METHODS else 'avg')
    meta_set('inv_recipients', json.dumps(recips))
    log_audit("Paramètres de la valeur de l'inventaire modifiés",
              (f"chaque mois le {'dernier jour' if day == 'last' else day} à {hour} h" if d.get('auto') else "planification désactivée")
              + f" ; {INV_METHODS.get(d.get('method'), 'coût moyen')} ; destinataires : {', '.join(recips) or 'aucun'}")
    return jsonify({'ok': True})


@app.route('/tableau-de-bord-3d')
def dashboard3d_page():
    resp = permission_required_check('dashboard3d')
    if resp is not None:
        return resp
    local = three_local_ready()
    if not local:
        ensure_three_vendor_async()          # la prochaine ouverture utilisera la copie locale
    return render_template('dashboard3d.html', company=get_company_name(), three_local=local)


@app.route('/api/dashboard3d/data')
def api_dashboard3d_data():
    resp = permission_required_check('dashboard3d')
    if resp is not None:
        return resp
    return jsonify(dashboard3d_data(request.args.get('periode', 'mois_dernier')))


@app.route('/api/reports/gl', methods=['GET', 'POST'])
def api_reports_gl():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if request.method == 'POST':
        d = request.get_json(silent=True) or {}
        clean = lambda v: re.sub(r'[^0-9A-Za-z.\-]', '', str(v or ''))[:20]
        cfg = {'group_label': str(d.get('group_label') or 'Ventes élargies')[:60],
               'categories': {str(k)[:200]: {'gl': clean(v.get('gl')), 'groupe': bool(v.get('groupe'))}
                              for k, v in (d.get('categories') or {}).items() if isinstance(v, dict)},
               'payments': {str(k)[:120]: clean(v) for k, v in (d.get('payments') or {}).items()},
               'taxes': {k: clean((d.get('taxes') or {}).get(k)) for k in ('TPS', 'TVQ', 'TVH', 'TVP')}}
        meta_set('rep_gl', json.dumps(cfg, ensure_ascii=False))
        log_audit('Rapport des ventes : comptes GL modifiés', f"{len(cfg['categories'])} catégorie(s), {len(cfg['payments'])} mode(s) de paiement")
        return jsonify({'ok': True})
    conn = get_conn()
    try:
        cats = [r['name'] for r in conn.execute("SELECT name FROM ls_categories WHERE path NOT LIKE '%/%' OR path IS NULL ORDER BY name COLLATE NOCASE").fetchall()]
        pays = [r['name'] for r in conn.execute("SELECT DISTINCT name FROM sales_payments WHERE name IS NOT NULL AND TRIM(name)<>'' ORDER BY name").fetchall()]
        pays = sorted(set(pays) | set(rep_gl_cfg()['payments']), key=str.lower)
    finally:
        conn.close()
    cfg = rep_gl_cfg()
    known = {c.lower() for c in cats}
    cats += [c for c in cfg['categories'] if c.lower() not in known and c not in (REP_NO_CATEGORY, REP_MISC)]
    return jsonify({'config': cfg, 'categories': cats + [REP_NO_CATEGORY, REP_MISC], 'payments': pays})


@app.route('/rapports-personnalises')
def custom_reports_page():
    resp = permission_required_check('custom_reports')
    if resp is not None:
        return resp
    return render_template('custom_reports.html', company=get_company_name(),
                           username=session.get('username'), is_admin=session.get('is_admin'),
                           permissions=session.get('permissions') or [])


def _rep_run_local(kind, days_needed, compute, username):
    """Calcule un rapport à partir de la base locale ; si des jours manquent,
    les récupère d'abord dans Lightspeed (en arrière-plan)."""
    st = _rep_state
    st.update(error=None)
    if not days_needed:
        st[kind] = compute()
        return True
    st[kind] = None

    def then():
        try:
            st[kind] = compute()
        except Exception as e:
            traceback.print_exc()
            st['error'] = f"Erreur inattendue : {e}"
    start_store_job('période demandée', days_needed, username, then=then)
    return False


@app.route('/api/reports/status')
def api_reports_status():
    resp = permission_required_check('custom_reports')
    if resp is not None:
        return resp
    st, ss = _rep_state, _store_state
    cfg = ls_config()
    conn = get_conn()
    shops = [dict(r) for r in conn.execute("SELECT shop_id id, name FROM ls_shops WHERE archived=0 ORDER BY name").fetchall()]
    sends = [dict(r) for r in conn.execute("SELECT * FROM report_sends ORDER BY id DESC LIMIT 25").fetchall()]
    conn.close()
    sc = store_cfg()
    running = ss['running']
    return jsonify({'connected': cfg['connected'], 'is_admin': bool(session.get('is_admin')),
                    'running': running, 'progress': ss['progress'], 'job': ss['kind'] if running else None,
                    'error': st['error'] or (ss['error'] if not running else None),
                    'result': st.get('result') if not running else None,
                    'comparison': st.get('comparison') if not running else None,
                    'shops': shops, 'store': store_status(), 'sends': sends,
                    'recipients': sc['recipients'], 'last_week': last_week_bounds()[0].isoformat(),
                    'settings': {k: sc[k] for k in ('enabled', 'start', 'hour', 'auto_daily', 'auto_weekly',
                                                    'daily_level', 'weekly_level', 'bcc_company')},
                    'company_email': get_company_email(), 'send_now': dict(_send_now_state)})


@app.route('/api/reports/send-now', methods=['POST'])
def api_reports_send_now():
    resp = admin_required_check()
    if resp is not None:
        return resp
    kind = (request.get_json(silent=True) or {}).get('kind')
    if kind not in ('daily', 'weekly'):
        return jsonify({'ok': False, 'error': 'Rapport inconnu.'}), 400
    cfg = store_cfg()
    to = [x['email'] for x in cfg['recipients'] if x.get('daily' if kind == 'daily' else 'weekly') and x.get('email')]
    if not to:
        return jsonify({'ok': False, 'error': "Aucun gestionnaire n'est coché pour ce rapport dans la liste ci-dessus."}), 400
    _start, missing = _send_now_days(kind)
    if missing and not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Des jours ne sont pas encore dans Kubios et Kubios n'est pas connecté à Lightspeed."}), 400
    if _send_now_state['running']:
        return jsonify({'ok': False, 'error': 'Un envoi est déjà en cours.'}), 409
    if missing and _store_state['running']:
        return jsonify({'ok': False, 'error': 'Une lecture Lightspeed est déjà en cours. Réessaie dans quelques minutes.'}), 409
    _send_now_state.update(running=True, error=None, kind=kind, message='Envoi en cours…')
    threading.Thread(target=_send_now_worker, daemon=True,
                     args=(kind, to, cfg['daily_level'] if kind == 'daily' else cfg['weekly_level'], session.get('username'))).start()
    return jsonify({'ok': True, 'recipients': to, 'missing': len(missing)})


def _rep_dates(data):
    start = datetime.date.fromisoformat(data.get('start') or '')
    end = datetime.date.fromisoformat(data.get('end') or '')
    return start, end


@app.route('/api/reports/sales-by-category', methods=['POST'])
def api_reports_sales_by_category():
    resp = permission_required_check('custom_reports')
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}
    try:
        start, end = _rep_dates(data)
    except ValueError:
        return jsonify({'ok': False, 'error': "Dates invalides."}), 400
    if end < start:
        return jsonify({'ok': False, 'error': "La date de fin est avant la date de début."}), 400
    end = min(end, datetime.date.today())
    level = 'top' if data.get('level') == 'top' else 'full'
    shop_id = str(data.get('shop_id') or '').strip()
    missing = store_missing_days(start, end, need_tax=True, need_pay=True)
    if missing and not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Des jours de cette période ne sont pas encore dans Kubios et Kubios n'est "
                                              "pas connecté à Lightspeed (Administration → Lightspeed)."}), 400
    user = session.get('username')
    try:
        ready = _rep_run_local('result', missing, lambda: local_sales_by_category(start, end, shop_id, level, user), user)
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    return jsonify({'ok': True, 'ready': ready, 'missing': len(missing)})


@app.route('/api/reports/weekly', methods=['POST'])
def api_reports_weekly():
    resp = permission_required_check('custom_reports')
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}
    try:
        w0 = datetime.date.fromisoformat(data.get('week_start') or '')
    except ValueError:
        return jsonify({'ok': False, 'error': "Semaine invalide."}), 400
    w0 = w0 - datetime.timedelta(days=w0.weekday())
    w1 = min(w0 + datetime.timedelta(days=6), datetime.date.today())
    level = 'full' if data.get('level') == 'full' else 'top'
    shop_id = str(data.get('shop_id') or '').strip()
    missing = store_missing_days(w0, w1) + store_missing_days(w0 - datetime.timedelta(days=364),
                                                               w0 - datetime.timedelta(days=358))
    if missing and not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Des jours ne sont pas encore dans Kubios et Kubios n'est pas connecté à Lightspeed."}), 400
    user = session.get('username')
    try:
        ready = _rep_run_local('comparison', missing, lambda: weekly_comparison(w0, shop_id, level, user), user)
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    return jsonify({'ok': True, 'ready': ready, 'missing': len(missing)})


@app.route('/api/reports/weekly/export/<fmt>')
def api_reports_weekly_export(fmt):
    resp = permission_required_check('custom_reports')
    if resp is not None:
        return resp
    r = _rep_state.get('comparison')
    if not r:
        return jsonify({'error': "Aucun comparatif à exporter : génère-le d'abord."}), 400
    path = export_comparison_xlsx(r) if fmt == 'xlsx' else export_comparison_pdf(r)
    return send_file(str(path), as_attachment=(fmt == 'xlsx'), download_name=path.name)


_EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')


@app.route('/api/reports/send', methods=['POST'])
def api_reports_send():
    resp = permission_required_check('custom_reports')
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}
    r = _rep_state.get('comparison' if data.get('kind') == 'weekly' else 'result')
    if not r:
        return jsonify({'ok': False, 'error': "Génère d'abord le rapport."}), 400
    emails = sorted({e.strip() for e in (data.get('emails') or []) if isinstance(e, str) and e.strip()})
    bad = [e for e in emails if not _EMAIL_RE.match(e)]
    if not emails or bad:
        return jsonify({'ok': False, 'error': "Adresse invalide : " + ", ".join(bad) if bad else "Choisis au moins un destinataire."}), 400
    try:
        sent, errors = send_report_email(r, emails, session.get('username'),
                                         bcc_company=bool(data.get('bcc_company')))
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': f"Envoi impossible : {e}"}), 500
    return jsonify({'ok': bool(sent), 'sent': sent, 'errors': errors,
                    'error': "; ".join(errors) if errors and not sent else None})


@app.route('/api/reports/settings', methods=['POST'])
def api_reports_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}
    recips = []
    for x in data.get('recipients') or []:
        e = (x.get('email') or '').strip()
        if not e:
            continue
        if not _EMAIL_RE.match(e):
            return jsonify({'ok': False, 'error': f"Adresse invalide : {e}"}), 400
        recips.append({'name': (x.get('name') or '').strip(), 'email': e,
                       'daily': bool(x.get('daily')), 'weekly': bool(x.get('weekly'))})
    try:
        start = datetime.date.fromisoformat(data.get('start') or STORE_DEFAULT_START)
        hour = int(data.get('hour', 1))
        if not 0 <= hour <= 23:
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': "Date de départ ou heure invalide."}), 400
    meta_set('rep_recipients', json.dumps(recips, ensure_ascii=False))
    meta_set('rep_history_start', start.isoformat())
    meta_set('rep_nightly_hour', hour)
    meta_set('rep_store_enabled', '1' if data.get('enabled', True) else '0')
    meta_set('rep_auto_daily', '1' if data.get('auto_daily') else '0')
    meta_set('rep_auto_weekly', '1' if data.get('auto_weekly') else '0')
    meta_set('rep_daily_level', 'top' if data.get('daily_level') == 'top' else 'full')
    meta_set('rep_weekly_level', 'full' if data.get('weekly_level') == 'full' else 'top')
    meta_set('rep_bcc_company', '1' if data.get('bcc_company') else '0')
    log_audit('Paramètres des rapports automatiques modifiés',
              f"{len(recips)} gestionnaire(s) ; quotidien {'oui' if data.get('auto_daily') else 'non'} ; "
              f"hebdomadaire {'oui' if data.get('auto_weekly') else 'non'} ; à {hour} h ; historique depuis {start}")
    return jsonify({'ok': True})


@app.route('/api/reports/history/start', methods=['POST'])
def api_reports_history_start():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Kubios n'est pas connecté à Lightspeed."}), 400
    start = datetime.date.fromisoformat(store_cfg()['start'])
    yesterday = datetime.date.today() - datetime.timedelta(days=1)
    missing = store_missing_days(start, yesterday)
    if not missing:
        return jsonify({'ok': True, 'missing': 0})
    try:
        start_store_job('historique', missing, session.get('username'))
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    return jsonify({'ok': True, 'missing': len(missing)})


@app.route('/api/reports/nightly/run', methods=['POST'])
def api_reports_nightly_run():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if _store_state['running']:
        return jsonify({'ok': False, 'error': "Une récupération est déjà en cours."}), 409
    threading.Thread(target=nightly_reports_run, daemon=True).start()
    log_audit('Tâche de nuit des rapports lancée manuellement')
    return jsonify({'ok': True})


@app.route('/api/reports/sales-by-category/export/<fmt>')
def api_reports_export(fmt):
    resp = permission_required_check('custom_reports')
    if resp is not None:
        return resp
    r = _rep_state.get('result')
    if not r:
        return jsonify({'error': "Aucun rapport à exporter : génère-le d'abord."}), 400
    try:
        path = export_report_xlsx(r) if fmt == 'xlsx' else export_report_pdf(r) if fmt == 'pdf' else None
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': f"Exportation impossible : {e}"}), 500
    if path is None:
        return jsonify({'error': 'Format inconnu.'}), 400
    return send_file(str(path), as_attachment=(fmt == 'xlsx'), download_name=path.name)
