# -*- coding: utf-8 -*-
"""Outils RH partagés : employés, documents et signatures, évaluations, calcul des heures, horaires, congés, courriels RH.
Module de Kubios (découpé de app.py en 1.47.0, code inchangé)."""
import os
import re
import io
import csv
import sys
import json
import base64
import hashlib
import unicodedata
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import openpyxl
from openpyxl.utils import get_column_letter
import licensing
from kubios_base import AT_FMT, _at_now, client_ip, get_company_name, get_conn, meta_get, meta_set
from kubios_mail import send_email
from kubios_pdf import _at_doc, _at_pdf_kit
from kubios_version import APP_NAME
from kubios_app import BASE_DIR, app
from kubios_auth import permission_required_check
from kubios_systeme import login_bg_mode, login_bg_url, login_video_url
from kubios_atelier_outils import at_profit

__all__ = ['HR_CRITERIA', 'HR_DIR', 'HR_DOC_CATS', 'HR_DOC_EXT', 'HR_DOC_MAX', 'HR_FIELDS', 'HR_NOTE_KINDS', 'HR_SCALE', 'HR_STATUS', 'HR_TEMPLATES', 'JOURS_CRT', 'JOURS_FR', 'LEAVE_KINDS', 'LEAVE_STATUS', 'PDF_DIR', 'SCHED_DEFAULT_TEMPLATES', 'SCHED_MEALS', 'TC_BREAK_PAID_MAX', 'TC_COOKIE', 'TC_KINDS', 'TC_MAX_AGE', 'TC_OT_WEEK', '_MOIS_FR', '_d', '_emp_render', '_esc', '_hm', '_hm_min', '_hr_check', '_hr_emp', '_leave_html_card', '_leave_summary_rows', '_pc', '_sched_period', '_sched_same', '_tc_dt', '_tc_fail', '_tc_period_from_args', '_tc_rows', 'emp_session_emp', 'export_hr_eval_pdf', 'export_hr_letter_pdf', 'export_sched_emp_pdf', 'export_sched_pdf', 'export_tc_pdf', 'export_tc_xlsx', 'hm_txt', 'hr_atelier_stats', 'hr_build_signed_pdf', 'hr_criteria', 'hr_doc_file_hash', 'hr_emp_name', 'hr_log', 'hr_reminders', 'hr_sig_clean', 'hr_store_file', 'hr_templates', 'leave_apply_schedule', 'leave_approver_config', 'leave_approvers', 'leave_auto_note', 'leave_notify_managers', 'leaves_in_range', 'sched_cells', 'sched_compare', 'sched_day_fr', 'sched_email_html', 'sched_employees', 'sched_label', 'sched_paid_min', 'sched_period_of', 'sched_settings', 'tc_allowed', 'tc_authorize', 'tc_day_details', 'tc_days', 'tc_events', 'tc_link_token', 'tc_period_of', 'tc_secret', 'tc_settings', 'tc_sheet', 'tc_state']


PDF_DIR = BASE_DIR / "Etats_de_compte"


def _d(x):
    return f"{x[8:10]}-{x[5:7]}-{x[:4]}"


_MOIS_FR = ('janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre',
            'octobre', 'novembre', 'décembre')


def _hm(sec):
    sec = int(round((sec or 0) / 60)); return f"{sec // 60} h {sec % 60:02d}"


def _pc(v):
    return '—' if v is None else f"{v:g} %".replace('.', ',')


HR_DIR = BASE_DIR / "Dossiers_RH"


HR_DOC_EXT = {'.pdf', '.png', '.jpg', '.jpeg', '.webp', '.docx', '.xlsx', '.txt'}


HR_DOC_MAX = 15 * 1024 * 1024


HR_DOC_CATS = {'contrat': 'Contrat / embauche', 'formation': 'Formation', 'certification': 'Certification', 'evaluation': 'Évaluation',
               'evaluation_atelier': "Fiche d'évaluation (atelier)", 'autre': 'Autre'}


HR_NOTE_KINDS = {'felicitation': 'Félicitation', 'rencontre': 'Rencontre', 'avertissement': 'Avertissement', 'note': 'Note'}


HR_STATUS = {'actif': 'Actif', 'probation': 'En probation', 'conge': 'En congé', 'inactif': 'Inactif (parti)'}


HR_SCALE = {1: 'Insatisfaisant', 2: 'À améliorer', 3: 'Répond aux attentes', 4: 'Dépasse les attentes', 5: 'Exceptionnel'}


HR_CRITERIA = [
    ('service', 'Service à la clientèle', "Accueil, écoute, conseils justes, suivi des demandes et des plaintes."),
    ('produits', 'Connaissance des produits et de la location', "Outils, équipement de location, accessoires, conditions de location."),
    ('qualite', 'Qualité du travail', "Minutie, inspection de l'équipement retourné, entretien, propreté du magasin et des aires de travail."),
    ('securite', 'Sécurité', "Port des ÉPI, procédures sécuritaires, démonstration sécuritaire de l'équipement aux clients."),
    ('procedures', 'Respect des procédures', "Caisse, contrats de location, dépôts, inventaire, documents."),
    ('productivite', 'Productivité et gestion du temps', "Volume de travail, priorités, respect des délais."),
    ('fiabilite', 'Fiabilité et ponctualité', "Assiduité, présence, respect de l'horaire."),
    ('equipe', 'Travail d\u2019équipe et communication', "Collaboration, entraide, communication avec les collègues et la direction."),
    ('initiative', 'Initiative et autonomie', "Prendre les devants, proposer des améliorations, apprendre."),
]


def hr_log(conn, emp_id, action):
    conn.execute("INSERT INTO hr_access_log(ts, username, employee_id, action, ip) VALUES (?,?,?,?,?)",
                 (_at_now(), session.get('username') or '?', emp_id, action, client_ip()))


def hr_emp_name(e):
    return f"{e['first_name'] or ''} {e['last_name'] or ''}".strip()


def hr_reminders(conn):
    t = datetime.date.today(); soon = (t + datetime.timedelta(days=30)).isoformat(); ti = t.isoformat()
    out = []
    for r in conn.execute("SELECT d.*, e.first_name, e.last_name FROM hr_documents d JOIN hr_employees e ON e.id=d.employee_id "
                          "WHERE d.expires_on IS NOT NULL AND d.expires_on<>'' AND d.expires_on<=? AND e.status<>'inactif' ORDER BY d.expires_on", (soon,)).fetchall():
        out.append({'employee_id': r['employee_id'], 'name': hr_emp_name(r), 'date': r['expires_on'], 'late': r['expires_on'] < ti,
                    'text': ('Certification expirée : ' if r['expires_on'] < ti else 'Certification à renouveler : ') + (r['title'] or '')})
    for r in conn.execute("SELECT * FROM hr_employees WHERE status='probation' AND probation_end IS NOT NULL AND probation_end<>'' AND probation_end<=?", (soon,)).fetchall():
        out.append({'employee_id': r['id'], 'name': hr_emp_name(r), 'date': r['probation_end'], 'late': r['probation_end'] < ti, 'text': 'Fin de la probation'})
    for r in conn.execute("SELECT * FROM hr_employees WHERE status<>'inactif' AND next_review IS NOT NULL AND next_review<>'' AND next_review<=?", (soon,)).fetchall():
        out.append({'employee_id': r['id'], 'name': hr_emp_name(r), 'date': r['next_review'], 'late': r['next_review'] < ti, 'text': 'Évaluation à faire'})
    for r in conn.execute("SELECT v.*, e.first_name, e.last_name FROM hr_evaluations v JOIN hr_employees e ON e.id=v.employee_id WHERE v.status='brouillon'").fetchall():
        out.append({'employee_id': r['employee_id'], 'name': hr_emp_name(r), 'date': r['eval_date'] or '', 'late': False, 'text': 'Évaluation en brouillon à terminer'})
    out.sort(key=lambda x: x['date'] or '9999')
    return out


def hr_store_file(emp_id, data, original, category, title, expires=None, username=None, conn=None):
    ext = Path(original).suffix.lower()
    d = HR_DIR / str(emp_id); d.mkdir(parents=True, exist_ok=True)
    fname = f"{datetime.datetime.now():%Y%m%d_%H%M%S}_{secrets.token_hex(4)}{ext}"
    (d / fname).write_bytes(data)
    own = conn is None
    conn = conn or get_conn()
    try:
        cur = conn.execute("INSERT INTO hr_documents(employee_id, category, title, filename, original_name, size, expires_on, created_at, created_by) "
                           "VALUES (?,?,?,?,?,?,?,?,?)", (emp_id, category, title[:200], fname, Path(original).name[:200], len(data), expires or None,
                                                          _at_now(), username or session.get('username') or '?'))
        if own:
            conn.commit()
        return cur.lastrowid
    finally:
        if own:
            conn.close()


def hr_atelier_stats(emp, d0, d1):
    """Statistiques d'atelier de la période pour un employé relié à un mécanicien (sans coûts)."""
    if not emp['mechanic_id']:
        return None
    r = at_profit({'start': d0, 'end': d1})
    m = next((x for x in r['mechanics'] if x['id'] == emp['mechanic_id']), None)
    if not m:
        return {'jobs_count': 0}
    return {k: m[k] for k in ('jobs_count', 'done_count', 'seconds', 'billed_minutes', 'yield', 'real_rate', 'over_count', 'billed_count',
                              'problems', 'corrections')} | {'shop_yield': r['totals']['yield']}


def export_hr_eval_pdf(emp, ev):
    k = _at_pdf_kit(); Tb, TS, Pa, C, mm = k['Table'], k['TableStyle'], k['Paragraph'], k['colors'], k['mm']
    d = HR_DIR / str(emp['id']); d.mkdir(parents=True, exist_ok=True)
    path = d / f"_apercu_evaluation_{ev['id']}.pdf"
    per = f"Du {_d(ev['period_start'])} au {_d(ev['period_end'])}" if ev['period_start'] and ev['period_end'] else ''
    doc, header = _at_doc(path, k, "Évaluation du rendement", f"{hr_emp_name(emp)} · {emp['position'] or ''} · {per}")
    scores = json.loads(ev['scores'] or '{}')
    story = [Pa(hr_emp_name(emp), k['h1']),
             Pa(f"Poste : <b>{emp['position'] or '—'}</b> · Embauché le {_d(emp['hire_date']) if emp['hire_date'] else '—'} · "
                f"Évaluation du {_d(ev['eval_date']) if ev['eval_date'] else '—'} · Évaluateur : <b>{ev['evaluator'] or '—'}</b>", k['small']),
             Pa(f"Période évaluée : {per or '—'}", k['small']), k['Spacer'](1, 6)]
    rows = [["Critère", "Note", "Appréciation", "Commentaire"]]
    crit = json.loads(ev.get('criteria') or 'null') or [{'key': c['key'], 'label': c['label'], 'hint': c['hint']} for c in hr_criteria()]
    for c in crit:
        sc = scores.get(c['key']) or {}
        v = sc.get('score')
        rows.append([Pa(f"<b>{c['label']}</b><br/><font size=7 color='#6b7280'>{c['hint']}</font>", k['cell']), f"{v} / 5" if v else ('S.O.' if sc.get('na') else '—'),
                     HR_SCALE.get(int(v), '') if v else ('Ne s’applique pas' if sc.get('na') else ''), Pa((sc.get('comment') or '').replace('<', '&lt;'), k['cell'])])
    rows.append([Pa('<b>Moyenne générale</b>', k['cell']), f"{ev['overall']:.1f} / 5".replace('.', ',') if ev['overall'] else '—',
                 HR_SCALE.get(int(round(ev['overall'])), '') if ev['overall'] else '', ''])
    t = Tb(rows, colWidths=[70 * mm, 16 * mm, 34 * mm, 66 * mm], repeatRows=1)
    t.setStyle(TS(k['base'] + [('ALIGN', (1, 0), (1, -1), 'CENTER'), ('VALIGN', (0, 1), (-1, -1), 'TOP'),
                               ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'), ('BACKGROUND', (0, -1), (-1, -1), C.HexColor('#dbe3f3'))]))
    story.append(t)
    st = json.loads(ev['atelier_stats'] or 'null')
    if st and st.get('jobs_count'):
        story.append(Pa("Statistiques d'atelier de la période", k['h2']))
        rows = [["Bons travaillés", "Heures punchées", "Rendement", "Moy. atelier", "Dépassés +15 min", "Problèmes", "Punchs corrigés"],
                [f"{st['jobs_count']} ({st.get('done_count', 0)} terminés)", _hm(st.get('seconds', 0)), _pc(st.get('yield')), _pc(st.get('shop_yield')),
                 f"{st.get('over_count', 0)} / {st.get('billed_count', 0)}", st.get('problems', 0), st.get('corrections', 0)]]
        t = Tb(rows, colWidths=[30 * mm, 24 * mm, 22 * mm, 26 * mm, 30 * mm, 26 * mm, 26 * mm]); t.setStyle(TS(k['base'] + [('ALIGN', (0, 0), (-1, -1), 'CENTER')])); story.append(t)
    for title, val in (("Points forts", ev['strengths']), ("Points à améliorer", ev['improvements']), ("Objectifs pour la prochaine période", ev['objectives']),
                       ("Commentaires de l'employé", ev['employee_comments'])):
        story.append(Pa(title, k['h2']))
        story.append(Pa((val or '—').replace('<', '&lt;').replace('\n', '<br/>'), k['cell']))
    sig = Tb([["Signature de l'évaluateur", "", "Signature de l'employé", "", "Date"], ["", "", "", "", ""]],
             colWidths=[52 * mm, 8 * mm, 52 * mm, 8 * mm, 60 * mm], rowHeights=[6 * mm, 12 * mm])
    sig.setStyle(TS([('FONTSIZE', (0, 0), (-1, -1), 8), ('TEXTCOLOR', (0, 0), (-1, 0), C.HexColor('#4b5563')),
                     ('LINEBELOW', (0, 1), (0, 1), .5, C.black), ('LINEBELOW', (2, 1), (2, 1), .5, C.black), ('LINEBELOW', (4, 1), (4, 1), .5, C.black)]))
    story += [k['Spacer'](1, 10), Pa("La signature de l'employé confirme qu'il a pris connaissance de l'évaluation, pas nécessairement qu'il est d'accord.", k['small']),
              k['Spacer'](1, 4), sig]
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


HR_TEMPLATES = {
    'avertissement': {'title': 'Avertissement écrit', 'category': 'disciplinaire', 'note_kind': 'avertissement', 'employee_sign': True, 'witness': True,
                      'ack': "En signant ce document, l'employé confirme l'avoir reçu et en avoir pris connaissance. Sa signature ne signifie pas qu'il est d'accord avec son contenu. Il peut inscrire ses commentaires ci-dessous.",
                      'sections': [('objet', 'Objet (motif de l\u2019avertissement)', '', 1),
                                   ('faits', 'Description des faits', '', 5),
                                   ('attentes', 'Attentes et mesures correctives', "Nous nous attendons à ce que la situation soit corrigée immédiatement et de façon durable. N'hésite pas à demander de l'aide à ton responsable au besoin.", 4),
                                   ('consequences', 'Conséquences en cas de récidive', "Tout nouveau manquement de même nature, ou tout autre manquement, pourrait entraîner des mesures disciplinaires plus sévères, pouvant aller jusqu'au congédiement.", 3)]},
    'felicitation': {'title': 'Lettre de reconnaissance', 'category': 'lettre', 'note_kind': 'felicitation', 'employee_sign': False, 'witness': False, 'ack': '',
                     'sections': [('objet', 'Objet', '', 1),
                                  ('texte', 'Message', "Nous tenons à souligner ton excellent travail et ton engagement envers l'entreprise et nos clients. Merci !", 6)]},
    'rencontre': {'title': 'Compte rendu de rencontre', 'category': 'lettre', 'note_kind': 'rencontre', 'employee_sign': True, 'witness': False,
                  'ack': "Les signatures confirment que la rencontre a eu lieu et que le compte rendu a été remis à l'employé.",
                  'sections': [('objet', 'Objet de la rencontre', '', 1), ('presents', 'Personnes présentes', '', 1),
                               ('points', 'Points discutés', '', 5), ('suivis', 'Décisions et suivis', '', 4)]},
    'attestation': {'title': "Attestation d'emploi", 'category': 'lettre', 'note_kind': 'note', 'employee_sign': False, 'witness': False, 'ack': '',
                    'sections': [('texte', 'Texte de l\u2019attestation', "Nous attestons que {nom} est à l'emploi de {entreprise} depuis le {embauche}, au poste de {poste}.", 4),
                                 ('ajout', 'Précisions (facultatif)', '', 2)]},
}
HR_DOC_CATS.update({'disciplinaire': 'Mesure disciplinaire', 'lettre': 'Lettre / document créé'})   # (déplacé de app.py en 1.50.0)


def hr_criteria(active_only=True):
    try:
        saved = json.loads(meta_get('hr_criteria') or 'null')
    except ValueError:
        saved = None
    lst = saved if isinstance(saved, list) and saved else [{'key': k, 'label': l, 'hint': h, 'active': True} for k, l, h in HR_CRITERIA]
    return [c for c in lst if c.get('active', True)] if active_only else lst


def hr_templates():
    try:
        ov = json.loads(meta_get('hr_doc_templates') or '{}')
    except ValueError:
        ov = {}
    out = {}
    for t, tpl in HR_TEMPLATES.items():
        o = ov.get(t, {})
        out[t] = {'title': tpl['title'], 'employee_sign': tpl['employee_sign'], 'witness': tpl['witness'], 'ack': o.get('ack', tpl['ack']),
                  'sections': [{'key': k, 'label': l, 'default': (o.get('defaults') or {}).get(k, d), 'rows': r} for k, l, d, r in tpl['sections']]}
    return out


def export_hr_letter_pdf(emp, ttype, doc_date, fields, author, path):
    """Document RH créé à partir d'un modèle (avertissement, reconnaissance, rencontre, attestation)."""
    k = _at_pdf_kit(); Tb, TS, Pa, C, mm = k['Table'], k['TableStyle'], k['Paragraph'], k['colors'], k['mm']
    tpl = hr_templates()[ttype]
    doc, header = _at_doc(path, k, tpl['title'], f"{hr_emp_name(emp)} · {_d(doc_date)}")
    esc_ = lambda t: (t or '').replace('&', '&amp;').replace('<', '&lt;').replace('\n', '<br/>')
    body = k['cell'].clone('body', fontSize=10, leading=14)
    story = [Pa(tpl['title'], k['h1']), k['Spacer'](1, 6)]
    info = Tb([["Employé", hr_emp_name(emp), "Date", _d(doc_date)],
               ["Poste", emp['position'] or '—', "Embauché le", _d(emp['hire_date']) if emp['hire_date'] else '—']], colWidths=[24 * mm, 70 * mm, 26 * mm, 66 * mm])
    info.setStyle(TS([('FONTSIZE', (0, 0), (-1, -1), 9), ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'), ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
                      ('BOX', (0, 0), (-1, -1), .5, C.HexColor('#cbd5e1')), ('INNERGRID', (0, 0), (-1, -1), .25, C.HexColor('#e5e7eb')),
                      ('BACKGROUND', (0, 0), (0, -1), C.HexColor('#f1f5f9')), ('BACKGROUND', (2, 0), (2, -1), C.HexColor('#f1f5f9'))]))
    story += [info, k['Spacer'](1, 6)]
    for s in tpl['sections']:
        v = (fields.get(s['key']) or '').strip()
        if not v:
            continue
        story.append(Pa(s['label'], k['h2'])); story.append(Pa(esc_(v), body))
    if tpl['employee_sign']:
        if tpl['ack']:
            story += [k['Spacer'](1, 6), Pa(tpl['ack'], k['small'])]
        story.append(Pa("Commentaires de l'employé", k['h2']))
        cm = (fields.get('commentaires') or '').strip()
        if cm:
            story.append(Pa(esc_(cm), body))
        else:
            lines = Tb([[''] for _ in range(3)], colWidths=[180 * mm], rowHeights=[7 * mm] * 3)
            lines.setStyle(TS([('LINEBELOW', (0, 0), (-1, -1), .5, C.HexColor('#9ca3af'))])); story.append(lines)
    if tpl['ack'] and not tpl['employee_sign']:
        story += [k['Spacer'](1, 8), Pa(tpl['ack'], k['small'])]
    cols = [("Signature du responsable", author)] + ([("Signature de l'employé", hr_emp_name(emp))] if tpl['employee_sign'] else []) + ([("Signature du témoin", '')] if tpl['witness'] else [])
    n = len(cols); gap = 10; w = (180 - gap * (n - 1)) / n           # une colonne vide entre chaque signature
    grid = lambda vals: sum(([v, ''] for v in vals), [])[:-1]
    widths = sum(([w * mm, gap * mm] for _ in cols), [])[:-1]
    sig = Tb([grid([c[0] for c in cols]), grid(['' for _ in cols]), grid([c[1] for c in cols]), grid(["Date : ______________" for _ in cols])],
             colWidths=widths, rowHeights=[6 * mm, 14 * mm, 5 * mm, 6 * mm])
    st_ = [('FONTSIZE', (0, 0), (-1, -1), 8), ('TEXTCOLOR', (0, 0), (-1, 0), C.HexColor('#4b5563')), ('TEXTCOLOR', (0, 2), (-1, 2), C.HexColor('#111827')),
           ('LEFTPADDING', (0, 0), (-1, -1), 0)]
    st_ += [('LINEBELOW', (2 * i, 1), (2 * i, 1), .5, C.black) for i in range(n)]
    sig.setStyle(TS(st_))
    story += [k['Spacer'](1, 14), sig]
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


TC_COOKIE = 'kubios_poste_presence'


TC_MAX_AGE = 400 * 24 * 3600


TC_BREAK_PAID_MAX = 15 * 60          # pause de 15 min ou moins : payée ; plus longue (dîner) : déduite au complet


TC_OT_WEEK = 40 * 3600               # heures supplémentaires au-delà de 40 h / semaine


TC_KINDS = {'in': 'Entrée', 'break_start': 'Début de pause', 'break_end': 'Retour de pause', 'out': 'Sortie'}


_tc_fail = {}


def tc_settings():
    period = meta_get('tc_period') or 'week'
    try:
        anchor = datetime.date.fromisoformat(meta_get('tc_anchor') or '2026-01-05')
    except ValueError:
        anchor = datetime.date(2026, 1, 5)
    anchor -= datetime.timedelta(days=anchor.weekday())       # toujours un lundi
    return {'period': period if period in ('week', '2weeks') else 'week', 'anchor': anchor}


def tc_period_of(d):
    """(début, fin) de la période de paie qui contient la date d (semaines du lundi au dimanche)."""
    st = tc_settings()
    monday = d - datetime.timedelta(days=d.weekday())
    if st['period'] == 'week':
        return monday, monday + datetime.timedelta(days=6)
    n = (monday - st['anchor']).days // 14
    start = st['anchor'] + datetime.timedelta(days=14 * n)
    return start, start + datetime.timedelta(days=13)


def _tc_dt(s):
    return datetime.datetime.strptime(s, AT_FMT)


def tc_events(conn, emp_id, d0, d1):
    a = (datetime.datetime.combine(d0, datetime.time(0)) - datetime.timedelta(hours=14)).strftime(AT_FMT)
    b = datetime.datetime.combine(d1 + datetime.timedelta(days=1), datetime.time(0)).strftime(AT_FMT)
    return [dict(r) for r in conn.execute("SELECT * FROM tc_events WHERE employee_id=? AND deleted=0 AND ts>=? AND ts<? ORDER BY ts, id",
                                          (emp_id, a, b)).fetchall()]


def tc_days(events, d0, d1, now=None):
    """Calcule chaque journée : heures travaillées (pauses ≤ 15 min payées, plus longues déduites), pauses, oublis."""
    now = now or datetime.datetime.now()
    days = {}
    def day(d):
        return days.setdefault(d, {'date': d.isoformat(), 'worked': 0.0, 'paid_breaks': 0.0, 'unpaid_breaks': 0.0,
                                   'first_in': None, 'last_out': None, 'open': False, 'missing_out': False, 'state': 'out'})
    cur = None
    def close(end, missing=False):
        nonlocal cur
        dd = day(cur['start'].date())
        if cur['break_open']:
            cur['breaks'].append((cur['break_open'], end)); cur['break_open'] = None
        if missing:
            dd['missing_out'] = True
        else:
            span = (end - cur['start']).total_seconds()
            unpaid = sum((b - a).total_seconds() for a, b in cur['breaks'] if (b - a).total_seconds() > TC_BREAK_PAID_MAX)
            paid = sum((b - a).total_seconds() for a, b in cur['breaks'] if (b - a).total_seconds() <= TC_BREAK_PAID_MAX)
            dd['worked'] += max(0.0, span - unpaid); dd['paid_breaks'] += paid; dd['unpaid_breaks'] += unpaid
            dd['last_out'] = end.strftime('%H:%M')
        cur = None
    for e in events:
        t = _tc_dt(e['ts']); k = e['kind']
        if k == 'in':
            if cur:
                close(t, missing=True)
            cur = {'start': t, 'breaks': [], 'break_open': None}
            dd = day(t.date())
            dd['first_in'] = dd['first_in'] or t.strftime('%H:%M')
        elif k == 'break_start' and cur and not cur['break_open']:
            cur['break_open'] = t
        elif k == 'break_end' and cur and cur['break_open']:
            cur['breaks'].append((cur['break_open'], t)); cur['break_open'] = None
        elif k == 'out' and cur:
            close(t)
    if cur:
        dd = day(cur['start'].date())
        if cur['start'].date() == now.date():         # quart en cours : compté jusqu'à maintenant
            on_break = cur['break_open'] is not None
            brk = list(cur['breaks']) + ([(cur['break_open'], now)] if on_break else [])
            span = (now - cur['start']).total_seconds()
            unpaid = sum((b - a).total_seconds() for a, b in brk if (b - a).total_seconds() > TC_BREAK_PAID_MAX)
            dd['worked'] += max(0.0, span - unpaid); dd['open'] = True; dd['state'] = 'break' if on_break else 'in'
            dd['since'] = (cur['break_open'] or cur['start']).strftime('%H:%M')
        else:
            dd['missing_out'] = True
    out, d = [], d0
    while d <= d1:
        x = days.get(d) or day(d)
        out.append(x); d += datetime.timedelta(days=1)
    return out


def tc_sheet(conn, emp_id, d0, d1):
    days = tc_days(tc_events(conn, emp_id, d0, d1), d0, d1)
    weeks, ot = [], 0.0
    for i in range(0, len(days), 7):
        w = sum(x['worked'] for x in days[i:i + 7]); weeks.append(w); ot += max(0.0, w - TC_OT_WEEK)
    total = sum(x['worked'] for x in days)
    return {'days': days, 'total': total, 'overtime': ot, 'regular': total - ot, 'weeks': weeks,
            'missing': sum(1 for x in days if x['missing_out'])}


def tc_state(conn, emp_id):
    today = datetime.date.today()
    d = tc_days(tc_events(conn, emp_id, today, today), today, today)[0]
    w0, w1 = today - datetime.timedelta(days=today.weekday()), today
    week = sum(x['worked'] for x in tc_days(tc_events(conn, emp_id, w0, w1), w0, w1))
    last = conn.execute("SELECT kind, ts FROM tc_events WHERE employee_id=? AND deleted=0 ORDER BY ts DESC, id DESC LIMIT 1", (emp_id,)).fetchone()
    state = d['state'] if d['open'] else ('done' if d['last_out'] else 'out')
    return {'state': state, 'since': d.get('since'), 'first_in': d['first_in'], 'last_out': d['last_out'], 'today': d['worked'], 'week': week,
            'last_kind': last['kind'] if last else None}


def tc_allowed():
    if session.get('user_id') and (session.get('is_admin') or {'rh', 'punch_presence'} & set(session.get('permissions') or [])):
        return True
    raw = request.cookies.get(TC_COOKIE)
    if not raw:
        return False
    try:
        from itsdangerous import URLSafeTimedSerializer
        data = URLSafeTimedSerializer(app.secret_key, salt='kubios-poste-presence').loads(raw, max_age=TC_MAX_AGE)
    except Exception:
        return False
    return secrets.compare_digest(str(data.get('v', '')), tc_secret())


def tc_secret():
    s = meta_get('tc_secret')
    if not s:
        s = secrets.token_urlsafe(16); meta_set('tc_secret', s)
    return s


def tc_link_token():
    t = meta_get('tc_link_token')
    if not t:
        t = secrets.token_urlsafe(24); meta_set('tc_link_token', t)
    return t


def tc_authorize(resp):
    from itsdangerous import URLSafeTimedSerializer
    resp.set_cookie(TC_COOKIE, URLSafeTimedSerializer(app.secret_key, salt='kubios-poste-presence').dumps({'v': tc_secret()}),
                    max_age=TC_MAX_AGE, httponly=True, samesite='Lax', secure=request.is_secure)
    return resp


def hm_txt(sec):
    m = int(round((sec or 0) / 60)); return f"{m // 60} h {m % 60:02d}"


def tc_day_details(r):
    """Une ligne par journée avec du prévu ou du punché : prévu, entrée, sortie, pauses, dîner, heures, remarques."""
    out = []
    for x in r['sheet']['days']:
        evs = [e for e in r.get('events', []) if e['ts'][:10] == x['date']]
        if not (x['worked'] or x['missing_out'] or x.get('sched') or evs):
            continue
        rem = []
        if x.get('absent'):
            rem.append('ABSENT (horaire prévu, aucun punch)')
        if x.get('late'):
            rem.append(f"Retard {x['late']} min")
        if x['missing_out']:
            rem.append('Sortie manquante')
        for e in evs:
            if e.get('corrected_by'):
                rem.append(f"{TC_KINDS.get(e['kind'], e['kind'])} {e['ts'][11:16]} corrigé(e) par {e['corrected_by']}" + (f" — {e['note']}" if e.get('note') else ''))
        d = datetime.date.fromisoformat(x['date'])
        out.append({'date': x['date'], 'jour': f"{JOURS_CRT[d.weekday()]} {d.day}", 'prevu': x.get('sched') or '—',
                    'entree': x['first_in'] or '—', 'sortie': ('en cours' if x['open'] else (x['last_out'] or '—')),
                    'pauses': round(x['paid_breaks'] / 60), 'diner': round(x['unpaid_breaks'] / 60), 'heures': x['worked'], 'remarques': rem})
    return out


def export_tc_xlsx(rows, d0, d1, path):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    wb = Workbook(); ws = wb.active; ws.title = "Feuille de temps"
    days = [d0 + datetime.timedelta(days=i) for i in range((d1 - d0).days + 1)]
    J = ('Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim')
    ws['A1'] = f"{get_company_name()} — Feuille de temps"; ws['A1'].font = Font(bold=True, size=14)
    ws['A2'] = f"Période du {_d(d0.isoformat())} au {_d(d1.isoformat())} — heures en format décimal (ex. 7,50 = 7 h 30) — pauses de 15 min ou moins payées, dîner déduit — heures sup. au-delà de 40 h par semaine"
    ws['A2'].font = Font(italic=True, size=9, color='555555')
    head = ['Employé', 'Poste'] + [f"{J[d.weekday()]} {d.day}" for d in days] + ['Heures régulières', 'Heures sup.', 'Total', 'Approuvée']
    ws.append([]); ws.append(head)
    hdr = ws.max_row
    thin = Side(style='thin', color='CCCCCC')
    for c in ws[hdr]:
        c.font = Font(bold=True, color='FFFFFF'); c.fill = PatternFill('solid', fgColor='1E3A8A'); c.alignment = Alignment(horizontal='center', wrap_text=True)
    for r in rows:
        vals = [r['name'], r['position'] or ''] + [round(x['worked'] / 3600, 2) if x['worked'] else None for x in r['sheet']['days']] + \
               [round(r['sheet']['regular'] / 3600, 2), round(r['sheet']['overtime'] / 3600, 2), round(r['sheet']['total'] / 3600, 2), 'Oui' if r['approved'] else 'Non']
        ws.append(vals)
        for i, x in enumerate(r['sheet']['days']):
            if x['missing_out']:
                c = ws.cell(row=ws.max_row, column=3 + i); c.fill = PatternFill('solid', fgColor='FDE68A'); c.value = 'Sortie manquante'
    last = ws.max_row
    ws.append(['TOTAL', ''] + [None] * len(days) + [f"=SUM({col}{hdr + 1}:{col}{last})" for col in
                                                     [ws.cell(row=hdr, column=3 + len(days) + k).column_letter for k in range(3)]] + [''])
    for c in ws[ws.max_row]:
        c.font = Font(bold=True); c.fill = PatternFill('solid', fgColor='DBE3F3')
    for row in ws.iter_rows(min_row=hdr, max_row=ws.max_row):
        for c in row:
            c.border = Border(top=thin, bottom=thin, left=thin, right=thin)
            if c.column > 2 and c.row > hdr and isinstance(c.value, (int, float)):
                c.number_format = '0.00'
    ws.column_dimensions['A'].width = 24; ws.column_dimensions['B'].width = 22
    for k in range(len(days) + 4):
        ws.column_dimensions[ws.cell(row=hdr, column=3 + k).column_letter].width = 11
    ws.freeze_panes = ws.cell(row=hdr + 1, column=3)
    ws3 = wb.create_sheet("Détail par jour")
    ws3.append(['Employé', 'Date', 'Prévu (horaire)', 'Entrée', 'Sortie', 'Pauses payées (min)', 'Dîner déduit (min)', 'Heures', 'Remarques'])
    for c in ws3[1]:
        c.font = Font(bold=True, color='FFFFFF'); c.fill = PatternFill('solid', fgColor='1E3A8A'); c.alignment = Alignment(wrap_text=True, vertical='center')
    for r in rows:
        for dl in tc_day_details(r):
            ws3.append([r['name'], dl['date'], dl['prevu'], dl['entree'], dl['sortie'], dl['pauses'] or None, dl['diner'] or None,
                        round(dl['heures'] / 3600, 2) if dl['heures'] else None, ' ; '.join(dl['remarques'])])
            if dl['remarques']:
                ws3.cell(row=ws3.max_row, column=9).fill = PatternFill('solid', fgColor='FEF3C7')
            ws3.cell(row=ws3.max_row, column=8).number_format = '0.00'
    for col, w in zip('ABCDEFGHI', (24, 12, 26, 9, 9, 12, 12, 9, 70)):
        ws3.column_dimensions[col].width = w
    ws3.freeze_panes = 'B2'
    ws2 = wb.create_sheet("Détail des punchs")
    ws2.append(['Employé', 'Date', 'Heure', 'Punch', 'Note / correction'])
    for c in ws2[1]:
        c.font = Font(bold=True, color='FFFFFF'); c.fill = PatternFill('solid', fgColor='1E3A8A')
    for r in rows:
        for e in r['events']:
            ws2.append([r['name'], e['ts'][:10], e['ts'][11:16], TC_KINDS.get(e['kind'], e['kind']),
                        (e['note'] or '') + (f" (corrigé par {e['corrected_by']})" if e['corrected_by'] else '')])
    for col, w in zip('ABCDE', (24, 12, 8, 18, 40)):
        ws2.column_dimensions[col].width = w
    wb.save(path)
    return path


def export_tc_pdf(rows, d0, d1, path):
    k = _at_pdf_kit(); Tb, TS, Pa, C, mm = k['Table'], k['TableStyle'], k['Paragraph'], k['colors'], k['mm']
    doc, header = _at_doc(path, k, "Feuille de temps", f"Du {_d(d0.isoformat())} au {_d(d1.isoformat())} — généré le {datetime.datetime.now():%d-%m-%Y à %H:%M}", True)
    days = [d0 + datetime.timedelta(days=i) for i in range((d1 - d0).days + 1)]
    J = ('Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim')
    head = ['Employé'] + [f"{J[d.weekday()]} {d.day}" for d in days] + ['Régulières', 'Sup.', 'Total']
    data = [head]
    for r in rows:
        data.append([Pa(f"<b>{r['name']}</b><br/><font size=6.5 color='#6b7280'>{r['position'] or ''}</font>", k['cell'])] +
                    [('oubli' if x['missing_out'] else (hm_txt(x['worked']) if x['worked'] else '—')) for x in r['sheet']['days']] +
                    [hm_txt(r['sheet']['regular']), hm_txt(r['sheet']['overtime']) if r['sheet']['overtime'] else '—', hm_txt(r['sheet']['total'])])
    tot = sum(r['sheet']['total'] for r in rows); otot = sum(r['sheet']['overtime'] for r in rows)
    data.append([Pa('<b>Total</b>', k['cell'])] + [''] * len(days) + [hm_txt(tot - otot), hm_txt(otot), hm_txt(tot)])
    cw = 250 / (len(days) + 4)
    t = Tb(data, colWidths=[40 * mm] + [cw * mm] * len(days) + [cw * 1.15 * mm] * 3, repeatRows=1)
    st_ = k['base'] + [('ALIGN', (1, 0), (-1, -1), 'CENTER'), ('FONTSIZE', (0, 0), (-1, -1), 7.5 if len(days) > 7 else 8.5),
                       ('FONTNAME', (-3, 1), (-1, -1), 'Helvetica-Bold'), ('BACKGROUND', (0, -1), (-1, -1), C.HexColor('#dbe3f3')),
                       ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold')]
    for ri, r in enumerate(rows, start=1):
        for ci, x in enumerate(r['sheet']['days'], start=1):
            if x['missing_out']:
                st_.append(('BACKGROUND', (ci, ri), (ci, ri), C.HexColor('#fde68a')))
        if r['sheet']['overtime']:
            st_.append(('TEXTCOLOR', (-2, ri), (-2, ri), C.HexColor('#b45309')))
    t.setStyle(TS(st_))
    story = [Pa("Résumé de la période", k['h2']), t, k['Spacer'](1, 6),
             Pa("Pauses de 15 minutes ou moins payées ; pauses plus longues (dîner) déduites. Heures supplémentaires : au-delà de 40 h par semaine "
                "(lundi au dimanche). « oubli » = sortie non punchée, à corriger avant la paie.", k['small'])]
    appr = [r['name'] for r in rows if not r['approved']]
    story.append(Pa(("Toutes les feuilles sont approuvées." if not appr else "Non approuvées : " + ', '.join(appr)), k['small']))
    # détail par employé et par jour
    from reportlab.lib.styles import ParagraphStyle
    rem_st = ParagraphStyle('tc_rem', parent=k['cell'], fontSize=7.5, leading=9, textColor=C.HexColor('#9a3412'))
    for r in rows:
        det = tc_day_details(r)
        if not det:
            continue
        story.append(k['PageBreak']())
        story.append(Pa(f"Détail — {r['name']}" + (f" ({r['position']})" if r['position'] else ''), k['h2']))
        data = [['Jour', 'Prévu (horaire)', 'Entrée', 'Sortie', 'Pauses payées', 'Dîner déduit', 'Heures', 'Remarques']]
        for dl in det:
            data.append([dl['jour'], Pa(dl['prevu'], k['cell']), dl['entree'], dl['sortie'], f"{dl['pauses']} min" if dl['pauses'] else '—',
                         f"{dl['diner']} min" if dl['diner'] else '—', hm_txt(dl['heures']) if dl['heures'] else '—',
                         Pa('<br/>'.join(x.replace('<', '&lt;') for x in dl['remarques']) or '', rem_st)])
        data.append(['Total', '', '', '', '', '', hm_txt(r['sheet']['total']), Pa(f"dont {hm_txt(r['sheet']['overtime'])} en heures supplémentaires" if r['sheet']['overtime'] else '', k['cell'])])
        t = Tb(data, colWidths=[16 * mm, 50 * mm, 17 * mm, 17 * mm, 22 * mm, 22 * mm, 18 * mm, 98 * mm], repeatRows=1)
        st2 = k['base'] + [('ALIGN', (2, 0), (6, -1), 'CENTER'), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('FONTSIZE', (0, 0), (-1, -1), 8),
                           ('BACKGROUND', (0, -1), (-1, -1), C.HexColor('#dbe3f3')), ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold')]
        for i, dl in enumerate(det, start=1):
            if dl['remarques']:
                st2.append(('BACKGROUND', (7, i), (7, i), C.HexColor('#fff7ed')))
        t.setStyle(TS(st2))
        story.append(t)
        story.append(Pa("Pauses de 15 min ou moins payées (incluses dans les heures) ; pauses plus longues (dîner) déduites au complet. "
                        "Retard : entrée après l'heure prévue à l'horaire, au-delà de la tolérance.", k['small']))
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


def hr_sig_clean(d):
    mode = 'drawn' if d.get('mode') == 'drawn' else 'typed'
    name = str(d.get('name') or '').strip()[:80]
    if len(name) < 3:
        raise ValueError("Inscris ton nom complet.")
    sig = {'mode': mode, 'name': name}
    if mode == 'drawn':
        img = str(d.get('img') or '')
        if not img.startswith('data:image/png;base64,') or len(img) > 400_000:
            raise ValueError("Dessine ta signature dans le cadre.")
        sig['img'] = img
    return sig


def hr_build_signed_pdf(conn, doc_id):
    """PDF signé = document d'origine + page de signatures (nom, date, heure, poste, empreinte du document)."""
    d = dict(conn.execute("SELECT * FROM hr_documents WHERE id=?", (doc_id,)).fetchone())
    e = dict(conn.execute("SELECT * FROM hr_employees WHERE id=?", (d['employee_id'],)).fetchone())
    folder = HR_DIR / str(d['employee_id']); src = folder / d['filename']
    if not src.exists() or src.suffix.lower() != '.pdf':
        return None
    import io
    from pypdf import PdfReader, PdfWriter
    k = _at_pdf_kit(); Tb, TS, Pa, C, mm = k['Table'], k['TableStyle'], k['Paragraph'], k['colors'], k['mm']
    from reportlab.platypus import Image as RLImage
    buf = io.BytesIO()
    doc = k['SimpleDocTemplate'](buf, pagesize=k['letter'], leftMargin=18 * mm, rightMargin=18 * mm, topMargin=18 * mm, bottomMargin=16 * mm)
    story = [Pa("Page de signatures", k['h1']), k['Spacer'](1, 4),
             Pa(f"Document : <b>{d['title'] or d['original_name']}</b><br/>Employé : <b>{hr_emp_name(e)}</b> — {get_company_name()}<br/>"
                f"Empreinte du document signé (SHA-256) : <font face='Courier' size=7>{d['doc_hash']}</font>", k['small']), k['Spacer'](1, 10)]
    def block(title, sig, when, extra=''):
        if not sig:
            return [Pa(f"<b>{title}</b> : pas encore signé.", k['small']), k['Spacer'](1, 8)]
        s = json.loads(sig)
        if s.get('mode') == 'drawn' and s.get('img'):
            raw = base64.b64decode(s['img'].split(',', 1)[1])
            mark = RLImage(io.BytesIO(raw), width=70 * mm, height=22 * mm, kind='proportional')
        else:
            from reportlab.lib.styles import ParagraphStyle
            mark = Pa(f"<i>{s['name']}</i>", ParagraphStyle('sig', fontName='Times-Italic', fontSize=24, leading=28, textColor=C.HexColor('#1e3a8a')))
        t = Tb([[mark], [Pa(f"<b>{title}</b> — {s['name']}<br/>Signé électroniquement le {when[:10]} à {when[11:16]}{extra}", k['small'])]], colWidths=[120 * mm])
        t.setStyle(TS([('LINEBELOW', (0, 0), (0, 0), .6, C.black), ('LEFTPADDING', (0, 0), (-1, -1), 0)]))
        return [t, k['Spacer'](1, 14)]
    story += block("Gestionnaire", d['mgr_sig'], d['mgr_signed_at'] or '', f" par {d['mgr_signed_by'] or ''}")
    story += block("Employé", d['emp_sig'], d['emp_signed_at'] or '', f" — poste {d['emp_sign_ip'] or ''}")
    if d['emp_comment']:
        story += [Pa("Commentaire de l'employé", k['h2']), Pa((d['emp_comment'] or '').replace('<', '&lt;'), k['cell'])]
    story += [k['Spacer'](1, 10), Pa("La signature de l'employé confirme qu'il a reçu et lu ce document, pas nécessairement qu'il est d'accord avec son contenu. "
                                    "Les signatures ont été apposées dans Kubios ; l'empreinte ci-dessus permet de vérifier que le document n'a pas été modifié.", k['small'])]
    doc.build(story)
    w = PdfWriter()
    for p in PdfReader(str(src)).pages:
        w.add_page(p)
    for p in PdfReader(io.BytesIO(buf.getvalue())).pages:
        w.add_page(p)
    out = folder / f"_signe_{doc_id}.pdf"
    with open(out, 'wb') as f:
        w.write(f)
    conn.execute("UPDATE hr_documents SET signed_filename=? WHERE id=?", (out.name, doc_id))
    return out


def hr_doc_file_hash(conn, doc_id):
    d = conn.execute("SELECT employee_id, filename, doc_hash FROM hr_documents WHERE id=?", (doc_id,)).fetchone()
    if d['doc_hash']:
        return d['doc_hash']
    h = hashlib.sha256((HR_DIR / str(d['employee_id']) / d['filename']).read_bytes()).hexdigest()
    conn.execute("UPDATE hr_documents SET doc_hash=? WHERE id=?", (h, doc_id))
    return h


def emp_session_emp():
    eid = session.get('emp_id')
    if not eid:
        return None
    conn = get_conn()
    try:
        r = conn.execute("SELECT e.*, p.login, p.active AS portal_active FROM hr_employees e JOIN hr_portal p ON p.employee_id=e.id WHERE e.id=?", (eid,)).fetchone()
    finally:
        conn.close()
    if not r or not r['portal_active'] or r['status'] == 'inactif':
        session.pop('emp_id', None)
        return None
    return dict(r)


SCHED_DEFAULT_TEMPLATES = [['07:00', '16:00'], ['08:00', '17:00'], ['08:00', '16:00'], ['08:00', '13:00']]


SCHED_MEALS = ['11:00', '12:00', '13:00']


JOURS_FR = ('lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche')


JOURS_CRT = ('Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim')


def sched_settings():
    try:
        tpl = json.loads(meta_get('sched_templates') or 'null') or SCHED_DEFAULT_TEMPLATES
    except ValueError:
        tpl = SCHED_DEFAULT_TEMPLATES
    closed = [int(x) for x in (meta_get('sched_closed_days') if meta_get('sched_closed_days') is not None else '6').split(',') if x.strip().isdigit()]
    try:
        grace = int(meta_get('sched_late_grace') or 5)
    except ValueError:
        grace = 5
    return {'templates': tpl, 'meals': SCHED_MEALS, 'closed': closed, 'grace': grace}


def _hm_min(s):
    """« 08:30 » → minutes depuis minuit. (Ne pas confondre avec _hm(sec), qui met en forme une durée en secondes.)"""
    h, m = s.split(':'); return int(h) * 60 + int(m)


def sched_paid_min(c):
    if not c or c.get('kind') != 'work' or not c.get('start') or not c.get('end'):
        return 0
    return max(0, _hm_min(c['end']) - _hm_min(c['start']) - (60 if c.get('meal') else 0))


def sched_label(c):
    if not c:
        return '—'
    if c['kind'] == 'off':
        return 'Congé'
    t = lambda s: f"{int(s[:2])} h" + (f" {s[3:]}" if s[3:] != '00' else '')
    return f"{t(c['start'])} – {t(c['end'])}" + (f", repas {t(c['meal'])}" if c.get('meal') else '')


def sched_cells(conn, table, d0, d1, emp_id=None):
    q = f"SELECT * FROM {table} WHERE day BETWEEN ? AND ?" + (" AND employee_id=?" if emp_id else "")
    out = {}
    for r in conn.execute(q, (d0.isoformat(), d1.isoformat()) + ((emp_id,) if emp_id else ())).fetchall():
        out.setdefault(r['employee_id'], {})[r['day']] = {'kind': r['kind'], 'start': r['start'], 'end': r['end'], 'meal': r['meal'], 'note': r['note'] or ''}
    return out


def _sched_same(a, b):
    k = ('kind', 'start', 'end', 'meal', 'note')
    return (a is None and b is None) or (a is not None and b is not None and all((a.get(x) or '') == (b.get(x) or '') for x in k))


def sched_employees(conn):
    return [dict(r) for r in conn.execute(
        "SELECT id, first_name, last_name, department, position, email FROM hr_employees WHERE status<>'inactif' "
        "ORDER BY COALESCE(NULLIF(department,''),'~') COLLATE NOCASE, first_name COLLATE NOCASE, last_name COLLATE NOCASE").fetchall()]


def sched_day_fr(iso):
    d = datetime.date.fromisoformat(iso)
    return f"{JOURS_FR[d.weekday()]} {d.day}{'er' if d.day == 1 else ''} {_MOIS_FR[d.month - 1]}"


def export_sched_pdf(conn, d0, d1, path):
    k = _at_pdf_kit(); Tb, TS, Pa, C, mm = k['Table'], k['TableStyle'], k['Paragraph'], k['colors'], k['mm']
    st = sched_settings()
    doc, header = _at_doc(path, k, "Horaire de travail", f"Du {_d(d0.isoformat())} au {_d(d1.isoformat())}", True)
    cells = sched_cells(conn, 'sched_published', d0, d1)
    emps = sched_employees(conn)
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_CENTER
    ctr = ParagraphStyle('sc_ctr', parent=k['cell'], alignment=TA_CENTER, fontSize=8.5, leading=10.5)
    dephd = ParagraphStyle('sc_dep', parent=k['cell'], fontName='Helvetica-Bold', textColor=C.white, fontSize=9)
    story = []
    wk, n = d0, 1
    while wk <= d1:
        days = [wk + datetime.timedelta(days=i) for i in range(7)]
        if n > 1:
            story.append(k['PageBreak']() if 'PageBreak' in k else k['Spacer'](1, 14))
        story.append(Pa(f"PÉRIODE {n} — semaine du {_d(days[0].isoformat())} au {_d(days[-1].isoformat())}", k['h2']))
        for dep in sorted({(e['department'] or 'Sans département') for e in emps}, key=lambda x: (x == 'Sans département', x.lower())):
            data = [[Pa(dep, dephd)] + [f"{JOURS_CRT[d.weekday()]} {d.day}" for d in days] + ['Total']]
            styles = []
            for ri, e in enumerate([e for e in emps if (e['department'] or 'Sans département') == dep], start=1):
                row, tot = [Pa(f"{e['first_name']} {e['last_name']}", k['cell'])], 0
                for ci, d in enumerate(days, start=1):
                    c = (cells.get(e['id']) or {}).get(d.isoformat())
                    if d.weekday() in st['closed'] and not c:
                        row.append('FERMÉ'); styles.append(('TEXTCOLOR', (ci, ri), (ci, ri), C.HexColor('#94a3b8')))
                    elif c and c['kind'] == 'off':
                        row.append('Congé'); styles.append(('BACKGROUND', (ci, ri), (ci, ri), C.HexColor('#fef3c7')))
                    elif c:
                        tot += sched_paid_min(c)
                        row.append(Pa(f"{sched_label(c).split(',')[0]}" + (f"<br/><font size=7 color='#64748b'>repas {int(c['meal'][:2])} h</font>" if c.get('meal') else ''), ctr))
                    else:
                        row.append('')
                row.append(f"{tot // 60} h" + (f" {tot % 60:02d}" if tot % 60 else ''))
                data.append(row)
            if len(data) == 1:
                continue
            t = Tb(data, colWidths=[46 * mm] + [28 * mm] * 7 + [18 * mm], repeatRows=1)
            t.setStyle(TS(k['base'] + [('ALIGN', (1, 0), (-1, -1), 'CENTER'), ('ALIGN', (-1, 1), (-1, -1), 'CENTER'), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('FONTSIZE', (0, 0), (-1, -1), 8.5),
                                       ('FONTNAME', (-1, 1), (-1, -1), 'Helvetica-Bold')] + styles))
            story += [t, k['Spacer'](1, 6)]
        wk += datetime.timedelta(days=7); n += 1
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


def sched_compare(conn, emp_id, days, tc_days_list):
    """Retards et absences : compare l'horaire publié aux punchs (feuilles de temps)."""
    st = sched_settings()
    cells = sched_cells(conn, 'sched_published', datetime.date.fromisoformat(days[0]), datetime.date.fromisoformat(days[-1]), emp_id).get(emp_id, {})
    today = datetime.date.today().isoformat()
    out = []
    for d, x in zip(days, tc_days_list):
        c = cells.get(d)
        info = {'sched': sched_label(c) if c else None, 'late': 0, 'absent': False}
        if c and c['kind'] == 'work':
            if x['first_in']:
                late = _hm_min(x['first_in']) - _hm_min(c['start'])
                if late > st['grace']:
                    info['late'] = late
            elif d < today or (d == today and datetime.datetime.now().strftime('%H:%M') > c['end']):
                info['absent'] = True
        out.append(info)
    return out


LEAVE_KINDS = {'vacances': 'Vacances', 'personnel': 'Congé personnel', 'maladie': 'Congé maladie', 'autre': 'Autre congé'}


LEAVE_STATUS = {'en_attente': 'En attente', 'approuvee': 'Approuvée', 'refusee': 'Refusée', 'annulee': 'Annulée'}


def leave_auto_note(kind):
    return f"{LEAVE_KINDS.get(kind, 'Congé')} (approuvé)"


def leaves_in_range(conn, d0, d1, emp_id=None):
    """Congés approuvés qui touchent la période : {employee_id: {jour: {'kind', 'label', 'id', 'start', 'end'}}}."""
    q = "SELECT * FROM leave_requests WHERE status='approuvee' AND start<=? AND end>=?" + (" AND employee_id=?" if emp_id else "")
    out = {}
    for r in conn.execute(q, (d1.isoformat(), d0.isoformat()) + ((emp_id,) if emp_id else ())).fetchall():
        d = max(datetime.date.fromisoformat(r['start']), d0)
        while d <= min(datetime.date.fromisoformat(r['end']), d1):
            out.setdefault(r['employee_id'], {})[d.isoformat()] = {'kind': r['kind'], 'label': LEAVE_KINDS.get(r['kind'], 'Congé'), 'id': r['id'],
                                                                    'start': r['start'], 'end': r['end']}
            d += datetime.timedelta(days=1)
    return out


def leave_apply_schedule(conn, lv, remove=False):
    """Approuvé : chaque journée devient « congé » (brouillon et publié) ; annulé : ces journées sont libérées."""
    note = leave_auto_note(lv['kind'])
    closed = sched_settings()['closed']
    d, end = datetime.date.fromisoformat(lv['start']), datetime.date.fromisoformat(lv['end'])
    while d <= end:
        day = d.isoformat()
        for tbl in ('sched_shifts', 'sched_published'):
            if remove:
                conn.execute(f"DELETE FROM {tbl} WHERE employee_id=? AND day=? AND kind='off' AND note=?", (lv['employee_id'], day, note))
            elif d.weekday() not in closed:
                conn.execute(f"INSERT OR REPLACE INTO {tbl}(employee_id, day, kind, start, end, meal, note, updated_at, updated_by) VALUES (?,?,?,?,?,?,?,?,?)",
                             (lv['employee_id'], day, 'off', None, None, None, note, _at_now(), 'Congés'))
        d += datetime.timedelta(days=1)


def _esc(t):
    from markupsafe import escape
    return str(escape(t or ''))


def sched_email_html(emp, d0, d1, cells, changes, first, company):
    """Courriel d'horaire : ce qui a changé (avant / maintenant), puis l'horaire complet des 2 périodes."""
    blue, muted = '#1e3a8a', '#64748b'
    fmt = lambda c: ((c.get('note') or 'Congé') if c.get('kind') == 'off' else sched_label(c)) if c else 'Aucun quart'
    h = [f"""<div style="font-family:Segoe UI,Arial,sans-serif;max-width:640px;margin:0 auto;color:#0f172a">
<div style="background:linear-gradient(135deg,#1e3a8a,#4f46e5);color:#fff;padding:22px 26px;border-radius:14px 14px 0 0">
<div style="font-size:13px;opacity:.85">{_esc(company)}</div><div style="font-size:22px;font-weight:800;margin-top:2px">{'Ton horaire est publié' if first else 'Ton horaire a changé'}</div>
<div style="font-size:14px;opacity:.9;margin-top:4px">Du {sched_day_fr(d0.isoformat())} au {sched_day_fr(d1.isoformat())}</div></div>
<div style="background:#fff;border:1px solid #e2e8f0;border-top:0;border-radius:0 0 14px 14px;padding:22px 26px">
<p style="font-size:15px;margin:0 0 14px">Bonjour {_esc(emp['first_name'])},</p>"""]
    if not first and changes:
        h.append(f"""<div style="background:#fffbeb;border:1px solid #fcd34d;border-radius:10px;padding:12px 14px;margin-bottom:18px">
<div style="font-weight:800;color:#92400e;margin-bottom:8px">Ce qui a changé ({len(changes)} journée{'s' if len(changes) > 1 else ''})</div>
<table style="width:100%;border-collapse:collapse;font-size:13.5px">""")
        for day, a, b in sorted(changes):
            h.append(f"""<tr><td style="padding:6px 4px;border-top:1px solid #fde68a;font-weight:700;white-space:nowrap">{_esc(sched_day_fr(day)).capitalize()}</td>
<td style="padding:6px 4px;border-top:1px solid #fde68a;color:{muted};text-decoration:line-through">{_esc(fmt(a))}</td>
<td style="padding:6px 4px;border-top:1px solid #fde68a">→</td><td style="padding:6px 4px;border-top:1px solid #fde68a;font-weight:800;color:{blue}">{_esc(fmt(b))}</td></tr>""")
        h.append("</table></div>")
    changed_days = {c[0] for c in changes}
    wk, n = d0, 1
    while wk <= d1:
        tot = 0
        rows = []
        for i in range(7):
            d = wk + datetime.timedelta(days=i); day = d.isoformat(); c = cells.get(day)
            closed = d.weekday() in sched_settings()['closed'] and not c
            if c and c['kind'] == 'work':
                tot += sched_paid_min(c)
                txt = f"<b style='color:{blue}'>{_esc(sched_label(c).split(',')[0])}</b>" + (f"<br><span style='color:{muted};font-size:12px'>repas {int(c['meal'][:2])} h</span>" if c.get('meal') else '')
            elif c:
                txt = f"<b style='color:#92400e'>{_esc(c.get('note') or 'Congé')}</b>"
            else:
                txt = f"<span style='color:#94a3b8'>{'Fermé' if closed else '—'}</span>"
            bg = '#fffbeb' if day in changed_days and not first else ('#f8fafc' if i % 2 else '#fff')
            rows.append(f"<tr style='background:{bg}'><td style='padding:7px 10px;font-weight:700;width:150px'>{_esc(sched_day_fr(day)).capitalize()}</td><td style='padding:7px 10px'>{txt}</td></tr>")
        h.append(f"""<div style="font-weight:800;color:{blue};margin:14px 0 6px">Période {n} <span style="color:{muted};font-weight:500">— {tot // 60} h{f' {tot % 60:02d}' if tot % 60 else ''} prévues</span></div>
<table style="width:100%;border-collapse:collapse;font-size:14px;border:1px solid #e2e8f0;border-radius:10px">{''.join(rows)}</table>""")
        wk += datetime.timedelta(days=7); n += 1
    h.append(f"""<p style="font-size:13px;color:{muted};margin:18px 0 0">Ton horaire est aussi joint en PDF et disponible dans ton espace employé (« Mon horaire »).
Pour une demande de congé, utilise « Mes congés » dans ton espace employé.</p></div>
<div style="text-align:center;font-size:11.5px;color:#94a3b8;margin-top:10px">{_esc(company)} · Kubios</div></div>""")
    return ''.join(h)


def export_sched_emp_pdf(emp, d0, d1, cells, changes, first, path):
    k = _at_pdf_kit(); Tb, TS, Pa, C, mm = k['Table'], k['TableStyle'], k['Paragraph'], k['colors'], k['mm']
    doc, header = _at_doc(path, k, f"Horaire — {emp['first_name']} {emp['last_name']}", f"Du {_d(d0.isoformat())} au {_d(d1.isoformat())}")
    fmt = lambda c: ((c.get('note') or 'Congé') if c.get('kind') == 'off' else sched_label(c)) if c else 'Aucun quart'
    story = []
    if changes and not first:
        story.append(Pa("Ce qui a changé", k['h2']))
        data = [['Journée', 'Avant', 'Maintenant']] + [[sched_day_fr(d).capitalize(), fmt(a), fmt(b)] for d, a, b in sorted(changes)]
        t = Tb(data, colWidths=[45 * mm, 60 * mm, 60 * mm]); t.setStyle(TS(k['base'] + [('FONTSIZE', (0, 0), (-1, -1), 9), ('BACKGROUND', (0, 1), (-1, -1), C.HexColor('#fffbeb'))]))
        story += [t, k['Spacer'](1, 8)]
    wk, n = d0, 1
    while wk <= d1:
        data, tot = [['Journée', 'Quart', 'Repas', 'Heures']], 0
        for i in range(7):
            d = wk + datetime.timedelta(days=i); c = cells.get(d.isoformat())
            if c and c['kind'] == 'work':
                m = sched_paid_min(c); tot += m
                data.append([sched_day_fr(d.isoformat()).capitalize(), sched_label(c).split(',')[0], f"{int(c['meal'][:2])} h" if c.get('meal') else '—', f"{m // 60} h{f' {m % 60:02d}' if m % 60 else ''}"])
            else:
                data.append([sched_day_fr(d.isoformat()).capitalize(), (c.get('note') or 'Congé') if c else ('Fermé' if d.weekday() in sched_settings()['closed'] else '—'), '', ''])
        data.append(['Total', '', '', f"{tot // 60} h{f' {tot % 60:02d}' if tot % 60 else ''}"])
        story.append(Pa(f"Période {n} — semaine du {_d(wk.isoformat())}", k['h2']))
        t = Tb(data, colWidths=[55 * mm, 55 * mm, 25 * mm, 30 * mm])
        t.setStyle(TS(k['base'] + [('FONTSIZE', (0, 0), (-1, -1), 9.5), ('BACKGROUND', (0, -1), (-1, -1), C.HexColor('#dbe3f3')), ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold')]))
        story += [t, k['Spacer'](1, 8)]
        wk += datetime.timedelta(days=7); n += 1
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


def leave_approver_config():
    try:
        cfg = json.loads(meta_get('leave_approvers') or '{}')
    except ValueError:
        cfg = {}
    return cfg if isinstance(cfg, dict) else {}


def leave_approvers(conn, department):
    """Approbateurs d'un département : ceux choisis pour ce département, sinon ceux choisis pour tout le magasin,
    sinon (rien de configuré) les administrateurs et les comptes avec l'accès RH qui ont un courriel."""
    cfg = leave_approver_config()
    names = cfg.get(department or '') or cfg.get('*') or []
    rows = [dict(r) for r in conn.execute("SELECT username, email, full_name, is_admin, permissions FROM users WHERE active=1 AND email IS NOT NULL AND email<>''").fetchall()]
    if names:
        return [r for r in rows if r['username'] in names]
    return [r for r in rows if r['is_admin'] or 'rh' in (r['permissions'] or '')]


def _leave_html_card(title, color, inner, button=None, company=None):
    btn = (f"<div style='margin-top:18px'><a href='{_esc(button[1])}' style='display:inline-block;background:#2563eb;color:#fff;text-decoration:none;"
           f"font-weight:700;padding:11px 20px;border-radius:10px'>{_esc(button[0])}</a></div>") if button else ''
    return (f"<div style='font-family:Segoe UI,Arial,sans-serif;max-width:600px;margin:0 auto;color:#0f172a'>"
            f"<div style='background:{color};color:#fff;padding:18px 24px;border-radius:14px 14px 0 0'><div style='font-size:13px;opacity:.85'>{_esc(company or get_company_name())}</div>"
            f"<div style='font-size:20px;font-weight:800;margin-top:2px'>{title}</div></div>"
            f"<div style='background:#fff;border:1px solid #e2e8f0;border-top:0;border-radius:0 0 14px 14px;padding:20px 24px'>{inner}{btn}</div>"
            f"<div style='text-align:center;font-size:11.5px;color:#94a3b8;margin-top:10px'>{_esc(company or get_company_name())} · Kubios</div></div>")


def _leave_summary_rows(lv, emp, extra=()):
    days = (datetime.date.fromisoformat(lv['end']) - datetime.date.fromisoformat(lv['start'])).days + 1
    rows = [('Employé', f"{emp['first_name']} {emp['last_name']}" + (f" — {emp['department']}" if emp.get('department') else '')),
            ('Type', LEAVE_KINDS.get(lv['kind'], lv['kind'])),
            ('Du', sched_day_fr(lv['start']).capitalize()), ('Au', sched_day_fr(lv['end']).capitalize()),
            ('Durée', f"{days} jour{'s' if days > 1 else ''} de calendrier")] + list(extra)
    return "<table style='width:100%;border-collapse:collapse;font-size:14px'>" + ''.join(
        f"<tr><td style='padding:7px 0;color:#64748b;width:120px;vertical-align:top'>{_esc(k)}</td><td style='padding:7px 0;font-weight:600'>{v if k == '__html' else _esc(v)}</td></tr>"
        for k, v in rows) + "</table>"


def leave_notify_managers(conn, emp, lv):
    """Avise les approbateurs du département de l'employé (courriel en HTML)."""
    others = conn.execute("SELECT e.first_name || ' ' || e.last_name n, l.start, l.end FROM leave_requests l JOIN hr_employees e ON e.id=l.employee_id "
                          "WHERE l.status='approuvee' AND l.employee_id<>? AND l.start<=? AND l.end>=?", (emp['id'], lv['end'], lv['start'])).fetchall()
    planned = sched_cells(conn, 'sched_published', datetime.date.fromisoformat(lv['start']), datetime.date.fromisoformat(lv['end']), emp['id']).get(emp['id'], {})
    work = [f"{sched_day_fr(d).capitalize()} : {sched_label(c)}" for d, c in sorted(planned.items()) if c['kind'] == 'work']
    try:
        link = request.host_url.rstrip('/') + '/rh/conges'
    except Exception:
        link = None
    inner = (f"<p style='font-size:15px;margin:0 0 14px'><b>{_esc(emp['first_name'])} {_esc(emp['last_name'])}</b> demande un congé.</p>"
             + _leave_summary_rows(lv, emp)
             + (f"<div style='background:#f8fafc;border-left:4px solid #94a3b8;padding:10px 14px;margin:14px 0;font-size:14px'><b>Note de l'employé :</b><br>{_esc(lv['note'])}</div>" if lv.get('note') else '')
             + (f"<div style='background:#fff7ed;border:1px solid #fed7aa;color:#9a3412;padding:10px 14px;border-radius:10px;margin:12px 0;font-size:13.5px'><b>Déjà en congé ces jours-là :</b><br>"
                + '<br>'.join(_esc(f"{o['n']} ({_d(o['start'])} au {_d(o['end'])})") for o in others) + "</div>" if others else '')
             + (f"<div style='background:#eff6ff;border:1px solid #bfdbfe;color:#1e3a8a;padding:10px 14px;border-radius:10px;margin:12px 0;font-size:13.5px'><b>Prévu à son horaire publié :</b><br>"
                + '<br>'.join(_esc(w) for w in work) + "</div>" if work else ''))
    html = _leave_html_card('Nouvelle demande de congé', 'linear-gradient(135deg,#b45309,#f59e0b)', inner, ('Répondre dans Kubios', link) if link else None)
    text = (f"{emp['first_name']} {emp['last_name']} demande : {LEAVE_KINDS.get(lv['kind'])} du {sched_day_fr(lv['start'])} au {sched_day_fr(lv['end'])}."
            + (f"\n\nNote de l'employé : {lv['note']}" if lv.get('note') else '') + "\n\nPour répondre : Kubios → Gestion RH → Congés." + (f"\n{link}" if link else ''))
    sent = 0
    for u in leave_approvers(conn, emp.get('department')):
        try:
            send_email(u['email'], f"{get_company_name()} — demande de congé de {emp['first_name']} {emp['last_name']}", text, None,
                       mode='send', bcc_company=False, html=html, category='Congés')
            sent += 1
        except Exception:
            traceback.print_exc()
    return sent


def _hr_check():
    return permission_required_check('rh')


def _hr_emp(conn, eid):
    e = conn.execute("SELECT * FROM hr_employees WHERE id=?", (eid,)).fetchone()
    return dict(e) if e else None


HR_FIELDS = ('first_name', 'last_name', 'position', 'department', 'hire_date', 'status', 'probation_end', 'end_date', 'next_review',
             'email', 'phone', 'address', 'emergency_name', 'emergency_phone', 'username', 'notes')


def _tc_period_from_args():
    try:
        d = datetime.date.fromisoformat(request.args.get('start') or '')
    except ValueError:
        d = datetime.date.today()
    return tc_period_of(d)


def _tc_rows(conn, d0, d1, with_events=False):
    rows = []
    for e in conn.execute("SELECT * FROM hr_employees WHERE tc_enabled=1 OR id IN (SELECT DISTINCT employee_id FROM tc_events WHERE deleted=0 AND ts>=? AND ts<?) "
                          "ORDER BY status='inactif', first_name COLLATE NOCASE", (d0.isoformat(), (d1 + datetime.timedelta(days=1)).isoformat())).fetchall():
        sh = tc_sheet(conn, e['id'], d0, d1)
        appr = conn.execute("SELECT approved_by, approved_at FROM tc_approvals WHERE employee_id=? AND period_start=?", (e['id'], d0.isoformat())).fetchone()
        cmp_ = sched_compare(conn, e['id'], [x['date'] for x in sh['days']], sh['days'])
        for x, cinfo in zip(sh['days'], cmp_):
            x.update(cinfo)
        sh['lates'] = sum(1 for c in cmp_ if c['late']); sh['absences'] = sum(1 for c in cmp_ if c['absent'])
        r = {'id': e['id'], 'name': f"{e['first_name']} {e['last_name']}", 'position': e['position'], 'sheet': sh,
             'approved': dict(appr) if appr else None, 'state': tc_state(conn, e['id'])['state'] if d0 <= datetime.date.today() <= d1 else None}
        if with_events:
            r['events'] = tc_events(conn, e['id'], d0, d1)
        rows.append(r)
    return rows


def _emp_render(mode, **kw):
    return render_template('employe_auth.html', mode=mode, company=get_company_name(), app_name=APP_NAME, year=datetime.date.today().year,
                           bg_url=login_bg_url(), bg_mode=login_bg_mode(), video_url=login_video_url(), **kw)


def sched_period_of(d):
    """L'horaire se fait toujours sur 2 semaines (Période 1 et Période 2), alignées sur la date de départ de la paie."""
    anchor = tc_settings()['anchor']
    monday = d - datetime.timedelta(days=d.weekday())
    start = anchor + datetime.timedelta(days=14 * ((monday - anchor).days // 14))
    return start, start + datetime.timedelta(days=13)


def _sched_period():
    try:
        d = datetime.date.fromisoformat(request.values.get('start') or '')
    except ValueError:
        d = datetime.date.today()
    return sched_period_of(d)
