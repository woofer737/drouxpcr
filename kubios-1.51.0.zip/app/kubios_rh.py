# -*- coding: utf-8 -*-
"""Pages Gestion RH : dossiers des employés, documents, évaluations, administration RH.
Module de Kubios (découpé de app.py en 1.47.0, code inchangé)."""
import os
import re
import io
import csv
import sys
import json
import base64
import hashlib
import unicodedata
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import openpyxl
from openpyxl.utils import get_column_letter
import licensing
from kubios_base import AT_FMT, _at_now, get_company_name, get_conn, meta_set
from kubios_mail import send_email
from kubios_app import app
from kubios_auth import admin_required_check, current_display_name, log_audit
from kubios_atelier_outils import at_mechanics
from kubios_rh_outils import (
    HR_DIR, HR_DOC_CATS, HR_DOC_EXT, HR_DOC_MAX, HR_FIELDS, HR_NOTE_KINDS, HR_SCALE, HR_STATUS,
    HR_TEMPLATES, _d, _hr_check, _hr_emp, export_hr_eval_pdf, export_hr_letter_pdf, hr_atelier_stats,
    hr_build_signed_pdf, hr_criteria, hr_doc_file_hash, hr_emp_name, hr_log, hr_reminders,
    hr_sig_clean, hr_store_file, hr_templates,
)

__all__ = ['api_hr_atelier_stats', 'api_hr_doc', 'api_hr_doc_email', 'api_hr_doc_publish', 'api_hr_doc_sign', 'api_hr_doc_upload', 'api_hr_emp_punch_cfg', 'api_hr_employee', 'api_hr_employee_save', 'api_hr_employees', 'api_hr_eval_pdf', 'api_hr_eval_save', 'api_hr_generate', 'api_hr_note', 'api_hr_portal', 'api_hr_settings', 'hr_admin_page', 'hr_page']


@app.route('/rh')
def hr_page():
    resp = _hr_check()
    if resp is not None:
        return resp
    return render_template('rh.html', company=get_company_name(), is_admin=bool(session.get('is_admin')))


@app.route('/api/rh/employees')
def api_hr_employees():
    resp = _hr_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        rows = [dict(r) for r in conn.execute("SELECT id, first_name, last_name, position, status, hire_date, mechanic_id FROM hr_employees "
                                              "ORDER BY status='inactif', last_name COLLATE NOCASE, first_name COLLATE NOCASE").fetchall()]
        return jsonify({'employees': rows, 'reminders': hr_reminders(conn), 'status': HR_STATUS, 'scale': HR_SCALE,
                        'criteria': [[c['key'], c['label'], c['hint']] for c in hr_criteria()], 'templates': hr_templates(), 'template_order': list(HR_TEMPLATES),
                        'doc_cats': HR_DOC_CATS, 'note_kinds': HR_NOTE_KINDS,
                        'mechanics': [{'id': m['id'], 'name': m['name']} for m in at_mechanics(True)],
                        'users': [r['username'] for r in conn.execute("SELECT username FROM users ORDER BY username").fetchall()]})
    finally:
        conn.close()


@app.route('/api/rh/employees/<int:eid>')
def api_hr_employee(eid):
    resp = _hr_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        e = _hr_emp(conn, eid)
        if not e:
            return jsonify({'error': 'Employé introuvable.'}), 404
        hr_log(conn, eid, 'Consultation du dossier'); conn.commit()
        docs = [dict(r) for r in conn.execute("SELECT * FROM hr_documents WHERE employee_id=? ORDER BY created_at DESC", (eid,)).fetchall()]
        evals = [dict(r) for r in conn.execute("SELECT * FROM hr_evaluations WHERE employee_id=? ORDER BY COALESCE(eval_date, created_at) DESC", (eid,)).fetchall()]
        notes = [dict(r) for r in conn.execute("SELECT * FROM hr_notes WHERE employee_id=? ORDER BY note_date DESC, id DESC", (eid,)).fetchall()]
        log = [dict(r) for r in conn.execute("SELECT * FROM hr_access_log WHERE employee_id=? ORDER BY id DESC LIMIT 100", (eid,)).fetchall()] if session.get('is_admin') else None
        e['tc_has_pin'] = bool(e.pop('tc_pin_hash', None))          # jamais l'empreinte du NIP
        p = conn.execute("SELECT login, active, invited_at, last_login, password_hash IS NOT NULL AS has_password FROM hr_portal WHERE employee_id=?", (eid,)).fetchone()
        for x in docs:
            x['mgr_sig'] = bool(x.get('mgr_sig')); x['emp_sig'] = bool(x.get('emp_sig'))
        return jsonify({'employee': e, 'documents': docs, 'evaluations': evals, 'notes': notes, 'log': log, 'portal': dict(p) if p else None})
    finally:
        conn.close()


@app.route('/api/rh/employees', methods=['POST'])
@app.route('/api/rh/employees/<int:eid>', methods=['PUT', 'DELETE'])
def api_hr_employee_save(eid=None):
    resp = _hr_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        if request.method == 'DELETE':
            if not session.get('is_admin'):
                return jsonify({'ok': False, 'error': "Seul un administrateur peut supprimer un dossier. Marque plutôt l'employé « Inactif »."}), 403
            e = _hr_emp(conn, eid)
            if not e:
                return jsonify({'ok': False, 'error': 'Employé introuvable.'}), 404
            for t in ('hr_documents', 'hr_evaluations', 'hr_notes', 'hr_portal', 'tc_events', 'tc_approvals'):
                conn.execute(f"DELETE FROM {t} WHERE employee_id=?", (eid,))
            conn.execute("DELETE FROM hr_employees WHERE id=?", (eid,))
            hr_log(conn, eid, 'Dossier supprimé'); conn.commit()
            shutil.rmtree(HR_DIR / str(eid), ignore_errors=True)
            log_audit('RH : dossier supprimé', hr_emp_name(e))
            return jsonify({'ok': True})
        d = request.get_json(silent=True) or {}
        vals = {f: (str(d.get(f) or '').strip()[:1000] or None) for f in HR_FIELDS}
        if not vals['first_name'] or not vals['last_name']:
            return jsonify({'ok': False, 'error': 'Le prénom et le nom sont requis.'}), 400
        if vals['status'] not in HR_STATUS:
            vals['status'] = 'actif'
        for f in ('hire_date', 'probation_end', 'end_date', 'next_review'):
            if vals[f]:
                try:
                    datetime.date.fromisoformat(vals[f])
                except ValueError:
                    return jsonify({'ok': False, 'error': 'Date invalide.'}), 400
        if re.search(r'\b\d{3}[ -]?\d{3}[ -]?\d{3}\b', (vals['notes'] or '')):
            return jsonify({'ok': False, 'error': "Les notes semblent contenir un numéro d'assurance sociale : ne l'inscris pas dans Kubios."}), 400
        try:
            mid = int(d['mechanic_id']) if d.get('mechanic_id') not in (None, '') else None
        except (TypeError, ValueError):
            mid = None
        if eid is None:
            cur = conn.execute("INSERT INTO hr_employees(" + ','.join(HR_FIELDS) + ", mechanic_id, created_at, updated_at) VALUES ("
                               + ','.join('?' * (len(HR_FIELDS) + 3)) + ")", [vals[f] for f in HR_FIELDS] + [mid, _at_now(), _at_now()])
            eid = cur.lastrowid
            hr_log(conn, eid, 'Dossier créé')
            msg = 'RH : dossier créé'
        else:
            if not _hr_emp(conn, eid):
                return jsonify({'ok': False, 'error': 'Employé introuvable.'}), 404
            conn.execute("UPDATE hr_employees SET " + ', '.join(f + '=?' for f in HR_FIELDS) + ", mechanic_id=?, updated_at=? WHERE id=?",
                         [vals[f] for f in HR_FIELDS] + [mid, _at_now(), eid])
            hr_log(conn, eid, 'Profil modifié')
            msg = 'RH : profil modifié'
        conn.commit()
    finally:
        conn.close()
    log_audit(msg, f"{vals['first_name']} {vals['last_name']}")
    return jsonify({'ok': True, 'id': eid})


@app.route('/api/rh/employees/<int:eid>/documents', methods=['POST'])
def api_hr_doc_upload(eid):
    resp = _hr_check()
    if resp is not None:
        return resp
    f = request.files.get('file')
    if not f or not f.filename:
        return jsonify({'ok': False, 'error': 'Choisis un fichier.'}), 400
    if Path(f.filename).suffix.lower() not in HR_DOC_EXT:
        return jsonify({'ok': False, 'error': 'Type de fichier non accepté (PDF, image, Word, Excel ou texte).'}), 400
    data = f.read()
    if len(data) > HR_DOC_MAX:
        return jsonify({'ok': False, 'error': 'Fichier trop gros (15 Mo au maximum).'}), 400
    cat = request.form.get('category') if request.form.get('category') in HR_DOC_CATS else 'autre'
    exp = (request.form.get('expires_on') or '').strip() or None
    if exp:
        try:
            datetime.date.fromisoformat(exp)
        except ValueError:
            return jsonify({'ok': False, 'error': "Date d'échéance invalide."}), 400
    conn = get_conn()
    try:
        e = _hr_emp(conn, eid)
        if not e:
            return jsonify({'ok': False, 'error': 'Employé introuvable.'}), 404
        hr_store_file(eid, data, f.filename, cat, (request.form.get('title') or Path(f.filename).stem).strip(), exp, conn=conn)
        hr_log(conn, eid, 'Document ajouté : ' + f.filename[:80]); conn.commit()
    finally:
        conn.close()
    log_audit('RH : document ajouté', f"{hr_emp_name(e)} — {f.filename}")
    return jsonify({'ok': True})


@app.route('/api/rh/documents/<int:did>', methods=['GET', 'DELETE'])
def api_hr_doc(did):
    resp = _hr_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        d = conn.execute("SELECT * FROM hr_documents WHERE id=?", (did,)).fetchone()
        if not d:
            return jsonify({'error': 'Document introuvable.'}), 404
        p = HR_DIR / str(d['employee_id']) / d['filename']
        if request.method == 'DELETE':
            conn.execute("DELETE FROM hr_documents WHERE id=?", (did,))
            hr_log(conn, d['employee_id'], 'Document supprimé : ' + (d['original_name'] or '')); conn.commit()
            try:
                p.unlink()
            except OSError:
                pass
            log_audit('RH : document supprimé', d['original_name'] or '')
            return jsonify({'ok': True})
        hr_log(conn, d['employee_id'], 'Document ouvert : ' + (d['original_name'] or '')); conn.commit()
        if request.args.get('signed') == '1' and d['signed_filename']:
            p = HR_DIR / str(d['employee_id']) / d['signed_filename']
    finally:
        conn.close()
    if not p.exists():
        return "Fichier introuvable sur le disque.", 404
    return send_file(str(p), as_attachment=request.args.get('dl') == '1', download_name=d['original_name'] or p.name)


@app.route('/api/rh/employees/<int:eid>/notes', methods=['POST'])
@app.route('/api/rh/notes/<int:nid>', methods=['DELETE'])
def api_hr_note(eid=None, nid=None):
    resp = _hr_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        if nid is not None:
            n = conn.execute("SELECT * FROM hr_notes WHERE id=?", (nid,)).fetchone()
            if not n:
                return jsonify({'ok': False, 'error': 'Note introuvable.'}), 404
            conn.execute("DELETE FROM hr_notes WHERE id=?", (nid,)); hr_log(conn, n['employee_id'], 'Note supprimée'); conn.commit()
            return jsonify({'ok': True})
        d = request.get_json(silent=True) or {}
        text = str(d.get('text') or '').strip()[:3000]
        if not text:
            return jsonify({'ok': False, 'error': 'Écris la note.'}), 400
        kind = d.get('kind') if d.get('kind') in HR_NOTE_KINDS else 'note'
        nd = (d.get('note_date') or '').strip() or datetime.date.today().isoformat()
        conn.execute("INSERT INTO hr_notes(employee_id, kind, note_date, text, created_by, created_at) VALUES (?,?,?,?,?,?)",
                     (eid, kind, nd, text, current_display_name(), _at_now()))
        hr_log(conn, eid, 'Note ajoutée : ' + HR_NOTE_KINDS[kind]); conn.commit()
        return jsonify({'ok': True})
    finally:
        conn.close()


@app.route('/api/rh/employees/<int:eid>/evaluations', methods=['POST'])
@app.route('/api/rh/evaluations/<int:vid>', methods=['PUT', 'DELETE'])
def api_hr_eval_save(eid=None, vid=None):
    resp = _hr_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        if vid is not None:
            ev = conn.execute("SELECT * FROM hr_evaluations WHERE id=?", (vid,)).fetchone()
            if not ev:
                return jsonify({'ok': False, 'error': 'Évaluation introuvable.'}), 404
            eid = ev['employee_id']
            if request.method == 'DELETE':
                if ev['status'] == 'finalisee' and not session.get('is_admin'):
                    return jsonify({'ok': False, 'error': 'Seul un administrateur peut supprimer une évaluation finalisée.'}), 403
                conn.execute("DELETE FROM hr_evaluations WHERE id=?", (vid,)); hr_log(conn, eid, 'Évaluation supprimée'); conn.commit()
                return jsonify({'ok': True})
            if ev['status'] == 'finalisee':
                return jsonify({'ok': False, 'error': 'Cette évaluation est finalisée : elle ne peut plus être modifiée.'}), 409
        e = _hr_emp(conn, eid)
        if not e:
            return jsonify({'ok': False, 'error': 'Employé introuvable.'}), 404
        d = request.get_json(silent=True) or {}
        crit = json.loads(ev['criteria']) if vid is not None and ev['criteria'] and ev['status'] == 'finalisee' else \
            [{'key': c['key'], 'label': c['label'], 'hint': c['hint']} for c in hr_criteria()]
        scores = {}
        for c in crit:
            sc = (d.get('scores') or {}).get(c['key']) or {}
            na = sc.get('score') == 'na'
            try:
                v = int(sc.get('score')) if sc.get('score') not in (None, '', 'na') else None
            except (TypeError, ValueError):
                v = None
            scores[c['key']] = {'score': v if v in HR_SCALE else None, 'na': na, 'comment': str(sc.get('comment') or '')[:500]}
        got = [s['score'] for s in scores.values() if s['score']]
        overall = round(sum(got) / len(got), 2) if got else None
        p0, p1 = (d.get('period_start') or '').strip() or None, (d.get('period_end') or '').strip() or None
        for x in (p0, p1, d.get('eval_date') or None):
            if x:
                try:
                    datetime.date.fromisoformat(x)
                except ValueError:
                    return jsonify({'ok': False, 'error': 'Date invalide.'}), 400
        stats = hr_atelier_stats(e, p0, p1) if p0 and p1 else None
        final = bool(d.get('finalize'))
        if final and any(not s['score'] and not s['na'] for s in scores.values()):
            return jsonify({'ok': False, 'error': 'Note chaque critère, ou marque-le « S.O. » (ne s’applique pas), avant de finaliser.'}), 400
        if final and not got:
            return jsonify({'ok': False, 'error': 'Au moins un critère doit être noté.'}), 400
        vals = (p0, p1, d.get('eval_date') or datetime.date.today().isoformat(), str(d.get('evaluator') or current_display_name())[:120],
                json.dumps(scores, ensure_ascii=False), overall, *(str(d.get(k) or '')[:3000] for k in ('strengths', 'improvements', 'objectives', 'employee_comments')),
                'finalisee' if final else 'brouillon', json.dumps(stats) if stats else None, _at_now(), json.dumps(crit, ensure_ascii=False))
        if vid is None:
            cur = conn.execute("INSERT INTO hr_evaluations(period_start, period_end, eval_date, evaluator, scores, overall, strengths, improvements, objectives, "
                               "employee_comments, status, atelier_stats, updated_at, criteria, employee_id, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                               vals + (eid, _at_now()))
            vid = cur.lastrowid
        else:
            conn.execute("UPDATE hr_evaluations SET period_start=?, period_end=?, eval_date=?, evaluator=?, scores=?, overall=?, strengths=?, improvements=?, "
                         "objectives=?, employee_comments=?, status=?, atelier_stats=?, updated_at=?, criteria=? WHERE id=?", vals + (vid,))
        hr_log(conn, eid, 'Évaluation ' + ('finalisée' if final else 'enregistrée (brouillon)'))
        if final:
            ev = dict(conn.execute("SELECT * FROM hr_evaluations WHERE id=?", (vid,)).fetchone())
            p = export_hr_eval_pdf(e, ev)
            hr_store_file(eid, p.read_bytes(), f"Evaluation_{ev['eval_date']}.pdf", 'evaluation', f"Évaluation du {_d(ev['eval_date'])}", username=session.get('username'), conn=conn)
            try:
                p.unlink()
            except OSError:
                pass
            if not e['next_review'] or e['next_review'] <= datetime.date.today().isoformat():
                nr = (datetime.date.fromisoformat(ev['eval_date']) + datetime.timedelta(days=365)).isoformat()
                conn.execute("UPDATE hr_employees SET next_review=? WHERE id=?", (nr, eid))
        conn.commit()
    finally:
        conn.close()
    if final:
        log_audit('RH : évaluation finalisée', hr_emp_name(e))
    return jsonify({'ok': True, 'id': vid})


@app.route('/api/rh/evaluations/<int:vid>/pdf')
def api_hr_eval_pdf(vid):
    resp = _hr_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        ev = conn.execute("SELECT * FROM hr_evaluations WHERE id=?", (vid,)).fetchone()
        if not ev:
            return "Évaluation introuvable.", 404
        e = _hr_emp(conn, ev['employee_id']); hr_log(conn, ev['employee_id'], 'Aperçu PDF de l\u2019évaluation'); conn.commit()
    finally:
        conn.close()
    p = export_hr_eval_pdf(e, dict(ev))
    return send_file(str(p), mimetype='application/pdf', as_attachment=False, download_name=f"Evaluation_{hr_emp_name(e).replace(' ', '_')}.pdf")


@app.route('/api/rh/employees/<int:eid>/atelier-stats')
def api_hr_atelier_stats(eid):
    resp = _hr_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        e = _hr_emp(conn, eid)
    finally:
        conn.close()
    if not e:
        return jsonify({'error': 'Employé introuvable.'}), 404
    try:
        return jsonify({'stats': hr_atelier_stats(e, request.args.get('start'), request.args.get('end'))})
    except (ValueError, TypeError):
        return jsonify({'stats': None})


@app.route('/rh/administration')
def hr_admin_page():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return render_template('rh_admin.html', company=get_company_name())


@app.route('/api/rh/settings', methods=['GET', 'POST'])
def api_hr_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if request.method == 'GET':
        return jsonify({'criteria': hr_criteria(False), 'templates': hr_templates(), 'template_order': list(HR_TEMPLATES)})
    d = request.get_json(silent=True) or {}
    if 'criteria' in d:
        out, used = [], set()
        for c in d['criteria'] or []:
            label = str(c.get('label') or '').strip()[:120]
            if not label:
                continue
            key = re.sub(r'[^a-z0-9]+', '_', str(c.get('key') or '').lower()).strip('_')[:40]
            if not key:
                base = re.sub(r'[^a-z0-9]+', '_', unicodedata.normalize('NFKD', label).encode('ascii', 'ignore').decode().lower()).strip('_')[:30] or 'critere'
                key, n = base, 2
                while key in used:
                    key = f"{base}_{n}"; n += 1
            if key in used:
                continue
            used.add(key)
            out.append({'key': key, 'label': label, 'hint': str(c.get('hint') or '').strip()[:300], 'active': bool(c.get('active', True))})
        if not any(c['active'] for c in out):
            return jsonify({'ok': False, 'error': 'Garde au moins un critère actif.'}), 400
        meta_set('hr_criteria', json.dumps(out, ensure_ascii=False))
        log_audit('RH : critères d\u2019évaluation modifiés', f"{sum(1 for c in out if c['active'])} critère(s) actif(s)")
    if 'templates' in d:
        ov = {}
        for t, v in (d['templates'] or {}).items():
            if t in HR_TEMPLATES and isinstance(v, dict):
                keys = {s[0] for s in HR_TEMPLATES[t]['sections']}
                ov[t] = {'ack': str(v.get('ack') or '')[:1000], 'defaults': {kk: str(vv or '')[:3000] for kk, vv in (v.get('defaults') or {}).items() if kk in keys}}
        meta_set('hr_doc_templates', json.dumps(ov, ensure_ascii=False))
        log_audit('RH : modèles de documents modifiés', '')
    return jsonify({'ok': True, 'criteria': hr_criteria(False), 'templates': hr_templates(), 'template_order': list(HR_TEMPLATES)})


@app.route('/api/rh/employees/<int:eid>/generate', methods=['POST'])
def api_hr_generate(eid):
    resp = _hr_check()
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    ttype = d.get('type')
    if ttype not in HR_TEMPLATES:
        return jsonify({'ok': False, 'error': 'Type de document inconnu.'}), 400
    dd = (d.get('date') or '').strip() or datetime.date.today().isoformat()
    try:
        datetime.date.fromisoformat(dd)
    except ValueError:
        return jsonify({'ok': False, 'error': 'Date invalide.'}), 400
    fields = {kk: str(v or '')[:5000] for kk, v in (d.get('fields') or {}).items()}
    conn = get_conn()
    try:
        e = _hr_emp(conn, eid)
        if not e:
            return jsonify({'ok': False, 'error': 'Employé introuvable.'}), 404
        tpl = HR_TEMPLATES[ttype]
        if ttype != 'attestation' and not (fields.get('objet') or '').strip():
            return jsonify({'ok': False, 'error': "Inscris l'objet du document."}), 400
        rep_ = {'{nom}': hr_emp_name(e), '{entreprise}': get_company_name(), '{embauche}': _d(e['hire_date']) if e['hire_date'] else '—', '{poste}': e['position'] or '—'}
        for kk in fields:
            for a, b in rep_.items():
                fields[kk] = fields[kk].replace(a, b)
        d_ = HR_DIR / str(eid); d_.mkdir(parents=True, exist_ok=True)
        tmp = d_ / f"_apercu_{ttype}.pdf"
        export_hr_letter_pdf(e, ttype, dd, fields, current_display_name(), tmp)
        if d.get('preview'):
            hr_log(conn, eid, f"Aperçu : {tpl['title']}"); conn.commit()
            return send_file(str(tmp), mimetype='application/pdf', as_attachment=False, download_name=f"{tpl['title']}.pdf")
        title = tpl['title'] + (f" — {fields.get('objet').strip()[:80]}" if (fields.get('objet') or '').strip() else '')
        did = hr_store_file(eid, tmp.read_bytes(), f"{re.sub(r'[^A-Za-z0-9]+', '_', tpl['title'])}_{dd}.pdf", tpl['category'], f"{title} ({_d(dd)})",
                            username=session.get('username'), conn=conn)
        conn.execute("INSERT INTO hr_notes(employee_id, kind, note_date, text, created_by, created_at) VALUES (?,?,?,?,?,?)",
                     (eid, tpl['note_kind'], dd, f"{title} — document créé et classé au dossier.", current_display_name(), _at_now()))
        hr_log(conn, eid, f"Document créé : {tpl['title']}"); conn.commit()
        try:
            tmp.unlink()
        except OSError:
            pass
    finally:
        conn.close()
    log_audit('RH : document créé', f"{hr_emp_name(e)} — {title}")
    return jsonify({'ok': True, 'document_id': did})


@app.route('/api/rh/documents/<int:did>/publish', methods=['POST'])
def api_hr_doc_publish(did):
    resp = _hr_check()
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    conn = get_conn()
    try:
        doc = conn.execute("SELECT * FROM hr_documents WHERE id=?", (did,)).fetchone()
        if not doc:
            return jsonify({'ok': False, 'error': 'Document introuvable.'}), 404
        pub = bool(d.get('published'))
        sign = bool(d.get('sign_required')) and pub
        if sign and not doc['filename'].lower().endswith('.pdf'):
            return jsonify({'ok': False, 'error': 'Seuls les documents PDF peuvent être signés.'}), 400
        if sign:
            hr_doc_file_hash(conn, did)
        conn.execute("UPDATE hr_documents SET published=?, published_at=?, sign_required=? WHERE id=?",
                     (1 if pub else 0, _at_now() if pub and not doc['published'] else doc['published_at'], 1 if sign else 0, did))
        hr_log(conn, doc['employee_id'], ('Publié dans le portail' if pub else 'Retiré du portail') + f" : {doc['title']}" + (' (signature demandée)' if sign else ''))
        conn.commit()
    finally:
        conn.close()
    return jsonify({'ok': True})


@app.route('/api/rh/documents/<int:did>/sign', methods=['POST'])
def api_hr_doc_sign(did):
    resp = _hr_check()
    if resp is not None:
        return resp
    try:
        sig = hr_sig_clean(request.get_json(silent=True) or {})
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    conn = get_conn()
    try:
        doc = conn.execute("SELECT * FROM hr_documents WHERE id=?", (did,)).fetchone()
        if not doc or not doc['filename'].lower().endswith('.pdf'):
            return jsonify({'ok': False, 'error': 'Seuls les documents PDF peuvent être signés.'}), 400
        hr_doc_file_hash(conn, did)
        conn.execute("UPDATE hr_documents SET mgr_sig=?, mgr_signed_at=?, mgr_signed_by=? WHERE id=?",
                     (json.dumps(sig, ensure_ascii=False), _at_now(), current_display_name(), did))
        hr_build_signed_pdf(conn, did)
        hr_log(conn, doc['employee_id'], f"Signé par le gestionnaire : {doc['title']}")
        conn.commit()
    finally:
        conn.close()
    log_audit('RH : document signé (gestionnaire)', doc['title'] or '')
    return jsonify({'ok': True})


@app.route('/api/rh/documents/<int:did>/email', methods=['POST'])
def api_hr_doc_email(did):
    resp = _hr_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        doc = conn.execute("SELECT * FROM hr_documents WHERE id=?", (did,)).fetchone()
        if not doc:
            return jsonify({'ok': False, 'error': 'Document introuvable.'}), 404
        e = dict(conn.execute("SELECT * FROM hr_employees WHERE id=?", (doc['employee_id'],)).fetchone())
        if not e.get('email'):
            return jsonify({'ok': False, 'error': "Aucun courriel n'est inscrit dans le profil de l'employé."}), 400
        folder = HR_DIR / str(doc['employee_id'])
        p = folder / (doc['signed_filename'] or doc['filename'])
        if p.suffix.lower() != '.pdf':
            return jsonify({'ok': False, 'error': 'Seuls les documents PDF peuvent être envoyés par courriel.'}), 400
        signed = bool(doc['signed_filename'])
        body = (f"Bonjour {e['first_name']},\n\nTu trouveras ci-joint une copie du document « {doc['title']} »"
                + (" avec les signatures." if signed else ".") + f"\n\nCe courriel est confidentiel.\n\n{get_company_name()}")
        try:
            send_email(e['email'], f"{get_company_name()} — {doc['title']}", body, str(p), mode='send', bcc_company=False)
        except Exception as ex:
            return jsonify({'ok': False, 'error': f"Envoi impossible : {ex}"}), 400
        conn.execute("UPDATE hr_documents SET emailed_at=? WHERE id=?", (_at_now(), did))
        hr_log(conn, doc['employee_id'], f"Copie envoyée par courriel : {doc['title']}"); conn.commit()
    finally:
        conn.close()
    log_audit('RH : document envoyé par courriel', f"{doc['title']} → {e['email']}")
    return jsonify({'ok': True, 'to': e['email']})


@app.route('/api/rh/employees/<int:eid>/portal', methods=['POST'])
def api_hr_portal(eid):
    resp = _hr_check()
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    act = d.get('action')
    conn = get_conn()
    try:
        e = conn.execute("SELECT * FROM hr_employees WHERE id=?", (eid,)).fetchone()
        if not e:
            return jsonify({'ok': False, 'error': 'Employé introuvable.'}), 404
        if act == 'revoke':
            conn.execute("UPDATE hr_portal SET active=0, token=NULL WHERE employee_id=?", (eid,))
            hr_log(conn, eid, 'Accès au portail retiré'); conn.commit()
            log_audit('RH : accès au portail retiré', hr_emp_name(e))
            return jsonify({'ok': True})
        if not e['email']:
            return jsonify({'ok': False, 'error': "Inscris d'abord le courriel de l'employé dans son profil : il servira à se connecter."}), 400
        login = e['email'].strip().lower()
        dup = conn.execute("SELECT employee_id FROM hr_portal WHERE login=? AND employee_id<>?", (login, eid)).fetchone()
        if dup:
            return jsonify({'ok': False, 'error': 'Ce courriel est déjà utilisé par le portail d\u2019un autre employé.'}), 400
        tok = secrets.token_urlsafe(24); exp = (datetime.datetime.now() + datetime.timedelta(days=7)).strftime(AT_FMT)
        if conn.execute("SELECT 1 FROM hr_portal WHERE employee_id=?", (eid,)).fetchone():
            conn.execute("UPDATE hr_portal SET login=?, active=1, token=?, token_expires=?, invited_at=? WHERE employee_id=?", (login, tok, exp, _at_now(), eid))
        else:
            conn.execute("INSERT INTO hr_portal(employee_id, login, active, token, token_expires, invited_at, created_at) VALUES (?,?,1,?,?,?,?)",
                         (eid, login, tok, exp, _at_now(), _at_now()))
        hr_log(conn, eid, 'Invitation au portail envoyée'); conn.commit()
    finally:
        conn.close()
    link = request.host_url.rstrip('/') + url_for('emp_activate', t=tok)
    sent, err = False, None
    try:
        send_email(login, f"{get_company_name()} — ton espace employé",
                   f"Bonjour {e['first_name']},\n\n{get_company_name()} t'a créé un espace employé dans Kubios : tu pourras y consulter tes heures "
                   f"et tes documents, et signer ceux qui te sont envoyés.\n\nPour choisir ton mot de passe, ouvre ce lien (valide 7 jours) :\n{link}\n\n"
                   f"Ton identifiant : {login}\n\n{get_company_name()}", None, mode='send', bcc_company=False)
        sent = True
    except Exception as ex:
        err = str(ex)
    log_audit('RH : invitation au portail', f"{hr_emp_name(e)} — {'envoyée' if sent else 'non envoyée : ' + (err or '')}")
    return jsonify({'ok': True, 'sent': sent, 'error': err, 'link': link, 'login': login})


@app.route('/api/rh/employees/<int:eid>/punch', methods=['POST'])
def api_hr_emp_punch_cfg(eid):
    resp = _hr_check()
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    conn = get_conn()
    try:
        e = conn.execute("SELECT * FROM hr_employees WHERE id=?", (eid,)).fetchone()
        if not e:
            return jsonify({'ok': False, 'error': 'Employé introuvable.'}), 404
        if 'enabled' in d:
            conn.execute("UPDATE hr_employees SET tc_enabled=? WHERE id=?", (1 if d['enabled'] else 0, eid))
        if d.get('pin'):
            pin = str(d['pin']).strip()
            if not re.fullmatch(r'\d{4,6}', pin):
                return jsonify({'ok': False, 'error': 'Le NIP doit avoir de 4 à 6 chiffres.'}), 400
            conn.execute("UPDATE hr_employees SET tc_pin_hash=? WHERE id=?", (generate_password_hash(pin), eid))
        hr_log(conn, eid, 'Réglages du punch modifiés'); conn.commit()
    finally:
        conn.close()
    return jsonify({'ok': True})
