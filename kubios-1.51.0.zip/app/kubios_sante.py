# -*- coding: utf-8 -*-
"""Super administrateur (fournisseur), mode maintenance, santé du système, métriques et alertes (1.51.0).

Le super administrateur est un compte VISIBLE dans la liste des utilisateurs ; il ne peut être créé que sur
l'ordinateur serveur :  python kubios_sante.py --promouvoir <nom_utilisateur>   (ou Activer_super_admin.bat).
Toutes ses actions sont notées au journal d'audit comme celles des autres comptes."""
import os, sys, json, time, socket, shutil, sqlite3, platform, tempfile, threading, traceback, datetime, collections
from pathlib import Path
from flask import request, session, jsonify, render_template, g, got_request_exception

from kubios_app import app, BASE_DIR, APP_DIR
from kubios_base import get_conn, meta_get, meta_set, _at_now, DB_PATH, get_company_name, get_settings
from kubios_version import APP_VERSION
from kubios_auth import log_audit
from kubios_mail import send_email
from kubios_license import get_license_status
from kubios_comptes import _sync_state, EXCEL_PATH, BACKUP_DIR
from kubios_lightspeed import ls_config
from kubios_rh_outils import PDF_DIR, HR_DIR
from kubios_atelier import HT_DROP_DIR
from kubios_systeme import VERSIONS_DIR
from kubios_sauvegardes import fb_list, fb_dir

STARTED_AT = time.time()
_REQ = collections.deque(maxlen=20000)          # (horodatage, durée ms, code HTTP) des requêtes récentes
_REQ_LOCK = threading.Lock()
MAINT_PUNCH_PATHS = ('/punch-employes', '/api/tc/station', '/api/tc/punch', '/atelier/punch', '/api/atelier/kiosk')
MAINT_ALWAYS = ('static', 'login', 'login_mfa', 'login_mfa_setup', 'logout')
HEALTH_DEFAULTS = {'disk_min_pct': 10, 'disk_min_gb': 5, 'backup_max_h': 26, 'p95_max_ms': 3000, 'errors_max_1h': 5,
                   'failed_logins_max_1h': 20, 'level': 'error', 'emails': ''}
STATUS_ORDER = {'ok': 0, 'info': 0, 'warn': 1, 'error': 2}
BACKGROUND_TASKS = {                                  # tâches lancées par start_app() ; une tâche arrêtée = alerte
    '_auto_sync_loop': 'synchronisation Excel', '_net_time_loop': 'horloge de confiance', '_ls_auto_sync_loop': 'synchronisation Lightspeed',
    '_nightly_loop': 'tâches de nuit', '_full_backup_loop': 'sauvegarde complète', '_inventory_loop': 'instantanés d\u2019inventaire',
    '_atelier_reread_loop': 'relecture des ventes de l\u2019atelier', '_ht_drop_loop': 'dépôt HubTiger', 'surveillance_sante': 'surveillance de la santé'}


# ---------------------------------------------------------------------------
# Super administrateur
# ---------------------------------------------------------------------------
def is_superadmin():
    return bool(session.get('is_superadmin'))


def user_is_superadmin(user_id):
    conn = get_conn()
    try:
        r = conn.execute("SELECT is_superadmin FROM users WHERE id=?", (user_id,)).fetchone()
        return bool(r and r['is_superadmin'])
    finally:
        conn.close()


def superadmin_ids():
    conn = get_conn()
    try:
        return {r['id'] for r in conn.execute("SELECT id FROM users WHERE is_superadmin=1").fetchall()}
    finally:
        conn.close()


def _require_superadmin():
    if not session.get('user_id'):
        return jsonify({'ok': False, 'error': 'Connexion requise.'}), 401
    if not is_superadmin():
        return jsonify({'ok': False, 'error': 'Réservé au super administrateur.'}), 403
    return None


@app.before_request
def _protect_superadmin_accounts():
    """Un compte super administrateur (fournisseur) ne peut être modifié ou supprimé que par un super administrateur."""
    if request.method in ('PUT', 'DELETE', 'POST') and request.path.startswith('/api/users/') and not is_superadmin():
        tail = request.path[len('/api/users/'):].split('/')[0]
        if tail.isdigit() and user_is_superadmin(int(tail)):
            return jsonify({'ok': False, 'error': "Ce compte appartient au fournisseur du logiciel (accès de maintenance) : "
                                                  "il ne peut pas être modifié ici. Communiquez avec votre fournisseur au besoin."}), 403
    return None


# ---------------------------------------------------------------------------
# Mode maintenance
# ---------------------------------------------------------------------------
def maintenance_state():
    return {'on': meta_get('maint_on') == '1', 'message': meta_get('maint_msg') or '', 'until': meta_get('maint_until') or '',
            'punch': meta_get('maint_punch') != '0', 'since': meta_get('maint_since') or '', 'by': meta_get('maint_by') or ''}


_MAINT_CACHE = {'t': 0.0, 'on': False}


def _maint_on():
    """État du mode maintenance, relu au plus toutes les 3 secondes (évite une lecture de la base à chaque requête)."""
    if time.time() - _MAINT_CACHE['t'] > 3:
        _MAINT_CACHE.update(t=time.time(), on=(meta_get('maint_on') == '1'))
    return _MAINT_CACHE['on']


@app.before_request
def _maintenance_gate():
    """En maintenance, seul le super administrateur utilise Kubios ; les autres voient la page de maintenance."""
    if not _maint_on() or request.endpoint in MAINT_ALWAYS or is_superadmin():
        return None
    st = maintenance_state()
    if st['punch'] and request.path.startswith(MAINT_PUNCH_PATHS):
        return None
    if request.path.startswith('/api/'):
        return jsonify({'ok': False, 'error': 'Kubios est en maintenance. ' + (st['message'] or 'Réessayez dans quelques minutes.')}), 503
    return render_template('maintenance.html', company=get_company_name(), st=st), 503


# ---------------------------------------------------------------------------
# Mesure des requêtes et des erreurs
# ---------------------------------------------------------------------------
@app.before_request
def _metrics_start():
    g._t0 = time.perf_counter()


@app.after_request
def _metrics_end(resp):
    t0 = getattr(g, '_t0', None)
    if t0 is not None and request.endpoint != 'static':
        with _REQ_LOCK:
            _REQ.append((time.time(), (time.perf_counter() - t0) * 1000.0, resp.status_code))
    return resp


def _record_error(sender, exception, **extra):
    try:
        conn = get_conn()
        try:
            conn.execute("INSERT INTO app_errors(ts, method, path, username, error, trace) VALUES (?,?,?,?,?,?)",
                         (_at_now(), request.method, request.path[:300], session.get('username'), f"{type(exception).__name__}: {exception}"[:500],
                          traceback.format_exc()[-4000:]))
            conn.execute("DELETE FROM app_errors WHERE id NOT IN (SELECT id FROM app_errors ORDER BY id DESC LIMIT 500)")
            conn.commit()
        finally:
            conn.close()
    except Exception:
        pass


got_request_exception.connect(_record_error, app)


def request_stats(seconds):
    cut = time.time() - seconds
    with _REQ_LOCK:
        rows = [r for r in _REQ if r[0] >= cut]
    if not rows:
        return {'count': 0, 'avg_ms': 0, 'p95_ms': 0, 'errors': 0}
    ms = sorted(r[1] for r in rows)
    return {'count': len(rows), 'avg_ms': round(sum(ms) / len(ms)), 'p95_ms': round(ms[min(len(ms) - 1, int(len(ms) * 0.95))]),
            'errors': sum(1 for r in rows if r[2] >= 500)}


# ---------------------------------------------------------------------------
# Vérifications
# ---------------------------------------------------------------------------
def health_cfg():
    try:
        cfg = json.loads(meta_get('health_cfg') or '{}')
    except ValueError:
        cfg = {}
    return {**HEALTH_DEFAULTS, **{k: v for k, v in cfg.items() if k in HEALTH_DEFAULTS}}


def _proc_mem_mb():
    try:
        import psutil
        return round(psutil.Process().memory_info().rss / 1048576)
    except Exception:
        pass
    if sys.platform == 'win32':
        try:
            import ctypes
            from ctypes import wintypes

            class PMC(ctypes.Structure):
                _fields_ = [('cb', wintypes.DWORD), ('PageFaultCount', wintypes.DWORD), ('PeakWorkingSetSize', ctypes.c_size_t),
                            ('WorkingSetSize', ctypes.c_size_t), ('QuotaPeakPagedPoolUsage', ctypes.c_size_t), ('QuotaPagedPoolUsage', ctypes.c_size_t),
                            ('QuotaPeakNonPagedPoolUsage', ctypes.c_size_t), ('QuotaNonPagedPoolUsage', ctypes.c_size_t),
                            ('PagefileUsage', ctypes.c_size_t), ('PeakPagefileUsage', ctypes.c_size_t)]
            c = PMC(); c.cb = ctypes.sizeof(PMC)
            ctypes.windll.psapi.GetProcessMemoryInfo(ctypes.windll.kernel32.GetCurrentProcess(), ctypes.byref(c), c.cb)
            return round(c.WorkingSetSize / 1048576)
        except Exception:
            return None
    try:
        import resource
        return round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024)
    except Exception:
        return None


def _dir_check(label, path, must_exist=True):
    p = Path(path)
    if not p.exists():
        return {'label': label, 'status': 'error' if must_exist else 'info', 'value': 'absent', 'detail': str(p)}
    try:
        fd, tmp = tempfile.mkstemp(prefix='.kubios_test_', dir=str(p))
        os.close(fd); os.remove(tmp)
        return {'label': label, 'status': 'ok', 'value': 'lecture et écriture', 'detail': str(p)}
    except Exception as e:
        return {'label': label, 'status': 'error', 'value': 'écriture impossible', 'detail': f"{p} — {e}"}


def _fmt_age(sec):
    if sec is None:
        return 'jamais'
    if sec < 3600:
        return f"il y a {int(sec // 60)} min"
    if sec < 172800:
        return f"il y a {sec / 3600:.1f} h".replace('.', ',')
    return f"il y a {int(sec // 86400)} jours"


def health_checks():
    cfg = health_cfg()
    now = datetime.datetime.now()
    groups = collections.OrderedDict()

    def add(group, cid, label, status, value, detail=''):
        groups.setdefault(group, []).append({'id': cid, 'label': label, 'status': status, 'value': value, 'detail': detail})

    # --- Système
    up = time.time() - STARTED_AT
    add('Système', 'version', 'Version de Kubios', 'info', APP_VERSION)
    add('Système', 'uptime', 'En marche depuis', 'info', _fmt_age(up).replace('il y a ', ''), datetime.datetime.fromtimestamp(STARTED_AT).strftime('%Y-%m-%d %H:%M'))
    add('Système', 'host', 'Ordinateur', 'info', socket.gethostname(), f"{platform.system()} {platform.release()} · Python {platform.python_version()}")
    mem = _proc_mem_mb()
    add('Système', 'memory', 'Mémoire utilisée par Kubios', 'info' if mem is None or mem < 1500 else 'warn', f"{mem} Mo" if mem is not None else 'non disponible')
    running = {t.name.split('(')[-1].rstrip(')') if '(' in t.name else t.name for t in threading.enumerate() if t.is_alive()}
    started = [n for n in BACKGROUND_TASKS if n in running]
    if not started:
        add('Système', 'threads', 'Tâches de fond', 'info', 'non démarrées', 'Kubios n\u2019a pas été lancé par le service ou start.bat (mode test).')
    else:
        missing = [BACKGROUND_TASKS[n] for n in BACKGROUND_TASKS if n not in running]
        add('Système', 'threads', 'Tâches de fond', 'error' if missing else 'ok',
            f"{len(started)} sur {len(BACKGROUND_TASKS)} en marche", ('ARRÊTÉE(S) : ' + ', '.join(missing) + ' — redémarrer Kubios') if missing else
            ', '.join(BACKGROUND_TASKS[n] for n in started))
    # --- Stockage
    try:
        du = shutil.disk_usage(str(BASE_DIR))
        free_gb, pct = du.free / 1073741824, du.free / du.total * 100
        st = 'error' if (pct < cfg['disk_min_pct'] / 2 or free_gb < cfg['disk_min_gb'] / 2) else ('warn' if (pct < cfg['disk_min_pct'] or free_gb < cfg['disk_min_gb']) else 'ok')
        add('Stockage', 'disk', 'Espace disque libre', st, f"{free_gb:.1f} Go ({pct:.0f} %)".replace('.', ','), f"sur {du.total / 1073741824:.0f} Go — {BASE_DIR.anchor or BASE_DIR}".replace('.', ','))
    except Exception as e:
        add('Stockage', 'disk', 'Espace disque libre', 'error', 'illisible', str(e))
    for cid, label, path, must in (('dir_base', 'Dossier principal', BASE_DIR, True), ('dir_app', 'Dossier du programme', APP_DIR, True),
                                   ('dir_pdf', 'États de compte (PDF)', PDF_DIR, True), ('dir_backup', 'Sauvegardes avant modification', BACKUP_DIR, True),
                                   ('dir_fb', 'Sauvegardes complètes', fb_dir(), True), ('dir_hr', 'Documents RH', HR_DIR, False),
                                   ('dir_ht', 'Dépôt HubTiger', HT_DROP_DIR, False), ('dir_ver', 'Versions conservées', VERSIONS_DIR, False)):
        r = _dir_check(label, path, must); add('Stockage', cid, r['label'], r['status'], r['value'], r['detail'])
    # --- Base de données
    try:
        size = DB_PATH.stat().st_size; wal = Path(str(DB_PATH) + '-wal')
        wal_size = wal.stat().st_size if wal.exists() else 0
        add('Base de données', 'db_size', 'Taille de la base', 'ok', f"{size / 1048576:.1f} Mo".replace('.', ','), f"journal WAL : {wal_size / 1048576:.1f} Mo".replace('.', ','))
        conn = get_conn()
        try:
            mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
            add('Base de données', 'db_mode', 'Mode du journal', 'ok' if mode.lower() == 'wal' else 'warn', mode.upper())
            t0 = time.perf_counter(); conn.execute("SELECT COUNT(*) FROM users").fetchone()
            ms = (time.perf_counter() - t0) * 1000
            add('Base de données', 'db_latency', 'Temps de réponse de la base', 'ok' if ms < 200 else 'warn', f"{ms:.0f} ms")
        finally:
            conn.close()
    except Exception as e:
        add('Base de données', 'db_size', 'Base de données', 'error', 'inaccessible', str(e))
    integ = meta_get('health_integrity') or ''
    integ_at = meta_get('health_integrity_at') or ''
    add('Base de données', 'db_integrity', 'Intégrité (vérification de nuit)', 'info' if not integ else ('ok' if integ == 'ok' else 'error'),
        'jamais vérifiée' if not integ else ('intègre' if integ == 'ok' else 'PROBLÈME'), (integ_at + (' — ' + integ if integ not in ('', 'ok') else '')).strip(' —'))
    # --- Sauvegardes
    try:
        lst = fb_list()
        if not lst:
            add('Sauvegardes', 'backup', 'Dernière sauvegarde complète', 'error', 'aucune')
        else:
            last = datetime.datetime.strptime(lst[0]['created_at'][:19], '%Y-%m-%d %H:%M:%S')
            age_h = (now - last).total_seconds() / 3600
            st = 'error' if age_h > cfg['backup_max_h'] * 2 else ('warn' if age_h > cfg['backup_max_h'] else 'ok')
            add('Sauvegardes', 'backup', 'Dernière sauvegarde complète', st, _fmt_age(age_h * 3600), f"{lst[0]['name']} · {len(lst)} conservée(s)")
            if not lst[0].get('valid'):
                add('Sauvegardes', 'backup_valid', 'Dernière sauvegarde lisible', 'error', 'base absente du fichier', lst[0]['name'])
    except Exception as e:
        add('Sauvegardes', 'backup', 'Dernière sauvegarde complète', 'error', 'illisible', str(e))
    # --- Connexions externes
    try:
        lc = ls_config()
        if not lc['connected']:
            add('Connexions', 'lightspeed', 'Lightspeed', 'info', 'non connecté')
        else:
            err = meta_get('ls_last_sync_error')
            add('Connexions', 'lightspeed', 'Lightspeed', 'warn' if err else 'ok', 'connecté' + (' — dernière synchro en erreur' if err else ''),
                (err or '') or ('dernière synchro : ' + (meta_get('ls_last_sync') or 'jamais')))
    except Exception as e:
        add('Connexions', 'lightspeed', 'Lightspeed', 'warn', 'illisible', str(e))
    try:
        mode = {'m365': 'Microsoft 365', 'smtp': 'SMTP'}.get(get_settings().get('send_mode'), 'Outlook')
        conn = get_conn()
        try:
            since = (now - datetime.timedelta(hours=24)).strftime('%Y-%m-%d %H:%M:%S')
            sent = conn.execute("SELECT COUNT(*) FROM email_log WHERE ts>=? AND status<>'erreur'", (since,)).fetchone()[0]
            errs = conn.execute("SELECT COUNT(*) FROM email_log WHERE ts>=? AND status='erreur'", (since,)).fetchone()[0]
            last_err = conn.execute("SELECT ts, error FROM email_log WHERE status='erreur' ORDER BY id DESC LIMIT 1").fetchone()
        finally:
            conn.close()
        add('Connexions', 'email', 'Envoi des courriels', 'error' if errs and not sent else ('warn' if errs else 'ok'),
            f"{mode} · {sent} envoyé(s), {errs} erreur(s) en 24 h", (f"dernière erreur {last_err['ts']} : {last_err['error']}" if last_err and errs else ''))
    except Exception as e:
        add('Connexions', 'email', 'Envoi des courriels', 'warn', 'illisible', str(e))
    try:
        err = _sync_state.get('last_error')
        age = (time.time() - EXCEL_PATH.stat().st_mtime) if EXCEL_PATH.exists() else None
        add('Connexions', 'excel', 'Classeur Excel des comptes', 'warn' if err else ('ok' if EXCEL_PATH.exists() else 'info'),
            ('erreur de synchronisation' if err else ('à jour ' + _fmt_age(age) if age is not None else 'pas encore créé')), err or str(EXCEL_PATH))
    except Exception as e:
        add('Connexions', 'excel', 'Classeur Excel des comptes', 'warn', 'illisible', str(e))
    # --- Licence
    try:
        ls = get_license_status()
        if not ls.get('active'):
            add('Licence', 'license', 'Licence', 'error', 'inactive', ls.get('reason') or ls.get('error') or '')
        else:
            dl = ls.get('days_left')
            add('Licence', 'license', 'Licence', 'ok' if dl is None or dl > 30 else ('warn' if dl > 7 else 'error'),
                'à vie' if dl is None else f"{dl} jour(s) restant(s)", (ls.get('payload') or {}).get('licensee', ''))
    except Exception as e:
        add('Licence', 'license', 'Licence', 'warn', 'illisible', str(e))
    # --- Activité
    h1 = request_stats(3600)
    add('Activité', 'requests', 'Requêtes (dernière heure)', 'info', str(h1['count']), f"moyenne {h1['avg_ms']} ms")
    add('Activité', 'p95', 'Temps de réponse (95 % des requêtes)', 'ok' if h1['p95_ms'] <= cfg['p95_max_ms'] else 'warn', f"{h1['p95_ms']} ms",
        f"seuil d'alerte : {cfg['p95_max_ms']} ms")
    try:
        conn = get_conn()
        try:
            since = (now - datetime.timedelta(hours=1)).strftime('%Y-%m-%d %H:%M:%S')
            e1 = conn.execute("SELECT COUNT(*) FROM app_errors WHERE ts>=?", (since,)).fetchone()[0]
            f1 = conn.execute("SELECT COUNT(*) FROM audit_log WHERE ts>=? AND action='Connexion échouée'", (since,)).fetchone()[0]
            online = conn.execute("SELECT COUNT(*) FROM user_sessions WHERE revoked_at IS NULL AND last_seen>=?",
                                  ((now - datetime.timedelta(minutes=5)).strftime('%Y-%m-%d %H:%M:%S'),)).fetchone()[0]
        finally:
            conn.close()
        add('Activité', 'errors', 'Erreurs du serveur (dernière heure)', 'ok' if e1 == 0 else ('warn' if e1 <= cfg['errors_max_1h'] else 'error'), str(e1))
        add('Activité', 'failed_logins', 'Connexions échouées (dernière heure)', 'ok' if f1 <= cfg['failed_logins_max_1h'] else 'warn', str(f1),
            'beaucoup d\u2019échecs peut indiquer une tentative d\u2019intrusion' if f1 > cfg['failed_logins_max_1h'] else '')
        add('Activité', 'online', 'Personnes en ligne', 'info', str(online))
    except Exception as e:
        add('Activité', 'errors', 'Activité', 'warn', 'illisible', str(e))
    st = maintenance_state()
    add('Activité', 'maintenance', 'Mode maintenance', 'warn' if st['on'] else 'ok', 'ACTIF' if st['on'] else 'désactivé',
        (f"depuis {st['since']} par {st['by']}" if st['on'] else ''))
    allc = [c for v in groups.values() for c in v]
    worst = max((STATUS_ORDER[c['status']] for c in allc), default=0)
    return {'overall': ['ok', 'warn', 'error'][worst], 'groups': [{'name': k, 'checks': v} for k, v in groups.items()],
            'checked_at': now.strftime('%Y-%m-%d %H:%M:%S')}


# ---------------------------------------------------------------------------
# Historique des métriques, vérification de nuit et alertes
# ---------------------------------------------------------------------------
def metrics_snapshot():
    s5 = request_stats(300)
    try:
        du = shutil.disk_usage(str(BASE_DIR)); free_gb, pct = du.free / 1073741824, du.free / du.total * 100
    except Exception:
        free_gb = pct = None
    db_mb = DB_PATH.stat().st_size / 1048576 if DB_PATH.exists() else None
    conn = get_conn()
    try:
        online = conn.execute("SELECT COUNT(*) FROM user_sessions WHERE revoked_at IS NULL AND last_seen>=?",
                              ((datetime.datetime.now() - datetime.timedelta(minutes=5)).strftime('%Y-%m-%d %H:%M:%S'),)).fetchone()[0]
        conn.execute("INSERT INTO health_metrics(ts, disk_free_gb, disk_free_pct, db_mb, req_5min, avg_ms, p95_ms, errors_5min, online, mem_mb) "
                     "VALUES (?,?,?,?,?,?,?,?,?,?)", (_at_now(), free_gb, pct, db_mb, s5['count'], s5['avg_ms'], s5['p95_ms'], s5['errors'], online, _proc_mem_mb()))
        conn.execute("DELETE FROM health_metrics WHERE ts < ?", ((datetime.datetime.now() - datetime.timedelta(days=30)).strftime('%Y-%m-%d %H:%M:%S'),))
        conn.commit()
    finally:
        conn.close()


def integrity_check():
    """PRAGMA quick_check : vérifie la structure de la base sans la bloquer longtemps."""
    try:
        conn = sqlite3.connect(str(DB_PATH), timeout=30)
        try:
            res = conn.execute("PRAGMA quick_check").fetchall()
        finally:
            conn.close()
        val = 'ok' if res and res[0][0] == 'ok' else '; '.join(r[0] for r in res[:5])[:500]
    except Exception as e:
        val = f"vérification impossible : {e}"[:500]
    meta_set('health_integrity', val); meta_set('health_integrity_at', _at_now())
    return val


def _alert_recipients():
    return [x.strip() for x in (health_cfg()['emails'] or '').replace(';', ',').split(',') if '@' in x]


def _alert_html(title, color, items, footer):
    rows = ''.join(f"<tr><td style='padding:8px 10px;border-top:1px solid #e2e8f0;font-weight:700'>{c['group']} — {c['label']}</td>"
                   f"<td style='padding:8px 10px;border-top:1px solid #e2e8f0;color:{ {'error': '#b91c1c', 'warn': '#b45309'}.get(c['status'], '#166534') };font-weight:700'>{c['value']}</td>"
                   f"<td style='padding:8px 10px;border-top:1px solid #e2e8f0;color:#64748b;font-size:13px'>{c.get('detail') or ''}</td></tr>" for c in items)
    return (f"<div style='font-family:Segoe UI,Arial,sans-serif;max-width:680px;margin:0 auto'><div style='background:{color};color:#fff;padding:16px 22px;border-radius:12px 12px 0 0'>"
            f"<div style='font-size:13px;opacity:.85'>{get_company_name()} · Kubios {APP_VERSION} · {socket.gethostname()}</div><div style='font-size:20px;font-weight:800'>{title}</div></div>"
            f"<div style='border:1px solid #e2e8f0;border-top:0;border-radius:0 0 12px 12px;padding:16px 22px'><table style='width:100%;border-collapse:collapse;font-size:14px'>{rows}</table>"
            f"<p style='font-size:13px;color:#64748b'>{footer}</p></div></div>")


def run_alerts(force_test=False):
    """Compare l'état des vérifications au précédent ; avise le super administrateur des problèmes et des retours à la normale."""
    to = _alert_recipients()
    res = health_checks()
    flat = [{**c, 'group': gr['name']} for gr in res['groups'] for c in gr['checks']]
    if force_test:
        if not to:
            return {'ok': False, 'error': 'Aucun courriel d\u2019alerte n\u2019est enregistré.'}
        for addr in to:
            send_email(addr, f"[Kubios] Test des alertes — {get_company_name()}", "Ceci est un test des alertes de santé de Kubios.", None,
                       mode='send', bcc_company=False, category='Alertes système',
                       html=_alert_html('Test des alertes de santé', '#2563eb', flat[:8], 'Ce courriel confirme que les alertes vous parviendront.'))
        return {'ok': True, 'sent': len(to)}
    level = STATUS_ORDER['warn'] if health_cfg()['level'] == 'warn' else STATUS_ORDER['error']
    try:
        prev = json.loads(meta_get('health_alert_state') or '{}')
    except ValueError:
        prev = {}
    now = time.time()
    current = {c['id']: c['status'] for c in flat}
    new_bad = [c for c in flat if STATUS_ORDER[c['status']] >= level and (STATUS_ORDER.get(prev.get(c['id'], {}).get('s', 'ok'), 0) < STATUS_ORDER[c['status']]
                                                                     or now - prev.get(c['id'], {}).get('t', 0) > 12 * 3600)]
    recovered = [c for c in flat if STATUS_ORDER[c['status']] < level and STATUS_ORDER.get(prev.get(c['id'], {}).get('s', 'ok'), 0) >= level]
    state = {k: {'s': v, 't': prev.get(k, {}).get('t', 0)} for k, v in current.items()}
    if to and new_bad:
        worst = 'error' if any(c['status'] == 'error' for c in new_bad) else 'warn'
        for addr in to:
            try:
                send_email(addr, f"[Kubios] {'PROBLÈME' if worst == 'error' else 'Avertissement'} — {get_company_name()} ({len(new_bad)})",
                           '\n'.join(f"- {c['group']} — {c['label']} : {c['value']} {c.get('detail') or ''}" for c in new_bad), None,
                           mode='send', bcc_company=False, category='Alertes système',
                           html=_alert_html('Problème détecté' if worst == 'error' else 'Avertissement', '#b91c1c' if worst == 'error' else '#b45309', new_bad,
                                            'Ouvrez Kubios → Système → Santé du système pour le détail. Un rappel est envoyé toutes les 12 heures tant que le problème persiste.'))
            except Exception:
                traceback.print_exc()
        for c in new_bad:
            state[c['id']]['t'] = now
    if to and recovered:
        for addr in to:
            try:
                send_email(addr, f"[Kubios] Retour à la normale — {get_company_name()}", '\n'.join(f"- {c['group']} — {c['label']} : {c['value']}" for c in recovered),
                           None, mode='send', bcc_company=False, category='Alertes système',
                           html=_alert_html('Retour à la normale', '#16a34a', recovered, 'Ces vérifications sont revenues à la normale.'))
            except Exception:
                traceback.print_exc()
    meta_set('health_alert_state', json.dumps(state))
    return {'ok': True, 'problems': len(new_bad), 'recovered': len(recovered)}


def _health_loop():
    time.sleep(90)
    last_integrity_day = None
    while True:
        try:
            metrics_snapshot()
            n = datetime.datetime.now()
            if n.hour == 3 and last_integrity_day != n.date():           # vérification d'intégrité chaque nuit, vers 3 h
                integrity_check(); last_integrity_day = n.date()
            run_alerts()
        except Exception:
            traceback.print_exc()
        time.sleep(300)


def start_health_monitor():
    threading.Thread(target=_health_loop, name='surveillance_sante', daemon=True).start()


# ---------------------------------------------------------------------------
# Pages et API (super administrateur seulement)
# ---------------------------------------------------------------------------
@app.route('/systeme/sante')
def sante_page():
    if not session.get('user_id'):
        from flask import redirect, url_for
        return redirect(url_for('login', next=request.path))
    if not is_superadmin():
        return render_template('maintenance.html', company=get_company_name(), st={'on': False, 'message': 'Cette page est réservée au super administrateur.'},
                               forbidden=True), 403
    return render_template('sante.html', company=get_company_name())


@app.route('/api/sante')
def api_sante():
    resp = _require_superadmin()
    if resp:
        return resp
    res = health_checks()
    days = 7 if request.args.get('periode') == '7j' else 1
    conn = get_conn()
    try:
        since = (datetime.datetime.now() - datetime.timedelta(days=days)).strftime('%Y-%m-%d %H:%M:%S')
        metrics = [dict(r) for r in conn.execute("SELECT * FROM health_metrics WHERE ts>=? ORDER BY ts", (since,)).fetchall()]
        errors = [dict(r) for r in conn.execute("SELECT id, ts, method, path, username, error FROM app_errors ORDER BY id DESC LIMIT 25").fetchall()]
    finally:
        conn.close()
    cfg = health_cfg()
    return jsonify({'ok': True, **res, 'metrics': metrics, 'errors': errors, 'maintenance': maintenance_state(), 'cfg': cfg,
                    'stats_1h': request_stats(3600), 'stats_5m': request_stats(300)})


@app.route('/api/sante/erreurs/<int:eid>')
def api_sante_erreur(eid):
    resp = _require_superadmin()
    if resp:
        return resp
    conn = get_conn()
    try:
        r = conn.execute("SELECT * FROM app_errors WHERE id=?", (eid,)).fetchone()
    finally:
        conn.close()
    return jsonify({'ok': bool(r), 'error': dict(r) if r else None})


@app.route('/api/sante/integrite', methods=['POST'])
def api_sante_integrite():
    resp = _require_superadmin()
    if resp:
        return resp
    val = integrity_check()
    log_audit('Santé : vérification d\u2019intégrité de la base', val)
    return jsonify({'ok': True, 'result': val})


@app.route('/api/sante/reglages', methods=['POST'])
def api_sante_reglages():
    resp = _require_superadmin()
    if resp:
        return resp
    d = request.get_json(silent=True) or {}
    cfg = health_cfg()
    for k in ('disk_min_pct', 'disk_min_gb', 'backup_max_h', 'p95_max_ms', 'errors_max_1h', 'failed_logins_max_1h'):
        if k in d:
            try:
                cfg[k] = max(0, float(d[k]))
            except (TypeError, ValueError):
                return jsonify({'ok': False, 'error': 'Valeur invalide : ' + k}), 400
    if d.get('level') in ('error', 'warn'):
        cfg['level'] = d['level']
    if 'emails' in d:
        mails = [x.strip() for x in str(d['emails']).replace(';', ',').split(',') if x.strip()]
        bad = [m for m in mails if '@' not in m or '.' not in m.split('@')[-1]]
        if bad:
            return jsonify({'ok': False, 'error': 'Adresse invalide : ' + ', '.join(bad)}), 400
        cfg['emails'] = ', '.join(mails)
    meta_set('health_cfg', json.dumps(cfg))
    log_audit('Santé : réglages des alertes modifiés', json.dumps(cfg, ensure_ascii=False))
    return jsonify({'ok': True, 'cfg': cfg})


@app.route('/api/sante/test-alerte', methods=['POST'])
def api_sante_test_alerte():
    resp = _require_superadmin()
    if resp:
        return resp
    try:
        r = run_alerts(force_test=True)
    except Exception as e:
        r = {'ok': False, 'error': str(e)}
    return jsonify(r), (200 if r.get('ok') else 400)


@app.route('/api/sante/maintenance', methods=['POST'])
def api_sante_maintenance():
    resp = _require_superadmin()
    if resp:
        return resp
    d = request.get_json(silent=True) or {}
    on = bool(d.get('on'))
    meta_set('maint_msg', str(d.get('message') or '')[:500])
    meta_set('maint_until', str(d.get('until') or '')[:40])
    meta_set('maint_punch', '1' if d.get('punch', True) else '0')
    if on and meta_get('maint_on') != '1':
        meta_set('maint_since', _at_now()); meta_set('maint_by', session.get('full_name') or session.get('username') or '')
    meta_set('maint_on', '1' if on else '0')
    _MAINT_CACHE.update(t=0.0)
    log_audit('Mode maintenance ' + ('activé' if on else 'désactivé'), (d.get('message') or '') + (f" (fin prévue : {d.get('until')})" if d.get('until') else ''))
    return jsonify({'ok': True, 'maintenance': maintenance_state()})


# ---------------------------------------------------------------------------
# Promotion d'un compte, seulement sur l'ordinateur serveur (ligne de commande)
# ---------------------------------------------------------------------------
def _cli():
    import argparse
    ap = argparse.ArgumentParser(description="Kubios — super administrateur (à lancer sur l'ordinateur serveur).")
    grp = ap.add_mutually_exclusive_group(required=True)
    grp.add_argument('--promouvoir', metavar='UTILISATEUR'); grp.add_argument('--retirer', metavar='UTILISATEUR'); grp.add_argument('--liste', action='store_true')
    a = ap.parse_args()
    from kubios_sauvegardes import init_db_schema
    init_db_schema()                                   # au cas où la colonne n'existe pas encore
    conn = get_conn()
    try:
        if a.liste:
            rows = conn.execute("SELECT username, full_name FROM users WHERE is_superadmin=1").fetchall()
            print('Super administrateurs :', ', '.join(r['username'] for r in rows) or 'aucun'); return 0
        name = a.promouvoir or a.retirer
        u = conn.execute("SELECT id FROM users WHERE username=?", (name,)).fetchone()
        if not u:
            print(f"Compte introuvable : {name}. Créez d'abord le compte dans Kubios (Gestion → Utilisateurs)."); return 1
        if a.promouvoir:
            conn.execute("UPDATE users SET is_superadmin=1, is_admin=1, active=1 WHERE id=?", (u['id'],))
        else:
            conn.execute("UPDATE users SET is_superadmin=0 WHERE id=?", (u['id'],))
        conn.execute("INSERT INTO audit_log(ts, username, action, details) VALUES (?,?,?,?)",
                     (_at_now(), 'serveur', 'Super administrateur ' + ('accordé' if a.promouvoir else 'retiré'), f"{name} — depuis {socket.gethostname()}"))
        conn.commit()
        print(('Super administrateur accordé à ' if a.promouvoir else 'Super administrateur retiré à ') + name +
              '. La personne doit se reconnecter pour que le changement prenne effet.')
        return 0
    finally:
        conn.close()


if __name__ == '__main__':
    sys.exit(_cli())
