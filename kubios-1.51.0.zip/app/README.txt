KUBIOS — Logiciel de gestion d'entreprise
=========================================

Ce dossier contient le programme Kubios. Ne modifiez ni ne déplacez ses fichiers :
les mises à jour les remplacent automatiquement.

Démarrage
- Service Windows : Kubios démarre seul avec Windows (Installer_service.bat,
  à lancer une fois en tant qu'administrateur ; Redemarrer_service.bat pour le relancer).
- Démarrage manuel : start.bat (la fenêtre doit rester ouverte pendant l'utilisation).

Données
- La base de données (data.db) et les documents sont conservés dans ce dossier et
  dans le dossier parent. Les mises à jour ne les touchent jamais.
- Kubios fait une sauvegarde complète chaque nuit (Système → Sauvegardes).
  Conservez aussi une copie des sauvegardes hors de cet ordinateur.

Utilisation
- Consultez le Manuel d'utilisation de Kubios, remis par votre fournisseur.
- Pour toute question ou tout problème, communiquez avec votre fournisseur.
