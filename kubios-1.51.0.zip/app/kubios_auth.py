# -*- coding: utf-8 -*-
"""Contrôles d'accès, permissions, utilisateur courant et journal d'audit.
Module de Kubios (découpé de app.py en 1.46.0, code inchangé)."""
import os
import re
import io
import csv
import sys
import json
import base64
import hashlib
import unicodedata
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import openpyxl
from openpyxl.utils import get_column_letter
import licensing
from kubios_base import db_add_audit, get_conn

__all__ = ['PERMISSION_KEYS', '_dump_permissions', '_parse_permissions', 'admin_required_check', 'current_display_name', 'log_audit', 'permission_required_check']


PERMISSION_KEYS = {
    'comptes_recevoir': "Comptes à recevoir (clients, factures)",
    'reports': "Rapports (état de compte, envoi, vieillissement)",
    'audit': "Journal d'audit",
    'license': "Licence",
    'email_settings': "Paramètres d'envoi (Outlook/SMTP)",
    'updates': "Mises à jour",
    'credit_accounts': "Comptes de crédit (Lightspeed)",
    'custom_reports': "Rapport des ventes (Lightspeed)",
    'tax_reports': "Rapport des taxes (Lightspeed)",
    'inventory_reports': "Valeur de l'inventaire (Lightspeed)",
    'dashboard3d': "Tableau de bord 3D",
    'atelier_punch': "Gestion Atelier — poste de punch",
    'atelier': "Gestion Atelier — tableau et punchs",
    'atelier_profit': "Gestion Atelier — rentabilité et évaluations (données sensibles)",
    'rh': "Gestion RH — dossiers des employés (renseignements personnels)",
    'punch_presence': "Gestion RH — poste de punch des employés (ordinateur de travail)",
}


def _parse_permissions(raw):
    try:
        val = json.loads(raw) if raw else []
        return [p for p in val if p in PERMISSION_KEYS] if isinstance(val, list) else []
    except Exception:
        return []


def _dump_permissions(perms):
    clean = sorted(set(p for p in (perms or []) if p in PERMISSION_KEYS))
    return json.dumps(clean)


def admin_required_check():
    if not session.get('is_admin'):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'forbidden', 'message': 'Réservé aux administrateurs.'}), 403
        return "Accès refusé — réservé aux administrateurs.", 403
    return None


def permission_required_check(perm_key):
    """Comme admin_required_check, mais laisse passer un utilisateur non-admin
    qui a reçu la permission granulaire `perm_key` (voir PERMISSION_KEYS).
    Un administrateur a toujours accès à tout."""
    if session.get('is_admin'):
        return None
    if perm_key in (session.get('permissions') or []):
        return None
    if request.path.startswith('/api/'):
        return jsonify({'error': 'forbidden', 'message': "Ton compte n'a pas accès à cette section."}), 403
    return "Accès refusé — ton compte n'a pas accès à cette section.", 403


def log_audit(action, details=''):
    """À appeler depuis une route Flask (a accès à la session courante)."""
    db_add_audit(session.get('username'), action, details)


def current_display_name():
    name = session.get('full_name')
    if not name and session.get('user_id'):
        try:
            conn = get_conn()
            r = conn.execute("SELECT full_name FROM users WHERE id=?", (session['user_id'],)).fetchone()
            conn.close()
            name = r['full_name'] if r else None
        except Exception:
            name = None
    return (name or session.get('username') or '').strip()
