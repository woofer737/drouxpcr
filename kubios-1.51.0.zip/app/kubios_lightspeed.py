# -*- coding: utf-8 -*-
"""Connexion à Lightspeed (jeton, appels, limites) et téléchargement des ventes du magasin.
Module de Kubios (découpé de app.py en 1.48.0, code inchangé)."""
import os
import re
import io
import csv
import sys
import json
import base64
import hashlib
import unicodedata
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import openpyxl
from openpyxl.utils import get_column_letter
import licensing
from kubios_base import db_add_audit, get_conn, meta_get, meta_set
from kubios_version import APP_VERSION
from kubios_app import BASE_DIR

__all__ = ['APP_PORT', 'CARD_BRANDS', 'FEE_DIAG_PATH', 'HT_JOB_RE', 'LS_API_BASE', 'LS_AUTH_BASE', 'LS_AUTO_MODES', 'LS_BALANCE_SIGNS', 'LS_PAGE_LIMIT', 'LightspeedError', 'PAY_TYPE_FR', 'SERVICE_MIN_RE', 'STORE_CHUNK_DAYS', 'TAX_DEFAULT_NAMES', 'TAX_EPS', '_chunks', '_ls_api_get', '_ls_as_list', '_ls_card_brand', '_ls_error_text', '_ls_fee_info', '_ls_get_all', '_ls_header', '_ls_http', '_ls_is_account_payment', '_ls_line_text', '_ls_local_date', '_ls_payment_mode', '_ls_reconcile', '_ls_ref_cache', '_ls_sale_tax_total', '_ls_sync_state', '_ls_taxcat_classes', '_ls_taxcat_row', '_ls_throttle', '_ls_token_cache', '_ls_token_lock', '_ls_token_request', '_ls_workshop_info', '_parse_money', '_rep_line_values', '_store_fetch_range', '_store_lock', '_store_refresh_refs', '_store_state', '_tax_pct', '_truthy', 'ls_access_token', 'ls_config', 'ls_default_redirect_uri', 'ls_fetch_account', 'start_store_job', 'store_sync_days']


APP_PORT = int(os.environ.get("APP_PORT", "5080"))


LS_AUTH_BASE = os.environ.get('LS_AUTH_BASE', 'https://cloud.lightspeedapp.com/auth/oauth')


LS_API_BASE = os.environ.get('LS_API_BASE', 'https://api.lightspeedapp.com/API/V3')


LS_PAGE_LIMIT = 100


LS_BALANCE_SIGNS = ('auto', 'positive_du', 'negative_du')


LS_AUTO_MODES = ('off', 'daily', 'month_end')  # désactivée / chaque jour / dernier jour du mois


_ls_token_lock = threading.Lock()


_ls_token_cache = {'access_token': None, 'expires': 0.0}


_ls_sync_state = {'running': False, 'started_at': None, 'finished_at': None,
                  'progress': '', 'result': None, 'error': None, 'by': None}


class LightspeedError(RuntimeError):
    pass


def ls_default_redirect_uri():
    # Lightspeed exige une adresse https:// : aucune page n'y répond, le
    # navigateur affiche une erreur et l'utilisateur colle l'adresse obtenue
    # (qui contient le code d'autorisation) dans Administration → Lightspeed.
    # La même adresse sert pour le test et la prod.
    return "https://localhost/kubios-lightspeed"


def ls_config():
    try:
        hour = int(meta_get('ls_auto_sync_hour') or 22)
    except ValueError:
        hour = 22
    sign = meta_get('ls_balance_sign') or 'auto'
    auto_mode = meta_get('ls_auto_sync_mode')
    if auto_mode not in LS_AUTO_MODES:
        # versions 1.10.0 à 1.10.2 : simple case « chaque jour »
        auto_mode = 'daily' if meta_get('ls_auto_sync') == '1' else 'off'
    redirect_uri = (meta_get('ls_redirect_uri') or '').strip()
    if not redirect_uri or redirect_uri == f"http://localhost:{APP_PORT}/lightspeed/callback":
        # ancienne valeur proposée en 1.10.0/1.10.1, refusée par Lightspeed (http)
        redirect_uri = ls_default_redirect_uri()
    return {
        'client_id': (meta_get('ls_client_id') or '').strip(),
        'client_secret': (meta_get('ls_client_secret') or '').strip(),
        'redirect_uri': redirect_uri,
        'account_id': (meta_get('ls_account_id') or '').strip(),
        'account_name': meta_get('ls_account_name') or '',
        'connected': bool(meta_get('ls_refresh_token')),
        'balance_sign': sign if sign in LS_BALANCE_SIGNS else 'auto',
        'auto_sync': auto_mode != 'off',
        'auto_mode': auto_mode,
        'auto_sync_hour': min(max(hour, 0), 23),
    }


def _truthy(v):
    return str(v).strip().lower() in ('1', 'true', 'yes', 'oui')


def _ls_header(headers, name):
    for k, v in (headers or {}).items():
        if k.lower() == name.lower():
            return v
    return None


def _ls_http(method, url, data=None, headers=None, timeout=60):
    """Requête HTTP vers Lightspeed. Retourne (statut, en-têtes, JSON)."""
    hdrs = {'Accept': 'application/json', 'User-Agent': f'Kubios/{APP_VERSION}'}
    hdrs.update(headers or {})
    body = None
    if data is not None:
        body = urllib.parse.urlencode(data).encode('utf-8')
        hdrs['Content-Type'] = 'application/x-www-form-urlencoded'
    req = urllib.request.Request(url, data=body, headers=hdrs, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode('utf-8', 'replace')
            return r.status, dict(r.headers), (json.loads(raw) if raw.strip() else {})
    except urllib.error.HTTPError as e:
        raw = e.read().decode('utf-8', 'replace')
        try:
            payload = json.loads(raw)
        except Exception:
            payload = {'raw': raw[:300]}
        return e.code, dict(e.headers or {}), payload if isinstance(payload, dict) else {'raw': str(payload)[:300]}
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        reason = getattr(e, 'reason', e)
        raise LightspeedError(f"Impossible de joindre Lightspeed ({reason}). Vérifie la connexion Internet.")
    except ValueError:
        raise LightspeedError("Réponse illisible reçue de Lightspeed.")


def _ls_error_text(payload, status):
    for k in ('error_description', 'message', 'error', 'raw'):
        v = (payload or {}).get(k)
        if v:
            return str(v)
    return f"HTTP {status}"


def _ls_token_request(data):
    cfg = ls_config()
    if not cfg['client_id'] or not cfg['client_secret']:
        raise LightspeedError("Le Client ID et le Client secret Lightspeed ne sont pas configurés "
                              "(Administration → Lightspeed).")
    data = dict(data, client_id=cfg['client_id'], client_secret=cfg['client_secret'])
    status, _, payload = _ls_http('POST', f"{LS_AUTH_BASE}/token", data=data, timeout=30)
    if status != 200 or not payload.get('access_token'):
        raise LightspeedError(f"Lightspeed a refusé l'authentification : {_ls_error_text(payload, status)}. "
                              "Si le problème persiste, reconnecte Kubios à Lightspeed (Administration).")
    _ls_token_cache['access_token'] = payload['access_token']
    try:
        expires_in = int(payload.get('expires_in') or 1800)
    except (TypeError, ValueError):
        expires_in = 1800
    _ls_token_cache['expires'] = time.time() + max(expires_in - 60, 60)
    # Lightspeed peut remettre un nouveau refresh token (l'ancien devient
    # alors invalide) : on le garde immédiatement.
    if payload.get('refresh_token'):
        meta_set('ls_refresh_token', payload['refresh_token'])
    return payload['access_token']


def ls_access_token(force_refresh=False):
    with _ls_token_lock:
        if not force_refresh and _ls_token_cache['access_token'] and time.time() < _ls_token_cache['expires']:
            return _ls_token_cache['access_token']
        rt = meta_get('ls_refresh_token')
        if not rt:
            raise LightspeedError("Kubios n'est pas connecté à Lightspeed "
                                  "(Administration → Lightspeed → Connecter à Lightspeed).")
        return _ls_token_request({'grant_type': 'refresh_token', 'refresh_token': rt})


def _ls_throttle(headers):
    """Respecte la limite de requêtes de Lightspeed (« seau » X-LS-API-Bucket-Level)."""
    level = _ls_header(headers, 'X-LS-API-Bucket-Level') or ''
    try:
        used, cap = (float(x) for x in level.split('/'))
        time.sleep(2.0 if cap and used / cap > 0.7 else 0.3)
    except Exception:
        time.sleep(0.5)


def _ls_api_get(path_or_url, params=None):
    url = path_or_url if path_or_url.startswith('http') else f"{LS_API_BASE}{path_or_url}"
    if params:
        url += ('&' if '?' in url else '?') + urllib.parse.urlencode(params)
    for attempt in range(6):
        token = ls_access_token(force_refresh=(attempt > 0 and _ls_token_cache['access_token'] is None))
        status, headers, payload = _ls_http('GET', url, headers={'Authorization': f'Bearer {token}'})
        if status == 200:
            _ls_throttle(headers)
            return payload
        if status == 401 and attempt == 0:
            _ls_token_cache['access_token'] = None
            continue
        if status in (429, 502, 503, 504):
            try:
                wait = float(_ls_header(headers, 'Retry-After') or 0)
            except ValueError:
                wait = 0
            time.sleep(min(max(wait, 2 ** attempt), 30))
            continue
        raise LightspeedError(f"Erreur de l'API Lightspeed (HTTP {status}) : {_ls_error_text(payload, status)}")
    raise LightspeedError("Lightspeed ne répond pas ou reçoit trop de requêtes. Réessaie dans quelques minutes.")


def _ls_as_list(v):
    if v is None or v == '':
        return []
    return v if isinstance(v, list) else [v]


def _ls_get_all(account_id, resource, params, label, state=None):
    """Lit toutes les pages d'une ressource (pagination « next » de l'API V3,
    ou par offset pour les réponses plus anciennes)."""
    base = f"/Account/{account_id}/{resource}.json"
    url, query = base, dict(params, limit=LS_PAGE_LIMIT)
    out = []
    for _ in range(2000):
        data = _ls_api_get(url, query)
        out.extend(_ls_as_list(data.get(resource)))
        (state if state is not None else _ls_sync_state)['progress'] = f"{label} : {len(out)} lu(s)…"
        attrs = data.get('@attributes') or {}
        nxt = attrs.get('next')
        if nxt:
            url, query = nxt, None
            continue
        try:
            count = int(attrs.get('count') or 0)
            offset = int(attrs.get('offset') or 0)
            lim = int(attrs.get('limit') or LS_PAGE_LIMIT)
        except (TypeError, ValueError):
            break
        if 'offset' in attrs and offset + lim < count:
            url, query = base, dict(params, limit=LS_PAGE_LIMIT, offset=offset + lim)
            continue
        break
    return out


def ls_fetch_account():
    data = _ls_api_get('/Account.json')
    acc = _ls_as_list(data.get('Account'))
    if not acc:
        raise LightspeedError("Aucun compte Lightspeed accessible avec cette connexion.")
    return str(acc[0].get('accountID') or '').strip(), (acc[0].get('name') or '').strip()


def _ls_local_date(ts):
    """Date locale (AAAA-MM-JJ) d'un horodatage ISO de Lightspeed."""
    if not ts:
        return None
    try:
        dt = datetime.datetime.fromisoformat(str(ts).replace('Z', '+00:00'))
        if dt.tzinfo is not None:
            dt = dt.astimezone()
        return dt.date().isoformat()
    except ValueError:
        return str(ts)[:10]


def _ls_is_account_payment(p):
    ca = str(p.get('creditAccountID') or '').strip()
    if ca and ca != '0':
        return True
    ptype = str((p.get('PaymentType') or {}).get('type') or '').strip().lower()
    return ptype == 'credit account'


_ls_ref_cache = {}   # catégories / magasins : gardés 30 min


def _rep_line_values(ln):
    qty = _parse_money(ln.get('unitQuantity'))
    unit = _parse_money(ln.get('unitPrice'))
    raw_sub = ln.get('calcSubtotal')
    subtotal = _parse_money(raw_sub) if raw_sub not in (None, '') else unit * qty
    discount = _parse_money(ln.get('calcLineDiscount')) + _parse_money(ln.get('calcTransactionDiscount'))
    total = subtotal - discount
    unit_cost = _parse_money(ln.get('fifoCost')) or _parse_money(ln.get('avgCost'))
    return qty, subtotal, discount, total, unit_cost * qty


STORE_CHUNK_DAYS = 7


_store_lock = threading.Lock()


_store_state = {'running': False, 'progress': '', 'error': None, 'kind': None, 'done_days': 0, 'total_days': 0}


def _store_refresh_refs(account_id, st):
    cats = _ls_get_all(account_id, 'Category', {}, 'Catégories', state=st)
    shops = _ls_get_all(account_id, 'Shop', {}, 'Magasins', state=st)
    try:
        taxcats = _ls_get_all(account_id, 'TaxCategory', {'load_relations': json.dumps(['TaxCategoryClasses'])},
                              'Catégories de taxes', state=st)
    except LightspeedError:
        taxcats = []
    try:
        taxclasses = _ls_get_all(account_id, 'TaxClass', {}, 'Classes de taxes', state=st)
    except LightspeedError:
        taxclasses = []
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    conn = get_conn()
    try:
        for c in cats:
            cid = str(c.get('categoryID') or '').strip()
            if cid:
                name = (c.get('name') or '').strip() or f"Catégorie {cid}"
                conn.execute("INSERT OR REPLACE INTO ls_categories(category_id, name, path, updated_at) VALUES (?,?,?,?)",
                             (cid, name, (c.get('fullPathName') or '').strip() or name, now))
        for s in shops:
            conn.execute("INSERT OR REPLACE INTO ls_shops(shop_id, name, archived) VALUES (?,?,?)",
                         (str(s.get('shopID')), (s.get('name') or '').strip() or f"Magasin {s.get('shopID')}",
                          1 if _truthy(s.get('archived')) else 0))
        for tc in taxclasses:
            cid = str(tc.get('taxClassID') or '').strip()
            if cid:
                conn.execute("INSERT OR REPLACE INTO ls_tax_classes(tax_class_id, name) VALUES (?,?)",
                             (cid, (tc.get('name') or '').strip() or f"Classe {cid}"))
        for t in taxcats:
            row = _ls_taxcat_row(t)
            if not row[0]:
                continue
            for cc in _ls_taxcat_classes(t):
                conn.execute("INSERT OR REPLACE INTO ls_tax_category_classes(tax_category_id, tax_class_id, tax1_rate, "
                             "tax2_rate) VALUES (?,?,?,?)", (row[0], cc[0], cc[1], cc[2]))
            has_real_name = any(isinstance(t.get(k), str) and t.get(k).strip()
                                for k in ('taxCategoryName', 'taxName', 'name', 'description', 'title'))
            known = conn.execute("SELECT name FROM ls_tax_categories WHERE tax_category_id=?", (row[0],)).fetchone()
            if not has_real_name and known and known['name'] and not re.fullmatch(r'Catégorie \d+', known['name']):
                # garder le vrai nom déjà connu ; mettre à jour seulement les taxes
                conn.execute("UPDATE ls_tax_categories SET tax1_name=?, tax2_name=?, tax1_rate=?, tax2_rate=? "
                             "WHERE tax_category_id=?", (row[2], row[3], row[4], row[5], row[0]))
            else:
                conn.execute("INSERT OR REPLACE INTO ls_tax_categories(tax_category_id, name, tax1_name, tax2_name, "
                             "tax1_rate, tax2_rate) VALUES (?,?,?,?,?,?)", row)
        conn.commit()
    finally:
        conn.close()
    _ls_ref_cache.clear()


def _store_fetch_range(account_id, d0, d1, st):
    """Lit les ventes de d0 à d1 (inclus) et remplace les lignes de ces jours."""
    t0 = datetime.datetime.combine(d0, datetime.time()).astimezone()
    t1 = datetime.datetime.combine(d1 + datetime.timedelta(days=1), datetime.time()).astimezone()
    params = {'completed': 'true',
              'completeTime': f"><,{t0.isoformat(timespec='seconds')},{t1.isoformat(timespec='seconds')}",
              'load_relations': ''}
    base_rel = ['SaleLines', 'SaleLines.Item', 'TaxCategory', 'TaxCategory.TaxCategoryClasses', 'SalePayments', 'SalePayments.PaymentType']
    optional = [(flag, rel) for flag, rel in (('ls_no_cccharge', 'SalePayments.CCCharge'), ('ls_no_line_note', 'SaleLines.Note'))
                if meta_get(flag) != '1']
    sales, last_err = None, None
    for drop in range(len(optional) + 1):     # tout d'abord ; puis sans le détail des cartes ; puis sans les notes
        kept, dropped = optional[drop:], optional[:drop]
        params['load_relations'] = json.dumps(base_rel + [rel for _f, rel in kept])
        try:
            sales = _ls_get_all(account_id, 'Sale', params, f"Ventes du {d0.isoformat()} au {d1.isoformat()}", state=st)
        except LightspeedError as e:
            last_err = e
            continue
        for flag, _rel in dropped:            # relation refusée par ce compte : on s'en passe désormais
            meta_set(flag, '1')
        break
    if sales is None:
        raise last_err
    taxcats_seen = {}
    for s_ in sales:
        tc = s_.get('TaxCategory')
        if isinstance(tc, dict) and str(tc.get('taxCategoryID') or s_.get('taxCategoryID') or '').strip():
            tc = dict(tc)
            tc.setdefault('taxCategoryID', s_.get('taxCategoryID'))
            row = _ls_taxcat_row(tc)
            has_real_name = any(isinstance(tc.get(k), str) and tc.get(k).strip()
                                for k in ('taxCategoryName', 'taxName', 'name', 'description', 'title'))
            taxcats_seen[row[0]] = (row, has_real_name)
    conn = get_conn()
    known_classes = {}
    for r in conn.execute("SELECT * FROM ls_tax_category_classes").fetchall():
        known_classes.setdefault(r['tax_category_id'], {})[r['tax_class_id']] = (r['tax1_rate'], r['tax2_rate'])
    conn.close()
    rows, counts, class_rates_seen = [], {}, []
    pay_rows = []
    diag, diag_items, diag_ws, diag_pay = [], [], [], []
    for s in sales:
        if _truthy(s.get('voided')):
            continue
        day = _ls_local_date(s.get('completeTime')) or d0.isoformat()
        sid = str(s.get('saleID') or '').strip()
        counts[day] = counts.get(day, 0) + 1
        tax_cat = str(s.get('taxCategoryID') or '').strip()
        s_r1, s_r2 = _parse_money(s.get('tax1Rate')), _parse_money(s.get('tax2Rate'))
        for k_, p_ in enumerate(_ls_as_list((s.get('SalePayments') or {}).get('SalePayment'))):
            pt = p_.get('PaymentType') if isinstance(p_.get('PaymentType'), dict) else {}
            mode = _ls_payment_mode(p_)
            if len(diag_pay) < 20 and mode not in {d_['mode_kubios'] for d_ in diag_pay}:
                diag_pay.append({'mode_kubios': mode, 'brut': {k: v for k, v in p_.items() if k not in ('Sale',)}})
            pay_rows.append((str(p_.get('salePaymentID') or f"{sid}-p{k_}"), sid, day, str(s.get('shopID') or ''),
                             str(p_.get('paymentTypeID') or pt.get('paymentTypeID') or ''), mode,
                             ((pt.get('type') or '').strip() + ' | ' + (pt.get('name') or '').strip())[:120],
                             round(_parse_money(p_.get('amount')), 2)))
        # taux propres aux classes d'articles dans la catégorie de la vente
        cls_rates = dict(known_classes.get(tax_cat, {}))
        tc = s.get('TaxCategory') if isinstance(s.get('TaxCategory'), dict) else {}
        for cid, a, b in _ls_taxcat_classes(tc):
            cls_rates[cid] = (a, b)
            class_rates_seen.append((tax_cat, cid, a, b))
        lines = []
        for i, ln in enumerate(_ls_as_list((s.get('SaleLines') or {}).get('SaleLine'))):
            item = ln.get('Item') or {}
            qty, sub, disc, tot, cost = _rep_line_values(ln)
            tcls = str(ln.get('taxClassID') or item.get('taxClassID') or '').strip()
            if tcls == '0':
                tcls = ''
            taxable = 0 if str(ln.get('tax', 'true')).strip().lower() == 'false' else 1
            # Taux : celui de la ligne, sinon celui de la classe de l'article dans la
            # catégorie de taxes de la vente, sinon celui de la vente.
            c1, c2 = cls_rates.get(tcls, (s_r1, s_r2))
            r1 = _parse_money(ln.get('tax1Rate')) if ln.get('tax1Rate') not in (None, '') else c1
            r2 = _parse_money(ln.get('tax2Rate')) if ln.get('tax2Rate') not in (None, '') else c2
            t1 = _parse_money(ln.get('calcTax1')) if ln.get('calcTax1') not in (None, '') else (tot * r1 if taxable else 0.0)
            t2 = _parse_money(ln.get('calcTax2')) if ln.get('calcTax2') not in (None, '') else (tot * r2 if taxable else 0.0)
            is_fee, fee_name = _ls_fee_info(ln)
            ws_text, ws_job, ws_min = _ls_workshop_info(ln, qty)
            if ws_job and len(diag_ws) < 25:
                diag_ws.append(ln)
            if (is_fee or str(ln.get('itemID') or '0').strip() in ('', '0')) and len(diag) < 25:
                diag.append(ln)
            elif len(diag_items) < 3:
                diag_items.append(ln)
            lines.append([str(ln.get('saleLineID') or f"{sid}-{i}"), sid, day, str(s.get('shopID') or ''),
                          str(ln.get('itemID') or item.get('itemID') or '0').strip() or '0',
                          str(item.get('categoryID') or '').strip(), qty, round(sub, 4), round(disc, 4),
                          round(tot, 4), round(cost, 4), t1, t2, r1, r2, taxable,
                          str(ln.get('taxCategoryID') or '').strip() or tax_cat, tcls, 1 if is_fee else 0, fee_name,
                          (ws_text[:400] if (ws_job or ws_min or is_fee) else None), ws_job, ws_min])
        # Taxes arrondies PAR VENTE, comme Lightspeed : la somme des lignes est
        # ajustée au total de taxe de la vente.
        for col, idx in ((11, 1), (12, 2)):
            target = _ls_sale_tax_total(s, idx)
            if target is not None and lines:
                adj = _ls_reconcile([l[col] for l in lines], [l[9] if l[15] else 0 for l in lines], target)
                for l, v in zip(lines, adj):
                    l[col] = v
        for l in lines:
            l[11], l[12] = round(l[11], 4), round(l[12], 4)
            rows.append(tuple(l))
    today = datetime.date.today()
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    conn = get_conn()
    try:
        for cat, cid, a, b in class_rates_seen:
            conn.execute("INSERT OR REPLACE INTO ls_tax_category_classes(tax_category_id, tax_class_id, tax1_rate, "
                         "tax2_rate) VALUES (?,?,?,?)", (cat, cid, a, b))
        for row, has_real_name in taxcats_seen.values():
            # ne remplace pas un vrai nom déjà connu par un nom construit à partir des taxes
            known = conn.execute("SELECT name FROM ls_tax_categories WHERE tax_category_id=?", (row[0],)).fetchone()
            if not has_real_name and known and known['name'] and not re.fullmatch(r'Catégorie \d+', known['name']):
                continue
            conn.execute("INSERT OR REPLACE INTO ls_tax_categories(tax_category_id, name, tax1_name, tax2_name, "
                         "tax1_rate, tax2_rate) VALUES (?,?,?,?,?,?)", row)
        conn.execute("DELETE FROM sales_lines WHERE sale_date BETWEEN ? AND ?", (d0.isoformat(), d1.isoformat()))
        conn.execute("DELETE FROM sales_payments WHERE sale_date BETWEEN ? AND ?", (d0.isoformat(), d1.isoformat()))
        conn.executemany("INSERT OR REPLACE INTO sales_payments(payment_id, sale_id, sale_date, shop_id, type_id, name, ptype, amount) "
                         "VALUES (?,?,?,?,?,?,?,?)", pay_rows)
        conn.executemany("INSERT OR REPLACE INTO sales_lines(sale_line_id, sale_id, sale_date, shop_id, item_id, "
                         "category_id, qty, subtotal, discount, total, cost, tax1, tax2, tax1_rate, tax2_rate, "
                         "taxable, tax_cat, tax_class, is_fee, fee_name, descr, job_ref, svc_minutes) "
                         "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
        d = d0
        while d <= d1:
            conn.execute("INSERT OR REPLACE INTO sales_days(day, sales_count, complete, fetched_at, tax_ok, ws_ok, pay_ok) "
                         "VALUES (?,?,?,?,3,1,2)", (d.isoformat(), counts.get(d.isoformat(), 0), 1 if d < today else 0, now))
            d += datetime.timedelta(days=1)
        conn.commit()
    finally:
        conn.close()
    # Diagnostic : quelques lignes brutes (frais, articles divers, articles) pour
    # vérifier comment Lightspeed décrit les frais. Aucune donnée de client.
    if diag or diag_ws or diag_pay:
        try:
            keep = ('saleLineID', 'saleID', 'itemID', 'unitQuantity', 'unitPrice', 'calcSubtotal', 'calcTotal',
                    'calcTax1', 'calcTax2', 'tax', 'taxClassID', 'description', 'lineType', 'type', 'Note', 'note')
            clean = lambda ln: {k: v for k, v in ln.items() if k in keep or 'fee' in k.lower() or k == 'Item'}
            FEE_DIAG_PATH.write_text(json.dumps({'genere_le': now, 'periode': [d0.isoformat(), d1.isoformat()],
                                                 'lignes_frais_ou_divers': [clean(x) for x in diag],
                                                 'lignes_atelier_hubtiger': [clean(x) for x in diag_ws],
                                                 'paiements': diag_pay,
                                                 'exemples_articles': [clean(x) for x in diag_items]},
                                                ensure_ascii=False, indent=2, default=str), encoding='utf-8')
        except Exception:
            traceback.print_exc()


def _chunks(days):
    """Regroupe des jours en plages consécutives d'au plus STORE_CHUNK_DAYS jours."""
    out = []
    for d in sorted(days):
        if out and (d - out[-1][1]).days == 1 and (d - out[-1][0]).days < STORE_CHUNK_DAYS:
            out[-1][1] = d
        else:
            out.append([d, d])
    return out


def store_sync_days(days, st, kind):
    """Récupère les jours demandés (plages de 7 jours). Retourne le nombre de jours."""
    cfg = ls_config()
    account_id = cfg['account_id']
    if not account_id:
        account_id, name = ls_fetch_account()
        meta_set('ls_account_id', account_id)
        meta_set('ls_account_name', name)
    _store_refresh_refs(account_id, st)
    chunks = _chunks(days)
    st.update(total_days=len(days), done_days=0, kind=kind)
    for a, b in chunks:
        _store_fetch_range(account_id, a, b, st)
        st['done_days'] += (b - a).days + 1
        st['progress'] = f"{st['done_days']} jour(s) sur {st['total_days']} récupéré(s)…"
    return len(days)


def start_store_job(kind, days, username, then=None):
    """Lance une récupération en arrière-plan (historique ou période précise)."""
    if not _store_lock.acquire(blocking=False):
        raise LightspeedError("Une récupération des ventes est déjà en cours.")
    st = _store_state
    st.update(running=True, progress="Connexion à Lightspeed…", error=None, kind=kind, done_days=0, total_days=len(days))

    def _run():
        try:
            n = store_sync_days(days, st, kind)
            db_add_audit(username or '?', 'Ventes Lightspeed récupérées', f"{kind} : {n} jour(s)")
            if then:
                then()
        except Exception as e:
            if not isinstance(e, LightspeedError):
                traceback.print_exc()
            st['error'] = str(e) if isinstance(e, LightspeedError) else f"Erreur inattendue : {e}"
        finally:
            st['running'] = False
            st['progress'] = ''
            _store_lock.release()

    threading.Thread(target=_run, daemon=True).start()


TAX_EPS = 0.00005


TAX_DEFAULT_NAMES = {1: 'TPS', 2: 'TVQ'}   # quand le nom est vide dans Lightspeed


def _ls_taxcat_classes(t):
    """Taux propres à chaque classe d'article dans une catégorie de taxes
    (ex. au Québec, un article « Shopify 13 » taxé à 13 %). Liste de
    (taxClassID, taux1, taux2)."""
    rel = t.get('TaxCategoryClasses') or {}
    out = []
    for c in _ls_as_list(rel.get('TaxCategoryClass') if isinstance(rel, dict) else rel):
        cid = str(c.get('taxClassID') or '').strip()
        if cid:
            out.append((cid, _parse_money(c.get('tax1Rate')), _parse_money(c.get('tax2Rate'))))
    return out


FEE_DIAG_PATH = BASE_DIR / "diagnostic_frais_lightspeed.json"


HT_JOB_RE = re.compile(r'HT\s*:\s*#?\s*0*(\d{1,9})', re.I)


SERVICE_MIN_RE = re.compile(r'\bService\s+(\d{1,4})\s*min', re.I)


def _ls_line_text(ln):
    """Texte affiché d'une ligne de vente : description de l'article + note de la ligne."""
    parts = []
    item = ln.get('Item') if isinstance(ln.get('Item'), dict) else {}
    for v in (item.get('description'), ln.get('description'), ln.get('note')):
        if isinstance(v, str) and v.strip():
            parts.append(v.strip())
    note = ln.get('Note')
    if isinstance(note, dict) and isinstance(note.get('note'), str) and note['note'].strip():
        parts.append(note['note'].strip())
    return ' '.join(parts)


def _ls_workshop_info(ln, qty):
    """(texte, numéro de bon HubTiger, minutes de service facturées) d'une ligne."""
    text = _ls_line_text(ln)
    m = HT_JOB_RE.search(text)
    job = m.group(1) if m else None
    item = ln.get('Item') if isinstance(ln.get('Item'), dict) else {}
    sm = SERVICE_MIN_RE.search(str(item.get('description') or '')) or SERVICE_MIN_RE.search(text)
    minutes = float(sm.group(1)) * qty if sm else None
    return text, job, minutes


def _ls_fee_info(ln):
    """Frais d'article (consigne, écofrais…) ajouté automatiquement par
    Lightspeed ? Retourne (est_un_frais, nom). La forme exacte dans l'API n'est
    pas documentée : on accepte tous les indices raisonnables."""
    fee_obj = None
    is_fee = False
    for k, v in ln.items():
        kl = k.lower()
        if 'fee' not in kl:
            continue
        if isinstance(v, dict) and v:
            is_fee, fee_obj = True, v
        elif isinstance(v, list) and v:
            is_fee, fee_obj = True, (v[0] if isinstance(v[0], dict) else None)
        elif isinstance(v, str) and v.strip() and v.strip().lower() not in ('0', 'false', 'no', 'non'):
            is_fee = True
        elif isinstance(v, (int, float)) and not isinstance(v, bool) and v:
            is_fee = True
        elif v is True:
            is_fee = True
    for k in ('lineType', 'type', 'saleLineType'):
        if str(ln.get(k) or '').strip().lower() in ('fee', 'itemfee', 'item_fee', 'frais'):
            is_fee = True
    if not is_fee:
        return False, None
    name = None
    if isinstance(fee_obj, dict):
        name = fee_obj.get('name') or fee_obj.get('feeName') or fee_obj.get('description')
    note = ln.get('Note') if isinstance(ln.get('Note'), dict) else {}
    name = name or ln.get('description') or ln.get('feeName') or note.get('note') or (ln.get('Item') or {}).get('description')
    return True, (str(name).strip() if name else "Frais")


CARD_BRANDS = (('visa', 'Visa'), ('master', 'Mastercard'), ('mc', 'Mastercard'), ('amex', 'American Express'),
               ('american express', 'American Express'), ('discover', 'Discover'), ('jcb', 'JCB'), ('diners', 'Diners Club'),
               ('unionpay', 'UnionPay'), ('interac', 'Interac (débit)'))


PAY_TYPE_FR = {'cash': 'Comptant', 'check': 'Chèque', 'cheque': 'Chèque', 'debit card': 'Interac (débit)', 'debit': 'Interac (débit)',
               'credit account': 'Compte à recevoir', 'gift card': 'Carte-cadeau', 'gift': 'Carte-cadeau',
               'credit card': 'Carte de crédit (marque inconnue)', 'ecom': 'Paiement en ligne', 'layaway': 'Mise de côté'}


def _ls_card_brand(p_):
    """Marque de la carte d'un paiement : champs du détail de transaction (CCCharge),
    sinon premier chiffre d'un numéro masqué (4 = Visa, 5/2 = Mastercard, 3 = Amex)."""
    cc = p_.get('CCCharge') if isinstance(p_.get('CCCharge'), dict) else {}
    texts = []
    for src in (cc, p_):
        for k in ('cardType', 'cardBrand', 'brand', 'ccType', 'cardName', 'type', 'cardTypeName', 'paymentMethod'):
            v = src.get(k)
            if isinstance(v, str) and v.strip():
                texts.append(v.strip().lower())
    for t in texts:
        for key, label in CARD_BRANDS:
            if t == key or key in t.replace('-', ' ') and (len(key) > 2 or t.startswith(key)):
                return label
    for k in ('xnum', 'cardNumber', 'maskedNumber', 'ccNumber'):
        v = str(cc.get(k) or p_.get(k) or '').strip()
        if v[:1].isdigit():
            return {'4': 'Visa', '5': 'Mastercard', '2': 'Mastercard', '3': 'American Express', '6': 'Discover'}.get(v[0])
    return None


def _ls_payment_mode(p_):
    """Mode de paiement réel (en français) d'un paiement de vente Lightspeed."""
    pt = p_.get('PaymentType') if isinstance(p_.get('PaymentType'), dict) else {}
    name, ptype = (pt.get('name') or '').strip(), (pt.get('type') or '').strip().lower()
    if _ls_is_account_payment(p_):
        return 'Compte à recevoir'
    low = name.lower()
    for key, label in CARD_BRANDS:                       # mode déjà nommé « Visa », « MasterCard »…
        if key in low and len(key) > 2:
            return label
    if ptype == 'credit card' or low in ('credit card', 'carte de crédit', 'carte de credit', 'credit'):
        return _ls_card_brand(p_) or 'Carte de crédit (marque inconnue)'
    if low in PAY_TYPE_FR:
        return PAY_TYPE_FR[low]
    if name:
        return name
    return PAY_TYPE_FR.get(ptype, '(Autre)')


def _ls_sale_tax_total(s, idx):
    """Taxe totale d'une vente telle qu'arrondie par Lightspeed (None si absente)."""
    for k in (f'calcTax{idx}', f'tax{idx}', f'taxTotal{idx}'):
        v = s.get(k)
        if v not in (None, ''):
            try:
                return float(v)
            except (TypeError, ValueError):
                pass
    return None


def _ls_reconcile(values, weights, target):
    """Ajuste des montants de lignes pour que leur somme égale le total de la
    vente (arrondi par Lightspeed). Petite différence d'arrondi : sur la plus
    grosse ligne ; sinon répartie au prorata."""
    diff = round(target - sum(values), 4)
    if abs(diff) < 0.00005 or not values:
        return values
    base = [abs(v) for v in values] if any(abs(v) > 0.00005 for v in values) else [abs(w) for w in weights]
    if not any(base):
        return values
    out = list(values)
    if abs(diff) < 0.5:
        k = max(range(len(base)), key=lambda i: base[i])
        out[k] = round(out[k] + diff, 4)
        return out
    tot = sum(base)
    for i, b in enumerate(base):
        out[i] = round(out[i] + diff * b / tot, 4)
    return out


def _ls_taxcat_row(t):
    """Catégorie de taxes Lightspeed -> (id, nom, taxe1, taxe2, taux1, taux2). Le nom
    peut être dans différents champs selon le compte ; sinon on le construit à
    partir des taxes (jamais un simple numéro)."""
    tid = str(t.get('taxCategoryID') or '').strip()
    n1, n2 = (t.get('tax1Name') or '').strip(), (t.get('tax2Name') or '').strip()
    r1, r2 = _parse_money(t.get('tax1Rate')), _parse_money(t.get('tax2Rate'))
    name = ''
    for k in ('taxCategoryName', 'taxName', 'name', 'description', 'title'):
        v = t.get(k)
        if isinstance(v, str) and v.strip():
            name = v.strip()
            break
    if not name:
        parts = [f"{n or TAX_DEFAULT_NAMES[i]} {f'{_tax_pct(r):g}'.replace('.', ',')} %"
                 for i, (n, r) in enumerate(((n1, r1), (n2, r2)), start=1) if abs(r) > TAX_EPS]
        name = " + ".join(parts) if parts else "Aucune taxe"
    return tid, name, n1, n2, r1, r2


def _tax_pct(r):
    """Taux en pourcentage (Lightspeed : 0.05 ou 5 selon les champs)."""
    r = float(r or 0)
    return round(r * 100, 4) if abs(r) <= 1 else round(r, 4)


def _parse_money(v):
    """Convertit une valeur monétaire venant d'un fichier importé (nombre,
    ou texte du genre "$150000.00", "$-219.30", "1 234,56$", "") en float.
    Tolère le symbole $ avant ou après le signe négatif, les espaces et les
    séparateurs de milliers (virgule ou espace)."""
    if v is None:
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    if not s:
        return 0.0
    neg = '-' in s
    s = s.replace('$', '').replace('-', '').replace(' ', '').replace('\xa0', '').replace('\u202f', '')
    if ',' in s and '.' not in s and re.search(r',\d{1,2}$', s):
        # Format français : la virgule est le séparateur décimal (« 1 234,56 $ »).
        s = s.replace(',', '.')
    else:
        s = s.replace(',', '')
    if not s:
        return 0.0
    try:
        val = float(s)
    except ValueError:
        return 0.0
    return -val if neg else val
