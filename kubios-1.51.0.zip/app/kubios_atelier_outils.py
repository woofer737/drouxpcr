# -*- coding: utf-8 -*-
"""Outils de l'atelier partagés : mécaniciens, bons, facturation, rentabilité, périodes.
Module de Kubios (découpé de app.py en 1.47.0, code inchangé)."""
import os
import re
import io
import csv
import sys
import json
import base64
import hashlib
import unicodedata
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import openpyxl
from openpyxl.utils import get_column_letter
import licensing
from kubios_base import AT_FMT, get_conn, meta_get

__all__ = ['_at_clipped', '_at_dt', '_at_job_status', '_at_period', 'at_billing', 'at_default_rate', 'at_job_infos', 'at_mechanics', 'at_profit', 'at_unmatched', 'store_missing_days']


def store_missing_days(d0, d1, need_tax=False, need_ws=False, need_pay=False):
    """Jours de la période absents de la base locale (ou incomplets : aujourd'hui).
    need_tax : exige aussi les montants de taxes (jours récupérés avant 1.17.0)."""
    conn = get_conn()
    have = {r['day'] for r in conn.execute("SELECT day FROM sales_days WHERE complete=1 AND day BETWEEN ? AND ?"
                                           + (" AND tax_ok>=3" if need_tax else "") + (" AND ws_ok=1" if need_ws else "")
                                           + (" AND pay_ok>=2" if need_pay else ""),
                                           (d0.isoformat(), d1.isoformat())).fetchall()}
    conn.close()
    out, d = [], d0
    while d <= d1:
        if d.isoformat() not in have:
            out.append(d)
        d += datetime.timedelta(days=1)
    return out


def _at_dt(s):
    return datetime.datetime.strptime(s, AT_FMT)


def at_default_rate():
    try:
        return float(meta_get('atelier_cost_rate') or 30)
    except ValueError:
        return 30.0


def at_mechanics(include_inactive=False):
    conn = get_conn()
    rows = [dict(r) for r in conn.execute("SELECT * FROM shop_mechanics" + ("" if include_inactive else " WHERE active=1")
                                          + " ORDER BY name COLLATE NOCASE").fetchall()]
    conn.close()
    return rows


def _at_period(args):
    today = datetime.date.today()
    p = args.get('periode', 'jour')
    if args.get('start') and args.get('end'):
        d0, d1 = datetime.date.fromisoformat(args['start']), datetime.date.fromisoformat(args['end'])
    elif p == 'semaine':
        d0, d1 = today - datetime.timedelta(days=today.weekday()), today
    elif p == 'mois':
        d0, d1 = today.replace(day=1), today
    elif p == 'mois_dernier':
        last = today.replace(day=1) - datetime.timedelta(days=1); d0, d1 = last.replace(day=1), last
    elif p == 'trimestre':
        d0, d1 = datetime.date(today.year, (today.month - 1) // 3 * 3 + 1, 1), today
    elif p == 'annee':
        d0, d1 = datetime.date(today.year, 1, 1), today
    else:
        d0, d1 = today, today
    if d1 < d0:
        d0, d1 = d1, d0
    return d0, d1


def _at_clipped(conn, d0, d1):
    """Punchs de la période, ramenés aux bornes de la période (secondes)."""
    a, b = datetime.datetime.combine(d0, datetime.time.min), datetime.datetime.combine(d1 + datetime.timedelta(days=1), datetime.time.min)
    now = datetime.datetime.now()
    out = []
    for r in conn.execute("SELECT p.*, m.name, m.cost_rate FROM shop_punches p JOIN shop_mechanics m ON m.id=p.mechanic_id "
                          "WHERE p.start_at < ? AND (p.end_at IS NULL OR p.end_at > ?)", (b.strftime(AT_FMT), a.strftime(AT_FMT))).fetchall():
        s, e = max(_at_dt(r['start_at']), a), min(_at_dt(r['end_at']) if r['end_at'] else now, b)
        if e > s:
            d = dict(r); d['s'], d['e'] = s, e; d['sec'] = (e - s).total_seconds(); out.append(d)
    return out


def _at_job_status(conn, job):
    if conn.execute("SELECT 1 FROM shop_punches WHERE job=? AND end_at IS NULL", (job,)).fetchone():
        return 'En cours'
    last = conn.execute("SELECT ended_by FROM shop_punches WHERE job=? ORDER BY end_at DESC, id DESC LIMIT 1", (job,)).fetchone()
    return 'Terminé' if last and last['ended_by'] == 'fin' else 'En pause'


def at_billing(conn, job):
    """Facturé pour un bon : saisie manuelle si présente, sinon lignes Lightspeed « HT: #bon »."""
    o = conn.execute("SELECT * FROM shop_billing WHERE job=?", (job,)).fetchone()
    r = conn.execute("SELECT COALESCE(SUM(svc_minutes),0) mn, COALESCE(SUM(CASE WHEN svc_minutes>0 THEN total ELSE 0 END),0) amt, "
                     "COALESCE(SUM(CASE WHEN COALESCE(svc_minutes,0)=0 THEN total ELSE 0 END),0) parts, "
                     "GROUP_CONCAT(DISTINCT sale_id) sales FROM sales_lines l LEFT JOIN shop_sale_links k ON k.sale_line_id=l.sale_line_id "
                     "WHERE COALESCE(k.ignored,0)=0 AND COALESCE(k.job, l.job_ref)=?", (job,)).fetchone()
    sales = [x for x in (r['sales'] or '').split(',') if x]
    if o:
        return {'minutes': o['billed_minutes'], 'amount': o['billed_amount'], 'parts': round(r['parts'], 2), 'sales': sales,
                'source': 'manuel', 'note': o['note']}
    if not sales:
        return {'minutes': None, 'amount': None, 'parts': 0.0, 'sales': [], 'source': None}
    return {'minutes': round(r['mn'], 1), 'amount': round(r['amt'], 2), 'parts': round(r['parts'], 2), 'sales': sales, 'source': 'lightspeed'}


def at_unmatched(d0, d1):
    """Services facturés (« Service N mins ») de la période qu'on ne peut pas relier à un bon punché :
    sans numéro « HT: # », ou avec un numéro sur lequel personne n'a punché."""
    conn = get_conn()
    try:
        punched = {r['job'] for r in conn.execute("SELECT DISTINCT job FROM shop_punches").fetchall()}
        rows = conn.execute(
            "SELECT l.sale_line_id, l.sale_id, l.sale_date, l.descr, l.svc_minutes, l.total, l.job_ref, k.job link_job, COALESCE(k.ignored,0) ignored "
            "FROM sales_lines l LEFT JOIN shop_sale_links k ON k.sale_line_id=l.sale_line_id "
            "WHERE l.sale_date BETWEEN ? AND ? AND COALESCE(l.svc_minutes,0) > 0 ORDER BY l.sale_date DESC, l.sale_id",
            (d0.isoformat(), d1.isoformat())).fetchall()
        out, ignored = [], 0
        # 1.40.1 : bons déjà associés à une vente (pour ne pas les proposer deux fois)
        used = {r[0] for r in conn.execute("SELECT job_ref FROM sales_lines WHERE job_ref IS NOT NULL AND job_ref<>'' "
                                            "UNION SELECT job FROM shop_sale_links WHERE job IS NOT NULL AND job<>''").fetchall()}
        jobinfo = lambda j: conn.execute("SELECT job, client, item, work, due_date, status FROM shop_jobs WHERE job=?", (j,)).fetchone()
        for r in rows:
            job = r['link_job'] or r['job_ref']
            if r['ignored']:
                ignored += 1
                continue
            if job and job in punched:
                continue
            row = {'line': r['sale_line_id'], 'sale': r['sale_id'], 'date': r['sale_date'], 'descr': r['descr'] or '',
                   'minutes': r['svc_minutes'], 'amount': round(r['total'] or 0, 2), 'job': job or '',
                   'reason': 'sans_bon' if not job else 'sans_punch', 'job_info': None, 'suggest': []}
            if job:
                ji = jobinfo(job)
                row['job_info'] = {'client': ji['client'], 'item': ji['item']} if ji else None
            elif len(out) < 300:
                # bons probables : même durée de service, date prévue proche, pas encore associés à une vente
                sd = datetime.date.fromisoformat(r['sale_date'][:10])
                cand = conn.execute(
                    "SELECT job, client, item, due_date, created_at FROM shop_jobs WHERE work LIKE ? AND status<>'annule' "
                    "AND COALESCE(due_date, substr(created_at,1,10)) BETWEEN ? AND ?",
                    (f"%Service {int(r['svc_minutes'])} mins%", (sd - datetime.timedelta(days=21)).isoformat(), (sd + datetime.timedelta(days=3)).isoformat())).fetchall()
                cand = [c for c in cand if c['job'] not in used]
                cand.sort(key=lambda c: (c['job'] not in punched, abs((datetime.date.fromisoformat((c['due_date'] or c['created_at'])[:10]) - sd).days)))
                row['suggest'] = [{'job': c['job'], 'client': c['client'] or '', 'item': c['item'] or '', 'due': c['due_date'] or '',
                                   'punched': c['job'] in punched} for c in cand[:3]]
            out.append(row)
        return {'rows': out[:300], 'count': len(out), 'ignored': ignored}
    finally:
        conn.close()


def at_profit(args):
    d0, d1 = _at_period(args)
    conn = get_conn()
    try:
        dflt = at_default_rate()
        pun = _at_clipped(conn, d0, d1)
        jobs, mech = {}, {}
        for p in pun:
            rate = p['cost_rate'] if p['cost_rate'] is not None else dflt
            j = jobs.setdefault(p['job'], {'job': p['job'], 'sec': 0.0, 'cost': 0.0, 'by': {}})
            j['sec'] += p['sec']; j['cost'] += p['sec'] / 3600 * rate
            j['by'][p['mechanic_id']] = j['by'].get(p['mechanic_id'], 0) + p['sec']
            mm = mech.setdefault(p['mechanic_id'], {'name': p['name'], 'rate': rate, 'iv': [], 'bmin': 0.0, 'bamt': 0.0, 'bsec': 0.0, 'jobs': []})
            mm['iv'].append((p['s'], p['e']))
        out_jobs = []
        T = {'billed': 0.0, 'cost': 0.0, 'billed_min': 0.0, 'punched_billed_sec': 0.0, 'unbilled': 0, 'cost_all': 0.0}
        for j in jobs.values():
            b = at_billing(conn, j['job'])
            names = ', '.join(sorted({mech[k]['name'] for k in j['by']}))
            info = at_job_infos(conn, [j['job']]).get(j['job'], {})
            row = {'job': j['job'], 'client': info.get('client', ''), 'item': info.get('item', ''),
                   'mechs': names, 'seconds': j['sec'], 'cost': round(j['cost'], 2), 'status': _at_job_status(conn, j['job']),
                   'billed_minutes': b['minutes'], 'billed': b['amount'], 'parts': b['parts'], 'source': b['source'], 'sales': b['sales']}
            T['cost_all'] += j['cost']
            for k, sec in j['by'].items():              # fiche de chaque mécanicien : sa part de chaque bon
                share = sec / j['sec'] if j['sec'] else 0
                bm = (b['minutes'] or 0) * share if b['amount'] is not None else None
                ba = b['amount'] * share if b['amount'] is not None else None
                cost_k = sec / 3600 * mech[k]['rate']
                mech[k]['jobs'].append({'job': j['job'], 'client': info.get('client', ''), 'item': info.get('item', ''), 'status': row['status'],
                                        'seconds': sec, 'shared': len(j['by']) > 1, 'billed_minutes': None if bm is None else round(bm, 1),
                                        'billed': None if ba is None else round(ba, 2), 'cost': round(cost_k, 2),
                                        'gap_minutes': None if bm is None else round(sec / 60 - bm, 1),
                                        'margin': None if ba is None else round(ba - cost_k, 2),
                                        'job_loss': b['amount'] is not None and b['amount'] - j['cost'] < 0})
            if b['amount'] is not None:
                row['margin'] = round(b['amount'] - j['cost'], 2)
                row['gap_minutes'] = round(j['sec'] / 60 - (b['minutes'] or 0), 1)
                T['billed'] += b['amount']; T['cost'] += j['cost']; T['billed_min'] += b['minutes'] or 0; T['punched_billed_sec'] += j['sec']
                for k, sec in j['by'].items():          # partage du facturé selon le temps de chacun
                    share = sec / j['sec'] if j['sec'] else 0
                    mech[k]['bmin'] += (b['minutes'] or 0) * share; mech[k]['bamt'] += b['amount'] * share; mech[k]['bsec'] += sec
            else:
                T['unbilled'] += 1
            out_jobs.append(row)
        out_jobs.sort(key=lambda r: (r.get('margin') is None, r.get('margin') or 0))
        out_mech = []
        for k, mm in mech.items():
            iv = sorted(mm['iv']); tot = 0.0; cs, ce = None, None
            for s_, e_ in iv:                       # temps réel (deux bons en même temps comptés une fois)
                if cs is None or s_ > ce:
                    if cs is not None: tot += (ce - cs).total_seconds()
                    cs, ce = s_, e_
                else:
                    ce = max(ce, e_)
            if cs is not None: tot += (ce - cs).total_seconds()
            js = mm['jobs']
            billed_js = [x for x in js if x['billed'] is not None]
            cost = round(tot / 3600 * mm['rate'], 2)
            a0, a1 = d0.strftime('%Y-%m-%d 00:00:00'), (d1 + datetime.timedelta(days=1)).strftime('%Y-%m-%d 00:00:00')
            problems = conn.execute("SELECT COUNT(*) FROM shop_messages WHERE mechanic_id=? AND kind='probleme' AND created_at>=? AND created_at<?", (k, a0, a1)).fetchone()[0]
            corrections = conn.execute("SELECT COUNT(*) FROM shop_punches WHERE mechanic_id=? AND corrected_by IS NOT NULL AND start_at>=? AND start_at<?", (k, a0, a1)).fetchone()[0]
            lost_sec = max(0.0, mm['bsec'] - mm['bmin'] * 60)
            out_mech.append({'id': k, 'name': mm['name'], 'seconds': tot, 'rate': mm['rate'], 'cost': cost,
                             'billed_minutes': round(mm['bmin'], 1), 'billed': round(mm['bamt'], 2), 'billed_job_seconds': mm['bsec'],
                             'yield': round(mm['bmin'] / (mm['bsec'] / 60) * 100) if mm['bsec'] >= 60 else None,
                             'margin': round(mm['bamt'] - mm['bsec'] / 3600 * mm['rate'], 2),
                             'margin_pct': round((mm['bamt'] - mm['bsec'] / 3600 * mm['rate']) / mm['bamt'] * 100, 1) if mm['bamt'] >= 1 else None,
                             'real_rate': round(mm['bamt'] / (mm['bsec'] / 3600), 2) if mm['bsec'] >= 60 else None,
                             'jobs_count': len(js), 'done_count': sum(1 for x in js if x['status'] == 'Terminé'),
                             'billed_count': len(billed_js), 'unbilled_count': len(js) - len(billed_js),
                             'over_count': sum(1 for x in billed_js if x['gap_minutes'] > 15), 'loss_count': sum(1 for x in billed_js if x['job_loss']),
                             'avg_job_seconds': tot / len(js) if js else 0, 'problems': problems, 'corrections': corrections,
                             'lost_seconds': lost_sec, 'lost_cost': round(lost_sec / 3600 * mm['rate'], 2),
                             'jobs': sorted(js, key=lambda x: -(x['gap_minutes'] if x['gap_minutes'] is not None else -1e9))})
        out_mech.sort(key=lambda r: r['name'])
        return {'start': d0.isoformat(), 'end': d1.isoformat(), 'jobs': out_jobs, 'mechanics': out_mech,
                'totals': {'billed': round(T['billed'], 2), 'cost': round(T['cost'], 2), 'margin': round(T['billed'] - T['cost'], 2),
                           'billed_minutes': round(T['billed_min'], 1), 'punched_billed_seconds': T['punched_billed_sec'],
                           'yield': round(T['billed_min'] / (T['punched_billed_sec'] / 60) * 100) if T['punched_billed_sec'] >= 60 else None,
                           'effective_rate': round(T['billed'] / (T['punched_billed_sec'] / 3600), 2) if T['punched_billed_sec'] >= 60 else None,
                           'unbilled_jobs': T['unbilled'], 'cost_all': round(T['cost_all'], 2),
                           'lost_seconds': max(0.0, T['punched_billed_sec'] - T['billed_min'] * 60),
                           'lost_cost': round(sum(m['lost_cost'] for m in out_mech), 2),
                           'unbilled_seconds': sum(r['seconds'] for r in out_jobs if r['billed'] is None),
                           'unbilled_cost': round(sum(r['cost'] for r in out_jobs if r['billed'] is None), 2),
                           'punched_seconds': sum(m['seconds'] for m in out_mech)},
                'default_rate': dflt, 'missing_days': len([d for d in store_missing_days(d0, d1, need_ws=True) if d < datetime.date.today()]),
                'unmatched': at_unmatched(d0, d1)}
    finally:
        conn.close()


def at_job_infos(conn, jobs):
    """Client / appareil / travaux des bons connus dans Kubios."""
    jobs = [j for j in set(jobs) if j]
    if not jobs:
        return {}
    q = "SELECT j.*, m.name mech_name FROM shop_jobs j LEFT JOIN shop_mechanics m ON m.id=j.mechanic_id WHERE j.job IN (%s)" % ','.join('?' * len(jobs))
    return {r['job']: {'client': r['client'] or '', 'item': r['item'] or '', 'work': r['work'] or '', 'due': r['due_date'] or '',
                       'status': r['status'], 'mechanic': r['mech_name'] or '', 'mechanic_id': r['mechanic_id'],
                       'priority': r['priority'] or 'normal', 'notes': r['notes'] or '', 'position': r['position'] or 0,
                       'work_date': r['work_date'] or ''}
            for r in conn.execute(q, jobs).fetchall()}
