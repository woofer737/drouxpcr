# -*- coding: utf-8 -*-
"""Pages du temps : punch des employés, feuilles de temps, horaires, congés.
Module de Kubios (découpé de app.py en 1.47.0, code inchangé)."""
import os
import re
import io
import csv
import sys
import json
import base64
import hashlib
import unicodedata
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import openpyxl
from openpyxl.utils import get_column_letter
import licensing
from kubios_base import AT_FMT, _at_now, client_ip, db_add_audit, get_company_name, get_conn, meta_get, meta_set
from kubios_mail import send_email
from kubios_app import app
from kubios_auth import admin_required_check, current_display_name, log_audit, permission_required_check
from kubios_rh_outils import (
    LEAVE_KINDS, LEAVE_STATUS, PDF_DIR, TC_KINDS, _d, _esc, _hm_min, _leave_html_card,
    _leave_summary_rows, _sched_period, _sched_same, _tc_fail, _tc_period_from_args, _tc_rows,
    export_sched_emp_pdf, export_sched_pdf, export_tc_pdf, export_tc_xlsx, leave_apply_schedule,
    leave_approver_config, leave_approvers, leaves_in_range, sched_cells, sched_day_fr,
    sched_email_html, sched_employees, sched_label, sched_settings, tc_allowed, tc_authorize, tc_days,
    tc_events, tc_link_token, tc_settings, tc_state,
)

__all__ = ['api_leave_approvers', 'api_leave_decide', 'api_leaves', 'api_sched', 'api_sched_cells', 'api_sched_copy', 'api_sched_pdf', 'api_sched_publish', 'api_sched_settings', 'api_tc_approve', 'api_tc_day', 'api_tc_event', 'api_tc_export', 'api_tc_punch', 'api_tc_settings', 'api_tc_sheet', 'api_tc_station', 'leave_page', 'sched_page', 'tc_sheets_page', 'tc_station_page']


@app.route('/punch-employes', methods=['GET', 'POST'])
def tc_station_page():
    if request.method == 'POST':                       # code d'accès du poste
        h = meta_get('tc_code_hash')
        if h and check_password_hash(h, (request.form.get('code') or '').strip()):
            db_add_audit('Poste de punch des employés', 'Poste autorisé (code)', client_ip())
            return tc_authorize(redirect(url_for('tc_station_page')))
        return render_template('tc_station.html', company=get_company_name(), mode='code',
                               error="Code d'accès incorrect." if h else "Aucun code d'accès n'est défini : un administrateur doit le créer dans Administration RH.")
    tok = request.args.get('cle')
    if tok and secrets.compare_digest(tok, tc_link_token()):
        db_add_audit('Poste de punch des employés', 'Poste autorisé (lien direct)', client_ip())
        return tc_authorize(redirect(url_for('tc_station_page')))
    if not tc_allowed():
        return render_template('tc_station.html', company=get_company_name(), mode='code', error=None)
    return render_template('tc_station.html', company=get_company_name(), mode='station', error=None)


@app.route('/api/tc/station')
def api_tc_station():
    if not tc_allowed():
        return jsonify({'error': 'Poste non autorisé.'}), 401
    conn = get_conn()
    try:
        out = []
        for e in conn.execute("SELECT id, first_name, last_name, position FROM hr_employees WHERE tc_enabled=1 AND status<>'inactif' "
                              "ORDER BY first_name COLLATE NOCASE, last_name COLLATE NOCASE").fetchall():
            st = tc_state(conn, e['id'])
            out.append({'id': e['id'], 'name': f"{e['first_name']} {e['last_name']}", 'position': e['position'] or '',
                        'state': st['state'], 'since': st['since'], 'first_in': st['first_in'], 'last_out': st['last_out']})
        return jsonify({'employees': out, 'now': datetime.datetime.now().strftime(AT_FMT)})
    finally:
        conn.close()


@app.route('/api/tc/punch', methods=['POST'])
def api_tc_punch():
    if not tc_allowed():
        return jsonify({'ok': False, 'error': 'Poste non autorisé.'}), 401
    d = request.get_json(silent=True) or {}
    try:
        eid = int(d.get('employee_id'))
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Employé inconnu.'}), 400
    f = _tc_fail.get(eid, {'n': 0, 'until': 0})
    if f['until'] > time.time():
        return jsonify({'ok': False, 'error': f"Trop d'essais. Réessaie dans {int((f['until'] - time.time()) // 60) + 1} minute(s).", 'pin': True}), 429
    conn = get_conn()
    try:
        e = conn.execute("SELECT * FROM hr_employees WHERE id=? AND tc_enabled=1 AND status<>'inactif'", (eid,)).fetchone()
        if not e or not e['tc_pin_hash']:
            return jsonify({'ok': False, 'error': "Cet employé n'a pas de NIP de punch : demande à ton gestionnaire."}), 400
        if not check_password_hash(e['tc_pin_hash'], str(d.get('pin') or '')):
            f['n'] += 1
            if f['n'] >= 5:
                f = {'n': 0, 'until': time.time() + 300}
            _tc_fail[eid] = f
            return jsonify({'ok': False, 'error': 'NIP incorrect.', 'pin': True}), 403
        _tc_fail.pop(eid, None)
        act = d.get('action')
        st = tc_state(conn, eid)
        allowed = {'out': ('in',), 'done': ('in',), 'in': ('break_start', 'out'), 'break': ('break_end', 'out')}[st['state']]
        if act != 'login':
            if act not in allowed:
                return jsonify({'ok': False, 'error': 'Ce punch ne correspond pas à ton état actuel.'}), 400
            if act == 'out' and st['state'] == 'break':
                conn.execute("INSERT INTO tc_events(employee_id, ts, kind, station, created_by) VALUES (?,?,?,?,?)",
                             (eid, _at_now(), 'break_end', client_ip(), 'poste'))
            conn.execute("INSERT INTO tc_events(employee_id, ts, kind, station, created_by) VALUES (?,?,?,?,?)", (eid, _at_now(), act, client_ip(), 'poste'))
            conn.commit()
            st = tc_state(conn, eid)
        allowed = {'out': ['in'], 'done': ['in'], 'in': ['break_start', 'out'], 'break': ['break_end', 'out']}[st['state']]
        return jsonify({'ok': True, 'done': act != 'login', 'action': act, 'name': f"{e['first_name']} {e['last_name']}", 'first_name': e['first_name'],
                        'state': st, 'allowed': allowed, 'time': datetime.datetime.now().strftime('%H:%M')})
    finally:
        conn.close()


@app.route('/rh/feuilles-de-temps')
def tc_sheets_page():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    return render_template('tc_sheets.html', company=get_company_name(), is_admin=bool(session.get('is_admin')))


@app.route('/api/tc/sheet')
def api_tc_sheet():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    d0, d1 = _tc_period_from_args()
    conn = get_conn()
    try:
        rows = _tc_rows(conn, d0, d1)
    finally:
        conn.close()
    st = tc_settings()
    late_now = []
    today = datetime.date.today()
    if d0 <= today <= d1:
        now_hm = datetime.datetime.now().strftime('%H:%M'); grace = sched_settings()['grace']
        conn = get_conn()
        try:
            pub = sched_cells(conn, 'sched_published', today, today)
            for e in conn.execute("SELECT id, first_name, last_name FROM hr_employees WHERE tc_enabled=1 AND status<>'inactif'").fetchall():
                c = (pub.get(e['id']) or {}).get(today.isoformat())
                if not c or c['kind'] != 'work':
                    continue
                d = tc_days(tc_events(conn, e['id'], today, today), today, today)[0]
                if not d['first_in'] and _hm_min(now_hm) > _hm_min(c['start']) + grace and now_hm < c['end']:
                    late_now.append({'name': f"{e['first_name']} {e['last_name']}", 'kind': 'absent', 'start': c['start']})
                elif d['first_in'] and _hm_min(d['first_in']) - _hm_min(c['start']) > grace:
                    late_now.append({'name': f"{e['first_name']} {e['last_name']}", 'kind': 'late', 'start': c['start'],
                                     'minutes': _hm_min(d['first_in']) - _hm_min(c['start'])})
        finally:
            conn.close()
    return jsonify({'start': d0.isoformat(), 'end': d1.isoformat(), 'rows': rows, 'period': st['period'], 'late_now': late_now,
                    'prev': (d0 - datetime.timedelta(days=1)).isoformat(), 'next': (d1 + datetime.timedelta(days=1)).isoformat()})


@app.route('/api/tc/day')
def api_tc_day():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    try:
        eid, d = int(request.args.get('employee_id')), datetime.date.fromisoformat(request.args.get('date'))
    except (TypeError, ValueError):
        return jsonify({'error': 'Paramètres invalides.'}), 400
    conn = get_conn()
    try:
        ev = [x for x in tc_events(conn, eid, d, d) if x['ts'][:10] == d.isoformat() or True]
        day = tc_days(ev, d, d)[0]
        return jsonify({'events': [x for x in ev if x['ts'] >= (d - datetime.timedelta(hours=14)).isoformat()], 'day': day, 'kinds': TC_KINDS})
    finally:
        conn.close()


@app.route('/api/tc/events', methods=['POST'])
@app.route('/api/tc/events/<int:ev_id>', methods=['PUT', 'DELETE'])
def api_tc_event(ev_id=None):
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    note = str(d.get('note') or '').strip()[:200]
    conn = get_conn()
    try:
        if request.method == 'DELETE':
            ev = conn.execute("SELECT * FROM tc_events WHERE id=?", (ev_id,)).fetchone()
            if not ev:
                return jsonify({'ok': False, 'error': 'Punch introuvable.'}), 404
            conn.execute("UPDATE tc_events SET deleted=1, corrected_by=?, corrected_at=?, note=? WHERE id=?",
                         (current_display_name(), _at_now(), note or ev['note'], ev_id))
            conn.commit(); log_audit('RH : punch retiré', f"employé #{ev['employee_id']} — {ev['ts']} {TC_KINDS.get(ev['kind'])}")
            return jsonify({'ok': True})
        kind = d.get('kind')
        try:
            ts = datetime.datetime.strptime(str(d.get('ts') or ''), '%Y-%m-%dT%H:%M').strftime(AT_FMT)
        except ValueError:
            return jsonify({'ok': False, 'error': 'Date et heure invalides.'}), 400
        if kind not in TC_KINDS:
            return jsonify({'ok': False, 'error': 'Type de punch invalide.'}), 400
        if not note:
            return jsonify({'ok': False, 'error': 'Indique la raison de la correction (ex. oubli de punch).'}), 400
        if ev_id is None:
            eid = int(d.get('employee_id') or 0)
            conn.execute("INSERT INTO tc_events(employee_id, ts, kind, station, created_by, note, corrected_by, corrected_at) VALUES (?,?,?,?,?,?,?,?)",
                         (eid, ts, kind, 'correction', current_display_name(), note, current_display_name(), _at_now()))
            msg = f"employé #{eid} — ajout {ts} {TC_KINDS[kind]} — {note}"
        else:
            ev = conn.execute("SELECT * FROM tc_events WHERE id=?", (ev_id,)).fetchone()
            if not ev:
                return jsonify({'ok': False, 'error': 'Punch introuvable.'}), 404
            conn.execute("UPDATE tc_events SET ts=?, kind=?, note=?, corrected_by=?, corrected_at=? WHERE id=?",
                         (ts, kind, note, current_display_name(), _at_now(), ev_id))
            msg = f"employé #{ev['employee_id']} — {ev['ts']} → {ts} {TC_KINDS[kind]} — {note}"
        conn.commit()
    finally:
        conn.close()
    log_audit('RH : punch corrigé', msg)
    return jsonify({'ok': True})


@app.route('/api/tc/approve', methods=['POST'])
def api_tc_approve():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    try:
        d0 = datetime.date.fromisoformat(d.get('start'))
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Période invalide.'}), 400
    ids = [int(x) for x in d.get('employee_ids') or []]
    conn = get_conn()
    try:
        for i in ids:
            if d.get('undo'):
                conn.execute("DELETE FROM tc_approvals WHERE employee_id=? AND period_start=?", (i, d0.isoformat()))
            else:
                conn.execute("INSERT OR REPLACE INTO tc_approvals(employee_id, period_start, approved_by, approved_at) VALUES (?,?,?,?)",
                             (i, d0.isoformat(), current_display_name(), _at_now()))
        conn.commit()
    finally:
        conn.close()
    log_audit('RH : feuilles de temps ' + ('désapprouvées' if d.get('undo') else 'approuvées'), f"période du {d0} — {len(ids)} employé(s)")
    return jsonify({'ok': True})


@app.route('/api/tc/export')
def api_tc_export():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    d0, d1 = _tc_period_from_args()
    conn = get_conn()
    try:
        rows = [r for r in _tc_rows(conn, d0, d1, with_events=True) if r['sheet']['total'] or r['sheet']['missing'] or r['events']]
    finally:
        conn.close()
    out = PDF_DIR / "Feuilles_de_temps"; out.mkdir(parents=True, exist_ok=True)
    if request.args.get('fmt') == 'pdf':
        p = export_tc_pdf(rows, d0, d1, out / f"Feuille_de_temps_{d0}_au_{d1}.pdf")
        log_audit('RH : feuille de temps (PDF)', f"{d0} au {d1}")
        return send_file(str(p), mimetype='application/pdf', as_attachment=False, download_name=p.name)
    p = export_tc_xlsx(rows, d0, d1, out / f"Feuille_de_temps_{d0}_au_{d1}.xlsx")
    log_audit('RH : feuille de temps (Excel)', f"{d0} au {d1}")
    return send_file(str(p), as_attachment=True, download_name=p.name)


@app.route('/api/tc/settings', methods=['GET', 'POST'])
def api_tc_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if request.method == 'POST':
        d = request.get_json(silent=True) or {}
        if d.get('period') in ('week', '2weeks'):
            meta_set('tc_period', d['period'])
        if d.get('anchor'):
            try:
                meta_set('tc_anchor', datetime.date.fromisoformat(d['anchor']).isoformat())
            except ValueError:
                return jsonify({'ok': False, 'error': 'Date de début invalide.'}), 400
        if d.get('code') is not None:
            c = str(d['code']).strip()
            if len(c) < 6:
                return jsonify({'ok': False, 'error': "Le code d'accès doit avoir au moins 6 caractères."}), 400
            meta_set('tc_code_hash', generate_password_hash(c))
        if d.get('revoke'):
            meta_set('tc_secret', secrets.token_urlsafe(16)); meta_set('tc_link_token', secrets.token_urlsafe(24))
        log_audit('RH : réglages du punch modifiés', json.dumps({k: v for k, v in d.items() if k != 'code'}, ensure_ascii=False))
    st = tc_settings()
    return jsonify({'ok': True, 'period': st['period'], 'anchor': st['anchor'].isoformat(), 'has_code': bool(meta_get('tc_code_hash')),
                    'link': request.host_url.rstrip('/') + url_for('tc_station_page', cle=tc_link_token())})


@app.route('/rh/horaires')
def sched_page():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    return render_template('sched.html', company=get_company_name(), is_admin=bool(session.get('is_admin')))


@app.route('/api/sched')
def api_sched():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    d0, d1 = _sched_period()
    conn = get_conn()
    try:
        draft, pub = sched_cells(conn, 'sched_shifts', d0, d1), sched_cells(conn, 'sched_published', d0, d1)
        emps = sched_employees(conn)
        changed = 0
        for e in emps:
            for i in range((d1 - d0).days + 1):
                day = (d0 + datetime.timedelta(days=i)).isoformat()
                if not _sched_same((draft.get(e['id']) or {}).get(day), (pub.get(e['id']) or {}).get(day)):
                    changed += 1
    finally:
        conn.close()
    conn = get_conn()
    try:
        leaves = {str(k): v for k, v in leaves_in_range(conn, d0, d1).items()}
        pending = conn.execute("SELECT COUNT(*) FROM leave_requests WHERE status='en_attente'").fetchone()[0]
    finally:
        conn.close()
    return jsonify({'leaves': leaves, 'leaves_pending': pending, 'start': d0.isoformat(), 'end': d1.isoformat(), 'prev': (d0 - datetime.timedelta(days=1)).isoformat(),
                    'next': (d1 + datetime.timedelta(days=1)).isoformat(), 'employees': [{k: e[k] for k in ('id', 'first_name', 'last_name', 'department', 'position')} for e in emps],
                    'draft': draft, 'published': pub, 'changed': changed, 'last_publish': meta_get('sched_last_publish'), 'settings': sched_settings()})


@app.route('/api/sched/cells', methods=['POST'])
def api_sched_cells():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    cells = (request.get_json(silent=True) or {}).get('cells') or []
    skipped = 0
    conn = get_conn()
    try:
        for c in cells[:400]:
            eid, day = int(c.get('employee_id') or 0), str(c.get('day') or '')
            datetime.date.fromisoformat(day)
            kind = c.get('kind')
            if True:                                      # 1.44.0 : un congé approuvé verrouille la journée
                lv = leaves_in_range(conn, datetime.date.fromisoformat(day), datetime.date.fromisoformat(day), eid).get(eid, {}).get(day)
                if lv and len(cells) > 1:                 # remplissage de la semaine : on saute les congés
                    skipped += 1
                    continue
                if lv:
                    return jsonify({'ok': False, 'error': f"Cette journée est en {lv['label'].lower()} approuvé(e) du {_d(lv['start'])} au {_d(lv['end'])}. "
                                                          "Pour la modifier, annule d'abord le congé dans Gestion RH → Congés."}), 400
            if kind is None:
                conn.execute("DELETE FROM sched_shifts WHERE employee_id=? AND day=?", (eid, day)); continue
            if kind not in ('work', 'off'):
                return jsonify({'ok': False, 'error': 'Type de journée invalide.'}), 400
            start, end, meal = (c.get('start') or None), (c.get('end') or None), (c.get('meal') or None)
            if kind == 'work':
                if not (start and end and re.fullmatch(r'\d\d:\d\d', start) and re.fullmatch(r'\d\d:\d\d', end)) or _hm_min(end) <= _hm_min(start):
                    return jsonify({'ok': False, 'error': 'Heures de début et de fin invalides.'}), 400
                if meal and (not re.fullmatch(r'\d\d:\d\d', meal) or not (_hm_min(start) <= _hm_min(meal) <= _hm_min(end) - 60)):
                    return jsonify({'ok': False, 'error': 'Le repas doit être pendant le quart.'}), 400
            else:
                start = end = meal = None
            conn.execute("INSERT OR REPLACE INTO sched_shifts(employee_id, day, kind, start, end, meal, note, updated_at, updated_by) VALUES (?,?,?,?,?,?,?,?,?)",
                         (eid, day, kind, start, end, meal, str(c.get('note') or '').strip()[:120] or None, _at_now(), current_display_name()))
        conn.commit()
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Données invalides.'}), 400
    finally:
        conn.close()
    return jsonify({'ok': True, 'skipped': skipped})


@app.route('/api/sched/copy', methods=['POST'])
def api_sched_copy():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    d0, d1 = _sched_period()
    mode = request.values.get('mode') or 'prev'
    w2 = d0 + datetime.timedelta(days=7)
    if mode == 'p1_to_p2':        # même chose la 2e semaine
        p0, p1, t0, t1 = d0, d0 + datetime.timedelta(days=6), w2, d1
    elif mode == 'p2_to_p1':
        p0, p1, t0, t1 = w2, d1, d0, d0 + datetime.timedelta(days=6)
    else:                          # les 2 semaines précédentes
        p0, p1 = d0 - datetime.timedelta(days=14), d0 - datetime.timedelta(days=1)
        t0, t1 = d0, d1
    off = (t0 - p0).days
    conn = get_conn()
    try:
        src = [dict(r) for r in conn.execute("SELECT * FROM sched_shifts WHERE day BETWEEN ? AND ?", (p0.isoformat(), p1.isoformat())).fetchall()]
        if not src:
            return jsonify({'ok': False, 'error': "Il n'y a pas d'horaire à copier pour ces dates."}), 400
        conn.execute("DELETE FROM sched_shifts WHERE day BETWEEN ? AND ?", (t0.isoformat(), t1.isoformat()))
        for r in src:
            nd = (datetime.date.fromisoformat(r['day']) + datetime.timedelta(days=off)).isoformat()
            if t0.isoformat() <= nd <= t1.isoformat():
                conn.execute("INSERT OR REPLACE INTO sched_shifts(employee_id, day, kind, start, end, meal, note, updated_at, updated_by) VALUES (?,?,?,?,?,?,?,?,?)",
                             (r['employee_id'], nd, r['kind'], r['start'], r['end'], r['meal'], None, _at_now(), current_display_name()))
        conn.commit()
    finally:
        conn.close()
    log_audit('RH : horaire copié', f"{p0} au {p1} → {t0} au {t1}")
    return jsonify({'ok': True, 'copied': len(src)})


@app.route('/api/sched/publish', methods=['POST'])
def api_sched_publish():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    d0, d1 = _sched_period()
    conn = get_conn()
    try:
        draft, pub = sched_cells(conn, 'sched_shifts', d0, d1), sched_cells(conn, 'sched_published', d0, d1)
        emps = {e['id']: e for e in sched_employees(conn)}
        changes = {}
        for eid in set(draft) | set(pub):
            for i in range((d1 - d0).days + 1):
                day = (d0 + datetime.timedelta(days=i)).isoformat()
                a, b = (pub.get(eid) or {}).get(day), (draft.get(eid) or {}).get(day)
                if not _sched_same(a, b):
                    changes.setdefault(eid, []).append((day, a, b))
        conn.execute("DELETE FROM sched_published WHERE day BETWEEN ? AND ?", (d0.isoformat(), d1.isoformat()))
        conn.execute("INSERT INTO sched_published SELECT * FROM sched_shifts WHERE day BETWEEN ? AND ?", (d0.isoformat(), d1.isoformat()))
        first = not pub
        sent, failed = 0, 0
        for eid, ch in changes.items():
            e = emps.get(eid)
            if not e:
                continue
            fmt = lambda c: ((c.get('note') or 'Congé') if c.get('kind') == 'off' else sched_label(c)) if c else 'aucun quart'
            is_first = first or not any(pub.get(eid, {}).values())
            if is_first:
                txt = f"Ton horaire du {sched_day_fr(d0.isoformat())} au {sched_day_fr(d1.isoformat())} est publié."
                lines = [f"  • {sched_day_fr(day)} : {fmt(b)}" for day, a, b in sorted(ch) if b]
            else:
                txt = f"Ton horaire a changé ({len(ch)} journée{'s' if len(ch) > 1 else ''})."
                lines = [f"  • {sched_day_fr(day)} : {fmt(b)} (avant : {fmt(a)})" for day, a, b in sorted(ch)]
            short = txt if len(ch) > 3 else txt + ' ' + ' ; '.join(f"{sched_day_fr(day)} : {fmt(b)}" for day, a, b in sorted(ch))
            conn.execute("INSERT INTO sched_notices(employee_id, created_at, text) VALUES (?,?,?)", (eid, _at_now(), short[:400]))
            conn.commit()        # libère la base avant l'envoi : le journal des envois doit pouvoir écrire
            if e.get('email'):
                try:
                    mine = (draft.get(eid) or {})
                    out = PDF_DIR / "Horaires"; out.mkdir(parents=True, exist_ok=True)
                    pdf = export_sched_emp_pdf(e, d0, d1, mine, ch, is_first,
                                               out / f"Horaire_{e['first_name']}_{e['last_name']}_{d0}.pdf".replace(' ', '_'))
                    html = sched_email_html(e, d0, d1, mine, ch, is_first, get_company_name())
                    send_email(e['email'], f"{get_company_name()} — " + ("ton horaire" if is_first else "changement à ton horaire"),
                               f"Bonjour {e['first_name']},\n\n{txt}\n\n" + '\n'.join(lines) +
                               "\n\nTon horaire est joint en PDF et disponible dans ton espace employé.\n\n" + get_company_name(),
                               str(pdf), mode='send', bcc_company=False, html=html, category='Horaires')
                    sent += 1
                except Exception:
                    traceback.print_exc()
                    failed += 1
        conn.commit()
    finally:
        conn.close()
    meta_set('sched_last_publish', _at_now())
    log_audit('RH : horaire publié', f"{d0} au {d1} — {len(changes)} employé(s) touché(s), {sent} courriel(s) envoyé(s), {failed} échec(s)")
    return jsonify({'ok': True, 'employees': len(changes), 'sent': sent, 'failed': failed})


@app.route('/api/sched/pdf')
def api_sched_pdf():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    d0, d1 = _sched_period()
    out = PDF_DIR / "Horaires"; out.mkdir(parents=True, exist_ok=True)
    conn = get_conn()
    try:
        p = export_sched_pdf(conn, d0, d1, out / f"Horaire_{d0}_au_{d1}.pdf")
    finally:
        conn.close()
    return send_file(str(p), mimetype='application/pdf', as_attachment=False, download_name=p.name)


@app.route('/api/sched/settings', methods=['POST'])
def api_sched_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    if 'templates' in d:
        tpl = [[a, b] for a, b in d['templates'] if re.fullmatch(r'\d\d:\d\d', a or '') and re.fullmatch(r'\d\d:\d\d', b or '') and _hm_min(b) > _hm_min(a)][:8]
        if not tpl:
            return jsonify({'ok': False, 'error': 'Au moins un quart type est requis.'}), 400
        meta_set('sched_templates', json.dumps(tpl))
    if 'closed' in d:
        meta_set('sched_closed_days', ','.join(str(int(x)) for x in d['closed'] if 0 <= int(x) <= 6))
    if 'grace' in d:
        meta_set('sched_late_grace', str(max(0, min(60, int(d['grace'] or 0)))))
    log_audit('RH : réglages des horaires', json.dumps(d, ensure_ascii=False))
    return jsonify({'ok': True, 'settings': sched_settings()})


@app.route('/rh/conges')
def leave_page():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    return render_template('leaves.html', company=get_company_name(), is_admin=bool(session.get('is_admin')))


@app.route('/api/leaves')
def api_leaves():
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    st = request.args.get('statut') or 'en_attente'
    conn = get_conn()
    try:
        q = ("SELECT l.*, e.first_name, e.last_name, e.department FROM leave_requests l JOIN hr_employees e ON e.id=l.employee_id"
             + ("" if st == 'tous' else " WHERE l.status=?") + " ORDER BY " + ("l.created_at" if st == 'en_attente' else "l.start DESC") + " LIMIT 300")
        rows = [dict(r) for r in conn.execute(q, () if st == 'tous' else (st,)).fetchall()]
        for r in rows:
            # qui d'autre est absent ou en congé ces jours-là (pour décider)
            others = conn.execute("SELECT e.first_name || ' ' || e.last_name n, l.start, l.end FROM leave_requests l JOIN hr_employees e ON e.id=l.employee_id "
                                  "WHERE l.status='approuvee' AND l.employee_id<>? AND l.start<=? AND l.end>=?", (r['employee_id'], r['end'], r['start'])).fetchall()
            r['overlap'] = [f"{o['n']} ({_d(o['start'])} au {_d(o['end'])})" for o in others]
            r['days'] = (datetime.date.fromisoformat(r['end']) - datetime.date.fromisoformat(r['start'])).days + 1
            r['kind_label'] = LEAVE_KINDS.get(r['kind'], r['kind']); r['status_label'] = LEAVE_STATUS.get(r['status'], r['status'])
        pending = conn.execute("SELECT COUNT(*) FROM leave_requests WHERE status='en_attente'").fetchone()[0]
    finally:
        conn.close()
    return jsonify({'rows': rows, 'pending': pending})


@app.route('/api/leaves/<int:lid>/decide', methods=['POST'])
def api_leave_decide(lid):
    resp = permission_required_check('rh')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    action = d.get('action')
    comment = str(d.get('comment') or '').strip()[:500]
    if action not in ('approuvee', 'refusee', 'annuler'):
        return jsonify({'ok': False, 'error': 'Action invalide.'}), 400
    if action == 'refusee' and not comment:
        return jsonify({'ok': False, 'error': 'Indique la raison du refus : elle sera envoyée à l\u2019employé.'}), 400
    conn = get_conn()
    try:
        lv = conn.execute("SELECT * FROM leave_requests WHERE id=?", (lid,)).fetchone()
        if not lv:
            return jsonify({'ok': False, 'error': 'Demande introuvable.'}), 404
        lv = dict(lv)
        e = dict(conn.execute("SELECT * FROM hr_employees WHERE id=?", (lv['employee_id'],)).fetchone())
        if action == 'annuler':
            if lv['status'] != 'approuvee':
                return jsonify({'ok': False, 'error': 'Seul un congé approuvé peut être annulé.'}), 400
            leave_apply_schedule(conn, lv, remove=True)
            conn.execute("UPDATE leave_requests SET status='annulee', manager_comment=?, decided_by=?, decided_at=? WHERE id=?",
                         (comment or lv['manager_comment'], current_display_name(), _at_now(), lid))
            new = 'annulee'
        else:
            if lv['status'] != 'en_attente':
                return jsonify({'ok': False, 'error': 'Cette demande a déjà reçu une réponse.'}), 400
            conn.execute("UPDATE leave_requests SET status=?, manager_comment=?, decided_by=?, decided_at=? WHERE id=?",
                         (action, comment or None, current_display_name(), _at_now(), lid))
            if action == 'approuvee':
                leave_apply_schedule(conn, lv)
            new = action
        txt = {'approuvee': 'a été approuvée', 'refusee': "n'a pas été approuvée", 'annulee': 'a été annulée'}[new]
        conn.execute("INSERT INTO sched_notices(employee_id, created_at, text) VALUES (?,?,?)",
                     (lv['employee_id'], _at_now(), f"Ta demande de {LEAVE_KINDS.get(lv['kind']).lower()} du {sched_day_fr(lv['start'])} au {sched_day_fr(lv['end'])} {txt}."
                      + (f" Commentaire : {comment}" if comment else '')))
        conn.commit()
    finally:
        conn.close()
    sent = False
    who = current_display_name()
    when = datetime.datetime.now()
    when_txt = f"{sched_day_fr(when.date().isoformat())} à {when:%H h %M}"
    verb = {'approuvee': 'Approuvé', 'refusee': 'Refusé', 'annulee': 'Annulé'}[new]
    color = {'approuvee': 'linear-gradient(135deg,#15803d,#22c55e)', 'refusee': 'linear-gradient(135deg,#b91c1c,#ef4444)', 'annulee': 'linear-gradient(135deg,#b45309,#f59e0b)'}[new]
    extra = [(f"{verb} par", f"{who}, le {when_txt}")]
    com_html = (f"<div style='background:#f8fafc;border-left:4px solid #64748b;padding:10px 14px;margin:14px 0;font-size:14px'><b>Commentaire de {_esc(who)} :</b><br>{_esc(comment)}</div>"
                if comment else '')
    if e.get('email'):
        inner = (f"<p style='font-size:15px;margin:0 0 14px'>Bonjour {_esc(e['first_name'])}, ta demande de congé {txt}.</p>" + _leave_summary_rows(lv, e, extra) + com_html
                 + ("<p style='font-size:14px;color:#475569;margin:14px 0 0'>Ces journées sont maintenant indiquées en congé dans ton horaire (« Mon horaire »).</p>" if new == 'approuvee' else '')
                 + ("<p style='font-size:14px;color:#475569;margin:14px 0 0'>Ces journées ne sont plus en congé dans ton horaire.</p>" if new == 'annulee' else ''))
        html = _leave_html_card(f"Demande de congé {LEAVE_STATUS[new].lower()}", color, inner)
        try:
            send_email(e['email'], f"{get_company_name()} — demande de congé {LEAVE_STATUS[new].lower()}",
                       f"Bonjour {e['first_name']},\n\nTa demande de {LEAVE_KINDS.get(lv['kind']).lower()} du {sched_day_fr(lv['start'])} au {sched_day_fr(lv['end'])} {txt}."
                       f"\n{verb} par {who}, le {when_txt}." + (f"\n\nCommentaire : {comment}" if comment else ''), None, mode='send', bcc_company=False, html=html, category='Congés')
            sent = True
        except Exception:
            traceback.print_exc()
    # avis aux autres approbateurs : la demande est traitée, et par qui
    conn = get_conn()
    try:
        approvers = [u for u in leave_approvers(conn, e.get('department')) if u['username'] != session.get('username')]
    finally:
        conn.close()
    if approvers:
        inner = (f"<p style='font-size:15px;margin:0 0 14px'>La demande de congé de <b>{_esc(e['first_name'])} {_esc(e['last_name'])}</b> a été traitée : rien d'autre à faire.</p>"
                 + _leave_summary_rows(lv, e, [('Décision', LEAVE_STATUS[new])] + extra) + com_html)
        masc = {'approuvee': 'approuvé', 'refusee': 'refusé', 'annulee': 'annulé'}[new]       # « le congé » est masculin
        html = _leave_html_card(f"Congé {masc} par {_esc(who)}", color, inner)
        for u in approvers:
            try:
                send_email(u['email'], f"{get_company_name()} — congé de {e['first_name']} {e['last_name']} {masc} par {who}",
                           f"La demande de congé de {e['first_name']} {e['last_name']} ({sched_day_fr(lv['start'])} au {sched_day_fr(lv['end'])}) : {LEAVE_STATUS[new].lower()} par {who}, le {when_txt}."
                           + (f"\nCommentaire : {comment}" if comment else ''), None, mode='send', bcc_company=False, html=html, category='Congés')
            except Exception:
                traceback.print_exc()
    log_audit(f"RH : congé {LEAVE_STATUS[new].lower()}", f"{e['first_name']} {e['last_name']} — {lv['start']} au {lv['end']}" + (f" — {comment}" if comment else ''))
    return jsonify({'ok': True, 'status': new, 'emailed': sent})


@app.route('/api/leaves/approvers', methods=['GET', 'POST'])
def api_leave_approvers():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if request.method == 'POST':
        d = request.get_json(silent=True) or {}
        cfg = {str(k): [str(u) for u in v][:20] for k, v in (d.get('config') or {}).items() if isinstance(v, list) and v}
        meta_set('leave_approvers', json.dumps(cfg, ensure_ascii=False))
        log_audit('RH : approbateurs des congés modifiés', json.dumps(cfg, ensure_ascii=False))
    conn = get_conn()
    try:
        users = [{'username': r['username'], 'name': r['full_name'] or r['username'], 'email': r['email'] or '',
                  'rh': bool(r['is_admin'] or 'rh' in (r['permissions'] or ''))}
                 for r in conn.execute("SELECT username, full_name, email, is_admin, permissions FROM users WHERE active=1 ORDER BY COALESCE(full_name, username) COLLATE NOCASE").fetchall()]
        deps = [r[0] for r in conn.execute("SELECT DISTINCT department FROM hr_employees WHERE status<>'inactif' AND department IS NOT NULL AND department<>'' ORDER BY department COLLATE NOCASE").fetchall()]
    finally:
        conn.close()
    return jsonify({'ok': True, 'config': leave_approver_config(), 'users': users, 'departments': deps})
