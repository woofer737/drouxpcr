# -*- coding: utf-8 -*-
"""Outils communs des PDF (mise en page, en-tête, logo, avis).
Module du tronc commun de Kubios (découpé de app.py en 1.45.0, code inchangé)."""
import os, re, io, csv, sys, json, base64, hashlib, unicodedata, time, shutil, secrets, sqlite3, zipfile, threading, subprocess, datetime, traceback
import urllib.request, urllib.error, urllib.parse, email.utils
from pathlib import Path
from flask import request, session, has_request_context
import licensing
from kubios_base import get_company_name

__all__ = ['LOGO_PATH', 'REPORT_DISCLAIMER', 'REPORT_DISCLAIMER_TITLE', '_at_doc', '_at_pdf_kit', '_pdf_disclaimer']


LOGO_PATH = Path(__file__).resolve().parent / "static" / "logo.png"


REPORT_DISCLAIMER_TITLE = "Avis de non-responsabilité"


REPORT_DISCLAIMER = ("Les montants de ce rapport sont calculés automatiquement à partir des données de Lightspeed et de Kubios, "
                     "et sont fournis à titre indicatif. Kubios et Groupe SRB ne peuvent être tenus responsables d'erreurs, "
                     "d'omissions ou d'inexactitudes. Validez périodiquement, par échantillonnage, les montants dans Lightspeed "
                     "avant de les utiliser à des fins comptables ou fiscales.")


def _pdf_disclaimer(space=14, size=7.5):
    """Encadré de l'avis de non-responsabilité, ajouté à la fin des rapports PDF internes."""
    from reportlab.platypus import Table, TableStyle, Paragraph, Spacer, KeepTogether
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib import colors
    st = ParagraphStyle('avis', fontName='Helvetica', fontSize=size, leading=size + 2, textColor=colors.HexColor('#4b5563'))
    t = Table([[Paragraph(f"<b>{REPORT_DISCLAIMER_TITLE}</b> — {REPORT_DISCLAIMER}", st)]])
    t.setStyle(TableStyle([('BOX', (0, 0), (-1, -1), 0.5, colors.HexColor('#cbd5e1')), ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#f8fafc')),
                           ('LEFTPADDING', (0, 0), (-1, -1), 6), ('RIGHTPADDING', (0, 0), (-1, -1), 6),
                           ('TOPPADDING', (0, 0), (-1, -1), 5), ('BOTTOMPADDING', (0, 0), (-1, -1), 5)]))
    return KeepTogether([Spacer(1, space), t])


def _at_pdf_kit():
    from reportlab.lib.pagesizes import letter, landscape
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, KeepTogether, PageBreak
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    ss = getSampleStyleSheet()
    k = dict(letter=letter, landscape=landscape, mm=mm, colors=colors, SimpleDocTemplate=SimpleDocTemplate, Table=Table, TableStyle=TableStyle,
             Paragraph=Paragraph, Spacer=Spacer, KeepTogether=KeepTogether, PageBreak=PageBreak)
    k['cell'] = ParagraphStyle('c', parent=ss['Normal'], fontSize=8, leading=10)
    k['cellb'] = ParagraphStyle('cb', parent=k['cell'], fontName='Helvetica-Bold')
    k['h1'] = ParagraphStyle('h1', parent=ss['Normal'], fontName='Helvetica-Bold', fontSize=16, leading=19)
    k['h2'] = ParagraphStyle('h2', parent=ss['Normal'], fontName='Helvetica-Bold', fontSize=11, spaceBefore=6, spaceAfter=4, textColor=colors.HexColor('#1e3a8a'))
    k['small'] = ParagraphStyle('s', parent=ss['Normal'], fontSize=8.5, leading=11, textColor=colors.HexColor('#4b5563'))
    k['base'] = [('FONTSIZE', (0, 0), (-1, -1), 8), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('LINEBELOW', (0, 0), (-1, -1), 0.25, colors.HexColor('#d1d5db')),
                 ('TOPPADDING', (0, 0), (-1, -1), 3), ('BOTTOMPADDING', (0, 0), (-1, -1), 3), ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                 ('TEXTCOLOR', (0, 0), (-1, 0), colors.white), ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e3a8a'))]
    return k


def _at_doc(path, k, title, sub, landscape_=False):
    ps = k['landscape'](k['letter']) if landscape_ else k['letter']
    lm = 14 * k['mm']
    def header(canvas, doc_):
        canvas.saveState()
        w, h = ps
        canvas.setFont('Helvetica-Bold', 15); canvas.drawString(lm, h - 15 * k['mm'], get_company_name())
        canvas.setFont('Helvetica-Bold', 11); canvas.drawString(lm, h - 21.5 * k['mm'], title)
        canvas.setFont('Helvetica', 8.5); canvas.drawString(lm, h - 26.5 * k['mm'], sub)
        if LOGO_PATH.exists():
            from reportlab.lib.utils import ImageReader
            img = ImageReader(str(LOGO_PATH)); iw, ih = img.getSize(); lw = 34 * k['mm']
            canvas.drawImage(img, w - lm - lw, h - 12 * k['mm'] - lw * ih / iw, width=lw, height=lw * ih / iw, mask='auto')
        canvas.setStrokeColor(k['colors'].HexColor('#999999')); canvas.line(lm, h - 29 * k['mm'], w - lm, h - 29 * k['mm'])
        canvas.setFont('Helvetica', 7); canvas.drawString(lm, 8 * k['mm'], f"{get_company_name()} — {title}"); canvas.drawRightString(w - lm, 8 * k['mm'], f"Page {doc_.page}")
        canvas.restoreState()
    doc = k['SimpleDocTemplate'](str(path), pagesize=ps, leftMargin=lm, rightMargin=lm, topMargin=32 * k['mm'], bottomMargin=12 * k['mm'])
    return doc, header
