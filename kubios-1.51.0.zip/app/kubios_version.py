# -*- coding: utf-8 -*-
"""Nom, numéro de version et historique des changements de Kubios.
Module de Kubios (découpé de app.py en 1.46.0, code inchangé)."""
import os
import re
import io
import csv
import sys
import json
import base64
import hashlib
import unicodedata
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import openpyxl
from openpyxl.utils import get_column_letter
import licensing
from kubios_base import COMPANY_EMAIL_DEFAULT

__all__ = ['APP_NAME', 'APP_VERSION', 'CHANGELOG']


APP_NAME = "Kubios"


APP_VERSION = "1.51.0"


CHANGELOG = [
    {
        "version": "1.51.0",
        "date": "2026-11-12",
        "changes": [
            "Nouveau : super administrateur (fournisseur). Compte visible dans la liste des utilisateurs (badge « Fournisseur »), "
            "créé seulement sur l'ordinateur serveur (Activer_super_admin.bat), non modifiable par les administrateurs du client, "
            "et qui ne compte pas dans le nombre d'utilisateurs de la licence.",
            "Nouveau : mode maintenance. Message, retour prévu, option pour laisser fonctionner les postes de punch ; "
            "les autres utilisateurs voient une page d'attente.",
            "Nouveau : Système → Santé du système (super administrateur) : espace disque, base de données et intégrité, accès aux "
            "dossiers, sauvegardes, Lightspeed, courriels, Excel, licence, tâches de fond, temps de réponse, erreurs du serveur, "
            "historique des métriques sur 24 h ou 7 jours, et alertes par courriel avec seuils réglables.",
        ],
    },
    {
        "version": "1.50.1",
        "date": "2026-11-11",
        "changes": [
            "Nouvelles installations : le nom et le courriel de l'entreprise par défaut sont neutres (« Mon entreprise », aucune "
            "copie cachée tant que le courriel n'est pas saisi). Une installation existante garde automatiquement ses valeurs.",
            "Exemples des champs rendus génériques (paramètres d'envoi, entreprise, sauvegardes, inventaire) ; le service "
            "Windows s'affiche maintenant « Kubios » ; README simplifié.",
        ],
    },
    {
        "version": "1.50.0",
        "date": "2026-11-11",
        "changes": [
            "Structure : fin du découpage. Chaque fichier importe maintenant explicitement ce qu'il utilise des autres modules "
            "(plus d'importations « tout d'un coup ») ; le numéro de version n'est plus défini qu'à un seul endroit "
            "(kubios_version.py). Aucun changement visible.",
            "Note : l'installation manuelle d'un paquet demande maintenant Kubios 1.46 ou plus récent (sinon, passer par GitHub).",
        ],
    },
    {
        "version": "1.49.0",
        "date": "2026-11-11",
        "changes": [
            "Structure : dernière grande étape du découpage. Les comptes à recevoir (kubios_comptes.py), le crédit (kubios_credit.py), "
            "les rapports (kubios_rapports.py), la connexion à Lightspeed (kubios_lightspeed_pages.py) et les sauvegardes "
            "(kubios_sauvegardes.py) sont sortis de app.py, qui ne garde que le démarrage, l'accueil et la connexion. Aucun changement visible.",
        ],
    },
    {
        "version": "1.48.0",
        "date": "2026-11-11",
        "changes": [
            "Structure : les pages de l'Atelier sont sorties de app.py dans kubios_atelier.py, la connexion à Lightspeed et le "
            "téléchargement des ventes dans kubios_lightspeed.py, et quelques petits outils communs dans kubios_outils.py. "
            "Aucun changement visible.",
        ],
    },
    {
        "version": "1.47.0",
        "date": "2026-11-11",
        "changes": [
            "Structure : les pages Gestion RH (kubios_rh.py), du temps — punch, feuilles de temps, horaires, congés — "
            "(kubios_temps.py) et du portail employé (kubios_portail.py) sont sorties de app.py, avec leurs outils partagés "
            "(kubios_rh_outils.py, kubios_atelier_outils.py). Aucun changement visible.",
        ],
    },
    {
        "version": "1.46.0",
        "date": "2026-11-11",
        "changes": [
            "Structure : les pages du module Système (utilisateurs, sessions, mises à jour, paramètres d'envoi, journaux, "
            "messages, entreprise, licence) sont sorties de app.py dans kubios_systeme.py ; le numéro de version et l'historique "
            "dans kubios_version.py ; l'application et les contrôles d'accès dans kubios_app.py et kubios_auth.py. Aucun changement visible.",
        ],
    },
    {
        "version": "1.45.0",
        "date": "2026-11-11",
        "changes": [
            "Structure : le tronc commun de Kubios est sorti de app.py dans 5 modules (kubios_base : base de données et réglages ; "
            "kubios_mail : courriels et journal ; kubios_pdf : outils des PDF ; kubios_license : licence ; kubios_sessions : "
            "sessions). Aucun changement visible : mêmes pages, mêmes adresses, mêmes réglages, mêmes données.",
        ],
    },
    {
        "version": "1.44.4",
        "date": "2026-11-11",
        "changes": [
            "Mises à jour : « Revenir à une version précédente ». Au démarrage, Kubios garde une copie du programme de la version "
            "en place (les 5 dernières) ; un bouton la réinstalle et redémarre. Seul le programme change : la base et les fichiers restent.",
        ],
    },
    {
        "version": "1.44.3",
        "date": "2026-11-11",
        "changes": [
            "Correctif : les exports PDF de l'atelier (rapport financier de la rentabilité, fiches d'évaluation des mécaniciens) "
            "et le PDF des évaluations RH ne fonctionnaient plus depuis la 1.42.0 (conflit entre deux fonctions de même nom). "
            "Trouvé par la nouvelle suite de tests automatiques.",
        ],
    },
    {
        "version": "1.44.2",
        "date": "2026-11-11",
        "changes": [
            "Portail employé : « Imprimer » ouvre un PDF fait pour le papier — mon horaire (2 semaines) ou l'horaire du "
            "magasin (par département, en paysage). Impression directe (Ctrl+P) aussi mise en page : sans le menu, une "
            "journée par ligne.",
        ],
    },
    {
        "version": "1.44.1",
        "date": "2026-11-11",
        "changes": [
            "Congés : choix des approbateurs (pour tout le magasin ou par département) dans la page Congés ; seuls eux "
            "reçoivent les demandes. Nouveau courriel de demande (dates, durée, note, qui est déjà en congé, horaire prévu, "
            "bouton « Répondre dans Kubios »). Le courriel de décision indique qui a approuvé ou refusé, et quand ; les autres "
            "approbateurs reçoivent un avis que la demande est traitée.",
        ],
    },
    {
        "version": "1.44.0",
        "date": "2026-11-11",
        "changes": [
            "Nouveau : Système → Journal des envois. Chaque courriel est noté (date, méthode Outlook / SMTP / Microsoft 365, "
            "boîte d'envoi, destinataire, objet, pièce jointe, état, résumé) ; le contenu des courriels de sécurité n'est pas conservé.",
            "Horaires : le courriel de publication est maintenant en HTML, avec l'horaire complet des 2 périodes, un encadré "
            "« Ce qui a changé » (avant / maintenant) et l'horaire de l'employé en PDF.",
            "Nouveau : Congés. L'employé demande ses congés dans son portail ; le responsable approuve ou refuse avec un "
            "commentaire (courriel à l'employé, avis aux responsables) ; un congé approuvé est inscrit et verrouillé dans l'horaire.",
        ],
    },
    {
        "version": "1.43.2",
        "date": "2026-11-11",
        "changes": [
            "Microsoft 365 : adresse de réponse pour les états de compte (ex. le groupe Teams recevables@) et option de copie "
            "cachée à cette adresse. Utile quand la boîte des comptes à recevoir est un groupe Microsoft 365, qui ne peut pas "
            "servir de boîte d'envoi.",
        ],
    },
    {
        "version": "1.43.1",
        "date": "2026-11-10",
        "changes": [
            "Paramètres d'envoi : guide Microsoft 365 mis à jour avec la méthode recommandée par Microsoft (RBAC pour les "
            "applications d'Exchange Online, limitée aux deux boîtes, sans permission Mail.Send dans Entra) ; message "
            "d'erreur d'accès refusé plus précis.",
        ],
    },
    {
        "version": "1.43.0",
        "date": "2026-11-09",
        "changes": [
            "Nouveau : Gestion → En ligne. Liste des sessions ouvertes (Kubios et portail employé) avec l'adresse, "
            "l'appareil et la dernière activité ; un administrateur peut fermer une session ou toutes celles d'une personne.",
            "Paramètres d'envoi : nouvelle méthode Microsoft 365 (Graph). Les états de compte partent de la boîte partagée "
            "des comptes à recevoir, tous les autres envois de la boîte de Kubios ; brouillons déposés dans la boîte ; "
            "test d'envoi par boîte. Outlook et SMTP restent disponibles.",
            "Utilisateurs : « Nouvel utilisateur » et « Réactiver » grisés quand la limite de la licence est atteinte ; "
            "pastille verte pour les personnes en ligne ; le panneau se ferme correctement avec ×.",
        ],
    },
    {
        "version": "1.42.1",
        "date": "2026-11-09",
        "changes": [
            "Horaires : toujours sur 2 semaines (Période 1 et Période 2) ; menu « Copier » : Période 1 → Période 2, "
            "Période 2 → Période 1, ou les 2 semaines précédentes. PDF : heures centrées sous chaque jour, une page par période.",
            "Feuilles de temps : « En direct » montre aussi qui est en retard ou pas encore arrivé selon l'horaire. Le PDF "
            "et l'Excel ont un détail par jour : prévu, entrée, sortie, pauses payées, dîner déduit, heures, et remarques "
            "(retard, absence, sortie manquante, corrections avec la raison).",
        ],
    },
    {
        "version": "1.42.0",
        "date": "2026-11-09",
        "changes": [
            "Nouveau : Gestion RH → Horaires. Grille par département et par jour, quarts types et repas en un clic, "
            "congés, total de la semaine (repas déduit), copie de la période précédente, PDF à afficher. Brouillon "
            "jusqu'à la publication ; à la publication, chaque employé touché reçoit un courriel avec ses journées.",
            "Portail employé : « Mon horaire » (cette semaine et la suivante, aujourd'hui en évidence, avis des "
            "changements) et l'horaire de tout le magasin ; la journée d'aujourd'hui sur l'accueil.",
            "Feuilles de temps : retards (au-delà de la tolérance, 5 min par défaut) et absences signalés en comparant "
            "l'horaire publié aux punchs.",
        ],
    },
    {
        "version": "1.41.1",
        "date": "2026-11-09",
        "changes": [
            "Feuilles de temps : la fenêtre de correction des punchs est plus large ; chaque punch tient sur deux lignes "
            "(type, date et heure, boutons, puis la raison sur toute la largeur). Les raisons s'affichent en entier.",
        ],
    },
    {
        "version": "1.41.0",
        "date": "2026-11-09",
        "changes": [
            "Bons de travail : bouton ⏱ « Ajouter du temps / Terminer » sur chaque bon. Le responsable ajoute le temps "
            "qu'un mécanicien a oublié de puncher (durée en un clic, proposée d'après « Service N mins »), avec la raison "
            "notée au journal, et peut marquer le bon terminé ; un punch resté ouvert est fermé. Kubios refuse un temps "
            "qui chevauche un autre punch du mécanicien ou qui finirait dans le futur.",
        ],
    },
    {
        "version": "1.40.2",
        "date": "2026-11-09",
        "changes": [
            "Liste et Terminés des bons de travail : tableau compact qui tient à l'écran sans défiler de gauche à droite "
            "(client et appareil sur deux lignes, priorité sous le numéro, actions en petits boutons) ; un clic sur la "
            "ligne ouvre le bon.",
        ],
    },
    {
        "version": "1.40.1",
        "date": "2026-11-09",
        "changes": [
            "Bons de travail : vue « ✓ Terminés » et liste avec recherche (numéro, client, appareil, travaux), filtres "
            "(statut, mécanicien, période de fin), colonne « Terminé le » et pages de 50 bons. La liste et le calendrier "
            "ne sont plus limités à 500 bons.",
            "Services non reliés : client et appareil du bon quand il n'a aucun punch, et bons probables proposés (même "
            "durée de service, date proche) à associer en un clic quand la vente n'a pas de « HT: # ».",
        ],
    },
    {
        "version": "1.40.0",
        "date": "2026-11-09",
        "changes": [
            "Atelier → Bons de travail : « Importer de HubTiger » — dépose l'export « Jobs booked in detail » (.xlsx), "
            "vois l'aperçu (nouveaux bons, bons complétés, bons terminés), puis confirme. Les champs saisis dans Kubios "
            "ne sont jamais écrasés ; le mécanicien, l'ordre et la date de travail ne sont jamais touchés.",
            "Option : dossier de dépôt C:\\DBouxpCR\\Import_HubTiger — un export qui y est enregistré est importé tout seul "
            "(vérification toutes les 5 minutes), puis rangé dans « Importés ».",
        ],
    },
    {
        "version": "1.39.2",
        "date": "2026-11-09",
        "changes": [
            "Page de connexion : bouton « Punch des employés » à côté de « Espace employé » (module RH actif) ; un "
            "appareil non autorisé doit entrer le code d'accès des postes.",
        ],
    },
    {
        "version": "1.39.1",
        "date": "2026-11-09",
        "changes": [
            "Page de connexion : bouton « Espace employé » vers le portail des employés (affiché quand le module RH est "
            "actif) ; lien de retour vers la connexion Kubios sur la page du portail.",
        ],
    },
    {
        "version": "1.39.0",
        "date": "2026-11-09",
        "changes": [
            "Portail employé (module RH) : chaque employé peut avoir son espace (invitation par courriel, compte séparé "
            "qui ne compte pas dans les utilisateurs de la licence) pour voir ses heures et les documents publiés, et "
            "signer ceux qui le demandent.",
            "Documents RH : publier ou retirer du portail, demander la signature de l'employé, signer comme gestionnaire "
            "(nom tapé ou signature dessinée), PDF signé avec page de signatures et empreinte, envoi d'une copie par courriel.",
            "Punch des employés : poste sur ordinateur ou tablette autorisé (NIP), entrée, pause, retour, sortie ; feuilles "
            "de temps avec pauses de 15 min ou moins payées, dîner déduit, heures sup. au-delà de 40 h/semaine, corrections "
            "notées, approbation, période à la semaine ou aux deux semaines, exports Excel et PDF.",
        ],
    },
    {
        "version": "1.38.0",
        "date": "2026-11-08",
        "changes": [
            "Licence par modules : le noyau, Gestion Atelier et Gestion RH ont chacun leur durée (ex. noyau à vie, "
            "Atelier et RH 1 an). Un module non inclus ou expiré disparaît du menu et ses pages sont bloquées, sans "
            "perte de données. Les anciens codes (OE-LIC1-) restent valides et donnent accès à tous les modules.",
            "Nouvelle page Licence, dans le style des autres pages, avec le tableau des modules ; l'avis « expire "
            "bientôt » couvre aussi les modules. Nouveau générateur de licences avec fenêtres (outil séparé).",
        ],
    },
    {
        "version": "1.37.0",
        "date": "2026-11-08",
        "changes": [
            "Page Utilisateurs repensée : recherche et filtres, liste épurée (rôle, statut, 2FA, nombre d'accès, "
            "dernière connexion), et panneau de détail par personne (profil, rôle et accès regroupés par module avec "
            "modèles en un clic, sécurité et mot de passe avec générateur, statut). Un seul bouton « Enregistrer ».",
        ],
    },
    {
        "version": "1.36.0",
        "date": "2026-11-08",
        "changes": [
            "Mises à jour : installer un paquet téléversé (kubios-x.y.z.zip), sans passer par GitHub. Kubios vérifie "
            "le paquet, affiche sa version et ses changements, avertit s'il est plus ancien ou identique, puis "
            "l'installe et redémarre comme une mise à jour normale.",
        ],
    },
    {
        "version": "1.35.0",
        "date": "2026-11-08",
        "changes": [
            "Vérification en deux étapes : à chaque connexion, on peut choisir entre le code de l'application "
            "d'authentification et un code reçu par courriel (si un courriel est inscrit au compte).",
        ],
    },
    {
        "version": "1.34.1",
        "date": "2026-11-08",
        "changes": [
            "Vérification en deux étapes : quand un code d'application est refusé, Kubios indique si l'horloge du PC "
            "est décalée (et de combien) ou si le code vient d'être utilisé ; tolérance portée à ±60 s ; les codes ne "
            "sont plus tous refusés après une correction de l'horloge vers l'arrière.",
        ],
    },
    {
        "version": "1.34.0",
        "date": "2026-11-08",
        "changes": [
            "Poste de punch : retour automatique à l'accueil après 4 h d'inactivité (au lieu de 1 min), réglable par "
            "un administrateur dans Atelier → Mécaniciens (1 min à 8 h).",
            "Pages de double authentification, de mot de passe oublié et de réinitialisation : même nouveau design que la "
            "page de connexion (même fond : animation, image ou vidéo).",
        ],
    },
    {
        "version": "1.33.0",
        "date": "2026-11-08",
        "changes": [
            "Poste de punch : le NIP se tape au pavé tactile ou au clavier (chiffres, Retour arrière, Entrée, Échap).",
            "Poste de punch : onglet « À venir » — le mécanicien voit ses bons planifiés des prochains jours "
            "(7 jours, 14 jours ou tous), regroupés par journée, et peut en débuter un pour prendre de l'avance.",
        ],
    },
    {
        "version": "1.32.0",
        "date": "2026-11-08",
        "changes": [
            "Nouvelle identité : Kubios, logiciel de gestion d'entreprise. Nouvelle page de connexion « Gérez tout. "
            "Simplement. » avec une mosaïque animée de mini tableaux de bord en fond ; l'avertissement « Accès "
            "autorisé seulement » est conservé.",
            "Administration → Page de connexion : choix du fond (animation Kubios, image ou vidéo personnalisée) et "
            "téléversement d'une vidéo (MP4 ou WebM, jouée en boucle sans son). La vidéo est incluse dans les "
            "sauvegardes complètes.",
        ],
    },
    {
        "version": "1.31.0",
        "date": "2026-11-08",
        "changes": [
            "Nouvelle page « Administration RH » (administrateurs) : modifier, ordonner, ajouter ou désactiver les "
            "critères d'évaluation, et les textes par défaut des modèles de documents. Les évaluations passées gardent "
            "leurs critères d'origine.",
            "Évaluations : option « S.O. » (ne s'applique pas) sur chaque critère, exclu de la moyenne.",
            "Dossier de l'employé : « Créer un document » — avertissement écrit, lettre de reconnaissance, compte rendu "
            "de rencontre, attestation d'emploi — en PDF avec signatures, classé au dossier et noté à l'historique.",
        ],
    },
    {
        "version": "1.30.0",
        "date": "2026-11-08",
        "changes": [
            "Nouveau module « Gestion RH » (permission dédiée) : dossier de chaque employé (profil, documents, "
            "évaluations, historique, journal des consultations), rappels (certifications à renouveler, fin de "
            "probation, évaluations à faire).",
            "Évaluation du rendement adaptée à un magasin de vente et de location d'outils (9 critères notés de 1 à 5, "
            "points forts, à améliorer, objectifs, commentaires de l'employé), statistiques d'atelier automatiques pour "
            "les mécaniciens, PDF signable classé au dossier à la finalisation.",
            "Atelier → export des fiches d'évaluation : option « Enregistrer aussi au dossier RH ». Les documents RH "
            "sont inclus dans les sauvegardes complètes.",
        ],
    },
    {
        "version": "1.29.2",
        "date": "2026-11-08",
        "changes": [
            "Atelier → Rentabilité : fenêtre « Exporter en PDF… » pour choisir le rapport (financier ou fiche "
            "d'évaluation), la période (prédéfinie, une journée ou du … au …), la personne (tous ou un seul "
            "mécanicien) et les options.",
        ],
    },
    {
        "version": "1.29.1",
        "date": "2026-11-08",
        "changes": [
            "Nouvelle permission « Gestion Atelier — rentabilité et évaluations (données sensibles) » : sans elle, "
            "l'onglet Rentabilité, les fiches d'évaluation et le rapport financier sont cachés et refusés par le serveur.",
            "« Services non reliés » dans son propre onglet pour le responsable d'atelier, avec Ce mois / Mois dernier / "
            "Ce trimestre et « Relire Lightspeed ».",
            "Option : relire chaque nuit (vers 2 h) les ventes des N derniers jours, pour reprendre les « HT: #bon » "
            "ajoutés ou corrigés après coup.",
        ],
    },
    {
        "version": "1.29.0",
        "date": "2026-11-08",
        "changes": [
            "Atelier → Rentabilité : statistiques de performance par mécanicien (bons travaillés et terminés, heures "
            "punchées et facturées, rendement, taux réel, marge, bons dépassant le temps facturé, problèmes signalés, "
            "punchs corrigés), comparées à la moyenne de l'atelier et à la période précédente ; coût du temps non "
            "facturé ; périodes « Cette année » et dates au choix.",
            "Exports PDF : rapport financier de l'atelier, et fiches d'évaluation (une ou toutes, une page par "
            "mécanicien) avec observations automatiques, commentaires et signatures ; options pour inclure ou non le "
            "coût et la marge, et le détail par bon.",
        ],
    },
    {
        "version": "1.28.0",
        "date": "2026-11-08",
        "changes": [
            "Bons de travail : glisser-déposer pour réattribuer un bon à un autre mécanicien ou changer l'ordre.",
            "Nouveau calendrier de planification (une ligne par mécanicien, une colonne par jour) : on glisse les "
            "bons « À planifier » au bon mécanicien et à la bonne journée. Champ « Date de travail » dans le bon. "
            "Sur le poste de punch, « Ma journée » ne montre que les bons d'aujourd'hui (ou en retard) et ceux sans date.",
            "L'atelier en direct : panneau escamotable « Bons du jour » (à faire / en cours, et terminés aujourd'hui) "
            "et compteur dans l'en-tête, sans cacher la vue 3D.",
        ],
    },
    {
        "version": "1.27.0",
        "date": "2026-11-08",
        "changes": [
            "Nouvelle page « L'atelier en direct » (Atelier → bouton « Ouvrir l'atelier en direct », ou /atelier/direct) : "
            "garage 3D avec une baie par mécanicien (élévateur, machine de saison, établi), écran par baie avec le bon, "
            "le client et le chronomètre, gyrophare aux couleurs de l'état ; mise à jour toutes les 5 secondes. "
            "Conçue pour une fenêtre séparée ou une télé (sans le menu, plein écran).",
            "Alertes en direct avec son : problème signalé, message d'un mécanicien, punch oublié ; « OK, vu » marque les "
            "messages comme lus. Jusqu'à 12 mécaniciens (2ᵉ rangée de baies). three.js en local.",
        ],
    },
    {
        "version": "1.26.1",
        "date": "2026-11-07",
        "changes": [
            "Derrière Cloudflare Tunnel, Kubios lit la vraie adresse de l'utilisateur (en-tête CF-Connecting-IP, "
            "cru seulement quand la connexion vient du tunnel sur le même PC) : blocage du code d'accès des "
            "tablettes par appareil, et bonne adresse dans le journal d'audit.",
            "Journal d'audit : adresse de chaque connexion, et tentatives de connexion échouées.",
        ],
    },
    {
        "version": "1.26.0",
        "date": "2026-11-07",
        "changes": [
            "Poste de punch : « Message au responsable » et « Signaler un problème » sur un bon (pièce manquante, "
            "plus long que prévu, client à contacter, outil, autre) ; le mécanicien voit les réponses du responsable.",
            "Responsable : pastille rouge sur « Atelier » et alerte en bas de l'écran, partout dans Kubios ; nouvel "
            "onglet Atelier → Messages pour répondre et marquer les problèmes résolus ; courriel facultatif quand un "
            "problème est signalé.",
        ],
    },
    {
        "version": "1.25.0",
        "date": "2026-11-07",
        "changes": [
            "Bons de travail : priorité en couleur (Normal, Dans la journée, Urgent), notes du responsable pour "
            "le mécanicien, ordre de travail par mécanicien (flèches) et vue en colonnes par mécanicien.",
            "Poste de punch : « Ma journée » en cartes colorées dans l'ordre du responsable, avec date souhaitée "
            "(aujourd'hui, demain, en retard) ; le détail du bon et les notes s'affichent avant de débuter et "
            "pendant le chronomètre.",
            "Supprimer un bon de travail ou changer son numéro : réservé aux administrateurs (le temps punché, le "
            "facturé et les associations suivent le nouveau numéro).",
        ],
    },
    {
        "version": "1.24.2",
        "date": "2026-11-07",
        "changes": [
            "Atelier → Rentabilité : « Relire Lightspeed » montre l'avancement et rafraîchit la page à la fin ; "
            "la journée en cours n'est plus signalée comme manquante.",
            "Nouvelle liste « Services facturés non reliés » : services de la période sans numéro de bon HubTiger, "
            "ou dont le bon n'a aucun temps punché ; chacun peut être associé à un bon ou ignoré (journal d'audit).",
            "Atelier → Mécaniciens : suppression d'un mécanicien (avec confirmation s'il a des punchs ; "
            "désactiver garde l'historique).",
        ],
    },
    {
        "version": "1.24.1",
        "date": "2026-11-07",
        "changes": [
            "Rapport des ventes → Envois automatiques : boutons « Envoyer maintenant » pour le rapport de la "
            "veille et le comparatif de la semaine passée, aux gestionnaires cochés (mêmes destinataires et même "
            "copie cachée que l'envoi automatique). Les ventes manquantes sont d'abord lues dans Lightspeed ; le "
            "résultat apparaît dans le journal des envois.",
        ],
    },
    {
        "version": "1.24.0",
        "date": "2026-11-07",
        "changes": [
            "Avis de non-responsabilité au bas de tous les rapports internes (écran, PDF, Excel et courriels) : "
            "les montants sont calculés automatiquement et fournis à titre indicatif ; Kubios et Groupe SRB ne "
            "peuvent être tenus responsables d'erreurs ; les montants doivent être validés périodiquement, par "
            "échantillonnage, dans Lightspeed. Les états de compte envoyés aux clients ne sont pas touchés.",
        ],
    },
    {
        "version": "1.23.2",
        "date": "2026-11-07",
        "changes": [
            "Rapport des ventes : comptes GL du modèle préréglés (Ventes 4100, Sans catégorie 4190, Articles "
            "divers 4150, Location 4200, Pièces de rechange 4300, Service 4400, Fond de livraison 4500, Usage "
            "Interne Magasin 4900 ; Visa 1020, Mastercard 1025, Interac 1010, Compte à recevoir 1100, Comptant "
            "1000 ; TPS 2310, TVQ 2315). Le sous-total « Ventes élargies » regroupe Ventes, (Sans catégorie) et "
            "(Articles divers, sans fiche). Tout reste modifiable dans « Comptes GL du rapport ».",
        ],
    },
    {
        "version": "1.23.1",
        "date": "2026-11-07",
        "changes": [
            "Rapport des ventes, répartition par mode de paiement : le vrai mode est retrouvé (Visa, "
            "Mastercard, American Express… à partir du détail de la transaction de carte ; Compte à "
            "recevoir pour les paiements portés au compte d'un client ; Interac, Comptant, Carte-cadeau…). "
            "Chaque mode apparaît dans « Comptes GL du rapport ». Les jours déjà lus sont relus une fois.",
        ],
    },
    {
        "version": "1.23.0",
        "date": "2026-11-07",
        "changes": [
            "Nouvelle permission « Comptes à recevoir (clients, factures) », vérifiée par le serveur sur la page "
            "et toutes ses données. Les utilisateurs existants la reçoivent automatiquement ; un nouvel utilisateur "
            "ne voit plus les comptes à recevoir sans cette permission (menu, accueil, tableau de bord 3D).",
            "Rapport des ventes au format comptable (écran, PDF, Excel, courriel) : 1. ventes par catégorie avec "
            "compte GL et sous-total des « ventes élargies », 2. répartition par mode de paiement, 3. ventilation "
            "des taxes, puis grand total facturé aux clients. Comptes GL réglables par un administrateur.",
            "Les paiements de chaque vente sont maintenant gardés dans Kubios (les jours déjà lus sont relus une "
            "fois au prochain rapport).",
            "Atelier → En direct : rafraîchi toutes les 5 secondes (pause, reprise et fin visibles presque aussitôt).",
        ],
    },
    {
        "version": "1.22.0",
        "date": "2026-11-07",
        "changes": [
            "Atelier : onglet « Bons de travail » pour créer les bons à la main (numéro HubTiger, client, "
            "appareil, travaux, date promise) et les attribuer à un mécanicien ; statut suivi par les punchs "
            "(ouvert, en cours, terminé), réouverture ou annulation par le gestionnaire.",
            "Poste de punch : « Mes bons attribués » en premier, avec le client et l'appareil.",
            "Poste de punch sans le login de Kubios : code d'accès propre au poste ou lien direct qui "
            "autorise la tablette (environ un an) ; « Révoquer les tablettes » coupe l'accès de toutes les "
            "tablettes. Le NIP du mécanicien reste demandé à chaque punch.",
        ],
    },
    {
        "version": "1.21.0",
        "date": "2026-11-07",
        "changes": [
            "Nouvelle section « Gestion Atelier ». Poste de punch (tablette) : le mécanicien choisit "
            "son nom, entre son NIP, tape ou scanne le numéro du bon HubTiger, puis Débuter / Pause / "
            "Reprendre / Terminer. S'il a déjà un bon en cours, Kubios demande quoi faire : terminer "
            "l'ancien, le mettre en pause ou travailler sur les deux.",
            "Page « Atelier » : qui travaille sur quoi en direct, temps par bon, alertes de punchs "
            "restés ouverts, correction et ajout de punchs (journal d'audit), gestion des mécaniciens "
            "(NIP, taux coûtant visible des administrateurs seulement).",
            "Rentabilité (administrateurs) : minutes et montants de service facturés dans Lightspeed "
            "(lignes « Service N mins » marquées « HT: #bon ») comparés au temps punché et au coût "
            "du mécanicien ; rendement, taux horaire réel, marge par bon et par mécanicien ; saisie "
            "manuelle du facturé au besoin.",
            "Les ventes gardées dans Kubios notent maintenant le numéro de bon HubTiger et les minutes "
            "de service de chaque ligne (les jours déjà lus peuvent être relus depuis la page Atelier).",
        ],
    },
    {
        "version": "1.20.1",
        "date": "2026-11-06",
        "changes": [
            "Tableau de bord 3D sans Internet : three.js est téléchargé une seule fois par Kubios "
            "(version fixée et vérifiée), gardé dans app\\static\\vendor et servi en local. "
            "État et bouton de téléchargement dans Administration.",
            "Maquette embellie et moins blanche : socle de gazon sur terre et roche, routes en "
            "asphalte, maisons pastel avec fleurs et buissons, étang avec reflets et ondulations, "
            "stationnement, lampadaires allumés la nuit, nuages qui passent, fond bleu ciel.",
        ],
    },
    {
        "version": "1.20.0",
        "date": "2026-11-06",
        "changes": [
            "Nouveau module « Tableau de bord 3D » (menu principal, permission dédiée) : "
            "maquette isométrique de l'entreprise en three.js, alimentée par les données de "
            "Kubios. Magasin = ventes de la période (mois en cours ou mois dernier), bâtiment "
            "mauve = taxes (TPS, TVQ, TVH), palettes = dernier instantané de l'inventaire, tour "
            "verte = comptes de crédit, maisons = 10 plus gros soldes à recevoir (toit selon le "
            "retard, taille selon le solde).",
            "Survol, clic avec zoom et panneau de détails, vues, étiquettes, jour/nuit et "
            "rotation. Chaque partie respecte les accès de l'utilisateur. Nécessite Internet "
            "(three.js est chargé en ligne).",
        ],
    },
    {
        "version": "1.19.1",
        "date": "2026-11-02",
        "changes": [
            "Valeur de l'inventaire : bouton « Prendre et envoyer maintenant », qui lit l'inventaire "
            "dans Lightspeed et envoie aussitôt le PDF par courriel aux personnes choisies "
            "(destinataires de la planification proposés, modifiables).",
        ],
    },
    {
        "version": "1.19.0",
        "date": "2026-11-01",
        "changes": [
            "Nouveau rapport « Valeur de l'inventaire » (menu Rapports, permission dédiée) : "
            "instantané lu dans Lightspeed (quantités en main × coût moyen ou coût par défaut), "
            "valeur au prix de détail, articles et unités en stock, détail par catégorie ; "
            "quantités négatives signalées à part.",
            "Historique des instantanés gardé dans Kubios, avec graphique de l'évolution et "
            "variation d'un instantané à l'autre ; PDF et envoi par courriel de n'importe quel mois.",
            "Planification mensuelle (jour du mois ou dernier jour, à l'heure choisie) avec envoi "
            "automatique du PDF aux personnes choisies.",
        ],
    },
    {
        "version": "1.18.0",
        "date": "2026-11-01",
        "changes": [
            "Nouvelle interface : menu latéral permanent sur toutes les pages (Clients et "
            "comptes, Rapports, Gestion, Système), selon les accès de chaque utilisateur, avec "
            "son nom complet et le bouton de déconnexion.",
            "Nouvel accueil : bandeau illustré « Bord de mer » qui suit le moment de la journée "
            "(matin, après-midi, soir), salutation selon l'heure (Bon matin, Bon après-midi, "
            "Bonsoir), recherche rapide d'un client, raccourcis (ajouter une facture, vérifier les "
            "factures Lightspeed, envoyer les états de compte, taxes du mois dernier), section "
            "« À surveiller » (factures en retard, sauvegarde de la nuit, licence) et ventes des "
            "7 derniers jours.",
            "Utilisateurs : nouveau champ « Nom complet », à la création et dans « Profil et "
            "sécurité ».",
        ],
    },
    {
        "version": "1.17.6",
        "date": "2026-10-31",
        "changes": [
            "Rapport des taxes : nouvelle section « Rapport des frais » à la fin (à l'écran et "
            "dans le PDF), pour les mêmes dates : Total des frais d'articles (consigne, écofrais, "
            "taxes environnementales…), comme le « Total des frais » du rapport « Lignes de "
            "vente → Frais » de Lightspeed, avec le détail par frais.",
            "Diagnostic : à chaque lecture des ventes, Kubios enregistre quelques lignes brutes de "
            "frais dans « diagnostic_frais_lightspeed.json » (C:\\DBouxpCR), pour valider la "
            "détection des frais au besoin.",
            "Les jours lus avant cette version sont relus une fois dans Lightspeed lors du "
            "prochain rapport des taxes.",
        ],
    },
    {
        "version": "1.17.5",
        "date": "2026-10-31",
        "changes": [
            "Rapport des taxes, mêmes montants que Lightspeed au cent près : les taxes sont "
            "arrondies par vente (comme Lightspeed) plutôt que ligne par ligne.",
            "Les taux propres à chaque classe d'article sont pris en compte (ex. un article "
            "« Shopify 13 » taxé à 13 % dans une vente au Québec), pour une ventilation juste.",
            "Nouveau tableau « Par classe de taxe », présenté comme le rapport « Taxe de vente » "
            "de Lightspeed (Item, Shopify 13, No Class…) : sous-total, réductions, taxé, non "
            "taxé, TPS, TVQ, total des taxes et total. Sommaire avec TPS et TVQ séparées.",
            "Ventilation par taux avec les noms officiels (TPS, TVH, TVQ, TVP) ; « TVQ » au lieu "
            "de « Taxe 2 » quand le nom est vide ; lignes à 0 $ masquées.",
            "Les jours lus avant cette version sont relus une fois dans Lightspeed lors du "
            "prochain rapport des taxes.",
        ],
    },
    {
        "version": "1.17.4",
        "date": "2026-10-31",
        "changes": [
            "Licence : quand il reste 15 jours ou moins avant l'expiration, une fenêtre s'affiche "
            "à chaque connexion pour aviser de communiquer avec le fournisseur afin de renouveler "
            "la licence ; elle se ferme avec « J'ai compris » (en rouge à 3 jours ou moins). "
            "Les licences à vie ne sont pas concernées.",
        ],
    },
    {
        "version": "1.17.3",
        "date": "2026-10-31",
        "changes": [
            "Rapport des taxes : le nom des catégories de taxes de Lightspeed est lu aussi avec "
            "chaque vente et dans tous les champs possibles ; à défaut, la catégorie est décrite "
            "par ses taxes (ex. « TPS 5 % + TVQ 9,975 % » ou « Aucune taxe ») au lieu d'un numéro. "
            "Utiliser « Relire Lightspeed et régénérer » pour mettre à jour les noms d'une période.",
        ],
    },
    {
        "version": "1.17.2",
        "date": "2026-10-31",
        "changes": [
            "Rapport des taxes : bouton « Relire Lightspeed et régénérer », qui relit toutes "
            "les ventes de la période dans Lightspeed (ventes modifiées, annulées ou retournées "
            "après coup) avant de refaire le rapport. Le rapport indique aussi quand les ventes "
            "ont été lues dans Lightspeed pour la dernière fois.",
        ],
    },
    {
        "version": "1.17.1",
        "date": "2026-10-31",
        "changes": [
            "Republication de la 1.17.0 combinée avec la 1.16.2 : inclut la limite "
            "d'utilisateurs actifs et la date d'expiration des licences, en plus du Rapport "
            "des ventes et du Rapport des taxes. Remplace le premier paquet 1.17.0, qui ne "
            "contenait pas les changements de la 1.16.2.",
        ],
    },
    {
        "version": "1.17.0",
        "date": "2026-10-30",
        "changes": [
            "La tuile « Rapports personnalisés » s'appelle maintenant « Rapport des ventes ».",
            "Nouvelle tuile « Rapport des taxes » (permission dédiée) : pour les dates choisies, "
            "ventilation de chaque taxe par taux (ex. TPS 5 %, TVQ 9,975 %) avec ventes taxables "
            "et taxe perçue, ventes non taxables, totaux avant et après taxes, et détail par "
            "catégorie de taxes Lightspeed. Affichage à l'écran et téléchargement en PDF.",
            "Les montants de taxes de chaque vente sont maintenant gardés dans Kubios ; les "
            "jours récupérés avant cette version sont relus dans Lightspeed la première fois "
            "qu'un rapport des taxes les couvre.",
        ],
    },
    {
        "version": "1.16.2",
        "date": "2026-10-30",
        "changes": [
            "Licence : prise en charge des licences avec une date d'expiration précise et "
            "d'une limite d'utilisateurs actifs (ex. 5 utilisateurs, ou illimité). Une fois "
            "la limite atteinte, la création ou la réactivation d'un compte est refusée. "
            "La page Licence affiche la limite et le nombre d'utilisateurs actifs. Les "
            "licences déjà émises restent valides, avec utilisateurs illimités.",
        ],
    },
    {
        "version": "1.16.1",
        "date": "2026-10-30",
        "changes": [
            "Sauvegardes : avis par courriel après chaque sauvegarde automatique (réussie ou "
            "en échec) ou seulement en cas d'échec, à une ou plusieurs adresses, avec bouton "
            "« Envoyer un courriel de test ». Le courriel d'échec indique la raison et quoi vérifier.",
        ],
    },
    {
        "version": "1.16.0",
        "date": "2026-10-30",
        "changes": [
            "Nouvelle option « Sauvegardes » (accueil, administrateurs) : sauvegarde complète "
            "de toutes les données et de la configuration (base de données, classeur Excel, "
            "logo et image de fond), automatiquement une fois par jour à l'heure choisie, "
            "conservée 30 jours (7 ou 14 au choix), dans le dossier choisi (disque externe ou "
            "réseau recommandé).",
            "Boutons « Faire une sauvegarde maintenant », « Télécharger » et « Restaurer » ; "
            "restauration possible aussi à partir d'un fichier. Avant toute restauration, "
            "l'état actuel est sauvegardé ; la connexion Lightspeed actuelle est conservée.",
        ],
    },
    {
        "version": "1.15.1",
        "date": "2026-10-30",
        "changes": [
            "« Messages aux utilisateurs » devient une option à part (tuile sur l'accueil, "
            "section Administration) au lieu d'une section de la page Administration.",
        ],
    },
    {
        "version": "1.15.0",
        "date": "2026-10-30",
        "changes": [
            "Nouvelle option « Messages aux utilisateurs » (accueil) : publier un message en bandeau "
            "(rouge, jaune ou bleu) affiché en haut de toutes les pages pour les utilisateurs "
            "connectés, pendant une période choisie (7 à 90 jours, date précise ou sans fin), "
            "avec aperçu. Désactiver, réactiver, modifier ou supprimer en tout temps ; le "
            "bandeau disparaît seul à la date de fin.",
        ],
    },
    {
        "version": "1.14.1",
        "date": "2026-10-30",
        "changes": [
            "La gestion du courriel et de la double authentification passe dans la page "
            "Utilisateurs (bouton « Courriel et 2FA » sur chaque compte, colonnes Courriel "
            "et 2FA) ; elle est retirée de la page Administration.",
            "Création d'un utilisateur : champ Courriel et case « 2FA obligatoire ».",
        ],
    },
    {
        "version": "1.14.0",
        "date": "2026-10-28",
        "changes": [
            "Mot de passe oublié : lien « Mot de passe oublié ? » sur la page de connexion. "
            "Un lien de réinitialisation est envoyé au courriel de l'utilisateur (valide "
            "1 heure, une seule fois, 3 demandes par heure au maximum).",
            "Double authentification (2FA), exigée utilisateur par utilisateur par un "
            "administrateur. À sa première connexion, l'utilisateur choisit sa méthode : "
            "application (Google ou Microsoft Authenticator, code QR) ou code de 6 chiffres "
            "envoyé par courriel. Blocage de 15 minutes après 5 codes erronés.",
            "Administration → nouvelle section « Utilisateurs : courriel et double "
            "authentification » : courriel de chaque utilisateur, 2FA obligatoire ou non, "
            "état de la configuration et bouton pour la réinitialiser (téléphone perdu).",
        ],
    },
    {
        "version": "1.13.2",
        "date": "2026-10-24",
        "changes": [
            "Rapports personnalisés : la copie cachée envoyée à l'adresse courriel de "
            "l'entreprise devient optionnelle (case dans Envois automatiques et dans la "
            "fenêtre « Envoyer par courriel ») ; par défaut, les rapports n'envoient plus "
            "de copie. Les états de compte des clients ne changent pas.",
        ],
    },
    {
        "version": "1.13.1",
        "date": "2026-10-24",
        "changes": [
            "Envois automatiques : choix du regroupement (catégories complètes ou catégories "
            "principales) pour le rapport de la veille et pour le comparatif hebdomadaire.",
        ],
    },
    {
        "version": "1.13.0",
        "date": "2026-10-24",
        "changes": [
            "Rapports personnalisés : les ventes de Lightspeed sont maintenant gardées dans "
            "Kubios. Chaque nuit (1 h par défaut), Kubios récupère les ventes de la veille "
            "(et relit les 7 derniers jours pour les retours et annulations). L'historique "
            "peut être récupéré depuis la date choisie (1er janvier 2024 par défaut). Les "
            "rapports se génèrent ensuite instantanément.",
            "Rapport de la veille envoyé automatiquement chaque matin aux gestionnaires choisis, "
            "et bouton « Envoyer par courriel » pour tout rapport généré.",
            "Nouveau rapport « Comparatif hebdomadaire » : une semaine (lundi au dimanche) "
            "comparée à la même semaine l'an dernier (52 semaines plus tôt, mêmes jours), avec "
            "graphique par jour, écarts et variations par catégorie ; envoyé automatiquement "
            "chaque lundi et consultable dans Kubios. Export Excel et PDF.",
            "Onglet « Envois automatiques » (administrateurs) : gestionnaires et types de "
            "rapports reçus, heure de la tâche de nuit, état de l'historique, journal des envois.",
        ],
    },
    {
        "version": "1.12.0",
        "date": "2026-10-13",
        "changes": [
            "Nouveau module « Rapports personnalisés » (accueil), avec une permission "
            "dédiée pour les utilisateurs non administrateurs.",
            "Premier rapport : « Ventes par catégorie d'articles », lu directement dans "
            "Lightspeed (API) pour la période choisie (aujourd'hui, hier, semaine, mois, "
            "mois dernier, année ou dates précises), par magasin au besoin, en catégories "
            "complètes ou principales : quantité, sous-total, rabais, total, coût, profit, "
            "marge et part des ventes, avec total général.",
            "Exportation du rapport en Excel et en PDF (logo de l'entreprise).",
        ],
    },
    {
        "version": "1.11.3",
        "date": "2026-10-12",
        "changes": [
            "Comptes à recevoir : bouton « Fusionner… » dans la fiche client. On choisit "
            "l'autre client et le nom à garder : les factures, les liens Lightspeed et les "
            "paiements traités passent au client gardé, ses coordonnées vides sont "
            "complétées, l'autre client est retiré (son onglet Excel est supprimé à la "
            "prochaine synchronisation). Une sauvegarde est prise avant.",
            "Noms reconnus : le nom d'un client fusionné (ou l'ancien nom d'un client "
            "renommé) reste associé au bon client ; les prochaines vérifications Lightspeed "
            "le retrouvent automatiquement.",
            "Factures Lightspeed : action « Relier seulement » pour relier un client "
            "Lightspeed à un client Kubios existant sans inscrire de facture ; un paiement "
            "d'un client pas encore reconnu peut être relié et appliqué au client choisi.",
            "Fiche client : liste des liens Lightspeed et des noms reconnus, avec bouton "
            "pour en retirer un.",
        ],
    },
    {
        "version": "1.11.2",
        "date": "2026-10-12",
        "changes": [
            "Factures Lightspeed : les paiements reçus sur compte dans Lightspeed peuvent "
            "maintenant être appliqués aux factures dans Kubios. Kubios propose la "
            "répartition (la facture dont le solde est exactement le montant payé, sinon "
            "les plus anciennes d'abord, avec paiement partiel au besoin) ; on peut choisir "
            "la facture par laquelle commencer, ou « Déjà fait » si le paiement avait été "
            "marqué à la main. Un paiement traité n'est plus jamais reproposé.",
            "Vérification des soldes : pour chaque client relié à Lightspeed, le solde dans "
            "Kubios est comparé au solde de son compte de crédit ; les écarts sont listés "
            "(facture ou paiement manquant d'un côté).",
            "La sauvegarde prise avant l'inscription couvre aussi les paiements appliqués.",
        ],
    },
    {
        "version": "1.11.1",
        "date": "2026-10-12",
        "changes": [
            "Nouvelle page de connexion : image de fond (plan technique aux couleurs de "
            "Kubios par défaut), présentation du logiciel à gauche et formulaire à droite ; "
            "s'adapte aux petits écrans.",
            "Bas de page « Propulsé par Groupe SRB — © année » : l'année se met à jour "
            "automatiquement.",
            "Administration : téléverser sa propre photo comme image de fond de la page "
            "de connexion (JPG, PNG ou WEBP, 8 Mo max.), ou revenir à l'image par défaut.",
        ],
    },
    {
        "version": "1.11.0",
        "date": "2026-10-11",
        "changes": [
            "Comptes à recevoir : nouvel onglet « Factures Lightspeed ». Le bouton "
            "« Vérifier les factures » lit dans Lightspeed les ventes portées au compte "
            "de crédit depuis une date et montre celles qui ne sont pas encore dans "
            "Kubios (comparaison par numéro de vente). Tu choisis pour chacune : "
            "inscrire, plus tard ou ignorer, puis « Inscrire dans Kubios ».",
            "Montant = partie de la vente portée au compte ; un retour porté au compte "
            "devient une note de crédit ; échéance = dernier jour du mois suivant. Les "
            "ventes de clients absents de Kubios sont dans « Autres clients » : on peut "
            "les relier à un client existant ou créer le client (coordonnées lues dans "
            "Lightspeed).",
            "Les paiements reçus sur compte dans Lightspeed sont affichés comme rappel "
            "(Lightspeed ne les relie pas à une facture précise) : ils se marquent "
            "toujours dans Kubios.",
            "Une sauvegarde des comptes à recevoir (clients et factures) est prise avant "
            "chaque inscription ; un administrateur peut tout remettre comme avant "
            "(section « Sauvegardes avant inscription »).",
        ],
    },
    {
        "version": "1.10.3",
        "date": "2026-10-11",
        "changes": [
            "Synchronisation Lightspeed automatique : choix de la fréquence dans "
            "Administration → Lightspeed — désactivée, chaque jour, ou le dernier jour "
            "de chaque mois (à partir de l'heure choisie, 23 h proposé).",
            "La synchronisation de fin de mois garde toujours un rapport PDF « Fin de "
            "mois » dans « Rapports PDF par importation », même si aucun solde n'a "
            "changé, pour avoir le portrait de chaque fin de mois.",
        ],
    },
    {
        "version": "1.10.2",
        "date": "2026-10-11",
        "changes": [
            "Connexion Lightspeed : Lightspeed exige une adresse de retour en https://. "
            "L'adresse proposée est maintenant https://localhost/kubios-lightspeed (la "
            "même pour le test et la prod). Après l'autorisation, le navigateur affiche "
            "une page d'erreur : il suffit de copier l'adresse de la barre d'adresse et "
            "de la coller dans Administration → Lightspeed pour terminer la connexion, "
            "à partir de n'importe quel poste.",
        ],
    },
    {
        "version": "1.10.1",
        "date": "2026-10-11",
        "changes": [
            "Comptes de crédit : une sauvegarde est prise automatiquement avant chaque "
            "importation (réinitialisation de la liste, import des mouvements, "
            "synchronisation Lightspeed manuelle ou automatique). Si la sauvegarde "
            "échoue, l'importation est annulée.",
            "Nouvelle section « Sauvegardes avant importation » : un administrateur "
            "peut remettre les comptes de crédit et leur historique exactement comme "
            "avant une mauvaise importation. L'état actuel est sauvegardé juste avant, "
            "donc une restauration peut elle aussi être annulée. Les comptes à recevoir "
            "ne sont pas touchés.",
            "Une synchronisation sans aucun changement ne garde pas de sauvegarde ; "
            "les 60 plus récentes sont conservées (dossier Backups_comptes_credit).",
        ],
    },
    {
        "version": "1.10.0",
        "date": "2026-10-11",
        "changes": [
            "Comptes de crédit : synchronisation directe avec Lightspeed R-Series "
            "(API). Plus besoin d'exporter le fichier « credit_account_listings » : "
            "le bouton « Synchroniser maintenant » lit les comptes de crédit dans "
            "Lightspeed et met à jour la limite, le montant dû et le dépôt de chaque "
            "client (un changement de solde est inscrit dans l'historique).",
            "Chaque compte Kubios est maintenant relié à son compte Lightspeed par son "
            "numéro : les clients portant le même nom ne se mélangent plus. À la "
            "première synchronisation, l'association se fait par nom ; les homonymes "
            "sont listés dans « Comptes Lightspeed à associer » pour être reliés à la main.",
            "Administration → Lightspeed : Client ID / secret de l'application "
            "Lightspeed, bouton « Connecter à Lightspeed », test de connexion, sens du "
            "solde (détecté automatiquement à la première synchronisation) et "
            "synchronisation automatique quotidienne à l'heure choisie.",
            "Les cartes-cadeaux et les comptes archivés de Lightspeed sont ignorés ; "
            "les comptes « Ne pas synchroniser » sont reliés mais jamais modifiés.",
        ],
    },
    {
        "version": "1.9.3",
        "date": "2026-10-08",
        "changes": [
            "Comptes à recevoir : une facture à montant négatif (note de crédit) "
            "n'est plus affichée « Payée ». Elle porte maintenant un badge bleu "
            "« Crédit », avec son montant et son solde en bleu. Le bouton devient "
            "« Crédit appliqué » (le crédit a été utilisé ou remboursé — son solde "
            "passe à 0, badge « Crédit appliqué ») et peut être annulé.",
            "Dans la liste des clients, un client dont le solde total est négatif "
            "affiche un badge bleu « Crédit » au lieu de « À jour ».",
        ],
    },
    {
        "version": "1.9.2",
        "date": "2026-10-08",
        "changes": [
            "Comptes de crédit : la fiche d'un client permet maintenant de "
            "modifier le compte (nom, limite de crédit, montant dû, dépôt, "
            "notes) et de le supprimer (administrateurs seulement, avec son "
            "historique).",
            "Chaque mouvement de l'historique peut être modifié (date, type, "
            "vente, montant) ou supprimé s'il est en erreur. Le solde du client "
            "est ajusté automatiquement de la différence (une confirmation "
            "indique le montant).",
            "Nouvelle case « Ne pas synchroniser avec l'importation » sur chaque "
            "compte : l'import des mouvements (instantané mensuel ou journal de "
            "transactions) ne touche plus à ce compte et garde tes valeurs. La "
            "réinitialisation complète de la liste, elle, remplace quand même "
            "tout. Un badge « Non synchronisé » s'affiche dans la liste.",
            "Toutes ces actions sont inscrites au journal d'audit.",
        ],
    },
    {
        "version": "1.9.1",
        "date": "2026-10-08",
        "changes": [
            "Comptes de crédit : « Importer / réinitialiser la liste des "
            "clients » accepte maintenant aussi l'export Lightspeed "
            "« credit_account_listings » (.csv en anglais, colonnes First Name, "
            "Last Name, Credit Limit, Debt), en plus du format en français "
            "(Prénom / Entreprise, Nom, Limite de crédit, Montant dû, Dépôt). "
            "Le montant dû vient de la colonne « Debt » ; un « Debt » négatif "
            "(crédit en faveur du client) est importé comme dépôt, avec un "
            "montant dû à 0. L'import mensuel des mouvements applique la même "
            "règle : les clients en crédit ne sont plus comptés deux fois "
            "(solde négatif + dépôt).",
            "Correction : un montant écrit à la française dans un fichier "
            "importé (ex. « 1 234,56 $ ») était lu comme 123 456 $ ; la "
            "virgule décimale est maintenant reconnue.",
        ],
    },
    {
        "version": "1.9.0",
        "date": "2026-10-08",
        "changes": [
            "Comptes à recevoir : nouveau bouton « Modifier le client » dans la "
            "fiche d'un client. Il permet de changer le nom, le courriel, le "
            "téléphone et l'adresse d'un client existant. Lors d'un changement "
            "de nom, toutes ses factures suivent automatiquement et son onglet "
            "dans le fichier Excel est renommé à la prochaine synchronisation "
            "(aucun onglet en double). Chaque modification est inscrite au "
            "journal d'audit avec l'ancienne et la nouvelle valeur.",
            "La fiche d'un client affiche maintenant son courriel et son "
            "téléphone sous son nom.",
        ],
    },
    {
        "version": "1.8.9",
        "date": "2026-10-06",
        "changes": [
            "Licence : l'expiration des licences de 30 jours et d'un an ne "
            "dépend plus seulement de la date de l'ordinateur. L'app vérifie "
            "la date réelle sur Internet (au démarrage puis toutes les 6 "
            "heures) et mémorise la date la plus récente qu'elle a vue. Si la "
            "date de l'ordinateur est reculée de plus d'un jour, l'app se "
            "bloque avec un message demandant de corriger la date, et "
            "l'événement est inscrit au journal d'audit. Sans Internet, la "
            "date mémorisée sert de référence. Les licences à vie ne sont "
            "pas touchées.",
        ],
    },
    {
        "version": "1.8.8",
        "date": "2026-09-30",
        "changes": [
            "Nouveau module « Administration » (réservé aux administrateurs, "
            "accessible depuis la page d'accueil) permettant de personnaliser "
            "le logiciel : nom et courriel de l'entreprise, logo affiché sur "
            "les états de compte et rapports PDF (avec retour possible au "
            "logo par défaut), ainsi que les messages de conclusion affichés "
            "au bas des PDF et dans les courriels.",
        ],
    },
    {
        "version": "1.8.7",
        "date": "2026-09-30",
        "changes": [
            "Ajout d'une page d'accueil (menu) après la connexion : elle "
            "propose des tuiles vers chaque volet accessible (Comptes à "
            "recevoir, Comptes de crédit, Utilisateurs, Audit, Paramètres "
            "d'envoi, Mises à jour, Licence) au lieu d'atterrir directement "
            "sur les comptes à recevoir. Les liens « Accueil » sur les "
            "autres pages ramènent maintenant à ce menu.",
        ],
    },
    {
        "version": "1.8.6",
        "date": "2026-09-30",
        "changes": [
            "Ajout d'un avertissement légal (« Accès autorisé seulement ») "
            "sur la page de connexion, rappelant que le système est réservé "
            "aux personnes autorisées et que les activités peuvent être "
            "surveillées et auditées.",
        ],
    },
    {
        "version": "1.8.5",
        "date": "2026-09-30",
        "changes": [
            "Le style et les couleurs de la nouvelle page de connexion "
            "(Kubios) s'appliquent maintenant à tout le logiciel : en-tête "
            "en dégradé bleu avec le logo sur chaque page, boutons "
            "principaux assortis — sur l'écran principal, Utilisateurs, "
            "Audit, Paramètres d'envoi, Mises à jour, Licence et Comptes de "
            "crédit.",
        ],
    },
    {
        "version": "1.8.4",
        "date": "2026-09-30",
        "changes": [
            "Comptes de crédit : « Importer / réinitialiser la liste des "
            "clients » (qui remplace toute la liste et efface l'historique "
            "des mouvements) est maintenant réservé aux administrateurs — "
            "les utilisateurs avec seulement l'accès « Comptes de crédit » "
            "peuvent encore importer les mouvements/instantanés mensuels et "
            "consulter les rapports, mais plus réinitialiser la liste.",
        ],
    },
    {
        "version": "1.8.3",
        "date": "2026-09-30",
        "changes": [
            "Nouvelle page de connexion : le logiciel s'appelle maintenant "
            "« Kubios » (nouveau logo et design revus) — ce nom n'apparaît "
            "qu'à l'écran de connexion et n'affecte pas les états de compte, "
            "courriels ou documents envoyés aux clients, qui continuent "
            "d'afficher le nom de l'entreprise comme avant.",
        ],
    },
    {
        "version": "1.8.2",
        "date": "2026-09-30",
        "changes": [
            "Ajout d'un filtre « Cacher les clients à 0$ » sur la liste des "
            "comptes de crédit (limite, solde et dépôt tous à zéro).",
            "Ajout de l'export PDF des comptes de crédit (logo en haut à "
            "droite, comme les autres rapports) — soit la liste actuelle, "
            "soit le rapport exact d'une importation passée.",
            "Chaque importation (liste initiale, instantané mensuel ou "
            "journal de transactions) garde maintenant sa propre photo des "
            "soldes, téléchargeable en PDF n'importe quand — même s'il y a "
            "plusieurs importations dans le même mois, chacune garde son "
            "propre rapport.",
            "Ajout d'une option pour exclure les clients à 0$ (limite, solde "
            "et dépôt) des PDF générés, autant pour la liste actuelle que "
            "pour le rapport d'une importation passée.",
        ],
    },
    {
        "version": "1.8.1",
        "date": "2026-09-29",
        "changes": [
            "Correction de l'import mensuel des comptes de crédit : le fichier "
            "Lightspeed réellement reçu chaque mois (« credit_account_listings... "
            ".csv ») est un instantané des soldes actuels (First Name, Last Name, "
            "Credit Limit, Debt), pas un journal de transactions — il causait "
            "l'erreur « Colonnes Customer et Amount introuvables ». Le format est "
            "maintenant détecté automatiquement : instantané mensuel (met à jour "
            "les soldes) ou journal de transactions (ajoute des mouvements), les "
            "deux dans le même bouton « Importer les mouvements du mois ».",
            "Les montants avec le symbole $ (ex. « $150000.00 », « $-219.30 ») "
            "sont maintenant lus correctement dans tous les imports de comptes de "
            "crédit.",
        ],
    },
    {
        "version": "1.8.0",
        "date": "2026-09-29",
        "changes": [
            "Ajout d'un nouveau volet « Comptes de crédit » (Lightspeed), "
            "distinct des comptes à recevoir : liste des clients avec limite "
            "de crédit, solde dû et dépôt, avec alerte si un client dépasse "
            "sa limite.",
            "Import initial de la liste des comptes de crédit depuis un "
            "fichier Excel ou CSV.",
            "Import mensuel des mouvements (transactions) exportés de "
            "Lightspeed en CSV — met à jour les soldes automatiquement, sans "
            "risque de doublons si le même fichier est réimporté par erreur.",
        ],
    },
    {
        "version": "1.7.0",
        "date": "2026-09-29",
        "changes": [
            "Ajout de la date de chaque paiement (en plus du montant) — le "
            "rapport d'âge des comptes à recevoir pour un mois passé (ex. au "
            "31-07-2026) ignore maintenant correctement les paiements reçus "
            "après cette date, au lieu de les soustraire par erreur.",
            "Les factures et le tableau des clients affichent maintenant la "
            "date du paiement partiel ou complet déjà reçu.",
        ],
    },
    {
        "version": "1.6.4",
        "date": "2026-09-27",
        "changes": [
            "Installation d'une mise à jour : demande maintenant explicitement "
            "si cet ordinateur redémarre l'application comme service Windows "
            "ou manuellement via start.bat, au lieu de le deviner tout seul — "
            "utile quand plusieurs ordinateurs n'utilisent pas le même mode.",
        ],
    },
    {
        "version": "1.6.3",
        "date": "2026-09-27",
        "changes": [
            "Correctif important : l'installation automatique des mises à jour "
            "ne fonctionnait pas quand l'application tournait comme service "
            "Windows — le service s'arrêtait bien, mais ne redémarrait jamais "
            "tout seul et le code n'était pas remplacé, à cause d'un chemin "
            "Python incorrect utilisé en arrière-plan dans ce mode précis.",
        ],
    },
    {
        "version": "1.6.2",
        "date": "2026-09-27",
        "changes": [
            "Correctif : la vérification des mises à jour pouvait afficher "
            "« Réponse invalide du serveur de mises à jour » si le fichier de "
            "version en ligne contenait un caractère invisible en début de "
            "fichier ; le message d'erreur précise maintenant la cause exacte.",
        ],
    },
    {
        "version": "1.6.1",
        "date": "2026-09-27",
        "changes": [
            "Correctif : le résultat de « Vérifier les mises à jour » (nouvelle "
            "version disponible ou déjà à jour) ne s'affichait pas à l'écran "
            "même si la vérification fonctionnait correctement en arrière-plan.",
        ],
    },
    {
        "version": "1.6.0",
        "date": "2026-09-27",
        "changes": [
            "Installation automatique des mises à jour : le bouton « Installer "
            "maintenant » télécharge et applique lui-même une mise à jour "
            "détectée, puis redémarre l'application (les données du client — "
            "base de données, fichier Excel, PDF — ne sont jamais touchées).",
        ],
    },
    {
        "version": "1.5.0",
        "date": "2026-09-27",
        "changes": [
            "Ajout d'accès particuliers par utilisateur (Rapports, Audit, Licence, "
            "Paramètres d'envoi, Mises à jour) — gérable depuis la page Utilisateurs, "
            "en plus du statut administrateur.",
            "Ajout de la vérification en ligne des mises à jour (bouton « Vérifier "
            "les mises à jour »).",
        ],
    },
    {
        "version": "1.4.0",
        "date": "2026-09-27",
        "changes": [
            "Ajout d'une page « Mises à jour » (menu admin) qui affiche la version "
            "installée et l'historique complet des changements.",
        ],
    },
    {
        "version": "1.3.0",
        "date": "2026-09-26",
        "changes": [
            "Port de l'application changé de 5050 à 5080 (configurable via APP_PORT).",
            "Remplacement du serveur de développement Flask par un serveur de "
            "production (Waitress) — plus stable pour un usage continu.",
        ],
    },
    {
        "version": "1.2.0",
        "date": "2026-09-26",
        "changes": [
            "Ajout du démarrage automatique avec Windows (service Windows en "
            "arrière-plan, sans fenêtre visible).",
            "Préparation des outils pour produire un installateur Windows "
            "autonome (Setup.exe).",
        ],
    },
    {
        "version": "1.1.0",
        "date": "2026-09-26",
        "changes": [
            "Ajout du système de licence (activation par code — 30 jours, 1 an "
            "ou à vie — avec redemande automatique à l'expiration).",
            "Ajout du rapport mensuel d'envoi de courriels.",
            "Copie automatique (CCI) de chaque courriel envoyé vers "
            f"{COMPANY_EMAIL_DEFAULT}.",
            "Possibilité de modifier le sujet et le message avant l'envoi d'un "
            "état de compte.",
        ],
    },
    {
        "version": "1.0.0",
        "date": None,
        "changes": [
            "Version de référence : gestion des comptes à recevoir, paiements "
            "partiels, envoi des états de compte par Outlook ou par serveur "
            "SMTP, journal d'audit, gestion des utilisateurs et permissions.",
        ],
    },
]
