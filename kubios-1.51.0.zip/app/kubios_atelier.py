# -*- coding: utf-8 -*-
"""Pages de l'Atelier : poste de punch des mécaniciens, bons de travail, calendrier, atelier en direct, messages, rentabilité, services non reliés, import HubTiger.
Module de Kubios (découpé de app.py en 1.48.0, code inchangé)."""
import os
import re
import io
import csv
import sys
import json
import base64
import hashlib
import unicodedata
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import openpyxl
from openpyxl.utils import get_column_letter
import licensing
from kubios_base import (
    AT_FMT, _at_now, client_ip, db_add_audit, get_company_name, get_conn, get_settings, meta_get,
    meta_set,
)
from kubios_mail import send_email
from kubios_pdf import _at_doc, _at_pdf_kit, _pdf_disclaimer
from kubios_app import BASE_DIR, app
from kubios_auth import admin_required_check, current_display_name, log_audit, permission_required_check
from kubios_systeme import three_local_ready
from kubios_atelier_outils import (
    _at_clipped, _at_dt, _at_job_status, _at_period, at_billing, at_default_rate, at_job_infos,
    at_mechanics, at_profit, at_unmatched, store_missing_days,
)
from kubios_rh_outils import PDF_DIR, _d, _hm, _pc, hr_log, hr_store_file
from kubios_lightspeed import LightspeedError, _store_state, ls_config, start_store_job
from kubios_outils import _fmt_money_fr, ensure_three_vendor_async

__all__ = ['AT_JOB_STATUS', 'AT_OPEN_ALERT_HOURS', 'AT_PRIORITY', 'AT_PROBLEMS', 'AT_REREAD_HOUR', 'HT_COLS', 'HT_DROP_DIR', 'HT_PENDING', 'KIOSK_COOKIE', 'KIOSK_IDLE_CHOICES', 'KIOSK_MAX_AGE', '_at_job_seconds', '_at_next_position', '_at_notify_problem', '_at_open', '_at_parse_dt', '_at_paused_jobs', '_at_pin_fail', '_at_shop_avg', '_gap', '_ht_clean', '_ht_date', '_kiosk_fail', '_kiosk_serializer', '_m', '_period_txt', '_trend', 'api_atelier_auto_reread', 'api_atelier_billing', 'api_atelier_direct', 'api_atelier_ht_import', 'api_atelier_ht_preview', 'api_atelier_ht_settings', 'api_atelier_ignored', 'api_atelier_job_delete', 'api_atelier_job_manual', 'api_atelier_job_move', 'api_atelier_job_place', 'api_atelier_job_save', 'api_atelier_jobs', 'api_atelier_kiosk', 'api_atelier_kiosk_access', 'api_atelier_kiosk_message', 'api_atelier_kiosk_thread', 'api_atelier_live', 'api_atelier_mechanic_delete', 'api_atelier_mechanics', 'api_atelier_message_reply', 'api_atelier_message_resolve', 'api_atelier_messages', 'api_atelier_messages_read', 'api_atelier_notify_emails', 'api_atelier_profit', 'api_atelier_profit_pdf', 'api_atelier_punch', 'api_atelier_punch_edit', 'api_atelier_punches', 'api_atelier_relire', 'api_atelier_relire_status', 'api_atelier_sale_link', 'api_atelier_unmatched', 'api_atelier_unread', 'at_direct_state', 'at_job_set_status', 'at_live', 'at_mech_state', 'at_norm_job', 'at_profit_compare', 'at_punch', 'at_reread_cfg', 'at_thread', 'at_unread_counts', 'at_verify_pin', 'atelier_direct_page', 'atelier_kiosk_forget', 'atelier_kiosk_login', 'atelier_page', 'atelier_punch_page', 'export_atelier_eval_pdf', 'export_atelier_finance_pdf', 'hr_allowed', 'ht_apply', 'ht_parse', 'ht_plan', 'ht_summary', 'kiosk_allowed', 'kiosk_authorize', 'kiosk_device_ok', 'kiosk_idle_minutes', 'kiosk_link_token', 'kiosk_secret']


AT_OPEN_ALERT_HOURS = 10


_at_pin_fail = {}


def at_norm_job(j):
    j = re.sub(r'\D', '', str(j or ''))
    return j.lstrip('0') or ('0' if j else '')


def at_verify_pin(mid, pin):
    """Vérifie le NIP (5 erreurs = 5 minutes de blocage). Retourne (mécanicien, erreur)."""
    f = _at_pin_fail.get(mid, [0, 0])
    if f[0] >= 5 and time.time() - f[1] < 300:
        return None, "Trop d'essais : réessaie dans quelques minutes."
    conn = get_conn()
    m = conn.execute("SELECT * FROM shop_mechanics WHERE id=? AND active=1", (mid,)).fetchone()
    conn.close()
    if not m or not m['pin_hash'] or not check_password_hash(m['pin_hash'], str(pin or '')):
        _at_pin_fail[mid] = [f[0] + 1 if time.time() - f[1] < 300 else 1, time.time()]
        return None, "NIP incorrect."
    _at_pin_fail.pop(mid, None)
    return dict(m), None


def _at_open(conn, mid):
    return [dict(r) for r in conn.execute("SELECT * FROM shop_punches WHERE mechanic_id=? AND end_at IS NULL ORDER BY start_at", (mid,)).fetchall()]


def _at_paused_jobs(conn, mid):
    """Bons dont le dernier punch de ce mécanicien s'est terminé par une pause."""
    rows = conn.execute("SELECT job, ended_by, MAX(end_at) e FROM shop_punches WHERE mechanic_id=? AND end_at IS NOT NULL "
                        "AND start_at >= ? GROUP BY job", (mid, (datetime.datetime.now() - datetime.timedelta(days=30)).strftime(AT_FMT))).fetchall()
    out = []
    for r in rows:
        last = conn.execute("SELECT ended_by FROM shop_punches WHERE mechanic_id=? AND job=? AND end_at IS NOT NULL ORDER BY end_at DESC, id DESC LIMIT 1",
                            (mid, r['job'])).fetchone()
        if last and last['ended_by'] == 'pause':
            out.append(r['job'])
    return out


def _at_job_seconds(conn, job):
    now = datetime.datetime.now()
    total = 0.0
    for r in conn.execute("SELECT start_at, end_at FROM shop_punches WHERE job=?", (job,)).fetchall():
        total += ((_at_dt(r['end_at']) if r['end_at'] else now) - _at_dt(r['start_at'])).total_seconds()
    return max(0, total)


def at_mech_state(conn, m):
    now = datetime.datetime.now()
    open_ = _at_open(conn, m['id'])
    paused = [j for j in _at_paused_jobs(conn, m['id']) if j not in {p['job'] for p in open_}]
    recent = [r['job'] for r in conn.execute("SELECT job, MAX(start_at) s FROM shop_punches WHERE mechanic_id=? GROUP BY job "
                                             "ORDER BY s DESC LIMIT 5", (m['id'],)).fetchall()]
    assigned = [r['job'] for r in conn.execute(
        "SELECT job FROM shop_jobs WHERE mechanic_id=? AND status IN ('ouvert','en_cours') AND (work_date IS NULL OR work_date='' OR work_date<=?) "
        "ORDER BY CASE WHEN status='en_cours' THEN 0 ELSE 1 END, COALESCE(NULLIF(work_date,''),'9999'), position, created_at",
        (m['id'], datetime.date.today().isoformat())).fetchall()]
    upcoming = [dict(r) for r in conn.execute(        # 1.33.0 : bons planifiés des prochains jours (pour prendre de l'avance)
        "SELECT job, work_date FROM shop_jobs WHERE mechanic_id=? AND status IN ('ouvert','en_cours') AND work_date>? "
        "ORDER BY work_date, position, created_at LIMIT 60", (m['id'], datetime.date.today().isoformat())).fetchall()]
    infos = at_job_infos(conn, [p['job'] for p in open_] + paused + recent + assigned + [u['job'] for u in upcoming])
    return {'id': m['id'], 'name': m['name'], 'color': m['color'] or '#2563eb',
            'upcoming': [{'job': u['job'], 'date': u['work_date'], 'total': _at_job_seconds(conn, u['job'])} for u in upcoming],
            'open': [{'id': p['id'], 'job': p['job'], 'since': p['start_at'],
                      'seconds': (now - _at_dt(p['start_at'])).total_seconds()} for p in open_],
            'paused': paused,
            'recent': [{'job': j, 'total': _at_job_seconds(conn, j)} for j in recent],
            'assigned': [{'job': j, 'total': _at_job_seconds(conn, j)} for j in assigned],
            'infos': infos, 'unread': at_unread_counts(conn, m['id'])}


def at_punch(mid, action, job, mode=None):
    """Applique une action du poste de punch. Retourne un dict (ok / conflict / error)."""
    job = at_norm_job(job)
    now = _at_now()
    conn = get_conn()
    try:
        m = dict(conn.execute("SELECT * FROM shop_mechanics WHERE id=?", (mid,)).fetchone())
        open_ = _at_open(conn, mid)
        if action == 'start' or action == 'resume':
            if not job:
                return {'ok': False, 'error': "Entre le numéro du bon."}
            if any(p['job'] == job for p in open_):
                return {'ok': True, 'state': at_mech_state(conn, m)}
            others = [p for p in open_ if p['job'] != job]
            if others and mode not in ('stop', 'pause', 'both'):
                return {'ok': False, 'conflict': True, 'open': [{'job': p['job'], 'seconds': (datetime.datetime.now() - _at_dt(p['start_at'])).total_seconds()} for p in others]}
            if others and mode in ('stop', 'pause'):
                for p in others:
                    conn.execute("UPDATE shop_punches SET end_at=?, ended_by=? WHERE id=?", (now, 'fin' if mode == 'stop' else 'pause', p['id']))
            conn.execute("INSERT INTO shop_punches(mechanic_id, job, start_at, end_at, ended_by, created_by) VALUES (?,?,?,NULL,NULL,'poste')",
                         (mid, job, now))
            at_job_set_status(conn, job, 'en_cours')
            if others and mode == 'stop':
                for p in others:
                    at_job_set_status(conn, p['job'], 'termine')
            conn.commit()
            db_add_audit(f"Atelier — {m['name']}", 'Punch : début', f"bon {job}" + (f" ({mode} : {', '.join(p['job'] for p in others)})" if others else ''))
            return {'ok': True, 'state': at_mech_state(conn, m)}
        if action in ('pause', 'finish'):
            p = next((p for p in open_ if p['job'] == job), None)
            session = 0.0
            if p:
                conn.execute("UPDATE shop_punches SET end_at=?, ended_by=? WHERE id=?", (now, 'pause' if action == 'pause' else 'fin', p['id']))
                session = (datetime.datetime.now() - _at_dt(p['start_at'])).total_seconds()
            elif action == 'finish':      # bon en pause terminé sans le reprendre : on note la fin
                conn.execute("INSERT INTO shop_punches(mechanic_id, job, start_at, end_at, ended_by, created_by) VALUES (?,?,?,?,'fin','poste')",
                             (mid, job, now, now))
            else:
                return {'ok': False, 'error': "Ce bon n'est pas en cours."}
            if action == 'finish':
                at_job_set_status(conn, job, 'termine')
            conn.commit()
            db_add_audit(f"Atelier — {m['name']}", 'Punch : ' + ('pause' if action == 'pause' else 'fin'), f"bon {job}")
            return {'ok': True, 'session': session, 'job_total': _at_job_seconds(conn, job), 'state': at_mech_state(conn, m)}
        return {'ok': False, 'error': "Action inconnue."}
    finally:
        conn.close()


def at_live(args):
    d0, d1 = _at_period(args)
    now = datetime.datetime.now()
    conn = get_conn()
    try:
        mechs = [at_mech_state(conn, m) for m in at_mechanics()]
        pun = _at_clipped(conn, d0, d1)
        jobs = {}
        for p in pun:
            j = jobs.setdefault(p['job'], {'job': p['job'], 'sec': 0.0, 'sessions': 0, 'mechs': set()})
            j['sec'] += p['sec']; j['sessions'] += 1; j['mechs'].add(p['name'])
        rows = []
        for j in sorted(jobs.values(), key=lambda x: -x['sec']):
            b = at_billing(conn, j['job'])
            info = at_job_infos(conn, [j['job']]).get(j['job'], {})
            rows.append({'job': j['job'], 'client': info.get('client', ''), 'item': info.get('item', ''),
                         'seconds': j['sec'], 'sessions': j['sessions'], 'mechs': ', '.join(sorted(j['mechs'])),
                         'status': _at_job_status(conn, j['job']), 'billed_minutes': b['minutes'], 'sales': b['sales']})
        today_sec = {}
        for p in _at_clipped(conn, datetime.date.today(), datetime.date.today()):
            today_sec[p['mechanic_id']] = today_sec.get(p['mechanic_id'], 0) + p['sec']
        for m in mechs:
            m['today'] = today_sec.get(m['id'], 0)
        alerts = [{'id': r['id'], 'mechanic': r['name'], 'job': r['job'], 'since': r['start_at']} for r in conn.execute(
            "SELECT p.id, p.job, p.start_at, m.name FROM shop_punches p JOIN shop_mechanics m ON m.id=p.mechanic_id WHERE p.end_at IS NULL "
            "AND p.start_at < ?", ((now - datetime.timedelta(hours=AT_OPEN_ALERT_HOURS)).strftime(AT_FMT),)).fetchall()]
        return {'start': d0.isoformat(), 'end': d1.isoformat(), 'mechanics': mechs, 'jobs': rows, 'alerts': alerts,
                'total_seconds': sum(p['sec'] for p in pun)}
    finally:
        conn.close()


AT_REREAD_HOUR = 2


def at_reread_cfg():
    try:
        days = int(meta_get('atelier_reread_days') or 7)
    except ValueError:
        days = 7
    return {'enabled': meta_get('atelier_reread_enabled') == '1', 'days': days, 'hour': AT_REREAD_HOUR,
            'last': meta_get('atelier_reread_last_at') or '', 'last_result': meta_get('atelier_reread_last_result') or ''}


def at_profit_compare(args):
    """Rentabilité de la période + la période précédente de même durée (pour les comparaisons)."""
    r = at_profit(args)
    d0, d1 = datetime.date.fromisoformat(r['start']), datetime.date.fromisoformat(r['end'])
    n = (d1 - d0).days + 1
    p0, p1 = d0 - datetime.timedelta(days=n), d0 - datetime.timedelta(days=1)
    prev = at_profit({'start': p0.isoformat(), 'end': p1.isoformat()})
    r['prev'] = {'start': prev['start'], 'end': prev['end'], 'totals': prev['totals'],
                 'mechanics': {m['id']: {'yield': m['yield'], 'margin': m['margin'], 'real_rate': m['real_rate'], 'seconds': m['seconds'],
                                         'jobs_count': m['jobs_count']} for m in prev['mechanics']}}
    r['all_mechanics'] = [{'id': m['id'], 'name': m['name'], 'active': bool(m['active'])} for m in at_mechanics(True)]
    return r


AT_JOB_STATUS = {'ouvert': 'Ouvert', 'en_cours': 'En cours', 'termine': 'Terminé', 'annule': 'Annulé'}


AT_PRIORITY = {'normal': 'Normal', 'jour': 'Dans la journée', 'urgent': 'Urgent'}


def _at_next_position(conn, mid):
    r = conn.execute("SELECT COALESCE(MAX(position),0) FROM shop_jobs WHERE COALESCE(mechanic_id,0)=COALESCE(?,0)", (mid,)).fetchone()
    return (r[0] or 0) + 1


def at_job_set_status(conn, job, status):
    conn.execute("UPDATE shop_jobs SET status=?, updated_at=? WHERE job=? AND status<>'annule'", (status, _at_now(), job))


KIOSK_COOKIE = 'kubios_poste_punch'


KIOSK_MAX_AGE = 400 * 86400


_kiosk_fail = {}


def _kiosk_serializer():
    from itsdangerous import URLSafeTimedSerializer
    return URLSafeTimedSerializer(app.secret_key, salt='kubios-poste-punch')


def kiosk_secret():
    s = meta_get('kiosk_secret')
    if not s:
        s = secrets.token_urlsafe(16)
        meta_set('kiosk_secret', s)
    return s


def kiosk_link_token():
    t = meta_get('kiosk_link_token')
    if not t:
        t = secrets.token_urlsafe(24)
        meta_set('kiosk_link_token', t)
    return t


def kiosk_device_ok():
    raw = request.cookies.get(KIOSK_COOKIE)
    if not raw:
        return False
    try:
        data = _kiosk_serializer().loads(raw, max_age=KIOSK_MAX_AGE)
    except Exception:
        return False
    return secrets.compare_digest(str(data.get('v', '')), kiosk_secret())


def kiosk_allowed():
    """Poste de punch : session Kubios avec la permission, ou tablette autorisée."""
    if session.get('user_id') and (session.get('is_admin') or 'atelier_punch' in (session.get('permissions') or [])):
        return True
    return kiosk_device_ok()


def kiosk_authorize(resp):
    resp.set_cookie(KIOSK_COOKIE, _kiosk_serializer().dumps({'v': kiosk_secret()}), max_age=KIOSK_MAX_AGE,
                    httponly=True, samesite='Lax', secure=request.is_secure)
    return resp


AT_PROBLEMS = {'pieces': 'Pièce manquante', 'temps': 'Plus long que prévu', 'client': 'Client à contacter',
               'outil': 'Outil / équipement', 'autre': 'Autre problème'}


def at_unread_counts(conn, mid=None):
    if mid is None:
        r = conn.execute("SELECT COUNT(*) n, SUM(CASE WHEN kind='probleme' AND resolved_at IS NULL THEN 1 ELSE 0 END) p "
                         "FROM shop_messages WHERE from_side='mecanicien' AND read_at IS NULL").fetchone()
        return {'unread': r['n'] or 0, 'problems': r['p'] or 0}
    return conn.execute("SELECT COUNT(*) FROM shop_messages WHERE mechanic_id=? AND from_side='responsable' AND read_at IS NULL",
                        (mid,)).fetchone()[0]


def at_thread(conn, mid, limit=40):
    rows = [dict(r) for r in conn.execute("SELECT * FROM shop_messages WHERE mechanic_id=? ORDER BY id DESC LIMIT ?", (mid, limit)).fetchall()]
    for r in rows:
        r['category_label'] = AT_PROBLEMS.get(r['category'] or '', '')
    return list(reversed(rows))


def _at_notify_problem(mech_name, job, category, text):
    emails = [e.strip() for e in (meta_get('atelier_notify_emails') or '').replace(';', ',').split(',') if '@' in e]
    if not emails:
        return

    def run():
        com = False
        if get_settings()['send_mode'] != 'smtp':
            try:
                import pythoncom
                pythoncom.CoInitialize()
                com = True
            except Exception:
                pass
        try:
            subject = f"Atelier — problème signalé par {mech_name}" + (f" (bon {job})" if job else '')
            body = (f"Bonjour,\n\n{mech_name} a signalé un problème" + (f" sur le bon {job}" if job else '') + f" :\n\n"
                    f"{AT_PROBLEMS.get(category, 'Problème')}" + (f"\n« {text} »" if text else '') +
                    f"\n\nRéponds-lui dans Kubios → Atelier → Messages.\n\n{get_company_name()}")
            for e in emails:
                try:
                    send_email(e, subject, body, None, mode='send', bcc_company=False)
                except Exception as ex:
                    db_add_audit('Atelier', 'Avis de problème par courriel — échec', f"{e} : {ex}")
        finally:
            if com:
                try:
                    import pythoncom
                    pythoncom.CoUninitialize()
                except Exception:
                    pass
    threading.Thread(target=run, daemon=True).start()


def at_direct_state(after=None):
    """État de chaque mécanicien actif pour la vue 3D, et les nouveaux messages (après « after »)."""
    nowd = datetime.datetime.now()
    conn = get_conn()
    try:
        today = {}
        for p in _at_clipped(conn, datetime.date.today(), datetime.date.today()):
            today[p['mechanic_id']] = today.get(p['mechanic_id'], 0) + p['sec']
        problems = {}
        for r in conn.execute("SELECT * FROM shop_messages WHERE kind='probleme' AND resolved_at IS NULL ORDER BY id").fetchall():
            problems[r['mechanic_id']] = {'id': r['id'], 'job': r['job'], 'label': AT_PROBLEMS.get(r['category'] or '', 'Problème'), 'text': r['text'] or ''}
        unread = {r['mechanic_id']: r['n'] for r in conn.execute(
            "SELECT mechanic_id, COUNT(*) n FROM shop_messages WHERE from_side='mecanicien' AND read_at IS NULL GROUP BY mechanic_id").fetchall()}
        mechs = []
        for m in at_mechanics():
            st = at_mech_state(conn, m)
            info = st['infos']
            if st['open']:
                cur = st['open'][0]; job = cur['job']; status = 'work'; since = cur['seconds']
            else:
                job = st['paused'][0] if st['paused'] else ''
                status = 'pause' if job else 'free'
                last = conn.execute("SELECT MAX(end_at) e FROM shop_punches WHERE mechanic_id=? AND end_at IS NOT NULL", (m['id'],)).fetchone()['e']
                start_day = datetime.datetime.combine(datetime.date.today(), datetime.time(7, 0))
                ref = _at_dt(last) if last else start_day
                since = max(0, (nowd - max(ref, start_day if status == 'free' else ref)).total_seconds())
            pb = problems.get(m['id'])
            if pb:
                status = 'alert'
            i = info.get(job, {}) if job else {}
            oubli = [o for o in st['open'] if o['seconds'] > AT_OPEN_ALERT_HOURS * 3600]
            mechs.append({'id': m['id'], 'name': m['name'], 'color': m['color'] or '#2563eb', 'status': status, 'job': job,
                          'client': i.get('client', ''), 'item': i.get('item', ''), 'since_seconds': since,
                          'job_seconds': _at_job_seconds(conn, job) if job else 0, 'today_seconds': today.get(m['id'], 0),
                          'others': [o['job'] for o in st['open'][1:]], 'problem': pb, 'unread': unread.get(m['id'], 0),
                          'oubli': [{'punch': o['id'], 'job': o['job'], 'since': o['since']} for o in oubli],
                          'next': [{'job': a['job'], 'label': ' — '.join(x for x in (info.get(a['job'], {}).get('client', ''), info.get(a['job'], {}).get('item', '')) if x)}
                                   for a in st['assigned'] if a['job'] != job][:3]})
        last_id = conn.execute("SELECT COALESCE(MAX(id),0) FROM shop_messages").fetchone()[0]
        today_iso = datetime.date.today().isoformat()
        names = {m['id']: (m['name'], m['color'] or '#2563eb') for m in at_mechanics(True)}
        todo = [dict(r) for r in conn.execute(
            "SELECT * FROM shop_jobs WHERE status IN ('ouvert','en_cours') AND (work_date=? OR (work_date IS NOT NULL AND work_date<>'' AND work_date<?) "
            "OR job IN (SELECT job FROM shop_punches WHERE end_at IS NULL)) ORDER BY CASE WHEN status='en_cours' THEN 0 ELSE 1 END, mechanic_id, position",
            (today_iso, today_iso)).fetchall()]
        done_jobs = {}
        for r in conn.execute("SELECT job, mechanic_id, MAX(end_at) e FROM shop_punches WHERE ended_by='fin' AND end_at LIKE ? GROUP BY job",
                              (today_iso + '%',)).fetchall():
            done_jobs[r['job']] = (r['mechanic_id'], r['e'])
        for r in conn.execute("SELECT job, mechanic_id, updated_at FROM shop_jobs WHERE status='termine' AND updated_at LIKE ?", (today_iso + '%',)).fetchall():
            done_jobs.setdefault(r['job'], (r['mechanic_id'], r['updated_at']))
        infos = at_job_infos(conn, [t['job'] for t in todo] + list(done_jobs))
        def jrow(job, mid, extra):
            i = infos.get(job, {})
            n = names.get(mid, ('', '#64748b'))
            return dict({'job': job, 'client': i.get('client', ''), 'item': i.get('item', ''), 'priority': i.get('priority', 'normal'),
                         'mechanic': n[0], 'color': n[1], 'seconds': _at_job_seconds(conn, job)}, **extra)
        day = {'todo': [jrow(t['job'], t['mechanic_id'], {'status': t['status'], 'late': bool(t['work_date'] and t['work_date'] < today_iso)}) for t in todo
                        if t['job'] not in done_jobs or t['status'] == 'en_cours'],
               'done': sorted([jrow(jb, v[0], {'finished_at': v[1]}) for jb, v in done_jobs.items()
                               if not any(t['job'] == jb and t['status'] == 'en_cours' for t in todo)], key=lambda x: x['finished_at'] or '', reverse=True)}
        events = []
        if after is not None:
            for r in conn.execute("SELECT s.*, m.name FROM shop_messages s JOIN shop_mechanics m ON m.id=s.mechanic_id "
                                  "WHERE s.id>? AND s.from_side='mecanicien' ORDER BY s.id LIMIT 10", (after,)).fetchall():
                events.append({'id': r['id'], 'mechanic_id': r['mechanic_id'], 'kind': r['kind'], 'job': r['job'],
                               'text': (AT_PROBLEMS.get(r['category'] or '', '') + (' — ' if r['text'] and r['category'] else '') if r['kind'] == 'probleme' else '') + (r['text'] or '')})
        return {'mechanics': mechs, 'last_id': last_id, 'events': events, 'unread_total': sum(unread.values()), 'day': day,
                'server_time': nowd.strftime(AT_FMT), 'company': get_company_name()}
    finally:
        conn.close()


def _m(v):
    return '—' if v is None else (('−' if v < 0 else '') + f"{abs(v):,.2f} $".replace(',', ' ').replace('.', ','))


def _gap(v):
    v = round(v or 0)
    return '0 min' if v == 0 else f"{'+' if v > 0 else '−'}{abs(v)} min"


def _period_txt(r):
    return (f"Le {_d(r['start'])}" if r['start'] == r['end'] else f"Du {_d(r['start'])} au {_d(r['end'])}")


def _trend(cur, prev, better_high=True, fmtf=str):
    if cur is None or prev is None:
        return '—'
    if abs(cur - prev) < 1e-9:
        return '='
    up = cur > prev
    return ('▲ ' if up else '▼ ') + fmtf(abs(cur - prev)) + ('' if up == better_high else ' (à surveiller)')


def export_atelier_finance_pdf(r):
    k = _at_pdf_kit(); T = r['totals']; P = r.get('prev', {}).get('totals', {})
    out = PDF_DIR / "Atelier"; out.mkdir(exist_ok=True)
    path = out / f"Rentabilite_atelier_{r['start']}_au_{r['end']}.pdf"
    g = datetime.datetime.now()
    doc, header = _at_doc(path, k, "Rentabilité de l'atelier — rapport financier", f"{_period_txt(r)} — généré le {g:%d-%m-%Y à %H:%M}", True)
    Tb, TS, Pa, C = k['Table'], k['TableStyle'], k['Paragraph'], k['colors']
    story = []
    kp = [["Main-d'œuvre facturée", "Coût (bons facturés)", "Marge", "Rendement", "Taux horaire réel", "Heures punchées"],
          [_m(T['billed']), _m(T['cost']), f"{_m(T['margin'])}" + (f"  ({T['margin'] / T['billed'] * 100:.1f} %)".replace('.', ',') if T['billed'] else ''),
           _pc(T['yield']), (_m(T['effective_rate']) + '/h') if T['effective_rate'] else '—', _hm(T['punched_seconds'])],
          ["Période précédente : " + _m(P.get('billed')), _m(P.get('cost')), _m(P.get('margin')), _pc(P.get('yield')),
           (_m(P.get('effective_rate')) + '/h') if P.get('effective_rate') else '—', _hm(P.get('punched_seconds', 0))]]
    t = Tb(kp, colWidths=[42 * k['mm']] * 6)
    t.setStyle(TS(k['base'] + [('FONTNAME', (0, 1), (-1, 1), 'Helvetica-Bold'), ('FONTSIZE', (0, 1), (-1, 1), 11), ('TEXTCOLOR', (0, 2), (-1, 2), C.HexColor('#6b7280')), ('FONTSIZE', (0, 2), (-1, 2), 7.5)]))
    story += [t, k['Spacer'](1, 4)]
    story.append(Pa(f"Temps punché au-delà du temps facturé (bons facturés) : <b>{_hm(T['lost_seconds'])}</b>, soit un coût de <b>{_m(T['lost_cost'])}</b>. "
                    f"Bons pas encore facturés : <b>{T['unbilled_jobs']}</b> ({_hm(T['unbilled_seconds'])}, coût de {_m(T['unbilled_cost'])}).", k['small']))
    story.append(Pa("Par mécanicien", k['h2']))
    rows = [["Mécanicien", "Bons", "H. punchées", "H. facturées", "Rendement", "Préc.", "Taux réel", "Coût", "Facturé", "Marge", "Marge %", "Dépassés"]]
    for m in r['mechanics']:
        pv = r.get('prev', {}).get('mechanics', {}).get(m['id'], {})
        rows.append([Pa(m['name'], k['cell']), m['jobs_count'], _hm(m['seconds']), _hm(m['billed_minutes'] * 60), _pc(m['yield']), _pc(pv.get('yield')),
                     (_m(m['real_rate']) + '/h') if m['real_rate'] else '—', _m(m['cost']), _m(m['billed']), _m(m['margin']), _pc(m['margin_pct']),
                     f"{m['over_count']} / {m['billed_count']}"])
    rows.append([Pa('<b>Atelier</b>', k['cell']), sum(m['jobs_count'] for m in r['mechanics']), _hm(T['punched_seconds']), _hm(T['billed_minutes'] * 60),
                 _pc(T['yield']), _pc(P.get('yield')), (_m(T['effective_rate']) + '/h') if T['effective_rate'] else '—',
                 _m(sum(m['cost'] for m in r['mechanics'])), _m(T['billed']), _m(T['margin']),
                 _pc(round(T['margin'] / T['billed'] * 100, 1) if T['billed'] else None), f"{sum(m['over_count'] for m in r['mechanics'])} / {sum(m['billed_count'] for m in r['mechanics'])}"])
    t = Tb(rows, colWidths=[44 * k['mm'], 13 * k['mm'], 21 * k['mm'], 21 * k['mm'], 19 * k['mm'], 15 * k['mm'], 22 * k['mm'], 22 * k['mm'], 22 * k['mm'], 22 * k['mm'], 16 * k['mm'], 18 * k['mm']], repeatRows=1)
    t.setStyle(TS(k['base'] + [('ALIGN', (1, 0), (-1, -1), 'RIGHT'), ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'), ('BACKGROUND', (0, -1), (-1, -1), C.HexColor('#dbe3f3'))]))
    story.append(t)
    worst = [j for j in r['jobs'] if j.get('margin') is not None][:15]
    if worst:
        story.append(Pa("Bons les moins rentables", k['h2']))
        rows = [["Bon", "Client / appareil", "Mécaniciens", "Temps passé", "Facturé (min)", "Écart", "Facturé", "Coût", "Marge"]]
        for j in worst:
            rows.append([j['job'], Pa(' — '.join(x for x in (j['client'], j['item']) if x) or '—', k['cell']), Pa(j['mechs'], k['cell']), _hm(j['seconds']),
                         f"{round(j['billed_minutes'] or 0)} min", _gap(j['gap_minutes']), _m(j['billed']), _m(j['cost']), _m(j['margin'])])
        t = Tb(rows, colWidths=[16 * k['mm'], 62 * k['mm'], 46 * k['mm'], 22 * k['mm'], 22 * k['mm'], 20 * k['mm'], 24 * k['mm'], 22 * k['mm'], 22 * k['mm']], repeatRows=1)
        t.setStyle(TS(k['base'] + [('ALIGN', (3, 0), (-1, -1), 'RIGHT')])); story.append(t)
    unb = [j for j in r['jobs'] if j.get('billed') is None][:20]
    if unb:
        story.append(Pa("Bons pas encore facturés", k['h2']))
        rows = [["Bon", "Client / appareil", "Mécaniciens", "Statut", "Temps passé", "Coût"]]
        for j in unb:
            rows.append([j['job'], Pa(' — '.join(x for x in (j['client'], j['item']) if x) or '—', k['cell']), Pa(j['mechs'], k['cell']), j['status'], _hm(j['seconds']), _m(j['cost'])])
        t = Tb(rows, colWidths=[16 * k['mm'], 80 * k['mm'], 60 * k['mm'], 26 * k['mm'], 24 * k['mm'], 24 * k['mm']], repeatRows=1)
        t.setStyle(TS(k['base'] + [('ALIGN', (4, 0), (-1, -1), 'RIGHT')])); story.append(t)
    story.append(_pdf_disclaimer())
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


def _at_shop_avg(r):
    ms = [m for m in r['mechanics'] if m['seconds'] >= 60] or r['mechanics']
    n = len(ms) or 1
    T = r['totals']
    return {'yield': T['yield'], 'real_rate': T['effective_rate'], 'jobs_count': round(sum(m['jobs_count'] for m in ms) / n, 1),
            'avg_job_seconds': sum(m['avg_job_seconds'] for m in ms) / n,
            'over_pct': round(sum(m['over_count'] for m in ms) / max(1, sum(m['billed_count'] for m in ms)) * 100),
            'problems': round(sum(m['problems'] for m in ms) / n, 1), 'corrections': round(sum(m['corrections'] for m in ms) / n, 1),
            'margin_pct': round(T['margin'] / T['billed'] * 100, 1) if T['billed'] else None}


def export_atelier_eval_pdf(r, mech_ids=None, show_cost=True, show_detail=True):
    k = _at_pdf_kit(); out = PDF_DIR / "Atelier"; out.mkdir(exist_ok=True)
    ms = [m for m in r['mechanics'] if not mech_ids or m['id'] in mech_ids]
    tag = 'tous' if not mech_ids or len(ms) != 1 else re.sub(r'[^A-Za-z0-9]+', '_', ms[0]['name'])
    path = out / f"Evaluation_{tag}_{r['start']}_au_{r['end']}.pdf"
    g = datetime.datetime.now()
    doc, header = _at_doc(path, k, "Fiche d'évaluation — performance en atelier", f"{_period_txt(r)} — généré le {g:%d-%m-%Y à %H:%M}")
    Tb, TS, Pa, C, mm = k['Table'], k['TableStyle'], k['Paragraph'], k['colors'], k['mm']
    avg = _at_shop_avg(r)
    from reportlab.platypus import KeepInFrame
    pw, ph = k['letter']
    story = []
    for idx, m in enumerate(ms):
        page_start = len(story)
        pv = r.get('prev', {}).get('mechanics', {}).get(m['id'], {})
        over_pct = round(m['over_count'] / m['billed_count'] * 100) if m['billed_count'] else None
        story.append(Pa(f"{m['name']}", k['h1']))
        story.append(Pa(f"{_period_txt(r)} · période précédente : du {_d(r['prev']['start'])} au {_d(r['prev']['end'])}", k['small']))
        story.append(k['Spacer'](1, 6))
        boxes = [["Heures punchées", "Heures facturées", "Rendement", "Taux horaire réel"],
                 [_hm(m['seconds']), _hm(m['billed_minutes'] * 60), _pc(m['yield']), (_m(m['real_rate']) + '/h') if m['real_rate'] else '—']]
        if show_cost:
            boxes += [["Coût du temps", "Main-d'œuvre facturée", "Marge", "Coût du temps dépassé"],
                      [_m(m['cost']), _m(m['billed']), f"{_m(m['margin'])} ({_pc(m['margin_pct'])})", _m(m['lost_cost'])]]
        t = Tb(boxes, colWidths=[45 * mm] * 4)
        st_ = [('FONTSIZE', (0, 0), (-1, -1), 8), ('ALIGN', (0, 0), (-1, -1), 'CENTER'), ('BOX', (0, 0), (-1, -1), .5, C.HexColor('#cbd5e1')),
               ('INNERGRID', (0, 0), (-1, -1), .25, C.HexColor('#e5e7eb')), ('TEXTCOLOR', (0, 0), (-1, 0), C.HexColor('#4b5563')),
               ('FONTNAME', (0, 1), (-1, 1), 'Helvetica-Bold'), ('FONTSIZE', (0, 1), (-1, 1), 13), ('TOPPADDING', (0, 1), (-1, 1), 6), ('BOTTOMPADDING', (0, 1), (-1, 1), 6)]
        if show_cost:
            st_ += [('TEXTCOLOR', (0, 2), (-1, 2), C.HexColor('#4b5563')), ('FONTNAME', (0, 3), (-1, 3), 'Helvetica-Bold'), ('FONTSIZE', (0, 3), (-1, 3), 11),
                    ('TOPPADDING', (0, 3), (-1, 3), 5), ('BOTTOMPADDING', (0, 3), (-1, 3), 5)]
        t.setStyle(TS(st_)); story += [t]
        story.append(Pa("Comparaison", k['h2']))
        num = lambda v: f"{v:g}".replace('.', ',')
        cmp = [["Indicateur", "Ce mécanicien", "Moyenne de l'atelier", "Période précédente", "Tendance"],
               ["Rendement (facturé ÷ punché)", _pc(m['yield']), _pc(avg['yield']), _pc(pv.get('yield')), _trend(m['yield'], pv.get('yield'), True, lambda v: f"{v:g} pts")],
               ["Taux horaire réel", (_m(m['real_rate']) + '/h') if m['real_rate'] else '—', (_m(avg['real_rate']) + '/h') if avg['real_rate'] else '—',
                (_m(pv.get('real_rate')) + '/h') if pv.get('real_rate') else '—', _trend(m['real_rate'], pv.get('real_rate'), True, _m)],
               ["Bons travaillés", m['jobs_count'], num(avg['jobs_count']), pv.get('jobs_count', '—'), _trend(m['jobs_count'], pv.get('jobs_count'), True, lambda v: f"{v:g}")],
               ["Temps moyen par bon", _hm(m['avg_job_seconds']), _hm(avg['avg_job_seconds']), '—', ''],
               ["Bons dépassant le temps facturé (+15 min)", f"{m['over_count']} / {m['billed_count']}" + (f" ({over_pct} %)" if over_pct is not None else ''), f"{avg['over_pct']} %", '—', ''],
               ["Problèmes signalés", m['problems'], num(avg['problems']), '—', ''],
               ["Punchs corrigés par un gestionnaire", m['corrections'], num(avg['corrections']), '—', '']]
        if show_cost:
            cmp.insert(3, ["Marge sur la main-d'œuvre", _pc(m['margin_pct']), _pc(avg['margin_pct']), '—', ''])
        t = Tb(cmp, colWidths=[62 * mm, 30 * mm, 32 * mm, 30 * mm, 26 * mm])
        t.setStyle(TS(k['base'] + [('ALIGN', (1, 0), (-1, -1), 'CENTER')])); story.append(t)
        obs = []
        if m['yield'] is not None:
            obs.append(f"Rendement {'au-dessus' if m['yield'] >= 100 else 'sous'} du temps facturé ({_pc(m['yield'])}" + (f", moyenne de l'atelier {_pc(avg['yield'])})." if avg['yield'] else ")."))
        if over_pct is not None and over_pct >= 30:
            obs.append(f"{m['over_count']} bon(s) sur {m['billed_count']} dépassent le temps facturé de plus de 15 minutes : à revoir (estimation, pièces, méthode).")
        if m['corrections'] >= 3:
            obs.append(f"{m['corrections']} punch(s) ont dû être corrigés : rappeler l'importance de puncher au début et à la fin.")
        if m['unbilled_count']:
            obs.append(f"{m['unbilled_count']} bon(s) travaillé(s) pas encore facturé(s) : ils ne comptent pas dans le rendement.")
        if obs:
            story.append(Pa("Observations automatiques (à valider par le responsable)", k['h2']))
            for o in obs:
                story.append(Pa('• ' + o, k['small']))
        if show_detail and m['jobs']:
            story.append(Pa("Bons avec le plus grand écart", k['h2']))
            hd = ["Bon", "Client / appareil", "Temps passé", "Temps facturé", "Écart"] + (["Marge"] if show_cost else [])
            rows = [hd]
            for j in [x for x in m['jobs'] if x['gap_minutes'] is not None][:5]:
                rows.append([j['job'] + (' *' if j['shared'] else ''), Pa(' — '.join(x for x in (j['client'], j['item']) if x) or '—', k['cell']), _hm(j['seconds']),
                             f"{round(j['billed_minutes'] or 0)} min", _gap(j['gap_minutes'])] + ([_m(j['margin'])] if show_cost else []))
            if len(rows) > 1:
                cw = [16 * mm, (74 if show_cost else 98) * mm, 24 * mm, 24 * mm, 22 * mm] + ([24 * mm] if show_cost else [])
                t = Tb(rows, colWidths=cw, repeatRows=1); t.setStyle(TS(k['base'] + [('ALIGN', (2, 0), (-1, -1), 'RIGHT')])); story.append(t)
                story.append(Pa("* bon partagé avec un autre mécanicien : le temps facturé est réparti selon le temps de chacun.", k['small']))
        story.append(Pa("Commentaires du responsable", k['h2']))
        lines = Tb([[''] for _ in range(3)], colWidths=[180 * mm], rowHeights=[7 * mm] * 3)
        lines.setStyle(TS([('LINEBELOW', (0, 0), (-1, -1), .5, C.HexColor('#9ca3af'))])); story.append(lines)
        sig = Tb([["Signature du responsable", "", "Signature de l'employé", "", "Date"], ["", "", "", "", ""]], colWidths=[52 * mm, 8 * mm, 52 * mm, 8 * mm, 60 * mm], rowHeights=[6 * mm, 12 * mm])
        sig.setStyle(TS([('FONTSIZE', (0, 0), (-1, -1), 8), ('TEXTCOLOR', (0, 0), (-1, 0), C.HexColor('#4b5563')),
                         ('LINEBELOW', (0, 1), (0, 1), .5, C.black), ('LINEBELOW', (2, 1), (2, 1), .5, C.black), ('LINEBELOW', (4, 1), (4, 1), .5, C.black)]))
        story += [k['Spacer'](1, 4), sig, _pdf_disclaimer(10, 6.5)]
        parts = []
        for f_ in story[page_start:]:                               # KeepInFrame n'accepte pas les KeepTogether
            parts.extend(getattr(f_, '_content', None) or [f_])
        del story[page_start:]                                      # une page par mécanicien : réduit au besoin
        story.append(KeepInFrame(pw - 28 * mm - 2, ph - 44 * mm - 6, parts, mode='shrink'))
        if idx < len(ms) - 1:
            story.append(k['PageBreak']())
    if not ms:
        story.append(Pa("Aucun temps punché pour ce mécanicien dans la période.", k['small']))
    doc.build(story, onFirstPage=header, onLaterPages=header)
    return path


def hr_allowed():
    return bool(session.get('is_admin')) or 'rh' in (session.get('permissions') or [])


HT_DROP_DIR = BASE_DIR / "Import_HubTiger"


HT_PENDING = BASE_DIR / "_import_hubtiger_attente.json"


HT_COLS = {'job': 'job card #', 'booked': 'booked in date', 'sched': 'scheduled date', 'client': 'customer', 'item': 'item',
           'serial': 'serial nr', 'services': 'service types', 'done': 'job completed'}


def _ht_clean(s):
    s = re.sub(r'-{4,}', '', str(s or ''))
    s = re.sub(r'\s+', ' ', s).strip()
    return re.sub(r'\s*-\s*$', '', s).strip()


def _ht_date(s):
    s = str(s or '').strip()[:10].replace('/', '-')
    try:
        return datetime.date.fromisoformat(s).isoformat()
    except ValueError:
        return None


def ht_parse(path):
    """Lit l'export HubTiger (xlsx ou csv). Retourne une liste de bons {job, client, item, work, serial, due, booked, done}."""
    rows = []
    if str(path).lower().endswith('.csv'):
        import csv as _csv
        with open(path, newline='', encoding='utf-8-sig') as f:
            rows = [r for r in _csv.reader(f)]
    else:
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True, data_only=True)
        rows = [list(r) for r in wb.worksheets[0].iter_rows(values_only=True)]
        wb.close()
    head_i = next((i for i, r in enumerate(rows[:10]) if any(str(c or '').strip().lower() == 'job card #' for c in r)), None)
    if head_i is None:
        raise ValueError("Ce fichier ne ressemble pas à l'export « Jobs booked in detail » de HubTiger (colonne « Job Card # » introuvable).")
    head = [str(c or '').strip().lower() for c in rows[head_i]]
    idx = {k: head.index(v) for k, v in HT_COLS.items() if v in head}
    if 'job' not in idx:
        raise ValueError("Colonne « Job Card # » introuvable.")
    get = lambda r, k: (r[idx[k]] if k in idx and idx[k] < len(r) else None)
    out, seen = [], set()
    for r in rows[head_i + 1:]:
        job = at_norm_job(get(r, 'job'))
        if not job or job in seen:
            continue
        seen.add(job)
        svc = [s.strip() for s in str(get(r, 'services') or '').split(';') if s.strip()]
        serial = _ht_clean(get(r, 'serial'))
        if serial.upper() in ('TBD', 'NON IDENTIFIER', 'N/A'):
            serial = ''
        out.append({'job': job, 'client': _ht_clean(get(r, 'client'))[:120], 'item': _ht_clean(get(r, 'item'))[:160],
                    'work': ' · '.join(svc)[:400], 'serial': serial[:80], 'due': _ht_date(get(r, 'sched')),
                    'booked': _ht_date(get(r, 'booked')), 'done': str(get(r, 'done') or '').strip().lower() in ('yes', 'oui', 'true', '1')})
    return out


def ht_plan(conn, items, include_done=True):
    """Ce que l'import ferait, sans rien écrire."""
    plan = {'new_open': [], 'new_done': [], 'update': [], 'complete': [], 'same': 0, 'skipped_done': 0}
    open_punch = {r['job'] for r in conn.execute("SELECT DISTINCT job FROM shop_punches WHERE end_at IS NULL").fetchall()}
    for it in items:
        ex = conn.execute("SELECT * FROM shop_jobs WHERE job=?", (it['job'],)).fetchone()
        if not ex:
            if it['done'] and not include_done:
                plan['skipped_done'] += 1
            else:
                plan['new_done' if it['done'] else 'new_open'].append(it)
            continue
        fill = {k: it[v] for k, v in (('client', 'client'), ('item', 'item'), ('work', 'work'), ('due_date', 'due')) if not ex[k] and it[v]}
        finish = it['done'] and ex['status'] in ('ouvert', 'en_cours') and it['job'] not in open_punch
        if fill:
            plan['update'].append(dict(it, fill=fill))
        if finish:
            plan['complete'].append(it)
        if not fill and not finish:
            plan['same'] += 1
    return plan


def ht_apply(conn, plan, who):
    now = _at_now()
    for it in plan['new_open'] + plan['new_done']:
        conn.execute("INSERT INTO shop_jobs(job, client, item, work, due_date, status, created_by, created_at, updated_at, notes, position, priority) "
                     "VALUES (?,?,?,?,?,?,?,?,?,?,?, 'normal')",
                     (it['job'], it['client'] or None, it['item'] or None, it['work'] or None, it['due'], 'termine' if it['done'] else 'ouvert',
                      'HubTiger (import)', (it['booked'] or now[:10]) + ' 00:00:00',
                      # bon déjà terminé : HubTiger ne donne pas la date de fin, la date prévue s'en approche le plus
                      ((min(it['due'] or it['booked'] or now[:10], now[:10]) + ' 12:00:00') if it['done'] else now),
                      (f"N° de série : {it['serial']}" if it['serial'] else None), _at_next_position(conn, None)))
    for it in plan['update']:
        sets = ', '.join(f"{k}=COALESCE(NULLIF({k}, ''), ?)" for k in it['fill'])
        conn.execute(f"UPDATE shop_jobs SET {sets}, updated_at=? WHERE job=?", list(it['fill'].values()) + [now, it['job']])
    for it in plan['complete']:
        conn.execute("UPDATE shop_jobs SET status='termine', updated_at=? WHERE job=? AND status IN ('ouvert','en_cours')", (now, it['job']))
    conn.commit()
    res = {'created': len(plan['new_open']) + len(plan['new_done']), 'created_open': len(plan['new_open']), 'updated': len(plan['update']),
           'completed': len(plan['complete']), 'same': plan['same']}
    db_add_audit(who, 'Atelier : import HubTiger', f"{res['created']} bon(s) créé(s) dont {res['created_open']} ouvert(s), "
                                                    f"{res['updated']} complété(s), {res['completed']} terminé(s), {res['same']} inchangé(s)")
    return res


def ht_summary(plan):
    return {'new_open': len(plan['new_open']), 'new_done': len(plan['new_done']), 'update': len(plan['update']), 'complete': len(plan['complete']),
            'same': plan['same'], 'skipped_done': plan['skipped_done'],
            'sample_new': [{k: it[k] for k in ('job', 'client', 'item', 'work', 'due')} for it in plan['new_open'][:12]],
            'sample_complete': [it['job'] for it in plan['complete'][:20]]}


@app.route('/atelier/punch')
def atelier_punch_page():
    cle = request.args.get('cle')
    if cle:                                   # lien direct : autorise cette tablette
        if secrets.compare_digest(cle, kiosk_link_token()):
            db_add_audit('Poste de punch', 'Tablette autorisée (lien direct)', client_ip())
            return kiosk_authorize(redirect(url_for('atelier_punch_page')))
        return render_template('atelier_kiosk_login.html', company=get_company_name(), error="Ce lien n'est plus valide.")
    if not kiosk_allowed():
        return render_template('atelier_kiosk_login.html', company=get_company_name(), error=None)
    return render_template('atelier_punch.html', company=get_company_name(), device_only=not session.get('user_id'))


@app.route('/atelier')
def atelier_page():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    return render_template('atelier.html', company=get_company_name(), is_admin=bool(session.get('is_admin')),
                           can_profit=bool(session.get('is_admin')) or 'atelier_profit' in (session.get('permissions') or []),
                           can_rh=bool(session.get('is_admin')) or 'rh' in (session.get('permissions') or []))


@app.route('/api/atelier/kiosk')
def api_atelier_kiosk():
    if not kiosk_allowed():
        return jsonify({'error': 'Poste de punch non autorisé.'}), 401
    conn = get_conn()
    try:
        return jsonify({'mechanics': [at_mech_state(conn, m) for m in at_mechanics()], 'now': _at_now(), 'idle_minutes': kiosk_idle_minutes()})
    finally:
        conn.close()


@app.route('/api/atelier/punch', methods=['POST'])
def api_atelier_punch():
    if not kiosk_allowed():
        return jsonify({'error': 'Poste de punch non autorisé.'}), 401
    d = request.get_json(silent=True) or {}
    try:
        mid = int(d.get('mechanic_id'))
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Mécanicien inconnu.'}), 400
    m, err = at_verify_pin(mid, d.get('pin'))
    if err:
        return jsonify({'ok': False, 'error': err, 'pin': True}), 403
    if d.get('action') == 'login':
        conn = get_conn()
        try:
            return jsonify({'ok': True, 'state': at_mech_state(conn, m)})
        finally:
            conn.close()
    return jsonify(at_punch(mid, d.get('action'), d.get('job'), d.get('mode')))


@app.route('/api/atelier/live')
def api_atelier_live():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    return jsonify(at_live(request.args))


@app.route('/api/atelier/punches')
def api_atelier_punches():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d0, d1 = _at_period(request.args)
    a, b = d0.strftime('%Y-%m-%d 00:00:00'), (d1 + datetime.timedelta(days=1)).strftime('%Y-%m-%d 00:00:00')
    conn = get_conn()
    rows = [dict(r) for r in conn.execute("SELECT p.*, m.name FROM shop_punches p JOIN shop_mechanics m ON m.id=p.mechanic_id "
                                          "WHERE p.start_at < ? AND (p.end_at IS NULL OR p.end_at >= ?) ORDER BY p.start_at DESC",
                                          (b, a)).fetchall()]
    conn.close()
    return jsonify({'start': d0.isoformat(), 'end': d1.isoformat(), 'punches': rows,
                    'mechanics': [{'id': m['id'], 'name': m['name']} for m in at_mechanics(True)]})


def _at_parse_dt(v):
    v = (v or '').strip().replace('T', ' ')
    if not v:
        return None
    if len(v) == 16:
        v += ':00'
    return _at_dt(v).strftime(AT_FMT)


@app.route('/api/atelier/punches', methods=['POST'])
@app.route('/api/atelier/punches/<int:pid>', methods=['PUT', 'DELETE'])
def api_atelier_punch_edit(pid=None):
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        old = dict(conn.execute("SELECT * FROM shop_punches WHERE id=?", (pid,)).fetchone() or {}) if pid else None
        if pid and not old:
            return jsonify({'ok': False, 'error': 'Punch introuvable.'}), 404
        if request.method == 'DELETE':
            conn.execute("DELETE FROM shop_punches WHERE id=?", (pid,))
            conn.commit()
            log_audit('Atelier : punch supprimé', f"bon {old['job']}, {old['start_at']} → {old['end_at'] or 'ouvert'}")
            return jsonify({'ok': True})
        d = request.get_json(silent=True) or {}
        try:
            start, end = _at_parse_dt(d.get('start_at')), _at_parse_dt(d.get('end_at'))
            mid = int(d.get('mechanic_id') or (old or {}).get('mechanic_id'))
        except (TypeError, ValueError):
            return jsonify({'ok': False, 'error': 'Date ou mécanicien invalide.'}), 400
        job = at_norm_job(d.get('job') or (old or {}).get('job'))
        if not start or not job:
            return jsonify({'ok': False, 'error': 'Le bon et le début sont requis.'}), 400
        if end and end <= start:
            return jsonify({'ok': False, 'error': 'La fin doit être après le début.'}), 400
        ended_by = d.get('ended_by') if d.get('ended_by') in ('pause', 'fin') else ('fin' if end else None)
        if pid:
            conn.execute("UPDATE shop_punches SET mechanic_id=?, job=?, start_at=?, end_at=?, ended_by=?, corrected_by=?, corrected_at=? WHERE id=?",
                         (mid, job, start, end, ended_by, session.get('username'), _at_now(), pid))
            conn.commit()
            log_audit('Atelier : punch corrigé', f"bon {old['job']} {old['start_at']} → {old['end_at'] or 'ouvert'} devient bon {job} {start} → {end or 'ouvert'}")
        else:
            conn.execute("INSERT INTO shop_punches(mechanic_id, job, start_at, end_at, ended_by, created_by, corrected_by, corrected_at) "
                         "VALUES (?,?,?,?,?,?,?,?)", (mid, job, start, end, ended_by, 'manuel', session.get('username'), _at_now()))
            conn.commit()
            log_audit('Atelier : punch ajouté', f"bon {job} {start} → {end or 'ouvert'}")
        conn.commit()
        return jsonify({'ok': True})
    finally:
        conn.close()


@app.route('/api/atelier/jobs/<job>/manual', methods=['GET', 'POST'])
def api_atelier_job_manual(job):
    """1.41.0 : le responsable ajoute du temps oublié sur un bon et/ou le termine."""
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    job = at_norm_job(job)
    conn = get_conn()
    try:
        j = conn.execute("SELECT * FROM shop_jobs WHERE job=?", (job,)).fetchone()
        open_p = [dict(r) for r in conn.execute(
            "SELECT p.id, p.start_at, p.mechanic_id, m.name FROM shop_punches p LEFT JOIN shop_mechanics m ON m.id=p.mechanic_id "
            "WHERE p.job=? AND p.end_at IS NULL", (job,)).fetchall()]
        if request.method == 'GET':
            m = re.search(r'Service\s+(\d+)\s*min', (j['work'] if j else '') or '', re.I)
            return jsonify({'ok': True, 'job': job, 'exists': bool(j), 'status': j['status'] if j else None, 'mechanic_id': j['mechanic_id'] if j else None,
                            'seconds': _at_job_seconds(conn, job), 'suggest_minutes': int(m.group(1)) if m else None, 'open': open_p})
        d = request.get_json(silent=True) or {}
        try:
            minutes = int(d.get('minutes') or 0)
        except (TypeError, ValueError):
            return jsonify({'ok': False, 'error': 'Durée invalide.'}), 400
        finish = bool(d.get('finish'))
        reason = str(d.get('reason') or '').strip()[:200]
        if minutes < 0 or minutes > 16 * 60:
            return jsonify({'ok': False, 'error': 'La durée doit être entre 1 minute et 16 heures.'}), 400
        if not minutes and not finish:
            return jsonify({'ok': False, 'error': 'Indique une durée, ou coche « Marquer le bon terminé ».'}), 400
        if minutes and not reason:
            return jsonify({'ok': False, 'error': 'Indique la raison (ex. oubli de punch).'}), 400
        who = current_display_name()
        done = []
        if minutes:
            try:
                mid = int(d.get('mechanic_id'))
                start = datetime.datetime.strptime(f"{d.get('date')} {d.get('start')}", '%Y-%m-%d %H:%M')
            except (TypeError, ValueError):
                return jsonify({'ok': False, 'error': 'Choisis le mécanicien, la date et l\u2019heure de début.'}), 400
            if not conn.execute("SELECT 1 FROM shop_mechanics WHERE id=?", (mid,)).fetchone():
                return jsonify({'ok': False, 'error': 'Mécanicien introuvable.'}), 400
            end = start + datetime.timedelta(minutes=minutes)
            if end > datetime.datetime.now() + datetime.timedelta(minutes=5):
                return jsonify({'ok': False, 'error': 'Ce temps finirait dans le futur : vérifie la date et l\u2019heure de début.'}), 400
            clash = conn.execute("SELECT job, start_at, end_at FROM shop_punches WHERE mechanic_id=? AND start_at < ? AND COALESCE(end_at, ?) > ?",
                                 (mid, end.strftime(AT_FMT), _at_now(), start.strftime(AT_FMT))).fetchone()
            if clash:
                return jsonify({'ok': False, 'error': f"Ce mécanicien a déjà du temps punché dans cette plage (bon {clash['job']}, "
                                                      f"{clash['start_at'][11:16]} à {(clash['end_at'] or 'en cours')[11:16]}). Choisis une autre heure de début."}), 400
            conn.execute("INSERT INTO shop_punches(mechanic_id, job, start_at, end_at, ended_by, created_by, corrected_by, corrected_at) VALUES (?,?,?,?,?,?,?,?)",
                         (mid, job, start.strftime(AT_FMT), end.strftime(AT_FMT), 'fin' if finish else 'pause', 'manuel (responsable)', who, _at_now()))
            done.append(f"{minutes} min ajoutées le {start:%Y-%m-%d} de {start:%H:%M} à {end:%H:%M} (mécanicien #{mid}) — {reason}")
        if finish:
            closes = d.get('close') or {}
            for p in open_p:                                   # punch oublié ouvert : fermé à l'heure indiquée par le responsable
                try:
                    end_p = datetime.datetime.strptime(str(closes.get(str(p['id'])) or ''), '%Y-%m-%dT%H:%M')
                except ValueError:
                    return jsonify({'ok': False, 'error': f"Indique l'heure de fin du punch oublié de {p['name'] or 'ce mécanicien'}."}), 400
                st_p = datetime.datetime.strptime(p['start_at'], AT_FMT)
                if end_p <= st_p or end_p > datetime.datetime.now() + datetime.timedelta(minutes=1):
                    return jsonify({'ok': False, 'error': f"L'heure de fin du punch de {p['name'] or 'ce mécanicien'} doit être après son début "
                                                          f"({p['start_at'][:16]}) et pas dans le futur."}), 400
                conn.execute("UPDATE shop_punches SET end_at=?, ended_by='fin', corrected_by=?, corrected_at=? WHERE id=?",
                             (end_p.strftime(AT_FMT), who, _at_now(), p['id']))
                done.append(f"punch oublié de {p['name'] or 'mécanicien'} fermé : {p['start_at'][:16]} → {end_p:%Y-%m-%d %H:%M}")
            if j:
                conn.execute("UPDATE shop_jobs SET status='termine', updated_at=? WHERE job=?", (_at_now(), job))
            else:
                conn.execute("INSERT INTO shop_jobs(job, status, created_by, created_at, updated_at, position, priority) VALUES (?,?,?,?,?,?, 'normal')",
                             (job, 'termine', who, _at_now(), _at_now(), _at_next_position(conn, None)))
            done.append('bon marqué terminé')
        conn.commit()
        secs = _at_job_seconds(conn, job)
    finally:
        conn.close()
    log_audit('Atelier : temps ajouté / bon terminé par le responsable', f"bon {job} — " + ' ; '.join(done))
    return jsonify({'ok': True, 'seconds': secs, 'done': done})


@app.route('/api/atelier/profit')
def api_atelier_profit():
    resp = permission_required_check('atelier_profit')
    if resp is not None:
        return resp
    return jsonify(at_profit_compare(request.args))


@app.route('/api/atelier/billing/<job>', methods=['POST', 'DELETE'])
def api_atelier_billing(job):
    resp = permission_required_check('atelier_profit')
    if resp is not None:
        return resp
    job = at_norm_job(job)
    conn = get_conn()
    try:
        if request.method == 'DELETE':
            conn.execute("DELETE FROM shop_billing WHERE job=?", (job,))
            conn.commit()
            log_audit('Atelier : facturé manuel retiré', f"bon {job}")
            return jsonify({'ok': True})
        d = request.get_json(silent=True) or {}
        try:
            minutes, amount = float(d.get('minutes') or 0), float(d.get('amount') or 0)
        except (TypeError, ValueError):
            return jsonify({'ok': False, 'error': 'Montant ou minutes invalides.'}), 400
        conn.execute("INSERT OR REPLACE INTO shop_billing(job, billed_minutes, billed_amount, note, username, updated_at) VALUES (?,?,?,?,?,?)",
                     (job, minutes, amount, (d.get('note') or '')[:200], session.get('username'), _at_now()))
        conn.commit()
        log_audit('Atelier : facturé saisi à la main', f"bon {job} : {minutes:g} min, {_fmt_money_fr(amount)}")
        return jsonify({'ok': True})
    finally:
        conn.close()


@app.route('/api/atelier/jobs/<job>/move', methods=['POST'])
def api_atelier_job_move(job):
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    up = (request.get_json(silent=True) or {}).get('dir') == 'up'
    job = at_norm_job(job)
    conn = get_conn()
    try:
        j = conn.execute("SELECT * FROM shop_jobs WHERE job=?", (job,)).fetchone()
        if not j:
            return jsonify({'ok': False, 'error': 'Bon introuvable.'}), 404
        lst = [r['job'] for r in conn.execute("SELECT job FROM shop_jobs WHERE COALESCE(mechanic_id,0)=COALESCE(?,0) "
                                              "AND status IN ('ouvert','en_cours') ORDER BY position, COALESCE(due_date,'9999'), created_at",
                                              (j['mechanic_id'],)).fetchall()]
        i = lst.index(job) if job in lst else -1
        k = i - 1 if up else i + 1
        if i < 0 or k < 0 or k >= len(lst):
            return jsonify({'ok': True})
        lst[i], lst[k] = lst[k], lst[i]
        for pos, jb in enumerate(lst, start=1):           # renumérote proprement la liste du mécanicien
            conn.execute("UPDATE shop_jobs SET position=? WHERE job=?", (pos, jb))
        conn.commit()
        return jsonify({'ok': True})
    finally:
        conn.close()


@app.route('/api/atelier/jobs/<job>/place', methods=['POST'])
def api_atelier_job_place(job):
    """Glisser-déposer : attribue le bon à un mécanicien (ou à personne), à un rang de sa liste,
    et, si « work_date » est fourni, à une journée de travail (vide = à planifier)."""
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    job = at_norm_job(job)
    try:
        mid = int(d['mechanic_id']) if d.get('mechanic_id') not in (None, '') else None
        index = int(d['index']) if d.get('index') not in (None, '') else None
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Valeurs invalides.'}), 400
    wd = None
    if 'work_date' in d:
        wd = (d.get('work_date') or '').strip() or ''
        if wd:
            try:
                datetime.date.fromisoformat(wd)
            except ValueError:
                return jsonify({'ok': False, 'error': 'Date de travail invalide.'}), 400
    conn = get_conn()
    try:
        j = conn.execute("SELECT * FROM shop_jobs WHERE job=?", (job,)).fetchone()
        if not j:
            return jsonify({'ok': False, 'error': 'Bon introuvable.'}), 404
        if mid is not None and not conn.execute("SELECT 1 FROM shop_mechanics WHERE id=?", (mid,)).fetchone():
            return jsonify({'ok': False, 'error': 'Mécanicien introuvable.'}), 404
        lst = [r['job'] for r in conn.execute("SELECT job FROM shop_jobs WHERE COALESCE(mechanic_id,0)=COALESCE(?,0) AND job<>? "
                                              "AND status IN ('ouvert','en_cours') ORDER BY position, COALESCE(due_date,'9999'), created_at",
                                              (mid, job)).fetchall()]
        lst.insert(len(lst) if index is None else max(0, min(index, len(lst))), job)
        for pos, jb in enumerate(lst, start=1):
            conn.execute("UPDATE shop_jobs SET position=? WHERE job=?", (pos, jb))
        conn.execute("UPDATE shop_jobs SET mechanic_id=?, updated_at=?" + (", work_date=?" if wd is not None else "") + " WHERE job=?",
                     ((mid, _at_now()) + ((wd or None,) if wd is not None else ()) + (job,)))
        conn.commit()
        names = {m['id']: m['name'] for m in at_mechanics(True)}
    finally:
        conn.close()
    changes = []
    if j['mechanic_id'] != mid:
        changes.append('attribué à ' + names.get(mid, 'personne'))
    if wd is not None and (j['work_date'] or '') != wd:
        changes.append(('planifié le ' + wd) if wd else 'retiré du calendrier')
    if changes:
        log_audit('Atelier : bon de travail déplacé', f"bon {job} — " + ', '.join(changes))
    return jsonify({'ok': True})


@app.route('/api/atelier/jobs/<job>', methods=['DELETE'])
def api_atelier_job_delete(job):
    resp = admin_required_check()
    if resp is not None:
        return resp
    job = at_norm_job(job)
    conn = get_conn()
    try:
        j = conn.execute("SELECT * FROM shop_jobs WHERE job=?", (job,)).fetchone()
        if not j:
            return jsonify({'ok': False, 'error': 'Bon introuvable.'}), 404
        conn.execute("DELETE FROM shop_jobs WHERE job=?", (job,))
        conn.commit()
    finally:
        conn.close()
    log_audit('Atelier : bon de travail supprimé', f"bon {job} — {j['client'] or ''} {j['item'] or ''}".strip())
    return jsonify({'ok': True})


@app.route('/api/atelier/sale-link', methods=['POST'])
def api_atelier_sale_link():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    line = str(d.get('line') or '')
    action = d.get('action')
    conn = get_conn()
    try:
        r = conn.execute("SELECT sale_id, descr FROM sales_lines WHERE sale_line_id=?", (line,)).fetchone()
        if not r:
            return jsonify({'ok': False, 'error': 'Ligne de vente introuvable.'}), 404
        if action == 'link':
            job = at_norm_job(d.get('job'))
            if not job:
                return jsonify({'ok': False, 'error': 'Entre le numéro du bon.'}), 400
            conn.execute("INSERT OR REPLACE INTO shop_sale_links(sale_line_id, job, ignored, username, updated_at) VALUES (?,?,0,?,?)",
                         (line, job, session.get('username'), _at_now()))
            msg = f"vente {r['sale_id']} associée au bon {job}"
        elif action == 'ignore':
            conn.execute("INSERT OR REPLACE INTO shop_sale_links(sale_line_id, job, ignored, username, updated_at) VALUES (?,NULL,1,?,?)",
                         (line, session.get('username'), _at_now()))
            msg = f"vente {r['sale_id']} ignorée"
        elif action == 'reset':
            conn.execute("DELETE FROM shop_sale_links WHERE sale_line_id=?", (line,))
            msg = f"vente {r['sale_id']} : association retirée"
        else:
            return jsonify({'ok': False, 'error': 'Action inconnue.'}), 400
        conn.commit()
    finally:
        conn.close()
    log_audit('Atelier : service facturé', f"{msg} — {(r['descr'] or '')[:80]}")
    return jsonify({'ok': True})


@app.route('/api/atelier/unmatched')
def api_atelier_unmatched():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d0, d1 = _at_period(request.args)
    return jsonify({'start': d0.isoformat(), 'end': d1.isoformat(), 'unmatched': at_unmatched(d0, d1),
                    'missing_days': len([d for d in store_missing_days(d0, d1, need_ws=True) if d < datetime.date.today()]),
                    'auto': at_reread_cfg(), 'connected': ls_config()['connected']})


@app.route('/api/atelier/auto-reread', methods=['POST'])
def api_atelier_auto_reread():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    try:
        days = max(1, min(31, int(d.get('days') or 7)))
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Nombre de jours invalide.'}), 400
    meta_set('atelier_reread_enabled', '1' if d.get('enabled') else '0')
    meta_set('atelier_reread_days', days)
    log_audit('Atelier : relecture automatique des ventes', ('activée' if d.get('enabled') else 'désactivée') + f", {days} derniers jours")
    return jsonify({'ok': True, 'auto': at_reread_cfg()})


@app.route('/api/atelier/ignored')
def api_atelier_ignored():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d0, d1 = _at_period(request.args)
    conn = get_conn()
    rows = [dict(r) for r in conn.execute(
        "SELECT l.sale_line_id line, l.sale_id sale, l.sale_date date, l.descr, l.svc_minutes minutes, l.total amount, k.username, k.updated_at "
        "FROM shop_sale_links k JOIN sales_lines l ON l.sale_line_id=k.sale_line_id WHERE k.ignored=1 AND l.sale_date BETWEEN ? AND ? "
        "ORDER BY l.sale_date DESC", (d0.isoformat(), d1.isoformat())).fetchall()]
    conn.close()
    return jsonify({'rows': rows})


@app.route('/api/atelier/relire/status')
def api_atelier_relire_status():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    ss = _store_state
    return jsonify({'running': ss['running'], 'progress': ss['progress'], 'error': None if ss['running'] else ss['error']})


@app.route('/api/atelier/mechanics/<int:mid>', methods=['DELETE'])
def api_atelier_mechanic_delete(mid):
    resp = admin_required_check()
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        m = conn.execute("SELECT * FROM shop_mechanics WHERE id=?", (mid,)).fetchone()
        if not m:
            return jsonify({'ok': False, 'error': 'Mécanicien introuvable.'}), 404
        n = conn.execute("SELECT COUNT(*) FROM shop_punches WHERE mechanic_id=?", (mid,)).fetchone()[0]
        if n and request.args.get('force') != '1':
            return jsonify({'ok': False, 'punches': n,
                            'error': f"{m['name']} a {n} punch(s) enregistré(s)."}), 409
        conn.execute("DELETE FROM shop_punches WHERE mechanic_id=?", (mid,))
        conn.execute("UPDATE shop_jobs SET mechanic_id=NULL WHERE mechanic_id=?", (mid,))
        conn.execute("DELETE FROM shop_mechanics WHERE id=?", (mid,))
        conn.commit()
    finally:
        conn.close()
    log_audit('Atelier : mécanicien supprimé', f"{m['name']}" + (f" (et ses {n} punch(s))" if n else ''))
    return jsonify({'ok': True})


@app.route('/api/atelier/relire', methods=['POST'])
def api_atelier_relire():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d0, d1 = _at_period(request.get_json(silent=True) or {})
    if not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Kubios n'est pas connecté à Lightspeed."}), 400
    days = [d0 + datetime.timedelta(days=i) for i in range((d1 - d0).days + 1)]
    try:
        start_store_job('ventes de l\'atelier', days, session.get('username'))
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    return jsonify({'ok': True, 'days': len(days)})


@app.route('/api/atelier/mechanics', methods=['GET', 'POST'])
@app.route('/api/atelier/mechanics/<int:mid>', methods=['PUT'])
def api_atelier_mechanics(mid=None):
    resp = admin_required_check()
    if resp is not None:
        return resp
    if request.method == 'GET':
        return jsonify({'mechanics': [{k: m[k] for k in ('id', 'name', 'cost_rate', 'active', 'color')} | {'has_pin': bool(m['pin_hash'])}
                                      for m in at_mechanics(True)], 'default_rate': at_default_rate(),
                        'busy': _store_state['running']})
    d = request.get_json(silent=True) or {}
    if d.get('default_rate') is not None and mid is None and not d.get('name'):
        try:
            meta_set('atelier_cost_rate', float(d['default_rate']))
        except (TypeError, ValueError):
            return jsonify({'ok': False, 'error': 'Taux invalide.'}), 400
        log_audit('Atelier : taux coûtant par défaut modifié', str(d['default_rate']))
        return jsonify({'ok': True})
    name = (d.get('name') or '').strip()[:60]
    pin = str(d.get('pin') or '').strip()
    if pin and not re.fullmatch(r'\d{4,6}', pin):
        return jsonify({'ok': False, 'error': 'Le NIP doit avoir 4 à 6 chiffres.'}), 400
    try:
        rate = float(d['cost_rate']) if d.get('cost_rate') not in (None, '') else None
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Taux invalide.'}), 400
    conn = get_conn()
    try:
        if mid is None:
            if not name or not pin:
                return jsonify({'ok': False, 'error': 'Le nom et un NIP de 4 à 6 chiffres sont requis.'}), 400
            conn.execute("INSERT INTO shop_mechanics(name, pin_hash, cost_rate, active, color, created_at) VALUES (?,?,?,1,?,?)",
                         (name, generate_password_hash(pin), rate, d.get('color') or '#2563eb', _at_now()))
            conn.commit()
            log_audit('Atelier : mécanicien ajouté', name)
        else:
            old = conn.execute("SELECT * FROM shop_mechanics WHERE id=?", (mid,)).fetchone()
            if not old:
                return jsonify({'ok': False, 'error': 'Mécanicien introuvable.'}), 404
            conn.execute("UPDATE shop_mechanics SET name=?, cost_rate=?, active=?, color=? WHERE id=?",
                         (name or old['name'], rate, 1 if d.get('active', True) else 0, d.get('color') or old['color'], mid))
            if pin:
                conn.execute("UPDATE shop_mechanics SET pin_hash=? WHERE id=?", (generate_password_hash(pin), mid))
            conn.commit()
            log_audit('Atelier : mécanicien modifié', (name or old['name']) + (' (nouveau NIP)' if pin else ''))
        conn.commit()
        return jsonify({'ok': True})
    finally:
        conn.close()


@app.route('/atelier/punch/acces', methods=['POST'])
def atelier_kiosk_login():
    ip = client_ip()
    f = _kiosk_fail.get(ip, [0, 0])
    if f[0] >= 8 and time.time() - f[1] < 900:
        return render_template('atelier_kiosk_login.html', company=get_company_name(), error="Trop d'essais : réessaie dans 15 minutes.")
    h = meta_get('kiosk_code_hash')
    if h and check_password_hash(h, request.form.get('code', '')):
        _kiosk_fail.pop(ip, None)
        db_add_audit('Poste de punch', 'Tablette autorisée (code d\'accès)', ip)
        return kiosk_authorize(redirect(url_for('atelier_punch_page')))
    _kiosk_fail[ip] = [f[0] + 1 if time.time() - f[1] < 900 else 1, time.time()]
    return render_template('atelier_kiosk_login.html', company=get_company_name(),
                           error="Code incorrect." if h else "Aucun code d'accès n'est défini : un administrateur doit le créer dans Kubios → Atelier → Mécaniciens.")


@app.route('/atelier/punch/oublier')
def atelier_kiosk_forget():
    resp = redirect(url_for('atelier_punch_page'))
    resp.delete_cookie(KIOSK_COOKIE)
    return resp


KIOSK_IDLE_CHOICES = (1, 5, 30, 60, 240, 480)


def kiosk_idle_minutes():
    """Délai avant le retour automatique à l'accueil du poste de punch (1.34.0 : 4 h par défaut)."""
    try:
        v = int(meta_get('kiosk_idle_minutes') or 240)
    except ValueError:
        v = 240
    return v if v in KIOSK_IDLE_CHOICES else 240


@app.route('/api/atelier/kiosk-access', methods=['GET', 'POST'])
def api_atelier_kiosk_access():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if request.method == 'POST':
        d = request.get_json(silent=True) or {}
        if 'idle_minutes' in d:
            try:
                v = int(d['idle_minutes'])
            except (TypeError, ValueError):
                v = 0
            if v not in KIOSK_IDLE_CHOICES:
                return jsonify({'ok': False, 'error': 'Délai invalide.'}), 400
            meta_set('kiosk_idle_minutes', v)
            log_audit('Poste de punch : retour automatique à l\u2019accueil', f"après {v} min")
            return jsonify({'ok': True})
        if d.get('revoke'):
            meta_set('kiosk_secret', secrets.token_urlsafe(16))
            meta_set('kiosk_link_token', secrets.token_urlsafe(24))
            log_audit('Poste de punch : tablettes révoquées', 'nouveau lien direct créé')
            return jsonify({'ok': True})
        code = str(d.get('code') or '')
        if len(code) < 6:
            return jsonify({'ok': False, 'error': "Le code d'accès doit avoir au moins 6 caractères."}), 400
        meta_set('kiosk_code_hash', generate_password_hash(code))
        log_audit("Poste de punch : code d'accès modifié", '')
        return jsonify({'ok': True})
    return jsonify({'has_code': bool(meta_get('kiosk_code_hash')), 'idle_minutes': kiosk_idle_minutes(),
                    'link': request.host_url.rstrip('/') + url_for('atelier_punch_page') + '?cle=' + kiosk_link_token()})


@app.route('/api/atelier/jobs')
def api_atelier_jobs():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    a = request.args
    st = a.get('statut') or 'ouverts'
    done_expr = "COALESCE((SELECT MAX(p.end_at) FROM shop_punches p WHERE p.job=j.job AND p.ended_by='fin'), j.updated_at)"
    where, params = [], []
    if st == 'ouverts':
        where.append("j.status IN ('ouvert','en_cours')")
    elif st in ('termine', 'annule', 'en_cours'):
        where.append("j.status=?"); params.append(st)
    elif st == 'cal':                                   # calendrier : bons ouverts + ceux planifiés dans la semaine affichée
        where.append("(j.status IN ('ouvert','en_cours') OR j.work_date BETWEEN ? AND ?)"); params += [a.get('from') or '', a.get('to') or '']
    q = (a.get('q') or '').strip()
    if q:
        like = f"%{q}%"
        where.append("(j.job LIKE ? OR j.client LIKE ? OR j.item LIKE ? OR j.work LIKE ? OR j.notes LIKE ?)"); params += [like] * 5
    if a.get('mech') == 'none':
        where.append("j.mechanic_id IS NULL")
    elif (a.get('mech') or '').isdigit():
        where.append("j.mechanic_id=?"); params.append(int(a['mech']))
    if st == 'termine' and a.get('from') and a.get('to'):
        where.append(f"{done_expr} >= ? AND {done_expr} < ?"); params += [a['from'], (datetime.date.fromisoformat(a['to']) + datetime.timedelta(days=1)).isoformat()]
    order = {'termine': "done_at DESC", 'annule': "j.updated_at DESC", 'tous': "j.created_at DESC"}.get(
        st, "COALESCE(m.name,'~'), j.position, COALESCE(j.due_date,'9999'), j.created_at")
    sql_where = (" WHERE " + " AND ".join(where)) if where else ""
    paged = a.get('page') is not None
    page = max(1, int(a.get('page') or 1)) if (a.get('page') or '1').isdigit() else 1
    per_page = 50
    conn = get_conn()
    try:
        total = conn.execute(f"SELECT COUNT(*) FROM shop_jobs j LEFT JOIN shop_mechanics m ON m.id=j.mechanic_id{sql_where}", params).fetchone()[0]
        rows = [dict(r) for r in conn.execute(
            f"SELECT j.*, m.name mech_name, {done_expr} done_at FROM shop_jobs j LEFT JOIN shop_mechanics m ON m.id=j.mechanic_id{sql_where} "
            f"ORDER BY {order}" + (f" LIMIT {per_page} OFFSET {(page - 1) * per_page}" if paged else " LIMIT 2000"), params).fetchall()]
        for r in rows:
            r['seconds'] = _at_job_seconds(conn, r['job'])
            r['status_label'] = AT_JOB_STATUS.get(r['status'], r['status'])
        return jsonify({'jobs': rows, 'total': total, 'page': page, 'per_page': per_page if paged else total,
                        'mechanics': [{'id': m['id'], 'name': m['name'], 'color': m['color']} for m in at_mechanics()],
                        'is_admin': bool(session.get('is_admin'))})
    finally:
        conn.close()


@app.route('/api/atelier/jobs', methods=['POST'])
@app.route('/api/atelier/jobs/<job>', methods=['PUT'])
def api_atelier_job_save(job=None):
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    num = at_norm_job(d.get('job') if job is None else job)
    if not num:
        return jsonify({'ok': False, 'error': 'Entre le numéro du bon (celui de HubTiger).'}), 400
    try:
        mid = int(d['mechanic_id']) if d.get('mechanic_id') not in (None, '') else None
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Mécanicien invalide.'}), 400
    due = (d.get('due_date') or '').strip() or None
    if due:
        try:
            datetime.date.fromisoformat(due)
        except ValueError:
            return jsonify({'ok': False, 'error': 'Date promise invalide.'}), 400
    status = d.get('status') if d.get('status') in AT_JOB_STATUS else None
    fields = {k: (str(d.get(k) or '').strip()[:300] or None) for k in ('client', 'item', 'work')}
    notes = str(d.get('notes') or '').strip()[:1000] or None
    work_date = (d.get('work_date') or '').strip() or None
    if work_date:
        try:
            datetime.date.fromisoformat(work_date)
        except ValueError:
            return jsonify({'ok': False, 'error': 'Date de travail invalide.'}), 400
    priority = d.get('priority') if d.get('priority') in AT_PRIORITY else None
    new_num = at_norm_job(d.get('new_job')) if job is not None and d.get('new_job') else None
    if new_num and new_num != num and not session.get('is_admin'):
        return jsonify({'ok': False, 'error': "Seul un administrateur peut changer le numéro d'un bon."}), 403
    conn = get_conn()
    try:
        exists = conn.execute("SELECT * FROM shop_jobs WHERE job=?", (num,)).fetchone()
        if job is None and exists:
            return jsonify({'ok': False, 'error': f"Le bon {num} existe déjà."}), 409
        if job is not None and not exists:
            return jsonify({'ok': False, 'error': 'Bon introuvable.'}), 404
        if exists:
            pos = exists['position'] if exists['mechanic_id'] == mid else _at_next_position(conn, mid)
            conn.execute("UPDATE shop_jobs SET client=?, item=?, work=?, mechanic_id=?, due_date=?, status=?, updated_at=?, "
                         "notes=?, priority=?, position=?, work_date=? WHERE job=?",
                         (fields['client'], fields['item'], fields['work'], mid, due, status or exists['status'], _at_now(),
                          notes if 'notes' in d else exists['notes'], priority or exists['priority'] or 'normal', pos,
                          work_date if 'work_date' in d else exists['work_date'], num))
            if new_num and new_num != num:
                if conn.execute("SELECT 1 FROM shop_jobs WHERE job=?", (new_num,)).fetchone():
                    conn.rollback()
                    return jsonify({'ok': False, 'error': f"Le bon {new_num} existe déjà."}), 409
                for tbl in ('shop_jobs', 'shop_punches', 'shop_billing', 'shop_sale_links'):
                    conn.execute(f"UPDATE {tbl} SET job=? WHERE job=?", (new_num, num))
            conn.commit()
            changes = []
            if exists['mechanic_id'] != mid:
                changes.append('attribué à ' + (next((m['name'] for m in at_mechanics(True) if m['id'] == mid), 'personne')))
            if status and status != exists['status']:
                changes.append('statut : ' + AT_JOB_STATUS[status])
            if priority and priority != (exists['priority'] or 'normal'):
                changes.append('priorité : ' + AT_PRIORITY[priority])
            if new_num and new_num != num:
                changes.append(f'numéro changé pour {new_num}')
            log_audit('Atelier : bon de travail modifié', f"bon {num}" + (' — ' + ', '.join(changes) if changes else ''))
            num = new_num or num
        else:
            conn.execute("INSERT INTO shop_jobs(job, client, item, work, mechanic_id, due_date, status, created_by, created_at, updated_at, "
                         "notes, priority, position, work_date) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                         (num, fields['client'], fields['item'], fields['work'], mid, due, status or 'ouvert', session.get('username'),
                          _at_now(), _at_now(), notes, priority or 'normal', _at_next_position(conn, mid), work_date))
            conn.commit()
            log_audit('Atelier : bon de travail créé', f"bon {num} — {fields['client'] or ''} {fields['item'] or ''}".strip())
        conn.commit()
        return jsonify({'ok': True, 'job': num})
    finally:
        conn.close()


@app.route('/api/atelier/kiosk/message', methods=['POST'])
def api_atelier_kiosk_message():
    if not kiosk_allowed():
        return jsonify({'error': 'Poste de punch non autorisé.'}), 401
    d = request.get_json(silent=True) or {}
    try:
        mid = int(d.get('mechanic_id'))
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Mécanicien inconnu.'}), 400
    m, err = at_verify_pin(mid, d.get('pin'))
    if err:
        return jsonify({'ok': False, 'error': err, 'pin': True}), 403
    kind = 'probleme' if d.get('kind') == 'probleme' else 'message'
    category = d.get('category') if d.get('category') in AT_PROBLEMS else None
    text = str(d.get('text') or '').strip()[:1000]
    job = at_norm_job(d.get('job')) or None
    if kind == 'message' and not text:
        return jsonify({'ok': False, 'error': 'Écris ton message.'}), 400
    if kind == 'probleme' and not category:
        return jsonify({'ok': False, 'error': 'Choisis le type de problème.'}), 400
    conn = get_conn()
    try:
        conn.execute("INSERT INTO shop_messages(created_at, mechanic_id, job, kind, category, text, from_side) VALUES (?,?,?,?,?,?,'mecanicien')",
                     (_at_now(), mid, job, kind, category, text or None))
        conn.commit()
    finally:
        conn.close()
    db_add_audit(f"Atelier — {m['name']}", 'Problème signalé' if kind == 'probleme' else 'Message au responsable',
                 (f"bon {job} — " if job else '') + (AT_PROBLEMS.get(category, '') + (' : ' if text and category else '') if category else '') + text)
    if kind == 'probleme':
        _at_notify_problem(m['name'], job, category, text)
    return jsonify({'ok': True})


@app.route('/api/atelier/kiosk/thread', methods=['POST'])
def api_atelier_kiosk_thread():
    if not kiosk_allowed():
        return jsonify({'error': 'Poste de punch non autorisé.'}), 401
    d = request.get_json(silent=True) or {}
    try:
        mid = int(d.get('mechanic_id'))
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Mécanicien inconnu.'}), 400
    m, err = at_verify_pin(mid, d.get('pin'))
    if err:
        return jsonify({'ok': False, 'error': err, 'pin': True}), 403
    conn = get_conn()
    try:
        thread = at_thread(conn, mid)
        conn.execute("UPDATE shop_messages SET read_at=? WHERE mechanic_id=? AND from_side='responsable' AND read_at IS NULL", (_at_now(), mid))
        conn.commit()
        return jsonify({'ok': True, 'thread': thread, 'problems': AT_PROBLEMS})
    finally:
        conn.close()


@app.route('/api/atelier/unread')
def api_atelier_unread():
    if not (session.get('is_admin') or 'atelier' in (session.get('permissions') or [])):
        return jsonify({'unread': 0, 'problems': 0})
    conn = get_conn()
    try:
        c = at_unread_counts(conn)
        last = conn.execute("SELECT s.id, s.kind, s.category, s.job, s.text, m.name FROM shop_messages s JOIN shop_mechanics m ON m.id=s.mechanic_id "
                            "WHERE s.from_side='mecanicien' AND s.read_at IS NULL ORDER BY s.id DESC LIMIT 1").fetchone()
        c['last'] = dict(last) if last else None
        if c['last']:
            c['last']['category_label'] = AT_PROBLEMS.get(c['last']['category'] or '', '')
        return jsonify(c)
    finally:
        conn.close()


@app.route('/api/atelier/messages')
def api_atelier_messages():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    conn = get_conn()
    try:
        out = []
        for m in at_mechanics(True):
            thread = at_thread(conn, m['id'])
            if not thread and not m['active']:
                continue
            unread = sum(1 for x in thread if x['from_side'] == 'mecanicien' and not x['read_at'])
            open_p = sum(1 for x in thread if x['kind'] == 'probleme' and not x['resolved_at'])
            out.append({'id': m['id'], 'name': m['name'], 'color': m['color'], 'thread': thread, 'unread': unread,
                        'open_problems': open_p, 'last_at': thread[-1]['created_at'] if thread else ''})
        out.sort(key=lambda x: x['last_at'], reverse=True)                   # plus récent d'abord…
        out.sort(key=lambda x: (-x['open_problems'], -x['unread']))           # …mais problèmes et non lus en tête
        return jsonify({'conversations': out, 'counts': at_unread_counts(conn),
                        'notify_emails': meta_get('atelier_notify_emails') or '', 'is_admin': bool(session.get('is_admin'))})
    finally:
        conn.close()


@app.route('/api/atelier/messages', methods=['POST'])
def api_atelier_message_reply():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    try:
        mid = int(d.get('mechanic_id'))
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Mécanicien inconnu.'}), 400
    text = str(d.get('text') or '').strip()[:1000]
    if not text:
        return jsonify({'ok': False, 'error': 'Écris ta réponse.'}), 400
    conn = get_conn()
    try:
        conn.execute("INSERT INTO shop_messages(created_at, mechanic_id, job, kind, text, from_side, username) VALUES (?,?,?,?,?,'responsable',?)",
                     (_at_now(), mid, at_norm_job(d.get('job')) or None, 'message', text, current_display_name()))
        conn.execute("UPDATE shop_messages SET read_at=? WHERE mechanic_id=? AND from_side='mecanicien' AND read_at IS NULL", (_at_now(), mid))
        conn.commit()
    finally:
        conn.close()
    return jsonify({'ok': True})


@app.route('/api/atelier/messages/read', methods=['POST'])
def api_atelier_messages_read():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    conn = get_conn()
    try:
        conn.execute("UPDATE shop_messages SET read_at=? WHERE mechanic_id=? AND from_side='mecanicien' AND read_at IS NULL",
                     (_at_now(), int(d.get('mechanic_id') or 0)))
        conn.commit()
    finally:
        conn.close()
    return jsonify({'ok': True})


@app.route('/api/atelier/messages/<int:msg_id>/resolve', methods=['POST'])
def api_atelier_message_resolve(msg_id):
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    undo = (request.get_json(silent=True) or {}).get('undo')
    conn = get_conn()
    try:
        r = conn.execute("SELECT * FROM shop_messages WHERE id=?", (msg_id,)).fetchone()
        if not r:
            return jsonify({'ok': False, 'error': 'Message introuvable.'}), 404
        conn.execute("UPDATE shop_messages SET resolved_at=?, resolved_by=?, read_at=COALESCE(read_at, ?) WHERE id=?",
                     (None if undo else _at_now(), None if undo else current_display_name(), _at_now(), msg_id))
        conn.commit()
    finally:
        conn.close()
    log_audit('Atelier : problème ' + ('rouvert' if undo else 'résolu'), f"bon {r['job'] or '—'} — {AT_PROBLEMS.get(r['category'] or '', '')}")
    return jsonify({'ok': True})


@app.route('/api/atelier/notify-emails', methods=['POST'])
def api_atelier_notify_emails():
    resp = admin_required_check()
    if resp is not None:
        return resp
    v = str((request.get_json(silent=True) or {}).get('emails') or '').strip()[:500]
    bad = [e for e in re.split(r'[;,]\s*', v) if e and not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+', e)]
    if bad:
        return jsonify({'ok': False, 'error': 'Adresse invalide : ' + ', '.join(bad)}), 400
    meta_set('atelier_notify_emails', v)
    log_audit('Atelier : courriels avisés des problèmes', v or '(aucun)')
    return jsonify({'ok': True})


@app.route('/atelier/direct')
def atelier_direct_page():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    local = three_local_ready()
    if not local:
        ensure_three_vendor_async()
    return render_template('atelier_direct.html', company=get_company_name(), three_local=local)


@app.route('/api/atelier/direct')
def api_atelier_direct():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    a = request.args.get('after')
    try:
        after = int(a) if a not in (None, '', '-1') else None
    except ValueError:
        after = None
    return jsonify(at_direct_state(after))


@app.route('/api/atelier/profit/pdf')
def api_atelier_profit_pdf():
    resp = permission_required_check('atelier_profit')
    if resp is not None:
        return resp
    a = request.args
    r = at_profit_compare(a)
    try:
        if a.get('type') == 'eval':
            ids = None if a.get('mechanic') in (None, '', 'all') else [int(a['mechanic'])]
            path = export_atelier_eval_pdf(r, ids, a.get('cost', '1') == '1', a.get('detail', '1') == '1')
            log_audit("Atelier : fiche d'évaluation (PDF)", f"{'tous' if not ids else ids[0]} — {r['start']} au {r['end']}")
            if a.get('save_rh') == '1' and hr_allowed():      # copie classée au dossier RH de chaque employé relié
                conn = get_conn()
                try:
                    for m in r['mechanics']:
                        if ids and m['id'] not in ids:
                            continue
                        emp = conn.execute("SELECT * FROM hr_employees WHERE mechanic_id=?", (m['id'],)).fetchone()
                        if not emp:
                            continue
                        one = export_atelier_eval_pdf(r, [m['id']], a.get('cost', '1') == '1', a.get('detail', '1') == '1')
                        hr_store_file(emp['id'], one.read_bytes(), one.name, 'evaluation_atelier',
                                      f"Fiche d'atelier du {_d(r['start'])} au {_d(r['end'])}", username=session.get('username'), conn=conn)
                        hr_log(conn, emp['id'], "Fiche d'évaluation de l'atelier classée au dossier")
                    conn.commit()
                finally:
                    conn.close()
        else:
            path = export_atelier_finance_pdf(r)
            log_audit('Atelier : rapport financier (PDF)', f"{r['start']} au {r['end']}")
    except (ValueError, TypeError) as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    return send_file(str(path), mimetype='application/pdf', as_attachment=False, download_name=path.name)


@app.route('/api/atelier/hubtiger/preview', methods=['POST'])
def api_atelier_ht_preview():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    f = request.files.get('file')
    if not f or not f.filename or Path(f.filename).suffix.lower() not in ('.xlsx', '.csv'):
        return jsonify({'ok': False, 'error': "Choisis l'export HubTiger (fichier .xlsx ou .csv)."}), 400
    tmp = BASE_DIR / ('_import_hubtiger' + Path(f.filename).suffix.lower())
    f.save(str(tmp))
    try:
        items = ht_parse(tmp)
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass
    if not items:
        return jsonify({'ok': False, 'error': 'Aucun bon trouvé dans ce fichier.'}), 400
    include_done = request.form.get('include_done', '1') == '1'
    conn = get_conn()
    try:
        plan = ht_plan(conn, items, include_done)
    finally:
        conn.close()
    token = secrets.token_hex(8)
    HT_PENDING.write_text(json.dumps({'token': token, 'user': session.get('username'), 'items': items, 'include_done': include_done,
                                      'file': f.filename}, ensure_ascii=False), encoding='utf-8')
    return jsonify({'ok': True, 'token': token, 'total': len(items), 'file': f.filename, **ht_summary(plan)})


@app.route('/api/atelier/hubtiger/import', methods=['POST'])
def api_atelier_ht_import():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    d = request.get_json(silent=True) or {}
    try:
        pend = json.loads(HT_PENDING.read_text(encoding='utf-8'))
    except Exception:
        pend = None
    if not pend or pend.get('token') != d.get('token'):
        return jsonify({'ok': False, 'error': "L'aperçu n'est plus disponible : dépose le fichier de nouveau."}), 400
    conn = get_conn()
    try:
        res = ht_apply(conn, ht_plan(conn, pend['items'], pend['include_done']), current_display_name())
    finally:
        conn.close()
    try:
        HT_PENDING.unlink()
    except OSError:
        pass
    return jsonify({'ok': True, **res})


@app.route('/api/atelier/hubtiger/settings', methods=['GET', 'POST'])
def api_atelier_ht_settings():
    resp = permission_required_check('atelier')
    if resp is not None:
        return resp
    if request.method == 'POST':
        d = request.get_json(silent=True) or {}
        if 'drop' in d:
            meta_set('ht_drop_enabled', '1' if d['drop'] else '0')
            if d['drop']:
                HT_DROP_DIR.mkdir(parents=True, exist_ok=True)
        if 'include_done' in d:
            meta_set('ht_include_done', '1' if d['include_done'] else '0')
        log_audit('Atelier : réglages de l\u2019import HubTiger', json.dumps(d, ensure_ascii=False))
    try:
        last = json.loads(meta_get('ht_last_drop') or 'null')
    except ValueError:
        last = None
    return jsonify({'ok': True, 'drop': meta_get('ht_drop_enabled') == '1', 'include_done': meta_get('ht_include_done') != '0',
                    'folder': str(HT_DROP_DIR), 'last': last})
