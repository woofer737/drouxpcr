# -*- coding: utf-8 -*-
"""Pages des comptes à recevoir : clients, factures, paiements, états de compte, synchronisation Excel, factures Lightspeed.
Module de Kubios (découpé de app.py en 1.49.0, code inchangé)."""
import os
import re
import io
import csv
import sys
import json
import base64
import hashlib
import unicodedata
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import openpyxl
from openpyxl.utils import get_column_letter
import licensing
from kubios_base import db_add_audit, get_company_email, get_company_name, get_conn, get_settings, meta_get, meta_set
from kubios_mail import send_email
from kubios_pdf import LOGO_PATH, _pdf_disclaimer
from kubios_app import BASE_DIR, app
from kubios_auth import admin_required_check, log_audit, permission_required_check
from kubios_systeme import get_email_closing_message, get_pdf_footer_message
from kubios_rh_outils import PDF_DIR
from kubios_lightspeed import (
    LightspeedError, _ls_api_get, _ls_as_list, _ls_get_all, _ls_is_account_payment, _ls_local_date,
    _ls_sync_state, _parse_money, _truthy, ls_config, ls_fetch_account,
)
from kubios_outils import _fmt_money_fr

__all__ = ['BACKUP_DIR', 'BACKUP_SCOPES', 'CLIENT_FIELD_LABELS', 'CLIENT_INFO_FIELDS', 'CREDIT_BACKUP_DIR', 'CREDIT_BACKUP_KEEP', 'CREDIT_BACKUP_TABLES', 'EXCEL_PATH', 'FIRST_INVOICE_ROW', 'FORMULA_MIN_LAST_ROW', 'HEADER_RESERVED_HEIGHT', 'INFO_ROWS', 'INVALID_SHEET_CHARS', 'LOG_SHEET', 'LS_SYNC_MOVEMENT_TYPE', 'MAX_BACKUPS', 'MODELE_SHEET', 'MOIS_FR', 'SOMMAIRE_SHEET', 'STATEMENT_PREFIX', '_ar_allocate', '_ar_existing_numbers', '_ar_open_invoices', '_ar_propose_payments', '_backup_path', '_bulk_lock', '_bulk_state', '_credit_client_display_name', '_credit_net_debt', '_db_lock', '_last_day_next_month', '_ls_apply_values', '_ls_ar_balance_check', '_ls_ar_default_since', '_ls_ar_lock', '_ls_ar_state', '_ls_customer_names', '_ls_debt', '_ls_fetch_customer_contact', '_ls_insert_client', '_norm_credit_name', '_prune_backups', '_prune_scope_backups', '_queue_sheet_delete', '_queue_sheet_rename', '_resolve_date_paiement', '_run_bulk', '_split_debt', '_sync_lock', '_sync_state', '_unique_sheet_name', 'api_add_invoice', 'api_aging_report', 'api_bulk_draft', 'api_bulk_draft_status', 'api_bulk_send', 'api_client_detail', 'api_client_ls_link_remove', 'api_client_ls_links', 'api_clients', 'api_create_client', 'api_delete_invoice', 'api_envois_report', 'api_get_pdf', 'api_list_ar_backups', 'api_ls_ar_apply', 'api_ls_ar_check', 'api_ls_ar_status', 'api_ls_link_pending', 'api_ls_pending', 'api_merge_client', 'api_monthly_report', 'api_restore_ar_backup', 'api_set_invoice_paid', 'api_statement', 'api_sync', 'api_sync_status', 'api_update_client', 'api_update_invoice', 'car_page', 'compute_bucket', 'db_add_invoice', 'db_aging_all_clients', 'db_backup_scope', 'db_client_detail', 'db_client_ls_links', 'db_create_client', 'db_delete_invoice', 'db_discard_credit_backup', 'db_envois_by_month', 'db_get_invoice', 'db_invoices_by_month', 'db_list_clients', 'db_list_credit_backups', 'db_log_envoi', 'db_ls_link_pending', 'db_ls_list_pending', 'db_merge_clients', 'db_next_statement_number', 'db_restore_credit_backup', 'db_set_invoice_paid', 'db_update_client', 'db_update_invoice', 'export_to_excel', 'generate_aging_report_pdf', 'generate_envoi_report_pdf', 'generate_monthly_report_pdf', 'generate_statement_pdf', 'get_sender_signature', 'invoices_with_buckets', 'ls_ar_apply', 'ls_ar_build_preview', 'mark_dirty', 'month_end_or_today', 'refresh_header_sums', 'safe_sheet_name', 'save_wb_atomic', 'set_row_formulas', 'start_ls_ar_check', 'sum_totals', 'write_client_sheet']


EXCEL_PATH = BASE_DIR / "Compte à recevoir.xlsx"


def get_sender_signature():
    email = get_company_email()
    name = get_company_name()
    return f"{name}\n{email}" if email else name


STATEMENT_PREFIX = "OE-"


INFO_ROWS = {
    'adresse': 3,
    'ville': 4,
    'province': 5,
    'code_postal': 6,
    'courriel': 7,
}


FIRST_INVOICE_ROW = 8


FORMULA_MIN_LAST_ROW = 1000


MODELE_SHEET = "Modèle"


SOMMAIRE_SHEET = "Sommaire"


LOG_SHEET = "LOG_ENVOIS"


INVALID_SHEET_CHARS = r'[:\\/?*\[\]]'


_db_lock = threading.Lock()


def mark_dirty():
    meta_set('dirty', '1')


def safe_sheet_name(name: str) -> str:
    cleaned = re.sub(INVALID_SHEET_CHARS, '', name).strip()
    return cleaned[:31] if len(cleaned) > 31 else cleaned


def compute_bucket(today, echeance_str, montant):
    if not echeance_str:
        return {'g': 0.0, 'h': 0.0, 'i': 0.0, 'j': 0.0}
    try:
        echeance = datetime.datetime.strptime(echeance_str, '%Y-%m-%d').date()
    except ValueError:
        return {'g': 0.0, 'h': 0.0, 'i': 0.0, 'j': 0.0}
    diff = (today - echeance).days
    g = montant if today <= echeance else 0.0
    h = montant if 0 < diff <= 30 else 0.0
    i = montant if 30 < diff <= 60 else 0.0
    j = montant if diff > 60 else 0.0
    return {'g': g, 'h': h, 'i': i, 'j': j}


def invoices_with_buckets(rows, ref_date=None):
    """Ajoute à chaque facture son solde restant (montant - montant payé, s'il y a eu un
    paiement partiel ou total) et sa tranche d'âge calculée sur ce solde restant — pas
    sur le montant facturé au complet.

    Pour un rapport d'âge d'un mois PASSÉ (ref_date fourni) : si le paiement enregistré
    (date_paiement) est survenu APRÈS ref_date, on ne le soustrait pas du solde — la
    facture apparaît alors comme elle l'était réellement à cette date-là, sans tenir
    compte d'un paiement reçu depuis. Pour la vue courante (ref_date=None), le paiement
    est toujours pris en compte normalement."""
    today = ref_date or datetime.date.today()
    today_str = today.strftime('%Y-%m-%d')
    out = []
    for r in rows:
        d = dict(r)
        montant_paye_total = d.get('montant_paye') or 0.0
        date_paiement = d.get('date_paiement') or ''
        if montant_paye_total and date_paiement and date_paiement > today_str:
            montant_paye_effectif = 0.0
        else:
            montant_paye_effectif = montant_paye_total
        solde = d['montant'] - montant_paye_effectif
        d['montant_paye'] = montant_paye_total
        d['date_paiement'] = date_paiement
        d['solde'] = solde
        d['bucket'] = compute_bucket(today, d['echeance'], solde)
        out.append(d)
    return out


def sum_totals(invoices):
    """totals['montant'] représente le solde total dû (après paiements partiels) — le nom
    est conservé pour ne pas casser le reste du code qui l'utilise comme 'montant dû'."""
    totals = {'montant': 0.0, 'g': 0.0, 'h': 0.0, 'i': 0.0, 'j': 0.0}
    for inv in invoices:
        totals['montant'] += inv.get('solde', inv['montant'])
        for k in ('g', 'h', 'i', 'j'):
            totals[k] += inv['bucket'][k]
    return totals


def db_list_clients():
    conn = get_conn()
    clients = conn.execute("SELECT name, courriel FROM clients ORDER BY name COLLATE NOCASE").fetchall()
    result = []
    for c in clients:
        rows = conn.execute("SELECT * FROM invoices WHERE client_name=?", (c['name'],)).fetchall()
        totals = sum_totals(invoices_with_buckets(rows))
        result.append({'name': c['name'], 'courriel': c['courriel'] or '', 'solde': round(totals['montant'], 2)})
    conn.close()
    return result


def db_client_detail(name):
    conn = get_conn()
    c = conn.execute("SELECT * FROM clients WHERE name=?", (name,)).fetchone()
    if c is None:
        conn.close()
        return None
    rows = conn.execute("SELECT * FROM invoices WHERE client_name=? ORDER BY id", (name,)).fetchall()
    conn.close()
    invoices = invoices_with_buckets(rows)
    totals = sum_totals(invoices)
    info = {'phone': c['phone'] or '', 'adresse': c['adresse'] or '', 'ville': c['ville'] or '',
            'province': c['province'] or '', 'code_postal': c['code_postal'] or '', 'courriel': c['courriel'] or ''}
    return {'name': c['name'], 'info': info, 'invoices': invoices, 'totals': totals}


def db_create_client(name, phone, adresse, ville, province, code_postal, courriel):
    conn = get_conn()
    existing = conn.execute("SELECT 1 FROM clients WHERE name=?", (name,)).fetchone()
    if existing:
        conn.close()
        raise RuntimeError("Ce client existe déjà.")
    base_sheet_name = safe_sheet_name(name)
    sheet_name = base_sheet_name
    suffix = 2
    while conn.execute("SELECT name FROM clients WHERE sheet_name=?", (sheet_name,)).fetchone():
        # collision (deux noms différents tronquent pareil) : on distingue avec un suffixe
        tail = f"_{suffix}"
        sheet_name = base_sheet_name[:31 - len(tail)] + tail
        suffix += 1
    conn.execute(
        "INSERT INTO clients(name, sheet_name, phone, adresse, ville, province, code_postal, courriel) VALUES (?,?,?,?,?,?,?,?)",
        (name, sheet_name, phone or '', adresse or '', ville or '', province or 'Qc', code_postal or '', courriel or '')
    )
    conn.commit()
    conn.close()
    mark_dirty()
    return sheet_name


CLIENT_FIELD_LABELS = {
    'name': "Nom", 'courriel': "Courriel", 'phone': "Téléphone", 'adresse': "Adresse",
    'ville': "Ville", 'province': "Province", 'code_postal': "Code postal",
}


def _unique_sheet_name(conn, name, exclude_client=None):
    """Nom d'onglet Excel valide et unique (insensible à la casse, comme
    Excel) parmi les clients — en excluant éventuellement le client lui-même
    (cas d'un renommage) — et jamais égal à un onglet système."""
    reserved = {MODELE_SHEET.lower(), SOMMAIRE_SHEET.lower(), LOG_SHEET.lower()}
    base = safe_sheet_name(name) or "Client"
    candidate = base
    suffix = 2
    while True:
        if candidate.lower() not in reserved:
            row = conn.execute(
                "SELECT name FROM clients WHERE sheet_name = ? COLLATE NOCASE AND name <> ?",
                (candidate, exclude_client if exclude_client is not None else '\x00')
            ).fetchone()
            if row is None:
                return candidate
        tail = f"_{suffix}"
        candidate = base[:31 - len(tail)] + tail
        suffix += 1


def _queue_sheet_delete(conn, sheet):
    """Mémorise un onglet Excel à supprimer à la prochaine synchronisation
    (client fusionné dans un autre)."""
    row = conn.execute("SELECT value FROM meta WHERE key='pending_sheet_deletes'").fetchone()
    try:
        pending = json.loads(row['value']) if row and row['value'] else []
    except Exception:
        pending = []
    if sheet and sheet not in pending:
        pending.append(sheet)
    conn.execute("INSERT INTO meta(key,value) VALUES('pending_sheet_deletes', ?) "
                 "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (json.dumps(pending, ensure_ascii=False),))


CLIENT_INFO_FIELDS = ('phone', 'adresse', 'ville', 'province', 'code_postal', 'courriel')


def db_merge_clients(source, target, username):
    """Fusionne le client `source` dans `target` : factures, liens Lightspeed,
    paiements traités et noms reconnus passent à `target` ; ses coordonnées
    vides sont complétées par celles de `source` ; `source` est supprimé (son
    onglet Excel le sera à la prochaine synchronisation) et son nom devient un
    nom reconnu de `target`. Une sauvegarde des comptes à recevoir est prise avant."""
    conn = get_conn()
    s = conn.execute("SELECT * FROM clients WHERE name=?", (source,)).fetchone()
    t = conn.execute("SELECT * FROM clients WHERE name=?", (target,)).fetchone()
    conn.close()
    if s is None or t is None:
        raise RuntimeError("Client introuvable.")
    if source == target:
        raise RuntimeError("Choisis deux clients différents.")
    s, t = dict(s), dict(t)
    backup_id = db_backup_scope('ar', f"Avant fusion de « {source} » dans « {target} »", username)
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    conn = get_conn()
    try:
        n_inv = conn.execute("SELECT COUNT(*) n FROM invoices WHERE client_name=?", (source,)).fetchone()['n']
        filled = []
        for f in CLIENT_INFO_FIELDS:
            if not (t.get(f) or '').strip() and (s.get(f) or '').strip():
                conn.execute(f"UPDATE clients SET {f}=? WHERE name=?", (s[f], target))
                filled.append(f)
        conn.execute("UPDATE invoices SET client_name=? WHERE client_name=?", (target, source))
        conn.execute("UPDATE ls_ar_customers SET client_name=? WHERE client_name=?", (target, source))
        conn.execute("UPDATE ls_ar_payments SET client_name=? WHERE client_name=?", (target, source))
        conn.execute("UPDATE ls_ar_aliases SET client_name=? WHERE client_name=?", (target, source))
        if _norm_credit_name(source) != _norm_credit_name(target):
            conn.execute("INSERT OR REPLACE INTO ls_ar_aliases(alias, display, client_name, created_at) "
                         "VALUES (?,?,?,?)", (_norm_credit_name(source), source, target, now))
        conn.execute("DELETE FROM clients WHERE name=?", (source,))
        if s.get('sheet_name'):
            _queue_sheet_delete(conn, s['sheet_name'])
        conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('dirty', '1')")
        conn.commit()
    finally:
        conn.close()
    return {'invoices': n_inv, 'filled': filled, 'backup_id': backup_id}


def db_client_ls_links(name):
    conn = get_conn()
    try:
        customers = [dict(r) for r in conn.execute(
            "SELECT ls_customer_id, ls_name, linked_at FROM ls_ar_customers WHERE client_name=? "
            "ORDER BY linked_at", (name,)).fetchall()]
        aliases = [dict(r) for r in conn.execute(
            "SELECT alias, display, created_at FROM ls_ar_aliases WHERE client_name=? ORDER BY created_at",
            (name,)).fetchall()]
    finally:
        conn.close()
    return {'customers': customers, 'aliases': aliases}


def _queue_sheet_rename(conn, old_sheet, new_sheet):
    """Mémorise un renommage d'onglet Excel à appliquer à la prochaine
    synchronisation (le fichier Excel n'est jamais modifié directement ici)."""
    row = conn.execute("SELECT value FROM meta WHERE key='pending_sheet_renames'").fetchone()
    try:
        pending = json.loads(row['value']) if row and row['value'] else []
    except Exception:
        pending = []
    pending.append([old_sheet, new_sheet])
    conn.execute(
        "INSERT INTO meta(key,value) VALUES('pending_sheet_renames', ?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (json.dumps(pending, ensure_ascii=False),)
    )


def db_update_client(old_name, new_name, phone, adresse, ville, province, code_postal, courriel):
    """Modifie un client existant. Un changement de nom est appliqué en une
    seule transaction au client ET à toutes ses factures. Retourne
    (nouveau_nom, liste des changements [(champ, avant, après)])."""
    new_name = (new_name or '').strip()
    if not new_name:
        raise RuntimeError("Le nom du client est obligatoire.")
    new_values = {
        'name': new_name,
        'courriel': (courriel or '').strip(),
        'phone': (phone or '').strip(),
        'adresse': (adresse or '').strip(),
        'ville': (ville or '').strip(),
        'province': (province or '').strip() or 'Qc',
        'code_postal': (code_postal or '').strip(),
    }
    conn = get_conn()
    try:
        cur = conn.execute("SELECT * FROM clients WHERE name=?", (old_name,)).fetchone()
        if cur is None:
            raise RuntimeError("Client introuvable (il a peut-être déjà été renommé — recharge la page).")
        changes = [(k, cur[k] or '', v) for k, v in new_values.items() if (cur[k] or '') != v]
        if not changes:
            return old_name, []

        renamed = new_name != old_name
        sheet_name = cur['sheet_name']
        if renamed:
            dup = conn.execute(
                "SELECT name FROM clients WHERE name = ? COLLATE NOCASE AND name <> ?",
                (new_name, old_name)
            ).fetchone()
            if dup:
                raise RuntimeError(f"Un autre client porte déjà ce nom : « {dup['name']} ».")
            sheet_name = _unique_sheet_name(conn, new_name, exclude_client=old_name)

        # Les factures référencent clients(name) : on diffère la vérification
        # des clés étrangères à la fin de la transaction pour pouvoir changer
        # le nom des deux côtés.
        conn.execute("PRAGMA defer_foreign_keys = ON")
        conn.execute(
            "UPDATE clients SET name=?, sheet_name=?, phone=?, adresse=?, ville=?, province=?, "
            "code_postal=?, courriel=? WHERE name=?",
            (new_values['name'], sheet_name, new_values['phone'], new_values['adresse'],
             new_values['ville'], new_values['province'], new_values['code_postal'],
             new_values['courriel'], old_name)
        )
        if renamed:
            conn.execute("UPDATE invoices SET client_name=? WHERE client_name=?", (new_name, old_name))
            conn.execute("UPDATE ls_ar_customers SET client_name=? WHERE client_name=?", (new_name, old_name))
            conn.execute("UPDATE ls_ar_payments SET client_name=? WHERE client_name=?", (new_name, old_name))
            conn.execute("UPDATE ls_ar_aliases SET client_name=? WHERE client_name=?", (new_name, old_name))
            if _norm_credit_name(old_name) != _norm_credit_name(new_name):
                conn.execute("INSERT OR REPLACE INTO ls_ar_aliases(alias, display, client_name, created_at) "
                             "VALUES (?,?,?,?)", (_norm_credit_name(old_name), old_name, new_name,
                                                  datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            conn.execute("DELETE FROM ls_ar_aliases WHERE alias=?", (_norm_credit_name(new_name),))
            if sheet_name != cur['sheet_name']:
                _queue_sheet_rename(conn, cur['sheet_name'], sheet_name)
        conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('dirty', '1')")
        conn.commit()
        return new_name, changes
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _resolve_date_paiement(montant_paye, date_paiement, previous_date_paiement=None):
    """Détermine la date de paiement à enregistrer : si un montant payé est présent
    mais qu'aucune date n'a été fournie explicitement, on garde la date précédente
    si elle existe, sinon on utilise aujourd'hui (comportement par défaut, cohérent
    avec la migration initiale) — jamais None tant qu'il y a un montant payé, pour
    que les rapports d'âge de mois passés puissent trancher correctement."""
    if not montant_paye:
        return None
    if date_paiement:
        return date_paiement
    if previous_date_paiement:
        return previous_date_paiement
    return datetime.date.today().strftime('%Y-%m-%d')


def db_add_invoice(client_name, numero, date_facture, echeance, montant, notes,
                    montant_paye=0.0, date_paiement=None):
    conn = get_conn()
    c = conn.execute("SELECT 1 FROM clients WHERE name=?", (client_name,)).fetchone()
    if not c:
        conn.close()
        raise RuntimeError(f"Client introuvable : {client_name}")
    montant_paye = float(montant_paye or 0)
    date_paiement = _resolve_date_paiement(montant_paye, date_paiement)
    conn.execute(
        "INSERT INTO invoices(client_name, numero, date_facture, echeance, montant, notes, montant_paye, date_paiement) "
        "VALUES (?,?,?,?,?,?,?,?)",
        (client_name, str(numero), date_facture, echeance, float(montant), notes or '',
         montant_paye, date_paiement)
    )
    conn.commit()
    conn.close()
    mark_dirty()


def db_update_invoice(invoice_id, numero, date_facture, echeance, montant, notes,
                       montant_paye=0.0, date_paiement=None):
    conn = get_conn()
    existing = conn.execute("SELECT montant_paye, date_paiement FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    if not existing:
        conn.close()
        raise RuntimeError("Facture introuvable.")
    montant_paye = float(montant_paye or 0)
    montant_paye_a_change = abs((existing['montant_paye'] or 0.0) - montant_paye) > 0.005
    # Si le montant payé n'a pas changé, on garde la date déjà enregistrée (même si
    # aucune nouvelle date n'est fournie) ; s'il a changé sans date fournie, on
    # considère que ce changement vient d'être fait aujourd'hui.
    previous = existing['date_paiement'] if not montant_paye_a_change else None
    date_paiement = _resolve_date_paiement(montant_paye, date_paiement, previous)
    conn.execute(
        "UPDATE invoices SET numero=?, date_facture=?, echeance=?, montant=?, notes=?, "
        "montant_paye=?, date_paiement=? WHERE id=?",
        (str(numero), date_facture, echeance, float(montant), notes or '',
         montant_paye, date_paiement, invoice_id)
    )
    conn.commit()
    conn.close()
    mark_dirty()


def db_get_invoice(invoice_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def db_delete_invoice(invoice_id):
    conn = get_conn()
    existing = conn.execute("SELECT 1 FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    if not existing:
        conn.close()
        raise RuntimeError("Facture introuvable.")
    conn.execute("DELETE FROM invoices WHERE id=?", (invoice_id,))
    conn.commit()
    conn.close()
    mark_dirty()


def db_set_invoice_paid(invoice_id, paid, date_paiement=None):
    """Marque une facture comme entièrement payée (montant_paye = montant, avec la
    date de paiement fournie ou aujourd'hui par défaut) ou annule ce marquage (remet
    montant_paye et date_paiement à zéro/vide). Un paiement partiel déjà saisi
    manuellement est écrasé par cette action, dans les deux sens."""
    conn = get_conn()
    row = conn.execute("SELECT montant FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    if not row:
        conn.close()
        raise RuntimeError("Facture introuvable.")
    if paid:
        new_montant_paye = row['montant']
        new_date_paiement = date_paiement or datetime.date.today().strftime('%Y-%m-%d')
    else:
        new_montant_paye = 0.0
        new_date_paiement = None
    conn.execute("UPDATE invoices SET montant_paye=?, date_paiement=? WHERE id=?",
                 (new_montant_paye, new_date_paiement, invoice_id))
    conn.commit()
    conn.close()
    mark_dirty()


def db_next_statement_number():
    conn = get_conn()
    with _db_lock:
        row = conn.execute("SELECT value FROM meta WHERE key='statement_counter'").fetchone()
        current = int(row['value']) if row else 0
        new_val = current + 1
        conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('statement_counter', ?)", (str(new_val),))
        conn.commit()
    conn.close()
    mark_dirty()
    return f"{STATEMENT_PREFIX}{new_val:06d}"


def db_log_envoi(client, courriel, total, statut, note):
    conn = get_conn()
    conn.execute(
        "INSERT INTO log_envois(ts, client, courriel, total, statut, note, synced) VALUES (?,?,?,?,?,?,0)",
        (datetime.datetime.now().isoformat(), client, courriel, total, statut, note)
    )
    conn.commit()
    conn.close()
    mark_dirty()


def _credit_client_display_name(row):
    prenom = (row.get('prenom_entreprise') or '').strip()
    nom = (row.get('nom') or '').strip()
    if nom and nom.lower() not in prenom.lower():
        return f"{prenom} {nom}".strip()
    return prenom or nom


def _norm_credit_name(s):
    return (s or '').strip().lower()


def _credit_net_debt(row):
    """« Debt » net d'un compte (positif = doit, négatif = crédit/dépôt).
    Les fiches d'avant la 1.9.1 pouvaient avoir un solde négatif brut."""
    solde = float(row.get('solde') or 0.0)
    deposit = float(row.get('deposit') or 0.0)
    return solde if solde < 0 else solde - deposit


def _split_debt(debt):
    """Répartit un Debt net en (montant dû, dépôt)."""
    debt = round(float(debt), 2)
    return max(debt, 0.0), max(-debt, 0.0)


CREDIT_BACKUP_DIR = BASE_DIR / "Backups_comptes_credit"


CREDIT_BACKUP_KEEP = 60


CREDIT_BACKUP_TABLES = ('credit_clients', 'credit_movements', 'ls_pending_accounts')


BACKUP_SCOPES = {
    'credit': {
        'dir': CREDIT_BACKUP_DIR, 'prefix': 'comptes_credit',
        'tables': CREDIT_BACKUP_TABLES,
        # ordre d'effacement (enfants d'abord) ; la réinsertion se fait à l'envers
        'delete_order': ('credit_movements', 'ls_pending_accounts', 'credit_clients'),
        'totals': ("SELECT COUNT(*) n, COALESCE(SUM(solde),0) s, COALESCE(SUM(deposit),0) d FROM credit_clients",
                   "SELECT COUNT(*) n FROM credit_movements"),
        'main_table': 'credit_clients',
    },
    'ar': {
        'dir': BASE_DIR / "Backups_comptes_recevoir", 'prefix': 'comptes_recevoir',
        'tables': ('clients', 'invoices', 'ls_ar_customers', 'ls_ar_ignored', 'ls_ar_payments', 'ls_ar_aliases'),
        'delete_order': ('invoices', 'ls_ar_customers', 'ls_ar_ignored', 'ls_ar_payments', 'ls_ar_aliases',
                         'clients'),
        'totals': ("SELECT (SELECT COUNT(*) FROM clients) n, "
                   "COALESCE((SELECT SUM(COALESCE(montant,0) - COALESCE(montant_paye,0)) FROM invoices),0) s, "
                   "0 d", "SELECT COUNT(*) n FROM invoices"),
        'main_table': 'clients',
    },
}


def db_backup_scope(scope, label, username):
    """Copie les tables du module (scope) dans un fichier de sauvegarde.
    Retourne l'id de la sauvegarde. Lève RuntimeError si la copie échoue
    (l'importation qui suit doit alors être annulée)."""
    cfg = BACKUP_SCOPES[scope]
    cfg['dir'].mkdir(exist_ok=True)
    now = datetime.datetime.now()
    path = cfg['dir'] / f"{cfg['prefix']}_{now.strftime('%Y-%m-%d_%Hh%M%S')}_{secrets.token_hex(3)}.db"
    conn = get_conn()
    try:
        conn.execute("ATTACH DATABASE ? AS bk", (str(path),))
        conn.execute("BEGIN")
        for t in cfg['tables']:
            conn.execute(f"CREATE TABLE bk.{t} AS SELECT * FROM main.{t}")
        conn.execute("COMMIT")
        conn.execute("DETACH DATABASE bk")
        t = conn.execute(cfg['totals'][0]).fetchone()
        mv = conn.execute(cfg['totals'][1]).fetchone()['n']
        cur = conn.execute(
            "INSERT INTO credit_backups(created_at, label, username, filename, client_count, movement_count, "
            "total_solde, total_deposit, scope) VALUES (?,?,?,?,?,?,?,?,?)",
            (now.strftime('%Y-%m-%d %H:%M:%S'), label, username or '?', path.name,
             t['n'], mv, round(t['s'], 2), round(t['d'], 2), scope))
        conn.commit()
        backup_id = cur.lastrowid
    except Exception as e:
        traceback.print_exc()
        try:
            conn.rollback()
        except Exception:
            pass
        conn.close()
        try:
            path.unlink()
        except OSError:
            pass
        what = "des comptes de crédit" if scope == 'credit' else "des comptes à recevoir"
        raise RuntimeError(f"La sauvegarde {what} a échoué ({e}) : opération annulée, "
                           "aucune donnée n'a été modifiée.")
    conn.close()
    try:
        _prune_scope_backups(scope)
    except Exception:
        traceback.print_exc()  # le ménage des vieilles sauvegardes ne doit jamais bloquer l'opération
    return backup_id


def _backup_path(row):
    return BACKUP_SCOPES[row['scope'] if 'scope' in row.keys() else 'credit']['dir'] / row['filename']


def _prune_scope_backups(scope):
    conn = get_conn()
    try:
        old = conn.execute("SELECT * FROM credit_backups WHERE scope=? ORDER BY id DESC LIMIT -1 OFFSET ?",
                           (scope, CREDIT_BACKUP_KEEP)).fetchall()
        for r in old:
            try:
                _backup_path(r).unlink()
            except OSError:
                pass
            conn.execute("DELETE FROM credit_backups WHERE id=?", (r['id'],))
        conn.commit()
    finally:
        conn.close()


def db_discard_credit_backup(backup_id):
    """Supprime une sauvegarde devenue inutile (importation sans aucun changement)."""
    if not backup_id:
        return
    conn = get_conn()
    try:
        r = conn.execute("SELECT * FROM credit_backups WHERE id=?", (backup_id,)).fetchone()
        if r:
            try:
                _backup_path(r).unlink()
            except OSError:
                pass
            conn.execute("DELETE FROM credit_backups WHERE id=?", (backup_id,))
            conn.commit()
    finally:
        conn.close()


def db_list_credit_backups(scope='credit'):
    conn = get_conn()
    rows = [dict(r) for r in conn.execute("SELECT * FROM credit_backups WHERE scope=? ORDER BY id DESC",
                                          (scope,)).fetchall()]
    conn.close()
    for r in rows:
        r['file_ok'] = _backup_path(r).exists()
    return rows


def db_restore_credit_backup(backup_id, username, scope='credit'):
    """Remet les tables du module (comptes de crédit, ou clients et factures
    des comptes à recevoir) telles qu'elles étaient dans la sauvegarde.
    L'état actuel est sauvegardé juste avant, pour pouvoir annuler la
    restauration."""
    cfg = BACKUP_SCOPES[scope]
    conn = get_conn()
    b = conn.execute("SELECT * FROM credit_backups WHERE id=? AND scope=?", (backup_id, scope)).fetchone()
    conn.close()
    if b is None:
        raise RuntimeError("Sauvegarde introuvable.")
    b = dict(b)
    path = _backup_path(b)
    if not path.exists():
        raise RuntimeError(f"Le fichier de sauvegarde est introuvable ({path}).")
    d, h = b['created_at'][:10], b['created_at'][11:16]
    pre_id = db_backup_scope(scope, f"Avant restauration de la sauvegarde du {d[8:10]}-{d[5:7]}-{d[:4]} {h}",
                             username)
    conn = get_conn()
    try:
        conn.execute("ATTACH DATABASE ? AS bk", (str(path),))
        bk_tables = {r['name'] for r in conn.execute("SELECT name FROM bk.sqlite_master WHERE type='table'")}
        if cfg['main_table'] not in bk_tables:
            raise RuntimeError("Fichier de sauvegarde invalide.")
        conn.execute("BEGIN")
        try:
            for t in cfg['delete_order']:
                conn.execute(f"DELETE FROM main.{t}")
            for t in reversed(cfg['delete_order']):
                if t not in bk_tables:
                    continue
                main_cols = [r['name'] for r in conn.execute(f"PRAGMA main.table_info({t})")]
                bk_cols = {r['name'] for r in conn.execute(f"PRAGMA bk.table_info({t})")}
                cols = ", ".join(c for c in main_cols if c in bk_cols)
                conn.execute(f"INSERT INTO main.{t} ({cols}) SELECT {cols} FROM bk.{t}")
            conn.execute("UPDATE credit_backups SET restored_at=?, restored_by=? WHERE id=?",
                         (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), username or '?', backup_id))
            conn.execute("COMMIT")
        except Exception:
            conn.execute("ROLLBACK")
            raise
    finally:
        try:
            conn.execute("DETACH DATABASE bk")
        except Exception:
            pass
        conn.close()
    mark_dirty()
    return b, pre_id


LS_SYNC_MOVEMENT_TYPE = 'Synchronisation Lightspeed'


def _ls_debt(balance, sign):
    """« Debt » (positif = le client doit) à partir du solde brut Lightspeed."""
    return round(balance if sign == 'positive_du' else -balance, 2)


def _ls_apply_values(conn, client, row, debt, now, today, note):
    """Applique limite / dû / dépôt d'un compte Lightspeed à un compte Kubios.
    Retourne 'updated' ou 'unchanged'."""
    old_debt = _credit_net_debt(client)
    delta = round(debt - old_debt, 2)
    solde, deposit = _split_debt(debt)
    limit_changed = abs(float(client.get('credit_limit') or 0) - row['credit_limit']) >= 0.005
    raw_changed = (abs(float(client.get('solde') or 0) - solde) >= 0.005
                   or abs(float(client.get('deposit') or 0) - deposit) >= 0.005)
    if not (limit_changed or raw_changed or abs(delta) >= 0.01):
        return 'unchanged'
    conn.execute("UPDATE credit_clients SET credit_limit=?, solde=?, deposit=? WHERE id=?",
                 (row['credit_limit'], solde, deposit, client['id']))
    client.update(credit_limit=row['credit_limit'], solde=solde, deposit=deposit)
    # Seuil de 1,5 ¢ : d'anciens montants divisés par 2 (import du 29-09) ont
    # 3 décimales — l'arrondi à 2 décimales ne doit pas créer de faux mouvement.
    if abs(delta) >= 0.015:
        conn.execute(
            "INSERT INTO credit_movements(credit_client_id, lightspeed_id, date_mouvement, montant, type, sale, "
            "customer_brut, notes, imported_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (client['id'], None, today, delta, LS_SYNC_MOVEMENT_TYPE, None,
             _credit_client_display_name(row),
             f"{note} le {today} : Debt {old_debt:.2f}$ -> {debt:.2f}$", now))
    return 'updated'


def _ls_insert_client(conn, row, now, note):
    cur = conn.execute(
        "INSERT INTO credit_clients(prenom_entreprise, nom, credit_limit, solde, deposit, notes, created_at, "
        "ls_credit_account_id, ls_customer_id) VALUES (?,?,?,?,?,?,?,?,?)",
        (row['prenom_entreprise'], row['nom'], 0, 0, 0, note, now, row['ls_id'], row.get('ls_customer_id')))
    return {'id': cur.lastrowid, 'prenom_entreprise': row['prenom_entreprise'], 'nom': row['nom'],
            'credit_limit': 0.0, 'solde': 0.0, 'deposit': 0.0, 'no_sync': 0,
            'ls_credit_account_id': row['ls_id']}


def db_ls_list_pending():
    conn = get_conn()
    try:
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM ls_pending_accounts ORDER BY prenom_entreprise COLLATE NOCASE, nom COLLATE NOCASE"
        ).fetchall()]
        unlinked = {}
        for c in conn.execute("SELECT * FROM credit_clients WHERE ls_credit_account_id IS NULL").fetchall():
            c = dict(c)
            c['display_name'] = _credit_client_display_name(c)
            c['solde'], c['deposit'] = _split_debt(_credit_net_debt(c))
            unlinked.setdefault(_norm_credit_name(c['display_name']), []).append(
                {k: c[k] for k in ('id', 'display_name', 'credit_limit', 'solde', 'deposit', 'no_sync')})
        for r in rows:
            r['display_name'] = _credit_client_display_name(r)
            r['solde'], r['deposit'] = _split_debt(r['debt'])
            r['candidates'] = unlinked.get(_norm_credit_name(r['display_name']), [])
        return rows
    finally:
        conn.close()


def db_ls_link_pending(ls_id, client_id):
    """Associe un compte Lightspeed en attente à un compte Kubios existant
    (client_id) ou à un nouveau compte (client_id None). Retourne (client, action)."""
    conn = get_conn()
    try:
        p = conn.execute("SELECT * FROM ls_pending_accounts WHERE ls_credit_account_id=?", (ls_id,)).fetchone()
        if p is None:
            raise RuntimeError("Ce compte Lightspeed n'est plus en attente (relance la synchronisation).")
        p = dict(p)
        row = {'ls_id': p['ls_credit_account_id'], 'ls_customer_id': p['ls_customer_id'],
               'prenom_entreprise': p['prenom_entreprise'], 'nom': p['nom'],
               'credit_limit': float(p['credit_limit'] or 0)}
        if conn.execute("SELECT 1 FROM credit_clients WHERE ls_credit_account_id=?", (ls_id,)).fetchone():
            raise RuntimeError("Ce compte Lightspeed est déjà associé à un compte Kubios.")
        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        today = datetime.date.today().strftime('%Y-%m-%d')
        if client_id:
            c = conn.execute("SELECT * FROM credit_clients WHERE id=?", (client_id,)).fetchone()
            if c is None:
                raise RuntimeError("Compte Kubios introuvable.")
            client = dict(c)
            if client.get('ls_credit_account_id'):
                raise RuntimeError("Ce compte Kubios est déjà associé à un autre compte Lightspeed.")
            conn.execute("UPDATE credit_clients SET ls_credit_account_id=?, ls_customer_id=? WHERE id=?",
                         (ls_id, row['ls_customer_id'], client['id']))
            action = 'linked'
        else:
            client = _ls_insert_client(conn, row, now,
                                       "Créé lors d'une association manuelle (synchronisation Lightspeed).")
            action = 'created'
        if not client.get('no_sync'):
            _ls_apply_values(conn, client, row, float(p['debt'] or 0), now, today,
                             'Association manuelle Lightspeed')
        conn.execute("DELETE FROM ls_pending_accounts WHERE ls_credit_account_id=?", (ls_id,))
        conn.commit()
        client['display_name'] = _credit_client_display_name(client)
        return client, action, p
    finally:
        conn.close()


_ls_ar_lock = threading.Lock()


_ls_ar_state = {'running': False, 'progress': '', 'error': None, 'preview': None, 'by': None}


def _last_day_next_month(d):
    first_next = (d.replace(day=1) + datetime.timedelta(days=32)).replace(day=1)
    return (first_next + datetime.timedelta(days=32)).replace(day=1) - datetime.timedelta(days=1)


def _ls_customer_names(cust):
    """Variantes de nom d'un client Lightspeed (pour l'association par nom)."""
    first = (cust.get('firstName') or '').strip()
    last = (cust.get('lastName') or '').strip()
    company = (cust.get('company') or '').strip()
    display = company or f"{first} {last}".strip() or f"Client Lightspeed {cust.get('customerID') or ''}".strip()
    variants = {v for v in (company, f"{first} {last}".strip(), f"{last} {first}".strip()) if v}
    return display, variants


def _ar_existing_numbers(conn):
    return {str(r['numero']).strip() for r in conn.execute(
        "SELECT numero FROM invoices WHERE numero IS NOT NULL AND TRIM(numero) <> ''").fetchall()}


def ls_ar_build_preview(since, username, include_ignored=False):
    """Lit les ventes portées au compte depuis `since` (date) et prépare
    l'aperçu. Retourne le dictionnaire d'aperçu (gardé en mémoire)."""
    st = _ls_ar_state
    cfg = ls_config()
    account_id = cfg['account_id']
    if not account_id:
        account_id, name = ls_fetch_account()
        meta_set('ls_account_id', account_id)
        meta_set('ls_account_name', name)
    start = datetime.datetime.combine(since, datetime.time()).astimezone().isoformat(timespec='seconds')
    params = {'completed': 'true', 'completeTime': f'>,{start}',
              'load_relations': json.dumps(['SalePayments', 'SalePayments.PaymentType', 'Customer'])}
    sales = _ls_get_all(account_id, 'Sale', params, 'Ventes', state=st)
    st['progress'] = "Comparaison avec Kubios…"

    conn = get_conn()
    try:
        existing = _ar_existing_numbers(conn)
        clients = [r['name'] for r in conn.execute("SELECT name FROM clients").fetchall()]
        mapping = {r['ls_customer_id']: r['client_name']
                   for r in conn.execute("SELECT * FROM ls_ar_customers").fetchall()}
        aliases = [dict(r) for r in conn.execute("SELECT * FROM ls_ar_aliases").fetchall()]
        ignored = {r['sale_id'] for r in conn.execute("SELECT sale_id FROM ls_ar_ignored").fetchall()}
        done_payments = {r['sale_id'] for r in conn.execute("SELECT sale_id FROM ls_ar_payments").fetchall()}
    finally:
        conn.close()
    client_set = set(clients)
    by_norm = {}
    for c in clients:
        by_norm.setdefault(_norm_credit_name(c), []).append(c)
    # noms reconnus (anciens noms, clients fusionnés) -> client Kubios
    for a in aliases:
        if a['client_name'] in client_set and a['client_name'] not in by_norm.get(a['alias'], []):
            by_norm.setdefault(a['alias'], []).append(a['client_name'])

    # Champ du numéro : numéro de vente (saleID) par défaut ; si les numéros
    # déjà dans Kubios correspondent plutôt au numéro de billet, on prend celui-là.
    number_field = meta_get('ls_ar_number_field') or ''
    if number_field not in ('saleID', 'ticketNumber'):
        m_sale = sum(1 for s in sales if str(s.get('saleID') or '').strip() in existing)
        m_ticket = sum(1 for s in sales if str(s.get('ticketNumber') or '').strip() in existing)
        number_field = 'ticketNumber' if m_ticket > m_sale else 'saleID'
        if max(m_sale, m_ticket) >= 3:
            meta_set('ls_ar_number_field', number_field)

    today = datetime.date.today()
    items, payments = [], []
    counts = {'sales': len(sales), 'on_account': 0, 'in_kubios': 0, 'ignored': 0, 'payments_done': 0}
    for s in sales:
        if _truthy(s.get('voided')):
            continue
        on_acct = round(sum(_parse_money(p.get('amount'))
                            for p in _ls_as_list((s.get('SalePayments') or {}).get('SalePayment'))
                            if _ls_is_account_payment(p)), 2)
        if abs(on_acct) < 0.005:
            continue
        counts['on_account'] += 1
        total = _parse_money(s.get('calcTotal') or s.get('total'))
        cust = s.get('Customer') or {}
        cust_id = str(cust.get('customerID') or s.get('customerID') or '').strip()
        display, variants = _ls_customer_names(cust)
        client = mapping.get(cust_id) if mapping.get(cust_id) in client_set else None
        match = 'lien' if client else None
        if client is None:
            found = {c for v in variants for c in by_norm.get(_norm_credit_name(v), [])}
            if len(found) == 1:
                client, match = found.pop(), 'nom'
        date_vente = _ls_local_date(s.get('completeTime') or s.get('timeStamp')) or today.isoformat()
        sale_id = str(s.get('saleID') or '').strip()
        numero = str(s.get(number_field) or sale_id).strip()
        if on_acct < 0 and total >= -0.005:
            if sale_id in done_payments:
                counts['payments_done'] += 1
                continue
            payments.append({'sale_id': sale_id, 'date': date_vente, 'customer': display,
                             'customer_id': cust_id, 'client': client, 'match': match,
                             'montant': round(-on_acct, 2)})
            continue
        if numero in existing or sale_id in existing or str(s.get('ticketNumber') or '').strip() in existing:
            counts['in_kubios'] += 1
            continue
        is_ignored = sale_id in ignored
        if is_ignored:
            counts['ignored'] += 1
            if not include_ignored:
                continue
        try:
            d = datetime.date.fromisoformat(date_vente)
        except ValueError:
            d = today
        items.append({
            'sale_id': sale_id, 'numero': numero, 'date': date_vente,
            'echeance': _last_day_next_month(d).isoformat(),
            'montant': on_acct, 'kind': 'facture' if on_acct > 0 else 'credit',
            'customer_id': cust_id, 'customer': display, 'client': client, 'match': match,
            'ignored': is_ignored, 'sale_total': round(total, 2),
        })
    items.sort(key=lambda x: (x['client'] or x['customer']).lower() + x['date'])
    payments.sort(key=lambda x: (x['date'], x['sale_id']))
    _ar_propose_payments(payments, items)
    st['progress'] = "Vérification des soldes…"
    try:
        balances = _ls_ar_balance_check(account_id, items, payments)
    except LightspeedError as e:
        balances = {'error': str(e), 'rows': [], 'compared': 0, 'ok': 0, 'not_linked': []}
    return {
        'token': secrets.token_urlsafe(16),
        'created_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'since': since.isoformat(), 'until': today.isoformat(), 'by': username,
        'number_field': number_field, 'counts': counts,
        'items': items, 'payments': payments, 'balances': balances,
    }


def _ar_open_invoices(conn, client_names=None):
    """Factures ouvertes (solde > 0) par client, de la plus ancienne à la plus récente."""
    q = ("SELECT id, client_name, numero, date_facture, COALESCE(montant,0) - COALESCE(montant_paye,0) solde "
         "FROM invoices WHERE COALESCE(montant,0) - COALESCE(montant_paye,0) > 0.005")
    out = {}
    for r in conn.execute(q + " ORDER BY date_facture, id").fetchall():
        if client_names is not None and r['client_name'] not in client_names:
            continue
        out.setdefault(r['client_name'], []).append(
            {'id': r['id'], 'numero': r['numero'], 'date': r['date_facture'], 'solde': round(r['solde'], 2)})
    return out


def _ar_allocate(open_invoices, amount, first_id=None):
    """Répartit un paiement sur les factures ouvertes d'un client :
    1) la facture choisie (first_id) en premier, sinon une facture dont le
       solde est exactement le montant payé ; 2) puis les plus anciennes.
    Retourne ([(facture, montant appliqué)], excédent non appliqué)."""
    order = list(open_invoices)
    first = None
    if first_id:
        first = next((i for i in order if i['id'] == first_id), None)
    if first is None:
        first = next((i for i in order if abs(i['solde'] - amount) < 0.005), None)
    if first is not None:
        order = [first] + [i for i in order if i is not first]
    rest = round(amount, 2)
    alloc = []
    for inv in order:
        if rest < 0.005:
            break
        a = round(min(inv['solde'], rest), 2)
        if a < 0.005:
            continue
        alloc.append((inv, a))
        rest = round(rest - a, 2)
    return alloc, max(rest, 0.0)


def _ar_propose_payments(payments, items=()):
    """Ajoute à chaque paiement la répartition proposée (simulée dans l'ordre
    des dates, pour que deux paiements du même client ne visent pas le même
    solde) et la liste des factures ouvertes au moment du paiement."""
    clients = {p['client'] for p in payments if p['client']}
    if not clients:
        return
    conn = get_conn()
    try:
        open_by_client = _ar_open_invoices(conn, clients)
    finally:
        conn.close()
    # Les nouvelles factures de la même vérification comptent aussi (comme à
    # l'application, où elles sont inscrites avant les paiements).
    for it in items:
        if it.get('client') in clients and it['montant'] > 0:
            open_by_client.setdefault(it['client'], []).append(
                {'id': None, 'numero': it['numero'], 'date': it['date'], 'solde': it['montant'], 'new': True})
    for lst in open_by_client.values():
        lst.sort(key=lambda i: (i['date'] or '', i['id'] is None, i['id'] or 0))
    for p in payments:
        p['options'], p['pool'], p['allocations'], p['leftover'] = [], [], [], 0.0
        if not p['client']:
            continue
        opens = open_by_client.get(p['client'], [])
        p['pool'] = [dict(i) for i in opens]
        p['options'] = [dict(i) for i in opens if i['id'] is not None]
        alloc, rest = _ar_allocate(opens, p['montant'])
        p['allocations'] = [{'invoice_id': i['id'], 'numero': i['numero'], 'date': i['date'],
                             'solde': i['solde'], 'applique': a, 'new': bool(i.get('new'))} for i, a in alloc]
        p['leftover'] = rest
        for i, a in alloc:
            i['solde'] = round(i['solde'] - a, 2)
        open_by_client[p['client']] = [i for i in opens if i['solde'] > 0.005]


def _ls_ar_balance_check(account_id, items, payments):
    """Compare, pour chaque client des comptes à recevoir relié à Lightspeed,
    le solde Kubios (factures - payé) au solde de son compte de crédit."""
    sign = ls_config()['balance_sign']
    if sign not in ('positive_du', 'negative_du'):
        raise LightspeedError("Le sens du solde Lightspeed n'est pas encore connu : lance d'abord une "
                              "synchronisation des comptes de crédit (ou choisis-le dans Administration).")
    conn = get_conn()
    try:
        soldes = {r['client_name']: round(r['s'] or 0, 2) for r in conn.execute(
            "SELECT client_name, SUM(COALESCE(montant,0) - COALESCE(montant_paye,0)) s FROM invoices "
            "GROUP BY client_name").fetchall()}
        clients = [r['name'] for r in conn.execute("SELECT name FROM clients").fetchall()]
        mapping = {r['client_name']: r['ls_customer_id'] for r in conn.execute("SELECT * FROM ls_ar_customers")}
        credit_by_name = {}
        for r in conn.execute("SELECT prenom_entreprise, nom, ls_customer_id FROM credit_clients "
                              "WHERE ls_customer_id IS NOT NULL").fetchall():
            credit_by_name.setdefault(_norm_credit_name(_credit_client_display_name(dict(r))), []).append(
                r['ls_customer_id'])
    finally:
        conn.close()
    for it in list(items) + list(payments):
        if it.get('client') and it.get('customer_id') and it['client'] not in mapping:
            mapping[it['client']] = it['customer_id']
    links, not_linked = {}, []
    for c in clients:
        cid = mapping.get(c)
        if not cid:
            same = credit_by_name.get(_norm_credit_name(c)) or []
            cid = same[0] if len(same) == 1 else None
        if cid:
            links[c] = str(cid)
        elif abs(soldes.get(c, 0)) >= 0.01:
            not_linked.append({'client': c, 'kubios': soldes.get(c, 0)})
    # Lightspeed : client -> compte de crédit -> solde
    ids = sorted(set(links.values()))
    ca_by_customer = {}
    for k in range(0, len(ids), 100):
        batch = ids[k:k + 100]
        for cu in _ls_get_all(account_id, 'Customer', {'customerID': 'IN,[' + ','.join(batch) + ']'},
                              'Soldes (clients)', state=_ls_ar_state):
            ca = str(cu.get('creditAccountID') or '').strip()
            if ca and ca != '0':
                ca_by_customer[str(cu.get('customerID'))] = ca
    cas = sorted(set(ca_by_customer.values()))
    balance_by_ca = {}
    for k in range(0, len(cas), 100):
        batch = cas[k:k + 100]
        for a in _ls_get_all(account_id, 'CreditAccount', {'creditAccountID': 'IN,[' + ','.join(batch) + ']'},
                             'Soldes (comptes)', state=_ls_ar_state):
            balance_by_ca[str(a.get('creditAccountID'))] = _parse_money(a.get('balance'))
    pending = {it['client'] for it in list(items) + list(payments) if it.get('client')}
    rows, ok, compared = [], 0, 0
    for c, cid in sorted(links.items(), key=lambda x: x[0].lower()):
        ca = ca_by_customer.get(cid)
        if ca is None or ca not in balance_by_ca:
            if abs(soldes.get(c, 0)) >= 0.01:
                not_linked.append({'client': c, 'kubios': soldes.get(c, 0)})
            continue
        compared += 1
        ls_debt = _ls_debt(balance_by_ca[ca], sign)
        k_solde = soldes.get(c, 0.0)
        ecart = round(k_solde - ls_debt, 2)
        if abs(ecart) < 0.01:
            ok += 1
        else:
            rows.append({'client': c, 'kubios': k_solde, 'lightspeed': ls_debt, 'ecart': ecart,
                         'pending': c in pending})
    rows.sort(key=lambda r: -abs(r['ecart']))
    not_linked.sort(key=lambda r: r['client'].lower())
    return {'error': None, 'rows': rows, 'compared': compared, 'ok': ok, 'not_linked': not_linked}


def start_ls_ar_check(since, username, include_ignored=False):
    if not _ls_ar_lock.acquire(blocking=False):
        raise LightspeedError("Une vérification est déjà en cours.")
    st = _ls_ar_state
    st.update(running=True, progress="Connexion à Lightspeed…", error=None, preview=None, by=username)

    def _run():
        try:
            st['preview'] = ls_ar_build_preview(since, username, include_ignored)
        except Exception as e:
            if not isinstance(e, LightspeedError):
                traceback.print_exc()
            st['error'] = str(e) if isinstance(e, LightspeedError) else f"Erreur inattendue : {e}"
        finally:
            st['running'] = False
            st['progress'] = ''
            _ls_ar_lock.release()

    threading.Thread(target=_run, daemon=True).start()


def _ls_fetch_customer_contact(customer_id):
    """Coordonnées d'un client Lightspeed (pour créer le client dans Kubios)."""
    acct = ls_config()['account_id']
    data = _ls_api_get(f"/Account/{acct}/Customer/{customer_id}.json",
                       {'load_relations': json.dumps(['Contact'])})
    cust = data.get('Customer') or {}
    contact = cust.get('Contact') or {}
    addr = (_ls_as_list((contact.get('Addresses') or {}).get('ContactAddress')) or [{}])[0]
    phones = _ls_as_list((contact.get('Phones') or {}).get('ContactPhone'))
    emails = _ls_as_list((contact.get('Emails') or {}).get('ContactEmail'))
    phone = next((p.get('number') for p in phones if p.get('number')), '')
    email = next((e.get('address') for e in emails if e.get('address')), '')
    adresse = " ".join(x for x in ((addr.get('address1') or '').strip(), (addr.get('address2') or '').strip()) if x)
    return {'phone': phone or '', 'courriel': email or '', 'adresse': adresse,
            'ville': (addr.get('city') or '').strip(), 'province': (addr.get('state') or '').strip() or 'Qc',
            'code_postal': (addr.get('zip') or '').strip()}


def ls_ar_apply(token, choices, username, payment_choices=None):
    """Inscrit les factures choisies et applique les paiements choisis.
    choices : [{sale_id, action: 'inscrire'|'ignorer', client: nom Kubios ou '' (nouveau client)}]
    payment_choices : [{sale_id, action: 'appliquer'|'deja_fait', first_invoice_id: id ou None}]"""
    pv = _ls_ar_state.get('preview')
    if not pv or pv['token'] != token:
        raise RuntimeError("Cette vérification n'est plus à jour : relance « Vérifier les factures ».")
    items = {it['sale_id']: it for it in pv['items']}
    pays = {p['sale_id']: p for p in pv.get('payments', [])}
    to_add, to_ignore, to_pay, to_mark = [], [], [], []
    conn = get_conn()
    known = {r['name'].lower(): r['name'] for r in conn.execute("SELECT name FROM clients").fetchall()}
    conn.close()
    to_link = []   # (ls_customer_id, nom Lightspeed, client Kubios)

    def _existing(name, what):
        c = known.get((name or '').strip().lower())
        if c is None:
            raise RuntimeError(f"« {name} » n'est pas un client existant dans Kubios ({what}). "
                               "Choisis un client dans la liste.")
        return c

    for ch in choices or []:
        it = items.get(str(ch.get('sale_id') or ''))
        if it is None:
            continue
        if ch.get('action') == 'inscrire':
            to_add.append((it, (ch.get('client') or '').strip()))
        elif ch.get('action') == 'ignorer':
            to_ignore.append(it)
        elif ch.get('action') == 'relier' and it['customer_id']:
            to_link.append((it['customer_id'], it['customer'],
                            _existing(ch.get('client') or it.get('client'), f"vente n° {it['numero']}")))
    for ch in payment_choices or []:
        p = pays.get(str(ch.get('sale_id') or ''))
        if p is None:
            continue
        if not p['client'] and ch.get('client') and ch.get('action') in ('appliquer', 'relier'):
            p = dict(p, client=_existing(ch['client'], f"paiement du {p['date']}"))
            if p['customer_id']:
                to_link.append((p['customer_id'], p['customer'], p['client']))
        if ch.get('action') == 'relier' and p['client'] and p['customer_id']:
            to_link.append((p['customer_id'], p['customer'], p['client']))
            continue
        if ch.get('action') == 'appliquer' and p['client']:
            try:
                first = int(ch.get('first_invoice_id') or 0) or None
            except (TypeError, ValueError):
                first = None
            to_pay.append((p, first))
        elif ch.get('action') == 'deja_fait':
            to_mark.append(p)
    if not to_add and not to_ignore and not to_pay and not to_mark and not to_link:
        raise RuntimeError("Aucune facture ni aucun paiement choisi.")

    label = f"Avant inscription de {len(to_add)} facture(s)"
    if to_pay:
        label += f" et {len(to_pay)} paiement(s)"
    backup_id = db_backup_scope('ar', label + " Lightspeed", username)
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    created, added, skipped = [], 0, 0
    conn = get_conn()
    existing_clients = {r['name'].lower(): r['name'] for r in conn.execute("SELECT name FROM clients").fetchall()}
    conn.close()
    # 1) clients à créer (coordonnées lues dans Lightspeed)
    resolved = []
    for it, client in to_add:
        name = client or it['customer']
        if name.lower() in existing_clients:
            resolved.append((it, existing_clients[name.lower()]))
            continue
        try:
            info = _ls_fetch_customer_contact(it['customer_id']) if it['customer_id'] else {}
        except LightspeedError:
            info = {}
        db_create_client(name, info.get('phone'), info.get('adresse'), info.get('ville'),
                         info.get('province'), info.get('code_postal'), info.get('courriel'))
        existing_clients[name.lower()] = name
        created.append(name)
        resolved.append((it, name))
    # 2) factures + liens client, en une transaction
    conn = get_conn()
    try:
        numbers = _ar_existing_numbers(conn)
        for it, client in resolved:
            if it['numero'] in numbers:
                skipped += 1
                continue
            conn.execute(
                "INSERT INTO invoices(client_name, numero, date_facture, echeance, montant, notes, montant_paye, "
                "date_paiement) VALUES (?,?,?,?,?,?,0,NULL)",
                (client, it['numero'], it['date'], it['echeance'], it['montant'],
                 f"Inscrite depuis Lightspeed (vente #{it['sale_id']})"))
            numbers.add(it['numero'])
            added += 1
            if it['customer_id']:
                conn.execute("INSERT OR REPLACE INTO ls_ar_customers(ls_customer_id, client_name, linked_at, ls_name) "
                             "VALUES (?,?,?,?)", (it['customer_id'], client, now, it['customer']))
            conn.execute("DELETE FROM ls_ar_ignored WHERE sale_id=?", (it['sale_id'],))
        for cid, ls_name, client in to_link:
            conn.execute("INSERT OR REPLACE INTO ls_ar_customers(ls_customer_id, client_name, linked_at, ls_name) "
                         "VALUES (?,?,?,?)", (cid, client, now, ls_name))
        for it in to_ignore:
            conn.execute("INSERT OR REPLACE INTO ls_ar_ignored(sale_id, ignored_at, username, info) VALUES (?,?,?,?)",
                         (it['sale_id'], now, username or '?',
                          f"{it['customer']} — n° {it['numero']} — {it['montant']:.2f} $ — {it['date']}"))
        # 3) paiements : répartition recalculée sur les factures ouvertes actuelles
        #    (y compris celles qu'on vient d'inscrire), dans l'ordre des dates.
        applied = []
        open_by_client = _ar_open_invoices(conn, {p['client'] for p, _ in to_pay})
        for p, first in sorted(to_pay, key=lambda x: (x[0]['date'], x[0]['sale_id'])):
            if conn.execute("SELECT 1 FROM ls_ar_payments WHERE sale_id=?", (p['sale_id'],)).fetchone():
                continue
            opens = open_by_client.get(p['client'], [])
            alloc, rest = _ar_allocate(opens, p['montant'], first)
            for inv, a in alloc:
                conn.execute("UPDATE invoices SET montant_paye = ROUND(COALESCE(montant_paye,0) + ?, 2), "
                             "date_paiement = ? WHERE id=?", (a, p['date'], inv['id']))
                inv['solde'] = round(inv['solde'] - a, 2)
            open_by_client[p['client']] = [i for i in opens if i['solde'] > 0.005]
            details = {'allocations': [{'invoice_id': i['id'], 'numero': i['numero'], 'montant': a} for i, a in alloc],
                       'excedent': rest}
            conn.execute("INSERT INTO ls_ar_payments(sale_id, client_name, payment_date, montant, status, details, "
                         "processed_at, username) VALUES (?,?,?,?,?,?,?,?)",
                         (p['sale_id'], p['client'], p['date'], p['montant'], 'applique',
                          json.dumps(details), now, username or '?'))
            applied.append({'client': p['client'], 'montant': p['montant'], 'date': p['date'],
                            'factures': [f"n° {i['numero']} ({_fmt_money_fr(a)})" for i, a in alloc], 'excedent': rest})
        for p in to_mark:
            conn.execute("INSERT OR REPLACE INTO ls_ar_payments(sale_id, client_name, payment_date, montant, status, "
                         "details, processed_at, username) VALUES (?,?,?,?,?,?,?,?)",
                         (p['sale_id'], p['client'] or p['customer'], p['date'], p['montant'], 'deja_fait',
                          None, now, username or '?'))
        conn.commit()
    finally:
        conn.close()
    if not added and not created and not applied:
        db_discard_credit_backup(backup_id)
        backup_id = None
    meta_set('ls_ar_last_until', pv['until'])
    mark_dirty()
    _ls_ar_state['preview'] = None
    return {'added': added, 'ignored': len(to_ignore), 'created_clients': created,
            'skipped': skipped, 'backup_id': backup_id, 'payments_applied': applied,
            'payments_marked': len(to_mark),
            'linked': sorted({f"{n} → {c}" for _, n, c in to_link})}


BACKUP_DIR = BASE_DIR / "Backups_auto"


MAX_BACKUPS = 20


_sync_lock = threading.Lock()


_sync_state = {"running": False, "last_error": None}


def _prune_backups():
    backups = sorted(BACKUP_DIR.glob("Compte à recevoir_*.xlsx"), key=lambda p: p.stat().st_mtime)
    for old in backups[:-MAX_BACKUPS]:
        try:
            old.unlink()
        except OSError:
            pass


def save_wb_atomic(wb):
    """Écriture atomique : fichier temporaire vérifié, puis remplacement. Une
    interruption pendant l'écriture ne peut jamais corrompre le fichier original."""
    if EXCEL_PATH.exists():
        try:
            stamp = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
            shutil.copy2(EXCEL_PATH, BACKUP_DIR / f"Compte à recevoir_{stamp}.xlsx")
            _prune_backups()
        except OSError:
            pass

    tmp_path = EXCEL_PATH.with_name(EXCEL_PATH.stem + ".tmp_write.xlsx")
    try:
        wb.save(tmp_path)
    except PermissionError:
        raise RuntimeError(
            "Impossible d'enregistrer : le fichier Excel est probablement ouvert. "
            "Ferme 'Compte à recevoir.xlsx' dans Excel puis réessaie."
        )
    try:
        check = openpyxl.load_workbook(tmp_path, read_only=True)
        check.close()
    except Exception as e:
        tmp_path.unlink(missing_ok=True)
        raise RuntimeError(f"Écriture invalide, annulée sans toucher l'original. Détail : {e}")
    os.replace(tmp_path, EXCEL_PATH)


def set_row_formulas(ws, row):
    # les tranches d'âge (G-J) se basent sur M (le solde restant après paiement),
    # pas sur F (le montant facturé au complet)
    ws.cell(row=row, column=7, value=f"=IF(TODAY()<=E{row},M{row},0)")
    ws.cell(row=row, column=8, value=f"=IF(AND(TODAY()>E{row},TODAY()-E{row}<=30),M{row},0)")
    ws.cell(row=row, column=9, value=f"=IF(AND(TODAY()-E{row}>30,TODAY()-E{row}<=60),M{row},0)")
    ws.cell(row=row, column=10, value=f"=IF(TODAY()-E{row}>60,M{row},0)")
    ws.cell(row=row, column=13, value=f"=F{row}-L{row}")  # solde = montant - payé
    for c in (7, 8, 9, 10, 12, 13):
        ws.cell(row=row, column=c).number_format = '#,##0.00;\\(#,##0.00\\)'


def refresh_header_sums(ws, last_row):
    last_row = max(last_row, FORMULA_MIN_LAST_ROW)
    for col in (6, 7, 8, 9, 10, 12, 13):
        letter = get_column_letter(col)
        ws.cell(row=2, column=col, value=f"=SUM({letter}3:{letter}{last_row})")


def write_client_sheet(ws, client_row, invoices):
    """Réécrit entièrement le bloc de factures d'un onglet client à partir des
    données SQLite (source unique de vérité)."""
    # efface l'ancien bloc de factures (colonnes C..M, à partir de la ligne 2)
    for r in range(2, max(ws.max_row, FORMULA_MIN_LAST_ROW) + 1):
        for c in range(3, 14):
            ws.cell(row=r, column=c).value = None

    ws.cell(row=1, column=12, value='Payé')
    ws.cell(row=1, column=13, value='Solde')

    ws.cell(row=2, column=1, value=client_row['name'])
    ws.cell(row=2, column=2, value=client_row['phone'] or '')
    ws.cell(row=INFO_ROWS['adresse'], column=1, value='Adresse')
    ws.cell(row=INFO_ROWS['adresse'], column=2, value=client_row['adresse'] or '')
    ws.cell(row=INFO_ROWS['ville'], column=1, value='Ville')
    ws.cell(row=INFO_ROWS['ville'], column=2, value=client_row['ville'] or '')
    ws.cell(row=INFO_ROWS['province'], column=1, value='Province')
    ws.cell(row=INFO_ROWS['province'], column=2, value=client_row['province'] or 'Qc')
    ws.cell(row=INFO_ROWS['code_postal'], column=1, value='Code Postal')
    ws.cell(row=INFO_ROWS['code_postal'], column=2, value=client_row['code_postal'] or '')
    ws.cell(row=INFO_ROWS['courriel'], column=1, value='Adresse couriel')
    ws.cell(row=INFO_ROWS['courriel'], column=2, value=client_row['courriel'] or '')

    row = FIRST_INVOICE_ROW
    for inv in invoices:
        ws.cell(row=row, column=3, value=inv['numero'])
        try:
            d = datetime.datetime.strptime(inv['date_facture'], '%Y-%m-%d') if inv['date_facture'] else None
        except ValueError:
            d = None
        try:
            e = datetime.datetime.strptime(inv['echeance'], '%Y-%m-%d') if inv['echeance'] else None
        except ValueError:
            e = None
        if d:
            ws.cell(row=row, column=4, value=d).number_format = 'dd-mm-yyyy'
        if e:
            ws.cell(row=row, column=5, value=e).number_format = 'dd/mm/yyyy'
        ws.cell(row=row, column=6, value=float(inv['montant'])).number_format = '#,##0.00;\\(#,##0.00\\)'
        if inv['notes']:
            ws.cell(row=row, column=11, value=inv['notes'])
        ws.cell(row=row, column=12, value=float(inv.get('montant_paye') or 0))
        set_row_formulas(ws, row)
        row += 1

    last_row = max(row - 1, FORMULA_MIN_LAST_ROW)
    refresh_header_sums(ws, last_row)


def export_to_excel():
    """Régénère le fichier Excel complet à partir de la base SQLite. Opération
    lente (~20-30s) — appelée en arrière-plan ou à la demande, jamais bloquante
    pour la saisie."""
    with _sync_lock:
        _sync_state["running"] = True
        _sync_state["last_error"] = None
        try:
            wb = openpyxl.load_workbook(EXCEL_PATH, data_only=False)
            conn = get_conn()
            # Renommages d'onglets en attente (clients renommés dans l'app).
            pending_row = conn.execute("SELECT value FROM meta WHERE key='pending_sheet_renames'").fetchone()
            try:
                pending_renames = json.loads(pending_row['value']) if pending_row and pending_row['value'] else []
            except Exception:
                pending_renames = []
            for old_sheet, new_sheet in pending_renames:
                if old_sheet not in wb.sheetnames or old_sheet == new_sheet:
                    continue
                if any(n.lower() == new_sheet.lower() for n in wb.sheetnames if n != old_sheet):
                    continue  # un onglet porte déjà ce nom : on ne touche à rien
                ws_r = wb[old_sheet]
                if old_sheet.lower() == new_sheet.lower():
                    # changement de majuscules seulement : openpyxl exige un nom intermédiaire
                    ws_r.title = "_renommage_tmp_"
                ws_r.title = new_sheet

            clients = conn.execute("SELECT * FROM clients ORDER BY name COLLATE NOCASE").fetchall()

            # Onglets de clients fusionnés dans un autre (1.11.3) : supprimés, sauf
            # si un client utilise encore ce nom d'onglet.
            del_row = conn.execute("SELECT value FROM meta WHERE key='pending_sheet_deletes'").fetchone()
            try:
                pending_deletes = json.loads(del_row['value']) if del_row and del_row['value'] else []
            except Exception:
                pending_deletes = []
            used_sheets = {c['sheet_name'] for c in clients}
            for sh in pending_deletes:
                if sh in wb.sheetnames and sh not in used_sheets and sh not in (SOMMAIRE_SHEET, MODELE_SHEET):
                    wb.remove(wb[sh])

            sommaire = wb[SOMMAIRE_SHEET]
            # efface les anciennes lignes du Sommaire (à partir de la ligne 3)
            for r in range(3, max(sommaire.max_row, len(clients) + 5) + 1):
                for c in range(1, 8):
                    sommaire.cell(row=r, column=c).value = None

            srow = 3
            for c in clients:
                sheet_name = c['sheet_name']
                if sheet_name not in wb.sheetnames:
                    ws = wb.copy_worksheet(wb[MODELE_SHEET])
                    ws.title = sheet_name
                    if ws.title != sheet_name:
                        # openpyxl a ajouté un suffixe (nom déjà pris) : on garde
                        # la base alignée sur le vrai nom de l'onglet.
                        conn.execute("UPDATE clients SET sheet_name=? WHERE name=?", (ws.title, c['name']))
                        sheet_name = ws.title
                else:
                    ws = wb[sheet_name]
                invoices = conn.execute(
                    "SELECT * FROM invoices WHERE client_name=? ORDER BY id", (c['name'],)
                ).fetchall()
                write_client_sheet(ws, c, [dict(i) for i in invoices])

                sommaire.cell(row=srow, column=1, value=c['name'])
                sommaire.cell(row=srow, column=2, value=f"='{sheet_name}'!G2")
                sommaire.cell(row=srow, column=3, value=f"='{sheet_name}'!H2")
                sommaire.cell(row=srow, column=4, value=f"='{sheet_name}'!I2")
                sommaire.cell(row=srow, column=5, value=f"='{sheet_name}'!J2")
                sommaire.cell(row=srow, column=6, value=f"='{sheet_name}'!M2")  # solde restant, pas le montant facturé
                sommaire.cell(row=srow, column=7, value=f"=SUM(B{srow}:E{srow})")
                srow += 1

            last_sommaire_row = max(srow - 1, 3)
            for col in (2, 3, 4, 5, 6):
                letter = get_column_letter(col)
                sommaire.cell(row=2, column=col, value=f"=SUM({letter}3:{letter}{last_sommaire_row})")
            sommaire.cell(row=2, column=7, value="=SUM(B2:E2)")

            counter_row = conn.execute("SELECT value FROM meta WHERE key='statement_counter'").fetchone()
            if counter_row:
                sommaire.cell(row=2, column=13, value=int(counter_row['value']))

            log_ws = wb[LOG_SHEET]
            pending_logs = conn.execute("SELECT * FROM log_envois WHERE synced=0 ORDER BY id").fetchall()
            r = log_ws.max_row + 1
            for lg in pending_logs:
                log_ws.cell(row=r, column=1, value=lg['ts'])
                log_ws.cell(row=r, column=2, value=lg['client'])
                log_ws.cell(row=r, column=3, value=lg['courriel'])
                log_ws.cell(row=r, column=4, value=lg['total'])
                log_ws.cell(row=r, column=5, value=lg['statut'])
                log_ws.cell(row=r, column=6, value=lg['note'])
                r += 1

            save_wb_atomic(wb)

            conn.execute("UPDATE log_envois SET synced=1 WHERE synced=0")
            conn.execute("DELETE FROM meta WHERE key='pending_sheet_renames'")
            conn.execute("DELETE FROM meta WHERE key='pending_sheet_deletes'")
            conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('dirty', '0')")
            conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('last_sync', ?)",
                         (datetime.datetime.now().isoformat(),))
            conn.commit()
            conn.close()
        except Exception as e:
            _sync_state["last_error"] = str(e)
            traceback.print_exc()
            raise
        finally:
            _sync_state["running"] = False


HEADER_RESERVED_HEIGHT = 62  # mm réservés en haut de la page 1 pour titre + logo


def generate_statement_pdf(client_name, info, invoices, totals, statement_number):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Table, TableStyle,
                                     Paragraph, Spacer, NextPageTemplate, PageBreak, ListFlowable,
                                     ListItem)
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

    safe_name = re.sub(r'[\\/:*?"<>|]', '_', client_name)
    pdf_path = PDF_DIR / f"Etat_de_compte_{safe_name}_{statement_number}.pdf"

    page_w, page_h = letter
    left_margin = right_margin = 18 * mm
    bottom_margin = 18 * mm

    styles = getSampleStyleSheet()
    h1 = ParagraphStyle('h1', parent=styles['Heading1'], fontSize=13, spaceAfter=6, spaceBefore=2)
    normal = ParagraphStyle('normal', parent=styles['Normal'], fontSize=10, leading=15)
    label_normal = ParagraphStyle('labelnormal', parent=normal)
    small = ParagraphStyle('small', parent=styles['Normal'], fontSize=9, leading=13)
    footer_style = ParagraphStyle('footer', parent=styles['Normal'], fontSize=10)

    emission_date = datetime.date.today().strftime('%Y-%m-%d')

    def draw_header(canvas, doc_):
        canvas.saveState()
        x = left_margin
        top = page_h - 20 * mm

        canvas.setFont('Helvetica-Bold', 22)
        canvas.drawString(x, top, "ÉTAT DE COMPTE")

        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 10 * mm, "Date d'émission :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 32 * mm, top - 10 * mm, emission_date)
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 15 * mm, "Numéro d'état de compte :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 45 * mm, top - 15 * mm, statement_number)

        if LOGO_PATH.exists():
            from reportlab.lib.utils import ImageReader
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            logo_w = 65 * mm
            logo_h = logo_w * ih / iw
            canvas.drawImage(img, page_w - right_margin - logo_w, top - logo_h + 4 * mm,
                              width=logo_w, height=logo_h, mask='auto')

        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.setLineWidth(0.5)
        rule_y = top - 22 * mm
        canvas.line(left_margin, rule_y, page_w - right_margin, rule_y)
        canvas.restoreState()

    def draw_plain(canvas, doc_):
        pass

    frame_first = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                         page_h - bottom_margin - HEADER_RESERVED_HEIGHT * mm, id='first')
    frame_rest = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                        page_h - bottom_margin - 15 * mm, id='rest')

    doc = BaseDocTemplate(str(pdf_path), pagesize=letter)
    doc.addPageTemplates([
        PageTemplate(id='First', frames=[frame_first], onPage=draw_header),
        PageTemplate(id='Rest', frames=[frame_rest], onPage=draw_plain),
    ])

    def field(label, value):
        return Paragraph(f"<b>{label} :</b> {value}", label_normal)

    story = []
    story.append(Paragraph("Information du client", h1))
    story.append(field("Client", client_name))
    story.append(field("Adresse", info.get('adresse', '') or '—'))
    ville_prov = f"{info.get('ville','')}, {info.get('province','')}".strip(', ')
    story.append(field("Ville / Province", ville_prov or '—'))
    story.append(field("Courriel", info.get('courriel', '') or '—'))
    story.append(field("Téléphone", info.get('phone', '') or '—'))
    story.append(Spacer(1, 6 * mm))

    from reportlab.platypus.flowables import HRFlowable
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))
    story.append(Spacer(1, 4 * mm))

    story.append(Paragraph("Sommaire des soldes", h1))
    tranche_rows = [
        ["Tranche", "Montant"],
        ["0 – 30 jours", f"{totals['g']:,.2f} $"],
        ["31 – 60 jours", f"{totals['h']:,.2f} $"],
        ["61 – 90 jours", f"{totals['i']:,.2f} $"],
        ["90+ jours", f"{totals['j']:,.2f} $"],
        ["TOTAL DÛ", f"{totals['montant']:,.2f} $"],
    ]
    tranche_table = Table(tranche_rows, colWidths=[70 * mm, 60 * mm])
    tranche_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('TOPPADDING', (0, 0), (-1, -1), 7),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
        ('LINEBELOW', (0, 0), (-1, 0), 0.5, colors.HexColor('#cccccc')),
        ('ALIGN', (1, 0), (1, -1), 'LEFT'),
    ]))
    story.append(tranche_table)
    story.append(Spacer(1, 4 * mm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))

    story.append(NextPageTemplate('Rest'))
    story.append(PageBreak())

    # Le montant affiché est le solde restant (montant facturé moins paiement partiel
    # déjà reçu) — une facture entièrement payée n'apparaît plus dans le détail.
    billable = [inv for inv in invoices if inv.get('solde', inv['montant']) != 0]
    has_partial = any(inv.get('montant_paye') for inv in billable)
    if billable:
        story.append(Paragraph("Détail des factures dues", h1))
        story.append(Spacer(1, 3 * mm))
        data = [["Facture", "Date", "Échéance", "Montant"]]
        for inv in billable:
            montant_affiche = inv.get('solde', inv['montant'])
            suffix = " *" if inv.get('montant_paye') else ""
            data.append([str(inv['numero']) + suffix, inv['date_facture'], inv['echeance'],
                         f"{montant_affiche:,.2f} $"])
        det_table = Table(data, colWidths=[38 * mm, 33 * mm, 33 * mm, 38 * mm], repeatRows=0)
        det_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
            ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ]))
        story.append(det_table)
        if has_partial:
            story.append(Spacer(1, 2 * mm))
            story.append(Paragraph("* Solde après un paiement partiel déjà reçu.", small))
        story.append(Spacer(1, 6 * mm))

    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph("Modalités et paiement", h1))
    bullets = [
        "Merci d'indiquer le <b>numéro de facture</b> lors du paiement.",
        "Pour toute question concernant votre état de compte, communiquez avec nous.",
        "Les montants indiqués sont dus immédiatement, sauf entente contraire.",
    ]
    story.append(ListFlowable(
        [ListItem(Paragraph(b, small), spaceAfter=4) for b in bullets],
        bulletType='bullet', start='circle', leftIndent=12,
    ))
    story.append(Spacer(1, 6 * mm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph(f"<b>{get_pdf_footer_message()}</b><br/>&nbsp;{get_company_name()}", footer_style))

    doc.build(story)
    return pdf_path


def db_invoices_by_month(year, month):
    """Toutes les factures dont la date de facture tombe dans le mois donné, groupées par client."""
    ym = f"{year:04d}-{month:02d}"
    conn = get_conn()
    rows = conn.execute(
        "SELECT client_name, numero, date_facture, echeance, montant, notes "
        "FROM invoices WHERE date_facture LIKE ? ORDER BY client_name COLLATE NOCASE, date_facture",
        (f"{ym}-%",)
    ).fetchall()
    conn.close()
    by_client = {}
    for r in rows:
        by_client.setdefault(r['client_name'], []).append(dict(r))
    return by_client


MOIS_FR = ["", "Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet",
           "Août", "Septembre", "Octobre", "Novembre", "Décembre"]


def generate_monthly_report_pdf(year, month, by_client):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Table, TableStyle,
                                     Paragraph, Spacer, NextPageTemplate, PageBreak)
    from reportlab.platypus.flowables import HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader

    mois_nom = MOIS_FR[month]
    report_dir = PDF_DIR / "Rapports_mensuels"
    report_dir.mkdir(exist_ok=True)
    pdf_path = report_dir / f"Rapport_{year:04d}-{month:02d}.pdf"

    page_w, page_h = letter
    left_margin = right_margin = 18 * mm
    bottom_margin = 18 * mm
    header_reserved = 55  # mm

    styles = getSampleStyleSheet()
    h1 = ParagraphStyle('h1', parent=styles['Heading1'], fontSize=12, spaceAfter=4, spaceBefore=8)
    footer_style = ParagraphStyle('footer', parent=styles['Normal'], fontSize=10)

    emission_date = datetime.date.today().strftime('%Y-%m-%d')

    def draw_header(canvas, doc_):
        canvas.saveState()
        x = left_margin
        top = page_h - 20 * mm
        canvas.setFont('Helvetica-Bold', 18)
        canvas.drawString(x, top, "RAPPORT MENSUEL — COMPTES À RECEVOIR")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 9 * mm, "Période :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 20 * mm, top - 9 * mm, f"{mois_nom} {year}")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 14 * mm, "Généré le :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 24 * mm, top - 14 * mm, emission_date)

        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            logo_w = 55 * mm
            logo_h = logo_w * ih / iw
            canvas.drawImage(img, page_w - right_margin - logo_w, top - logo_h + 2 * mm,
                              width=logo_w, height=logo_h, mask='auto')

        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.setLineWidth(0.5)
        rule_y = top - 19 * mm
        canvas.line(left_margin, rule_y, page_w - right_margin, rule_y)
        canvas.restoreState()

    def draw_plain(canvas, doc_):
        pass

    frame_first = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                         page_h - bottom_margin - header_reserved * mm, id='first')
    frame_rest = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                        page_h - bottom_margin - 15 * mm, id='rest')

    doc = BaseDocTemplate(str(pdf_path), pagesize=letter)
    doc.addPageTemplates([
        PageTemplate(id='First', frames=[frame_first], onPage=draw_header),
        PageTemplate(id='Rest', frames=[frame_rest], onPage=draw_plain),
    ])

    story = []
    client_names = sorted(by_client.keys(), key=lambda s: s.lower())
    grand_total = 0.0
    n_invoices = 0

    if not client_names:
        story.append(Paragraph(f"Aucune facture datée de {mois_nom} {year} n'a été trouvée.", styles['Normal']))
    else:
        for client_name in client_names:
            invs = by_client[client_name]
            subtotal = sum(i['montant'] for i in invs)
            grand_total += subtotal
            n_invoices += len(invs)

            story.append(Paragraph(client_name, h1))
            data = [["Facture", "Date", "Échéance", "Montant"]]
            for i in invs:
                data.append([str(i['numero']), i['date_facture'], i['echeance'] or '—',
                             f"{i['montant']:,.2f} $"])
            data.append(["", "", "Sous-total :", f"{subtotal:,.2f} $"])
            t = Table(data, colWidths=[38 * mm, 33 * mm, 33 * mm, 38 * mm], repeatRows=1)
            t.setStyle(TableStyle([
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 9),
                ('GRID', (0, 0), (-1, -2), 0.5, colors.black),
                ('LINEABOVE', (0, -1), (-1, -1), 0.75, colors.black),
                ('TOPPADDING', (0, 0), (-1, -1), 5),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ]))
            story.append(t)
            story.append(Spacer(1, 5 * mm))

        story.append(HRFlowable(width="100%", thickness=0.75, color=colors.HexColor('#333333')))
        story.append(Spacer(1, 3 * mm))
        story.append(Paragraph(
            f"<b>TOTAL — {n_invoices} facture(s), {len(client_names)} client(s) : {grand_total:,.2f} $</b>",
            footer_style))

    story.append(_pdf_disclaimer())
    doc.build(story)
    return pdf_path


def db_envois_by_month(year, month):
    """Tous les courriels (brouillons et envois) enregistrés dans le mois donné."""
    ym = f"{year:04d}-{month:02d}"
    conn = get_conn()
    rows = conn.execute(
        "SELECT ts, client, courriel, total, statut, note FROM log_envois "
        "WHERE ts LIKE ? ORDER BY ts",
        (f"{ym}-%",)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def generate_envoi_report_pdf(year, month, rows):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Table, TableStyle,
                                     Paragraph, Spacer, NextPageTemplate, PageBreak)
    from reportlab.platypus.flowables import HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader

    mois_nom = MOIS_FR[month]
    report_dir = PDF_DIR / "Rapports_envois"
    report_dir.mkdir(exist_ok=True)
    pdf_path = report_dir / f"Rapport_envois_{year:04d}-{month:02d}.pdf"

    page_w, page_h = letter
    left_margin = right_margin = 18 * mm
    bottom_margin = 18 * mm
    header_reserved = 55  # mm

    styles = getSampleStyleSheet()
    footer_style = ParagraphStyle('footer', parent=styles['Normal'], fontSize=10)

    emission_date = datetime.date.today().strftime('%Y-%m-%d')

    def draw_header(canvas, doc_):
        canvas.saveState()
        x = left_margin
        top = page_h - 20 * mm
        canvas.setFont('Helvetica-Bold', 18)
        canvas.drawString(x, top, "RAPPORT D'ENVOI — COURRIELS")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 9 * mm, "Période :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 20 * mm, top - 9 * mm, f"{mois_nom} {year}")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 14 * mm, "Généré le :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 24 * mm, top - 14 * mm, emission_date)

        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            logo_w = 55 * mm
            logo_h = logo_w * ih / iw
            canvas.drawImage(img, page_w - right_margin - logo_w, top - logo_h + 2 * mm,
                              width=logo_w, height=logo_h, mask='auto')

        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.setLineWidth(0.5)
        rule_y = top - 19 * mm
        canvas.line(left_margin, rule_y, page_w - right_margin, rule_y)
        canvas.restoreState()

    def draw_plain(canvas, doc_):
        pass

    frame_first = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                         page_h - bottom_margin - header_reserved * mm, id='first')
    frame_rest = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                        page_h - bottom_margin - 15 * mm, id='rest')

    doc = BaseDocTemplate(str(pdf_path), pagesize=letter)
    doc.addPageTemplates([
        PageTemplate(id='First', frames=[frame_first], onPage=draw_header),
        PageTemplate(id='Rest', frames=[frame_rest], onPage=draw_plain),
    ])

    story = []
    if not rows:
        story.append(Paragraph(f"Aucun courriel enregistré pour {mois_nom} {year}.", styles['Normal']))
    else:
        data = [["Date / heure", "Client", "Courriel", "Montant", "Statut", "Note"]]
        grand_total = 0.0
        n_envoyes = 0
        for r in rows:
            ts_disp = (r['ts'] or '')[:16].replace('T', ' ')
            data.append([ts_disp, r['client'] or '', r['courriel'] or '—',
                         f"{(r['total'] or 0):,.2f} $", r['statut'] or '', r['note'] or ''])
            grand_total += (r['total'] or 0)
            if (r['statut'] or '').upper() == 'ENVOYÉ':
                n_envoyes += 1
        t = Table(data, colWidths=[28 * mm, 32 * mm, 38 * mm, 20 * mm, 18 * mm, 40 * mm], repeatRows=1)
        t.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ]))
        story.append(t)
        story.append(Spacer(1, 5 * mm))
        story.append(HRFlowable(width="100%", thickness=0.75, color=colors.HexColor('#333333')))
        story.append(Spacer(1, 3 * mm))
        story.append(Paragraph(
            f"<b>TOTAL — {len(rows)} courriel(s) enregistré(s), dont {n_envoyes} envoyé(s) "
            f"directement : {grand_total:,.2f} $</b>",
            footer_style))

    story.append(_pdf_disclaimer())
    doc.build(story)
    return pdf_path


def month_end_or_today(year, month):
    """Dernier jour du mois choisi, sauf si c'est le mois en cours : dans ce cas on
    utilise la date d'aujourd'hui, pour que le rapport du mois courant corresponde
    exactement à l'état réel actuel."""
    import calendar
    today = datetime.date.today()
    if year == today.year and month == today.month:
        return today
    last_day = calendar.monthrange(year, month)[1]
    return datetime.date(year, month, last_day)


def db_aging_all_clients(ref_date=None):
    """Solde par tranche d'âge (0-30 / 31-60 / 61-90 / 90+), par client, pour tous les
    clients ayant un solde non nul, calculé par rapport à ref_date (aujourd'hui si non
    fourni). Si ref_date est fourni, seules les factures datées au plus tard à ref_date
    sont incluses (pour reproduire l'état tel qu'il était à la fin du mois choisi)."""
    conn = get_conn()
    clients = conn.execute("SELECT name FROM clients ORDER BY name COLLATE NOCASE").fetchall()
    rows = []
    ref_str = ref_date.strftime('%Y-%m-%d') if ref_date else None
    for c in clients:
        invs = conn.execute("SELECT * FROM invoices WHERE client_name=?", (c['name'],)).fetchall()
        if not invs:
            continue
        if ref_str:
            invs = [i for i in invs if (i['date_facture'] or '') <= ref_str]
        if not invs:
            continue
        totals = sum_totals(invoices_with_buckets(invs, ref_date))
        if abs(totals['montant']) < 0.005:
            continue
        rows.append({'name': c['name'], **totals})
    conn.close()
    rows.sort(key=lambda r: r['name'].lower())
    return rows


def generate_aging_report_pdf(rows, ref_date=None, period_label=None):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Table, TableStyle, Paragraph, Spacer
    from reportlab.platypus.flowables import HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader

    ref_date = ref_date or datetime.date.today()
    ref_str = ref_date.strftime('%Y-%m-%d')

    report_dir = PDF_DIR / "Rapports_mensuels"
    report_dir.mkdir(exist_ok=True)
    pdf_path = report_dir / f"Rapport_age_{ref_str}.pdf"

    page_w, page_h = letter
    left_margin = right_margin = 18 * mm
    bottom_margin = 18 * mm
    header_reserved = 50  # mm

    styles = getSampleStyleSheet()
    footer_style = ParagraphStyle('footer', parent=styles['Normal'], fontSize=10)

    emission_date = datetime.date.today().strftime('%Y-%m-%d')
    sous_titre = f"Tous les clients — soldes en date du {ref_str}" + (f" ({period_label})" if period_label else "")

    def draw_header(canvas, doc_):
        canvas.saveState()
        x = left_margin
        top = page_h - 20 * mm
        canvas.setFont('Helvetica-Bold', 16)
        canvas.drawString(x, top, "RAPPORT D'ÂGE DES COMPTES À RECEVOIR")
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 9 * mm, "Généré le :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 22 * mm, top - 9 * mm, emission_date)
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x, top - 14 * mm, sous_titre)

        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            logo_w = 50 * mm
            logo_h = logo_w * ih / iw
            canvas.drawImage(img, page_w - right_margin - logo_w, top - logo_h + 2 * mm,
                              width=logo_w, height=logo_h, mask='auto')

        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.setLineWidth(0.5)
        rule_y = top - 18 * mm
        canvas.line(left_margin, rule_y, page_w - right_margin, rule_y)
        canvas.restoreState()

    def draw_plain(canvas, doc_):
        pass

    frame_first = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                         page_h - bottom_margin - header_reserved * mm, id='first')
    frame_rest = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                        page_h - bottom_margin - 15 * mm, id='rest')

    doc = BaseDocTemplate(str(pdf_path), pagesize=letter)
    doc.addPageTemplates([
        PageTemplate(id='First', frames=[frame_first], onPage=draw_header),
        PageTemplate(id='Rest', frames=[frame_rest], onPage=draw_plain),
    ])

    story = []
    if not rows:
        story.append(Paragraph("Aucun client avec un solde dû.", styles['Normal']))
    else:
        data = [["Client", "0 – 30 j", "31 – 60 j", "61 – 90 j", "90+ j", "Total"]]
        grand = {'g': 0.0, 'h': 0.0, 'i': 0.0, 'j': 0.0, 'montant': 0.0}
        for r in rows:
            data.append([
                r['name'],
                f"{r['g']:,.2f} $", f"{r['h']:,.2f} $", f"{r['i']:,.2f} $", f"{r['j']:,.2f} $",
                f"{r['montant']:,.2f} $",
            ])
            for k in ('g', 'h', 'i', 'j', 'montant'):
                grand[k] += r[k]
        data.append([
            "TOTAL — tous les clients",
            f"{grand['g']:,.2f} $", f"{grand['h']:,.2f} $", f"{grand['i']:,.2f} $", f"{grand['j']:,.2f} $",
            f"{grand['montant']:,.2f} $",
        ])

        t = Table(data, colWidths=[55 * mm, 26 * mm, 26 * mm, 26 * mm, 26 * mm, 26 * mm], repeatRows=1)
        t.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8.5),
            ('GRID', (0, 0), (-1, -2), 0.5, colors.black),
            ('LINEABOVE', (0, -1), (-1, -1), 0.75, colors.black),
            ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
            ('ALIGN', (0, 0), (0, -1), 'LEFT'),
            ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#f3f4f6')),
        ]))
        story.append(t)
        story.append(Spacer(1, 4 * mm))
        story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))
        story.append(Spacer(1, 3 * mm))
        story.append(Paragraph(
            f"<b>{len(rows)} client(s) avec solde dû — total général : {grand['montant']:,.2f} $</b>",
            footer_style))

    story.append(_pdf_disclaimer())
    doc.build(story)
    return pdf_path


_bulk_state = {
    "running": False, "mode": None, "total": 0, "done": 0, "ok": 0, "skipped": 0, "errors": [],
    "finished_at": None,
}


_bulk_lock = threading.Lock()


def _run_bulk(mode, username=None):
    """mode: 'draft_silent' (brouillons dans Outlook, à réviser) ou 'send'
    (envoi direct immédiat, sans révision — irréversible)."""
    import pythoncom
    pythoncom.CoInitialize()
    try:
        clients = [c for c in db_list_clients() if c['solde'] and c['solde'] > 0]
        _bulk_state.update({"running": True, "mode": mode, "total": len(clients), "done": 0,
                             "ok": 0, "skipped": 0, "errors": [], "finished_at": None})
        for c in clients:
            name = c['name']
            try:
                detail = db_client_detail(name)
                to_email = detail['info'].get('courriel') or ''
                if not to_email:
                    _bulk_state["skipped"] += 1
                    _bulk_state["errors"].append(f"{name} : pas de courriel, ignoré")
                    _bulk_state["done"] += 1
                    continue
                statement_number = db_next_statement_number()
                pdf_path = generate_statement_pdf(name, detail['info'], detail['invoices'],
                                                    detail['totals'], statement_number)
                subject = f"État de compte — {name} ({statement_number})"
                body = (
                    f"Bonjour,\n\nVeuillez trouver ci-joint votre état de compte au "
                    f"{datetime.date.today().strftime('%d/%m/%Y')}.\n\n"
                    f"Solde total : {detail['totals']['montant']:,.2f} $\n\n"
                    f"{get_email_closing_message()}\n\n{get_sender_signature()}"
                )
                statut = send_email(to_email, subject, body, pdf_path, mode=mode, purpose='ar')
                label = "Envoi en lot" if mode == 'send' else "Brouillon en lot"
                db_log_envoi(name, to_email, detail['totals']['montant'], statut,
                             f"{label} — {statement_number}")
                _bulk_state["ok"] += 1
            except Exception as e:
                _bulk_state["errors"].append(f"{name} : {e}")
            _bulk_state["done"] += 1
    finally:
        _bulk_state["running"] = False
        _bulk_state["finished_at"] = datetime.datetime.now().isoformat()
        label = "Envoi en lot" if mode == 'send' else "Brouillons en lot"
        db_add_audit(username, label,
                     f"{_bulk_state['ok']} envoyé(s), {_bulk_state['skipped']} ignoré(s), "
                     f"{len(_bulk_state['errors'])} erreur(s)")
        pythoncom.CoUninitialize()


@app.route('/comptes-a-recevoir')
def car_page():
    return render_template('index.html', company=get_company_name(), company_email=get_company_email(),
                            username=session.get('username'), is_admin=session.get('is_admin', False),
                            permissions=session.get('permissions') or [])


@app.route('/api/clients')
def api_clients():
    clients = db_list_clients()
    return jsonify(clients)


@app.route('/api/client/<path:name>')
def api_client_detail(name):
    data = db_client_detail(name)
    if data is None:
        return jsonify({'error': 'Client introuvable'}), 404
    data['invoices'] = [i for i in data['invoices'] if i['montant'] != 0 or i['numero']]
    return jsonify(data)


@app.route('/api/client', methods=['POST'])
def api_create_client():
    data = request.json
    try:
        sheet_name = db_create_client(
            data['name'], data.get('phone', ''), data.get('adresse', ''),
            data.get('ville', ''), data.get('province', 'Qc'),
            data.get('code_postal', ''), data.get('courriel', ''),
        )
        log_audit('Création client', data['name'])
        return jsonify({'ok': True, 'sheet': sheet_name})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/client/<path:name>', methods=['PUT'])
def api_update_client(name):
    data = request.json or {}
    try:
        new_name, changes = db_update_client(
            name, data.get('name', ''), data.get('phone', ''), data.get('adresse', ''),
            data.get('ville', ''), data.get('province', 'Qc'),
            data.get('code_postal', ''), data.get('courriel', ''),
        )
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    if changes:
        details = "; ".join(f"{CLIENT_FIELD_LABELS.get(k, k)} : « {a} » → « {b} »" for k, a, b in changes)
        log_audit('Modification client', f"{name} — {details}")
    return jsonify({'ok': True, 'name': new_name, 'changed': len(changes)})


@app.route('/api/client/<path:name>/merge', methods=['POST'])
def api_merge_client(name):
    """Fusionne le client `name` dans le client `into` (celui qui est gardé)."""
    data = request.get_json(silent=True) or {}
    into = (data.get('into') or '').strip()
    try:
        res = db_merge_clients(name, into, session.get('username'))
    except RuntimeError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': f"Fusion impossible : {e}. Aucune donnée n'a été modifiée."}), 500
    log_audit('Fusion de clients', f"« {name} » fusionné dans « {into} » — {res['invoices']} facture(s) déplacée(s)"
              + (f" ; coordonnées complétées : {', '.join(CLIENT_FIELD_LABELS.get(f, f) for f in res['filled'])}"
                 if res['filled'] else ""))
    return jsonify(dict(res, ok=True, name=into))


@app.route('/api/client/<path:name>/ls-links')
def api_client_ls_links(name):
    return jsonify(db_client_ls_links(name))


@app.route('/api/client/<path:name>/ls-links/remove', methods=['POST'])
def api_client_ls_link_remove(name):
    data = request.get_json(silent=True) or {}
    conn = get_conn()
    try:
        if data.get('customer_id'):
            n = conn.execute("DELETE FROM ls_ar_customers WHERE client_name=? AND ls_customer_id=?",
                             (name, str(data['customer_id']))).rowcount
            what = f"lien avec le client Lightspeed #{data['customer_id']}"
        elif data.get('alias'):
            n = conn.execute("DELETE FROM ls_ar_aliases WHERE client_name=? AND alias=?",
                             (name, data['alias'])).rowcount
            what = f"nom reconnu « {data.get('display') or data['alias']} »"
        else:
            return jsonify({'ok': False, 'error': 'Rien à retirer.'}), 400
        conn.commit()
    finally:
        conn.close()
    if n:
        log_audit('Lien Lightspeed retiré', f"{name} — {what}")
    return jsonify({'ok': bool(n)})


@app.route('/api/client/<path:name>/invoice', methods=['POST'])
def api_add_invoice(name):
    data = request.json
    try:
        db_add_invoice(
            name, data['numero'], data['date_facture'], data['echeance'],
            data['montant'], data.get('notes', ''), data.get('montant_paye', 0) or 0,
            data.get('date_paiement') or None,
        )
        log_audit('Ajout facture', f"{name} — n° {data['numero']} — {float(data['montant']):,.2f} $")
        return jsonify({'ok': True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/invoice/<int:invoice_id>', methods=['PUT'])
def api_update_invoice(invoice_id):
    data = request.json
    try:
        existing = db_get_invoice(invoice_id)
        db_update_invoice(
            invoice_id, data['numero'], data['date_facture'], data['echeance'],
            data['montant'], data.get('notes', ''), data.get('montant_paye', 0) or 0,
            data.get('date_paiement') or None,
        )
        client_name = existing['client_name'] if existing else ''
        log_audit('Modification facture', f"{client_name} — n° {data['numero']}")
        return jsonify({'ok': True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/invoice/<int:invoice_id>', methods=['DELETE'])
def api_delete_invoice(invoice_id):
    try:
        inv = db_get_invoice(invoice_id)
        db_delete_invoice(invoice_id)
        detail = f"{inv['client_name']} — n° {inv['numero']} — {inv['montant']:,.2f} $" if inv else f"id={invoice_id}"
        log_audit('Suppression facture', detail)
        return jsonify({'ok': True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/invoice/<int:invoice_id>/paid', methods=['PUT'])
def api_set_invoice_paid(invoice_id):
    data = request.json or {}
    try:
        paid = bool(data.get('paid', True))
        inv = db_get_invoice(invoice_id)
        db_set_invoice_paid(invoice_id, paid, data.get('date_paiement') or None)
        detail = f"{inv['client_name']} — n° {inv['numero']}" if inv else f"id={invoice_id}"
        is_credit = bool(inv) and float(inv['montant'] or 0) < 0
        if is_credit:
            log_audit('Crédit appliqué' if paid else 'Crédit appliqué annulé', detail)
        else:
            log_audit('Facture marquée payée' if paid else 'Paiement annulé', detail)
        return jsonify({'ok': True})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/client/<path:name>/statement', methods=['POST'])
def api_statement(name):
    """Génère le PDF et (selon le mode) crée un brouillon ou envoie le courriel via Outlook.
    Ne touche pas à l'Excel — tout vient de la base rapide (le PDF/courriel n'a pas besoin
    d'attendre une synchronisation Excel)."""
    data = request.json or {}
    mode = data.get('mode', 'draft')
    if mode in ('draft', 'draft_silent') and get_settings()['send_mode'] == 'smtp':
        return jsonify({'ok': False, 'error':
                         "Le mode brouillon n'est pas disponible en mode d'envoi SMTP "
                         "(pas de fenêtre de relecture) — utilise \"Envoyer directement\"."}), 400
    try:
        client = db_client_detail(name)
        if client is None:
            return jsonify({'ok': False, 'error': 'Client introuvable'}), 404
        info, invoices, totals = client['info'], client['invoices'], client['totals']

        statement_number = db_next_statement_number()
        pdf_path = generate_statement_pdf(name, info, invoices, totals, statement_number)

        to_email = data.get('email') or info.get('courriel') or ''
        subject = data.get('subject') or f"État de compte — {name} ({statement_number})"
        body = data.get('body') or (
            f"Bonjour,\n\nVeuillez trouver ci-joint votre état de compte au "
            f"{datetime.date.today().strftime('%d/%m/%Y')}.\n\n"
            f"Solde total : {totals['montant']:,.2f} $\n\n"
            f"{get_email_closing_message()}\n\n{get_sender_signature()}"
        )

        if not to_email:
            statut = 'PDF_SEULEMENT'
            db_log_envoi(name, to_email, totals['montant'], statut, 'Aucun courriel client — PDF généré seulement')
            log_audit('État de compte généré', f"{name} — {statement_number} — PDF seulement (aucun courriel)")
            return jsonify({'ok': True, 'pdf': str(pdf_path), 'statut': statut,
                             'warning': "Aucune adresse courriel pour ce client — PDF généré mais courriel non préparé."})

        statut = send_email(to_email, subject, body, pdf_path, mode=mode, purpose='ar')
        db_log_envoi(name, to_email, totals['montant'], statut, f"Via app locale ({mode}) — {statement_number}")
        log_audit('État de compte généré', f"{name} — {statement_number} — {mode} — {totals['montant']:,.2f} $")
        return jsonify({'ok': True, 'pdf': str(pdf_path), 'statut': statut, 'statement_number': statement_number})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/client/<path:name>/pdf')
def api_get_pdf(name):
    client = db_client_detail(name)
    if client is None:
        return jsonify({'error': 'Client introuvable'}), 404
    statement_number = db_next_statement_number()
    pdf_path = generate_statement_pdf(name, client['info'], client['invoices'], client['totals'], statement_number)
    log_audit('PDF état de compte téléchargé', f"{name} — {statement_number}")
    return send_file(str(pdf_path), as_attachment=True)


@app.route('/api/reports/monthly')
def api_monthly_report():
    resp = permission_required_check('reports')
    if resp is not None:
        return resp
    try:
        year = int(request.args.get('year'))
        month = int(request.args.get('month'))
        if not (1 <= month <= 12):
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({'error': "Paramètres 'year' et 'month' invalides."}), 400
    by_client = db_invoices_by_month(year, month)
    pdf_path = generate_monthly_report_pdf(year, month, by_client)
    log_audit('Rapport mensuel généré', f"{MOIS_FR[month]} {year}")
    return send_file(str(pdf_path), as_attachment=True,
                      download_name=f"Rapport_{MOIS_FR[month]}_{year}.pdf")


@app.route('/api/reports/envois')
def api_envois_report():
    resp = permission_required_check('reports')
    if resp is not None:
        return resp
    try:
        year = int(request.args.get('year'))
        month = int(request.args.get('month'))
        if not (1 <= month <= 12):
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({'error': "Paramètres 'year' et 'month' invalides."}), 400
    rows = db_envois_by_month(year, month)
    pdf_path = generate_envoi_report_pdf(year, month, rows)
    log_audit('Rapport d\'envoi généré', f"{MOIS_FR[month]} {year}")
    return send_file(str(pdf_path), as_attachment=True,
                      download_name=f"Rapport_envois_{MOIS_FR[month]}_{year}.pdf")


@app.route('/api/reports/aging')
def api_aging_report():
    resp = permission_required_check('reports')
    if resp is not None:
        return resp
    year_raw = request.args.get('year')
    month_raw = request.args.get('month')
    ref_date = None
    period_label = None
    if year_raw or month_raw:
        try:
            year = int(year_raw)
            month = int(month_raw)
            if not (1 <= month <= 12):
                raise ValueError
        except (TypeError, ValueError):
            return jsonify({'error': "Paramètres 'year' et 'month' invalides."}), 400
        ref_date = month_end_or_today(year, month)
        period_label = f"{MOIS_FR[month]} {year}"

    rows = db_aging_all_clients(ref_date)
    pdf_path = generate_aging_report_pdf(rows, ref_date, period_label)
    ref_str = (ref_date or datetime.date.today()).strftime('%Y-%m-%d')
    log_audit('Rapport d\'âge généré', period_label or "aujourd'hui")
    return send_file(str(pdf_path), as_attachment=True,
                      download_name=f"Rapport_age_{ref_str}.pdf")


def _ls_ar_default_since():
    last = meta_get('ls_ar_last_until')
    try:
        # quelques jours de chevauchement : les factures déjà inscrites sont ignorées
        return datetime.date.fromisoformat(last) - datetime.timedelta(days=3)
    except (TypeError, ValueError):
        return datetime.date.today() - datetime.timedelta(days=30)


@app.route('/api/lightspeed/ar/status')
def api_ls_ar_status():
    st = _ls_ar_state
    cfg = ls_config()
    return jsonify({
        'connected': cfg['connected'],
        'is_admin': bool(session.get('is_admin')),
        'running': st['running'], 'progress': st['progress'], 'error': st['error'],
        'preview': st['preview'] if not st['running'] else None,
        'default_since': _ls_ar_default_since().isoformat(),
        'last_until': meta_get('ls_ar_last_until'),
    })


@app.route('/api/lightspeed/ar/check', methods=['POST'])
def api_ls_ar_check():
    if not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Kubios n'est pas connecté à Lightspeed "
                                              "(Administration → Lightspeed)."}), 400
    data = request.get_json(silent=True) or {}
    try:
        since = datetime.date.fromisoformat(data.get('since') or '')
    except ValueError:
        return jsonify({'ok': False, 'error': "Date de départ invalide."}), 400
    if since > datetime.date.today():
        return jsonify({'ok': False, 'error': "La date de départ est dans le futur."}), 400
    try:
        start_ls_ar_check(since, session.get('username'), bool(data.get('include_ignored')))
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    return jsonify({'ok': True})


@app.route('/api/lightspeed/ar/apply', methods=['POST'])
def api_ls_ar_apply():
    data = request.get_json(silent=True) or {}
    if _ls_ar_state['running']:
        return jsonify({'ok': False, 'error': "Une vérification est en cours."}), 409
    try:
        res = ls_ar_apply(data.get('token'), data.get('choices'), session.get('username'),
                          data.get('payment_choices'))
    except (RuntimeError, LightspeedError) as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': f"Erreur inattendue : {e}"}), 500
    parts = [f"{res['added']} facture(s) inscrite(s)"]
    if res['created_clients']:
        parts.append(f"{len(res['created_clients'])} client(s) créé(s) : " + ", ".join(res['created_clients']))
    if res['ignored']:
        parts.append(f"{res['ignored']} vente(s) ignorée(s)")
    if res['skipped']:
        parts.append(f"{res['skipped']} déjà présente(s)")
    for pa in res['payments_applied']:
        parts.append(f"paiement {_fmt_money_fr(pa['montant'])} du {pa['date']} ({pa['client']}) → "
                     + (", ".join(pa['factures']) or "aucune facture ouverte")
                     + (f", excédent {_fmt_money_fr(pa['excedent'])}" if pa['excedent'] else ""))
    if res['payments_marked']:
        parts.append(f"{res['payments_marked']} paiement(s) marqué(s) « déjà fait »")
    if res['linked']:
        parts.append("client(s) Lightspeed relié(s) : " + ", ".join(res['linked']))
    log_audit('Factures Lightspeed inscrites', "; ".join(parts))
    return jsonify(dict(res, ok=True))


@app.route('/api/ar-backups')
def api_list_ar_backups():
    return jsonify({'backups': db_list_credit_backups('ar'), 'can_restore': bool(session.get('is_admin'))})


@app.route('/api/ar-backups/<int:backup_id>/restore', methods=['POST'])
def api_restore_ar_backup(backup_id):
    resp = admin_required_check()
    if resp is not None:
        return resp
    if not _ls_ar_lock.acquire(blocking=False):
        return jsonify({'ok': False, 'error': "Une vérification Lightspeed est en cours. Réessaie dans un instant."}), 409
    try:
        b, pre_id = db_restore_credit_backup(backup_id, session.get('username'), scope='ar')
        _ls_ar_state['preview'] = None
    except RuntimeError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': f"Restauration impossible : {e}. Aucune donnée n'a été modifiée."}), 500
    finally:
        _ls_ar_lock.release()
    log_audit('Restauration des comptes à recevoir',
              f"Sauvegarde du {b['created_at'][:16]} ({b['label']}) — {b['client_count']} client(s), "
              f"{b['movement_count']} facture(s). L'état précédent a été sauvegardé (#{pre_id}).")
    return jsonify({'ok': True, 'client_count': b['client_count'], 'invoice_count': b['movement_count'],
                    'pre_backup_id': pre_id})


@app.route('/api/lightspeed/pending')
def api_ls_pending():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    return jsonify(db_ls_list_pending())


@app.route('/api/lightspeed/pending/<ls_id>/link', methods=['POST'])
def api_ls_link_pending(ls_id):
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}
    client_id = data.get('client_id')
    try:
        client_id = int(client_id) if client_id not in (None, '', 'new') else None
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': "Compte Kubios invalide."}), 400
    if _ls_sync_state['running']:
        return jsonify({'ok': False, 'error': "Une synchronisation est en cours, réessaie dans un instant."}), 409
    try:
        client, action, p = db_ls_link_pending(ls_id, client_id)
    except RuntimeError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    mark_dirty()
    log_audit('Association manuelle Lightspeed',
              f"Compte Lightspeed #{ls_id} ({_credit_client_display_name(p)}) → "
              + ("nouveau compte Kubios" if action == 'created' else f"compte Kubios « {client['display_name']} »"))
    return jsonify({'ok': True, 'action': action, 'client_id': client['id']})


@app.route('/api/sync', methods=['POST'])
def api_sync():
    try:
        export_to_excel()
        log_audit('Synchronisation manuelle vers Excel')
        return jsonify({'ok': True, 'last_sync': meta_get('last_sync')})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/sync/status')
def api_sync_status():
    return jsonify({
        'dirty': meta_get('dirty', '0') == '1',
        'running': _sync_state["running"],
        'last_error': _sync_state["last_error"],
        'last_sync': meta_get('last_sync'),
    })


@app.route('/api/statements/bulk-draft', methods=['POST'])
def api_bulk_draft():
    if get_settings()['send_mode'] == 'smtp':
        return jsonify({'ok': False, 'error':
                         "Le mode brouillon n'est pas disponible en mode d'envoi SMTP "
                         "(pas de fenêtre de relecture) — utilise \"Envoyer directement\"."}), 400
    with _bulk_lock:
        if _bulk_state["running"]:
            return jsonify({'ok': False, 'error': 'Une opération en lot est déjà en cours.'}), 409
        t = threading.Thread(target=_run_bulk, args=('draft_silent', session.get('username')), daemon=True)
        t.start()
    return jsonify({'ok': True})


@app.route('/api/statements/bulk-send', methods=['POST'])
def api_bulk_send():
    with _bulk_lock:
        if _bulk_state["running"]:
            return jsonify({'ok': False, 'error': 'Une opération en lot est déjà en cours.'}), 409
        t = threading.Thread(target=_run_bulk, args=('send', session.get('username')), daemon=True)
        t.start()
    return jsonify({'ok': True})


@app.route('/api/statements/bulk-draft/status')
def api_bulk_draft_status():
    return jsonify(_bulk_state)
