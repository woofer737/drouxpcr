# -*- coding: utf-8 -*-
"""Pages de la connexion à Lightspeed : réglages, connexion, test, synchronisation.
Module de Kubios (découpé de app.py en 1.49.0, code inchangé)."""
import os
import re
import io
import csv
import sys
import json
import base64
import hashlib
import unicodedata
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import openpyxl
from openpyxl.utils import get_column_letter
import licensing
from kubios_base import db_add_audit, get_conn, meta_get, meta_set
from kubios_app import app
from kubios_auth import admin_required_check, log_audit, permission_required_check
from kubios_lightspeed import (
    LS_AUTH_BASE, LS_AUTO_MODES, LS_BALANCE_SIGNS, LightspeedError, _ls_get_all, _ls_sync_state,
    _ls_token_cache, _ls_token_request, _parse_money, _truthy, ls_config, ls_default_redirect_uri,
    ls_fetch_account,
)
from kubios_comptes import (
    _credit_client_display_name, _credit_net_debt, _ls_apply_values, _ls_debt, _ls_insert_client,
    _norm_credit_name, db_discard_credit_backup, mark_dirty,
)
from kubios_credit import _ls_sync_lock, db_backup_credit, db_capture_credit_snapshot, db_list_credit_clients
from kubios_rapports import meta_delete

__all__ = ['LS_SCOPE', '_LS_CALLBACK_PAGE', '_ls_complete_oauth', '_ls_detect_sign', '_ls_result_text', '_ls_status_payload', 'api_ls_disconnect', 'api_ls_get_settings', 'api_ls_oauth_paste', 'api_ls_set_settings', 'api_ls_status', 'api_ls_sync', 'api_ls_test', 'db_ls_apply', 'lightspeed_connect', 'lightspeed_oauth_callback', 'ls_auto_mode_text', 'ls_fetch_credit_accounts', 'run_ls_sync', 'start_ls_sync_thread']


LS_SCOPE = 'employee:all'


def ls_fetch_credit_accounts(account_id):
    """Retourne (comptes, ignorés). Chaque compte : ls_id, ls_customer_id,
    prenom_entreprise, nom, credit_limit, balance (solde brut Lightspeed)."""
    accounts = _ls_get_all(account_id, 'CreditAccount', {}, 'Comptes de crédit')
    customers = _ls_get_all(account_id, 'Customer', {'creditAccountID': '>,0'}, 'Clients')
    by_ca = {}
    for c in customers:
        ca = str(c.get('creditAccountID') or '').strip()
        if ca and ca != '0':
            by_ca[ca] = c
    out = []
    skipped = {'gift_cards': 0, 'archived': 0}
    for a in accounts:
        if _truthy(a.get('giftCard')):
            skipped['gift_cards'] += 1
            continue
        if _truthy(a.get('archived')):
            skipped['archived'] += 1
            continue
        caid = str(a.get('creditAccountID') or '').strip()
        if not caid:
            continue
        cust = by_ca.get(caid) or {}
        first = (cust.get('firstName') or '').strip()
        last = (cust.get('lastName') or '').strip()
        company = (cust.get('company') or '').strip()
        prenom, nom = (first or company), last
        if not prenom:
            prenom, nom = last, ''
        if not prenom:
            prenom = (a.get('name') or '').strip() or f"Compte Lightspeed {caid}"
        out.append({
            'ls_id': caid,
            'ls_customer_id': str(cust.get('customerID') or '').strip() or None,
            'prenom_entreprise': prenom,
            'nom': nom or None,
            'credit_limit': round(_parse_money(a.get('creditLimit')), 2),
            'balance': round(_parse_money(a.get('balance')), 2),
        })
    return out, skipped


def _ls_detect_sign(rows):
    """Compare les soldes Lightspeed aux soldes actuels de Kubios (issus de
    l'export CSV) pour déterminer le sens du champ « balance »."""
    clients = db_list_credit_clients()
    by_lsid = {c['ls_credit_account_id']: c for c in clients if c.get('ls_credit_account_id')}
    names = {}
    for c in clients:
        names.setdefault(_norm_credit_name(c['display_name']), []).append(c)
    pos = neg = n = 0
    for r in rows:
        if abs(r['balance']) < 0.01:
            continue
        c = by_lsid.get(r['ls_id'])
        if c is None:
            same = names.get(_norm_credit_name(_credit_client_display_name(r))) or []
            c = same[0] if len(same) == 1 else None
        if c is None:
            continue
        d = _credit_net_debt(c)
        if abs(d) < 0.01:
            continue
        n += 1
        if abs(d - r['balance']) < 0.01:
            pos += 1
        elif abs(d + r['balance']) < 0.01:
            neg += 1
    if n >= 5 and pos >= 0.6 * n and pos > 2 * neg:
        return 'positive_du', (n, pos, neg)
    if n >= 5 and neg >= 0.6 * n and neg > 2 * pos:
        return 'negative_du', (n, pos, neg)
    raise LightspeedError(
        f"Impossible de déterminer automatiquement le sens du solde Lightspeed ({n} compte(s) comparé(s) : "
        f"{pos} concordent avec « positif = montant dû », {neg} avec « négatif = montant dû »). "
        "Choisis-le dans Administration → Lightspeed, puis relance la synchronisation.")


def db_ls_apply(rows, sign):
    """Applique les comptes lus dans Lightspeed à la base Kubios.
    1) compte déjà relié (ls_credit_account_id) -> mis à jour ;
    2) sinon, un seul compte Kubios non relié porte le même nom ET un seul
       compte Lightspeed porte ce nom -> relié puis mis à jour ;
    3) homonymes -> mis de côté dans ls_pending_accounts (association
       manuelle dans la page Comptes de crédit), rien n'est modifié ;
    4) aucun compte de ce nom -> nouveau compte Kubios relié.
    Les comptes « Ne pas synchroniser » sont reliés mais jamais modifiés."""
    conn = get_conn()
    try:
        clients = [dict(r) for r in conn.execute("SELECT * FROM credit_clients").fetchall()]
        by_lsid = {c['ls_credit_account_id']: c for c in clients if c.get('ls_credit_account_id')}
        unlinked = {}
        for c in clients:
            if not c.get('ls_credit_account_id'):
                unlinked.setdefault(_norm_credit_name(_credit_client_display_name(c)), []).append(c)
        ls_name_count = {}
        for r in rows:
            if r['ls_id'] not in by_lsid:
                k = _norm_credit_name(_credit_client_display_name(r))
                ls_name_count[k] = ls_name_count.get(k, 0) + 1

        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        today = datetime.date.today().strftime('%Y-%m-%d')
        res = {'updated': 0, 'unchanged': 0, 'linked': 0, 'created': 0, 'renamed': 0,
               'locked': 0, 'pending': 0, 'missing': 0}
        pending = []
        seen_ids = set()
        for r in rows:
            seen_ids.add(r['ls_id'])
            debt = _ls_debt(r['balance'], sign)
            key = _norm_credit_name(_credit_client_display_name(r))
            client = by_lsid.get(r['ls_id'])
            if client is None:
                cands = unlinked.get(key) or []
                if len(cands) == 1 and ls_name_count.get(key, 0) == 1:
                    client = cands[0]
                    unlinked[key] = []
                    conn.execute("UPDATE credit_clients SET ls_credit_account_id=?, ls_customer_id=? WHERE id=?",
                                 (r['ls_id'], r.get('ls_customer_id'), client['id']))
                    client['ls_credit_account_id'] = r['ls_id']
                    res['linked'] += 1
                elif cands:
                    pending.append((r, debt))
                    continue
                else:
                    client = _ls_insert_client(conn, r, now,
                                               "Créé automatiquement par la synchronisation Lightspeed.")
                    res['created'] += 1
                by_lsid[r['ls_id']] = client
            if client.get('no_sync'):
                res['locked'] += 1
                continue
            if _norm_credit_name(_credit_client_display_name(client)) != key:
                conn.execute("UPDATE credit_clients SET prenom_entreprise=?, nom=? WHERE id=?",
                             (r['prenom_entreprise'], r['nom'], client['id']))
                client.update(prenom_entreprise=r['prenom_entreprise'], nom=r['nom'])
                res['renamed'] += 1
            res[_ls_apply_values(conn, client, r, debt, now, today, 'Synchronisation Lightspeed')] += 1

        res['missing'] = sum(1 for k in by_lsid if k not in seen_ids)
        conn.execute("DELETE FROM ls_pending_accounts")
        for r, debt in pending:
            conn.execute(
                "INSERT INTO ls_pending_accounts(ls_credit_account_id, ls_customer_id, prenom_entreprise, nom, "
                "credit_limit, debt, seen_at) VALUES (?,?,?,?,?,?,?)",
                (r['ls_id'], r.get('ls_customer_id'), r['prenom_entreprise'], r['nom'],
                 r['credit_limit'], debt, now))
        res['pending'] = len(pending)
        conn.commit()
        return res
    finally:
        conn.close()


def _ls_result_text(res):
    parts = [f"{res.get('total', 0)} compte(s) lu(s)", f"{res['updated']} mis à jour",
             f"{res['unchanged']} inchangé(s)"]
    for k, lbl in (('created', "nouveau(x) compte(s) créé(s)"), ('linked', "associé(s) par nom"),
                   ('renamed', "nom(s) mis à jour"), ('pending', "homonyme(s) à associer manuellement"),
                   ('locked', "non synchronisé(s) ignoré(s)"), ('gift_cards', "carte(s)-cadeaux ignorée(s)"),
                   ('archived', "archivé(s) ignoré(s)"),
                   ('missing', "compte(s) Kubios relié(s) absent(s) de Lightspeed")):
        if res.get(k):
            parts.append(f"{res[k]} {lbl}")
    return ", ".join(parts)


def run_ls_sync(username, auto=False, month_end=False):
    """Synchronisation complète (appelée depuis un fil d'exécution). Lève
    LightspeedError en cas d'échec (le message est aussi gardé pour la page)."""
    if not _ls_sync_lock.acquire(blocking=False):
        raise LightspeedError("Une synchronisation Lightspeed est déjà en cours.")
    st = _ls_sync_state
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    st.update(running=True, started_at=now, finished_at=None, progress="Connexion à Lightspeed…",
              result=None, error=None, by=username)
    kind = ' — automatique de fin de mois' if month_end else (' — automatique' if auto else '')
    label = 'Synchronisation Lightspeed (comptes de crédit)' + kind
    try:
        cfg = ls_config()
        account_id = cfg['account_id']
        if not account_id:
            account_id, name = ls_fetch_account()
            meta_set('ls_account_id', account_id)
            meta_set('ls_account_name', name)
        rows, skipped = ls_fetch_credit_accounts(account_id)
        sign = cfg['balance_sign']
        if sign not in ('positive_du', 'negative_du'):
            sign, (n, pos, neg) = _ls_detect_sign(rows)
            meta_set('ls_balance_sign', sign)
            db_add_audit(username, 'Lightspeed : sens du solde détecté',
                         ("positif = montant dû" if sign == 'positive_du' else "négatif = montant dû")
                         + f" ({n} compte(s) comparé(s), {pos}/{neg})")
        st['progress'] = "Sauvegarde des comptes avant la mise à jour…"
        try:
            backup_id = db_backup_credit(
                "Avant synchronisation Lightspeed" + (" de fin de mois" if month_end else
                                                     (" automatique" if auto else "")), username)
        except RuntimeError as e:
            raise LightspeedError(str(e))
        st['progress'] = "Mise à jour des comptes…"
        res = db_ls_apply(rows, sign)
        if not any(res[k] for k in ('updated', 'created', 'linked', 'renamed')):
            db_discard_credit_backup(backup_id)
            backup_id = None
        res['backup_id'] = backup_id
        res.update(skipped)
        res['total'] = len(rows)
        res['snapshot_id'] = None
        if month_end:
            # Portrait de fin de mois : toujours gardé (rapport PDF), même sans changement.
            res['snapshot_id'] = db_capture_credit_snapshot(
                'Synchronisation Lightspeed de fin de mois (API)', 'API Lightspeed — automatique')
        elif res['updated'] or res['created']:
            res['snapshot_id'] = db_capture_credit_snapshot(
                'Synchronisation Lightspeed (API)', 'API Lightspeed' + (' — automatique' if auto else ''))
        mark_dirty()
        done = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        meta_set('ls_last_sync', done)
        meta_set('ls_last_sync_result', json.dumps(res))
        meta_delete('ls_last_sync_error')
        db_add_audit(username, label, _ls_result_text(res))
        st['result'] = res
        return res
    except Exception as e:
        if not isinstance(e, LightspeedError):
            traceback.print_exc()
        msg = str(e) if isinstance(e, LightspeedError) else f"Erreur inattendue : {e}"
        st['error'] = msg
        meta_set('ls_last_sync_error', f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} — {msg}")
        db_add_audit(username, label + ' — échec', msg)
        raise LightspeedError(msg)
    finally:
        st['running'] = False
        st['finished_at'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        st['progress'] = ''
        _ls_sync_lock.release()


def start_ls_sync_thread(username, auto=False):
    if _ls_sync_state['running']:
        raise LightspeedError("Une synchronisation Lightspeed est déjà en cours.")

    def _run():
        try:
            run_ls_sync(username, auto=auto)
        except LightspeedError as e:
            print("Synchronisation Lightspeed :", e)

    threading.Thread(target=_run, daemon=True).start()


def ls_auto_mode_text(mode, hour):
    if mode == 'daily':
        return f"chaque jour à partir de {hour} h"
    if mode == 'month_end':
        return f"le dernier jour de chaque mois à partir de {hour} h"
    return "désactivée"


def _ls_status_payload():
    cfg = ls_config()
    try:
        last_result = json.loads(meta_get('ls_last_sync_result') or 'null')
    except ValueError:
        last_result = None
    conn = get_conn()
    pending = conn.execute("SELECT COUNT(*) c FROM ls_pending_accounts").fetchone()['c']
    conn.close()
    return {
        'connected': cfg['connected'],
        'account_id': cfg['account_id'],
        'account_name': cfg['account_name'],
        'auto_sync': cfg['auto_sync'],
        'auto_mode': cfg['auto_mode'],
        'auto_mode_text': ls_auto_mode_text(cfg['auto_mode'], cfg['auto_sync_hour']),
        'auto_sync_hour': cfg['auto_sync_hour'],
        'balance_sign': cfg['balance_sign'],
        'last_sync': meta_get('ls_last_sync'),
        'last_result': last_result,
        'last_result_text': _ls_result_text(last_result) if last_result else '',
        'last_error': meta_get('ls_last_sync_error'),
        'pending': pending,
        'running': _ls_sync_state['running'],
        'progress': _ls_sync_state['progress'],
        'current_error': _ls_sync_state['error'],
        'current_result': _ls_sync_state['result'],
        'current_result_text': _ls_result_text(_ls_sync_state['result']) if _ls_sync_state['result'] else '',
    }


@app.route('/api/lightspeed/settings')
def api_ls_get_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    cfg = ls_config()
    return jsonify({
        'client_id': cfg['client_id'],
        'secret_set': bool(cfg['client_secret']),
        'redirect_uri': cfg['redirect_uri'],
        'default_redirect_uri': ls_default_redirect_uri(),
        'connected': cfg['connected'],
        'account_id': cfg['account_id'],
        'account_name': cfg['account_name'],
        'balance_sign': cfg['balance_sign'],
        'auto_sync': cfg['auto_sync'],
        'auto_mode': cfg['auto_mode'],
        'auto_mode_text': ls_auto_mode_text(cfg['auto_mode'], cfg['auto_sync_hour']),
        'auto_sync_hour': cfg['auto_sync_hour'],
        'last_sync': meta_get('ls_last_sync'),
    })


@app.route('/api/lightspeed/settings', methods=['POST'])
def api_ls_set_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}
    old = ls_config()
    client_id = (data.get('client_id') or '').strip()
    secret = (data.get('client_secret') or '').strip()
    redirect_uri = (data.get('redirect_uri') or '').strip() or ls_default_redirect_uri()
    if not redirect_uri.lower().startswith(('http://', 'https://')):
        return jsonify({'ok': False, 'error': "L'adresse de retour doit commencer par http:// ou https://."}), 400
    sign = data.get('balance_sign') or 'auto'
    if sign not in LS_BALANCE_SIGNS:
        return jsonify({'ok': False, 'error': "Sens du solde invalide."}), 400
    try:
        hour = int(data.get('auto_sync_hour', 22))
        if not 0 <= hour <= 23:
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': "Heure de synchronisation invalide."}), 400
    meta_set('ls_client_id', client_id)
    if secret:
        meta_set('ls_client_secret', secret)
    meta_set('ls_redirect_uri', redirect_uri)
    meta_set('ls_balance_sign', sign)
    auto_mode = data.get('auto_mode')
    if auto_mode is None:
        auto_mode = 'daily' if data.get('auto_sync') else 'off'
    if auto_mode not in LS_AUTO_MODES:
        return jsonify({'ok': False, 'error': "Fréquence de synchronisation invalide."}), 400
    meta_set('ls_auto_sync_mode', auto_mode)
    meta_set('ls_auto_sync', '0' if auto_mode == 'off' else '1')
    meta_set('ls_auto_sync_hour', hour)
    disconnected = False
    if old['connected'] and (client_id != old['client_id'] or (secret and secret != old['client_secret'])):
        # Nouvelle application Lightspeed : l'ancienne connexion n'est plus valide.
        meta_delete('ls_refresh_token', 'ls_account_id', 'ls_account_name')
        _ls_token_cache['access_token'] = None
        disconnected = True
    changes = []
    if client_id != old['client_id']:
        changes.append("Client ID modifié")
    if secret:
        changes.append("Client secret modifié")
    if sign != old['balance_sign']:
        changes.append(f"sens du solde : {sign}")
    if auto_mode != old['auto_mode'] or (auto_mode != 'off' and hour != old['auto_sync_hour']):
        changes.append("synchro automatique : " + ls_auto_mode_text(auto_mode, hour))
    log_audit('Paramètres Lightspeed modifiés', "; ".join(changes) or "aucun changement important")
    return jsonify({'ok': True, 'disconnected': disconnected})


@app.route('/lightspeed/connect')
def lightspeed_connect():
    resp = admin_required_check()
    if resp is not None:
        return resp
    cfg = ls_config()
    if not cfg['client_id'] or not cfg['client_secret']:
        return redirect(url_for('admin_settings_page'))
    state = secrets.token_urlsafe(24)
    meta_set('ls_oauth_state', json.dumps({'state': state, 'ts': time.time(),
                                           'username': session.get('username')}))
    params = {'response_type': 'code', 'client_id': cfg['client_id'], 'scope': LS_SCOPE,
              'state': state, 'redirect_uri': cfg['redirect_uri']}
    return redirect(f"{LS_AUTH_BASE}/authorize?" + urllib.parse.urlencode(params))


_LS_CALLBACK_PAGE = """<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Lightspeed — Kubios</title>
<style>body{margin:0;font-family:Segoe UI,Arial,sans-serif;background:#f4f6f8;color:#1f2937}
.box{max-width:520px;margin:60px auto;background:#fff;border:1px solid #e1e5ea;border-radius:10px;padding:24px}
h1{font-size:18px;margin-top:0}.ok{color:#166534}.err{color:#991b1b}a{color:#2563eb}</style></head>
<body><div class="box"><h1 class="{{ cls }}">{{ title }}</h1><p>{{ text }}</p>
<p><a href="{{ url_for('admin_settings_page') }}">Retour à l'administration</a> ·
<a href="{{ url_for('credit_accounts_page') }}">Comptes de crédit</a></p></div></body></html>"""


def _ls_complete_oauth(args):
    """Termine la connexion à partir des paramètres renvoyés par Lightspeed
    (code + state). Retourne (ok, titre, texte, statut HTTP)."""
    try:
        saved = json.loads(meta_get('ls_oauth_state') or '{}')
    except ValueError:
        saved = {}
    state = args.get('state') or ''
    if not saved.get('state') or not secrets.compare_digest(state, saved['state']) \
            or time.time() - float(saved.get('ts') or 0) > 900:
        return (False, "Connexion refusée",
                "La demande de connexion est expirée ou invalide (elle est valide 15 minutes et une seule "
                "fois). Recommence à partir de Administration → Lightspeed → Connecter à Lightspeed.", 400)
    meta_delete('ls_oauth_state')
    username = saved.get('username') or '?'
    if args.get('error'):
        db_add_audit(username, 'Connexion Lightspeed refusée', args.get('error'))
        return (False, "Connexion annulée",
                f"Lightspeed n'a pas autorisé la connexion ({args.get('error')}).", 400)
    code = args.get('code') or ''
    if not code:
        return (False, "Connexion refusée", "Lightspeed n'a pas renvoyé de code d'autorisation.", 400)
    try:
        _ls_token_request({'grant_type': 'authorization_code', 'code': code,
                           'redirect_uri': ls_config()['redirect_uri']})
        account_id, name = ls_fetch_account()
        meta_set('ls_account_id', account_id)
        meta_set('ls_account_name', name)
    except LightspeedError as e:
        db_add_audit(username, 'Connexion Lightspeed échouée', str(e))
        return (False, "Connexion échouée", str(e), 502)
    db_add_audit(username, 'Connexion à Lightspeed', f"Compte « {name} » (#{account_id})")
    return (True, "Kubios est connecté à Lightspeed",
            f"Compte « {name} » (#{account_id}). Tu peux maintenant synchroniser les comptes de "
            "crédit à partir de la page Comptes de crédit.", 200)


@app.route('/api/lightspeed/oauth-paste', methods=['POST'])
def api_ls_oauth_paste():
    """Fin de connexion par copier-coller : l'adresse https:// de retour n'est
    servie par personne, l'utilisateur colle l'adresse complète affichée par
    le navigateur (elle contient code=… et state=…)."""
    resp = admin_required_check()
    if resp is not None:
        return resp
    raw = ((request.get_json(silent=True) or {}).get('url') or '').strip()
    query = urllib.parse.urlparse(raw).query if '://' in raw else raw.lstrip('?')
    args = {k: v[0] for k, v in urllib.parse.parse_qs(query).items()}
    if not args.get('code') and not args.get('error'):
        return jsonify({'ok': False, 'error': "Cette adresse ne contient pas de code d'autorisation. Copie "
                                              "l'adresse complète de la barre d'adresse (elle contient « code= »)."}), 400
    ok, title, text, status = _ls_complete_oauth(args)
    return jsonify({'ok': ok, 'title': title, 'message': text}), (200 if ok else status)


@app.route('/lightspeed/callback')
def lightspeed_oauth_callback():
    """Retour de Lightspeed après autorisation. Exemptée de la connexion à
    Kubios (le navigateur peut revenir sur « localhost » sans le témoin de
    session) : protégée par le jeton « state » à usage unique, valide 15 min."""
    from flask import render_template_string

    def page(ok, title, text, code=200):
        return render_template_string(_LS_CALLBACK_PAGE, cls='ok' if ok else 'err',
                                      title=title, text=text), code

    return page(*_ls_complete_oauth(request.args))


@app.route('/api/lightspeed/disconnect', methods=['POST'])
def api_ls_disconnect():
    resp = admin_required_check()
    if resp is not None:
        return resp
    meta_delete('ls_refresh_token', 'ls_account_id', 'ls_account_name')
    _ls_token_cache['access_token'] = None
    log_audit('Déconnexion de Lightspeed')
    return jsonify({'ok': True})


@app.route('/api/lightspeed/test', methods=['POST'])
def api_ls_test():
    resp = admin_required_check()
    if resp is not None:
        return resp
    try:
        account_id, name = ls_fetch_account()
        meta_set('ls_account_id', account_id)
        meta_set('ls_account_name', name)
        return jsonify({'ok': True, 'account_id': account_id, 'account_name': name})
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 502


@app.route('/api/lightspeed/status')
def api_ls_status():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    return jsonify(_ls_status_payload())


@app.route('/api/lightspeed/sync', methods=['POST'])
def api_ls_sync():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    if not ls_config()['connected']:
        return jsonify({'ok': False, 'error': "Kubios n'est pas connecté à Lightspeed "
                                              "(Administration → Lightspeed)."}), 400
    try:
        start_ls_sync_thread(session.get('username'))
    except LightspeedError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    return jsonify({'ok': True})
