# -*- coding: utf-8 -*-
"""Pages du portail employé.
Module de Kubios (découpé de app.py en 1.47.0, code inchangé)."""
import os
import re
import io
import csv
import sys
import json
import base64
import hashlib
import unicodedata
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import openpyxl
from openpyxl.utils import get_column_letter
import licensing
from kubios_base import AT_FMT, _at_now, client_ip, db_add_audit, get_company_name, get_conn
from kubios_mail import send_email
from kubios_sessions import sess_close, sess_open
from kubios_app import app
from kubios_rh_outils import (
    HR_DIR, HR_DOC_CATS, LEAVE_KINDS, LEAVE_STATUS, PDF_DIR, _d, _emp_render, _tc_fail,
    emp_session_emp, export_sched_emp_pdf, export_sched_pdf, hr_build_signed_pdf, hr_log, hr_sig_clean,
    leave_notify_managers, sched_cells, sched_employees, sched_paid_min, sched_settings, tc_sheet,
    tc_state,
)

__all__ = ['api_emp_doc_file', 'api_emp_doc_sign', 'api_emp_documents', 'api_emp_hours', 'api_emp_leave_cancel', 'api_emp_leaves', 'api_emp_me', 'api_emp_schedule', 'api_emp_schedule_pdf', 'emp_activate', 'emp_forgot', 'emp_home', 'emp_login', 'emp_logout']


@app.route('/employe/connexion', methods=['GET', 'POST'])
def emp_login():
    if request.method == 'POST':
        login = (request.form.get('login') or '').strip().lower()
        key = 'emp:' + login
        f = _tc_fail.get(key, {'n': 0, 'until': 0})
        if f['until'] > time.time():
            return _emp_render('login', error="Trop d'essais. Réessaie dans quelques minutes.", login=login)
        conn = get_conn()
        try:
            p = conn.execute("SELECT p.*, e.status FROM hr_portal p JOIN hr_employees e ON e.id=p.employee_id WHERE p.login=?", (login,)).fetchone()
            ok = p and p['active'] and p['status'] != 'inactif' and p['password_hash'] and check_password_hash(p['password_hash'], request.form.get('password') or '')
            if ok:
                conn.execute("UPDATE hr_portal SET last_login=? WHERE employee_id=?", (_at_now(), p['employee_id']))
                hr_log(conn, p['employee_id'], 'Connexion au portail (employé)'); conn.commit()
        finally:
            conn.close()
        if ok:
            _tc_fail.pop(key, None)
            session['emp_id'] = p['employee_id']; session.permanent = True
            try:
                conn2 = get_conn()
                e2 = conn2.execute("SELECT first_name, last_name FROM hr_employees WHERE id=?", (p['employee_id'],)).fetchone()
                conn2.close()
                session['emp_sid'] = sess_open('portail', p['employee_id'], login, f"{e2['first_name']} {e2['last_name']}" if e2 else login)
                session['emp_sid_ts'] = time.time()
            except Exception:
                traceback.print_exc()
            return redirect(url_for('emp_home'))
        f['n'] += 1
        if f['n'] >= 6:
            f = {'n': 0, 'until': time.time() + 600}
        _tc_fail[key] = f
        return _emp_render('login', error='Courriel ou mot de passe incorrect.', login=login)
    if emp_session_emp():
        return redirect(url_for('emp_home'))
    return _emp_render('login', error="Ta session a été fermée par ton gestionnaire." if session.pop('emp_kicked', None) else None, login='')


@app.route('/employe/deconnexion')
def emp_logout():
    sess_close(session.get('emp_sid'), 'déconnexion')
    session.pop('emp_id', None); session.pop('emp_sid', None)
    return redirect(url_for('emp_login'))


@app.route('/employe/activer', methods=['GET', 'POST'])
def emp_activate():
    tok = request.values.get('t') or ''
    conn = get_conn()
    try:
        p = conn.execute("SELECT p.*, e.first_name FROM hr_portal p JOIN hr_employees e ON e.id=p.employee_id WHERE p.token=? AND p.active=1", (tok,)).fetchone() if tok else None
        if not p or (p['token_expires'] or '') < _at_now():
            return _emp_render('expired', error=None)
        if request.method == 'POST':
            pw, pw2 = request.form.get('password') or '', request.form.get('password2') or ''
            if len(pw) < 8:
                return _emp_render('activate', error='Le mot de passe doit avoir au moins 8 caractères.', t=tok, first_name=p['first_name'], login=p['login'])
            if pw != pw2:
                return _emp_render('activate', error='Les deux mots de passe ne sont pas identiques.', t=tok, first_name=p['first_name'], login=p['login'])
            conn.execute("UPDATE hr_portal SET password_hash=?, token=NULL, token_expires=NULL WHERE employee_id=?", (generate_password_hash(pw), p['employee_id']))
            hr_log(conn, p['employee_id'], 'Mot de passe du portail défini (employé)'); conn.commit()
            session['emp_id'] = p['employee_id']; session.permanent = True
            return redirect(url_for('emp_home'))
        return _emp_render('activate', error=None, t=tok, first_name=p['first_name'], login=p['login'])
    finally:
        conn.close()


@app.route('/employe/mot-de-passe-oublie', methods=['GET', 'POST'])
def emp_forgot():
    if request.method == 'POST':
        login = (request.form.get('login') or '').strip().lower()
        conn = get_conn()
        try:
            p = conn.execute("SELECT p.*, e.first_name FROM hr_portal p JOIN hr_employees e ON e.id=p.employee_id WHERE p.login=? AND p.active=1", (login,)).fetchone()
            if p:
                tok = secrets.token_urlsafe(24)
                conn.execute("UPDATE hr_portal SET token=?, token_expires=? WHERE employee_id=?",
                             (tok, (datetime.datetime.now() + datetime.timedelta(hours=2)).strftime(AT_FMT), p['employee_id'])); conn.commit()
                try:
                    send_email(login, f"{get_company_name()} — nouveau mot de passe",
                               f"Bonjour {p['first_name']},\n\nPour choisir un nouveau mot de passe pour ton espace employé, ouvre ce lien (valide 2 heures) :\n"
                               f"{request.host_url.rstrip('/') + url_for('emp_activate', t=tok)}\n\nSi tu n'as rien demandé, ignore ce courriel.\n\n{get_company_name()}",
                               None, mode='send', bcc_company=False)
                except Exception:
                    traceback.print_exc()
        finally:
            conn.close()
        return _emp_render('forgot_sent', error=None)
    return _emp_render('forgot', error=None)


@app.route('/employe')
def emp_home():
    e = emp_session_emp()
    if not e:
        return redirect(url_for('emp_login'))
    return render_template('employe.html', company=get_company_name(), emp=e)


@app.route('/api/emp/me')
def api_emp_me():
    e = emp_session_emp()
    if not e:
        return jsonify({'error': 'Session expirée.'}), 401
    conn = get_conn()
    try:
        st = tc_state(conn, e['id']) if e.get('tc_enabled') else None
        to_sign = conn.execute("SELECT COUNT(*) FROM hr_documents WHERE employee_id=? AND published=1 AND sign_required=1 AND emp_signed_at IS NULL", (e['id'],)).fetchone()[0]
    finally:
        conn.close()
    return jsonify({'first_name': e['first_name'], 'last_name': e['last_name'], 'position': e['position'], 'tc': bool(e.get('tc_enabled')),
                    'state': st, 'to_sign': to_sign, 'company': get_company_name(), 'weekly_hours': 40})


@app.route('/api/emp/hours')
def api_emp_hours():
    e = emp_session_emp()
    if not e:
        return jsonify({'error': 'Session expirée.'}), 401
    try:
        d = datetime.date.fromisoformat(request.args.get('start') or '')
    except ValueError:
        d = datetime.date.today()
    w0 = d - datetime.timedelta(days=d.weekday()); w1 = w0 + datetime.timedelta(days=6)
    conn = get_conn()
    try:
        sh = tc_sheet(conn, e['id'], w0, w1)
    finally:
        conn.close()
    return jsonify({'start': w0.isoformat(), 'end': w1.isoformat(), 'sheet': sh,
                    'prev': (w0 - datetime.timedelta(days=7)).isoformat(), 'next': (w0 + datetime.timedelta(days=7)).isoformat()})


@app.route('/api/emp/documents')
def api_emp_documents():
    e = emp_session_emp()
    if not e:
        return jsonify({'error': 'Session expirée.'}), 401
    conn = get_conn()
    try:
        rows = [dict(r) for r in conn.execute("SELECT id, category, title, published_at, sign_required, mgr_signed_at, mgr_signed_by, emp_signed_at, viewed_at, filename "
                                              "FROM hr_documents WHERE employee_id=? AND published=1 ORDER BY published_at DESC", (e['id'],)).fetchall()]
    finally:
        conn.close()
    for r in rows:
        r['category_label'] = HR_DOC_CATS.get(r['category'], r['category']); r['pdf'] = r.pop('filename', '').lower().endswith('.pdf')
    return jsonify({'documents': rows})


@app.route('/api/emp/documents/<int:did>/file')
def api_emp_doc_file(did):
    e = emp_session_emp()
    if not e:
        return "Session expirée.", 401
    conn = get_conn()
    try:
        d = conn.execute("SELECT * FROM hr_documents WHERE id=? AND employee_id=? AND published=1", (did, e['id'])).fetchone()
        if not d:
            return "Document introuvable.", 404
        if not d['viewed_at']:
            conn.execute("UPDATE hr_documents SET viewed_at=? WHERE id=?", (_at_now(), did))
        hr_log(conn, e['id'], f"Document consulté par l'employé : {d['title']}"); conn.commit()
    finally:
        conn.close()
    p = HR_DIR / str(e['id']) / (d['signed_filename'] or d['filename'])
    if not p.exists():
        return "Fichier introuvable.", 404
    return send_file(str(p), as_attachment=request.args.get('dl') == '1', download_name=(d['title'] or 'document') + p.suffix)


@app.route('/api/emp/documents/<int:did>/sign', methods=['POST'])
def api_emp_doc_sign(did):
    e = emp_session_emp()
    if not e:
        return jsonify({'ok': False, 'error': 'Session expirée.'}), 401
    d = request.get_json(silent=True) or {}
    if not d.get('ack'):
        return jsonify({'ok': False, 'error': 'Coche la case « J\u2019ai lu ce document ».'}), 400
    try:
        sig = hr_sig_clean(d)
    except ValueError as ex:
        return jsonify({'ok': False, 'error': str(ex)}), 400
    conn = get_conn()
    try:
        doc = conn.execute("SELECT * FROM hr_documents WHERE id=? AND employee_id=? AND published=1 AND sign_required=1", (did, e['id'])).fetchone()
        if not doc:
            return jsonify({'ok': False, 'error': 'Ce document ne demande pas de signature.'}), 404
        if doc['emp_signed_at']:
            return jsonify({'ok': False, 'error': 'Tu as déjà signé ce document.'}), 409
        h = hashlib.sha256((HR_DIR / str(e['id']) / doc['filename']).read_bytes()).hexdigest()
        if doc['doc_hash'] and h != doc['doc_hash']:
            return jsonify({'ok': False, 'error': 'Le document a été modifié depuis sa publication : demande à ton gestionnaire de le republier.'}), 409
        conn.execute("UPDATE hr_documents SET emp_sig=?, emp_signed_at=?, emp_comment=?, emp_sign_ip=?, doc_hash=? WHERE id=?",
                     (json.dumps(sig, ensure_ascii=False), _at_now(), str(d.get('comment') or '').strip()[:1000] or None, client_ip(), h, did))
        hr_build_signed_pdf(conn, did)
        hr_log(conn, e['id'], f"Signé par l'employé : {doc['title']}"); conn.commit()
    finally:
        conn.close()
    db_add_audit(f"Portail — {e['first_name']} {e['last_name']}", 'Document signé (employé)', doc['title'] or '')
    return jsonify({'ok': True})


@app.route('/api/emp/schedule/pdf')
def api_emp_schedule_pdf():
    """PDF à imprimer : mon horaire (2 semaines) ou l'horaire du magasin (2 semaines, par département)."""
    e = emp_session_emp()
    if not e:
        return redirect(url_for('emp_login'))
    try:
        d = datetime.date.fromisoformat(request.args.get('start') or '')
    except ValueError:
        d = datetime.date.today()
    w0 = d - datetime.timedelta(days=d.weekday()); w1 = w0 + datetime.timedelta(days=13)
    out = PDF_DIR / "Horaires" / "portail"; out.mkdir(parents=True, exist_ok=True)
    conn = get_conn()
    try:
        if request.args.get('all') == '1':
            p = export_sched_pdf(conn, w0, w1, out / f"Horaire_magasin_{w0}.pdf")
        else:
            mine = sched_cells(conn, 'sched_published', w0, w1, e['id']).get(e['id'], {})
            p = export_sched_emp_pdf(e, w0, w1, mine, [], True, out / f"Horaire_{e['id']}_{w0}.pdf")
    finally:
        conn.close()
    return send_file(str(p), mimetype='application/pdf', as_attachment=False,
                     download_name=('Horaire_du_magasin' if request.args.get('all') == '1' else f"Horaire_{e['first_name']}_{e['last_name']}").replace(' ', '_') + f"_{w0}.pdf")


@app.route('/api/emp/schedule')
def api_emp_schedule():
    e = emp_session_emp()
    if not e:
        return jsonify({'error': 'Session expirée.'}), 401
    try:
        d = datetime.date.fromisoformat(request.args.get('start') or '')
    except ValueError:
        d = datetime.date.today()
    w0 = d - datetime.timedelta(days=d.weekday()); w1 = w0 + datetime.timedelta(days=13)
    conn = get_conn()
    try:
        everyone = request.args.get('all') == '1'
        cells = sched_cells(conn, 'sched_published', w0, w1, None if everyone else e['id'])
        notices = [dict(r) for r in conn.execute("SELECT id, created_at, text FROM sched_notices WHERE employee_id=? AND seen_at IS NULL ORDER BY id DESC LIMIT 3", (e['id'],)).fetchall()]
        if request.args.get('seen') == '1':
            conn.execute("UPDATE sched_notices SET seen_at=? WHERE employee_id=? AND seen_at IS NULL", (_at_now(), e['id'])); conn.commit()
        emps = sched_employees(conn) if everyone else []
    finally:
        conn.close()
    for eid in cells:
        for c in cells[eid].values():
            c['paid'] = sched_paid_min(c)
            if eid != e['id']:
                c['note'] = ''                      # les notes ne sont visibles que par l'employé concerné
    return jsonify({'start': w0.isoformat(), 'mine': cells.get(e['id'], {}), 'all': {str(k): v for k, v in cells.items()} if everyone else None,
                    'employees': [{'id': x['id'], 'name': f"{x['first_name']} {x['last_name']}", 'department': x['department'] or ''} for x in emps],
                    'notices': notices, 'closed': sched_settings()['closed'], 'me': e['id'],
                    'prev': (w0 - datetime.timedelta(days=7)).isoformat(), 'next': (w0 + datetime.timedelta(days=7)).isoformat()})


@app.route('/api/emp/leaves', methods=['GET', 'POST'])
def api_emp_leaves():
    e = emp_session_emp()
    if not e:
        return jsonify({'error': 'Session expirée.'}), 401
    conn = get_conn()
    try:
        if request.method == 'POST':
            d = request.get_json(silent=True) or {}
            try:
                a, b = datetime.date.fromisoformat(d.get('start') or ''), datetime.date.fromisoformat(d.get('end') or '')
            except ValueError:
                return jsonify({'ok': False, 'error': 'Choisis la première et la dernière journée du congé.'}), 400
            if b < a:
                return jsonify({'ok': False, 'error': 'La dernière journée doit être après la première.'}), 400
            if a < datetime.date.today():
                return jsonify({'ok': False, 'error': 'La demande doit commencer aujourd\u2019hui ou plus tard.'}), 400
            if (b - a).days > 60:
                return jsonify({'ok': False, 'error': 'Une demande ne peut pas dépasser 60 jours : fais-en plusieurs au besoin.'}), 400
            kind = d.get('kind') if d.get('kind') in LEAVE_KINDS else 'vacances'
            dup = conn.execute("SELECT start, end, status FROM leave_requests WHERE employee_id=? AND status IN ('en_attente','approuvee') AND start<=? AND end>=?",
                               (e['id'], b.isoformat(), a.isoformat())).fetchone()
            if dup:
                return jsonify({'ok': False, 'error': f"Tu as déjà une demande {LEAVE_STATUS[dup['status']].lower()} du {_d(dup['start'])} au {_d(dup['end'])} qui touche ces dates."}), 400
            note = str(d.get('note') or '').strip()[:500] or None
            conn.execute("INSERT INTO leave_requests(employee_id, start, end, kind, note, status, created_at) VALUES (?,?,?,?,?, 'en_attente', ?)",
                         (e['id'], a.isoformat(), b.isoformat(), kind, note, _at_now()))
            hr_log(conn, e['id'], f"Demande de congé ({LEAVE_KINDS[kind]}) du {a} au {b}"); conn.commit()
            lv = {'kind': kind, 'start': a.isoformat(), 'end': b.isoformat(), 'note': note}
            notified = leave_notify_managers(conn, e, lv)
            return jsonify({'ok': True, 'notified': notified})
        rows = [dict(r) for r in conn.execute("SELECT * FROM leave_requests WHERE employee_id=? ORDER BY start DESC LIMIT 60", (e['id'],)).fetchall()]
        for r in rows:
            r['kind_label'] = LEAVE_KINDS.get(r['kind'], r['kind']); r['status_label'] = LEAVE_STATUS.get(r['status'], r['status'])
            r['days'] = (datetime.date.fromisoformat(r['end']) - datetime.date.fromisoformat(r['start'])).days + 1
        return jsonify({'rows': rows, 'kinds': [[k, v] for k, v in LEAVE_KINDS.items()]})   # dans l'ordre : Vacances d'abord
    finally:
        conn.close()


@app.route('/api/emp/leaves/<int:lid>/cancel', methods=['POST'])
def api_emp_leave_cancel(lid):
    e = emp_session_emp()
    if not e:
        return jsonify({'ok': False, 'error': 'Session expirée.'}), 401
    conn = get_conn()
    try:
        lv = conn.execute("SELECT * FROM leave_requests WHERE id=? AND employee_id=?", (lid, e['id'])).fetchone()
        if not lv or lv['status'] != 'en_attente':
            return jsonify({'ok': False, 'error': 'Seule une demande en attente peut être retirée. Pour un congé déjà approuvé, parle à ton gestionnaire.'}), 400
        conn.execute("UPDATE leave_requests SET status='annulee', cancelled_at=? WHERE id=?", (_at_now(), lid))
        hr_log(conn, e['id'], f"Demande de congé retirée par l'employé ({lv['start']} au {lv['end']})"); conn.commit()
    finally:
        conn.close()
    return jsonify({'ok': True})
