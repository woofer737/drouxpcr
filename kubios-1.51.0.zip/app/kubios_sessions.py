# -*- coding: utf-8 -*-
"""Registre des sessions (utilisateurs en ligne, déconnexion à distance).
Module du tronc commun de Kubios (découpé de app.py en 1.45.0, code inchangé)."""
import os, re, io, csv, sys, json, base64, hashlib, unicodedata, time, shutil, secrets, sqlite3, zipfile, threading, subprocess, datetime, traceback
import urllib.request, urllib.error, urllib.parse, email.utils
from pathlib import Path
from flask import request, session, has_request_context
import licensing
from kubios_base import _at_now, client_ip, get_conn

__all__ = ['_SESS_LOADED', '_SESS_REVOKED', '_sess_ua', '_session_registry', 'sess_close', 'sess_open']


_SESS_REVOKED = set()


_SESS_LOADED = {'ok': False}


def _sess_ua(ua):
    ua = ua or ''
    b = 'Edge' if 'Edg/' in ua else 'Chrome' if 'Chrome/' in ua else 'Firefox' if 'Firefox/' in ua else 'Safari' if 'Safari/' in ua else 'Navigateur'
    o = 'Windows' if 'Windows' in ua else 'Android' if 'Android' in ua else 'iPhone' if 'iPhone' in ua else 'iPad' if 'iPad' in ua else 'Mac' if 'Mac OS' in ua else 'Linux' if 'Linux' in ua else ''
    return f"{b} · {o}" if o else b


def sess_open(kind, user_id, username, display):
    sid = secrets.token_urlsafe(18)
    conn = get_conn()
    try:
        conn.execute("INSERT INTO user_sessions(sid, kind, user_id, username, display, ip, agent, created_at, last_seen) VALUES (?,?,?,?,?,?,?,?,?)",
                     (sid, kind, user_id, username, display, client_ip(), _sess_ua(request.headers.get('User-Agent')), _at_now(), _at_now()))
        conn.commit()
    finally:
        conn.close()
    return sid


def sess_close(sid, by):
    if not sid:
        return
    conn = get_conn()
    try:
        conn.execute("UPDATE user_sessions SET revoked_at=?, revoked_by=? WHERE sid=? AND revoked_at IS NULL", (_at_now(), by, sid)); conn.commit()
    finally:
        conn.close()


def _session_registry():
    """Coupe une session fermée par un administrateur, et note la dernière activité (au plus une fois par minute)."""
    if request.endpoint in ('static',) or not (session.get('user_id') or session.get('emp_id')):
        return None
    if not _SESS_LOADED['ok']:
        try:
            conn = get_conn()
            try:
                _SESS_REVOKED.update(r[0] for r in conn.execute("SELECT sid FROM user_sessions WHERE revoked_at IS NOT NULL AND revoked_by<>'déconnexion' "
                                                               "AND revoked_at > datetime('now', '-31 days')").fetchall())
            finally:
                conn.close()
            _SESS_LOADED['ok'] = True
        except Exception:
            return None
    for key, kind in (('sid', 'user'), ('emp_sid', 'portail')):
        sid = session.get(key)
        if kind == 'user' and not session.get('user_id'):
            continue
        if kind == 'portail' and not session.get('emp_id'):
            continue
        if sid and sid in _SESS_REVOKED:
            if kind == 'user':
                for k in ('user_id', 'username', 'is_admin', 'permissions', 'full_name', 'sid', 'sid_ts'):
                    session.pop(k, None)
                session['kicked'] = 1
            else:
                for k in ('emp_id', 'emp_sid', 'emp_sid_ts'):
                    session.pop(k, None)
                session['emp_kicked'] = 1
            continue
        try:
            if not sid:                                   # session ouverte avant la mise à jour : on l'inscrit
                if kind == 'user':
                    session['sid'] = sess_open('user', session['user_id'], session.get('username'), session.get('full_name') or session.get('username'))
                else:
                    session['emp_sid'] = sess_open('portail', session['emp_id'], None, None)
                session[key + '_ts'] = time.time()
            elif time.time() - (session.get(key + '_ts') or 0) > 60:
                conn = get_conn()
                try:
                    conn.execute("UPDATE user_sessions SET last_seen=?, ip=? WHERE sid=?", (_at_now(), client_ip(), sid)); conn.commit()
                finally:
                    conn.close()
                session[key + '_ts'] = time.time()
        except Exception:
            traceback.print_exc()
    return None
