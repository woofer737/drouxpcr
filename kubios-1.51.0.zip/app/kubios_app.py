# -*- coding: utf-8 -*-
"""L'application Flask et les dossiers de Kubios.
Module de Kubios (découpé de app.py en 1.46.0, code inchangé)."""
import os
import re
import io
import csv
import sys
import json
import base64
import hashlib
import unicodedata
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import openpyxl
from openpyxl.utils import get_column_letter
import licensing


__all__ = ['APP_DIR', 'BASE_DIR', 'app']


BASE_DIR = Path(__file__).resolve().parent.parent  # C:\DBouxpCR


APP_DIR = Path(__file__).resolve().parent


app = Flask(__name__)
