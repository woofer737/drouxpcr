# -*- coding: utf-8 -*-
"""Petits outils communs (format de l'argent, module 3D).
Module de Kubios (découpé de app.py en 1.48.0, code inchangé)."""
import os
import re
import io
import csv
import sys
import json
import base64
import hashlib
import unicodedata
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import openpyxl
from openpyxl.utils import get_column_letter
import licensing
from kubios_systeme import _three_state, download_three_vendor, three_local_ready

__all__ = ['_fmt_money_fr', 'ensure_three_vendor_async']


def _fmt_money_fr(v):
    return f"{v:,.2f}".replace(',', '\u00a0').replace('.', ',') + "\u00a0$"


def ensure_three_vendor_async():
    if not three_local_ready() and not _three_state['running']:
        threading.Thread(target=download_three_vendor, daemon=True).start()
