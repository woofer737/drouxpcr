# -*- coding: utf-8 -*-
"""Pages des comptes de crédit : comptes, mouvements, importations, instantanés.
Module de Kubios (découpé de app.py en 1.49.0, code inchangé)."""
import os
import re
import io
import csv
import sys
import json
import base64
import hashlib
import unicodedata
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import openpyxl
from openpyxl.utils import get_column_letter
import licensing
from kubios_base import get_company_name, get_conn
from kubios_pdf import LOGO_PATH, _pdf_disclaimer
from kubios_app import app
from kubios_auth import admin_required_check, log_audit, permission_required_check
from kubios_rh_outils import PDF_DIR
from kubios_lightspeed import _parse_money
from kubios_comptes import (
    CREDIT_BACKUP_DIR, CREDIT_BACKUP_KEEP, _credit_client_display_name, _credit_net_debt,
    _norm_credit_name, _split_debt, db_backup_scope, db_discard_credit_backup, db_list_credit_backups,
    db_restore_credit_backup, mark_dirty,
)

__all__ = ['CREDIT_FIELD_LABELS', '_apply_movement_delta', '_find_col', '_fmt_credit_val', '_ls_sync_lock', '_read_upload_rows', 'api_credit_clients_pdf', 'api_credit_snapshot_pdf', 'api_delete_credit_client', 'api_delete_credit_movement', 'api_get_credit_client', 'api_import_credit_clients', 'api_import_credit_movements', 'api_list_credit_backups', 'api_list_credit_clients', 'api_list_credit_snapshots', 'api_restore_credit_backup', 'api_update_credit_client', 'api_update_credit_movement', 'credit_accounts_page', 'db_backup_credit', 'db_capture_credit_snapshot', 'db_credit_client_movements', 'db_delete_credit_client', 'db_delete_credit_movement', 'db_get_credit_client', 'db_get_credit_snapshot', 'db_import_credit_clients', 'db_import_credit_movements', 'db_list_credit_clients', 'db_list_credit_snapshots', 'db_update_credit_balances', 'db_update_credit_client', 'db_update_credit_movement', 'generate_credit_accounts_pdf']


def db_list_credit_clients():
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM credit_clients ORDER BY prenom_entreprise COLLATE NOCASE, nom COLLATE NOCASE"
    ).fetchall()
    conn.close()
    out = []
    for r in rows:
        d = dict(r)
        d['display_name'] = _credit_client_display_name(d)
        out.append(d)
    return out


def db_get_credit_client(client_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM credit_clients WHERE id=?", (client_id,)).fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    d['display_name'] = _credit_client_display_name(d)
    return d


def db_credit_client_movements(client_id):
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM credit_movements WHERE credit_client_id=? ORDER BY date_mouvement, id",
        (client_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


CREDIT_FIELD_LABELS = {
    'prenom_entreprise': "Prénom / entreprise", 'nom': "Nom", 'credit_limit': "Limite de crédit",
    'solde': "Montant dû", 'deposit': "Dépôt", 'notes': "Notes", 'no_sync': "Ne pas synchroniser",
}


def db_update_credit_client(client_id, data):
    """Modifie un compte de crédit. Retourne (avant, changements)."""
    conn = get_conn()
    try:
        cur = conn.execute("SELECT * FROM credit_clients WHERE id=?", (client_id,)).fetchone()
        if cur is None:
            raise RuntimeError("Compte introuvable.")
        cur = dict(cur)
        new = {}
        if 'prenom_entreprise' in data:
            v = (data.get('prenom_entreprise') or '').strip()
            if not v:
                raise RuntimeError("Le prénom / nom d'entreprise est obligatoire.")
            new['prenom_entreprise'] = v
        if 'nom' in data:
            new['nom'] = (data.get('nom') or '').strip() or None
        for k in ('credit_limit', 'solde', 'deposit'):
            if k in data:
                try:
                    val = round(_parse_money(data.get(k)), 2)
                except Exception:
                    raise RuntimeError(f"Montant invalide : {CREDIT_FIELD_LABELS[k]}.")
                if val < 0:
                    raise RuntimeError(f"{CREDIT_FIELD_LABELS[k]} ne peut pas être négatif.")
                new[k] = val
        if 'notes' in data:
            new['notes'] = (data.get('notes') or '').strip() or None
        if 'no_sync' in data:
            new['no_sync'] = 1 if data.get('no_sync') in (True, 1, '1', 'true', 'on') else 0
        changes = []
        for k, v in new.items():
            old = cur.get(k)
            if isinstance(v, float):
                if abs(float(old or 0) - v) >= 0.005:
                    changes.append((k, old, v))
            elif (old if old not in ('',) else None) != v:
                changes.append((k, old, v))
        if changes:
            sets = ", ".join(f"{k}=?" for k, _, _ in changes)
            conn.execute(f"UPDATE credit_clients SET {sets} WHERE id=?",
                         [v for _, _, v in changes] + [client_id])
            conn.commit()
        return cur, changes
    finally:
        conn.close()


def db_delete_credit_client(client_id):
    conn = get_conn()
    try:
        cur = conn.execute("SELECT * FROM credit_clients WHERE id=?", (client_id,)).fetchone()
        if cur is None:
            raise RuntimeError("Compte introuvable.")
        n = conn.execute("SELECT COUNT(*) c FROM credit_movements WHERE credit_client_id=?",
                         (client_id,)).fetchone()['c']
        conn.execute("DELETE FROM credit_movements WHERE credit_client_id=?", (client_id,))
        conn.execute("DELETE FROM credit_clients WHERE id=?", (client_id,))
        conn.commit()
        return dict(cur), n
    finally:
        conn.close()


def _apply_movement_delta(conn, client_id, delta):
    """Ajuste le solde d'un compte de « delta » (positif = le client doit plus)."""
    c = conn.execute("SELECT * FROM credit_clients WHERE id=?", (client_id,)).fetchone()
    if c is None or abs(delta) < 0.005:
        return
    solde, deposit = _split_debt(_credit_net_debt(dict(c)) + delta)
    conn.execute("UPDATE credit_clients SET solde=?, deposit=? WHERE id=?", (solde, deposit, client_id))


def db_update_credit_movement(movement_id, data):
    """Modifie un mouvement ; le solde du client est ajusté de la différence
    de montant. Retourne (avant, après)."""
    conn = get_conn()
    try:
        m = conn.execute("SELECT * FROM credit_movements WHERE id=?", (movement_id,)).fetchone()
        if m is None:
            raise RuntimeError("Mouvement introuvable.")
        m = dict(m)
        date_mv = (data.get('date_mouvement') or '').strip() or None
        if date_mv:
            try:
                datetime.date.fromisoformat(date_mv)
            except Exception:
                raise RuntimeError("Date invalide (format attendu : AAAA-MM-JJ).")
        montant = round(_parse_money(data.get('montant')), 2)
        after = {
            'date_mouvement': date_mv,
            'type': (data.get('type') or '').strip() or None,
            'sale': (data.get('sale') or '').strip() or None,
            'montant': montant,
        }
        conn.execute("UPDATE credit_movements SET date_mouvement=?, type=?, sale=?, montant=? WHERE id=?",
                     (after['date_mouvement'], after['type'], after['sale'], after['montant'], movement_id))
        _apply_movement_delta(conn, m['credit_client_id'], montant - float(m['montant'] or 0))
        conn.commit()
        return m, after
    finally:
        conn.close()


def db_delete_credit_movement(movement_id):
    """Supprime un mouvement et annule son effet sur le solde du client."""
    conn = get_conn()
    try:
        m = conn.execute("SELECT * FROM credit_movements WHERE id=?", (movement_id,)).fetchone()
        if m is None:
            raise RuntimeError("Mouvement introuvable.")
        m = dict(m)
        conn.execute("DELETE FROM credit_movements WHERE id=?", (movement_id,))
        _apply_movement_delta(conn, m['credit_client_id'], -float(m['montant'] or 0))
        conn.commit()
        return m
    finally:
        conn.close()


def db_import_credit_clients(rows):
    """Remplace ENTIÈREMENT la liste des comptes de crédit à partir de lignes
    {prenom_entreprise, nom, credit_limit, solde, deposit, ligne_source}. Utilisé
    pour l'import initial (ou une réinitialisation complète demandée
    explicitement par un administrateur) — jamais appelé automatiquement, et
    n'affecte jamais l'historique des mouvements déjà importés (qui reste lié
    par credit_client_id — une réinitialisation supprime donc aussi, en
    cascade, tout l'historique des mouvements, car les anciens clients
    n'existent plus)."""
    conn = get_conn()
    conn.execute("DELETE FROM credit_movements")
    conn.execute("DELETE FROM credit_clients")
    conn.execute("DELETE FROM ls_pending_accounts")
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    for r in rows:
        conn.execute(
            "INSERT INTO credit_clients(prenom_entreprise, nom, credit_limit, solde, deposit, ligne_source, created_at) "
            "VALUES (?,?,?,?,?,?,?)",
            (r['prenom_entreprise'], r.get('nom') or None, float(r.get('credit_limit') or 0),
             float(r.get('solde') or 0), float(r.get('deposit') or 0),
             str(r['ligne_source']) if r.get('ligne_source') not in (None, '') else None, now)
        )
    conn.commit()
    count = conn.execute("SELECT COUNT(*) c FROM credit_clients").fetchone()['c']
    conn.close()
    mark_dirty()
    return count


def db_import_credit_movements(rows):
    """Importe des mouvements (transactions Lightspeed). Un mouvement déjà
    importé (même lightspeed_id) est ignoré — permet de réimporter le même
    fichier par erreur sans dupliquer. Les autres sont ajoutés et le solde du
    client correspondant (trouvé par nom, créé automatiquement si absent) est
    mis à jour. Retourne un résumé {imported, skipped, created_clients}."""
    conn = get_conn()
    existing_ids = set(
        r['lightspeed_id'] for r in conn.execute(
            "SELECT lightspeed_id FROM credit_movements WHERE lightspeed_id IS NOT NULL"
        ).fetchall()
    )
    clients = conn.execute("SELECT * FROM credit_clients").fetchall()
    by_name = {}
    for c in clients:
        cd = dict(c)
        by_name[_norm_credit_name(_credit_client_display_name(cd))] = cd

    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    imported = 0
    skipped = 0
    created_clients = 0
    locked = 0

    for r in rows:
        lsid = str(r.get('lightspeed_id') or '').strip() or None
        if lsid and lsid in existing_ids:
            skipped += 1
            continue
        customer = (r.get('customer') or '').strip()
        key = _norm_credit_name(customer)
        client = by_name.get(key)
        if client and client.get('no_sync'):
            locked += 1
            continue
        if not client:
            cur = conn.execute(
                "INSERT INTO credit_clients(prenom_entreprise, nom, credit_limit, solde, deposit, notes, created_at) "
                "VALUES (?,?,?,?,?,?,?)",
                (customer or '(client inconnu)', None, 0, 0, 0,
                 "Créé automatiquement lors d'un import de mouvements Lightspeed — "
                 "aucun client existant ne correspond à ce nom, à vérifier.", now)
            )
            client = {'id': cur.lastrowid, 'solde': 0.0, 'deposit': 0.0}
            by_name[key] = client
            created_clients += 1

        montant = float(r.get('montant') or 0)
        conn.execute(
            "INSERT INTO credit_movements(credit_client_id, lightspeed_id, date_mouvement, montant, type, sale, "
            "customer_brut, notes, imported_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (client['id'], lsid, r.get('date'), montant, r.get('type'), r.get('sale'),
             customer, r.get('notes') or '', now)
        )
        client['solde'], client['deposit'] = _split_debt(_credit_net_debt(client) + montant)
        conn.execute("UPDATE credit_clients SET solde=?, deposit=? WHERE id=?",
                     (client['solde'], client['deposit'], client['id']))
        if lsid:
            existing_ids.add(lsid)
        imported += 1

    conn.commit()
    conn.close()
    mark_dirty()
    return {'imported': imported, 'skipped': skipped, 'created_clients': created_clients, 'locked': locked}


def db_update_credit_balances(rows):
    """Met à jour les soldes des comptes de crédit à partir d'un « instantané »
    mensuel Lightspeed (une ligne par client avec sa limite de crédit et son
    solde dû ACTUELS — pas une liste de transactions). Pour chaque ligne : le
    client est trouvé par nom (prénom/entreprise + nom, comparaison insensible
    à la casse/accents), créé automatiquement s'il n'existe pas encore, puis
    sa limite de crédit et son solde sont remplacés par les valeurs du fichier.
    Si le solde change, un mouvement synthétique (type « Ajustement mensuel »)
    est enregistré pour garder un historique consultable dans la fiche client.
    Retourne {updated, unchanged, created_clients}."""
    conn = get_conn()
    clients = conn.execute("SELECT * FROM credit_clients").fetchall()
    by_name = {}
    for c in clients:
        cd = dict(c)
        by_name[_norm_credit_name(_credit_client_display_name(cd))] = cd

    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    today_str = datetime.date.today().strftime('%Y-%m-%d')
    updated = 0
    unchanged = 0
    created_clients = 0
    locked = 0

    for r in rows:
        prenom = (r.get('prenom_entreprise') or '').strip()
        nom = (r.get('nom') or '').strip() or None
        display = _credit_client_display_name({'prenom_entreprise': prenom, 'nom': nom})
        key = _norm_credit_name(display)
        if not key:
            continue
        new_limit = float(r.get('credit_limit') or 0)
        # « Debt » Lightspeed : positif = montant dû ; négatif = crédit en
        # faveur du client, conservé comme dépôt (montant dû à 0).
        debt = float(r.get('solde') or 0)
        new_solde = max(debt, 0.0)
        new_deposit = max(-debt, 0.0)
        client = by_name.get(key)
        if client and client.get('no_sync'):
            locked += 1
            continue
        if not client:
            cur = conn.execute(
                "INSERT INTO credit_clients(prenom_entreprise, nom, credit_limit, solde, deposit, notes, created_at) "
                "VALUES (?,?,?,?,?,?,?)",
                (prenom or '(client inconnu)', nom, new_limit, new_solde, 0,
                 "Créé automatiquement lors d'un import d'instantané mensuel Lightspeed — "
                 "aucun client existant ne correspond à ce nom, à vérifier.", now)
            )
            client = {'id': cur.lastrowid, 'solde': 0.0, 'deposit': 0.0, 'credit_limit': 0.0}
            by_name[key] = client
            created_clients += 1

        old_solde = float(client.get('solde') or 0.0)
        old_deposit = float(client.get('deposit') or 0.0)
        # Ancien « Debt » équivalent : les fiches importées avant la 1.9.1
        # pouvaient avoir un solde négatif (Debt brut) — on le reprend tel quel
        # pour ne pas créer de faux mouvement lors de la conversion en dépôt.
        old_debt = old_solde if old_solde < 0 else old_solde - old_deposit
        delta = round(debt - old_debt, 2)
        conn.execute("UPDATE credit_clients SET credit_limit=?, solde=?, deposit=? WHERE id=?",
                     (new_limit, new_solde, new_deposit, client['id']))
        client['solde'] = new_solde
        client['deposit'] = new_deposit
        client['credit_limit'] = new_limit

        if abs(delta) >= 0.01:
            conn.execute(
                "INSERT INTO credit_movements(credit_client_id, lightspeed_id, date_mouvement, montant, type, sale, "
                "customer_brut, notes, imported_at) VALUES (?,?,?,?,?,?,?,?,?)",
                (client['id'], None, today_str, delta, 'Ajustement mensuel', None, display,
                 f"Instantané Lightspeed importé le {today_str} : Debt {old_debt:.2f}$ -> {debt:.2f}$", now)
            )
            updated += 1
        else:
            unchanged += 1

    conn.commit()
    conn.close()
    mark_dirty()
    return {'updated': updated, 'unchanged': unchanged, 'created_clients': created_clients, 'locked': locked}


def db_capture_credit_snapshot(label, source=None):
    """Prend une photo de l'état COMPLET de la liste des comptes de crédit
    (tous les clients, avec leur limite/solde/dépôt du moment) et la range
    dans credit_snapshots/credit_snapshot_lines. Appelé après chaque import
    (initial, instantané mensuel ou journal de transactions) pour garder un
    rapport téléchargeable par import, même si plusieurs imports ont lieu
    dans le même mois."""
    conn = get_conn()
    clients = conn.execute(
        "SELECT * FROM credit_clients ORDER BY prenom_entreprise COLLATE NOCASE, nom COLLATE NOCASE"
    ).fetchall()
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    total_limit = sum((c['credit_limit'] or 0) for c in clients)
    total_solde = sum((c['solde'] or 0) for c in clients)
    total_deposit = sum((c['deposit'] or 0) for c in clients)
    cur = conn.execute(
        "INSERT INTO credit_snapshots(created_at, label, source, client_count, total_credit_limit, "
        "total_solde, total_deposit) VALUES (?,?,?,?,?,?,?)",
        (now, label, source, len(clients), total_limit, total_solde, total_deposit)
    )
    snap_id = cur.lastrowid
    for c in clients:
        conn.execute(
            "INSERT INTO credit_snapshot_lines(snapshot_id, prenom_entreprise, nom, credit_limit, solde, deposit) "
            "VALUES (?,?,?,?,?,?)",
            (snap_id, c['prenom_entreprise'], c['nom'], c['credit_limit'] or 0, c['solde'] or 0, c['deposit'] or 0)
        )
    conn.commit()
    conn.close()
    mark_dirty()
    return snap_id


def db_list_credit_snapshots():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM credit_snapshots ORDER BY created_at DESC, id DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def db_get_credit_snapshot(snapshot_id):
    conn = get_conn()
    header = conn.execute("SELECT * FROM credit_snapshots WHERE id=?", (snapshot_id,)).fetchone()
    if not header:
        conn.close()
        return None, None
    lines = conn.execute(
        "SELECT * FROM credit_snapshot_lines WHERE snapshot_id=? "
        "ORDER BY prenom_entreprise COLLATE NOCASE, nom COLLATE NOCASE",
        (snapshot_id,)
    ).fetchall()
    conn.close()
    out_lines = []
    for l in lines:
        d = dict(l)
        d['display_name'] = _credit_client_display_name(d)
        out_lines.append(d)
    return dict(header), out_lines


def db_backup_credit(label, username):
    return db_backup_scope('credit', label, username)


_ls_sync_lock = threading.Lock()


def generate_credit_accounts_pdf(rows, title, subtitle, filename_stub):
    """Génère un PDF listant les comptes de crédit (client / limite / solde /
    dépôt) avec le logo en haut à droite, sur le même modèle que les autres
    rapports (état de compte, rapport d'âge, etc.). `rows` doit contenir des
    dicts avec au moins display_name (ou prenom_entreprise/nom), credit_limit,
    solde, deposit."""
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Table, TableStyle, Paragraph, Spacer
    from reportlab.platypus.flowables import HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.utils import ImageReader

    report_dir = PDF_DIR / "Rapports_comptes_credit"
    report_dir.mkdir(exist_ok=True)
    safe_stub = re.sub(r'[^A-Za-z0-9_\-]+', '_', filename_stub)
    pdf_path = report_dir / f"{safe_stub}.pdf"

    page_w, page_h = letter
    left_margin = right_margin = 18 * mm
    bottom_margin = 18 * mm
    header_reserved = 50  # mm

    styles = getSampleStyleSheet()
    footer_style = ParagraphStyle('footer', parent=styles['Normal'], fontSize=10)
    emission_date = datetime.date.today().strftime('%Y-%m-%d')

    def draw_header(canvas, doc_):
        canvas.saveState()
        x = left_margin
        top = page_h - 20 * mm
        canvas.setFont('Helvetica-Bold', 16)
        canvas.drawString(x, top, title)
        canvas.setFont('Helvetica-Bold', 9)
        canvas.drawString(x, top - 9 * mm, "Généré le :")
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x + 22 * mm, top - 9 * mm, emission_date)
        canvas.setFont('Helvetica', 9)
        canvas.drawString(x, top - 14 * mm, subtitle)

        if LOGO_PATH.exists():
            img = ImageReader(str(LOGO_PATH))
            iw, ih = img.getSize()
            logo_w = 50 * mm
            logo_h = logo_w * ih / iw
            canvas.drawImage(img, page_w - right_margin - logo_w, top - logo_h + 2 * mm,
                              width=logo_w, height=logo_h, mask='auto')

        canvas.setStrokeColor(colors.HexColor('#999999'))
        canvas.setLineWidth(0.5)
        rule_y = top - 18 * mm
        canvas.line(left_margin, rule_y, page_w - right_margin, rule_y)
        canvas.restoreState()

    def draw_plain(canvas, doc_):
        pass

    frame_first = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                         page_h - bottom_margin - header_reserved * mm, id='first')
    frame_rest = Frame(left_margin, bottom_margin, page_w - left_margin - right_margin,
                        page_h - bottom_margin - 15 * mm, id='rest')

    doc = BaseDocTemplate(str(pdf_path), pagesize=letter)
    doc.addPageTemplates([
        PageTemplate(id='First', frames=[frame_first], onPage=draw_header),
        PageTemplate(id='Rest', frames=[frame_rest], onPage=draw_plain),
    ])

    story = []
    if not rows:
        story.append(Paragraph("Aucun client.", styles['Normal']))
    else:
        data = [["Client", "Limite de crédit", "Solde dû", "Dépôt"]]
        grand = {'credit_limit': 0.0, 'solde': 0.0, 'deposit': 0.0}
        for r in rows:
            name = r.get('display_name') or _credit_client_display_name(r)
            climit = r.get('credit_limit') or 0
            solde = r.get('solde') or 0
            deposit = r.get('deposit') or 0
            data.append([
                name,
                f"{climit:,.2f} $", f"{solde:,.2f} $", f"{deposit:,.2f} $",
            ])
            grand['credit_limit'] += climit
            grand['solde'] += solde
            grand['deposit'] += deposit
        data.append([
            "TOTAL",
            f"{grand['credit_limit']:,.2f} $", f"{grand['solde']:,.2f} $", f"{grand['deposit']:,.2f} $",
        ])

        t = Table(data, colWidths=[80 * mm, 35 * mm, 35 * mm, 35 * mm], repeatRows=1)
        t.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8.5),
            ('GRID', (0, 0), (-1, -2), 0.5, colors.black),
            ('LINEABOVE', (0, -1), (-1, -1), 0.75, colors.black),
            ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
            ('ALIGN', (0, 0), (0, -1), 'LEFT'),
            ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#f3f4f6')),
        ]))
        story.append(t)
        story.append(Spacer(1, 4 * mm))
        story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#999999')))
        story.append(Spacer(1, 3 * mm))
        story.append(Paragraph(
            f"<b>{len(rows)} client(s) — total dû : {grand['solde']:,.2f} $ — "
            f"total dépôts : {grand['deposit']:,.2f} $</b>",
            footer_style))

    story.append(_pdf_disclaimer())
    doc.build(story)
    return pdf_path


@app.route('/comptes-de-credit')
def credit_accounts_page():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    return render_template('credit_accounts.html', company=get_company_name(),
                            username=session.get('username'), is_admin=session.get('is_admin'),
                            permissions=session.get('permissions') or [])


@app.route('/api/credit-clients')
def api_list_credit_clients():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    return jsonify(db_list_credit_clients())


@app.route('/api/credit-clients/<int:client_id>')
def api_get_credit_client(client_id):
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    client = db_get_credit_client(client_id)
    if not client:
        return jsonify({'error': 'Client introuvable.'}), 404
    client['movements'] = db_credit_client_movements(client_id)
    client['can_delete'] = bool(session.get('is_admin'))
    return jsonify(client)


def _fmt_credit_val(k, v):
    if k == 'no_sync':
        return "oui" if v else "non"
    if isinstance(v, (int, float)) and k != 'no_sync':
        return f"{float(v):,.2f} $".replace(',', ' ')
    return v if v not in (None, '') else '—'


@app.route('/api/credit-clients/<int:client_id>', methods=['PUT'])
def api_update_credit_client(client_id):
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    try:
        before, changes = db_update_credit_client(client_id, request.json or {})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    if changes:
        details = "; ".join(f"{CREDIT_FIELD_LABELS.get(k, k)} : {_fmt_credit_val(k, a)} → {_fmt_credit_val(k, b)}"
                            for k, a, b in changes)
        log_audit('Modification compte de crédit', f"{_credit_client_display_name(before)} — {details}")
    return jsonify({'ok': True, 'changed': len(changes)})


@app.route('/api/credit-clients/<int:client_id>', methods=['DELETE'])
def api_delete_credit_client(client_id):
    resp = admin_required_check()
    if resp is not None:
        return resp
    try:
        before, n = db_delete_credit_client(client_id)
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    log_audit('Suppression compte de crédit',
              f"{_credit_client_display_name(before)} — limite {_fmt_credit_val('x', before.get('credit_limit') or 0)}, "
              f"dû {_fmt_credit_val('x', before.get('solde') or 0)}, dépôt {_fmt_credit_val('x', before.get('deposit') or 0)}, "
              f"{n} mouvement(s) supprimé(s)")
    return jsonify({'ok': True})


@app.route('/api/credit-movements/<int:movement_id>', methods=['PUT'])
def api_update_credit_movement(movement_id):
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    try:
        before, after = db_update_credit_movement(movement_id, request.json or {})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    client = db_get_credit_client(before['credit_client_id']) or {}
    log_audit('Modification mouvement de crédit',
              f"{client.get('display_name', '?')} — {before.get('date_mouvement') or '—'} "
              f"{before.get('type') or ''} {float(before.get('montant') or 0):.2f} $ → "
              f"{after['date_mouvement'] or '—'} {after['type'] or ''} {after['montant']:.2f} $")
    return jsonify({'ok': True})


@app.route('/api/credit-movements/<int:movement_id>', methods=['DELETE'])
def api_delete_credit_movement(movement_id):
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    try:
        m = db_delete_credit_movement(movement_id)
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    client = db_get_credit_client(m['credit_client_id']) or {}
    log_audit('Suppression mouvement de crédit',
              f"{client.get('display_name', '?')} — {m.get('date_mouvement') or '—'} {m.get('type') or ''} "
              f"{float(m.get('montant') or 0):.2f} $ (solde ajusté)")
    return jsonify({'ok': True})


def _read_upload_rows(file_storage):
    """Lit un fichier .xlsx ou .csv téléversé et retourne (headers, rows) —
    rows est une liste de listes, headers la première ligne. Détecte le
    format par l'extension du nom de fichier."""
    filename = (file_storage.filename or '').lower()
    raw = file_storage.read()
    if filename.endswith('.csv'):
        try:
            text = raw.decode('utf-8-sig')
        except UnicodeDecodeError:
            text = raw.decode('latin-1')
        reader = csv.reader(io.StringIO(text))
        all_rows = [row for row in reader if any((c or '').strip() for c in row)]
        if not all_rows:
            return [], []
        return all_rows[0], all_rows[1:]
    else:
        wb = openpyxl.load_workbook(io.BytesIO(raw), data_only=True)
        ws = wb.worksheets[0]
        all_rows = [list(r) for r in ws.iter_rows(values_only=True)
                    if any(c not in (None, '') for c in r)]
        if not all_rows:
            return [], []
        return [str(h or '') for h in all_rows[0]], all_rows[1:]


def _find_col(headers, *candidates):
    """Trouve l'index d'une colonne par nom (insensible à la casse/accents
    approximative), en essayant chaque candidat dans l'ordre."""
    norm_headers = [(h or '').strip().lower() for h in headers]
    for cand in candidates:
        cand_l = cand.strip().lower()
        for i, h in enumerate(norm_headers):
            if h == cand_l:
                return i
    return None


@app.route('/api/credit-clients/import', methods=['POST'])
def api_import_credit_clients():
    # Remplace/réinitialise TOUTE la liste des clients (et supprime l'historique
    # des mouvements en cascade) — opération destructrice réservée aux
    # administrateurs, contrairement aux autres actions de ce module qui ne
    # demandent que la permission 'credit_accounts'.
    resp = admin_required_check()
    if resp is not None:
        return resp
    if 'file' not in request.files or not request.files['file'].filename:
        return jsonify({'ok': False, 'error': "Aucun fichier reçu."}), 400
    divide_by_2 = str(request.form.get('divide_by_2', '')).lower() in ('1', 'true', 'on')
    try:
        headers, data_rows = _read_upload_rows(request.files['file'])
        # Deux formats acceptés : le fichier en français (Prénom / Entreprise,
        # Nom, Limite de crédit, Montant dû, Dépôt) ou l'export Lightspeed
        # « credit_account_listings » en anglais (First Name, Last Name,
        # Credit Limit, Debt).
        i_prenom = _find_col(headers, 'Prénom / Entreprise', 'Prenom / Entreprise', 'First Name',
                             'Nom', 'Client')
        i_nom = _find_col(headers, 'Last Name') if _find_col(headers, 'First Name') == i_prenom \
            else _find_col(headers, 'Nom', 'Last Name')
        i_limit = _find_col(headers, 'Limite de crédit', 'Limite de credit', 'Credit Limit')
        i_du = _find_col(headers, 'Montant dû', 'Montant du', 'Debt', 'Solde')
        i_dep = _find_col(headers, 'Dépôt', 'Depot', 'Deposit')
        i_src = _find_col(headers, 'Ligne source')
        if i_prenom is None:
            return jsonify({'ok': False, 'error':
                             "Colonne du nom du client introuvable (attendu : "
                             "« Prénom / Entreprise » ou, pour l'export Lightspeed, "
                             "« First Name »)."}), 400
        rows = []
        for r in data_rows:
            def cell(i):
                return r[i] if i is not None and i < len(r) else None
            montant_du = _parse_money(cell(i_du))
            deposit = _parse_money(cell(i_dep))
            if i_dep is None and montant_du < 0:
                # Export Lightspeed (pas de colonne Dépôt) : un « Debt » négatif
                # est un crédit en faveur du client — c'est son dépôt, et il ne
                # doit rien.
                deposit = -montant_du
                montant_du = 0.0
            if divide_by_2:
                montant_du = montant_du / 2
                deposit = deposit / 2
            rows.append({
                'prenom_entreprise': (str(cell(i_prenom)).strip() if cell(i_prenom) is not None else ''),
                'nom': (str(cell(i_nom)).strip() or None) if cell(i_nom) is not None else None,
                'credit_limit': _parse_money(cell(i_limit)),
                'solde': montant_du,
                'deposit': deposit,
                'ligne_source': cell(i_src),
            })
        rows = [r for r in rows if r['prenom_entreprise']]
        db_backup_credit(f"Avant réinitialisation de la liste ({request.files['file'].filename})",
                         session.get('username'))
        count = db_import_credit_clients(rows)
        log_audit('Import liste comptes de crédit', f"{count} client(s)" + (" (montants divisés par 2)" if divide_by_2 else ""))
        snap_id = db_capture_credit_snapshot(
            'Import initial / réinitialisation de la liste', request.files['file'].filename)
        return jsonify({'ok': True, 'count': count, 'snapshot_id': snap_id})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/credit-movements/import', methods=['POST'])
def api_import_credit_movements():
    """Accepte deux formats de fichier Lightspeed, détectés automatiquement
    à partir des en-têtes de colonnes :
      1) Journal de transactions (colonnes Customer + Amount, ex. la feuille
         « Mouvements ») -> chaque ligne est ajoutée comme mouvement distinct.
      2) Instantané mensuel des soldes (colonnes First Name/Last Name +
         Debt/Credit Limit, ex. l'export récurrent
         « credit_account_listings... .csv ») -> chaque ligne remplace la
         limite de crédit et le solde actuel du client correspondant."""
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    if 'file' not in request.files or not request.files['file'].filename:
        return jsonify({'ok': False, 'error': "Aucun fichier reçu."}), 400
    try:
        headers, data_rows = _read_upload_rows(request.files['file'])
        i_amount = _find_col(headers, 'Amount', 'Montant')
        i_customer = _find_col(headers, 'Customer', 'Client')
        i_first = _find_col(headers, 'First Name', 'Prénom / Entreprise', 'Prenom / Entreprise', 'Prénom', 'Prenom')
        i_last = _find_col(headers, 'Last Name', 'Nom')
        i_debt = _find_col(headers, 'Debt', 'Montant dû', 'Montant du', 'Solde')
        i_limit = _find_col(headers, 'Credit Limit', 'Limite de crédit', 'Limite de credit')

        if i_customer is not None and i_amount is not None:
            # --- Format 1 : journal de transactions ---
            i_id = _find_col(headers, 'ID')
            i_date = _find_col(headers, 'Date')
            i_type = _find_col(headers, 'Type')
            i_sale = _find_col(headers, 'Sale')
            rows = []
            for r in data_rows:
                def cell(i):
                    return r[i] if i is not None and i < len(r) else None
                date_raw = cell(i_date)
                date_str = str(date_raw)[:10] if date_raw else None
                rows.append({
                    'lightspeed_id': cell(i_id),
                    'date': date_str,
                    'montant': _parse_money(cell(i_amount)),
                    'type': cell(i_type),
                    'sale': cell(i_sale),
                    'customer': cell(i_customer),
                })
            rows = [r for r in rows if r['customer']]
            backup_id = db_backup_credit(
                f"Avant import du journal de transactions ({request.files['file'].filename})",
                session.get('username'))
            summary = db_import_credit_movements(rows)
            if not summary['imported'] and not summary['created_clients']:
                db_discard_credit_backup(backup_id)
            log_audit('Import mouvements comptes de crédit (journal de transactions)',
                      f"{summary['imported']} importé(s), {summary['skipped']} ignoré(s) (déjà présents), "
                      f"{summary['created_clients']} nouveau(x) client(s), "
                      f"{summary['locked']} ligne(s) ignorée(s) (compte non synchronisé)")
            snap_id = db_capture_credit_snapshot(
                'Import journal de transactions', request.files['file'].filename)
            return jsonify({'ok': True, 'mode': 'transactions', 'snapshot_id': snap_id, **summary})

        elif i_first is not None and (i_debt is not None or i_limit is not None):
            # --- Format 2 : instantané mensuel des soldes ---
            rows = []
            for r in data_rows:
                def cell(i):
                    return r[i] if i is not None and i < len(r) else None
                prenom = cell(i_first)
                if not prenom:
                    continue
                rows.append({
                    'prenom_entreprise': prenom,
                    'nom': cell(i_last),
                    'credit_limit': _parse_money(cell(i_limit)),
                    'solde': _parse_money(cell(i_debt)),
                })
            backup_id = db_backup_credit(
                f"Avant import de l'instantané mensuel ({request.files['file'].filename})",
                session.get('username'))
            summary = db_update_credit_balances(rows)
            if not summary['updated'] and not summary['created_clients']:
                db_discard_credit_backup(backup_id)
            log_audit('Import mouvements comptes de crédit (instantané mensuel)',
                      f"{summary['updated']} solde(s) mis à jour, {summary['unchanged']} inchangé(s), "
                      f"{summary['created_clients']} nouveau(x) client(s), "
                      f"{summary['locked']} compte(s) non synchronisé(s) ignoré(s)")
            snap_id = db_capture_credit_snapshot(
                'Import instantané mensuel Lightspeed', request.files['file'].filename)
            return jsonify({'ok': True, 'mode': 'snapshot', 'snapshot_id': snap_id, **summary})

        else:
            return jsonify({'ok': False, 'error':
                             "Format de fichier non reconnu. Colonnes attendues : soit « Customer » "
                             "et « Amount » (journal de transactions), soit « First Name » et "
                             "« Debt » / « Credit Limit » (instantané mensuel Lightspeed)."}), 400
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 400


@app.route('/api/credit-snapshots')
def api_list_credit_snapshots():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    return jsonify(db_list_credit_snapshots())


@app.route('/api/credit-snapshots/<int:snapshot_id>/pdf')
def api_credit_snapshot_pdf(snapshot_id):
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    exclude_zero = str(request.args.get('exclude_zero', '')).lower() in ('1', 'true', 'on')
    header, lines = db_get_credit_snapshot(snapshot_id)
    if not header:
        return jsonify({'error': "Instantané introuvable."}), 404
    if exclude_zero:
        lines = [l for l in lines if (l.get('credit_limit') or 0) != 0
                 or (l.get('solde') or 0) != 0 or (l.get('deposit') or 0) != 0]
    dt = header['created_at']
    dt_label = dt[:16].replace('T', ' ')
    subtitle = f"Photo prise le {dt_label}" + (f" — {header['label']}" if header.get('label') else "")
    if exclude_zero:
        subtitle += " (clients à 0$ exclus)"
    pdf_path = generate_credit_accounts_pdf(
        lines, "COMPTES DE CRÉDIT", subtitle,
        f"Comptes_credit_{dt[:10]}_{dt[11:13]}h{dt[14:16]}_{snapshot_id}" + ('_sans0' if exclude_zero else '')
    )
    log_audit('PDF comptes de crédit généré', f"Import #{snapshot_id} du {dt_label}" +
              (" (clients à 0$ exclus)" if exclude_zero else ""))
    return send_file(str(pdf_path), as_attachment=True,
                      download_name=f"Comptes_de_credit_{dt[:10]}_{dt[11:13]}h{dt[14:16]}.pdf")


@app.route('/api/credit-clients/pdf')
def api_credit_clients_pdf():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    exclude_zero = str(request.args.get('exclude_zero', '')).lower() in ('1', 'true', 'on')
    clients = db_list_credit_clients()
    if exclude_zero:
        clients = [c for c in clients if (c.get('credit_limit') or 0) != 0
                   or (c.get('solde') or 0) != 0 or (c.get('deposit') or 0) != 0]
    today_str = datetime.date.today().strftime('%Y-%m-%d')
    subtitle = f"Liste actuelle au {today_str}" + (" (clients à 0$ exclus)" if exclude_zero else "")
    pdf_path = generate_credit_accounts_pdf(
        clients, "COMPTES DE CRÉDIT", subtitle,
        f"Comptes_credit_actuel_{today_str}" + ('_sans0' if exclude_zero else '')
    )
    log_audit('PDF comptes de crédit généré', "Liste actuelle" + (" (clients à 0$ exclus)" if exclude_zero else ""))
    return send_file(str(pdf_path), as_attachment=True,
                      download_name=f"Comptes_de_credit_actuel_{today_str}.pdf")


@app.route('/api/credit-backups')
def api_list_credit_backups():
    resp = permission_required_check('credit_accounts')
    if resp is not None:
        return resp
    return jsonify({'backups': db_list_credit_backups(), 'can_restore': bool(session.get('is_admin')),
                    'folder': str(CREDIT_BACKUP_DIR), 'keep': CREDIT_BACKUP_KEEP})


@app.route('/api/credit-backups/<int:backup_id>/restore', methods=['POST'])
def api_restore_credit_backup(backup_id):
    # Remplace toute la liste des comptes de crédit : réservé aux administrateurs.
    resp = admin_required_check()
    if resp is not None:
        return resp
    if not _ls_sync_lock.acquire(blocking=False):
        return jsonify({'ok': False, 'error': "Une synchronisation Lightspeed est en cours. "
                                              "Réessaie quand elle sera terminée."}), 409
    try:
        b, pre_id = db_restore_credit_backup(backup_id, session.get('username'))
    except RuntimeError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': f"Restauration impossible : {e}. Aucune donnée n'a été modifiée."}), 500
    finally:
        _ls_sync_lock.release()
    log_audit('Restauration des comptes de crédit',
              f"Sauvegarde du {b['created_at'][:16]} ({b['label']}) — {b['client_count']} compte(s), "
              f"{b['movement_count']} mouvement(s). L'état précédent a été sauvegardé (#{pre_id}).")
    return jsonify({'ok': True, 'client_count': b['client_count'], 'pre_backup_id': pre_id})
