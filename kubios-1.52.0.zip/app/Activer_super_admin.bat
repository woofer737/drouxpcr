@echo off
chcp 65001 > nul
setlocal EnableDelayedExpansion
cd /d "%~dp0"
echo.
echo   Kubios - Super administrateur (fournisseur)
echo   -------------------------------------------
echo   A lancer seulement sur l'ordinateur serveur de Kubios.
echo   Le compte doit deja exister dans Kubios (Gestion - Utilisateurs).
echo.

set "PY="
rem 1) environnement virtuel de Kubios
if exist ".venv\Scripts\python.exe" call :essayer ".venv\Scripts\python.exe"

rem 2) le Python du service Windows de Kubios
if not defined PY (
  for /f "tokens=1,* delims=:" %%a in ('sc qc ComptesARecevoirOE 2^>nul ^| findstr /i "BINARY_PATH_NAME"') do set "SVC=%%b"
  if defined SVC (
    set "SVC=!SVC:~1!"
    set "SVC=!SVC:"=!"
    for %%f in ("!SVC!") do set "SVCDIR=%%~dpf"
    if exist "!SVCDIR!python.exe" call :essayer "!SVCDIR!python.exe"
    if not defined PY if exist "!SVCDIR!..\..\..\python.exe" call :essayer "!SVCDIR!..\..\..\python.exe"
  )
)

rem 3) le lanceur py, puis python
if not defined PY call :essayer "py" "-3"
if not defined PY call :essayer "python"

if not defined PY (
  echo   Aucun Python capable de lancer Kubios n'a ete trouve.
  echo   Tapez :  sc qc ComptesARecevoirOE   et lancez le python.exe du dossier indique
  echo   avec :   kubios_sante.py --promouvoir NOM_UTILISATEUR
  goto fin
)
echo   Python utilise : !PY! !PYARG!
echo.
set /p KUSER=Nom d'utilisateur a promouvoir : 
if "!KUSER!"=="" goto fin
!PY! !PYARG! kubios_sante.py --promouvoir "!KUSER!"
goto fin

:essayer
rem %1 = programme, %2 = argument facultatif ; on garde ce Python seulement s'il peut charger Kubios (Flask)
"%~1" %~2 -c "import flask" >nul 2>nul
if !errorlevel! equ 0 (
  set PY="%~1"
  set "PYARG=%~2"
)
exit /b

:fin
echo.
pause
endlocal
