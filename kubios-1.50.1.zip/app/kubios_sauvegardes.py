# -*- coding: utf-8 -*-
"""Pages des sauvegardes complètes.
Module de Kubios (découpé de app.py en 1.49.0, code inchangé)."""
import os
import re
import io
import csv
import sys
import json
import base64
import hashlib
import unicodedata
import time
import shutil
import secrets
import sqlite3
import zipfile
import threading
import subprocess
import datetime
import traceback
import urllib.request
import urllib.error
import urllib.parse
import email.utils
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_file, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import openpyxl
from openpyxl.utils import get_column_letter
import licensing
import tempfile
from kubios_base import DB_PATH, db_add_audit, get_company_name, get_conn, get_settings, meta_get, meta_set
from kubios_mail import send_email
from kubios_pdf import LOGO_PATH
from kubios_version import APP_VERSION
from kubios_app import BASE_DIR, app
from kubios_auth import admin_required_check, log_audit
from kubios_systeme import LOGIN_BG_CUSTOM_PREFIX, LOGIN_VIDEO_PREFIX, LOGO_DEFAULT_BACKUP_PATH, _EMAIL_OK
from kubios_rh_outils import HR_CRITERIA, HR_DIR
from kubios_lightspeed import _ls_ref_cache, _ls_token_cache, _store_lock
from kubios_comptes import EXCEL_PATH, _ls_ar_lock, _ls_ar_state, _sync_lock
from kubios_credit import _ls_sync_lock
from kubios_rapports import _rep_state, meta_delete

__all__ = ['_migrate_company_defaults', 'FB_DEFAULT_DIR', 'FB_KIND_LABELS', 'FB_LS_KEEP', 'FB_NAME_RE', 'FB_RETENTIONS', '_fb_do_backup', '_fb_lock', '_fb_path', '_fb_restore_response', '_fb_state', '_fb_static_files', '_send_plain_email', 'api_full_backups', 'api_full_backups_download', 'api_full_backups_notify_test', 'api_full_backups_restore', 'api_full_backups_restore_upload', 'api_full_backups_run', 'api_full_backups_settings', 'fb_cfg', 'fb_dir', 'fb_list', 'fb_notify', 'fb_prune', 'fb_read_manifest', 'full_backup', 'full_backups_page', 'full_restore', 'init_db_schema']


def _migrate_company_defaults(conn):
    """1.50.1 : les valeurs par défaut du nom et du courriel de l'entreprise deviennent neutres. Une installation
    existante (qui a déjà des comptes) et qui n'avait jamais saisi ces réglages garde les valeurs qu'elle utilisait."""
    try:
        if conn.execute("SELECT 1 FROM meta WHERE key='company_defaults_v1'").fetchone():
            return
        existing = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] > 0
        if existing:
            legacy = {'company_name': 'Outillages Express', 'company_email': 'recevables@outillagesexpress.ca'}
            for key, val in legacy.items():
                row = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
                if not row or not (row[0] or '').strip():
                    conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES (?, ?)", (key, val))
        conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES ('company_defaults_v1', ?)", ('existante' if existing else 'nouvelle',))
        conn.commit()
    except Exception:
        traceback.print_exc()


def init_db_schema():
    conn = get_conn()
    conn.execute("PRAGMA journal_mode=WAL")  # meilleure gestion des accès concurrents (plusieurs postes)
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS clients (
        name TEXT PRIMARY KEY,
        sheet_name TEXT UNIQUE,
        phone TEXT, adresse TEXT, ville TEXT, province TEXT,
        code_postal TEXT, courriel TEXT
    );
    CREATE TABLE IF NOT EXISTS invoices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        client_name TEXT NOT NULL REFERENCES clients(name),
        numero TEXT, date_facture TEXT, echeance TEXT,
        montant REAL, notes TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_invoices_client ON invoices(client_name);
    CREATE TABLE IF NOT EXISTS log_envois (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT, client TEXT, courriel TEXT, total REAL, statut TEXT, note TEXT,
        synced INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS meta (
        key TEXT PRIMARY KEY, value TEXT
    );
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        is_admin INTEGER NOT NULL DEFAULT 0,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT,
        permissions TEXT NOT NULL DEFAULT '[]'
    );
    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT, username TEXT, action TEXT, details TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(id DESC);
    CREATE TABLE IF NOT EXISTS credit_clients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        prenom_entreprise TEXT NOT NULL,
        nom TEXT,
        credit_limit REAL NOT NULL DEFAULT 0,
        solde REAL NOT NULL DEFAULT 0,
        deposit REAL NOT NULL DEFAULT 0,
        ligne_source TEXT,
        notes TEXT,
        created_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_credit_clients_nom ON credit_clients(prenom_entreprise, nom);
    CREATE TABLE IF NOT EXISTS credit_movements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        credit_client_id INTEGER NOT NULL REFERENCES credit_clients(id),
        lightspeed_id TEXT,
        date_mouvement TEXT,
        montant REAL NOT NULL DEFAULT 0,
        type TEXT,
        sale TEXT,
        customer_brut TEXT,
        notes TEXT,
        imported_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_credit_movements_client ON credit_movements(credit_client_id);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_credit_movements_lsid
        ON credit_movements(lightspeed_id) WHERE lightspeed_id IS NOT NULL;

    CREATE TABLE IF NOT EXISTS credit_snapshots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        label TEXT,
        source TEXT,
        client_count INTEGER NOT NULL DEFAULT 0,
        total_credit_limit REAL NOT NULL DEFAULT 0,
        total_solde REAL NOT NULL DEFAULT 0,
        total_deposit REAL NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS credit_snapshot_lines (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        snapshot_id INTEGER NOT NULL REFERENCES credit_snapshots(id),
        prenom_entreprise TEXT NOT NULL,
        nom TEXT,
        credit_limit REAL NOT NULL DEFAULT 0,
        solde REAL NOT NULL DEFAULT 0,
        deposit REAL NOT NULL DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_credit_snapshot_lines_snap ON credit_snapshot_lines(snapshot_id);
    """)
    conn.commit()
    # migration : ajoute la colonne montant_paye si elle n'existe pas encore
    # (sur une base créée avant l'ajout du suivi des paiements partiels)
    cols = [r['name'] for r in conn.execute("PRAGMA table_info(invoices)").fetchall()]
    if 'montant_paye' not in cols:
        conn.execute("ALTER TABLE invoices ADD COLUMN montant_paye REAL NOT NULL DEFAULT 0")
        conn.commit()
        cols.append('montant_paye')
    # migration : ajoute la colonne date_paiement si elle n'existe pas encore (sur
    # une base créée avant le suivi des dates de paiement). Sans cette date, un
    # rapport d'âge pour un mois passé ne peut pas savoir si un paiement avait
    # déjà été reçu à cette date-là ou non.
    if 'date_paiement' not in cols:
        conn.execute("ALTER TABLE invoices ADD COLUMN date_paiement TEXT")
        conn.commit()
        # Les paiements déjà saisis avant cette mise à jour n'ont pas de date
        # exacte connue. Par choix du client : on les considère reçus AUJOURD'HUI plutôt que "depuis
        # toujours" — un rapport d'âge pour un mois antérieur à aujourd'hui les
        # affichera donc comme non réglés à cette date passée (plus prudent
        # pour le suivi des comptes à recevoir que de les supposer déjà payés).
        today_str = datetime.date.today().strftime('%Y-%m-%d')
        conn.execute(
            "UPDATE invoices SET date_paiement=? "
            "WHERE montant_paye > 0 AND (date_paiement IS NULL OR date_paiement='')",
            (today_str,)
        )
        conn.commit()
    # migration : ajoute la colonne permissions si elle n'existe pas encore (sur
    # une base créée avant l'ajout des accès granulaires). Les comptes non-admin
    # déjà existants gardent l'accès aux rapports (comportement identique à
    # avant cette fonctionnalité) — les autres permissions doivent être
    # accordées explicitement depuis "Utilisateurs".
    user_cols = [r['name'] for r in conn.execute("PRAGMA table_info(users)").fetchall()]
    if 'permissions' not in user_cols:
        conn.execute("ALTER TABLE users ADD COLUMN permissions TEXT NOT NULL DEFAULT '[]'")
        conn.execute("UPDATE users SET permissions='[\"reports\"]' WHERE is_admin=0")
        conn.commit()
    # migration : case « ne pas synchroniser avec l'importation » sur les comptes de crédit
    cc_cols = [r['name'] for r in conn.execute("PRAGMA table_info(credit_clients)").fetchall()]
    if cc_cols and 'no_sync' not in cc_cols:
        conn.execute("ALTER TABLE credit_clients ADD COLUMN no_sync INTEGER NOT NULL DEFAULT 0")
        conn.commit()
    # migration 1.10.0 : lien avec l'API Lightspeed (identifiant du compte de
    # crédit et du client Lightspeed) + comptes Lightspeed en attente
    # d'association manuelle (homonymes).
    if cc_cols and 'ls_credit_account_id' not in cc_cols:
        conn.execute("ALTER TABLE credit_clients ADD COLUMN ls_credit_account_id TEXT")
        conn.execute("ALTER TABLE credit_clients ADD COLUMN ls_customer_id TEXT")
        conn.commit()
    conn.executescript("""
    CREATE UNIQUE INDEX IF NOT EXISTS idx_credit_clients_lsid
        ON credit_clients(ls_credit_account_id) WHERE ls_credit_account_id IS NOT NULL;
    CREATE TABLE IF NOT EXISTS credit_backups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        label TEXT,
        username TEXT,
        filename TEXT NOT NULL,
        client_count INTEGER NOT NULL DEFAULT 0,
        movement_count INTEGER NOT NULL DEFAULT 0,
        total_solde REAL NOT NULL DEFAULT 0,
        total_deposit REAL NOT NULL DEFAULT 0,
        restored_at TEXT,
        restored_by TEXT
    );
    CREATE TABLE IF NOT EXISTS ls_ar_customers (
        ls_customer_id TEXT PRIMARY KEY,
        client_name TEXT NOT NULL,
        linked_at TEXT
    );
    CREATE TABLE IF NOT EXISTS sales_payments (
        payment_id TEXT PRIMARY KEY, sale_id TEXT, sale_date TEXT, shop_id TEXT, type_id TEXT, name TEXT, ptype TEXT, amount REAL
    );
    CREATE INDEX IF NOT EXISTS idx_pay_date ON sales_payments(sale_date);
    CREATE TABLE IF NOT EXISTS shop_mechanics (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, pin_hash TEXT, cost_rate REAL,
        active INTEGER NOT NULL DEFAULT 1, color TEXT, created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS shop_punches (
        id INTEGER PRIMARY KEY AUTOINCREMENT, mechanic_id INTEGER NOT NULL, job TEXT NOT NULL,
        start_at TEXT NOT NULL, end_at TEXT, ended_by TEXT, created_by TEXT, corrected_by TEXT, corrected_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_punch_job ON shop_punches(job);
    CREATE INDEX IF NOT EXISTS idx_punch_mech ON shop_punches(mechanic_id, start_at);
    CREATE TABLE IF NOT EXISTS shop_jobs (
        job TEXT PRIMARY KEY, client TEXT, item TEXT, work TEXT, mechanic_id INTEGER, due_date TEXT,
        status TEXT NOT NULL DEFAULT 'ouvert', created_by TEXT, created_at TEXT, updated_at TEXT,
        priority TEXT NOT NULL DEFAULT 'normal', notes TEXT, position INTEGER NOT NULL DEFAULT 0, work_date TEXT
    );
    CREATE TABLE IF NOT EXISTS hr_employees (
        id INTEGER PRIMARY KEY AUTOINCREMENT, first_name TEXT, last_name TEXT, position TEXT, department TEXT, hire_date TEXT,
        status TEXT NOT NULL DEFAULT 'actif', probation_end TEXT, end_date TEXT, next_review TEXT, email TEXT, phone TEXT, address TEXT,
        emergency_name TEXT, emergency_phone TEXT, username TEXT, mechanic_id INTEGER, notes TEXT, created_at TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS hr_documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL, category TEXT, title TEXT, filename TEXT, original_name TEXT,
        size INTEGER, expires_on TEXT, created_at TEXT, created_by TEXT
    );
    CREATE TABLE IF NOT EXISTS hr_evaluations (
        id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL, period_start TEXT, period_end TEXT, eval_date TEXT, evaluator TEXT,
        scores TEXT, overall REAL, strengths TEXT, improvements TEXT, objectives TEXT, employee_comments TEXT, status TEXT NOT NULL DEFAULT 'brouillon',
        atelier_stats TEXT, created_at TEXT, updated_at TEXT, criteria TEXT
    );
    CREATE TABLE IF NOT EXISTS hr_notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL, kind TEXT, note_date TEXT, text TEXT, created_by TEXT, created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS hr_portal (
        employee_id INTEGER PRIMARY KEY, login TEXT UNIQUE, password_hash TEXT, active INTEGER NOT NULL DEFAULT 1,
        token TEXT, token_expires TEXT, invited_at TEXT, last_login TEXT, created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS tc_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL, ts TEXT NOT NULL, kind TEXT NOT NULL, station TEXT,
        created_by TEXT, note TEXT, deleted INTEGER NOT NULL DEFAULT 0, corrected_by TEXT, corrected_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_tc_emp_ts ON tc_events(employee_id, ts);
    CREATE TABLE IF NOT EXISTS email_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, method TEXT, sender TEXT, recipient TEXT, subject TEXT, category TEXT,
        attachment TEXT, mode TEXT, status TEXT, error TEXT, username TEXT, summary TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_email_log_ts ON email_log(ts);
    CREATE TABLE IF NOT EXISTS leave_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL, start TEXT NOT NULL, end TEXT NOT NULL, kind TEXT NOT NULL,
        note TEXT, status TEXT NOT NULL DEFAULT 'en_attente', manager_comment TEXT, decided_by TEXT, decided_at TEXT, created_at TEXT, cancelled_at TEXT
    );
    CREATE TABLE IF NOT EXISTS user_sessions (
        sid TEXT PRIMARY KEY, kind TEXT NOT NULL, user_id INTEGER, username TEXT, display TEXT, ip TEXT, agent TEXT,
        created_at TEXT, last_seen TEXT, revoked_at TEXT, revoked_by TEXT
    );
    CREATE TABLE IF NOT EXISTS sched_shifts (
        employee_id INTEGER NOT NULL, day TEXT NOT NULL, kind TEXT NOT NULL, start TEXT, end TEXT, meal TEXT, note TEXT,
        updated_at TEXT, updated_by TEXT, PRIMARY KEY(employee_id, day)
    );
    CREATE TABLE IF NOT EXISTS sched_published (
        employee_id INTEGER NOT NULL, day TEXT NOT NULL, kind TEXT NOT NULL, start TEXT, end TEXT, meal TEXT, note TEXT,
        updated_at TEXT, updated_by TEXT, PRIMARY KEY(employee_id, day)
    );
    CREATE TABLE IF NOT EXISTS sched_notices (
        id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL, created_at TEXT, text TEXT, seen_at TEXT
    );
    CREATE TABLE IF NOT EXISTS tc_approvals (
        employee_id INTEGER NOT NULL, period_start TEXT NOT NULL, approved_by TEXT, approved_at TEXT, PRIMARY KEY(employee_id, period_start)
    );
    CREATE TABLE IF NOT EXISTS hr_access_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, username TEXT, employee_id INTEGER, action TEXT, ip TEXT
    );
    CREATE TABLE IF NOT EXISTS shop_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, mechanic_id INTEGER NOT NULL, job TEXT,
        kind TEXT NOT NULL DEFAULT 'message', category TEXT, text TEXT, from_side TEXT NOT NULL, username TEXT,
        read_at TEXT, resolved_at TEXT, resolved_by TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_msg_mech ON shop_messages(mechanic_id, id);
    CREATE TABLE IF NOT EXISTS shop_sale_links (
        sale_line_id TEXT PRIMARY KEY, job TEXT, ignored INTEGER NOT NULL DEFAULT 0, username TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS shop_billing (
        job TEXT PRIMARY KEY, billed_minutes REAL, billed_amount REAL, note TEXT, username TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS inventory_snapshots (
        id INTEGER PRIMARY KEY AUTOINCREMENT, taken_at TEXT, kind TEXT, shop_id TEXT, shop_name TEXT, method TEXT,
        items INTEGER, units REAL, cost_value REAL, retail_value REAL, negative_items INTEGER, username TEXT
    );
    CREATE TABLE IF NOT EXISTS inventory_snapshot_lines (
        snapshot_id INTEGER NOT NULL, category TEXT, items INTEGER, units REAL, cost_value REAL, retail_value REAL
    );
    CREATE INDEX IF NOT EXISTS idx_inv_lines ON inventory_snapshot_lines(snapshot_id);
    CREATE TABLE IF NOT EXISTS announcements (
        id INTEGER PRIMARY KEY AUTOINCREMENT, message TEXT NOT NULL, color TEXT NOT NULL DEFAULT 'yellow',
        start_date TEXT, end_date TEXT, active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT, created_by TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS password_resets (
        token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL, created_at REAL, expires_at REAL,
        used_at REAL, ip TEXT
    );
    CREATE TABLE IF NOT EXISTS mfa_challenges (
        user_id INTEGER PRIMARY KEY, code_hash TEXT, expires_at REAL NOT NULL DEFAULT 0,
        attempts INTEGER NOT NULL DEFAULT 0, locked_until REAL NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS sales_lines (
        sale_line_id TEXT PRIMARY KEY,
        sale_id TEXT, sale_date TEXT, shop_id TEXT, item_id TEXT, category_id TEXT,
        qty REAL, subtotal REAL, discount REAL, total REAL, cost REAL
    );
    CREATE INDEX IF NOT EXISTS idx_sales_lines_date ON sales_lines(sale_date);
    CREATE TABLE IF NOT EXISTS sales_days (
        day TEXT PRIMARY KEY, sales_count INTEGER NOT NULL DEFAULT 0,
        complete INTEGER NOT NULL DEFAULT 0, fetched_at TEXT
    );
    CREATE TABLE IF NOT EXISTS ls_categories (category_id TEXT PRIMARY KEY, name TEXT, path TEXT, updated_at TEXT);
    CREATE TABLE IF NOT EXISTS ls_shops (shop_id TEXT PRIMARY KEY, name TEXT, archived INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS ls_tax_classes (tax_class_id TEXT PRIMARY KEY, name TEXT);
    CREATE TABLE IF NOT EXISTS ls_tax_category_classes (
        tax_category_id TEXT NOT NULL, tax_class_id TEXT NOT NULL,
        tax1_rate REAL NOT NULL DEFAULT 0, tax2_rate REAL NOT NULL DEFAULT 0,
        PRIMARY KEY (tax_category_id, tax_class_id)
    );
    CREATE TABLE IF NOT EXISTS ls_tax_categories (
        tax_category_id TEXT PRIMARY KEY, name TEXT, tax1_name TEXT, tax2_name TEXT,
        tax1_rate REAL NOT NULL DEFAULT 0, tax2_rate REAL NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS report_sends (
        id INTEGER PRIMARY KEY AUTOINCREMENT, sent_at TEXT, kind TEXT, period TEXT,
        recipients TEXT, status TEXT, error TEXT, username TEXT
    );
    CREATE TABLE IF NOT EXISTS ls_ar_aliases (
        alias TEXT PRIMARY KEY,          -- nom normalisé (_norm_credit_name)
        display TEXT,                    -- nom tel qu'il était écrit
        client_name TEXT NOT NULL,
        created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS ls_ar_payments (
        sale_id TEXT PRIMARY KEY,
        client_name TEXT,
        payment_date TEXT,
        montant REAL NOT NULL DEFAULT 0,
        status TEXT NOT NULL,
        details TEXT,
        processed_at TEXT,
        username TEXT
    );
    CREATE TABLE IF NOT EXISTS ls_ar_ignored (
        sale_id TEXT PRIMARY KEY,
        ignored_at TEXT,
        username TEXT,
        info TEXT
    );
    CREATE TABLE IF NOT EXISTS ls_pending_accounts (
        ls_credit_account_id TEXT PRIMARY KEY,
        ls_customer_id TEXT,
        prenom_entreprise TEXT,
        nom TEXT,
        credit_limit REAL NOT NULL DEFAULT 0,
        debt REAL NOT NULL DEFAULT 0,
        seen_at TEXT
    );
    """)
    conn.commit()
    # 1.17.0 : taxes gardées avec chaque ligne de vente (rapport des taxes)
    sl_cols = [r[1] for r in conn.execute("PRAGMA table_info(sales_lines)").fetchall()]
    for col, ddl in (('tax1', 'REAL NOT NULL DEFAULT 0'), ('tax2', 'REAL NOT NULL DEFAULT 0'),
                     ('tax1_rate', 'REAL'), ('tax2_rate', 'REAL'), ('taxable', 'INTEGER'), ('tax_cat', 'TEXT'),
                     ('tax_class', 'TEXT'), ('is_fee', 'INTEGER NOT NULL DEFAULT 0'), ('fee_name', 'TEXT'),
                     ('descr', 'TEXT'), ('job_ref', 'TEXT'), ('svc_minutes', 'REAL')):
        if sl_cols and col not in sl_cols:
            conn.execute(f"ALTER TABLE sales_lines ADD COLUMN {col} {ddl}")
    sd_cols = [r[1] for r in conn.execute("PRAGMA table_info(sales_days)").fetchall()]
    if sd_cols and 'tax_ok' not in sd_cols:
        conn.execute("ALTER TABLE sales_days ADD COLUMN tax_ok INTEGER NOT NULL DEFAULT 0")
    if sd_cols and 'ws_ok' not in sd_cols:       # 1.21.0 : numéros de bon HubTiger lus
        conn.execute("ALTER TABLE sales_days ADD COLUMN ws_ok INTEGER NOT NULL DEFAULT 0")
    for tbl, cols in (('hr_employees', (('tc_enabled', 'INTEGER NOT NULL DEFAULT 0'), ('tc_pin_hash', 'TEXT'))),
                      ('hr_documents', (('published', 'INTEGER NOT NULL DEFAULT 0'), ('published_at', 'TEXT'), ('sign_required', 'INTEGER NOT NULL DEFAULT 0'),
                                        ('mgr_sig', 'TEXT'), ('mgr_signed_at', 'TEXT'), ('mgr_signed_by', 'TEXT'), ('emp_sig', 'TEXT'), ('emp_signed_at', 'TEXT'),
                                        ('emp_comment', 'TEXT'), ('emp_sign_ip', 'TEXT'), ('doc_hash', 'TEXT'), ('signed_filename', 'TEXT'),
                                        ('viewed_at', 'TEXT'), ('emailed_at', 'TEXT')))):          # 1.39.0
        have = {r[1] for r in conn.execute(f"PRAGMA table_info({tbl})").fetchall()}
        for col, typ in cols:
            if have and col not in have:
                conn.execute(f"ALTER TABLE {tbl} ADD COLUMN {col} {typ}")
    he_cols = {r[1] for r in conn.execute("PRAGMA table_info(hr_evaluations)").fetchall()}
    if he_cols and 'criteria' not in he_cols:    # 1.31.0 : critères gardés avec chaque évaluation
        conn.execute("ALTER TABLE hr_evaluations ADD COLUMN criteria TEXT")
        conn.execute("UPDATE hr_evaluations SET criteria=? WHERE criteria IS NULL",      # évaluations de la 1.30 : critères d'origine
                     (json.dumps([{'key': k_, 'label': l_, 'hint': h_} for k_, l_, h_ in HR_CRITERIA], ensure_ascii=False),))
    sj_cols = {r[1] for r in conn.execute("PRAGMA table_info(shop_jobs)").fetchall()}
    for col, typ in (('priority', "TEXT NOT NULL DEFAULT 'normal'"), ('notes', 'TEXT'), ('position', 'INTEGER NOT NULL DEFAULT 0'), ('work_date', 'TEXT')):
        if sj_cols and col not in sj_cols:       # 1.25.0 : planification des bons
            conn.execute(f"ALTER TABLE shop_jobs ADD COLUMN {col} {typ}")
    if sd_cols and 'pay_ok' not in sd_cols:      # 1.23.0 : paiements gardés avec les ventes
        conn.execute("ALTER TABLE sales_days ADD COLUMN pay_ok INTEGER NOT NULL DEFAULT 0")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_sales_job ON sales_lines(job_ref)")
    conn.commit()
    # 1.23.0 : nouvelle permission « Comptes à recevoir » — accordée une fois aux utilisateurs
    # existants (non administrateurs), qui y avaient accès sans permission jusqu'ici.
    if not conn.execute("SELECT 1 FROM meta WHERE key='perm_ar_migrated'").fetchone():
        for u in conn.execute("SELECT id, permissions FROM users WHERE is_admin=0").fetchall():
            try:
                perms = json.loads(u['permissions'] or '[]')
            except ValueError:
                perms = []
            if 'comptes_recevoir' not in perms:
                conn.execute("UPDATE users SET permissions=? WHERE id=?", (json.dumps(perms + ['comptes_recevoir']), u['id']))
        conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES ('perm_ar_migrated', '1')")
        conn.commit()
    # 1.14.0 : courriel et double authentification des utilisateurs
    u_cols = [r[1] for r in conn.execute("PRAGMA table_info(users)").fetchall()]
    for col, ddl in (('email', 'TEXT'), ('full_name', 'TEXT'), ('mfa_required', 'INTEGER NOT NULL DEFAULT 0'), ('mfa_method', 'TEXT'),
                     ('mfa_secret', 'TEXT'), ('mfa_last_step', 'INTEGER NOT NULL DEFAULT 0'),
                     ('mfa_pending_secret', 'TEXT')):
        if u_cols and col not in u_cols:
            conn.execute(f"ALTER TABLE users ADD COLUMN {col} {ddl}")
    conn.commit()
    # 1.11.3 : nom du client Lightspeed gardé avec le lien (affiché dans la fiche)
    lc_cols = [r[1] for r in conn.execute("PRAGMA table_info(ls_ar_customers)").fetchall()]
    if 'ls_name' not in lc_cols:
        conn.execute("ALTER TABLE ls_ar_customers ADD COLUMN ls_name TEXT")
        conn.commit()
    # 1.11.0 : sauvegardes des comptes à recevoir dans la même table
    bk_cols = [r[1] for r in conn.execute("PRAGMA table_info(credit_backups)").fetchall()]
    if 'scope' not in bk_cols:
        conn.execute("ALTER TABLE credit_backups ADD COLUMN scope TEXT NOT NULL DEFAULT 'credit'")
        conn.commit()
    _migrate_company_defaults(conn)
    conn.close()


def _send_plain_email(to_email, subject, body):
    """Courriel sans pièce jointe ni copie à l'entreprise (codes, liens)."""
    com = False
    if get_settings()['send_mode'] != 'smtp':
        try:
            import pythoncom
            pythoncom.CoInitialize()
            com = True
        except Exception:
            pass
    try:
        send_email(to_email, subject, body, None, mode='send', bcc_company=False)
    finally:
        if com:
            try:
                import pythoncom
                pythoncom.CoUninitialize()
            except Exception:
                pass


FB_DEFAULT_DIR = BASE_DIR / "Sauvegardes_completes"


FB_RETENTIONS = (7, 14, 30)


FB_NAME_RE = re.compile(r'^kubios_[0-9A-Za-z_\-]+\.zip$')


FB_KIND_LABELS = {'auto': 'Automatique', 'manuelle': 'Manuelle', 'avant_restauration': 'Avant restauration'}


FB_LS_KEEP = ('ls_client_id', 'ls_client_secret', 'ls_redirect_uri', 'ls_refresh_token', 'ls_account_id',
              'ls_account_name')


_fb_lock = threading.Lock()


_fb_state = {'running': False, 'progress': '', 'error': None}


def fb_cfg():
    try:
        hour = min(max(int(meta_get('fb_hour') or 2), 0), 23)
    except ValueError:
        hour = 2
    try:
        ret = int(meta_get('fb_retention') or 30)
    except ValueError:
        ret = 30
    mode = meta_get('fb_notify_mode') or 'fail'
    return {'enabled': meta_get('fb_enabled') != '0', 'hour': hour,
            'retention': ret if ret in FB_RETENTIONS else 30,
            'dir': (meta_get('fb_dir') or '').strip() or str(FB_DEFAULT_DIR),
            'notify_emails': [e for e in (meta_get('fb_notify_emails') or '').split(',') if e.strip()],
            'notify_mode': mode if mode in ('all', 'fail') else 'fail'}


def fb_notify(ok, info=None, error=None, test=False):
    """Avise par courriel du résultat d'une sauvegarde automatique.
    Retourne (envoyés, erreurs)."""
    cfg = fb_cfg()
    emails = cfg['notify_emails']
    if not emails or (ok and cfg['notify_mode'] != 'all' and not test):
        return [], []
    now = datetime.datetime.now()
    when = now.strftime('%d-%m-%Y à %H:%M')
    company = get_company_name()
    if test:
        subject = f"[Test] Kubios — avis de sauvegarde ({company})"
        body = (f"Bonjour,\n\nCeci est un courriel de test envoyé le {when}.\n\nVous recevrez un avis "
                + ("après chaque sauvegarde automatique (réussie ou en échec)." if cfg['notify_mode'] == 'all'
                   else "seulement si une sauvegarde automatique échoue.")
                + f"\n\nSauvegarde automatique : {'activée' if cfg['enabled'] else 'DÉSACTIVÉE'}, chaque jour à {cfg['hour']} h."
                  f"\nDossier : {cfg['dir']}\n\n{company} — Kubios")
    elif ok:
        try:
            n = len(list(fb_dir().glob('kubios_*.zip')))
        except OSError:
            n = '?'
        subject = f"[Réussie] Kubios — sauvegarde du {now.strftime('%d-%m-%Y')} ({company})"
        body = (f"Bonjour,\n\nLa sauvegarde automatique de Kubios a réussi le {when}.\n\n"
                f"Fichier : {info['name']}\nTaille : {max(1, info['size'] // 1024):,} Ko\n".replace(',', ' ')
                + f"Dossier : {cfg['dir']}\nSauvegardes conservées : {n} (rétention de {cfg['retention']} jours)\n\n"
                  f"Aucune action n'est requise.\n\n{company} — Kubios")
    else:
        subject = f"[ÉCHEC] Kubios — la sauvegarde du {now.strftime('%d-%m-%Y')} a échoué ({company})"
        body = (f"Bonjour,\n\nLa sauvegarde automatique de Kubios a ÉCHOUÉ le {when}.\n\n"
                f"Raison : {error}\n\nÀ vérifier :\n"
                f"- le dossier de destination est accessible ({cfg['dir']}) : disque externe branché, dossier réseau disponible ;\n"
                f"- il reste de l'espace sur ce disque ;\n"
                f"- puis, dans Kubios → Sauvegardes, cliquez sur « Faire une sauvegarde maintenant ».\n\n"
                f"Tant que ce problème n'est pas réglé, les données ne sont pas sauvegardées.\n\n{company} — Kubios")
    sent, errors = [], []
    for e in emails:
        try:
            _send_plain_email(e.strip(), subject, body)
            sent.append(e.strip())
        except Exception as ex:
            errors.append(f"{e.strip()} : {ex}")
    if errors:
        meta_set('fb_notify_error', f"{now.strftime('%Y-%m-%d %H:%M')} — " + "; ".join(errors))
    else:
        meta_delete('fb_notify_error')
    if not test:
        db_add_audit('Sauvegarde automatique', 'Avis de sauvegarde envoyé' if sent else 'Avis de sauvegarde non envoyé',
                     ('réussite' if ok else 'échec') + f" → {', '.join(sent) or 'aucun'}"
                     + (f" ; erreurs : {'; '.join(errors)}" if errors else ""))
    return sent, errors


def fb_dir():
    d = Path(fb_cfg()['dir'])
    try:
        d.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise RuntimeError(f"le dossier de destination est inaccessible ({d}) : {e.strerror or e}. "
                           "Vérifie que le disque externe est branché ou que le dossier réseau est disponible.")
    return d


def _fb_static_files():
    st = LOGO_PATH.parent
    out = [p for p in (LOGO_PATH, LOGO_DEFAULT_BACKUP_PATH) if p.exists()]
    out += sorted(st.glob(LOGIN_BG_CUSTOM_PREFIX + '.*')) + sorted(st.glob(LOGIN_VIDEO_PREFIX + '.*'))
    return out


def _fb_do_backup(kind, username):
    """Crée l'archive (sans prendre _fb_lock : l'appelant le tient)."""
    d = fb_dir()
    now = datetime.datetime.now()
    name = f"kubios_{now.strftime('%Y-%m-%d_%Hh%M%S')}_{kind}.zip"
    final = d / name
    tmp_zip = d / (name + '.partiel')
    tmp_db = Path(tempfile.mkstemp(suffix='.db', prefix='kubios_')[1])
    try:
        _fb_state['progress'] = "Copie de la base de données…"
        src = sqlite3.connect(str(DB_PATH), timeout=60)
        dst = sqlite3.connect(str(tmp_db))
        try:
            src.backup(dst)
            ok = dst.execute("PRAGMA integrity_check").fetchone()[0]
        finally:
            dst.close()
            src.close()
        if ok != 'ok':
            raise RuntimeError(f"La base de données copiée est endommagée ({ok}).")
        files = {}
        _fb_state['progress'] = "Création de l'archive…"
        with zipfile.ZipFile(tmp_zip, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            z.write(tmp_db, 'data.db')
            files['data.db'] = tmp_db.stat().st_size
            if EXCEL_PATH.exists():
                got = _sync_lock.acquire(timeout=180)   # pas pendant une écriture du classeur
                try:
                    z.write(EXCEL_PATH, 'excel/' + EXCEL_PATH.name)
                    files['excel/' + EXCEL_PATH.name] = EXCEL_PATH.stat().st_size
                finally:
                    if got:
                        _sync_lock.release()
            for p in _fb_static_files():
                z.write(p, 'static/' + p.name)
                files['static/' + p.name] = p.stat().st_size
            if HR_DIR.exists():                       # 1.30.0 : documents des dossiers RH
                for p in sorted(HR_DIR.rglob('*')):
                    if p.is_file() and not p.name.startswith('_apercu'):
                        arc = 'rh/' + p.relative_to(HR_DIR).as_posix()
                        z.write(p, arc)
                        files[arc] = p.stat().st_size
            manifest = {'application': 'Kubios', 'version': APP_VERSION, 'created_at': now.strftime('%Y-%m-%d %H:%M:%S'),
                        'kind': kind, 'by': username or '?', 'company': get_company_name(), 'files': files}
            z.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
        os.replace(tmp_zip, final)
    except Exception:
        try:
            tmp_zip.unlink()
        except OSError:
            pass
        raise
    finally:
        try:
            tmp_db.unlink()
        except OSError:
            pass
    meta_set('fb_last', now.strftime('%Y-%m-%d %H:%M:%S'))
    meta_delete('fb_last_error')
    removed = fb_prune()
    db_add_audit(username or '?', 'Sauvegarde complète créée',
                 f"{name} ({final.stat().st_size // 1024} Ko)" + (f" ; {removed} ancienne(s) supprimée(s)" if removed else ""))
    return {'name': name, 'size': final.stat().st_size}


def fb_prune():
    """Supprime les sauvegardes plus vieilles que la rétention (garde toujours la plus récente)."""
    ret = fb_cfg()['retention']
    limit = time.time() - ret * 86400
    zips = sorted(fb_dir().glob('kubios_*.zip'), key=lambda p: p.stat().st_mtime, reverse=True)
    n = 0
    for p in zips[1:]:
        if p.stat().st_mtime < limit:
            try:
                p.unlink()
                n += 1
            except OSError:
                pass
    for p in fb_dir().glob('kubios_*.zip.partiel'):
        if p.stat().st_mtime < time.time() - 86400:
            try:
                p.unlink()
            except OSError:
                pass
    return n


def full_backup(kind, username):
    if not _fb_lock.acquire(blocking=False):
        raise RuntimeError("Une sauvegarde ou une restauration est déjà en cours.")
    _fb_state.update(running=True, progress="Démarrage…", error=None)
    try:
        return _fb_do_backup(kind, username)
    except Exception as e:
        traceback.print_exc()
        _fb_state['error'] = str(e)
        meta_set('fb_last_error', f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M')} — {e}")
        db_add_audit(username or '?', 'Sauvegarde complète — échec', str(e))
        raise
    finally:
        _fb_state.update(running=False, progress='')
        _fb_lock.release()


def fb_read_manifest(path):
    try:
        with zipfile.ZipFile(path) as z:
            names = set(z.namelist())
            m = json.loads(z.read('manifest.json').decode('utf-8')) if 'manifest.json' in names else {}
            m['has_db'] = 'data.db' in names
            return m
    except (zipfile.BadZipFile, OSError, ValueError, KeyError):
        return None


def fb_list():
    out = []
    for p in sorted(fb_dir().glob('kubios_*.zip'), key=lambda p: p.stat().st_mtime, reverse=True):
        m = fb_read_manifest(p) or {}
        out.append({'name': p.name, 'size': p.stat().st_size, 'created_at': m.get('created_at') or
                    datetime.datetime.fromtimestamp(p.stat().st_mtime).strftime('%Y-%m-%d %H:%M:%S'),
                    'kind': m.get('kind', ''), 'kind_label': FB_KIND_LABELS.get(m.get('kind'), m.get('kind') or '?'),
                    'version': m.get('version', '?'), 'by': m.get('by', ''), 'valid': bool(m.get('has_db')),
                    'excel': any(k.startswith('excel/') for k in (m.get('files') or {}))})
    return out


def full_restore(zip_path, username, source_label):
    """Restaure une archive. Lève RuntimeError (message pour l'utilisateur)."""
    m = fb_read_manifest(zip_path)
    if not m or not m.get('has_db'):
        raise RuntimeError("Ce fichier n'est pas une sauvegarde Kubios valide.")
    if not _fb_lock.acquire(blocking=False):
        raise RuntimeError("Une sauvegarde ou une restauration est déjà en cours.")
    held = []
    try:
        for name, lk in (('une récupération des ventes', _store_lock), ('une synchronisation Lightspeed', _ls_sync_lock),
                         ('une vérification des factures Lightspeed', _ls_ar_lock)):
            if not lk.acquire(blocking=False):
                raise RuntimeError(f"Impossible pour le moment : {name} est en cours. Réessaie dans quelques minutes.")
            held.append(lk)
        _fb_state.update(running=True, progress="Vérification de la sauvegarde…", error=None)
        tmp_dir = Path(tempfile.mkdtemp(prefix='kubios_restore_'))
        try:
            with zipfile.ZipFile(zip_path) as z:
                z.extract('data.db', tmp_dir)
                others = [n for n in z.namelist() if n.startswith(('excel/', 'static/', 'rh/')) and not n.endswith('/')]
                for n in others:
                    z.extract(n, tmp_dir)
            new_db = tmp_dir / 'data.db'
            c = sqlite3.connect(str(new_db))
            try:
                ok = c.execute("PRAGMA integrity_check").fetchone()[0]
                tables = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            finally:
                c.close()
            if ok != 'ok' or not {'users', 'meta'} <= tables:
                raise RuntimeError("La base de données de cette sauvegarde est endommagée ou incomplète : rien n'a été modifié.")
            _fb_state['progress'] = "Sauvegarde de l'état actuel…"
            pre = _fb_do_backup('avant_restauration', username)
            keep_ls = {k: meta_get(k) for k in FB_LS_KEEP} if meta_get('ls_refresh_token') else None
            _fb_state['progress'] = "Restauration…"
            got = _sync_lock.acquire(timeout=180)
            try:
                src = sqlite3.connect(str(new_db))
                dst = sqlite3.connect(str(DB_PATH), timeout=60)
                try:
                    src.backup(dst)
                finally:
                    dst.close()
                    src.close()
                init_db_schema()          # sauvegarde d'une version plus ancienne : mise à niveau
                if keep_ls:
                    for k, v in keep_ls.items():
                        if v is None:
                            meta_delete(k)
                        else:
                            meta_set(k, v)
                for p in (tmp_dir / 'excel').glob('*') if (tmp_dir / 'excel').exists() else []:
                    part = EXCEL_PATH.with_name(EXCEL_PATH.stem + '.restauration.xlsx')
                    shutil.copy2(p, part)
                    os.replace(part, EXCEL_PATH)
                if (tmp_dir / 'rh').exists():
                    shutil.copytree(tmp_dir / 'rh', HR_DIR, dirs_exist_ok=True)
                if (tmp_dir / 'static').exists():
                    for old in list(LOGO_PATH.parent.glob(LOGIN_BG_CUSTOM_PREFIX + '.*')) + list(LOGO_PATH.parent.glob(LOGIN_VIDEO_PREFIX + '.*')):
                        try:
                            old.unlink()
                        except OSError:
                            pass
                    for p in (tmp_dir / 'static').glob('*'):
                        shutil.copy2(p, LOGO_PATH.parent / p.name)
            finally:
                if got:
                    _sync_lock.release()
            _ls_token_cache['access_token'] = None
            _ls_ref_cache.clear()
            for st in (_rep_state, _ls_ar_state):
                for k in ('result', 'comparison', 'preview'):
                    if k in st:
                        st[k] = None
            db_add_audit(username or '?', 'Restauration complète',
                         f"{source_label} (sauvegarde du {m.get('created_at', '?')}, version {m.get('version', '?')}) ; "
                         f"état précédent sauvegardé : {pre['name']}")
            return {'restored_from': m.get('created_at'), 'version': m.get('version'), 'pre_backup': pre['name']}
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)
    except Exception as e:
        if not isinstance(e, RuntimeError):
            traceback.print_exc()
        _fb_state['error'] = str(e)
        raise
    finally:
        for lk in held:
            lk.release()
        _fb_state.update(running=False, progress='')
        _fb_lock.release()


@app.route('/sauvegardes')
def full_backups_page():
    resp = admin_required_check()
    if resp is not None:
        return resp
    return render_template('backups.html', company=get_company_name(), username=session.get('username'))


@app.route('/api/full-backups')
def api_full_backups():
    resp = admin_required_check()
    if resp is not None:
        return resp
    cfg = fb_cfg()
    try:
        items = fb_list()
        du = shutil.disk_usage(fb_dir())
        dir_error = None
    except (OSError, RuntimeError) as e:
        items, du, dir_error = [], None, f"Dossier inaccessible : {e}"
    return jsonify({'settings': cfg, 'default_dir': str(FB_DEFAULT_DIR), 'backups': items,
                    'total_size': sum(b['size'] for b in items), 'free': du.free if du else None,
                    'dir_error': dir_error, 'last': meta_get('fb_last'), 'last_error': meta_get('fb_last_error'),
                    'notify_error': meta_get('fb_notify_error'),
                    'running': _fb_state['running'], 'progress': _fb_state['progress'], 'error': _fb_state['error']})


@app.route('/api/full-backups/settings', methods=['POST'])
def api_full_backups_settings():
    resp = admin_required_check()
    if resp is not None:
        return resp
    data = request.get_json(silent=True) or {}
    try:
        hour = int(data.get('hour', 2))
        ret = int(data.get('retention', 30))
        if not 0 <= hour <= 23 or ret not in FB_RETENTIONS:
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': "Heure ou rétention invalide."}), 400
    emails = [e.strip() for e in re.split(r'[,;\s]+', data.get('notify_emails') or '') if e.strip()]
    bad = [e for e in emails if not _EMAIL_OK.match(e)]
    if bad:
        return jsonify({'ok': False, 'error': "Adresse courriel invalide : " + ", ".join(bad)}), 400
    mode = 'all' if data.get('notify_mode') == 'all' else 'fail'
    d = (data.get('dir') or '').strip() or str(FB_DEFAULT_DIR)
    try:
        p = Path(d)
        if not p.is_absolute():
            raise OSError("le chemin doit être complet (ex. E:\\Sauvegardes Kubios)")
        p.mkdir(parents=True, exist_ok=True)
        test = p / '.kubios_test'
        test.write_text('ok')
        test.unlink()
    except OSError as e:
        return jsonify({'ok': False, 'error': f"Dossier inutilisable : {e}"}), 400
    meta_set('fb_enabled', '1' if data.get('enabled', True) else '0')
    meta_set('fb_hour', hour)
    meta_set('fb_retention', ret)
    meta_set('fb_dir', '' if Path(d) == FB_DEFAULT_DIR else d)
    meta_set('fb_notify_emails', ','.join(emails))
    meta_set('fb_notify_mode', mode)
    log_audit('Paramètres des sauvegardes modifiés',
              f"{'activées' if data.get('enabled', True) else 'désactivées'} ; à {hour} h ; rétention {ret} jours ; dossier {d}"
              f" ; avis : {', '.join(emails) or 'aucun'} ({'à chaque sauvegarde' if mode == 'all' else 'échecs seulement'})")
    return jsonify({'ok': True})


@app.route('/api/full-backups/notify-test', methods=['POST'])
def api_full_backups_notify_test():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if not fb_cfg()['notify_emails']:
        return jsonify({'ok': False, 'error': "Inscris d'abord au moins une adresse, puis clique sur Enregistrer."}), 400
    sent, errors = fb_notify(True, test=True)
    log_audit('Avis de sauvegarde : courriel de test', f"{', '.join(sent) or 'aucun'}" + (f" ; erreurs : {'; '.join(errors)}" if errors else ""))
    return jsonify({'ok': bool(sent), 'sent': sent, 'errors': errors,
                    'error': "; ".join(errors) if errors and not sent else None})


@app.route('/api/full-backups/run', methods=['POST'])
def api_full_backups_run():
    resp = admin_required_check()
    if resp is not None:
        return resp
    try:
        res = full_backup('manuelle', session.get('username'))
    except RuntimeError as e:
        return jsonify({'ok': False, 'error': str(e)}), 409
    except Exception as e:
        return jsonify({'ok': False, 'error': f"Sauvegarde impossible : {e}"}), 500
    return jsonify(dict(res, ok=True))


def _fb_path(name):
    if not FB_NAME_RE.match(name or ''):
        return None
    p = fb_dir() / name
    return p if p.exists() else None


@app.route('/api/full-backups/<name>/download')
def api_full_backups_download(name):
    resp = admin_required_check()
    if resp is not None:
        return resp
    p = _fb_path(name)
    if p is None:
        return jsonify({'error': 'Sauvegarde introuvable.'}), 404
    log_audit('Sauvegarde complète téléchargée', name)
    return send_file(str(p), as_attachment=True, download_name=name)


def _fb_restore_response(path, label):
    try:
        res = full_restore(path, session.get('username'), label)
    except RuntimeError as e:
        return jsonify({'ok': False, 'error': str(e)}), 400
    except Exception as e:
        traceback.print_exc()
        return jsonify({'ok': False, 'error': f"Restauration impossible : {e}"}), 500
    session.clear()   # les comptes ont pu changer : on se reconnecte
    return jsonify(dict(res, ok=True))


@app.route('/api/full-backups/<name>/restore', methods=['POST'])
def api_full_backups_restore(name):
    resp = admin_required_check()
    if resp is not None:
        return resp
    if (request.get_json(silent=True) or {}).get('confirm') != 'RESTAURER':
        return jsonify({'ok': False, 'error': "Confirmation manquante."}), 400
    p = _fb_path(name)
    if p is None:
        return jsonify({'ok': False, 'error': 'Sauvegarde introuvable.'}), 404
    return _fb_restore_response(p, f"sauvegarde {name}")


@app.route('/api/full-backups/restore-upload', methods=['POST'])
def api_full_backups_restore_upload():
    resp = admin_required_check()
    if resp is not None:
        return resp
    if request.form.get('confirm') != 'RESTAURER':
        return jsonify({'ok': False, 'error': "Confirmation manquante."}), 400
    f = request.files.get('file')
    if not f or not f.filename.lower().endswith('.zip'):
        return jsonify({'ok': False, 'error': "Choisis un fichier de sauvegarde Kubios (.zip)."}), 400
    tmp = Path(tempfile.mkstemp(suffix='.zip', prefix='kubios_upload_')[1])
    try:
        f.save(str(tmp))
        return _fb_restore_response(tmp, f"fichier téléversé {f.filename}")
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass
